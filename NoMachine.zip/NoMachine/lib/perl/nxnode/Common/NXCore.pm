############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
Common::NXCore::BEGIN{package Common::NXCore;no warnings;require strict;do{
"\x73\x74\x72\x69\x63\x74"->unimport ("\x72\x65\x66\x73")};}sub 
Common::NXCore::BEGIN{package Common::NXCore;no warnings;require strict;do{
"\x73\x74\x72\x69\x63\x74"->unimport ("\x73\x75\x62\x73")};}sub 
Common::NXCore::BEGIN{package Common::NXCore;no warnings;eval (
"\x73\x75\x62\x20\x53\x4e\x53\x7b\x40\x5f\x3b\x7d\x73\x75\x62\x20\x53\x4e\x7b\x24\x5f\x5b\x30\x5d\x3b\x7d"
);}package Common::NXCore;no warnings;require Common::NXFile;(our (@ISA)=
"\x45\x78\x70\x6f\x72\x74\x65\x72");sub BEGIN{require Exporter;do{
"\x45\x78\x70\x6f\x72\x74\x65\x72"->import};}(our (@EXPORT)=SNS (
"\x6e\x78\x72\x65\x61\x64","\x6e\x78\x77\x72\x69\x74\x65",
"\x6e\x78\x6f\x70\x65\x6e","\x6e\x78\x63\x6c\x6f\x73\x65",
"\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x52\x65\x64\x69\x72\x65\x63\x74\x65\x64"
,
"\x72\x65\x64\x69\x72\x65\x63\x74\x53\x74\x61\x6e\x64\x61\x72\x64\x53\x65\x72\x76\x65\x72\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73"
,"\x6e\x78\x72\x65\x61\x64\x4c\x69\x6e\x65",
"\x61\x64\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x54\x6f\x4e\x58\x50\x4c\x41\x72\x72\x61\x79"
,
"\x72\x65\x6d\x6f\x76\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x46\x72\x6f\x6d\x4e\x58\x50\x4c\x41\x72\x72\x61\x79"
,"\x70\x61\x72\x73\x65\x5f\x63\x6f\x6e\x66\x69\x67\x5f\x66\x69\x6c\x65",
"\x69\x6e\x69\x74\x5f\x62\x79\x5f\x63\x6f\x6e\x66\x69\x67\x5f\x66\x69\x6c\x65",
"\x6e\x78\x73\x6c\x65\x65\x70",
"\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x4d\x6f\x6e\x6f",
"\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x42\x69",
"\x6e\x78\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x6e\x78\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x42\x67",
"\x6e\x78\x45\x78\x65\x63\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x6e\x78\x65\x78\x69\x74",
"\x6e\x78\x4c\x69\x73\x74\x65\x6e\x4f\x6e\x53\x6f\x63\x6b\x65\x74",
"\x6e\x78\x73\x65\x6c\x65\x63\x74",
"\x6e\x78\x41\x63\x63\x65\x70\x74\x53\x6f\x63\x6b\x65\x74",
"\x6e\x78\x66\x6c\x6f\x63\x6b","\x6e\x78\x63\x6f\x6e\x6e\x65\x63\x74",
"\x6e\x78\x67\x65\x74\x53\x54\x44\x49\x4e",
"\x6e\x78\x67\x65\x74\x53\x54\x44\x4f\x55\x54",
"\x6e\x78\x67\x65\x74\x53\x54\x44\x45\x52\x52",
"\x6e\x78\x63\x68\x65\x63\x6b\x50\x69\x70\x65",
"\x6e\x78\x72\x65\x73\x74\x6f\x72\x65\x53\x54\x44\x45\x52\x52",
"\x6e\x78\x72\x65\x64\x69\x72\x65\x63\x74\x53\x54\x44\x45\x52\x52",
"\x64\x65\x66\x69\x6e\x65",
"\x72\x65\x64\x69\x72\x65\x63\x74\x53\x74\x64\x65\x72\x72\x4e\x58\x50\x4c",
"\x68\x69\x64\x65\x4f\x75\x74\x70\x75\x74",
"\x6e\x78\x43\x68\x65\x63\x6b\x44\x65\x73\x6b\x74\x6f\x70\x4f\x77\x6e\x65\x72",
"\x72\x65\x73\x74\x6f\x72\x65\x53\x74\x61\x6e\x64\x61\x72\x64\x53\x65\x72\x76\x65\x72\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73"
,"\x63\x6c\x6f\x73\x65\x53\x6f\x63\x6b\x65\x74\x41\x74\x46\x69\x6e\x69\x73\x68",
"\x64\x6f\x4e\x6f\x74\x43\x6c\x6f\x73\x65\x53\x6f\x63\x6b\x65\x74\x41\x74\x46\x69\x6e\x69\x73\x68"
,"\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65","\x75\x72\x6c\x64\x65\x63\x6f\x64\x65",
"\x6e\x78\x54\x69\x6d\x65",
"\x61\x64\x64\x46\x68\x54\x6f\x4d\x6f\x6e\x69\x74\x6f\x72",
"\x6e\x78\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c",
"\x6c\x6f\x61\x64\x41\x67\x65\x6e\x74\x4c\x69\x62\x72\x61\x72\x69\x65\x73",
"\x6c\x6f\x61\x64\x41\x6c\x6c\x4d\x6f\x64\x75\x6c\x65\x73\x4c\x69\x62\x72\x61\x72\x69\x65\x73"
,"\x6c\x6f\x61\x64\x4e\x58\x4c\x69\x62\x72\x61\x72\x79",
"\x69\x73\x4e\x58\x4c\x69\x62\x72\x61\x72\x79\x4c\x6f\x61\x64\x65\x64\x46\x6f\x72\x4d\x6f\x64\x75\x6c\x65"
));($NXCore::currentNXSelectDescriptors={});($NXCore::descriptorsRedirected=
"\x6e\x6f");%NXCore::NXPLDescriptorsArray;(@NXCore::runCommandEnvironment=());(
$NXCore::runCommandPriority=(""));($NXCore::nodePriority=
"\x6e\x6f\x74\x53\x65\x74");$NXCore::readBuffer;%NXCore::UserInfo;
%NXCore::systemExitCodes;($NXCore::WMRunningTimeout_default=(0x0ae4+ 537-0x0b09)
);($NXCore::WMRunningTimeout_max=10000);($NXCore::WMRunningTimeout=
$NXCore::WMRunningTimeout_default);(@NXCore::NXServerLibraryList=(
"\x6c\x69\x62\x6e\x78\x68","\x6c\x69\x62\x6e\x78\x68\x73"));(
@NXCore::NXNodeLibraryList=("\x6c\x69\x62\x6e\x78\x68",
"\x6c\x69\x62\x6e\x78\x68\x6e"));(@NXCore::NXAgentLibraryList=
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67");(@NXCore::NXWebPlayerLibraryList=(
"\x6c\x69\x62\x6e\x78\x68","\x6c\x69\x62\x6e\x78\x68\x73"));($$NXCore::NXLibrary
{"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}={
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67",(0x03f7+ 1257-0x08e0),
"\x6c\x69\x62\x6e\x78\x68",(0x0737+ 7476-0x246b),"\x6c\x69\x62\x6e\x78\x68\x6e",
(0x06c2+ 4047-0x1691),"\x6c\x69\x62\x6e\x78\x68\x73",(0x0a76+ 4831-0x1d55)});(
$NXCore::nxselectIteration=(0x0737+ 3270-0x13fd));($NXCore::nxstdinClosed=
(0x0358+ 6352-0x1c28));($NXCore::windowsConsoleCPGet=(0x005d+ 4266-0x1107));sub 
shouldExitFromSelectOnFirstSignal{if (($GLOBAL::finishSelect==
(0x0622+ 7056-0x21b1))){return ((0x0114+ 4942-0x1461));}return (
(0x0293+ 8062-0x2211));}sub exitFromSelectOnFirstSignal{($GLOBAL::finishSelect=
(0x0321+ 1675-0x09ab));}sub disableExitFromSelectOnFirstSignal{(
$GLOBAL::finishSelect=(0x1c76+ 1295-0x2185));}sub 
getExitFromSelectOnFirstSignalFlag{return ($GLOBAL::finishSelect);}sub 
setExitFromSelectOnFirstSignalFlagValue{(my $finishSelect=shift (@_));(
$GLOBAL::finishSelect=$finishSelect);}sub shouldExitFromSelectWithSignalFD{if ((
$GLOBAL::finishSelectWithSignalFD==(0x0049+ 3753-0x0ef1))){return (
(0x08c7+ 5028-0x1c6a));}return ((0x0627+ 7793-0x2498));}sub 
exitFromSelectWithSignalFD{($GLOBAL::finishSelectWithSignalFD=
(0x00b6+ 5652-0x16c9));}sub disableExitFromSelectWithSignalFD{(
$GLOBAL::finishSelectWithSignalFD=(0x1f64+ 201-0x202d));}sub isNxstdinClosed{
return ($NXCore::nxstdinClosed);}sub setNxstdinClosed{($NXCore::nxstdinClosed=
(0x1a1f+ 524-0x1c2a));}sub nxselect{(my $ref_descriptors=shift (@_));(my $timeout
=shift (@_));(my $ref_result=shift (@_));(my $silence=shift (@_));($silence=
undef);(my $starttime=int ((main::nxTime ()*(0x119b+ 2655-0x1812))));if (((not (
defined ($timeout)))or ($timeout<(-(0x1994+ 711-0x1c5a))))){($timeout=(-
(0x00da+ 6445-0x1a06)));}__setCurrentNXSelectDescriptos ($ref_descriptors);(my $usingFirstCallbackAsTimeout
=(0x0d04+ 5987-0x2467));my ($nxselectTimeoutTimestamp);my (
$firstCallbackTimestamp);if (Common::NXSelector::isAnyTimestampCallbackWaiting 
()){($nxselectTimeoutTimestamp=($starttime+$timeout));($firstCallbackTimestamp=(
Common::NXSelector::getFirstTimestampCallback ()*(0x05bd+ 6650-0x1bcf)));if (
isCallbackTimestampBeforeSelectTimeout ($nxselectTimeoutTimestamp,
$firstCallbackTimestamp)){if (isTimeToRunTimestampCallback (
$firstCallbackTimestamp,$starttime)){
Common::NXSelector::runFirstTimestampCallback ();return (
runNextIterationAfterRunCallback (__getCurrentNXSelectDescriptorsAndClean (),
$ref_result,$nxselectTimeoutTimestamp,$starttime));}else{($timeout=
setNewSelectTimeout ($firstCallbackTimestamp,$starttime));}(
$usingFirstCallbackAsTimeout=(0x04dc+ 5637-0x1ae0));}}(my $length=
Common::NXSelector::countNonGlobalHandlers ($ref_descriptors));(my $descriptors=
(""));(my $log_descriptors=(""));foreach my $a (@$ref_descriptors){if ((
$descriptors eq (""))){($descriptors=($descriptors.$a));($log_descriptors=((
$log_descriptors."\x46\x44\x23").$a));}else{($descriptors=(($descriptors."\x2c")
.$a));($log_descriptors=(($log_descriptors."\x2c\x20\x46\x44\x23").$a));}}if ((
not (defined ($silence)))){Logger::debug2 (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x28".
$log_descriptors)."\x2c\x20").$timeout)."\x29"));}if (defined (
$NXBegin::MonitoredHandler)){($descriptors.=("\x2c".$NXBegin::MonitoredHandler))
;}(my $return=libnxh::NXSelect ($descriptors,$timeout));if (($timeout!=(-
(0x00fd+ 1098-0x0546)))){(my $actualTime=int ((main::nxTime ()*
(0x069d+ 2529-0x0c96))));($timeout=($timeout-($actualTime-$starttime)));if ((
$timeout<(0x0ba1+ 5272-0x2038))){($timeout=(0x0990+ 7264-0x25f0));}}(my (@result
)=());if (($return==(0x0cec+ 1510-0x12d2))){if ($usingFirstCallbackAsTimeout){
Common::NXSelector::runFirstTimestampCallback ();return (
runNextIterationAfterRunCallback (__getCurrentNXSelectDescriptorsAndClean (),
$ref_result,$nxselectTimeoutTimestamp,$firstCallbackTimestamp));}else{(
@$ref_result=@result);__cleanCurrentNXSelectIteration ();return;}}($return=~ /(-?\d+):(.*)/ )
;(my $exitcode=$1);(my $ready=$2);if (($exitcode==(-(0x0401+ 8145-0x23d1)))){(my $error
=libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());if ((
$error ne "\x45\x49\x4e\x54\x52")){Logger::error (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x28".
$descriptors).
"\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27"
).$errorstring)."\x27\x2e"));}else{Logger::debug2 (
"\x53\x65\x6c\x65\x63\x74\x20\x65\x78\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x45\x49\x4e\x54\x52"
);}(@$ref_result=@result);if (($error eq "\x45\x42\x41\x44\x46")){nxexit ();}
__cleanCurrentNXSelectIteration ();return;}my ($spacepos);my ($fh);(my $signalFd
=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});if ((not (($ready=~ /\d+/ )))){(
@$ref_result=@result);__cleanCurrentNXSelectIteration ();return;}while ((length 
($ready)>(0x0427+ 7094-0x1fdd))){($spacepos=index ($ready,"\x2c"));if ((
$spacepos>(0x0152+ 7846-0x1ff8))){($fh=substr ($ready,(0x0e59+ 6111-0x2638),
$spacepos));if (($fh==$signalFd)){$NXBegin::parser->checkSignal;if ((($length==
(0x0631+ 3730-0x14c2))or shouldExitFromSelectOnFirstSignal ())){
disableExitFromSelectOnFirstSignal ();if (shouldExitFromSelectWithSignalFD ()){
disableExitFromSelectWithSignalFD ();push (@$ref_result,$signalFd);}
__cleanCurrentNXSelectIteration ();return (());}if (($exitcode==
(0x0129+ 4740-0x13ac))){return (nxselect (
__getCurrentNXSelectDescriptorsAndClean (),$timeout,$ref_result));}}elsif (
Common::NXSelector::handleGlobalSelectorDescriptor ($fh)){Logger::debug (((
"\x46\x44\x23".$fh).
"\x20\x68\x61\x6e\x64\x6c\x65\x64\x20\x62\x79\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72"
));push (@result,$fh);last;}else{push (@result,$fh);}($ready=substr ($ready,(
$spacepos+(0x0755+ 5579-0x1d1f)),length ($ready)));}else{if (($ready==$signalFd)
){$NXBegin::parser->checkSignal;if ((($length==(0x06da+ 3452-0x1455))or 
shouldExitFromSelectOnFirstSignal ())){disableExitFromSelectOnFirstSignal ();if 
(shouldExitFromSelectWithSignalFD ()){disableExitFromSelectWithSignalFD ();push 
(@$ref_result,$signalFd);}__cleanCurrentNXSelectIteration ();return (());}if ((
$exitcode==(0x0c28+ 3952-0x1b97))){return (nxselect (
__getCurrentNXSelectDescriptorsAndClean (),$timeout,$ref_result));}}elsif ((
defined ($NXBegin::MonitoredHandler)and ($ready==$NXBegin::MonitoredHandler))){(my $callback
=$NXBegin::MonitoredHandlerCallback);if (defined ($callback)){&{$callback;}(
$ready);}($NXBegin::MonitoredHandler=undef);($NXBegin::MonitoredHandlerCallback=
undef);if (($exitcode==(0x0f45+ 4619-0x214f))){return (nxselect (
__getCurrentNXSelectDescriptorsAndClean (),$timeout,$ref_result));}}elsif (
Common::NXSelector::handleGlobalSelectorDescriptor ($ready)){Logger::debug2 (((
"\x46\x44\x23".$ready).
"\x20\x68\x61\x6e\x64\x6c\x65\x64\x20\x62\x79\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72"
));push (@result,$ready);last;}else{push (@result,$ready);}last;}}if ((not (
defined ($silence)))){foreach my $a (@result){Logger::debug2 ((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x3a\x20\x46\x44\x23"
.$a));}}(@$ref_result=@result);__cleanCurrentNXSelectIteration ();return;}sub 
restoreStandardServerDescriptors{($GLOBAL::DefaultSTDINDescriptor=
(0x0481+ 627-0x06f4));($GLOBAL::DefaultSTDOUTDescriptor=(0x01b9+ 8818-0x242a));(
$NXCore::descriptorsRedirected="\x6e\x6f");}sub 
redirectStandardServerDescriptors{($NXCore::descriptorsRedirected="\x79\x65\x73"
);Logger::debug2 ((
"\x52\x65\x64\x69\x72\x65\x63\x74\x20\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x62\x61\x73\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$GLOBAL::SOCKET_PASSED));($GLOBAL::DefaultSTDINDescriptor=
$GLOBAL::SOCKET_PASSED);if ((not (($GLOBAL::SOCKET_PASSED>=(0x0b3a+ 2337-0x145b)
)))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x65\x72\x76\x65\x72\x20\x73\x74\x64\x69\x6e\x2c\x20\x62\x61\x64\x20\x46\x44\x23"
.$GLOBAL::SOCKET_PASSED));}else{Logger::debug ((
"\x53\x45\x52\x56\x45\x52\x5f\x53\x54\x44\x49\x4e\x3a\x20".nxgetSTDIN ()));}(
$GLOBAL::DefaultSTDOUTDescriptor=$GLOBAL::SOCKET_PASSED);if ((not ((
$GLOBAL::SOCKET_PASSED>=(0x0252+ 966-0x0618))))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x65\x72\x76\x65\x72\x20\x73\x64\x74\x6f\x75\x74\x2c\x20\x62\x61\x64\x20\x46\x44\x23"
.$GLOBAL::SOCKET_PASSED));}else{Logger::debug ((
"\x53\x45\x52\x56\x45\x52\x5f\x53\x54\x44\x4f\x55\x54\x3a\x20".nxgetSTDOUT ()));
}}sub descriptorsRedirected{if (($NXCore::descriptorsRedirected eq 
"\x79\x65\x73")){return ((0x1aba+ 2929-0x262a));}return ((0x160d+ 887-0x1984));}
sub nxopen{(my $filepath=shift (@_));(my $mode=shift (@_));(my $permissions=(
shift (@_)||(0x17af+ 3513-0x2568)));(my $silent=(shift (@_)||{}));(my $modret=(-
(0x00c1+ 5413-0x15e5)));(my $setRights=(0x114a+ 3090-0x1d5c));(my ($package,
$filename,$line,$sub)=caller ((0x1340+ 1233-0x1810)));if (($sub eq (""))){($sub=
$package);}unless (Common::NXFile::isExists ($filepath)){($setRights=
(0x12c7+ 1724-0x1982));}(my $filepathToNXOpen=$filepath);($filepathToNXOpen=
convertStringFromWindowsCodePageToUtf8 ($filepathToNXOpen));(my $ret=
libnxh::NXOpen ($filepathToNXOpen,$mode,$permissions));if (($ret==(-
(0x07f3+ 6521-0x216b)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());if (__warningShouldBeLogged ($sub,$errorNumber,
$silent)){__reportWarningNXOpenFail ($filepath,$mode,$silent,$errorNumber,
$errorstring);}return (undef);}if (((($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6f\x70\x65\x6e\x4c\x6f\x67\x46\x69\x6c\x65"
)and isNXLibraryLoadedForModule ())and ($sub ne 
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72\x3a\x3a\x69\x6e\x69\x74\x42\x61\x63\x6b\x75\x70"
))){Logger::debug ((((((((((("\x4e\x58\x4f\x70\x65\x6e\x20\x46\x44\x23".$ret).
"\x20\x2d\x20\x66\x69\x6c\x65\x20").$filepath).
"\x20\x77\x69\x74\x68\x20\x6d\x6f\x64\x65\x20").$mode).
"\x20\x61\x6e\x64\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20").
$permissions)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}if ($setRights){my (
$errorName);my ($errorNumber);if (($permissions==(0x028b+ 5613-0x1878))){(
$permissions=$NXBits::UserReadWrite);}($modret=
Common::NXFile::setPermissionSilent ($filepath,$permissions,(\$errorName),(
\$errorNumber)));if (($modret==(-(0x07a9+ 6647-0x219f)))){if (
__warningShouldBeLogged ($sub,$errorNumber,$silent)){Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$filepath)."\x20\x74\x6f\x20").$permissions)."\x2e\x20").$errorNumber).
"\x2c\x20").$errorName)."\x2e"));}return (undef);}}closeSocketAtFinish ($ret);
return ($ret);}sub __warningShouldBeLogged{(my $sub=shift (@_));(my $error=shift
 (@_));(my $silent=shift (@_));if (($sub eq 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6f\x70\x65\x6e\x4c\x6f\x67\x46\x69\x6c\x65"
)){return ((0x1dd9+ 2357-0x270e));}if ((not (isNXLibraryLoadedForModule ()))){
return ((0x14c9+ 1494-0x1a9f));}if (($sub eq 
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72\x3a\x3a\x69\x6e\x69\x74\x42\x61\x63\x6b\x75\x70"
)){return ((0x1ecc+ 1824-0x25ec));}if (defined ($$silent{"\x41\x4c\x4c"})){
return ((0x04a9+ 6016-0x1c29));}if (((ErrnoENOENT ()==$error)and defined (
$$silent{"\x45\x4e\x4f\x45\x4e\x54"}))){return ((0x1080+ 3758-0x1f2e));}if (((
ErrnoEACCES ()==$error)and defined ($$silent{"\x45\x41\x43\x43\x45\x53"}))){
return ((0x16fb+ 3836-0x25f7));}return ((0x139b+ 3497-0x2143));}sub 
__reportWarningNXOpenFail{(my $filepath=shift (@_));(my $mode=shift (@_));(my $silent
=shift (@_));(my $errorNumber=shift (@_));(my $errorstring=shift (@_));(my $accessLog
=(""));(my $modeLog=(""));if (((ErrnoEACCES ()==$errorNumber)and defined (
$$silent{"\x45\x41\x43\x43\x45\x53"}))){($accessLog=(("\x55\x73\x65\x72\x20".
getEffectiveUsername ())."\x20"));if ((($mode %(0x05a9+ 2563-0x0faa))==
(0x047f+ 4099-0x1481))){($modeLog="\x20\x74\x6f\x20\x77\x72\x69\x74\x65");}else{
($modeLog="\x20\x74\x6f\x20\x72\x65\x61\x64");}Logger::warning (((($accessLog.
"\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e").$modeLog).(("\x3a\x20".$filepath
)."\x2e")));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));}else{Logger::warning (
(("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20".$filepath)."\x2e"));
Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20\x27").$errorstring)."\x27\x2e"));}}sub nxclose{(my $file=shift (@_));(my $firstCaller
=(caller ((0x023d+ 4463-0x13a9)))[(0x0708+ 3745-0x15a6)]);($firstCaller=~ s/:.*//s )
;(my ($package,$filename,$line,$sub)=caller ((0x09bd+ 3197-0x1639)));if (($sub 
eq (""))){($sub=$package);}(my $silence=(shift (@_)||"\x6e\x6f"));if ((not (
defined ($file)))){if (((!$silence)=="\x6e\x6f")){Logger::error (((
"\x4e\x58\x43\x6c\x6f\x73\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e"));}return ((0x0a38+ 5905-0x2149));}if ((($firstCaller ne 
"\x4c\x6f\x67\x67\x65\x72")and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x63\x6c\x6f\x73\x65\x4c\x6f\x67\x46\x69\x6c\x65"
))){Logger::debug ((((("\x4e\x58\x43\x6c\x6f\x73\x65\x20\x46\x44\x23".$file).
"\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}if (exists ($$NXCore::readBuffer{
$file})){delete ($$NXCore::readBuffer{$file});}
__removeDescriptorFromNXSelectCurrentList ($file);if (exists (
$$NXBegin::SocketsToClose{$file})){delete ($$NXBegin::SocketsToClose{$file});}
else{if ((($sub ne "\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67")and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x63\x6c\x6f\x73\x65\x4c\x6f\x67\x46\x69\x6c\x65"
))){Logger::warning (((((
"\x4e\x58\x43\x6c\x6f\x73\x65\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$file)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}return;}(my $ret=
libnxh::NXDescriptorClose ($file));return ((!$ret));}sub nxreadLine{(my $filehandle
=shift (@_));(my $readBuffer=shift (@_));(my $line=(""));(my $eolpos=(-
(0x1b64+ 2119-0x23aa)));(my $block=($GLOBAL::lengthOfReadLineBlock||
(0x010b+ 2068-0x089f)));(my $blockread=(0x04cc+ 5258-0x1956));($$readBuffer=("")
);if ((not (exists ($$NXCore::readBuffer{$filehandle})))){($$NXCore::readBuffer{
$filehandle}=(""));my ($buffer);while (main::nxread ($filehandle,(\$buffer),
16384)){($$NXCore::readBuffer{$filehandle}=($$NXCore::readBuffer{$filehandle}.
$buffer));}}($eolpos=index ($$NXCore::readBuffer{$filehandle},"\x0a"));if ((
$eolpos==(-(0x14f4+ 3495-0x229a)))){($line=$$NXCore::readBuffer{$filehandle});(
$$NXCore::readBuffer{$filehandle}=(""));}else{($line=substr (
$$NXCore::readBuffer{$filehandle},(0x0efd+ 584-0x1145),($eolpos+
(0x0626+ 3803-0x1500))));($$NXCore::readBuffer{$filehandle}=substr (
$$NXCore::readBuffer{$filehandle},($eolpos+(0x0bba+ 4171-0x1c04)),length (
$$NXCore::readBuffer{$filehandle})));}($line=~ s/\r//g );($$readBuffer=$line);
return (length ($line));}sub nxread{(my $FD_passed=shift (@_));(my $readBuffer=
shift (@_));(my $length=(shift (@_)||(0x0e6f+ 1791-0x0d6e)));(my $tmpRead=(
"\x20" x ($length+(0x05d9+ 687-0x0887))));(my $readLength=(0x13db+ 2776-0x1eb3))
;(my $FD_correct=$FD_passed);if ((ref ($FD_passed)and isNXLibraryLoadedForModule
 ())){if (($$FD_passed=~ /\*main::(\d+)/ )){($FD_correct=$1);}else{Logger::error
 ((("\x43\x61\x6e\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20".
$$FD_passed)."\x20\x74\x6f\x20\x69\x6e\x74"));nxexit ();}}($readLength=
libnxh::NXRead ($FD_correct,$tmpRead,$length));if ((not (defined ($readLength)))
){return (undef);}elsif (($readLength>(0x03fd+ 3304-0x10e5))){($$readBuffer=
substr ($tmpRead,(0x1495+ 3988-0x2429),$readLength));return ($readLength);}elsif
 (($readLength==(-(0x0eb7+ 3038-0x1a94)))){return (undef);}else{return (
$readLength);}}sub nxwrite{(my $FD_passed=shift (@_));(my $message=shift (@_));
if ((not (defined ($message)))){($message=(""));}(my $length=(shift (@_)||length
 ($message)));(my $offset=shift (@_));(my $silent=(shift (@_)||
(0x0abb+  74-0x0b05)));if (($length==(0x02e8+ 3906-0x122a))){return;}(my (
$package,$filename,$line,$sub)=caller ((0x05fa+ 8001-0x253a)));(my $FD_correct=
$FD_passed);if ((ref ($FD_passed)and isNXLibraryLoadedForModule ())){if ((
$$FD_passed=~ /\*main::(\d+)/ )){($FD_correct=$1);}else{nxwrite (
(0x0d8b+ 3297-0x1a6a),((
"\x6e\x78\x77\x72\x69\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20"
.$$FD_passed).
"\x20\x74\x6f\x20\x69\x6e\x74\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x65\x2e\x0a"))
;nxexit ();}}if ((defined ($offset)and ($offset ne ("")))){if (
isNXLibraryLoadedForModule ()){(my $nxwriteReturn=libnxh::NXWrite ($FD_correct,
$message,$length));if ((($nxwriteReturn==(-(0x0351+ 2036-0x0b44)))and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x54\x6f\x4c\x6f\x67\x66\x69\x6c\x65"
))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x46\x44\x23".
$FD_correct)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}return ($nxwriteReturn);}return (syswrite (
$FD_correct,$message,$length,$offset));}if (isNXLibraryLoadedForModule ()){(my $nxwriteReturn
=libnxh::NXWrite ($FD_correct,$message,$length));if ((($nxwriteReturn==(-
(0x0853+ 6765-0x22bf)))and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x54\x6f\x4c\x6f\x67\x66\x69\x6c\x65"
))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x46\x44\x23".
$FD_correct)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}return ($nxwriteReturn);}return (syswrite (
$$FD_correct,$message,$length));}sub setRunCommandEnv{(
@NXCore::runCommandEnvironment=@_);}sub getRunCommandEnv{return (
@NXCore::runCommandEnvironment);}sub cleanRunCommandEnv{(
@NXCore::runCommandEnvironment=());}sub setRunCommandPriority{(
$NXCore::runCommandPriority=shift (@_));}sub getRunCommandPriority{return (
$NXCore::runCommandPriority);}sub setCommandEnvironment{(my (@envToSet)=
getRunCommandEnv ());while ((my $key=shift (@envToSet))){(my $value=shift (
@envToSet));($ENV{$key}=$value);Logger::debug ((((
"\x73\x65\x74\x43\x6f\x6d\x6d\x61\x6e\x64\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x20\x27"
.$key)."\x27\x3d").$ENV{$key}),(0x0f7b+ 1736-0x1642));}}sub isNodeNormalPriority
{if ((getNodePriority ()eq "\x6e\x6f\x72\x6d\x61\x6c")){return (
(0x0392+ 2978-0x0f33));}return ((0x0509+ 329-0x0652));}sub isNodeLowPriority{if 
((getNodePriority ()eq "\x6c\x6f\x77")){return ((0x0b28+ 657-0x0db8));}return (
(0x0ea5+ 3549-0x1c82));}sub setNodePriority{($NXCore::nodePriority=shift (@_));}
sub getNodePriority{if (($NXCore::nodePriority eq "\x6e\x6f\x74\x53\x65\x74")){(
$NXCore::nodePriority=$GLOBAL::DisplayAgentPriority);}return (
$NXCore::nodePriority);}sub addDescriptorToNXPLArray{(my $descriptor=shift (@_))
;if (exists ($NXCore::NXPLDescriptorsArray{$descriptor})){Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$descriptor).
"\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x69\x6e\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}else{($NXCore::NXPLDescriptorsArray{$descriptor}=(0x0f66+ 5230-0x23d3));
Logger::debug ((("\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".
$descriptor).
"\x20\x61\x64\x64\x65\x64\x20\x74\x6f\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}}sub removeDescriptorFromNXPLArray{(my $descriptor=shift (@_));if (exists (
$NXCore::NXPLDescriptorsArray{$descriptor})){delete (
$NXCore::NXPLDescriptorsArray{$descriptor});Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$descriptor).
"\x20\x64\x65\x6c\x65\x74\x65\x64\x20\x66\x72\x6f\x6d\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}else{Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$descriptor).
"\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}}sub ioShouldBeDoneThroughNXPL{(my $descriptor=shift (@_));if (exists (
$NXCore::NXPLDescriptorsArray{$descriptor})){return ((0x061c+ 363-0x0786));}else
{return ((0x0240+ 3664-0x1090));}}sub parse_config_line{(my $line=shift (@_));(my $acceptable_keys
=shift (@_));chomp ($line);($line=main::trimLine ($line));if (($line=~ /^[ \t]*#/ )
){return;}elsif (($line=~ /^([ \t]*([^=;#]+)\s[ \s=]*"([^"]*))"$/ )){(my ($key,
$value)=($2,$3));($key=main::trimLine ($key));($value=main::trimLine ($value));
if ((not (defined ($value)))){($value=(""));}if ((($key=~ /(^$acceptable_keys$)/ )
or ($GLOBAL::REFRESH_CFG==(0x17ad+ 2295-0x20a3)))){main::redefine ($key,$value);
}}else{(my ($key,$value)=split ( / / ,$line,(0x0688+ 1891-0x0de9)));($key=
main::trimLine ($key));($value=~ s/(=|")//g );($value=main::trimLine ($value));
if (($value=~ /\s/ )){return;}if (((not (defined ($value)))or ($value eq (""))))
{if (($key eq 
"\x44\x69\x73\x61\x62\x6c\x65\x50\x65\x72\x73\x69\x73\x74\x65\x6e\x74\x53\x65\x73\x73\x69\x6f\x6e"
)){($value=(""));}else{return;}}if ((($key=~ /(^$acceptable_keys$)/ )or (
$GLOBAL::REFRESH_CFG==(0x044b+  82-0x049c)))){main::redefine ($key,$value);}}}
sub parse_config_line_init{(my $line=shift (@_));(my $config_file=shift (@_));
chomp ($line);($line=main::trimLine ($line));if ((($line eq (""))or ($line=~ /^#/ )
)){return;}elsif (($line=~ /^([ \t]*([^=;#]+)\s[ \s=]*"([^"]*))"$/ )){(my ($key,
$value)=($2,$3));($key=main::trimLine ($key));($value=main::trimLine ($value));
if ((not (defined ($value)))){($value=(""));}if ((($key=~ /(^$GLOBAL::OVERRIDABLE_USER_CONFIG_KEYS$)/ )
or ($GLOBAL::REFRESH_CFG==(0x046c+ 148-0x04ff)))){main::redefine ($key,$value);}
else{(my $kkey=("\x47\x4c\x4f\x42\x41\x4c\x3a\x3a".$key));if (defined ($$kkey)){
Logger::debug (((((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x20\x27"
.$key).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x72\x65\x64\x65\x66\x69\x6e\x65\x64\x20\x69\x6e\x20\x27"
).$config_file)."\x27"),(0x056a+ 4892-0x1886));}else{main::define ($key,$value);
}}}else{(my ($key,$value)=split ( /\s/ ,$line,(0x0593+ 1763-0x0c74)));($key=
main::trimLine ($key));if (($value=~ /^=(.*)/ )){($value=$1);}($value=~ s/"//g )
;($value=main::trimLine ($value));if (($value=~ /\s/ )){return;}if (((not (
defined ($value)))or ($value eq ("")))){if (((($key eq 
"\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x4c\x69\x62\x72\x61\x72\x79\x50\x72\x65\x6c\x6f\x61\x64"
)or ($key eq 
"\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x4c\x69\x62\x72\x61\x72\x79\x50\x61\x74\x68"
))or ($key eq 
"\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64\x73"
))){($value=(""));}else{return;}}if ((($key=~ /(^$GLOBAL::OVERRIDABLE_USER_CONFIG_KEYS$)/ )
or ($GLOBAL::REFRESH_CFG==(0x0d29+ 4723-0x1f9b)))){if ((
$GLOBAL::KEYS_WITH_YES_NO_NONE_ACCEPT_VALUE=~ /\($key\)/ )){if ((($value eq 
"\x79\x65\x73")or ($value eq "\x65\x6e\x61\x62\x6c\x65\x64"))){($value=
(0x0235+ 7545-0x1fad));}elsif (((($value eq "\x6e\x6f")or ($value eq 
"\x6e\x6f\x6e\x65"))or ($value eq "\x64\x69\x73\x61\x62\x6c\x65\x64"))){($value=
(0x154d+ 4231-0x25d4));}}main::redefine ($key,$value);}else{(my $kkey=(
"\x47\x4c\x4f\x42\x41\x4c\x3a\x3a".$key));if (defined ($$kkey)){Logger::debug ((
(((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x20\x27"
.$key).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x72\x65\x64\x65\x66\x69\x6e\x65\x64\x20\x69\x6e\x20\x27"
).$config_file)."\x27"),(0x207a+ 1070-0x24a8));}else{main::define ($key,$value);
}}}}sub define{(my ($key,$value)=@_);(my $kkey=(
"\x47\x4c\x4f\x42\x41\x4c\x3a\x3a".$key));if (((not (defined ($$kkey)))or (
$GLOBAL::REFRESH_CFG==(0x1d47+ 104-0x1dae)))){($$kkey=$value);}}sub parse_buffer
{(my $buffer=shift (@_));(my $config_file=shift (@_));(my $acceptable_keys=(
shift (@_)||(-(0x04a3+ 2617-0x0edb))));(my $finish=(0x0d6b+ 5987-0x24ce));(my $firstchar
=(""));(my $line=(""));(my $oldline=(""));(my $oldpos=(-(0x01b3+ 160-0x0252)));my (
$newpos);while ((not ($finish))){if (($buffer=~ /\G(.*)([\n])/cg )){($firstchar=
substr ($1,(0x148f+ 2571-0x1e9a),(0x0e18+ 3235-0x1aba)));if (($2 eq (""))){(
$buffer=~ /\G(.*)$/g );($oldline=$1);($finish=(0x0ee8+ 3627-0x1d12));}else{(
$line=($1."\x0a"));($line=~ s/\r//g );if (($acceptable_keys==(-
(0x1ed6+  49-0x1f06)))){parse_config_line_init ($line,$config_file);}else{
parse_config_line ($line,$acceptable_keys);}}}else{($finish=
(0x014a+ 2072-0x0961));}}return ($oldline);}sub init_by_config_file{(my (
$config_file,$errorString_ref)=@_);my ($fd);my ($errorNumber);if ((not (defined 
($config_file)))){Logger::error (
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
,(0x08aa+ 787-0x0bbc));error ("\x69\x6e\x69\x74",
"\x69\x6e\x69\x74\x20\x62\x79\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65",
"\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
);}if (Common::NXFile::isExists ($config_file)){($fd=main::nxopen ($config_file,
$NXBits::FileOpenRead,(0x0817+ 1273-0x0d10)));($errorNumber=libnxh::NXGetError 
());($$errorString_ref=libnxh::NXGetErrorString ());}else{return (
(0x0814+ 6047-0x1fb2));}if ((not (defined ($fd)))){Logger::error (((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20\x27"
.$config_file)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$$errorString_ref)."\x2e"));return ((0x223a+  48-0x2269));}Logger::debug (((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x70\x61\x72\x73\x65\x20\x6f\x66\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20\x27"
.$config_file)."\x27"),(0x085a+ 7121-0x242b));(my $processName=
NXBegin::getProcessName ());Logger::debug ((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x3a\x20"
.$processName),(0x0489+ 6218-0x1cd3));my ($buffer);while (main::nxreadLine ($fd,
(\$buffer))){parse_config_line_init ($buffer,$config_file);}main::nxclose ($fd);
return ((0x0415+ 1929-0x0b9e));}sub parse_config_file{(my ($config_file,
$acceptable_keys)=@_);my ($FILEH);if ((not (defined ($config_file)))){
Logger::error (
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
,(0x0661+ 8103-0x2607));error ("\x69\x6e\x69\x74",
"\x69\x6e\x69\x74\x20\x62\x79\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65",
"\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
);}if (Common::NXFile::isExists ($config_file)){($FILEH=main::nxopen (
$config_file,$NXBits::FileOpenRead,(0x09d3+ 3429-0x1738)));}else{return (
(0x07a2+ 5015-0x1b38));}if ((not (defined ($FILEH)))){return (
(0x0295+ 3940-0x11f8));}Logger::debug (((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x70\x61\x72\x73\x65\x20\x6f\x66\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20\x27"
.$config_file)."\x27"),(0x0fa8+ 5651-0x25bb));my ($buffer);while (
main::nxreadLine ($FILEH,(\$buffer))){parse_config_line ($buffer,
$acceptable_keys);}main::nxclose ($FILEH);return ((0x0cbd+ 1320-0x11e5));}sub 
reportErrorFromNXPL{(my $errorText=shift (@_));if (($errorText ne (""))){
Logger::error ($errorText);}else{(my ($package,$filename,$line,$sub)=caller (
(0x01d4+ 6546-0x1b65)));Logger::error (((
"\x54\x68\x65\x72\x65\x20\x69\x73\x20\x65\x72\x72\x6f\x72\x20\x77\x69\x74\x68\x20\x4e\x58\x50\x4c\x20\x69\x6e\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20"
.$sub)."\x2e"));}(my $errorString=logErrorFromNXPL ());return ($errorString);}
sub logErrorFromNXPL{(my $errorNumber=libnxh::NXGetError ());(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());my (
$reportedError);if ((($errorName ne (""))and ($errorName ne 
"\x53\x75\x63\x63\x65\x73\x73"))){if ((($errorNumber ne (""))and ($errorNumber 
ne "\x30"))){($reportedError=(($errorNumber."\x2c\x20").$errorName));}elsif (((
$errorString ne (""))and ($errorString ne "\x4e\x6f\x20\x65\x72\x72\x6f\x72"))){
($reportedError=(($errorName."\x2c\x20").$errorString));}else{($reportedError=
$errorName);}}elsif ((($errorNumber ne (""))and ($errorNumber ne "\x30"))){(
$reportedError=(($errorNumber."\x2c\x20").$errorName));}else{($reportedError=
"\x4e\x58\x50\x4c\x20\x64\x69\x64\x6e\x27\x74\x20\x72\x65\x70\x6f\x72\x74\x20\x74\x68\x65\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x72\x72\x6f\x72"
);Logger::debug2 (($reportedError."\x2e"));return ($reportedError);}
Logger::error ((("\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$reportedError)."\x2e"))
;return ($reportedError);}sub nxPipeCreateMono{(my $socket1=shift (@_));(my $socket2
=shift (@_));(my $ret=libnxh::NXPipeCreate ($$socket1,$$socket2,
(0x1088+ 4294-0x214e)));if (($ret==(-(0x0108+ 5816-0x17bf)))){(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning ((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorName)."\x2c\x20").$errorString));return ((0x0734+ 3258-0x13ee));}
closeSocketAtFinish ($$socket1);closeSocketAtFinish ($$socket2);Logger::debug ((
((((("\x4e\x58\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x28\x46\x44\x23".
$$socket1)."\x2c\x20\x46\x44\x23").$$socket2).
"\x2c\x20\x30\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$ret)."\x27"));
return (($ret+(0x09dc+ 5574-0x1fa1)));}sub nxPipeCreateBiWithError{(my $ref_socket1
=shift (@_));(my $ref_socket2=shift (@_));(my $ref_error=shift (@_));(my $ret=
libnxh::NXPipeCreate ($$ref_socket1,$$ref_socket2,(0x18eb+ 2491-0x22a5)));if ((
$ret==(-(0x0b71+ 1951-0x130f)))){(my $errorName=libnxh::NXGetErrorName ());(my $errorString
=libnxh::NXGetErrorString ());Logger::warning (((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorName)."\x2c\x20").$errorString)."\x2e"));($$ref_error=$errorString);
return ((0x0ac4+ 4584-0x1cac));}closeSocketAtFinish ($$ref_socket1);
closeSocketAtFinish ($$ref_socket2);Logger::debug (((((((
"\x4e\x58\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x28\x46\x44\x23".$$ref_socket1
)."\x2c\x20\x46\x44\x23").$$ref_socket2).
"\x2c\x20\x31\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$ret)."\x2e"));
return (($ret+(0x1654+ 3174-0x22b9)));}sub nxPipeCreateBi{(my $ref_socket1=shift
 (@_));(my $ref_socket2=shift (@_));my ($error);return (nxPipeCreateBiWithError 
($ref_socket1,$ref_socket2,(\$error)));}sub nxRunCommand{(my ($command,$options)
=@_);(my $silent=(shift (@_)||(0x1533+ 4351-0x2632)));(my $runcommand=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->new);$runcommand->setCommand (@$command);$runcommand->setOptions (@$options);(my (
$cmd_err,$cmd_out,$exit_value)=$runcommand->run);if ((((!$cmd_err)==
(0x070f+ 1591-0x0d46))and ($silent==(0x1711+ 3360-0x2431)))){Logger::warning ((
"\x45\x72\x72\x6f\x72\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x68\x65\x20\x65\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20"
.$cmd_out));}return ($cmd_err,$cmd_out,$exit_value);}sub nxRunCommandBg{(my (
$command,$options,$stdin,$stdout,$stderr)=@_);my ($rcOut,$rcErr,$rcExit);(my $runcommand
=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->new);$runcommand->setRunCommandInBG;$runcommand->setSaveStdinTo ($stdin);
$runcommand->setSaveStdoutTo ($stdout);$runcommand->setSaveStderrTo ($stderr);
$runcommand->setCommand (@$command);$runcommand->setOptions (@$options);(($rcOut
,$rcErr,$rcExit)=$runcommand->run);return ($rcOut,$rcErr,$rcExit);}sub 
nxExecCommand{(my ($command,$options)=@_);(my $silent=(shift (@_)||
(0x18bc+   4-0x18c0)));(my $runcommand=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->new);$runcommand->setCommandForExec (@$command);$runcommand->setOptions (
@$options);$runcommand->setExecCommand;(my $error=$runcommand->run);if (($error 
ne (""))){Logger::warning ((((
"\x45\x72\x72\x6f\x72\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x68\x65\x20\x65\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20"
.$cmd_out)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$error));return (
$error);}return ((""));}sub run_setup{Common::NXMsg::error (
"\x65\x4f\x70\x74\x69\x6f\x6e\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x4f\x6e\x57\x69\x6e\x64\x6f\x77\x73"
);main::nxexit ((0x0c10+ 6664-0x2618));(my $name=shift (@_));(my $name2=(shift (
@_)||("")));(my $run_in_bg=(0x11a3+ 1237-0x1677));($name=("\x2d\x2d".$name));if 
(($name2 ne (""))){if (($name2 eq "\x6e\x6f\x62\x67")){($run_in_bg=
(0x1de0+ 1034-0x21ea));($name2=(""));}else{($name2=("\x2d\x2d".$name2));}}my (
$CommandSetup);if (($GLOBAL::SOFTWARE_NAME eq "\x4e\x58\x53\x45\x52\x56\x45\x52"
)){($CommandSetup=(((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x74\x75\x70"
).$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));}else{(
$CommandSetup=(((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x74\x75\x70"
).$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x6e\x6f\x64\x65"));}Logger::debug (
"\x52\x75\x6e\x6e\x69\x6e\x67\x20\x72\x75\x6e\x5f\x73\x65\x74\x75\x70",
(0x0aed+ 4036-0x1ab1));(my (@command)=());if (($name2 eq (""))){(@command=(
$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote
 ($CommandSetup,$name)));}else{(@command=($GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote ($CommandSetup,$name
,$name2)));}(my (@options)=());my ($childPid);push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$childPid));if (($run_in_bg==
(0x0c57+ 1260-0x1142))){push (@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");}
(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options))
);Common::NXProcess::leaveChildAtFinish ($childPid);return ($cmd_err,$cmd_out,
$exit_value);}sub encodeBase64{(my $message=shift (@_));(my $size=length (
$message));(my $max=($size *(0x1653+ 1237-0x1b26)));(my $buffer=("\x20" x $max))
;(my $sizeEncoded=libnxh::NXB64Encode ($message,$size,$buffer,$max));(my $encodedMessage
=substr ($buffer,(0x16d3+ 2575-0x20e2),$sizeEncoded));return ($encodedMessage);}
sub decodeBase64{(my $encodedMessage=shift (@_));(my $size=length (
$encodedMessage));(my $max=($size *(0x1a4f+ 523-0x1c58)));(my $buffer=("\x20" x 
$max));(my $sizeDecoded=libnxh::NXB64Decode ($encodedMessage,$size,$buffer,$max)
);(my $decodedMessage=substr ($buffer,(0x0dc1+   1-0x0dc2),$sizeDecoded));return
 ($decodedMessage);}sub nxexit{(my $return=shift (@_));NXBegin::finalizeProcess 
();exit ($return);}sub assertExit{(my $return=shift (@_));(my ($package,
$filename,$line,$sub)=caller ((0x1475+ 413-0x1611)));if (($sub eq (""))){($sub=
$package);}if ((($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x54\x6f\x4c\x6f\x67\x66\x69\x6c\x65"
)and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x63\x6c\x6f\x73\x65\x4c\x6f\x67\x46\x69\x6c\x65"
))){Logger::warning (((
"\x41\x73\x73\x65\x72\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x66\x72\x6f\x6d\x20".
$sub)."\x2e"));}return ((0x0281+ 2623-0x0cc0));}sub nxAcceptSocket{(my $socket=
shift (@_));(my $silent=(shift (@_)||(0x222a+  57-0x2263)));(my $fd=
libnxh::NXAccept ($socket));(my $error=libnxh::NXGetError ());(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());if ((
not (defined ($fd)))){if (($silent==(0x115a+ 4665-0x2393))){Logger::warning ((((
(((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x70\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x3a\x20").$error)."\x2c\x20").$errorString)."\x2e"));}return (undef)
;}elsif (($fd==(-(0x08db+ 6046-0x2078)))){if (($silent==(0x09af+ 4728-0x1c27))){
Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x70\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x3a\x20").$error)."\x2c\x20").$errorString)."\x2e"));}return (undef)
;}else{Logger::debug (((((
"\x41\x63\x63\x65\x70\x74\x65\x64\x20\x6f\x6e\x20\x46\x44\x23".$socket).
"\x3a\x20\x46\x44\x23").$fd)."\x2e"));libnxh::NXDescriptorInheritable ($fd,
(0x0a66+ 7196-0x2682));closeSocketAtFinish ($fd);return ($fd);}}sub checkSocket{
(my $port=shift (@_));(my $nxplReturn=libnxh::NXTryBindLocal (
(0x0353+ 6380-0x1c3e),$port));Logger::debug ((((
"\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x3a\x20"
.$port)."\x20\x72\x65\x74\x75\x72\x6e\x3a\x20").$nxplReturn));if (($nxplReturn 
eq (0x0942+ 5675-0x1f6c))){return ((0x0fea+ 115-0x105d));}elsif (($nxplReturn eq
 (-(0x12c7+ 2155-0x1b31)))){return ((0x01e0+ 4493-0x136c));}else{(my $error=
libnxh::NXGetErrorName ());Logger::warning (((((((
"\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$port).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x76\x61\x6c\x75\x65\x20\x27"
).$nxplReturn)."\x27\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x3a\x20\x27").
$error)."\x27\x2e"));return ((0x239f+ 509-0x259b));}}sub checkUnixSocket{(my $socketName
=shift (@_));(my $isAbstract=shift (@_));(my $str=($isAbstract?
"\x61\x62\x73\x74\x72\x61\x63\x74\x20":("")));(my $nxplReturn=
libnxh::NXTryConnectUnixSocket ($socketName,$isAbstract));Logger::debug ((((((
"\x4e\x58\x54\x72\x79\x43\x6f\x6e\x6e\x65\x63\x74\x55\x6e\x69\x78\x53\x6f\x63\x6b\x65\x74\x20\x66\x6f\x72\x20"
.$str)."\x73\x6f\x63\x6b\x65\x74\x3a\x20").$socketName).
"\x20\x72\x65\x74\x75\x72\x6e\x3a\x20").$nxplReturn));if (($nxplReturn eq 
(0x0bc1+ 6711-0x25f7))){return ((0x072a+ 1218-0x0beb));}elsif (($nxplReturn eq (
-(0x054d+ 5279-0x19eb)))){return ((0x0d13+ 3746-0x1bb5));}else{(my $error=
libnxh::NXGetErrorName ());Logger::warning (((((((((
"\x4e\x58\x54\x72\x79\x43\x6f\x6e\x6e\x65\x63\x74\x55\x6e\x69\x78\x53\x6f\x63\x6b\x65\x74\x20\x66\x6f\x72\x20"
.$str)."\x73\x6f\x63\x6b\x65\x74\x20\x27").$socketName).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x76\x61\x6c\x75\x65\x20\x27"
).$nxplReturn)."\x27\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x3a\x20\x27").
$error)."\x27\x2e"));return ((0x0e75+ 6006-0x25ea));}}sub nxListenOnSocket{(my $port
=shift (@_));(my $silent=(shift (@_)||(0x0461+ 1085-0x089e)));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4f\x70\x65\x6e\x53\x6f\x63\x6b\x65\x74\x54\x6f\x4c\x69\x73\x74\x65\x6e\x45\x78\x28"
.$port)."\x2c\x20\x31\x30\x30\x2c\x20\x31\x2c\x20\x31\x29"));(my $FD=
libnxh::NXOpenSocketToListenEx ($port,(0x1dd7+ 859-0x20ce),(0x0bfc+ 1943-0x1392)
,(0x1945+ 162-0x19e6)));if (($FD==(-(0x10a7+ 4072-0x208e)))){(my $error=
libnxh::NXGetError ());(my $errorName=libnxh::NXGetErrorName ());(my $errorString
=libnxh::NXGetErrorString ());if ((($silent==(0x0c44+ 2379-0x158f))and (
$errorName ne "\x45\x41\x44\x44\x52\x49\x4e\x55\x53\x45"))){Logger::warning ((((
((("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x70\x6f\x72\x74\x20\x27".
$port)."\x27\x20\x74\x6f\x20\x6c\x69\x73\x74\x65\x6e\x3a\x20").$error).
"\x2c\x20").$errorString)."\x2e"));return ((-(0x15c9+ 3402-0x2311)));}return ((-
(0x073f+ 1486-0x0d0c)));}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4f\x70\x65\x6e\x53\x6f\x63\x6b\x65\x74\x54\x6f\x4c\x69\x73\x74\x65\x6e\x45\x78\x28"
.$port).
"\x2c\x20\x31\x30\x30\x2c\x20\x31\x2c\x20\x31\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x46\x44\x23"
).$FD)."\x2e"));(my $ret=libnxh::NXDescriptorInheritable ($FD,
(0x0f18+ 1562-0x1532)));unless ($ret){Logger::warning (((
"\x6e\x78\x4c\x69\x73\x74\x65\x6e\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x65\x64\x20\x66\x6c\x61\x67\x20\x6f\x6e\x20\x46\x44\x23"
.$FD)."\x2e"));}closeSocketAtFinish ($FD);return ($FD);}sub nxconnect{(my $addr=
shift (@_));(my $port=shift (@_));(my $silence=(shift (@_)||"\x6e\x6f"));(my (
$package,$filename,$line,$sub)=caller ((0x0f21+ 2598-0x1946)));if (($sub eq ("")
)){($sub=$package);}if ((not (defined ($port)))){Logger::error (((((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x3a\x20".$addr).
"\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x63\x61\x6c\x6c\x20\x66\x72\x6f\x6d\x20"
).$sub)."\x2e"));nxexit ();}Logger::debug (((((((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20".$addr)."\x20").$port).
"\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));(my $ret=libnxh::NXConnect ($addr,
$port));(my $error=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());if (($ret==(-(0x0fe6+ 3016-0x1bad)))){if (($silence
 eq "\x6e\x6f")){Logger::warning (((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20"
.$addr)."\x2c\x20").$port)."\x3a\x20").$errorstring)."\x20\x66\x72\x6f\x6d\x20")
.$sub)."\x2e"));}return ($ret);}Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x3a\x20\x46\x44\x23"
.$ret)."\x2e"));libnxh::NXDescriptorInheritable ($ret,(0x0f28+ 5884-0x2624));
closeSocketAtFinish ($ret);return ($ret);}sub nxTryLock{(my $filepath=shift (@_)
);(my $mode=shift (@_));(my $tryLock=libnxh::NXFileTryLock ($filepath,$mode));(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());if ((
$tryLock==(-(0x07e5+ 6035-0x1f77)))){Logger::warning (((((
"\x4e\x58\x46\x69\x6c\x65\x54\x72\x79\x4c\x6f\x63\x6b\x28".$filepath)."\x2c\x20"
).$mode)."\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));return ((0x0d15+ 4158-0x1d53));}Logger::debug2 ((((((
("\x4e\x58\x46\x69\x6c\x65\x54\x72\x79\x4c\x6f\x63\x6b\x28".$filepath).
"\x2c\x20").$mode)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$tryLock)
."\x27\x2e"));return ($tryLock);}sub nxflock{(my $filepath=shift (@_));(my $mode
=shift (@_));(my $flock=libnxh::NXFileLock ($filepath,$mode));Logger::debug ((((
(((
"\x6e\x78\x66\x6c\x6f\x63\x6b\x3a\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x4c\x6f\x63\x6b\x28"
.$filepath)."\x2c\x20").$mode).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$flock)."\x27\x2e"));if ((
$flock==(-(0x0234+ 4178-0x1285)))){($flock=(0x0b77+ 6707-0x25aa));}return (
$flock);}sub redirectStderrNXPL{(my $path=shift (@_));if (((not (defined ($path)
))or ($path ne ("")))){Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x70\x61\x74\x68"
);}if (defined ($NXBegin::oldSTDERR)){(my $fd_copy=libnxh::NXFileClone (
$NXBegin::oldSTDERR,(0x0c49+ 1895-0x13ae)));main::nxclose ($NXBegin::oldSTDERR);
($NXBegin::oldSTDERR=undef);}else{($NXBegin::oldSTDERR=libnxh::NXFileDuplicate (
(0x15f6+ 2873-0x212d)));Logger::debug (((
"\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x20\x6f\x66\x20\x53\x54\x44\x45\x52\x52\x20\x66\x64\x20\x69\x73\x3a\x20\x5b"
.$NXBegin::oldSTDERR)."\x5d"));(my $TMPFILE=main::nxopen ($path,(
$NXBits::O_CREAT+$NXBits::O_WRONLY),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersWrite)));(my $fd_copy=
libnxh::NXFileClone ($TMPFILE,(0x07dd+ 1764-0x0ebf)));}}sub nxsetSTDIN{(my $int=
shift (@_));($GLOBAL::DefaultSTDINDescriptor=$int);}sub nxsetSTDOUT{(my $int=
shift (@_));($GLOBAL::DefaultSTDOUTDescriptor=$int);}sub nxsetSTDERR{(my $int=
shift (@_));($NXBegin::STDERRint=$int);}sub nxgetSTDIN{if (
isNXLibraryLoadedForModule ()){return ($GLOBAL::DefaultSTDINDescriptor);}else{
return ((\*STDIN));}}sub nxgetSTDOUT{if (isNXLibraryLoadedForModule ()){return (
$GLOBAL::DefaultSTDOUTDescriptor);}else{return ((\*STDOUT));}}sub nxgetSTDERR{if
 (isNXLibraryLoadedForModule ()){return ($STDERR);}else{return ((\*STDERR));}}
sub nxsleep{(my $sleep=shift (@_));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->can_read (($sleep *(0x195a+ 2422-0x1ee8)),
"\x73\x69\x6c\x65\x6e\x74");return;}sub nxcheckPipe{(my $fh=shift (@_));(my $return
=libnxh::NXSelect ($fh,(0x0b92+ 1459-0x1144)));if (($return==
(0x0f77+ 6003-0x26ea))){return ((0x0605+ 2403-0x0f68));}($return=~ /(\d):(.*)/ )
;(my $exitcode=$1);return ($exitcode);}sub closeSocketAtFinish{(my $fh=shift (@_
));($$NXBegin::SocketsToClose{$fh}=(0x02a5+ 8066-0x2226));}sub 
doNotCloseSocketAtFinish{(my $fh=shift (@_));Logger::debug (((
"\x4e\x58\x43\x6f\x72\x65\x3a\x20\x44\x6f\x20\x6e\x6f\x74\x20\x63\x6c\x6f\x73\x65\x20\x61\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x46\x44\x23"
.$fh)."\x2e"));delete ($$NXBegin::SocketsToClose{$fh});}sub hideOutput{(my $log=
shift (@_));if ((not (defined ($log)))){return ((""));}($log=~ s/\w{32}/*****/gm )
;return ($log);}sub urlencode{(my ($string)=@_);if ((length ($string)==
(0x0ff6+ 5308-0x24b2))){Logger::debug3 (
"\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x3a\x20\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x65\x6e\x63\x6f\x64\x65\x2e"
);return ($string);}(my $buffer=("\x20" x ((length ($string)*
(0x05ad+ 4453-0x170f))+(0x14e9+ 916-0x187b))));(my $length=libnxh::NXUrlEncode (
$string,$buffer,length ($buffer)));if (($length==(-(0x010d+ 7393-0x1ded)))){
Logger::warning (
"\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x65\x6e\x63\x6f\x64\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e\x0a"
);return ((-(0x0f0a+ 5596-0x24e5)));}(my $result=substr ($buffer,
(0x0419+ 3493-0x11be),$length));return ($result);}sub urldecode{(my ($string)=@_
);if ((length ($string)==(0x12cc+ 3848-0x21d4))){Logger::debug3 (
"\x75\x72\x6c\x64\x65\x63\x6f\x64\x65\x3a\x20\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x64\x65\x63\x6f\x64\x65\x2e"
);return ($string);}(my $buffer=("\x20" x ((length ($string)*
(0x0981+ 4986-0x1cf8))+(0x07ca+ 7151-0x23b7))));(my $length=libnxh::NXUrlDecode 
($string,$buffer,length ($buffer)));if (($length==(-(0x17ad+ 185-0x1865)))){
Logger::warning (
"\x75\x72\x6c\x64\x65\x63\x6f\x64\x65\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x65\x63\x6f\x64\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e\x0a"
);return ((-(0x1ec9+ 1872-0x2618)));}(my $result=substr ($buffer,
(0x0bed+ 700-0x0ea9),$length));return ($result);}sub isCorrectIP{(my $ipToCheck=
shift (@_));(my (@ip)=split ( /%/ ,$ipToCheck,(0x16a4+ 1208-0x1b5c)));if (($ip[
(0x0dc0+ 2459-0x175b)]=~ /^(?:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9](?::|$)){8,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,6})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,6})?))|(?:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){6,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,4})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,4}:)?))?(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}))$/i )
){return ((0x1392+ 708-0x1655));}return ((0x0916+ 1118-0x0d74));}sub 
nxGetDesktopOwner{(my $buffer=("\x20" x (0x215f+ 475-0x223a)));(my $bufferLength
=(0x107d+ 2941-0x1afa));(my $ret=libnxh::NXAppleDesktopOwner ($buffer,
$bufferLength));if (($ret==(-(0x1244+ 296-0x136b)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());(my $file=
"\x2f\x64\x65\x76\x2f\x63\x6f\x6e\x73\x6f\x6c\x65");(my $desktopOwnerID=(stat (
$file))[(0x1432+ 807-0x1755)]);if (($desktopOwnerID==(0x1808+ 2293-0x20fd))){
return ("\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77");}Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x2e"
);Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20\x27").$errorstring)."\x27\x2e"));return ((-(0x0cc5+ 6142-0x24c2)));}(
$buffer=substr ($buffer,(0x017c+ 8536-0x22d4),index ($buffer,"\x00")));return (
$buffer);}sub nxCheckDesktopOwner{(my $user=nxGetDesktopOwner ());if (($user==(-
(0x123d+ 5031-0x25e3)))){return ((-(0x0312+ 3020-0x0edd)));}if (($user eq 
"\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77")){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x70\x70\x6c\x65\x44\x65\x73\x6b\x74\x6f\x70\x4f\x77\x6e\x65\x72\x3a\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x69\x73\x20\x4c\x6f\x67\x69\x6e\x20\x57\x69\x6e\x64\x6f\x77\x2e"
);return ((0x0845+ 7858-0x26f7));}(my $uid=userInfoGetUidByUsername ($user));
Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x70\x70\x6c\x65\x44\x65\x73\x6b\x74\x6f\x70\x4f\x77\x6e\x65\x72\x3a\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x69\x73\x20\x27"
.$user)."\x27\x20\x69\x64\x3a\x20\x27").$uid)."\x27\x2e"));return ($uid);}sub 
digestMd5Hex{(my $data=join ((""),@_));(my $buffer=("\x20" x 
(0x1f54+ 1844-0x2664)));my ($output);(my $errcode=libnxh::NXMd5Hex ($buffer,
$data));if (($errcode!=(-(0x0559+ 8323-0x25db)))){($output=substr ($buffer,
(0x0177+ 7844-0x201b),(0x03f5+ 1099-0x0820)));Logger::debug2 ((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x64\x35\x48\x65\x78\x20\x72\x65\x74\x75\x72\x6e\x73\x20"
.$output));return ($output);}else{reportErrorFromNXPL (
"\x64\x69\x67\x65\x73\x74\x4d\x64\x35\x48\x65\x78\x20\x66\x61\x69\x6c\x65\x64\x2e"
);main::nxexit ((0x0a41+ 4065-0x1a21));}}sub digestMd5Base64{(my $data=join (
(""),@_));(my $buffer=("\x20" x (0x0305+ 4117-0x12f6)));my ($output);(my $errcode
=libnxh::NXMd5B64 ($buffer,$data));if (($errcode!=(-(0x0e9a+ 4607-0x2098)))){(
$output=$buffer);($output=~ s/\0// );($output=~ s/=*\s+// );Logger::debug2 ((
"\x64\x69\x67\x65\x73\x74\x4d\x64\x35\x42\x61\x73\x65\x36\x34\x3a\x20\x72\x65\x74\x75\x72\x6e\x69\x6e\x67\x20"
.$output));return ($output);}else{reportErrorFromNXPL (
"\x64\x69\x67\x65\x73\x74\x4d\x64\x35\x42\x36\x34\x20\x66\x61\x69\x6c\x65\x64\x2e"
);main::nxexit ((0x0376+ 7893-0x224a));}}sub nxTime{(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));(my $timems=(($sec."\x2e").substr ($milisec,
(0x111d+ 5356-0x2609),(0x1231+ 3907-0x2171))));return ($timems);}sub 
isWMRunningByDisplay{(my $display=shift (@_));my ($errname);Logger::debug ((
"\x69\x73\x57\x4d\x52\x75\x6e\x6e\x69\x6e\x67\x42\x79\x44\x69\x73\x70\x6c\x61\x79\x20\x63\x61\x6c\x6c\x20\x6f\x6e\x20"
.$display));(my $ret=libnxh::NXWmRunning ($display));if (($ret==(-
(0x0ba9+ 1007-0x0f97)))){($errname=libnxh::NXGetErrorName ());if (($errname eq 
"\x45\x54\x49\x4d\x45\x44\x4f\x55\x54")){if ((not (increaseWmrunningTimeout ()))
){Logger::warning (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67\x20\x2d\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20"
.$NXCore::WMRunningTimeout_max)."\x20\x72\x65\x61\x63\x68\x65\x64\x2e"));}else{(
$ret=libnxh::NXWmRunning ($display));if (($ret==(-(0x03d1+ 7716-0x21f4)))){(
$errname=libnxh::NXGetErrorName ());}}}Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x57\x4d\x20\x6f\x6e\x20\x64\x69\x73\x70\x6c\x61\x79\x20"
.$display)."\x20").$errname));}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67\x28"
.$display)."\x29\x20\x5b").$ret)."\x5d"));return ($ret);}sub 
increaseWmrunningTimeout{if (($NXCore::WMRunningTimeout==
$NXCore::WMRunningTimeout_max)){return ((0x0f6a+ 2422-0x18e0));}if (defined (
$GLOBAL::NXWmRunningTimeout)){($NXCore::WMRunningTimeout_max=
$GLOBAL::NXWmRunningTimeout);}($NXCore::WMRunningTimeout=
$NXCore::WMRunningTimeout_max);__setWMRunningTimeout ($NXCore::WMRunningTimeout)
;return ((0x0911+ 5254-0x1d96));}sub setDefaultWmrunningTimeout{if ((
$NXCore::WMRunningTimeout==$NXCore::WMRunningTimeout_default)){return (
(0x0926+ 3600-0x1736));}($NXCore::WMRunningTimeout=
$NXCore::WMRunningTimeout_default);__setWMRunningTimeout (
$NXCore::WMRunningTimeout);return ((0x0783+  35-0x07a5));}sub 
__setWMRunningTimeout{(my $timeout=shift (@_));Logger::debug (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x57\x4d\x52\x75\x6e\x6e\x69\x6e\x67\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x74\x6f\x20\x27"
.$timeout)."\x27\x20\x6d\x73\x2e"));libnxh::NXWmSetTimeout ($timeout);}sub 
initVariable{(my $var=shift (@_));(my $value=shift (@_));($$var=$value);}sub 
initNXPLVariables{(my $variables=libnxh::NXInitConstants ());Logger::debug (((
"\x57\x41\x4e\x20\x69\x6e\x69\x74\x4e\x58\x50\x4c\x56\x61\x72\x69\x61\x62\x6c\x65\x73\x20\x5b"
.$variables)."\x5d\x2e"));initVariable ((\$NXBITS::SIGPWR),@$variables[
(0x0600+ 3739-0x144c)]);initVariable ((\$NXBITS::CONTAINER_INHERIT),@$variables[
(0x06fc+ 6242-0x1f0e)]);initVariable ((\$NXBITS::INHERIT_ONLY),@$variables[
(0x0404+ 2707-0x0e46)]);initVariable ((\$NXBITS::NO_INHERITANCE),@$variables[
(0x1338+ 359-0x144d)]);initVariable ((\$NXBITS::NO_PROPAGATE_INHERIT),
@$variables[(0x07b5+ 3089-0x1373)]);initVariable ((\$NXBITS::OBJECT_INHERIT),
@$variables[(0x0646+ 251-0x06ed)]);initVariable ((\$NXBITS::APPEND_STATUS_CREATE
),@$variables[(0x07ea+ 4584-0x197d)]);initVariable ((
\$NXBITS::APPEND_STATUS_CREATEAFTER),@$variables[(0x0b53+ 2913-0x165e)]);
initVariable ((\$NXBITS::APPEND_STATUS_ADDINZIP),@$variables[
(0x0780+ 4052-0x16fd)]);initVariable ((\$NXBITS::Z_NO_COMPRESSION),@$variables[
(0x2213+ 912-0x254b)]);initVariable ((\$NXBITS::Z_BEST_SPEED),@$variables[
(0x00cc+ 3428-0x0dd7)]);initVariable ((\$NXBITS::Z_BEST_COMPRESSION),@$variables
[(0x05b0+ 6724-0x1f9a)]);initVariable ((\$NXBITS::Z_DEFAULT_COMPRESSION),
@$variables[(0x0257+ 3616-0x101c)]);initVariable ((\$NXBITS::SIGCHLD),
@$variables[(0x06e5+ 3443-0x140b)]);initVariable ((\$NXBITS::SIGTERM),
@$variables[(0x022d+ 4025-0x1198)]);($STDERR=(0x202f+ 671-0x22cc));initVariable 
((\$STDERR),@$variables[(0x06c6+ 3368-0x13a8)]);($NXCore::systemExitCodes{
"\x45\x4e\x4f\x45\x4e\x54"}=@$variables[(0x10c8+ 1099-0x14cc)]);(
$NXCore::systemExitCodes{"\x45\x41\x43\x43\x45\x53"}=@$variables[
(0x015b+ 2339-0x0a36)]);($NXCore::systemExitCodes{
"\x45\x43\x4f\x4e\x4e\x52\x45\x46\x55\x53\x45\x44"}=@$variables[
(0x0b9b+ 5950-0x2290)]);($NXCore::systemExitCodes{"\x45\x49\x4e\x54\x52"}=
@$variables[(0x025d+ 8940-0x24ff)]);($NXCore::systemExitCodes{
"\x45\x4e\x4f\x44\x41\x54\x41"}=@$variables[(0x18df+ 2217-0x213d)]);(
$NXCore::systemExitCodes{"\x45\x50\x45\x52\x4d"}=@$variables[
(0x1c78+ 1155-0x20af)]);($NXCore::systemExitCodes{
"\x45\x54\x49\x4d\x45\x44\x4f\x55\x54"}=@$variables[(0x00ed+ 7872-0x1f51)]);(
$NXCore::systemExitCodes{"\x45\x48\x4f\x53\x54\x55\x4e\x52\x45\x41\x43\x48"}=
@$variables[(0x10fa+   5-0x10a2)]);($NXCore::systemExitCodes{
"\x45\x4e\x45\x54\x55\x4e\x52\x45\x41\x43\x48"}=@$variables[
(0x0372+ 5248-0x1794)]);($NXCore::systemExitCodes{
"\x45\x41\x44\x44\x52\x4e\x4f\x54\x41\x56\x41\x49\x4c"}=@$variables[
(0x04ad+ 6410-0x1d58)]);($NXCore::systemExitCodes{
"\x57\x53\x41\x45\x48\x4f\x53\x54\x44\x4f\x57\x4e"}=@$variables[
(0x0199+ 1914-0x08b3)]);($NXCore::systemExitCodes{
"\x57\x53\x41\x48\x4f\x53\x54\x5f\x4e\x4f\x54\x5f\x46\x4f\x55\x4e\x44"}=
@$variables[(0x14df+ 1922-0x1c00)]);return;}sub addFhToMonitor{(my $handle=shift
 (@_));(my $callback=shift (@_));($NXBegin::MonitoredHandler=$handle);(
$NXBegin::MonitoredHandlerCallback=$callback);}sub nxFileDuplicate{(my $descriptorToDuplicate
=shift (@_));(my $return=libnxh::NXFileDuplicate ($descriptorToDuplicate));if ((
$return>=(0x0d1b+ 4201-0x1d84))){Logger::debug (((((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".
$descriptorToDuplicate).
"\x20\x77\x61\x73\x20\x64\x75\x70\x6c\x69\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x46\x44\x23"
).$return)."\x2e"));libnxh::NXDescriptorInheritable ($return,
(0x169c+ 449-0x185d));return ($return);}else{(my $error=libnxh::NXGetErrorName 
());(my $errorstring=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x4e\x58\x46\x69\x6c\x65\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x28".
$descriptorToDuplicate)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$return)
."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));return (undef);}}sub nxFileClone{(my $descriptorToClone
=shift (@_));(my $target=shift (@_));(my $return=libnxh::NXFileClone (
$descriptorToClone,$target));if (($return>=(0x05d9+ 3268-0x129d))){Logger::debug
 ((((("\x46\x69\x6c\x65\x20\x68\x61\x6e\x64\x6c\x65\x20\x6f\x66\x20\x46\x44\x23"
.$descriptorToClone).
"\x20\x77\x61\x73\x20\x63\x6c\x6f\x6e\x65\x64\x20\x69\x6e\x74\x6f\x20\x46\x44\x23"
).$target)."\x2e"));return ($return);}else{(my $error=libnxh::NXGetErrorName ())
;(my $errorstring=libnxh::NXGetErrorString ());Logger::warning (((((((((((
"\x4e\x58\x46\x69\x6c\x65\x43\x6c\x6f\x6e\x65\x28".$descriptorToClone).
"\x2c\x20").$target)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$return).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));return (undef);}}sub nxDescriptorInheritable{(my $fd=
shift (@_));(my $value=(shift (@_)||(0x185c+ 1514-0x1e46)));(my $return=
libnxh::NXDescriptorInheritable ($fd,$value));if (($return==(-
(0x0478+ 3865-0x1390)))){reportErrorFromNXPL (((((((
"\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.$fd)."\x2c\x20").$value).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$return)."\x2e"));return (undef);}else{if ($value){Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$fd).
"\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x73\x65\x74\x20\x61\x73\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x2e"
));}else{Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$fd).
"\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x73\x65\x74\x20\x61\x73\x20\x6e\x6f\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x2e"
));}return ($return);}}sub setDescriptorInheritable{(my $fd=shift (@_));return (
nxDescriptorInheritable ($fd,(0x088c+ 552-0x0ab3)));}sub 
setDescriptorNotInheritable{(my $fd=shift (@_));return (nxDescriptorInheritable 
($fd,(0x20ac+ 697-0x2365)));}sub getApplicationName{(my $pid=shift (@_));if (
Common::NXProcess::isChildProcess ($pid)){(my ($name,$lifetime)=
Common::NXProcess::getChildNameAndLifetime ($pid));return ($name);}(my $readbuf=
("\x20" x (0x08e3+ 6918-0x22e7)));(my $name=libnxh::NXProcessGetImage ((
\$readbuf),(0x0b89+ 259-0x0b8b),$pid));if ((not (defined ($name)))){
Logger::debug (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));return ((""));}else{Logger::debug (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20".$pid).
"\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x6e\x61\x6d\x65\x20").$name)."\x2e"));
}return ($name);}sub checkIfPidProcessNameIs{(my $pid=shift (@_));(my $name=
shift (@_));(my $realName=getApplicationName ($pid));if (($realName=~ /$name/ ))
{return ((0x0dc4+ 570-0x0ffd));}return ((0x0f39+ 2037-0x172e));}sub 
__addDebugerNames{(my $names=shift (@_));if ((defined ($GLOBAL::EnableDebug)and 
defined ($GLOBAL::AcceptedDebuggerCommands))){if ((($GLOBAL::EnableDebug eq 
"\x31")and ($GLOBAL::AcceptedDebuggerCommands ne ("")))){(my (@acceptedNames)=
split ( /,/ ,$GLOBAL::AcceptedDebuggerCommands,(0x1d5f+ 2303-0x265e)));foreach my $acceptedName
 (@acceptedNames){(my (@pathParts)=split ( /$GLOBAL::DIRECTORY_SLASH/ ,
$acceptedName,(0x051a+ 1660-0x0b96)));(my $name=(""));foreach my $pathPart (
@pathParts){if (($pathPart ne (""))){($name=$pathPart);}}($names.=("\x7c".substr
 ($name,(0x0185+ 415-0x0324),(0x0a71+ 4145-0x1a93))));}}}return ($names);}sub 
__isProcessRunnningAndExpectedNameMatch{(my $pid=shift (@_));(my $expectedName=
shift (@_));(my $silent=shift (@_));if (($pid<(0x116a+ 2935-0x1ce0))){if ((
$silent eq "\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::error (((
"\x57\x72\x6f\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x64\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x70\x69\x64\x20"
.$pid)."\x2e"));}return ((0x1945+ 924-0x1ce1));}($expectedName=__addDebugerNames
 ($expectedName));if (Common::NXProcess::isProcessRunning ($pid)){if (
checkIfPidProcessNameIs ($pid,$expectedName)){if (($silent eq 
"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::debug2 (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20".$expectedName).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
).$pid)."\x2e"));}return ((0x01f4+ 3667-0x1046));}else{(my $realProcessName=
getApplicationName ($pid));if (($silent eq 
"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::error (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x68\x61\x73\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x2c\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
.$expectedName).
"\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
).$realProcessName)."\x2e"));}else{Logger::debug (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x68\x61\x73\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x2c\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
.$expectedName).
"\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
).$realProcessName)."\x2e"));}}}else{if (($silent eq 
"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::error (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20".$pid).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));}else{
Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20".$pid).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));}}return (
(0x090b+ 3837-0x1808));}sub isProcessRunnningAndExpectedNameMatch{(my $pid=shift
 (@_));(my $name=shift (@_));return (__isProcessRunnningAndExpectedNameMatch (
$pid,$name,"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74"));}sub 
isProcessRunnningAndExpectedNameMatchSilent{(my $pid=shift (@_));(my $name=shift
 (@_));return (__isProcessRunnningAndExpectedNameMatch ($pid,$name,
"\x73\x69\x6c\x65\x6e\x74"));}sub copyFile{(my $fileSource=shift (@_));(my $fileDest
=shift (@_));Logger::debug2 (((("\x63\x6f\x70\x79\x46\x69\x6c\x65\x3a\x20".
$fileSource)."\x2c\x20").$fileDest));if ((not (Common::NXFile::fileExists (
$fileSource)))){return ((0x17e5+ 1462-0x1d9a),((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x74\x20\x27".$fileSource).
"\x27\x20\x66\x69\x6c\x65\x2e"));}(my $copyRet=libnxh::NXFileCopy ($fileSource,
$fileDest));if (($copyRet ne (0x0862+ 1712-0x0f11))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x27".
$fileSource)."\x27\x20\x74\x6f\x20\x27").$fileDest)."\x27\x2e"));Logger::error (
(((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorString)."\x27\x2e"));return ((0x00a8+ 9218-0x24aa),((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x27".$fileSource).
"\x27\x20\x66\x69\x6c\x65\x20\x74\x6f\x20\x27").$fileDest).
"\x27\x20\x64\x75\x65\x20\x74\x6f\x20\x27").$errorString)."\x27\x2e"));}return (
(0x1da1+ 814-0x20cf),(""));}sub moveFile{(my $fileSource=shift (@_));(my $fileDest
=shift (@_));if ((not (Common::NXFile::fileExists ($fileSource)))){Logger::error
 ((((("\x6d\x6f\x76\x65\x46\x69\x6c\x65\x3a\x20".$fileSource)."\x2c\x20").
$fileDest).
"\x2e\x20\x46\x69\x6c\x65\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x2e"
));return;}(my $moveRet=libnxh::NXFileMove ($fileSource,$fileDest));if ((
$moveRet ne (0x0957+ 7441-0x2667))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6f\x76\x65\x20\x27".$fileSource).
"\x27\x20\x66\x69\x6c\x65\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorString)."\x27\x2e"));return ((0x0075+ 1780-0x0769));}return (
(0x08d9+ 5948-0x2014));}sub BEGIN{require Fcntl;do{"\x46\x63\x6e\x74\x6c"->
import ("\x3a\x6d\x6f\x64\x65")};}sub NXStat{(my $file=shift (@_));(my (@list)=
stat ($file));return (@list);}sub NXFileGid{(my $file=shift (@_));return ((
NXStat ($file))[(0x069c+ 3192-0x130f)]);}sub NXFileUid{(my $file=shift (@_));
return ((NXStat ($file))[(0x1398+ 1726-0x1a52)]);}sub NXFileMode{(my $file=shift
 (@_));return ((NXStat ($file))[(0x0cc8+ 5884-0x23c2)]);}sub NXFileMTime{(my $file
=shift (@_));return ((NXStat ($file))[(0x0db2+ 2499-0x176c)]);}sub NXFileATime{(my $file
=shift (@_));return ((NXStat ($file))[(0x0074+ 6173-0x1889)]);}sub NXFileSize{(my $file
=shift (@_));return ((NXStat ($file))[(0x0b98+ 820-0x0ec5)]);}sub NXFileCTime{(my $file
=shift (@_));return ((NXStat ($file))[(0x0421+ 430-0x05c5)]);}sub 
NXIsFileReadable{(my $file=shift (@_));(my $isReadable=(0x10d1+ 1768-0x17b9));(my $flag
="\x53\x5f\x49\x52\x55\x53\x45\x52");if (Common::NXFile::isExists ($file)){(my $mode
=NXFileMode ($file));($isReadable=($mode&"\x53\x5f\x49\x52\x55\x53\x45\x52"));}
return ($isReadable);}sub decodeDate{(my $code=shift (@_));(my $decode=($code^
(0x1a5d+ 1767-0x20c5)));return ($decode);}sub convertWindowsSidToUsername{(my $SID
=shift (@_));(my $bufferSize=(0x0a9a+ 5587-0x1e6d));(my $buffer=("\x20" x 
$bufferSize));(my $return=libnxh::NXConvertSidToUsername ($SID,$buffer,
$bufferSize));if (($return==(-(0x0736+ 4711-0x199c)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x53\x49\x44\x3a\x20"
.$SID)."\x2e"));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e"));return ((""));}($buffer
=substr ($buffer,(0x1b21+ 1848-0x2259),index ($buffer,"\x00")));Logger::debug ((
((("\x43\x6f\x6e\x76\x65\x72\x74\x65\x64\x20\x53\x49\x44\x20".$SID).
"\x20\x74\x6f\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20").$buffer)."\x2e"));
return ($buffer);}sub getEffectiveUserGroup{if ((
$GLOBAL::CACHE_EFFECTIVE_USERGROUP eq (""))){(my $euid=getEffectiveUid ());(my $usergroup
=userInfoGetGidByUid ($euid));($GLOBAL::CACHE_EFFECTIVE_USERGROUP=$usergroup);}
return ($GLOBAL::CACHE_EFFECTIVE_USERGROUP);}sub getEffectiveUserGroupID{();}sub
 getNXExecCommand{return (((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x65\x78\x65\x63").
$GLOBAL::BinExt));}sub nxwriteOrThrowException{(my $FD=shift (@_));(my $message=
shift (@_));(my $bytes=nxwrite ($FD,$message));if (($bytes==(-
(0x03c5+ 8344-0x245c)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->throw ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x46\x44\x23".
$FD));}return ($bytes);}sub isSystemUserExist{(my $login=shift (@_));(my $silent
=(0x0274+ 9328-0x26e3));if (((not (defined ($login)))or ($login eq ("")))){
Logger::error (
"\x4c\x6f\x67\x69\x6e\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e");
main::nxexit ();}if (__isCachedUserInfoForUsername ($login)){return (
(0x006a+ 6193-0x189a));}else{return (__setUserInfoForUsername ($login,$silent));
}}sub getEffectiveUsername{if ((defined ($GLOBAL::CACHE_EFFECTIVE_USERNAME)and (
$GLOBAL::CACHE_EFFECTIVE_USERNAME ne ("")))){return (
$GLOBAL::CACHE_EFFECTIVE_USERNAME);}my ($username);($username=
getLoginNameWindows ());if (defined ($username)){(
$GLOBAL::CACHE_EFFECTIVE_USERNAME=$username);}Logger::debug (((
"\x67\x65\x74\x45\x66\x66\x65\x63\x74\x69\x76\x65\x55\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20"
.$username)."\x2e"));return ($username);}sub ErrnoENOENT{return (
$NXCore::systemExitCodes{"\x45\x4e\x4f\x45\x4e\x54"});}sub ErrnoEACCES{return (
$NXCore::systemExitCodes{"\x45\x41\x43\x43\x45\x53"});}sub ErrnoECONNREFUSED{
return ($NXCore::systemExitCodes{
"\x45\x43\x4f\x4e\x4e\x52\x45\x46\x55\x53\x45\x44"});}sub ErrnoEINTR{return (
$NXCore::systemExitCodes{"\x45\x49\x4e\x54\x52"});}sub ErrnoENODATA{return (
$NXCore::systemExitCodes{"\x45\x4e\x4f\x44\x41\x54\x41"});}sub ErrnoEPERM{return
 ($NXCore::systemExitCodes{"\x45\x50\x45\x52\x4d"});}sub ErrnoETIMEDOUT{return (
$NXCore::systemExitCodes{"\x45\x54\x49\x4d\x45\x44\x4f\x55\x54"});}sub 
ErrnoEHOSTUNREACH{return ($NXCore::systemExitCodes{
"\x45\x48\x4f\x53\x54\x55\x4e\x52\x45\x41\x43\x48"});}sub ErrnoENETUNREACH{
return ($NXCore::systemExitCodes{"\x45\x4e\x45\x54\x55\x4e\x52\x45\x41\x43\x48"}
);}sub ErrnoEADDRNOTAVAIL{return ($NXCore::systemExitCodes{
"\x45\x41\x44\x44\x52\x4e\x4f\x54\x41\x56\x41\x49\x4c"});}sub ErrnoWSAEHOSTDOWN{
return ($NXCore::systemExitCodes{
"\x57\x53\x41\x45\x48\x4f\x53\x54\x44\x4f\x57\x4e"});}sub BEGIN{require Win32;do
{"\x57\x69\x6e\x33\x32"->import};}sub getLastErrorWindows{return (
Win32::GetLastError (@_));}sub BEGIN{require Win32;do{"\x57\x69\x6e\x33\x32"->
import};}sub getLastErrorMsgWindows{(my $errormsg=(Win32::FormatMessage (
getLastErrorWindows ())||("")));return (((
"\x57\x69\x6e\x33\x32\x20\x65\x72\x72\x6f\x72\x3a\x20".$errormsg)."\x2e\x0a"));}
sub FdGetOsFHandleWindows{(my $FD=shift (@_));(my $windowsFH=
libnxhs::NXGetWindowsFileHandle ($FD));if (($windowsFH==(-(0x0cca+ 6371-0x25ac))
)){reportErrorFromNXPL (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x47\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x46\x69\x6c\x65\x48\x61\x6e\x64\x6c\x65\x28"
.$FD)."\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));return (undef);}return (
$windowsFH);}sub isEffectiveUserAdministratorWindows{Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x49\x73\x45\x66\x66\x65\x63\x74\x69\x76\x65\x55\x73\x65\x72\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x28\x29"
);(my $return=libnxh::NXIsEffectiveUserAdministrator ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x49\x73\x45\x66\x66\x65\x63\x74\x69\x76\x65\x55\x73\x65\x72\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));unless (($return=~ /0|1/ )){reportErrorFromNXPL (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x63\x72\x65\x64\x65\x6e\x74\x69\x61\x6c\x73\x2e"
);return ((0x0723+ 6209-0x1f64));}if (($return==(0x0646+ 4506-0x17df))){return (
(0x0844+ 7052-0x23cf));}return ((0x16ad+ 2251-0x1f78));}sub getLoginNameWindows{
(my $size=(0x063f+ 7822-0x22cd));(my $userNameBuffer=("\x20" x $size));(my $length
=($size-(0x0693+ 6234-0x1eec)));(my $retval=libnxh::NXGetEffectiveUsername (
$userNameBuffer,$length));if (($retval==(-(0x02d4+ 6542-0x1c61)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20\x27").$errorstring)."\x27\x2e"));return ((""));}($userNameBuffer=
substr ($userNameBuffer,(0x0e32+ 5658-0x244c),index ($userNameBuffer,"\x00")));(my $effectiveUserSID
=("\x20" x $size));($retval=libnxh::NXGetSidOfCurrentProcess ($effectiveUserSID,
$length));if (($retval==(-(0x0124+ 7890-0x1ff5)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x53\x49\x44\x20\x6f\x66\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
);Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20\x27").$errorstring)."\x27\x2e"));}($effectiveUserSID=substr (
$effectiveUserSID,(0x1897+ 1239-0x1d6e),index ($effectiveUserSID,"\x00")));if ((
libnxh::NXUserExist ("\x6e\x78")==(0x0559+ 2493-0x0f15))){(my $nxSID=
userInfoGetUidByUsername ("\x6e\x78"));if (($nxSID eq $effectiveUserSID)){(
$userNameBuffer="\x6e\x78");}}return ($userNameBuffer);}sub 
isEffectiveUserAdministratorUnix{if (($>eq "\x30")){return (
(0x02da+ 8050-0x224b));}return ((0x01a5+ 2445-0x0b32));}sub clearPwNam{(my $login
=shift (@_));if (((not (defined ($login)))or ($login eq ("")))){Logger::warning 
(
"\x63\x6c\x65\x61\x72\x70\x77\x6e\x61\x6d\x3a\x20\x6c\x6f\x67\x69\x6e\x20\x6e\x61\x6d\x65\x20\x6e\x6f\x74\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e"
);return;}Logger::debug (((
"\x63\x6c\x65\x61\x72\x70\x77\x6e\x61\x6d\x3a\x20\x63\x6c\x65\x61\x72\x69\x6e\x67\x20\x63\x61\x63\x68\x65\x20\x66\x6f\x72\x20"
.$login)."\x2e"));__cleanCachedUserInfoForUsername ($login);return;}sub getPwNam
{(my $login=shift (@_));(my $silent=(0x01a3+ 6668-0x1baf));if (((not (defined (
$login)))or ($login eq ("")))){Logger::error (
"\x67\x65\x74\x50\x77\x4e\x61\x6d\x3a\x20\x4c\x6f\x67\x69\x6e\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e"
);main::nxexit ();}if (__isNotCachedUserInfoForUsername ($login)){
__setUserInfoForUsername ($login,$silent);}return (
__getCachedUserInfoHashForUsername ($login));}sub 
extractLicenseBodyFromLicenseFile{(my $content=shift (@_));if (($content=~ /(----- Begin subscription data -----.*----- End subscription data -----)/s )
){(my $body=$1);return ($body);}else{return ($content);}}sub 
readInputTillNewline{(my $filehandle=shift (@_));(my $return_buffer=shift (@_));
(my $silence=shift (@_));if ((not (defined ($silence)))){($silence=
(0x05b7+ 5660-0x1bd3));}Logger::debug (((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x70\x75\x74\x54\x69\x6c\x6c\x4e\x65\x77\x6c\x69\x6e\x65\x3a\x20\x52\x65\x61\x64\x69\x6e\x67\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$filehandle)."\x2e"));(my $fileh=$filehandle);($$return_buffer=(""));my (
$read_buf);(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;$selector->add ($fileh);my ($bytes_read);(my $oldint=$$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"});($$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=sub{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x53\x49\x47\x49\x4e\x54\x2c\x20\x67\x6f\x69\x6e\x67\x20\x74\x6f\x20\x65\x6e\x64\x20\x70\x72\x6f\x63\x65\x73\x73"
);nxexit ();});(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});
$selector->add ($signalFd);(my $finish=(0x0bd9+ 778-0x0ee3));while (($finish==
(0x0d70+ 5972-0x24c4))){(my (@ready)=$selector->can_read);if ((scalar (@ready)==
(0x198a+ 3391-0x26c9))){Logger::debug (
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x2e");($finish=
(0x14d4+ 2778-0x1fad));}foreach my $fh (@ready){if (($fh==$fileh)){($bytes_read=
main::nxread ($fh,(\$read_buf),(0x2176+ 5327-0x2645)));($$return_buffer.=
$read_buf);if ((not ($silence))){Logger::debug (((((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x46\x44\x23".$fh)."\x20\x5b").
$read_buf)."\x5d\x20\x5b").$bytes_read)."\x5d"));}if (($bytes_read==
(0x05f7+ 3607-0x140e))){Logger::debug (((
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$fh)."\x2e"));$selector->remove ($fh);$selector->remove ($signalFd);($finish=
(0x0420+ 2555-0x0e1a));}else{if (($read_buf=~ /\n/ )){$selector->remove ($fileh)
;$selector->remove ($signalFd);chomp ($$return_buffer);($$return_buffer=~ s/\r//g )
;($finish=(0x14b7+ 440-0x166e));}}}}}($$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=$oldint);}sub 
__setUserInfoForUsernameUnix{(my $username=shift (@_));(my $silent=shift (@_));(my $userBufferSize
=16384);(my $userBuffer=("\x20" x $userBufferSize));if ((libnxh::NXUserExist (
$username)==(0x0dd9+ 5052-0x2195))){__setCacheUserInfoFieldForUsername (
$username,"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username
,"\x70\x61\x73\x73\x77\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x65\x63\x6f\x73",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x64\x69\x72",(""));__setCacheUserInfoFieldForUsername ($username,
"\x73\x68\x65\x6c\x6c",(""));if (($silent==(0x009d+ 3532-0x0e69))){
Logger::warning ((("\x55\x73\x65\x72\x20".$username).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x20\x69\x6e\x20\x73\x79\x73\x74\x65\x6d\x2e"
));}return ((0x0ee2+ 1734-0x15a8));}(my $returnValue=libnxh::NXGetUserInfo (
$username,$userBuffer,$userBufferSize));if (($returnValue==(-
(0x0779+ 2359-0x10af)))){if (($silent==(0x09dc+ 765-0x0cd9))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x20\x69\x6e\x66\x6f\x20\x66\x6f\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}__setCacheUserInfoFieldForUsername ($username,
"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x70\x61\x73\x73\x77\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x65\x63\x6f\x73",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x64\x69\x72",(""));__setCacheUserInfoFieldForUsername ($username,
"\x73\x68\x65\x6c\x6c",(""));return ((0x130a+ 4218-0x2384));}($userBuffer=substr
 ($userBuffer,(0x10b9+ 3039-0x1c98),index ($userBuffer,"\x00")));(my (@array)=
split ( /:/ ,$userBuffer,(0x12ff+ 1058-0x1721)));
__setCacheUserInfoFieldForUsername ($username,"\x6e\x61\x6d\x65",$array[
(0x024f+ 5092-0x1633)]);__setCacheUserInfoFieldForUsername ($username,
"\x70\x61\x73\x73\x77\x64",$array[(0x2444+ 709-0x2708)]);
__setCacheUserInfoFieldForUsername ($username,"\x67\x65\x63\x6f\x73",$array[
(0x058c+ 8301-0x25f7)]);__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",$array[(0x0378+ 1486-0x0943)]);__setCacheUserInfoFieldForUsername
 ($username,"\x67\x69\x64",$array[(0x0ca5+ 301-0x0dce)]);
__setCacheUserInfoFieldForUsername ($username,"\x64\x69\x72",$array[
(0x114a+ 5114-0x253f)]);__setCacheUserInfoFieldForUsername ($username,
"\x73\x68\x65\x6c\x6c",$array[(0x0d49+ 2143-0x15a2)]);return (
(0x1b88+ 1258-0x2071));}sub __setUserInfoForUsernameWindows{(my $username=shift 
(@_));(my $silent=shift (@_));if ((libnxh::NXUserExist ($username)==
(0x0d25+ 4760-0x1fbd))){__setCacheUserInfoFieldForUsername ($username,
"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));if (($silent==(0x14ea+ 4349-0x25e7))){Logger::warning (((
"\x55\x73\x65\x72\x20".$username).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x20\x69\x6e\x20\x73\x79\x73\x74\x65\x6d\x2e"
));}return ((0x048b+ 7194-0x20a5));}(my $size=(0x03a8+ 6850-0x1c6a));(my $userSidBuffer
=("\x20" x $size));(my $length=($size-(0x18a4+ 2020-0x2087)));(my $retval=
libnxh::NXConvertUsernameToSid ($username,$userSidBuffer,$length));if (($retval
!=(0x04fb+ 5063-0x18c2))){if (($silent==(0x0666+ 1025-0x0a67))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x20\x73\x69\x64\x20\x66\x6f\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}__setCacheUserInfoFieldForUsername ($username,
"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));return ((0x21b7+ 503-0x23ae));}($userSidBuffer=substr (
$userSidBuffer,(0x0306+ 5515-0x1891),index ($userSidBuffer,"\x00")));
__setCacheUserInfoFieldForUsername ($username,"\x6e\x61\x6d\x65",$username);
__setCacheUserInfoFieldForUsername ($username,"\x75\x69\x64",$userSidBuffer);
return ((0x0ee5+ 4126-0x1f02));}sub setUserSidForUsername{(my $username=shift (
@_));(my $sid=shift (@_));if (__isCachedUserInfoForUsername ($username)){return;
}Logger::debug ((((("\x55\x73\x65\x72\x6e\x61\x6d\x65\x20".$username).
"\x20\x73\x69\x64\x20").$sid).
"\x20\x73\x65\x74\x20\x64\x69\x72\x65\x63\x74\x6c\x79"));
__setCacheUserInfoFieldForUsername ($username,"\x6e\x61\x6d\x65",$username);
__setCacheUserInfoFieldForUsername ($username,"\x75\x69\x64",$sid);
__setUidHashForUsername ($username,$sid);}sub __setUserInfoForUsername{(my $username
=shift (@_));(my $silent=shift (@_));if ((not (defined ($silent)))){($silent=
(0x06e9+ 1998-0x0eb7));}return (__setUserInfoForUsernameWindows ($username,
$silent));}sub userInfoGetUidByUsername{(my $username=shift (@_));(my (%options)
=getPwNam ($username));if ((defined ($options{"\x75\x69\x64"})and ($options{
"\x75\x69\x64"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x75\x69\x64"})."\x2e"
));return ($options{"\x75\x69\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x044d+ 6852-0x1f10)));}sub userInfoGetGidByUsername{(my $username=shift (@_));
(my (%options)=getPwNam ($username));if ((defined ($options{"\x67\x69\x64"})and 
($options{"\x67\x69\x64"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x67\x69\x64"})."\x2e"
));return ($options{"\x67\x69\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x1fa3+ 1630-0x2600)));}sub userInfoGetShellByUsername{(my $username=shift (@_)
);(my (%options)=getPwNam ($username));if ((defined ($options{
"\x73\x68\x65\x6c\x6c"})and ($options{"\x73\x68\x65\x6c\x6c"}ne ("")))){
Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x73\x68\x65\x6c\x6c"}
)."\x2e"));return ($options{"\x73\x68\x65\x6c\x6c"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return (
__getShellIfNotAvailable ());}sub userInfoGetLoginByUsername{(my $username=shift
 (@_));(my (%options)=getPwNam ($username));if ((defined ($options{
"\x6e\x61\x6d\x65"})and ($options{"\x6e\x61\x6d\x65"}ne ("")))){Logger::debug ((
(((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x6c\x6f\x67\x69\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x6e\x61\x6d\x65"}).
"\x2e"));return ($options{"\x6e\x61\x6d\x65"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x6c\x6f\x67\x69\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x0499+ 5538-0x1a3a)));}sub userInfoGetPasswdByUsername{(my $username=shift (@_
));(my (%options)=getPwNam ($username));if ((defined ($options{
"\x70\x61\x73\x73\x77\x64"})and ($options{"\x70\x61\x73\x73\x77\x64"}ne ("")))){
Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x70\x61\x73\x73\x77\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{
"\x70\x61\x73\x73\x77\x64"})."\x2e"));return ($options{
"\x70\x61\x73\x73\x77\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x70\x61\x73\x73\x77\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x0c20+ 4319-0x1cfe)));}sub userInfoGetGecosByUsername{(my $username=shift (@_)
);(my (%options)=getPwNam ($username));if ((defined ($options{
"\x67\x65\x63\x6f\x73"})and ($options{"\x67\x65\x63\x6f\x73"}ne ("")))){
Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x65\x63\x6f\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x67\x65\x63\x6f\x73"}
)."\x2e"));return ($options{"\x67\x65\x63\x6f\x73"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x65\x63\x6f\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x1eac+ 225-0x1f8c)));}sub userInfoGetDirByUsername{(my $username=shift (@_));(my (
%options)=getPwNam ($username));if ((defined ($options{"\x64\x69\x72"})and (
$options{"\x64\x69\x72"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x64\x69\x72\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x64\x69\x72"})."\x2e"
));return ($options{"\x64\x69\x72"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x64\x69\x72\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x1dd0+ 1839-0x24fe)));}sub userIsSystemAdministrator{(my $username=shift (@_))
;Logger::debug (((
"\x4e\x58\x43\x6f\x72\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x49\x73\x41\x64\x6d\x69\x6e\x28"
.$username)."\x29"));(my $return=libnxh::NXIsAdmin ($username));Logger::debug ((
(
"\x4e\x58\x43\x6f\x72\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x49\x73\x41\x64\x6d\x69\x6e\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));if (($return==(0x0782+ 3553-0x1562))){return (
(0x07b7+ 4838-0x1a9c));}return ((0x1119+ 1934-0x18a7));}sub getSystemGroups{(my $size
=16384);(my $groupBuffer=("\x20" x $size));(my $returnValue=
libnxh::NXGetAllSystemGroups ($groupBuffer,$size));if (($returnValue==(-
(0x0b67+ 6902-0x265c)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x61\x6c\x6c\x20\x73\x79\x73\x74\x65\x6d\x20\x67\x72\x6f\x75\x70\x73\x2e"
);Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
libnxh::NXGetError ())."\x2c\x20\x27").libnxh::NXGetErrorString ())."\x27\x2e"))
;return ((""));}(my (@buf)=split ( /\./ ,$groupBuffer,(0x161a+ 2436-0x1f9e)));(
$groupBuffer=$buf[(0x0de4+ 6077-0x25a1)]);return ($groupBuffer);}sub 
getParentPidByPid{(my $pid=shift (@_));(my $returnValue=(0x1a05+  24-0x1a1d));(
$returnValue=libnxh::NXGetParentProcessID ($pid));Logger::debug ((((
"\x4e\x58\x47\x65\x74\x50\x61\x72\x65\x6e\x74\x50\x69\x64\x46\x6f\x72\x50\x69\x64\x3a\x20\x50\x61\x72\x65\x6e\x74\x20\x70\x69\x64\x20\x66\x6f\x72\x20\x70\x69\x64\x20"
.$pid)."\x20\x69\x73\x20").$returnValue));return ($returnValue);}sub 
getUserGroupsFromSystem{(my $username=shift (@_));(my $size=16384);(my $groupBuffer
=("\x20" x $size));(my $returnValue=libnxh::NXGetUserSystemGroups ($username,
$groupBuffer,$size));if (($returnValue==(-(0x0ce3+ 4093-0x1cdf)))){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x67\x72\x6f\x75\x70\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".libnxh::NXGetError ())."\x2c\x20\x27"
).libnxh::NXGetErrorString ())."\x27\x2e"));return ((""));}elsif (($returnValue>
$size)){($size=$returnValue);Logger::debug ((
"\x50\x72\x6f\x76\x69\x64\x65\x64\x20\x62\x75\x66\x66\x65\x72\x20\x69\x73\x20\x74\x6f\x20\x73\x6d\x61\x6c\x6c\x20\x72\x65\x71\x69\x73\x74\x65\x64\x20\x69\x73\x3a\x20"
.$returnValue));($groupBuffer=("\x20" x $size));($returnValue=
libnxh::NXGetUserSystemGroups ($username,$groupBuffer,$size));if (($returnValue
==(-(0x096b+ 3358-0x1688)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x67\x72\x6f\x75\x70\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".libnxh::NXGetError ())."\x2c\x20\x27"
).libnxh::NXGetErrorString ())."\x27\x2e"));return ((""));}}(my (@buf)=split ( /\0/ ,
$groupBuffer,(0x03a5+ 2793-0x0e8e)));return ($buf[(0x1036+ 5672-0x265e)]);}sub 
nxConnectLocal{(my $port=shift (@_));(my $silence=(shift (@_)||"\x6e\x6f"));(my $error_ref
=shift (@_));(my ($package,$filename,$line,$sub)=caller ((0x0dd9+ 3361-0x1af9)))
;if (($sub eq (""))){($sub=$package);}if ((not (defined ($port)))){Logger::error
 (((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x3a\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x63\x61\x6c\x6c\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e"));nxexit ();}Logger::debug (((((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x68\x6f\x73\x74\x3a"
.$port)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));(my $returnValue=
libnxh::NXConnectLocal ($port));if (($returnValue==(-(0x04ec+ 3136-0x112b)))){(
$$error_ref=libnxh::NXGetConnectionError ());if (($silence eq "\x6e\x6f")){
Logger::warning (((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x68\x6f\x73\x74\x3a"
.$port)."\x3a\x20").$$error_ref)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}
return ((-(0x08e2+ 7561-0x266a)));}Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x20\x72\x65\x74\x75\x72\x6e\x3a\x20\x46\x44\x23"
.$returnValue)."\x2e"));nxDescriptorInheritable ($returnValue,
(0x0fe2+ 5377-0x24e3));closeSocketAtFinish ($returnValue);return ($returnValue);
}sub setAttributeOnWindows{(my $path=shift (@_));(my $attr=shift (@_));(my $value
=(shift (@_)||(0x1dc3+ 1961-0x256c)));(my $silent=(shift (@_)||
(0x03f2+ 8453-0x24f7)));if ((not (defined ($path)))){if (($silent==
(0x15c6+ 4254-0x2664))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2f\x66\x6f\x6c\x64\x65\x72\x2e"
);}return ((0x1667+ 2190-0x1ef5));}if ((not (defined ($attr)))){if (($silent==
(0x0724+ 5810-0x1dd6))){Logger::warning (
"\x41\x74\x74\x72\x69\x62\x75\x74\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2f\x66\x6f\x6c\x64\x65\x72\x2e"
);}return ((0x098d+ 2545-0x137e));}Logger::debug (((((((
"\x4e\x58\x53\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65\x3a\x20\x70\x61\x74\x68\x3a\x20"
.$path)."\x2c\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x3a\x20").$attr).
"\x2c\x20\x76\x61\x6c\x75\x65\x3a\x20").$value)."\x2e"));(my $result=
libnxh::NXSetAttribute ($path,$attr,$value));if (($result==(-
(0x1367+ 2540-0x1d52)))){if (($silent==(0x0127+ 3252-0x0ddb))){
reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x20\x66\x6f\x72\x20"
.$path)."\x2e"));}return ((0x0283+ 4755-0x1516));}return ((0x028c+ 3335-0x0f92))
;}sub setHiddenAttributeOnWindows{(my $path=shift (@_));setAttributeOnWindows (
$path,$GLOBAL::HiddenAttribute,(0x0d03+ 3829-0x1bf7));}sub 
removeHiddenAttributeOnWindows{(my $path=shift (@_));setAttributeOnWindows (
$path,$GLOBAL::HiddenAttribute,(0x1840+ 851-0x1b93));}sub 
setReadOnlyAttributeOnWindows{(my $path=shift (@_));return (
setAttributeOnWindows ($path,$GLOBAL::ReadOnlyAttribute,(0x02e8+ 809-0x0610)));}
sub removeReadOnlyAttributeOnWindows{(my $path=shift (@_));return (
setAttributeOnWindows ($path,$GLOBAL::ReadOnlyAttribute,(0x06c9+ 3615-0x14e8)));
}sub cleanOutLanguageCasesInEnvironemt{();}sub 
convertProcessPidToHandleAsSuperuser{(my $pid=shift (@_));Logger::debug (((
"\x43\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20\x70\x69\x64\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x76\x65\x72\x74\x50\x69\x64\x54\x6f\x48\x61\x6e\x64\x6c\x65\x28"
.$pid)."\x29\x2e"));(my $handle=libnxh::NXConvertPidToHandle ($pid));
Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x76\x65\x72\x74\x50\x69\x64\x54\x6f\x48\x61\x6e\x64\x6c\x65\x28"
.$pid)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$handle)."\x27\x2e"))
;if (($handle==(-(0x0afc+ 3407-0x184a)))){reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x2e"));}return ($handle);}
sub convertStringFromWindowsCodePageToUtf8{(my $stringToConvert=shift (@_));if (
libnxh::NXIsUtf8 ($stringToConvert)){Logger::debug2 (((
"\x53\x6b\x69\x70\x20\x63\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20".
$stringToConvert).
"\x20\x74\x6f\x20\x55\x54\x46\x2d\x38\x2e\x20\x53\x74\x72\x69\x6e\x67\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x69\x6e\x20\x55\x54\x46\x2d\x38\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67\x2e"
));return ($stringToConvert);}Logger::debug2 (((
"\x43\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20\x73\x74\x72\x69\x6e\x67\x3a\x20".
$stringToConvert)."\x2e"));(my $stringSize=length ($stringToConvert));(my $bufferSize
=(((0x0611+ 3622-0x1435)*$stringSize)+(0x063b+ 5435-0x1b75)));(my $buffer=(
"\x20" x $bufferSize));(my $returnValue=libnxh::NXConvertWindowsCodePageToUft8 (
$stringToConvert,$buffer,$bufferSize));if (($returnValue==(-(0x07a7+ 535-0x09bd)
))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x27".
$stringToConvert).
"\x27\x20\x66\x72\x6f\x6d\x20\x77\x69\x6e\x64\x6f\x77\x73\x20\x63\x6f\x64\x65\x20\x70\x61\x67\x65\x20\x74\x6f\x20\x75\x66\x74\x38\x2e"
));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
libnxh::NXGetError ())."\x2c\x20\x27").libnxh::NXGetErrorString ())."\x27\x2e"))
;return ($stringToConvert);}elsif (($returnValue>$bufferSize)){Logger::debug (((
"\x50\x72\x6f\x76\x69\x64\x65\x64\x20\x62\x75\x66\x66\x65\x72\x20\x77\x61\x73\x20\x74\x6f\x20\x73\x6d\x61\x6c\x6c\x2e\x20\x52\x65\x71\x69\x73\x74\x65\x64\x20\x73\x69\x7a\x65\x3a\x20"
.$returnValue)."\x2e"));($bufferSize=($returnValue+(0x0b35+ 4101-0x1b39)));(
$buffer=("\x20" x $bufferSize));($returnValue=
libnxh::NXConvertWindowsCodePageToUft8 ($stringToConvert,$buffer,$bufferSize));
if (($returnValue==(-(0x01e2+ 2523-0x0bbc)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x27".
$stringToConvert).
"\x27\x20\x66\x72\x6f\x6d\x20\x77\x69\x6e\x64\x6f\x77\x73\x20\x63\x6f\x64\x65\x20\x70\x61\x67\x65\x20\x74\x6f\x20\x75\x66\x74\x38\x2e"
));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
libnxh::NXGetError ())."\x2c\x20\x27").libnxh::NXGetErrorString ())."\x27\x2e"))
;return ($stringToConvert);}}($buffer=substr ($buffer,(0x0435+ 8676-0x2619),
index ($buffer,"\x00")));Logger::debug2 (((
"\x43\x6f\x6e\x76\x65\x72\x74\x65\x64\x20\x73\x74\x72\x69\x6e\x67\x3a\x20".
$buffer)."\x2e"));return ($buffer);}sub __getCachedUserInfoHashForUsername{(my $login
=shift (@_));return (%{$NXCore::UserInfo{$login};});}sub 
__getCachedUserInfoHashForUid{(my $uid=shift (@_));return (%{$NXCore::UserInfo{
$uid};});}sub __cleanCachedUserInfoForUsername{(my $login=shift (@_));(my $uid=
$NXCore::UserInfo{$login}{"\x75\x69\x64"});undef ($NXCore::UserInfo{$uid});undef
 ($NXCore::UserInfo{$login});}sub __cleanCachedUserInfoForUid{(my $uid=shift (@_
));(my $username=$NXCore::UserInfo{$uid}{"\x6e\x61\x6d\x65"});undef (
$NXCore::UserInfo{$username});undef ($NXCore::UserInfo{$uid});}sub 
__setCacheUserInfoFieldForUsername{(my $login=shift (@_));(my $field=shift (@_))
;(my $value=shift (@_));($NXCore::UserInfo{$login}{$field}=$value);}sub 
__setCacheUserInfoFieldForUid{(my $uid=shift (@_));(my $field=shift (@_));(my $value
=shift (@_));($NXCore::UserInfo{$uid}{$field}=$value);}sub 
__setUidHashForUsername{(my $username=shift (@_));(my $uid=shift (@_));(my $absoluteName
=convertWindowsSidToUsername ($uid));if (($absoluteName ne (""))){(
$NXCore::UserInfo{$uid}=$NXCore::UserInfo{$absoluteName});}else{(
$NXCore::UserInfo{$uid}=$NXCore::UserInfo{$username});}}sub 
__setUsernameHashForUid{(my $username=shift (@_));(my $uid=shift (@_));(
$NXCore::UserInfo{$username}=$NXCore::UserInfo{$uid});}sub 
__isCachedUserInfoForUsername{(my $login=shift (@_));(my (%userInfoHash)=
__getCachedUserInfoHashForUsername ($login));if ((%userInfoHash and (
$userInfoHash{"\x6e\x61\x6d\x65"}ne ("")))){return ((0x0ee3+ 2423-0x1859));}
return ((0x0ae7+ 7096-0x269f));}sub __isCachedUserInfoForUid{(my $uid=shift (@_)
);(my (%userInfoHash)=__getCachedUserInfoHashForUid ($uid));if ((%userInfoHash 
and ($userInfoHash{"\x75\x69\x64"}ne ("")))){return ((0x09ab+ 5098-0x1d94));}
return ((0x16ef+ 2993-0x22a0));}sub __isNotCachedUserInfoForUsername{(my $login=
shift (@_));return ((!__isCachedUserInfoForUsername ($login)));}sub 
__isNotCachedUserInfoForUid{(my $uid=shift (@_));return ((!
__isCachedUserInfoForUid ($uid)));}sub isEffectiveUsernameSystem{(my $returnValue
=libnxh::NXRunningOnSystemAccount ());if (($returnValue==(-(0x0b19+ 6666-0x2522)
))){Logger::warning (
"\x69\x73\x45\x66\x66\x65\x63\x74\x69\x76\x65\x55\x73\x65\x72\x6e\x61\x6d\x65\x53\x79\x73\x74\x65\x6d\x3a\x20\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x69\x66\x20\x53\x59\x53\x54\x45\x4d\x20\x61\x63\x63\x6f\x75\x6e\x74"
);return ((-(0x092a+ 4014-0x18d7)));}if (($returnValue==(0x0780+ 6525-0x20fc))){
return ((0x22e5+ 423-0x248b));}return ((0x033d+ 2320-0x0c4d));}sub 
isEffectiveUsernameRoot{if ((getEffectiveUid ()eq "\x30")){return (
(0x10b8+ 2752-0x1b77));}return ((0x1a5b+  93-0x1ab8));}sub isEffectiveUsernameNX
{if ((getEffectiveUsername ()eq "\x6e\x78")){return ((0x110f+ 2435-0x1a91));}
return ((0x0fb7+ 129-0x1038));}sub isEffectiveUserNXRootOrSystem{if (((
isEffectiveUsernameSystem ()or isEffectiveUsernameRoot ())or 
isEffectiveUsernameNX ())){return ((0x174b+ 2569-0x2153));}return (
(0x0602+ 6215-0x1e49));}sub getPwUid{(my $uid=shift (@_));if ((not (defined (
$uid)))){Logger::error (
"\x67\x65\x74\x50\x77\x55\x69\x64\x3a\x20\x55\x69\x64\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e"
);main::nxexit ();}if (__isNotCachedUserInfoForUid ($uid)){__setUserInfoForUid (
$uid);}return (__getCachedUserInfoHashForUid ($uid));}sub 
__setUserInfoForUidUnix{(my $uid=shift (@_));(my $userBufferSize=16384);(my $userBuffer
=("\x20" x $userBufferSize));(my $returnValue=libnxh::NXGetUserInfoByUid ($uid,
$userBuffer,$userBufferSize));if (($returnValue==(-(0x1068+ 4388-0x218b)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x20\x69\x6e\x66\x6f\x20\x66\x6f\x72\x20"
.$uid)."\x2e"));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));
__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",(""));
__setCacheUserInfoFieldForUid ($uid,"\x70\x61\x73\x73\x77\x64",(""));
__setCacheUserInfoFieldForUid ($uid,"\x67\x65\x63\x6f\x73",(""));
__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",(""));
__setCacheUserInfoFieldForUid ($uid,"\x67\x69\x64",(""));
__setCacheUserInfoFieldForUid ($uid,"\x64\x69\x72",(""));
__setCacheUserInfoFieldForUid ($uid,"\x73\x68\x65\x6c\x6c",(""));return (
(0x0a23+ 3526-0x17e9));}($userBuffer=substr ($userBuffer,(0x10c5+ 1630-0x1723),
index ($userBuffer,"\x00")));(my (@array)=split ( /:/ ,$userBuffer,
(0x0c51+ 6175-0x2470)));__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",
$array[(0x06eb+ 8206-0x26f9)]);__setCacheUserInfoFieldForUid ($uid,
"\x70\x61\x73\x73\x77\x64",$array[(0x15ba+ 1370-0x1b13)]);
__setCacheUserInfoFieldForUid ($uid,"\x67\x65\x63\x6f\x73",$array[
(0x07b4+ 136-0x083a)]);__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",$array
[(0x0f0f+ 4381-0x2029)]);__setCacheUserInfoFieldForUid ($uid,"\x67\x69\x64",
$array[(0x1a02+  78-0x1a4c)]);__setCacheUserInfoFieldForUid ($uid,"\x64\x69\x72"
,$array[(0x0c4a+ 2232-0x14fd)]);__setCacheUserInfoFieldForUid ($uid,
"\x73\x68\x65\x6c\x6c",$array[(0x0b1f+ 4657-0x1d4a)]);(my $username=$array[
(0x0cb4+ 5696-0x22f4)]);__setUsernameHashForUid ($username,$uid);return (
(0x0deb+ 4567-0x1fc1));}sub __setUserInfoForUidWindows{(my $uid=shift (@_));(my $username
=convertWindowsSidToUsername ($uid));if (($username eq (""))){
__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",(""));
__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",(""));return (
(0x062d+ 3496-0x13d5));}__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",
$username);__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",$uid);
__setUsernameHashForUid ($username,$uid);return ((0x01cc+ 8588-0x2357));}sub 
__setUserInfoForUid{(my $uid=shift (@_));return (__setUserInfoForUidWindows (
$uid));}sub userInfoGetUsernameByUid{(my $uid=shift (@_));(my (%options)=
getPwUid ($uid));if ((defined ($options{"\x6e\x61\x6d\x65"})and ($options{
"\x6e\x61\x6d\x65"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x6e\x61\x6d\x65"})."\x2e")
);return ($options{"\x6e\x61\x6d\x65"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x05af+ 1732-0x0c72)));}sub userInfoGetGidByUid{(my $uid=shift (@_));(my (
%options)=getPwUid ($uid));if ((defined ($options{"\x67\x69\x64"})and ($options{
"\x67\x69\x64"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x67\x69\x64"})."\x2e"));
return ($options{"\x67\x69\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x165d+ 423-0x1803)));}sub userInfoGetShellByUid{(my $uid=shift (@_));(my (
%options)=getPwUid ($uid));if ((defined ($options{"\x73\x68\x65\x6c\x6c"})and (
$options{"\x73\x68\x65\x6c\x6c"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x73\x68\x65\x6c\x6c"}).
"\x2e"));return ($options{"\x73\x68\x65\x6c\x6c"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((""));}sub 
getEffectiveUid{if ((defined ($GLOBAL::CACHE_EFFECTIVE_UID)and (
$GLOBAL::CACHE_EFFECTIVE_UID ne ("")))){return ($GLOBAL::CACHE_EFFECTIVE_UID);}(my $uid
=__getEffectiveUidForCurrentProcess ());if (defined ($uid)){(
$GLOBAL::CACHE_EFFECTIVE_UID=$uid);}Logger::debug (((
"\x45\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x20\x69\x73\x3a\x20".$uid)
."\x2e"));return ($uid);}sub __getEffectiveUidForCurrentProcess{my ($uid);(my $bufferSize
=(0x09eb+ 2125-0x1038));(my $buffer=("\x20" x $bufferSize));(my $returnValue=
libnxh::NXGetSidOfCurrentProcess ($buffer,$bufferSize));if (($returnValue==(-
(0x1c84+ 2569-0x268c)))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x69\x64\x20\x66\x6f\x72\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x2e\x20\x52\x65\x74\x75\x72\x6e\x20\x76\x61\x6c\x75\x65\x20\x69\x73\x3a\x20"
.$buffer)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorString)."\x27\x2e"));return ((""));}($buffer=substr ($buffer,
(0x0e79+ 2378-0x17c3),index ($buffer,"\x00")));($uid=$buffer);return ($uid);}sub
 getEffectiveShell{if ((defined ($GLOBAL::CACHE_EFFECTIVE_SHELL)and (
$GLOBAL::CACHE_EFFECTIVE_SHELL ne ("")))){return ($GLOBAL::CACHE_EFFECTIVE_SHELL
);}(my $shell=__getEffectiveShell ());if (((not (defined ($shell)))or ($shell eq
 ("")))){($GLOBAL::CACHE_EFFECTIVE_SHELL=__getShellIfNotAvailable ());}else{
Logger::debug (((
"\x45\x66\x66\x65\x63\x74\x69\x76\x65\x20\x73\x68\x65\x6c\x6c\x20\x69\x73\x3a\x20"
.$shell)."\x2e"));($GLOBAL::CACHE_EFFECTIVE_SHELL=$shell);}return (
$GLOBAL::CACHE_EFFECTIVE_SHELL);}sub __getEffectiveShell{my ($shell);($shell=
libnxh::NXTransGetEnvironment ("\x53\x48\x45\x4c\x4c"));return ($shell);}sub 
uidToUsername{(my $uid=shift (@_));if (((not (defined ($uid)))or ($uid eq ("")))
){Logger::warning (
"\x75\x69\x64\x54\x6f\x55\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20\x75\x69\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e\x20\x47\x65\x74\x74\x69\x6e\x67\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x2e"
);($uid=getEffectiveUid ());}return (userInfoGetUsernameByUid ($uid));}sub 
__getShellIfNotAvailable{(my $euid=getEffectiveUid ());my ($shell);if (
Common::NXFile::isExists ("\x2f\x62\x69\x6e\x2f\x62\x61\x73\x68")){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x69\x64\x20\x27"
.$euid).
"\x27\x3a\x20\x75\x73\x69\x6e\x67\x20\x27\x2f\x62\x69\x6e\x2f\x62\x61\x73\x68\x27"
),(0x0f17+ 2226-0x17c9));($shell="\x2f\x62\x69\x6e\x2f\x62\x61\x73\x68");}else{
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x69\x64\x20\x27"
.$euid).
"\x27\x3a\x20\x75\x73\x69\x6e\x67\x20\x27\x2f\x62\x69\x6e\x2f\x73\x68\x27"),
(0x0dd5+ 979-0x11a8));($shell="\x2f\x62\x69\x6e\x2f\x73\x68");}return ($shell);}
sub getProcessIdsByNameAndPpidOnWindows{(my $name=shift (@_));(my $ppid=shift (
@_));(my $strict=(0x1e38+ 1991-0x25ff));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
getProcessIdsByNameWithExtensionAndPpidOnWindows{(my $name=shift (@_));(my $ppid
=shift (@_));(my $strict=(0x0027+ 1025-0x0427));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
getProcessIdsByNameWithExtensionOnWindows{(my $name=shift (@_));(my $ppid=
(0x1b35+ 1508-0x2119));(my $strict=(0x1839+ 1562-0x1e52));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
getProcessIdsByNameOnWindows{(my $name=shift (@_));(my $ppid=
(0x117a+ 1209-0x1633));(my $strict=(0x0591+ 7159-0x2188));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
__getPidsByNameWithExtensionAndPpidOnWindows{(my $name=shift (@_));(my $ppid=(
shift (@_)||(0x0e53+ 6226-0x26a5)));(my $strict=(shift (@_)||
(0x0a75+ 6668-0x2481)));(my $pids=libnxh::NXGetPidsByNameAndParentPid ($name,
$ppid,$strict));return (@$pids);}sub __setConsoleEchoMode{(my $mode=shift (@_));
(my $result=libnxh::NXSetEchoMode ($mode));if (($result!=(0x09c4+ 3344-0x16d4)))
{reportErrorFromNXPL (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x74\x65\x72\x6d\x69\x6e\x61\x6c\x20\x65\x63\x68\x6f\x20\x6d\x6f\x64\x65\x2e"
);return ((0x0b08+ 4225-0x1b89));}return ((0x2136+ 1342-0x2673));}sub 
enableConsoleEchoMode{return (__setConsoleEchoMode ((0x0929+ 7130-0x2502)));}sub
 disableConsoleEchoMode{return (__setConsoleEchoMode ((0x148d+ 1233-0x195e)));}
sub loadNXLibrary{(my $library=shift (@_));if (isNXLibraryLoaded ($library)){
Logger::debug ((("\x27".$library).
"\x27\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x77\x61\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x6c\x6f\x61\x64\x65\x64\x2e"
));return;}(my (@backupINC)=@INC);if (($GLOBAL::AgentLibraryPath ne (""))){push 
(@INC,(($GLOBAL::AgentLibraryPath.$GLOBAL::DIRECTORY_SLASH)."\x70\x65\x72\x6c"))
;push (@INC,$GLOBAL::AgentLibraryPath);}push (@INC,(($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e"));(my $libraryreq=((
"\x6e\x78\x63\x6f\x72\x65\x2f".$library)."\x2e\x70\x6d"));eval{require (
$libraryreq);};(@INC=@backupINC);if ($@){(my $errString=$!);(my $errNo=int ($!))
;syswrite (STDERR,((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x74\x68\x65\x20\x27"
.$library)."\x27\x20\x6c\x69\x62\x72\x61\x72\x79\x2e\x0a"));syswrite (STDERR,(((
(
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errNo)."\x2c\x20\x27").$errString)."\x27\x2e\x0a"));exit (
(0x1033+ 4079-0x2021));}setNXLibraryLoaded ($library);return (
(0x19d4+ 2764-0x24a0));}sub loadAllModulesLibraries{if (($NXBegin::moduletype eq
 "\x6e\x78\x73\x65\x72\x76\x65\x72")){loadListOfLibraries ((
\@NXCore::NXServerLibraryList));}elsif (($NXBegin::moduletype eq 
"\x6e\x78\x6e\x6f\x64\x65")){loadListOfLibraries ((\@NXCore::NXNodeLibraryList))
;}elsif (($NXBegin::moduletype eq "\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72"
)){loadListOfLibraries ((\@NXCore::NXWebPlayerLibraryList));}}sub 
loadListOfLibraries{(my $libraryList=shift (@_));foreach my $library (@{
$libraryList;}){loadNXLibrary ($library);}}sub loadAgentLibraries{foreach my $library
 (@NXCore::NXAgentLibraryList){loadNXLibrary ($library);}}sub 
isAllServerLibrariesLoaded{foreach my $library (@NXCore::NXServerLibraryList){if
 (($$NXCore::NXLibrary{"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{
$library}==(0x0b62+ 2102-0x1398))){return ((0x006c+ 863-0x03cb));}}return (
(0x14df+ 418-0x1680));}sub isAllNodeLibrariesLoaded{foreach my $library (
@NXCore::NXNodeLibraryList){if (($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library}==
(0x09ac+ 6491-0x2307))){return ((0x0796+ 6060-0x1f42));}}return (
(0x18df+ 1199-0x1d8d));}sub isAllWebplayerLibrariesLoaded{foreach my $library (
@NXCore::NXWebPlayerLibraryList){if (($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library}==
(0x0350+ 6924-0x1e5c))){return ((0x1234+ 3581-0x2031));}}return (
(0x13b1+ 4195-0x2413));}sub isNXLibraryLoaded{(my $library=shift (@_));
Logger::debug (((((
"\x69\x73\x4e\x58\x4c\x69\x62\x72\x61\x72\x79\x4c\x6f\x61\x64\x65\x64\x20\x27".
$library)."\x27\x20\x3d\x20\x27").$$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library})."\x27\x2e"));if (
($$NXCore::NXLibrary{"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{
$library}==(0x0657+ 4584-0x183e))){return ((0x0f5b+ 2473-0x1903));}else{return (
(0x0456+ 4757-0x16eb));}}sub isNXLibraryLoadedForModule{if ((
$NXBegin::moduletype eq "\x6e\x78\x73\x65\x72\x76\x65\x72")){return (
isAllServerLibrariesLoaded ());}elsif (($NXBegin::moduletype eq 
"\x6e\x78\x6e\x6f\x64\x65")){return (isAllNodeLibrariesLoaded ());}elsif ((
$NXBegin::moduletype eq "\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72")){return 
(isAllWebplayerLibrariesLoaded ());}return ((0x0d51+ 459-0x0f1c));}sub 
setNXLibraryLoaded{(my $library=shift (@_));($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library}=
(0x044f+ 5436-0x198a));}sub listContentInDirectory{(my $path=shift (@_));(my $ref_contentArray
=shift (@_));(my $ref_error=shift (@_));(my $contentString=
libnxh::NXListContentInDirectory ($path));if (($contentString eq (""))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x63\x6f\x6e\x74\x65\x6e\x74\x2e"
);Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));($$ref_error=$errorString);return (
(0x093f+ 2554-0x1339));}(my (@lines)=split ( /\n/ ,$contentString,
(0x0456+ 6120-0x1c3e)));foreach my $line (@lines){if ((($line ne "\x2e")and (
$line ne "\x2e\x2e"))){push (@$ref_contentArray,$line);}}return (
(0x0df2+ 1892-0x1555));}sub listFilesInDirectory{(my $path=shift (@_));(my $ref_filesArray
=shift (@_));(my $sort=(shift (@_)||(0x1aa5+ 912-0x1e35)));(my $ref_error=shift 
(@_));(my (@content)=());(my $result=listContentInDirectory ($path,(\@content),
$ref_error));if (($result==(0x1e7d+ 1900-0x25e9))){return ((0x033f+ 205-0x040c))
;}my (@files);if ($sort){(@files=sort (@content));}else{(@files=@content);}
foreach my $file (@files){(my $filePath=(($path.$GLOBAL::DIRECTORY_SLASH).$file)
);if (Common::NXFile::fileExists ($filePath)){push (@$ref_filesArray,$file);}}
return ((0x01c6+ 8019-0x2118));}sub listFoldersInDirectory{(my $path=shift (@_))
;(my $ref_foldersArray=shift (@_));(my $ref_error=shift (@_));(my (@folders)=())
;(my $result=listContentInDirectory ($path,(\@folders),$ref_error));if (($result
==(0x1b89+ 1471-0x2148))){return ((0x0877+ 890-0x0bf1));}foreach my $folder (
@folders){(my $folderPath=(($path.$GLOBAL::DIRECTORY_SLASH).$folder));if (-d (
$folderPath)){push (@$ref_foldersArray,$folder);}}return ((0x0751+ 3197-0x13cd))
;}sub listSortedFilesInDirectory{(my $path=shift (@_));(my $ref_filesArray=shift
 (@_));(my $ref_error=shift (@_));(my $sort=(0x0892+ 7069-0x242e));return (
listFilesInDirectory ($path,$ref_filesArray,$sort,$ref_error));}sub 
__createZipFile{(my $destination=shift (@_));(my $ref_paths=shift (@_));(my $ref_names
=shift (@_));(my $ref_excludePaths=shift (@_));(my $append=shift (@_));(my $level
=shift (@_));(my $password=shift (@_));(my $ref_error=shift (@_));
__removeExtraSlashesFromZipPaths ($ref_paths,$ref_names,$ref_excludePaths);(my $returnValue
=libnxh::NXCreateZipFile ($destination,$ref_paths,$ref_names,$ref_excludePaths,
$append,$level,$password));if (($returnValue!=(0x04e5+ 1100-0x0931))){if ((
$returnValue==(-(0x0809+ 1671-0x0e8f)))){(my $errorNumber=libnxh::NXGetError ())
;(my $errorString=libnxh::NXGetErrorString ());Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x61\x72\x63\x68\x69\x76\x65\x20\x66\x69\x6c\x65\x20"
.$destination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").((
$errorNumber."\x2c\x20").$errorString)));($$ref_error=$errorString);return ((-
(0x1498+ 4067-0x247a)));}else{(my $nxerrorFilePath=
Common::NXPaths::getNXServerLogPath ());Logger::warning (((
"\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x72\x63\x68\x69\x76\x65\x20\x66\x69\x6c\x65\x20"
.$destination).
"\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x77\x61\x72\x6e\x69\x6e\x67\x73\x2e"
));Logger::warning ((
"\x46\x6f\x72\x20\x6d\x6f\x72\x65\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x70\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20"
.$nxerrorFilePath));return ((0x0fb3+ 2029-0x17a0));}}Logger::debug (((
"\x5a\x69\x70\x20\x66\x69\x6c\x65\x3a\x20".$destination).
"\x20\x63\x72\x65\x61\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79"
));return ((0x1175+ 1824-0x1894));}sub __removeExtraSlashesFromZipPaths{(my $ref_paths
=shift (@_));(my $ref_names=shift (@_));(my $ref_excludePaths=shift (@_));
foreach my $path (@$ref_paths){Common::NXPaths::removeExtraSlashesFromPath ((
\$path));}foreach my $path (@$ref_names){
Common::NXPaths::removeExtraSlashesFromPath ((\$path));}foreach my $path (
@$ref_excludePaths){Common::NXPaths::removeExtraSlashesFromPath ((\$path));}}sub
 createZipFileWithBestCompression{(my $destination=shift (@_));(my $ref_paths=
shift (@_));(my $ref_names=shift (@_));(my $ref_excludePaths=shift (@_));(my $ref_error
=shift (@_));my ($password);(my $returnValue=__createZipFile ($destination,
$ref_paths,$ref_names,$ref_excludePaths,$NXBITS::APPEND_STATUS_CREATE,
$NXBITS::Z_BEST_COMPRESSION,$password,$ref_error));return ($returnValue);}sub 
runNextIterationAfterRunCallback{(my $ref_descriptors=shift (@_));(my $ref_result
=shift (@_));(my $nxselectTimeoutTimestamp=shift (@_));(my $actualTime=shift (@_
));(my $timeout=($nxselectTimeoutTimestamp-$actualTime));return (nxselect (
$ref_descriptors,$timeout,$ref_result));}sub 
isCallbackTimestampBeforeSelectTimeout{(my $nxselectTimeout=shift (@_));(my $firstCallbackTimestamp
=shift (@_));if (($nxselectTimeout>$firstCallbackTimestamp)){return (
(0x21a9+ 695-0x245f));}return ((0x0ead+ 4588-0x2099));}sub 
isTimeToRunTimestampCallback{(my $firstCallbackTimestamp=shift (@_));(my $currentTime
=shift (@_));(my $timeout=($firstCallbackTimestamp-$currentTime));if (($timeout
<=(0x03e8+ 5130-0x17f2))){return ((0x07d0+ 447-0x098e));}return (
(0x136b+ 3243-0x2016));}sub setNewSelectTimeout{(my $firstCallbackTimestamp=
shift (@_));(my $currentTime=shift (@_));return (($firstCallbackTimestamp-
$currentTime));}sub getCommandLineOfCurrentProcessOnWindows{(my $commandLine=
libnxhs::NXGetCommandLine ());if (($commandLine eq (""))){return ((""));}
libnxh::NXGetConsoleOutput ();libnxh::NXSetConsoleOutputUTF8 ();(
$NXCore::windowsConsoleCPGet=(0x0ba8+ 790-0x0ebd));return ($commandLine);}sub 
restoreConsoleCPonWindows{if (($NXCore::windowsConsoleCPGet==
(0x0e18+ 3828-0x1d0b))){libnxh::NXSetDefaultConsoleOutput ();}}sub 
parseProcessArgumentsFromCommandLineOnWindows{(my $commandLine=
getCommandLineOfCurrentProcessOnWindows ());($commandLine=~ s/"//g );(my (
@arguments)=split ( / {1,}/ ,$commandLine,(0x1054+ 3000-0x1c0c)));while (
@arguments){(my $arg=shift (@arguments));if (($arg=~ /nxserver/ )){last;}}return
 (@arguments);}sub convertCommandLineArgumentsOnWindows{(my (@newArguments)=
parseProcessArgumentsFromCommandLineOnWindows ());(my $numberOfNewArguments=
scalar (@newArguments));if ((($numberOfNewArguments>(0x0bf3+ 5613-0x21e0))and (
$numberOfNewArguments==scalar (@ARGV)))){(@ARGV=@newArguments);return (
(0x0d68+ 1898-0x14d1));}return ((0x0c7c+ 4456-0x1de4));}sub 
addUserToSystemOnWindows{(my $username=shift (@_));(my $password=shift (@_));(my $ref_error
=shift (@_));(my $returnValue=libnxhs::NXNetUserAdd ($username,$password));if ((
$returnValue!=(0x0071+ 8768-0x22b0))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x75\x73\x65\x72\x20".$username).
"\x20\x74\x6f\x20\x73\x79\x73\x74\x65\x6d\x2e"));(my $error=
getErrorStringForErrorCodeOnWindows ($returnValue));if (($error ne (""))){
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$returnValue).
"\x2c\x20").$error)."\x2e"));($$ref_error=$error);}return ((0x0224+ 4656-0x1454)
);}Logger::debug ((("\x41\x64\x64\x65\x64\x20\x75\x73\x65\x72\x20".$username).
"\x20\x74\x6f\x20\x73\x79\x73\x74\x65\x6d\x2e"));return ((0x0cd2+ 4824-0x1fa9));
}sub deleteUserFromSystemOnWindows{(my $username=shift (@_));(my $ref_error=
shift (@_));(my $returnValue=libnxhs::NXNetUserDel ($username));if ((
$returnValue!=(0x0991+ 3447-0x1707))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x75\x73\x65\x72\x20".
$username)."\x20\x66\x72\x6f\x6d\x20\x73\x79\x73\x74\x65\x6d\x2e"));(my $error=
getErrorStringForErrorCodeOnWindows ($returnValue));if (($error ne (""))){
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$returnValue).
"\x2c\x20").$error)."\x2e"));($$ref_error=$error);}return ((0x1a2a+ 1189-0x1ecf)
);}Logger::debug ((("\x44\x65\x6c\x65\x74\x65\x64\x20\x75\x73\x65\x72\x20".
$username)."\x20\x66\x72\x6f\x6d\x20\x73\x79\x73\x74\x65\x6d\x2e"));return (
(0x06a7+ 6900-0x219a));}sub setUserSystemPasswordOnWindows{(my $username=shift (
@_));(my $password=shift (@_));(my $ref_error=shift (@_));(my $returnValue=
libnxhs::NXNetUserPass ($username,$password));if (($returnValue!=
(0x240a+ 275-0x251c))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x75\x73\x65\x72\x20".$username).
"\x20\x70\x61\x73\x73\x73\x77\x6f\x72\x64\x2e"));(my $error=
getErrorStringForErrorCodeOnWindows ($returnValue));if (($error ne (""))){
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$returnValue).
"\x2c\x20").$error)."\x2e"));($$ref_error=$error);}return ((0x0999+ 2767-0x1468)
);}Logger::debug ((("\x55\x73\x65\x72\x20".$username).
"\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x63\x68\x61\x6e\x67\x65\x2e"));return 
((0x1572+ 655-0x1800));}sub getErrorStringForErrorCodeOnWindows{(my $errorCode=
shift (@_));(my $returnValue=libnxh::NXGetErrorMessage ($errorCode));if ((
$returnValue ne (""))){chop ($returnValue);chop ($returnValue);return (
$returnValue);}return ((""));}sub __setCurrentNXSelectDescriptos{(my $ref_descriptors
=shift (@_));(++$NXCore::nxselectIteration);foreach $FD (@$ref_descriptors){(
$$NXCore::currentNXSelectDescriptors{$NXCore::nxselectIteration}{$FD}={});}}sub 
__removeDescriptorFromNXSelectCurrentList{(my $FD=shift (@_));for ((my $i=
(0x0d46+ 4875-0x2050));($i<=$NXCore::nxselectIteration);(++$i)){if (exists (
$$NXCore::currentNXSelectDescriptors{$i}{$FD})){delete (
$$NXCore::currentNXSelectDescriptors{$i}{$FD});}}}sub 
__getCurrentNXSelectDescriptorsAndClean{(my (@descriptors)=keys (%{
$$NXCore::currentNXSelectDescriptors{$NXCore::nxselectIteration};}));
__cleanCurrentNXSelectIteration ();return ((\@descriptors));}sub 
__cleanCurrentNXSelectIteration{($$NXCore::currentNXSelectDescriptors{
$NXCore::nxselectIteration}={});($NXCore::nxselectIteration--);}sub 
leftJustifyString{(my $string=shift (@_));(my $maxLength=shift (@_));(my $character
=(shift (@_)||"\x20"));(my $length=libnxh::NXStringLength ($string));(my $fillCount
=($maxLength-$length));if (($fillCount>(0x02bc+ 1090-0x06fe))){return (($string.
($character x $fillCount)));}return ($string);}sub leftJustifyOrTrimString{(my $string
=shift (@_));(my $maxLength=shift (@_));(my $character=(shift (@_)||"\x20"));(my $length
=libnxh::NXStringLength ($string));(my $fillCount=($maxLength-$length));if ((
$fillCount>(0x1952+ 895-0x1cd1))){return (($string.($character x $fillCount)));}
elsif (($fillCount<(0x13a8+ 3156-0x1ffc))){return (libnxh::NXSubstring ($string,
(0x0953+ 2125-0x11a0),$maxLength));}return ($string);}sub 
isCurrentUserSystemAdmin{(my $user=getEffectiveUsername ());Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x66\x20\x75\x73\x65\x72\x20".$user).
"\x20\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
));if ((libnxh::NXIsAdmin ($user)==(0x0d7b+ 3573-0x1b6f))){Logger::debug (((
"\x55\x73\x65\x72\x20".$user).
"\x20\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
));return ((0x04fb+ 4159-0x1539));}return ((0x085b+ 4494-0x19e9));Logger::debug 
((("\x55\x73\x65\x72\x20".$user).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
));}sub processPurgeArg{(my $msg=shift (@_));Logger::debug3 (((
"\x4e\x58\x43\x6f\x72\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x50\x75\x72\x67\x65\x41\x72\x67\x28"
.$msg)."\x29\x2e"));libnxh::NXProcessPurgeArg ($msg);Logger::debug3 (((
"\x4e\x58\x43\x6f\x72\x65\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x50\x75\x72\x67\x65\x41\x72\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$msg)."\x27\x2e"));return ($msg);}return ((0x1441+ 4244-0x24d4));
