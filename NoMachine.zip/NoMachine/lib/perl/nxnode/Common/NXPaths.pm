############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXPaths;no warnings;require Common::NXFile;(
$NXPaths::cacheUserHomeDirectory=(""));((%NXPaths::cacheRealUserHomePath)=());((
%NXPaths::cacheNXDirPerUserPath)=());sub __isNXDirPerUserCached{(my $username=
shift (@_));if (($username eq (""))){return ((0x10bd+ 2541-0x1aaa));}if (exists 
($NXPaths::cacheNXDirPerUserPath{$username})){return ((0x0844+ 1310-0x0d61));}
else{return ((0x02e0+ 6004-0x1a54));}}sub __setNXDirPerUserCached{(my $username=
shift (@_));(my $userNxDir=__handleUserNXDirectoryPathForUser ($username));(
$NXPaths::cacheNXDirPerUserPath{$username}=$userNxDir);}sub 
__setUsersNXDirPerUserCached{(my $username=shift (@_));(my $userNxDir=
__handleUsersDirectoryPathForUser ($username));($NXPaths::cacheNXDirPerUserPath{
$username}=$userNxDir);}sub __getNXDirPerUserCached{(my $username=shift (@_));
return ($NXPaths::cacheNXDirPerUserPath{$username});}sub __isRealUserHomeCached{
(my $username=shift (@_));if (($username eq (""))){return ((0x0144+ 7849-0x1fed)
);}if (exists ($NXPaths::cacheRealUserHomePath{$username})){return (
(0x02cf+ 2925-0x0e3b));}else{return ((0x0977+ 977-0x0d48));}}sub 
__setRealUserHomeCached{(my $username=shift (@_));(my $homePath=
__getUserHomeDirectoryByUsername ($username));($NXPaths::cacheRealUserHomePath{
$username}=$homePath);}sub __getRealUserHomeCached{(my $username=shift (@_));
return ($NXPaths::cacheRealUserHomePath{$username});}sub 
__getUserHomeDirectoryWindows{(my $username=shift (@_));(my $size=
(0x0b04+ 150-0x0a95));(my $homeBuffer=("\x20" x $size));(my $length=($size-
(0x0a6f+ 3998-0x1a0c)));(my $ret=libnxh::NXHomeDirGet ($homeBuffer,$length,
$username));if (($ret==(-(0x0a86+ 3871-0x19a4)))){Logger::debug (((
"\x55\x73\x65\x72\x20".$username).
"\x20\x68\x6f\x6d\x65\x64\x69\x72\x65\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x70\x61\x74\x68\x2e"
));return (((getSystemTMPPath ().$GLOBAL::DIRECTORY_SLASH).$username));}(my (
@buffer)=split ( /\000/ ,$homeBuffer,(0x17c4+ 2137-0x201d)));Logger::debug (((((
"\x55\x73\x65\x72\x20\x27".$username).
"\x27\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27").
$buffer[(0x097f+ 2378-0x12c9)])."\x27\x2e"));return ($buffer[
(0x0fc6+ 3009-0x1b87)]);}sub getFailbackHomeDirectoryPathFromNXTemp{return (((
getSystemTMPPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x54\x6d\x70\x48\x6f\x6d\x65"));}sub 
getNxDirectoryInEffectiveUserHomeDirectory{return (((
getEffectiveUserHomeDirectory ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));}sub
 getNxDirectoryInUserHomeDirectory{(my $username=shift (@_));return (((
getUserHomeDirectory ($username).$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));}sub
 getHomeDirectoryOfDesktopOwnerWindows{(my ($userName,$tmp)=
NXLocalSession::getDisplayOwnerAndType ());if (((not (defined ($userName)))or (
$userName eq ("")))){(my $failbackDirectory=
getFailbackHomeDirectoryPathFromNXTemp ());Logger::debug ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x79\x65\x74\x2e\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x20\x74\x6f\x20"
.$failbackDirectory));return ($failbackDirectory);}return (
__getUserHomeDirectoryWindows ($userName));}sub 
getNxDirectoryInHomeOfDesktopOwnerOnWindows{(my $ref_errorName=shift (@_));(my (
$userName,$tmp)=NXLocalSession::getDisplayOwnerAndType ());my (
$userDirectoryPath);if ((($GLOBAL::UsersDirectoryPath ne (""))and ($userName ne 
"\x6e\x78"))){($userDirectoryPath=__handleUsersDirectoryPathForUser ($userName))
;}elsif (($GLOBAL::UserNXDirectoryPath ne (""))){($userDirectoryPath=
__handleUserNXDirectoryPathForUser ($userName));}else{if (((not (defined (
$userName)))or ($userName eq ("")))){($userDirectoryPath=
getFailbackHomeDirectoryPathFromNXTemp ());Logger::debug ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x79\x65\x74\x2e\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x20\x74\x6f\x20"
.$userDirectoryPath));}else{($userDirectoryPath=__getUserHomeDirectoryWindows (
$userName));}}(my $nxDirectoryPath=(($userDirectoryPath.$GLOBAL::DIRECTORY_SLASH
)."\x2e\x6e\x78"));if ((not (Common::NXFile::directoryExists ($nxDirectoryPath))
)){Logger::debug (((
"\x2e\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x69\x6e\x20\x75\x73\x65\x72\x27\x73\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$nxDirectoryPath)."\x2e"));if ((not (
NXPaths::createAndCorrectUserNXDirectoryOnWindows ($nxDirectoryPath,
$ref_errorName)))){Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x73\x65\x74\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x61\x74\x20"
.$nxDirectoryPath)."\x2e"));}}return ($nxDirectoryPath);}sub 
getEffectiveUserHomeDirectory{return (getUserHomeDirectory (
Common::NXCore::getEffectiveUsername ()));}sub getUserXauthorityFile{(my $path=(
getUserRealHomeDirectoryByEffectiveUser ().
"\x2f\x2e\x58\x61\x75\x74\x68\x6f\x72\x69\x74\x79"));return ($path);}sub 
__getUserHomeDirectoryByUsername{(my $userName=shift (@_));return (
__getUserHomeDirectoryWindows ($userName));}sub __getUserHomeDirectoryUnix{(my $userName
=shift (@_));return (Common::NXCore::userInfoGetDirByUsername ($userName));}sub 
getUserRealHomeDirectoryByEffectiveUser{(my $username=
Common::NXCore::getEffectiveUsername ());if (($username eq (""))){
Common::NXCore::reportErrorFromNXPL (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);main::nxexit ((0x0213+ 923-0x05ad));}return (
getUserRealHomeDirectoryByUsername ($username));}sub 
getUserRealHomeDirectoryByUsername{(my $username=shift (@_));if (
__isRealUserHomeCached ($username)){return (__getRealUserHomeCached ($username))
;}else{__setRealUserHomeCached ($username);return (__getRealUserHomeCached (
$username));}}sub getUserHomeDirectory{(my $userName=shift (@_));if ((($userName
 eq (""))or (not (defined ($userName))))){Logger::error (
"\x43\x61\x6e\x20\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x66\x6f\x72\x20\x65\x6d\x70\x74\x79\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);main::nxexit ((0x1323+ 414-0x14c0));}if ((($GLOBAL::UsersDirectoryPath ne ("")
)and ($userName ne "\x6e\x78"))){if (__isNXDirPerUserCached ($userName)){return 
(__getNXDirPerUserCached ($userName));}__setUsersNXDirPerUserCached ($userName);
return (__getNXDirPerUserCached ($userName));}elsif ((
$GLOBAL::UserNXDirectoryPath ne (""))){if (__isNXDirPerUserCached ($userName)){
return (__getNXDirPerUserCached ($userName));}__setNXDirPerUserCached ($userName
);return (__getNXDirPerUserCached ($userName));}else{return (
getUserRealHomeDirectoryByUsername ($userName));}}sub getLanguageFile{(my $language
=shift (@_));(my $languageFile=((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)
."\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x63\x61\x6c\x65").
$GLOBAL::DIRECTORY_SLASH));($languageFile.=(
"\x6e\x78\x73\x65\x72\x76\x65\x72\x5f".$language));return ($languageFile);}sub 
getUserNXHomeDir{if (defined ($NXPaths::UserNXHomeDir)){return (
$NXPaths::UserNXHomeDir);}(my $size=(0x0ef5+ 1573-0x1415));(my $homeBuffer=(
"\x20" x $size));(my $length=($size-(0x0343+ 1048-0x075a)));(my $username=
"\x6e\x78");(my $ret=libnxh::NXHomeDirGet ($homeBuffer,$length,$username));(my (
@buffer)=split ( /\000/ ,$homeBuffer,(0x0328+ 1533-0x0925)));(
$NXPaths::UserNXHomeDir=$buffer[(0x09e9+ 2562-0x13eb)]);return (
$NXPaths::UserNXHomeDir);($NXPaths::UserNXHomeDir=
"\x2f\x76\x61\x72\x2f\x4e\x58\x2f\x6e\x78");return ($NXPaths::UserNXHomeDir);}
sub __handleUsersDirectoryPathForUser{(my $user=shift (@_));(my $ref_errorName=
shift (@_));if ((not (defined ($user)))){($user=
Common::NXCore::getEffectiveUsername ());}(my $DirPathExist=
(0x0165+ 3211-0x0def));if ((not (Common::NXFile::directoryExists (
$GLOBAL::UsersDirectoryPath)))){Logger::debug ((((("\x55\x73\x65\x72\x20".$user)
.
"\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
).$GLOBAL::UsersDirectoryPath)."\x2e"));($DirPathExist=
createAccessibleForAllDirectory ($ref_errorName,$GLOBAL::UsersDirectoryPath));}
if ($DirPathExist){(my $userDirPath=(($GLOBAL::UsersDirectoryPath.
$GLOBAL::DIRECTORY_SLASH).$user));if ((not (Common::NXFile::directoryExists (
$userDirPath)))){Logger::debug ((((("\x55\x73\x65\x72\x20".$user).
"\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
).$userDirPath)."\x2e"));if ((createAccessibleForUserDirectory ($ref_errorName,
$userDirPath,$user)==(0x2173+ 1384-0x26db))){if (((not (defined ($$ref_errorName
)))or ($$ref_errorName eq ("")))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e"));}else{Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$$ref_errorName));}}}return ($userDirPath);}Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$users)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$$ref_errorName));
return (undef);}sub __handleUserNXDirectoryPathForUser{(my $user=shift (@_));(my $ref_errorName
=shift (@_));if ((not (defined ($user)))){($user=
Common::NXCore::getEffectiveUsername ());}(my $DirPathExist=
(0x036a+ 4409-0x14a2));if ((not (Common::NXFile::directoryExists (
$GLOBAL::UserNXDirectoryPath)))){Logger::debug (((
"\x55\x73\x65\x72\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$GLOBAL::UserNXDirectoryPath)."\x2e"));($DirPathExist=
createAccessibleForAllDirectory ($ref_errorName,$GLOBAL::UserNXDirectoryPath));}
if ($DirPathExist){(my $userDirPath=(($GLOBAL::UserNXDirectoryPath.
$GLOBAL::DIRECTORY_SLASH).$user));if ((not (Common::NXFile::directoryExists (
$userDirPath)))){Logger::debug (((
"\x55\x73\x65\x72\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$userDirPath)."\x2e"));if ((createAccessibleForUserDirectory ($ref_errorName,
$userDirPath,$user)==(0x09fc+ 5685-0x2031))){if (((not (defined ($$ref_errorName
)))or ($$ref_errorName eq ("")))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e"));}else{Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$$ref_errorName));}}}return ($userDirPath);}Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$$ref_errorName));return (undef);}sub makePath{(my ($ref_errorMessage,$path,
$verbose,$mode)=@_);(my $success=(0x0d2d+ 6410-0x2636));($$ref_errorMessage=("")
);($path=Common::NXCore::convertStringFromWindowsCodePageToUtf8 ($path));
Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x28".
$path)."\x2c\x20").$mode)."\x29"));(my $returnValue=libnxh::NXMakePath ($path,
$mode));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x1171+ 3120-0x1da1))){(my $errorNumber
=libnxh::NXGetError ());($$ref_errorMessage=libnxh::NXGetErrorString ());(
$success=(0x1382+ 3070-0x1f80));Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$path)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$$ref_errorMessage)."\x27\x2e"));}return ($success
);}sub rmtree{(my $path=shift (@_));(my $returnValue=libnxh::NXRemovePath ($path
));if (($returnValue!=(0x01c4+ 5854-0x18a2))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$path)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));return ($returnValue);}
Logger::debug2 (((
"\x72\x6d\x74\x72\x65\x65\x3a\x20\x53\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x20\x72\x65\x6d\x6f\x76\x65\x64\x20"
.$path)."\x2e"));return ((0x0c6b+ 964-0x102f));}sub identityServerFilePath{
return ((((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").
$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72\x2e\x69\x64\x5f\x64\x73\x61\x2e\x6b\x65\x79"));}sub 
getSystemdServicePath{return (undef);}sub createAccessibleForAllDirectory{(my $ref_errorMessage
=shift (@_));(my $path=shift (@_));if ((not (makePath ($ref_errorMessage,$path))
)){return ((0x01f5+ 6690-0x1c17));}else{if ((
Common::NXFile::setPermissionsFullForAllDirectory ($path,$ref_errorMessage)==(-
(0x0d59+ 1083-0x1193)))){return ((0x069d+ 2280-0x0f85));}}return (
(0x1378+ 131-0x13fa));}sub createAccessibleForUserDirectory{(my $ref_errorMessage
=shift (@_));(my $path=shift (@_));(my $user=shift (@_));if ((not (makePath (
$ref_errorMessage,$path)))){return ((0x005f+ 9367-0x24f6));}else{if ((not (
defined ($user)))){($user=Common::NXCore::getEffectiveUsername ());}if ((
Common::NXFile::setOwnershipForUser ($path,$user,$ref_errorMessage)==(-
(0x086d+ 3348-0x1580)))){return ((0x0ec5+ 923-0x1260));}if ((
Common::NXFile::setPermissionsFullForUserDirectory ($path,$user,
$ref_errorMessage)==(-(0x2063+ 928-0x2402)))){return ((0x231c+  34-0x233e));}}
return ((0x11aa+ 1407-0x1728));}sub createNodeRootDirectory{(my $ref_errorMessage
=shift (@_));(my $path=shift (@_));(my $resultOwnership=(-(0x096c+ 7412-0x265f))
);(my $username=Common::NXCore::getEffectiveUsername ());if ((
$GLOBAL::CommonLogDirectory ne (""))){return (createAccessibleForAllDirectory ((
\$createDirectoryError),$path));}if ((not (makePath ($ref_errorMessage,$path))))
{return ((0x03b0+ 3171-0x1013));}else{if (
Common::NXCore::isEffectiveUsernameRoot ()){($resultOwnership=
Common::NXFile::setOwnershipForUserNXGroupRoot ($path,$ref_errorMessage));}else{
($resultOwnership=Common::NXFile::setOwnershipForUser ($path,$username,
$ref_errorMessage));}if (($resultOwnership==(-(0x0154+ 2981-0x0cf8)))){return (
(0x0e72+ 4130-0x1e94));}if ((Common::NXFile::setPermissionsUserNodeRootDirectory
 ($path,$username,$ref_errorMessage)==(-(0x0e28+ 5470-0x2385)))){return (
(0x0f4f+ 4487-0x20d6));}}return ((0x00a8+ 8478-0x21c5));}sub 
createAccessibleForNXDirectory{(my $ref_errorMessage=shift (@_));(my $path=shift
 (@_));unless (makePath ($ref_errorMessage,$path)){return ((0x1a83+ 3013-0x2648)
);}if ((Common::NXFile::setOwnerShipNXAndFullPermissions ($path,
$ref_errorMessage)==(-(0x1753+ 2818-0x2254)))){return ((0x0580+ 2265-0x0e59));}
return ((0x062f+ 3328-0x132e));}sub getNodeRootDirectoryPath{return (((
getDirectoryForLogsPath ().$GLOBAL::DIRECTORY_SLASH)."\x6e\x6f\x64\x65"));}sub 
sessionDirPathToClientPidFile{(my $sessionDir=shift (@_));(my $path=$sessionDir)
;($path.=($GLOBAL::DIRECTORY_SLASH."\x63\x6c\x69\x65\x6e\x74"));($path.=(
$GLOBAL::DIRECTORY_SLASH."\x70\x69\x64"));return ($path);}sub 
getPathForCommandOfProcessPid{(my $pid=shift (@_));return ((""));}sub 
getUserNodeCfgPath{(my $user=shift (@_));(my $path=((((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).$user).
"\x2e\x6e\x6f\x64\x65\x2e\x63\x66\x67"));return ($path);}sub 
getPathToLocalNXserverPlist{(my $path=((((($GLOBAL::DIRECTORY_SLASH.
"\x4c\x69\x62\x72\x61\x72\x79").$GLOBAL::DIRECTORY_SLASH).
"\x4c\x61\x75\x6e\x63\x68\x41\x67\x65\x6e\x74\x73").$GLOBAL::DIRECTORY_SLASH).
"\x63\x6f\x6d\x2e\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x6c\x6f\x63\x61\x6c\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x70\x6c\x69\x73\x74"
));return ($path);}sub getPathToNXDPlist{(my $path=((((($GLOBAL::DIRECTORY_SLASH
."\x4c\x69\x62\x72\x61\x72\x79").$GLOBAL::DIRECTORY_SLASH).
"\x4c\x61\x75\x6e\x63\x68\x44\x61\x65\x6d\x6f\x6e\x73").$GLOBAL::DIRECTORY_SLASH
).
"\x63\x6f\x6d\x2e\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x6e\x78\x64\x2e\x70\x6c\x69\x73\x74"
));return ($path);}sub getPathToServerDaemonPlist{(my $path=(((((
$GLOBAL::DIRECTORY_SLASH."\x4c\x69\x62\x72\x61\x72\x79").
$GLOBAL::DIRECTORY_SLASH)."\x4c\x61\x75\x6e\x63\x68\x44\x61\x65\x6d\x6f\x6e\x73"
).$GLOBAL::DIRECTORY_SLASH).
"\x63\x6f\x6d\x2e\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x73\x65\x72\x76\x65\x72\x2e\x70\x6c\x69\x73\x74"
));return ($path);}sub getSpecialUsersLogFolderPath{(my $path=((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67"));return ($path);}sub
 getSpecialUsersNXServerLogPath{(my $path=((getSpecialUsersLogFolderPath ().
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67"));
return ($path);}sub getDirectoryForLogsPath{if (($GLOBAL::CommonLogDirectory ne 
(""))){return ($GLOBAL::CommonLogDirectory);}if (
Common::NXCore::isEffectiveUserNXRootOrSystem ()){return (
getSpecialUsersLogFolderPath ());}return (
getNxDirectoryInEffectiveUserHomeDirectory ());}sub getNXServerLogPath{return ((
(getDirectoryForLogsPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67"));}sub 
removeExtraSlashesFromPath{(my $ref_path=shift (@_));($$ref_path=~ s/\\+/\\/g );
}sub getSystemTMPPath{return (windowsGetTempPath ());}sub windowsGetTempPath{(my $path
=libnxh::NXTransGetEnvironment ("\x54\x4d\x50"));if (($path eq (""))){($path=
libnxh::NXTransGetEnvironment ("\x54\x45\x4d\x50"));if (($path eq (""))){($path=
libnxh::NXTransGetEnvironment ("\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45"));
if (($path eq (""))){($path=libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"));}}}return ($path);}return (
(0x0c3a+ 6372-0x251d));
