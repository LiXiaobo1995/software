############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXDescriptor;no warnings;($NXDescriptor::restoreSTDOUT=
(0x1570+ 4111-0x257e));sub setNotRestoreSTDOUT{($NXDescriptor::restoreSTDOUT=
(0x189d+ 2616-0x22d5));}sub needRestoreSTDOUT{return (
$NXDescriptor::restoreSTDOUT);}sub yield{(my $fd=shift (@_));(my $socket=shift (
@_));(my $cookie=shift (@_));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x59\x69\x65\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$fd)."\x2c\x20").$socket)."\x2c\x20\x2a\x2a\x2a\x29"));(my $return=
libnxh::NXYieldDescriptor ($fd,$socket,$cookie));Logger::debug ((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x59\x69\x65\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$fd)."\x2c\x20").$socket)."\x2c\x20\x2a\x2a\x2a\x29\x20").$return));if ((
$return==(-(0x10a4+ 1373-0x1600)))){(my $errorInt=libnxh::NXGetError ());(my $errorName
=libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());if ((
$errorName eq "\x45\x4e\x4f\x54\x54\x59")){Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x59\x69\x65\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$fd)."\x2c\x20").$socket).
"\x2c\x20\x2a\x2a\x2a\x29\x20\x65\x72\x72\x6f\x72\x20\x69\x73\x20\x45\x4e\x4f\x54\x54\x59\x2c\x20\x74\x72\x79\x69\x6e\x67\x20\x61\x67\x61\x69\x6e"
));($return=libnxh::NXYieldDescriptor ($fd,$socket,$cookie));Logger::debug (((((
(
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x59\x69\x65\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$fd)."\x2c\x20").$socket)."\x2c\x20\x2a\x2a\x2a\x29\x20").$return));if ((
$return==(-(0x019f+ 2414-0x0b0c)))){($errorInt=libnxh::NXGetError ());(
$errorName=libnxh::NXGetErrorName ());($errorString=libnxh::NXGetErrorString ())
;}else{return ($return);}}Logger::error ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x79\x69\x65\x6c\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20"
.$fd)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorInt)."\x20").
$errorName)."\x20").$errorString));return ($return);}return ($return);}sub 
acquire{(my $pid=shift (@_));(my $fd=shift (@_));(my $socket=shift (@_));(my $cookie
=shift (@_));Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x63\x71\x75\x69\x72\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$pid)."\x2c\x20").$fd)."\x2c\x20").$socket)."\x2c\x20\x2a\x2a\x2a\x29"));(my $return
=libnxh::NXAcquireDescriptor ($pid,$fd,$socket,$cookie));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x63\x71\x75\x69\x72\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));if (($return==(-(0x0b3d+ 6671-0x254b)))){(my $errorInt=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());(my $errorName
=libnxh::NXGetErrorName ());Logger::error ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x71\x75\x69\x72\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x66\x72\x6f\x6d\x20\x70\x69\x64\x20"
.$pid)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$errorInt)."\x20").
$errorName)."\x20").$errorString));return ($return);}return ($return);}
"\x3f\x3f\x3f";
