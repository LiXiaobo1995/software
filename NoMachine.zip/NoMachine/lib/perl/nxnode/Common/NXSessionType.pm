############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXSessionType::BEGIN{package Common::NXSessionType;no warnings;
require Common::NXDistro;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x44\x69\x73\x74\x72\x6f"->import};}
package Common::NXSessionType;no warnings;my (%internal);my (%external);(
$NXSessionType::physicalDesktop=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70");($internal{
$NXSessionType::physicalDesktop}=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x2d\x64\x65\x73\x6b\x74\x6f\x70");($external{
"\x70\x68\x79\x73\x69\x63\x61\x6c\x2d\x64\x65\x73\x6b\x74\x6f\x70"}=
$NXSessionType::physicalDesktop);($external{
"\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73"}=
$NXSessionType::physicalDesktop);($external{
"\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63"}=$NXSessionType::physicalDesktop);(
$NXSessionType::physicalAttachDesktop=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x74\x74\x61\x63\x68\x44\x65\x73\x6b\x74\x6f\x70"
);($internal{$NXSessionType::physicalAttachDesktop}=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x2d\x64\x65\x73\x6b\x74\x6f\x70");(
$NXSessionType::virtualDefault=
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x66\x61\x75\x6c\x74");($internal{
$NXSessionType::virtualDefault}=
"\x75\x6e\x69\x78\x2d\x78\x73\x65\x73\x73\x69\x6f\x6e\x2d\x64\x65\x66\x61\x75\x6c\x74"
);($external{
"\x75\x6e\x69\x78\x2d\x78\x73\x65\x73\x73\x69\x6f\x6e\x2d\x64\x65\x66\x61\x75\x6c\x74"
}=$NXSessionType::virtualDefault);($NXSessionType::virtualGnome=
"\x76\x69\x72\x74\x75\x61\x6c\x47\x6e\x6f\x6d\x65");($internal{
$NXSessionType::virtualGnome}="\x75\x6e\x69\x78\x2d\x67\x6e\x6f\x6d\x65");(
$external{"\x75\x6e\x69\x78\x2d\x67\x6e\x6f\x6d\x65"}=
$NXSessionType::virtualGnome);($NXSessionType::virtualKde=
"\x76\x69\x72\x74\x75\x61\x6c\x4b\x64\x65");($internal{
$NXSessionType::virtualKde}="\x75\x6e\x69\x78\x2d\x6b\x64\x65");($external{
"\x75\x6e\x69\x78\x2d\x6b\x64\x65"}=$NXSessionType::virtualKde);(
$NXSessionType::virtualCde="\x76\x69\x72\x74\x75\x61\x6c\x43\x64\x65");(
$internal{$NXSessionType::virtualCde}="\x75\x6e\x69\x78\x2d\x63\x64\x65");(
$external{"\x75\x6e\x69\x78\x2d\x63\x64\x65"}=$NXSessionType::virtualCde);(
$NXSessionType::virtualConsole=
"\x76\x69\x72\x74\x75\x61\x6c\x43\x6f\x6e\x73\x6f\x6c\x65");($internal{
$NXSessionType::virtualConsole}=
"\x75\x6e\x69\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65");($external{
"\x75\x6e\x69\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65"}=
$NXSessionType::virtualConsole);($NXSessionType::virtualApplicationDefault=
"\x76\x69\x72\x74\x75\x61\x6c\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x44\x65\x66\x61\x75\x6c\x74"
);($internal{$NXSessionType::virtualApplicationDefault}=
"\x75\x6e\x69\x78\x2d\x64\x65\x66\x61\x75\x6c\x74");($external{
"\x75\x6e\x69\x78\x2d\x64\x65\x66\x61\x75\x6c\x74"}=
$NXSessionType::virtualApplicationDefault);($NXSessionType::virtualDesktop=
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70");($internal{
$NXSessionType::virtualDesktop}=
"\x75\x6e\x69\x78\x2d\x64\x65\x73\x6b\x74\x6f\x70");($external{
"\x75\x6e\x69\x78\x2d\x64\x65\x73\x6b\x74\x6f\x70"}=
$NXSessionType::virtualDesktop);($NXSessionType::virtualXdm=
"\x76\x69\x72\x74\x75\x61\x6c\x58\x64\x6d");($internal{
$NXSessionType::virtualXdm}="\x75\x6e\x69\x78\x2d\x78\x64\x6d");($external{
"\x75\x6e\x69\x78\x2d\x78\x64\x6d"}=$NXSessionType::virtualXdm);(
$NXSessionType::virtualVms="\x76\x69\x72\x74\x75\x61\x6c\x56\x6d\x73");(
$internal{$NXSessionType::virtualVms}="\x76\x6d\x73");($external{"\x76\x6d\x73"}
=$NXSessionType::virtualVms);($NXSessionType::virtualVnc=
"\x76\x69\x72\x74\x75\x61\x6c\x56\x6e\x63");($internal{
$NXSessionType::virtualVnc}="\x76\x6e\x63");($external{"\x76\x6e\x63"}=
$NXSessionType::virtualVnc);($NXSessionType::virtualRDP=
"\x76\x69\x72\x74\x75\x61\x6c\x52\x44\x50");($internal{
$NXSessionType::virtualRDP}="\x77\x69\x6e\x64\x6f\x77\x73");($external{
"\x77\x69\x6e\x64\x6f\x77\x73"}=$NXSessionType::virtualRDP);(
$NXSessionType::virtualUnixApplication=
"\x76\x69\x72\x74\x75\x61\x6c\x55\x6e\x69\x78\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e"
);($internal{$NXSessionType::virtualUnixApplication}=
"\x75\x6e\x69\x78\x2d\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e");($external{
"\x75\x6e\x69\x78\x2d\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e"}=
$NXSessionType::virtualUnixApplication);($NXSessionType::customForeignMaster=
"\x63\x75\x73\x74\x6f\x6d\x46\x6f\x72\x65\x69\x67\x6e\x4d\x61\x73\x74\x65\x72");
($internal{$NXSessionType::customForeignMaster}=
"\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65\x2d\x63\x75\x73\x74\x6f\x6d");(
$external{
"\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65\x2d\x63\x75\x73\x74\x6f\x6d"}=
$NXSessionType::customForeignMaster);($NXSessionType::foreignDesktop=
"\x66\x6f\x72\x65\x69\x67\x6e\x44\x65\x73\x6b\x74\x6f\x70");($internal{
$NXSessionType::foreignDesktop}="\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65");
($external{"\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65"}=
$NXSessionType::foreignDesktop);($NXSessionType::foreignAttach=
"\x66\x6f\x72\x65\x69\x67\x6e\x41\x74\x74\x61\x63\x68");($internal{
$NXSessionType::foreignAttach}="\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65");(
$NXSessionType::virtualAttach=
"\x76\x69\x72\x74\x75\x61\x6c\x41\x74\x74\x61\x63\x68");($internal{
$NXSessionType::virtualAttach}="\x73\x68\x61\x64\x6f\x77");($external{
"\x73\x68\x61\x64\x6f\x77"}=$NXSessionType::virtualAttach);(
$NXSessionType::nxFrameBuffer=
"\x6e\x78\x46\x72\x61\x6d\x65\x42\x75\x66\x66\x65\x72");($internal{
$NXSessionType::nxFrameBuffer}="\x6e\x78\x76\x66\x62");($external{
"\x6e\x78\x76\x66\x62"}=$NXSessionType::nxFrameBuffer);(
$NXSessionType::nxConsole="\x6e\x78\x43\x6f\x6e\x73\x6f\x6c\x65");($internal{
$NXSessionType::nxConsole}="\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65");(
$external{"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65"}=$NXSessionType::nxConsole)
;($NXSessionType::nxConsoleShadow=
"\x6e\x78\x43\x6f\x6e\x73\x6f\x6c\x65\x53\x68\x61\x64\x6f\x77");($internal{
$NXSessionType::nxConsoleShadow}=
"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65\x2d\x73\x68\x61\x64\x6f\x77");(
$external{"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65\x2d\x73\x68\x61\x64\x6f\x77"
}=$NXSessionType::nxConsoleShadow);($NXSessionType::automaticRecording=
"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67");($internal{
$NXSessionType::automaticRecording}="\x73\x68\x61\x64\x6f\x77");(
$NXSessionType::connectionMonitor=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");(
$NXSessionType::nodeConnectionMonitor=
"\x6e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);($NXSessionType::serverConnectionMonitor=
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);($NXSessionType::sessionNegotiate=
"\x73\x65\x73\x73\x69\x6f\x6e\x4e\x65\x67\x6f\x74\x69\x61\x74\x65");($internal{
$NXSessionType::sessionNegotiate}=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2d\x6f\x6e\x6c\x79");($external{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2d\x6f\x6e\x6c\x79"}=
$NXSessionType::sessionNegotiate);my (%translateFromClient35);(
$translateFromClient35{
"\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73"}=
$NXSessionType::physicalDesktop);($translateFromClient35{
"\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63"}=$NXSessionType::physicalDesktop);(
$translateFromClient35{"\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c"}=
$NXSessionType::physicalDesktop);my (%translateToClient35);($translateToClient35
{"\x77\x69\x6e\x64\x6f\x77\x73"}=
"\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73");(
$translateToClient35{"\x6d\x61\x63"}="\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63")
;($translateToClient35{"\x6c\x69\x6e\x75\x78"}=
"\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c");($translateToClient35{
"\x73\x6f\x6c\x61\x72\x69\x73"}="\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c");sub 
isNotVirtual{return ((!isVirtual (shift (@_))));}sub isVirtual{(my $sessionType=
shift (@_));if (((((((((($sessionType eq $NXSessionType::physicalDesktop)or (
$sessionType eq $NXSessionType::physicalAttachDesktop))or ($sessionType eq 
$NXSessionType::virtualAttach))or ($sessionType eq $NXSessionType::foreignAttach
))or ($sessionType eq $NXSessionType::connectionMonitor))or ($sessionType eq 
$NXSessionType::nodeConnectionMonitor))or ($sessionType eq 
$NXSessionType::serverConnectionMonitor))or ($sessionType eq 
$NXSessionType::foreignDesktop))or ($sessionType eq 
$NXSessionType::nxConsoleShadow))){return ((0x0e00+ 4682-0x204a));}return (
(0x03b6+ 2610-0x0de7));}sub isNotPhysical{return ((!isPhysical (shift (@_))));}
sub isPhysical{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::physicalDesktop)){return ((0x007c+   4-0x007f));}return (
(0x1528+ 2449-0x1eb9));}sub getForeignAttach{return (
$NXSessionType::foreignAttach);}sub isForeignAttach{(my $sessionType=shift (@_))
;if (($sessionType eq $NXSessionType::foreignAttach)){return (
(0x0d53+ 246-0x0e48));}return ((0x0608+ 5192-0x1a50));}sub isNotForeignAttach{
return ((!isForeignAttach (shift (@_))));}sub isForeignMaster{(my $sessionType=
shift (@_));if ((($sessionType eq $NXSessionType::customForeignMaster)or (
$sessionType eq $NXSessionType::foreignDesktop))){return ((0x0d8b+ 4725-0x1fff))
;}return ((0x1d95+ 1383-0x22fc));}sub isForeignDesktop{(my $sessionType=shift (
@_));if (($sessionType eq $NXSessionType::foreignDesktop)){return (
(0x15f1+ 1165-0x1a7d));}return ((0x2633+  45-0x2660));}sub isCustomForeignMaster
{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::customForeignMaster)){return ((0x0bc5+ 3504-0x1974));}return (
(0x01ba+ 3473-0x0f4b));}sub isNotForeignMaster{return ((!isForeignMaster (shift 
(@_))));}sub isVirtualAttach{(my $sessionType=shift (@_));if (((($sessionType eq
 $NXSessionType::virtualAttach)or ($sessionType eq $NXSessionType::foreignAttach
))or ($sessionType eq $NXSessionType::nxConsoleShadow))){return (
(0x0913+ 2089-0x113b));}return ((0x0e37+ 4768-0x20d7));}sub isNotPhysicalAttach{
return ((!isPhysicalAttach (shift (@_))));}sub getTypeForOptionsFile{(my $type=
shift (@_));if (($type eq $NXSessionType::virtualUnixApplication)){return (
"\x64\x65\x73\x6b\x74\x6f\x70");}(my $tmp=$internal{$type});($tmp=~ s/unix-// );
($tmp=~ s/xsession-.*/xsession-local/ );return ($tmp);}sub isPhysicalAttach{(my $sessionType
=shift (@_));if ((($sessionType eq $NXSessionType::physicalAttachDesktop)or (
$sessionType eq $NXSessionType::foreignAttach))){return ((0x0d28+ 1558-0x133d));
}return ((0x004b+ 7589-0x1df0));}sub typeNotExist{return ((!typeExist (shift (@_
))));}sub typeExist{(my $sessionType=shift (@_));if (defined ($internal{
$sessionType})){return ((0x244c+ 116-0x24bf));}return ((0x0e07+ 4681-0x2050));}
sub translateToClient{(my $type=shift (@_));(my $platform=shift (@_));
Logger::debug ((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x74\x6f\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x69\x73\x3a\x20"
.$type)."\x2c").$platform));my ($sessionType);if (((
$GLOBAL::CLIENT_MAJOR_VERSION lt (0x00f6+ 1133-0x055f))or (((
$GLOBAL::CLIENT_MAJOR_VERSION eq (0x179d+ 2949-0x231e))and (
$GLOBAL::CLIENT_MINOR_VERSION eq (0x01e2+ 2280-0x0aca)))and (
$GLOBAL::CLIENT_PATCH_VERSION lt (0x08bc+ 5576-0x1dc9))))){if (
Common::NXDistro::isLinux ($platform)){($platform="\x6c\x69\x6e\x75\x78");}if ((
$type eq $NXSessionType::physicalDesktop)){($sessionType=$translateToClient35{
$platform});}else{if ((not (defined ($internal{$type})))){
__setInternalAndExternalForFoundXSessions ($type);}($sessionType=$internal{$type
});}}else{if ((not (defined ($internal{$type})))){
__setInternalAndExternalForFoundXSessions ($type);}($sessionType=$internal{$type
});}Logger::debug (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$sessionType)."\x5d"));return ($sessionType);}sub translateFromClient{(my $type
=shift (@_));if ((($GLOBAL::CLIENT_MAJOR_VERSION lt (0x02fc+ 4903-0x161f))or (((
$GLOBAL::CLIENT_MAJOR_VERSION eq (0x090d+ 6403-0x220c))and (
$GLOBAL::CLIENT_MINOR_VERSION eq (0x191d+  93-0x197a)))and (
$GLOBAL::CLIENT_PATCH_VERSION lt (0x169c+ 3026-0x21b3))))){return (
__translateFromClient35 ($type));}else{return (__translateFromClient4 ($type));}
}sub __translateFromClient35{(my $type=shift (@_));Logger::debug2 (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x5b".$type).
"\x5d\x20\x74\x6f\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x66\x6f\x72\x20\x33\x2e\x35\x20\x63\x6c\x69\x65\x6e\x74\x2e"
));(my $sessionType=$translateFromClient35{$type});if (($sessionType eq (""))){(
$sessionType=$external{$type});}if (($sessionType eq (""))){Logger::debug2 (((((
"\x5f\x5f\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x46\x72\x6f\x6d\x43\x6c\x69\x65\x6e\x74\x33\x35\x20\x6e\x6f\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20"
.$type)."\x20\x5b").$sessionType)."\x5d"));($sessionType=$type);}else{
Logger::debug2 (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$sessionType)."\x5d"));}return ($sessionType);}sub __translateFromClient4{(my $type
=shift (@_));my ($sessionType);Logger::debug2 ((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x74\x6f\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x69\x73\x3a\x20"
.$type));if (typeExist ($type)){Logger::debug2 (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$type)."\x5d"));return ($type);}if (($type eq $internal{
$NXSessionType::physicalDesktop})){($sessionType=
$NXSessionType::physicalAttachDesktop);}elsif (($type eq $internal{
$NXSessionType::foreignDesktop})){($sessionType=$NXSessionType::foreignAttach);}
else{($sessionType=$external{$type});}if ((($sessionType eq (""))and ($type=~ /^xsession-/ )
)){getXsessionTypes ();($sessionType=$external{$type});}if (($sessionType eq 
(""))){Logger::debug2 (("\x4e\x6f\x20\x74\x79\x70\x65\x20\x66\x6f\x72\x20\x3a".
$type));($sessionType=$type);}else{Logger::debug2 (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$sessionType)."\x5d"));}return ($sessionType);}sub convertToInternal{(my $externalType
=shift (@_));if (typeExist ($externalType)){return ($externalType);}if ((
$externalType ne $external{$NXSessionType::physicalDesktop})){if (((
$externalType=~ /^xsession-/ )and (not (defined ($external{$externalType}))))){
getXsessionTypes ();}return ($external{$externalType});}(my $internalType=
$externalType);return ($internalType);}sub convertListToInternal{(my $list=shift
 (@_));(my (@sessionsArray)=split ( /,/ ,$list,(0x03d8+ 8921-0x26b1)));(my $sessions
=(""));foreach my $session (@sessionsArray){($sessions.=(convertToInternal (
$session)."\x2c"));}($sessions=~ s/,$// );return ($sessions);}sub 
convertToExternal{(my $internalType=shift (@_));if ((not (defined ($internal{
$internalType})))){__setInternalAndExternalForFoundXSessions ($internalType);}
return ($internal{$internalType});}sub convertListToExternal{(my $list=shift (@_
));(my (@sessionsArray)=split ( /,/ ,$list,(0x03e3+ 8978-0x26f5)));(my $sessions
=(""));foreach my $session (@sessionsArray){($sessions.=(convertToExternal (
$session)."\x2c"));}($sessions=~ s/,$// );return ($sessions);}sub 
convertExternalList{(my $externalList=shift (@_));Logger::debug2 (((
"\x4c\x69\x73\x74\x20\x74\x6f\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x69\x73\x3a\x20\x5b"
.$externalList)."\x5d"));my ($internalList);(my (@types)=split ( /,/ ,
$externalList,(0x083b+ 1746-0x0f0d)));foreach my $type (@types){my ($sessionType
);if (((($type eq "\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73")or 
($type eq "\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63"))or ($type eq 
"\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c"))){($sessionType=
$NXSessionType::physicalDesktop);}else{($sessionType=$external{$type});}if ((
$internalList ne (""))){($internalList.="\x2c");}($internalList.=$sessionType);}
Logger::debug2 (((
"\x43\x6f\x6e\x76\x65\x72\x74\x65\x64\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x20\x6c\x69\x73\x74\x20\x69\x73\x3a\x20\x5b"
.$internalList)."\x5d"));return ($internalList);}sub isMirror{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::physicalAttachDesktop)){return 
((0x048c+ 4487-0x1612));}return ((0x19b9+ 1459-0x1f6c));}sub isNotAttach{return 
((!isAttach (shift (@_))));}sub isAttach{(my $sessionType=shift (@_));if (((((
$sessionType eq $NXSessionType::physicalAttachDesktop)or ($sessionType eq 
$NXSessionType::virtualAttach))or ($sessionType eq $NXSessionType::foreignAttach
))or ($sessionType eq $NXSessionType::nxConsoleShadow))){return (
(0x0040+ 7305-0x1cc8));}return ((0x0852+ 984-0x0c2a));}sub isVirtualDefault{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualDefault)){return (
(0x01aa+ 3010-0x0d6b));}return ((0x0c10+ 4206-0x1c7e));}sub getVirtualDefault{
return ($NXSessionType::virtualDefault);}sub isUnixDefault{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::virtualApplicationDefault)){
return ((0x06d2+ 5167-0x1b00));}return ((0x0806+ 3183-0x1475));}sub isUnixGnome{
(my $sessionType=shift (@_));if (($sessionType eq $NXSessionType::virtualGnome))
{return ((0x057d+ 2037-0x0d71));}return ((0x0e14+ 6077-0x25d1));}sub isUnixXdm{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualXdm)){return (
(0x0254+ 8293-0x22b8));}return ((0x01e9+ 2001-0x09ba));}sub isUnixApplication{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualUnixApplication)){
return ((0x11f0+ 5052-0x25ab));}return ((0x0c84+ 5171-0x20b7));}sub isUnixKDE{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualKde)){return (
(0x0a0f+ 4542-0x1bcc));}return ((0x0119+ 7611-0x1ed4));}sub isUnixCde{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualCde)){return (
(0x00c0+ 368-0x022f));}return ((0x00bf+ 804-0x03e3));}sub isUnixConsole{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualConsole)){return (
(0x0875+ 6586-0x222e));}return ((0x00d4+ 5126-0x14da));}sub isUnixDesktop{(my $sessionType
=shift (@_));if ((($sessionType eq $NXSessionType::virtualDesktop)or (
$sessionType eq $NXSessionType::foreign))){return ((0x073c+ 1620-0x0d8f));}
return ((0x074b+ 608-0x09ab));}sub isSessionSomeShadow{(my $sessionType=shift (
@_));if (($sessionType=~ /shadow.*/ )){return ((0x14ac+ 2781-0x1f88));}return (
(0x071a+ 3771-0x15d5));}sub isUnixAny{(my $sessionType=shift (@_));if ((((((((((
$sessionType eq $NXSessionType::virtualGnome)or ($sessionType eq 
$NXSessionType::virtualKde))or ($sessionType eq $NXSessionType::virtualCde))or (
$sessionType eq $NXSessionType::virtualConsole))or ($sessionType eq 
$NXSessionType::virtualApplicationDefault))or ($sessionType eq 
$NXSessionType::virtualDesktop))or ($sessionType eq $NXSessionType::virtualXdm))
or ($sessionType eq $NXSessionType::virtualUnixApplication))or ($sessionType eq 
$NXSessionType::nxFrameBuffer))){return ((0x0a93+ 5869-0x217f));}return (
(0x040f+ 7549-0x218c));}sub isUnixVirtual{(my $sessionType=shift (@_));if ((((((
(($sessionType eq $NXSessionType::virtualGnome)or ($sessionType eq 
$NXSessionType::virtualKde))or ($sessionType eq $NXSessionType::virtualCde))or (
$sessionType eq $NXSessionType::virtualConsole))or ($sessionType eq 
$NXSessionType::virtualApplicationDefault))or ($sessionType eq 
$NXSessionType::virtualDesktop))or ($sessionType eq $NXSessionType::virtualXdm))
){return ((0x143d+ 1220-0x1900));}return ((0x098f+ 5815-0x2046));}sub 
isVirtualRDP{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::virtualRDP)){return ((0x05b4+ 3242-0x125d));}return (
(0x0e19+ 1169-0x12aa));}sub isVirtualRDPOrVnc{(my $sessionType=shift (@_));if ((
($sessionType eq $NXSessionType::virtualRDP)or ($sessionType eq 
$NXSessionType::virtualVnc))){return ((0x0bac+ 4067-0x1b8e));}return (
(0x0c2b+ 643-0x0eae));}sub isVirtualVms{(my $sessionType=shift (@_));if ((
$sessionType eq $NXSessionType::virtualVms)){return ((0x0c74+ 6166-0x2489));}
return ((0x1470+ 2014-0x1c4e));}sub isVirtualVnc{(my $sessionType=shift (@_));if
 (($sessionType eq $NXSessionType::virtualVnc)){return ((0x151f+ 1968-0x1cce));}
return ((0x2067+ 1656-0x26df));}sub isConnectionMonitor{(my $sessionType=shift (
@_));if (($sessionType eq $NXSessionType::connectionMonitor)){return (
(0x03b1+ 4536-0x1568));}return ((0x07c8+ 5509-0x1d4d));}sub 
isNodeConnectionMonitor{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::nodeConnectionMonitor)){return ((0x07e5+ 6440-0x210c));}return (
(0x0d9b+ 5136-0x21ab));}sub isServerConnectionMonitor{(my $sessionType=shift (@_
));if (($sessionType eq $NXSessionType::serverConnectionMonitor)){return (
(0x144f+ 2687-0x1ecd));}return ((0x1594+ 4450-0x26f6));}sub getPhysicalDesktop{
return ($NXSessionType::physicalDesktop);}sub getForeignDesktop{return (
$NXSessionType::foreignDesktop);}sub getCustomForeignMaster{return (
$NXSessionType::customForeignMaster);}sub isShadowable{(my $sessionType=shift (
@_));if ((((isPhysical ($sessionType)or isVirtual ($sessionType))or isVirtualVms
 ($sessionType))or isForeignDesktop ($sessionType))){return (
(0x1917+ 2250-0x21e0));}return ((0x1550+ 1201-0x1a01));}sub isReconnectable{(my $sessionType
=shift (@_));if (isVirtual ($sessionType)){return ((0x02fb+ 3748-0x119e));}
return ((0x036c+ 203-0x0437));}sub getSessionVms{return (
$NXSessionType::virtualVms);}sub getVirtualAttach{return (
$NXSessionType::virtualAttach);}sub getPhysicalAttach{return (
$NXSessionType::physicalAttachDesktop);}sub getUnixDefault{return (
$NXSessionType::virtualApplicationDefault);}sub getUnixDesktop{return (
$NXSessionType::virtualDesktop);}sub getConnectionMonitor{return (
$NXSessionType::connectionMonitor);}sub getNodeConnectionMonitor{return (
$NXSessionType::nodeConnectionMonitor);}sub getServerConnectionMonitor{return (
$NXSessionType::serverConnectionMonitor);}sub getSessionNegotiate{return (
$NXSessionType::sessionNegotiate);}sub getAllTypes{my ($allTypes);while ((my (
$key,$value)=each (%external))){($allTypes.=(convertToInternal ($key)."\x2c"));}
chop ($allTypes);return ($allTypes);}sub getAllExternalTypes{my ($allTypes);
while ((my ($key,$value)=each (%external))){($allTypes.=($key."\x2c"));}chop (
$allTypes);return ($allTypes);}sub getDefaultTypesForLocalNode{(my $availableSessions
=(""));return ($availableSessions);}sub isRootless{if ((not (defined (
$GLOBAL::parameters{"\x72\x6f\x6f\x74\x6c\x65\x73\x73"})))){return (
(0x0161+ 6636-0x1b4d));}else{return ($GLOBAL::parameters{
"\x72\x6f\x6f\x74\x6c\x65\x73\x73"});}}sub sessionTypeTerminateOnSIGCHLD{(my $sessionType
=shift (@_));if (((((((((($sessionType eq $NXSessionType::virtualGnome)or (
$sessionType eq $NXSessionType::virtualVms))or ($sessionType eq 
$NXSessionType::virtualVnc))or ($sessionType eq $NXSessionType::virtualRDP))or (
$sessionType eq $NXSessionType::virtualKde))or ($sessionType eq 
$NXSessionType::virtualCde))or ($sessionType eq $NXSessionType::virtualDefault))
or ($sessionType eq $NXSessionType::nxFrameBuffer))or ($sessionType=~ /^xsession-/ )
)){return ((0x0740+ 6154-0x1f49));}if (($sessionType eq 
$NXSessionType::virtualApplicationDefault)){if ((not (isRootless ()))){return (
(0x0b91+ 4113-0x1ba1));}}return ((0x0ff4+ 1206-0x14aa));}sub getNXFrameBuffer{
return ($NXSessionType::nxFrameBuffer);}sub isNxFrameBuffer{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::nxFrameBuffer)){return (
(0x008c+ 8445-0x2188));}return ((0x0221+ 3553-0x1002));}sub 
isTypeWhichStoreApplicationPid{(my $sessionType=shift (@_));if ((((((
$sessionType eq $NXSessionType::physicalDesktop)or ($sessionType eq 
$NXSessionType::physicalAttachDesktop))or ($sessionType eq 
$NXSessionType::virtualXdm))or ($sessionType eq $NXSessionType::virtualAttach))
or ($sessionType eq $NXSessionType::nxConsole))){return ((0x0264+ 1453-0x0811));
}return ((0x1de6+ 458-0x1faf));}sub isSessionTypeNotCalculatedForLBScript{(my $sessionType
=shift (@_));if (((((((($sessionType eq $NXSessionType::connectionMonitor)or (
$sessionType eq $NXSessionType::nodeConnectionMonitor))or ($sessionType eq 
$NXSessionType::serverConnectionMonitor))or ($sessionType eq 
$NXSessionType::physicalDesktop))or ($sessionType eq 
$NXSessionType::foreignDesktop))or ($sessionType eq 
$NXSessionType::foreignAttach))or ($sessionType eq 
$NXSessionType::customForeignMaster))){return ((0x10b7+ 4490-0x2240));}return (
(0x1ad3+ 2001-0x22a4));}sub isVirtualFamily{(my $sessionType=shift (@_));if ((
$sessionType eq $NXSessionType::virtualAttach)){return ((0x11d8+ 1378-0x1739));}
if (isVirtual ($sessionType)){return ((0x1acc+ 525-0x1cd8));}return (
(0x05b2+ 1532-0x0bae));}sub isNxConsoleFamily{(my $sessionType=shift (@_));if ((
($sessionType eq $NXSessionType::nxConsole)or ($sessionType eq 
$NXSessionType::nxConsoleShadow))){return ((0x01da+ 4235-0x1264));}return (
(0x1c1a+ 1103-0x2069));}sub isNxConsoleShadow{(my $sessionType=shift (@_));if ((
$sessionType eq $NXSessionType::nxConsoleShadow)){return ((0x1860+ 2259-0x2132))
;}return ((0x114d+ 4526-0x22fb));}sub isNxConsole{(my $sessionType=shift (@_));
if (($sessionType eq $NXSessionType::nxConsole)){return ((0x007d+ 6703-0x1aab));
}return ((0x0b62+ 6123-0x234d));}sub getNxConsoleShadow{return ($internal{
$NXSessionType::nxConsoleShadow});}sub getAutomaticRecording{return (
$NXSessionType::automaticRecording);}sub isAutomaticRecording{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::automaticRecording)){return (
(0x11e5+ 4440-0x233c));}return ((0x0fd1+ 5026-0x2373));}sub getXsessionTypes{
return ((""));}sub __setInternalAndExternalForFoundXSessions{(my $type=shift (@_
));(my $external=lc ($type));($internal{$type}=$external);($external{$external}=
$type);}sub isSystemXsession{(my $sessionType=shift (@_));if (($sessionType=~ /^xsession-/ )
){return ((0x0d24+ 5114-0x211d));}return ((0x0fe3+ 2583-0x19fa));}return (
(0x00c1+ 277-0x01d5));
