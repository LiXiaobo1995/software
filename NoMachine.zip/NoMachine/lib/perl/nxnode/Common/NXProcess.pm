############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXProcess;no warnings;($NXProcess::children={});(
$NXProcess::childrenData={});($NXProcess::finishedChildren={});(
$NXProcess::childFinishedWithSignal={});($NXProcess::childrenExitCallback={});(
$NXProcess::childrenErrorCallback={});($NXProcess::childrenToLeave={});(
$NXProcess::watchDogList={});($NXProcess::finishedWatchDogList={});(
$NXProcess::watchDogToLeaveList={});($NXProcess::watchDogAsSuperuser={});(
$NXProcess::errorNoProcessToWait=(-(0x0725+ 3080-0x132c)));(
$NXProcess::statusRunning=(0x0952+ 756-0x0c46));($NXProcess::statusExited=
(0x0570+ 4783-0x181e));($NXProcess::signalKill=(0x138b+ 417-0x1523));(
$NXProcess::signalTerm=(0x0198+ 4783-0x1438));($NXProcess::signalSegv=
(0x1139+ 401-0x12bf));($NXProcess::processTree=(0x036d+ 2318-0x0c7a));(
$NXProcess::noProcessTree=(0x0044+ 7369-0x1d0d));sub nxProcessCreate{(my $filename
=shift (@_));(my $command=shift (@_));(my $environment=shift (@_));(my $stdin=
shift (@_));(my $stdout=shift (@_));(my $stderr=shift (@_));(my $priority=shift 
(@_));my ($pid);my ($pidOrHandle);Logger::debug (((((((((((((((
"\x6e\x78\x50\x72\x6f\x63\x65\x73\x73\x43\x72\x65\x61\x74\x65\x3a\x20\x27".
$filename)."\x27\x20\x27").join ($",@$command))."\x27\x20\x27").join ($",
@$environment))."\x27\x20\x27\x46\x44\x23").$stdin)."\x27\x20\x27\x46\x44\x23").
$stdout)."\x27\x20\x27\x46\x44\x23").$stderr)."\x27\x20\x27").$priority)."\x27")
);($pidOrHandle=libnxh::NXProcessCreate ($filename,$command,$environment,$stdin,
$stdout,$stderr,$priority));if (($pidOrHandle==(-(0x0213+   2-0x0214)))){
Common::NXCore::reportErrorFromNXPL (((((((((((((((((
"\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x43\x72\x65\x61\x74\x65\x28".$filename).
"\x2c\x20").$command)."\x2c\x20").$environment)."\x2c\x20").$stdin)."\x2c\x20").
$stdout)."\x2c\x20").$stderr)."\x2c\x20").$priority).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$pidOrHandle)."\x2e"));return ((-(0x08f7+ 702-0x0bb4)));}($pid=
handleProcessHandle ($pidOrHandle));addChild ($pid);(my $commandLine=$filename);
foreach my $parameter (@$command){if (($parameter eq $filename)){next;}else{(
$commandLine.=("\x20".$parameter));}}registerChildName ($commandLine,$pid);
return ($pid);}sub nxProcessExec{(my $filename=shift (@_));(my $command=shift (
@_));(my $environment=shift (@_));(my $ref_error=shift (@_));Logger::debug (((((
(("\x6e\x78\x50\x72\x6f\x63\x65\x73\x73\x45\x78\x65\x63\x3a\x20\x27".$filename).
"\x27\x20\x27").join ($",@$command))."\x27\x20\x27").join ($",@$environment)).
"\x27"));(my $result=libnxh::NXProcessExec ($filename,$command,$environment));if
 (($result==(-(0x054b+ 5731-0x1bad)))){Common::NXCore::reportErrorFromNXPL (((((
(((("\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x45\x78\x65\x63\x28".$filename).
"\x2c\x20").$command)."\x2c\x20").$environment).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$result)."\x2e"));($$ref_error=libnxh::NXGetErrorString ());return (
(0x08ec+ 5250-0x1d6e));}return ((0x044b+ 1322-0x0974));}sub handleProcessHandle{
(my $pidOrHandle=shift (@_));(my $pid=getPidFromHandle ($pidOrHandle));(
$NXProcess::processPidsArrayByHandle{$pidOrHandle}=$pid);(
$NXProcess::processHandlesArrayByPid{$pid}=$pidOrHandle);return ($pid);}sub 
getPidFromHandle{(my $handle=shift (@_));(my $pid=libnxh::NXConvertHandlerToPid 
($handle));Logger::debug (((((
"\x67\x65\x74\x50\x69\x64\x46\x72\x6f\x6d\x48\x61\x6e\x64\x6c\x65\x3a\x20\x68\x61\x6e\x64\x6c\x65\x20\x5b"
.$handle).
"\x5d\x20\x63\x6f\x6e\x76\x65\x72\x74\x65\x64\x20\x74\x6f\x20\x70\x69\x64\x20\x5b"
).$pid)."\x5d\x2e"));return ($pid);}sub convertToHandleIfNeeded{(my $pid=shift (
@_));if (defined ($NXProcess::processHandlesArrayByPid{$pid})){(my $handle=
$NXProcess::processHandlesArrayByPid{$pid});if (($pid==
$NXProcess::processPidsArrayByHandle{$handle})){return ($handle);}}return ($pid)
;}sub checkIsProcessFinished{(my $pid=shift (@_));if (($pid>
(0x17bd+ 2190-0x204b))){if ((not (isChildProcess ($pid)))){if (isChildFinished (
$pid)){return ((0x12c0+ 2641-0x1d10));}if ((not (isOnWatchdogProcess ($pid)))){
if (isFinishedWatchDog ($pid)){return ((0x0c7c+ 5539-0x221e));}return ((-
(0x04df+ 5931-0x1c09)));}}}if (($pid==(0x065a+ 474-0x0834))){return ((-
(0x1559+ 2524-0x1f34)));}return ((0x1064+ 2757-0x1b29));}sub 
checkForWaitingEventForPid{(my $pid=shift (@_));(my $childrenList=
$NXProcess::children);if (($pid==(-(0x04e1+ 8270-0x252e)))){foreach my $listpid 
(keys (%$childrenList)){if (isChildFinished ($listpid)){return ($listpid);}else{
next;}}return ((0x10c3+ 2706-0x1b55));}elsif (($pid>(0x06a6+ 6118-0x1e8c))){if (
isChildProcess ($pid)){if (isChildFinished ($pid)){return ($pid);}else{return (
(0x02e3+ 3450-0x105d));}}else{if (isChildFinished ($pid)){return ($pid);}if (
isFinishedWatchDog ($pid)){return ($pid);}if (isOnWatchdogProcess ($pid)){return
 ((0x1024+ 3566-0x1e12));}return ((-(0x1d8f+ 1429-0x2323)));}}return ((-
(0x0ecd+ 321-0x100d)));}sub nxwaitpid{(my $pid=shift (@_));(my $options=(shift (
@_)||$NXBits::WAIT_NOHANG));(my $timeout=(shift (@_)||"\x69\x6e\x66"));(my $startwaitpid
=Common::NXTime::getSecondsSinceEpoch ());(my $sigpid=(-(0x087a+ 1446-0x0e1f)));my (
$status);my ($nxplreturn);(my $finished=checkIsProcessFinished ($pid));if ((
$finished!=(0x0dd1+ 6419-0x26e4))){if (($finished==(-(0x0086+ 9142-0x243b)))){
return ((-(0x0646+ 873-0x09ae)));}return ($pid);}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);if (($options==$NXBits::WAIT_UNTRACED)){while ((0x165d+ 2272-0x1f3c))
{if (($timeout eq "\x69\x6e\x66")){Common::NXCore::exitFromSelectOnFirstSignal 
();(my (@ready)=$selector->can_read);
Common::NXCore::disableExitFromSelectOnFirstSignal ();}else{if (($timeout<=
(0x0886+ 5659-0x1ea1))){return ((0x1c96+ 1569-0x22b7));}
Common::NXCore::exitFromSelectOnFirstSignal ();(my (@ready)=$selector->can_read 
(($timeout *(0x0ae0+ 3616-0x1518))));
Common::NXCore::disableExitFromSelectOnFirstSignal ();($timeout=($timeout-(
Common::NXTime::getSecondsSinceEpoch ()-$startwaitpid)));}(my $check=
checkForWaitingEventForPid ($pid));if (((!$check)==(0x0a76+ 799-0x0d95))){return
 ($check);}}}else{(my (@ready)=$selector->can_read ((0x0242+ 6218-0x1a8c),
"\x73\x69\x6c\x65\x6e\x74"));(my $waitingEvent=checkForWaitingEventForPid ($pid)
);return ($waitingEvent);}}sub nxChildProcessCheck{(my $pid=shift (@_));(my $status
=(0x063f+ 315-0x077a));(my $exit=(0x04f5+ 416-0x0695));my ($nxplreturn);(my $pidToNxpl
=convertToHandleIfNeeded ($pid));($nxplreturn=libnxh::NXProcessCheck ($pidToNxpl
,$status));if (($nxplreturn==(-(0x0169+ 4614-0x136e)))){(my $errname=
libnxh::NXGetErrorName ());Logger::warning (((((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x28".$pid)
."\x2f").$pidToNxpl).
"\x29\x20\x77\x69\x74\x68\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27"
).$errname)."\x27\x2e"));}if (($nxplreturn==(0x0bb1+ 3999-0x1b50))){
setChildExitCode ($pid,$status);}return ($nxplreturn);}sub sigterm{Logger::error
 (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
);return ((0x1105+ 529-0x1316));(my $process_pid=shift (@_));if (
libnxh::NXProcessRunning ($process_pid)){my ($result);if (isChildProcess (
$process_pid)){Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($result=libnxh::NXProcessKill ($process_pid,$NXBITS::SIGTERM));}else{
Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x74\x20\x61\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($result=libnxh::NXKillProcess ($process_pid,$NXBITS::SIGTERM));}if (($result
==(-(0x0538+ 1669-0x0bbc)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid)."\x2e"));return ((0x0426+ 1132-0x0892));}else{Logger::debug (((((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
).$result)."\x2e"));return ((0x1b2b+ 1165-0x1fb7));}}Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x2c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x0992+ 6441-0x22ba));}sub winKillTreeProcess{(my $process=shift (@_
));(my $recursive=(shift (@_)||(0x01f4+ 8531-0x2346)));(my $timeout=(shift (@_)
||(0x016d+ 3720-0x0ff0)));(my (@command)=$GLOBAL::CommandNXService);push (
@command,"\x2d\x2d\x70\x72\x6f\x63\x65\x73\x73\x6b\x69\x6c\x6c");(my (
@parameters)=());push (@parameters,"\x74\x69\x6d\x65\x6f\x75\x74",$timeout);if (
($process=~ /^\d+$/ )){if (isProcessRunning ($process)){push (@command,
"\x2d\x2d\x70\x69\x64");push (@command,$process);if ($recursive){push (@command,
"\x2d\x2d\x72\x65\x63\x75\x72\x73\x69\x76\x65");}(my ($cmd_err,$cmd_out,
$exit_value)=main::run_command ((\@command),(\@parameters)));Logger::debug (((((
"\x45\x78\x65\x63\x75\x74\x65\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27".join 
($",@command))."\x27\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20").
$exit_value)."\x2e"));if (($exit_value!=(0x1241+ 4594-0x2433))){my (
$nxserviceVersion);if (Common::NXInfo::isArchitecture64Bit ()){(
$nxserviceVersion="\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x36\x34");}else{(
$nxserviceVersion="\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x33\x32");}Logger::error
 (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$process)."\x3a\x20").$nxserviceVersion).
"\x20\x2d\x2d\x70\x72\x6f\x63\x65\x73\x73\x6b\x69\x6c\x6c\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20"
).$exit_value)."\x2e"));return ((0x01f9+ 6494-0x1b57));}return (
(0x0097+ 3830-0x0f8c));}}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$process)."\x2e"));return ((0x0ff4+ 5582-0x25c2));}return (
(0x0b28+ 5347-0x200a));}sub sigkill{(my $process_pid=shift (@_));(my $process_tree
=(shift (@_)||(0x12b4+ 1500-0x1890)));if ((not (defined ($process_pid)))){
Logger::warning (
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x62\x75\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x70\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);return ((0x23dc+ 785-0x26ed));}if ((($process_pid==(0x0bd6+ 1684-0x126a))or (
$process_pid==$ $))) {
 main::nxexit (getSignalKill ());}if (($process_tree==
(0x08da+ 2913-0x143a))){(my $killProcess=winKillTreeProcess ($pid));return (
$killProcess);}(my $pidToNxpl=convertToHandleIfNeeded ($process_pid));(my $status
=isProcessRunning ($process_pid));if ($status){my ($return);if (isChildProcess (
$process_pid)){Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($return=libnxh::NXProcessKill ($pidToNxpl,getSignalKill ()));}else{if ((
$process_tree==(0x03b7+ 7476-0x20eb))){Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x74\x20\x61\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($return=libnxh::NXKillProcess ($process_pid,getSignalKill ()));}else{
Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x74\x72\x65\x65\x2e"
));($return=libnxh::NXKillTree ($process_pid,getSignalKill ()));}}if (($return==
(-(0x0111+ 2009-0x08e9)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid)."\x2e"));return ((0x04d2+ 6298-0x1d6c));}else{Logger::debug (((((
(("\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".
$process_pid)."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
).$return)."\x2e"));return ((0x1ae2+ 2465-0x2482));}}else{Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));}return ((0x088d+ 7545-0x2605));}sub signalProcessByRestrictedScript{(my $pid
=shift (@_));(my $signal=shift (@_));(my $tree=shift (@_));Logger::warning (
"\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x73\x69\x67\x6e\x61\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x73\x63\x72\x69\x70\x74\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x2e"
);return ((0x0d17+ 4728-0x1f8f));(my $nxkillScript=
"\x6e\x78\x6b\x69\x6c\x6c\x2e\x73\x68");(my (@command)=(
Common::NXCore::getNXExecCommand (),$nxkillScript,$pid,$signal,$tree));(my (
@parameters)=());main::run_command ((\@command),(\@parameters));}sub 
sendTerminateWaitAndKill{();}sub leaveOrphans{foreach my $pid (keys (
%$NXProcess::childrenToLeave)){(my $pidToNxpl=convertToHandleIfNeeded ($pid));(my $result
=libnxh::NXForceRemove ($pidToNxpl));if (($result==(-(0x15c1+ 3640-0x23f8)))){
Common::NXCore::reportErrorFromNXPL (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x66\x6f\x72\x63\x65\x20\x72\x65\x6d\x6f\x76\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid)."\x2f").$pidToNxpl)."\x2e"));}else{Logger::debug (((((
"\x4c\x65\x66\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$pid)."\x2f").$pidToNxpl)
."\x20\x61\x73\x20\x6f\x72\x70\x68\x61\x6e\x2e"));}}foreach my $pid (keys (
%$NXProcess::watchDogList)){(my $result=libnxh::NXRemoveWatchdog ($pid));if ((
$result==(-(0x16a0+ 3449-0x2418)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x6f\x6e\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid)."\x2e"));}else{Logger::debug (((((
"\x52\x65\x6d\x6f\x76\x65\x64\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x6f\x6e\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid)."\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x27").$result).
"\x27\x2e"));}}}sub leaveChildAtFinish{(my $pid=shift (@_));if (isChildProcess (
$pid)){Logger::debug (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x63\x68\x69\x6c\x64\x20".$pid).
"\x20\x74\x6f\x20\x62\x65\x20\x6c\x65\x66\x74\x20\x61\x66\x74\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x65\x6e\x64\x73\x2e"
));($$NXProcess::childrenToLeave{$pid}=(0x0a74+ 5305-0x1f2c));}}sub 
leaveWatchdogAtFinish{(my $pid=shift (@_));($$NXProcess::watchDogToLeaveList{
$pid}=(0x09d5+ 5090-0x1db6));}sub removeFromLeaveWatchdogAtFinishList{(my $pid=
shift (@_));delete ($$NXProcess::watchDogToLeaveList{$pid});}sub 
addToWatchDogList{(my $pid=shift (@_));($$NXProcess::watchDogList{$pid}=
(0x043a+ 3829-0x132e));delete ($$NXProcess::finishedWatchDogList{$pid});}sub 
handleWatchDogSIG{foreach my $pid (keys (%$NXProcess::watchDogList)){
Logger::debug3 (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x2e"));if ((not (libnxh::NXProcessRunning ($pid)))){Logger::debug (
(("\x4e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));
(my $callback=$$NXProcess::childrenExitCallback{$pid});Logger::debug (((((
"\x45\x78\x65\x63\x75\x74\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27").$pid
)."\x2e\x27"));delete ($$NXProcess::watchDogList{$pid});libnxh::NXRemoveWatchdog
 ($pid);($$NXProcess::finishedWatchDogList{$pid}=(0x1078+ 4051-0x204a));if ((
$callback ne (""))){&{$callback;}($pid,(0x05e5+ 649-0x086e));}}}}sub 
setCallbackSIGCHLD{(my $pid=shift (@_));(my $callback=shift (@_));(
$$NXProcess::childrenExitCallback{$pid}=$callback);(
$$NXProcess::childrenErrorCallback{$pid}=$callback);if (((not (isChildProcess (
$pid)))and (not (isOnWatchdogProcess ($pid))))){addToWatchDogList ($pid);}
Logger::debug2 ((((("\x4e\x65\x77\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x5b".
$$NXProcess::childrenExitCallback{$pid}).
"\x5d\x20\x66\x6f\x72\x20\x53\x49\x47\x43\x48\x49\x4c\x44\x20\x66\x6f\x72\x20\x70\x69\x64\x20\x5b"
).$pid)."\x5d"));}sub setExitCallback{(my $pid=shift (@_));(my $callback=shift (
@_));($$NXProcess::childrenExitCallback{$pid}=$callback);}sub setErrorCallback{(my $pid
=shift (@_));(my $callback=shift (@_));($$NXProcess::childrenErrorCallback{$pid}
=$callback);}sub addWatchdog{(my $pid=shift (@_));if (((not (defined ($pid)))or 
($pid==(0x10a5+ 4824-0x237d)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));return ((-(0x0450+ 6564-0x1df3)));}if (isOnWatchdogProcess (
$pid)){Logger::warning ((("\x50\x72\x6f\x63\x65\x73\x73\x20\x50\x49\x44\x20\x27"
.$pid).
"\x27\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x6f\x6e\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x6c\x69\x73\x74\x2e"
));return ((0x2354+  80-0x23a4));}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x57\x61\x74\x63\x68\x64\x6f\x67\x28"
.$pid)."\x2c\x20").$NXBITS::SIGCHLD)."\x29\x2e"));(my $result=
libnxh::NXAddWatchdog ($pid,$NXBITS::SIGCHLD));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x57\x61\x74\x63\x68\x64\x6f\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));addToWatchDogList ($pid);setCallbackSIGCHLD ($pid,(
\&nxDefaultWatchdogExitHandler));return ((0x0f60+ 4222-0x1fde));}sub addChild{(my $pid
=(shift (@_)||(0x0bd1+ 1139-0x1044)));if (($pid<=(0x0425+ 808-0x074d))){
Logger::warning (((
"\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x77\x72\x6f\x6e\x67\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));return;}if ((not (isChildProcess ($pid)))){(my $pidToNxpl=
convertToHandleIfNeeded ($pid));(my $nxplreturn=libnxh::NXProcessAdd ($pidToNxpl
));($$NXProcess::children{$pid}=(0x1a17+  80-0x1a66));Logger::debug (((((
"\x41\x64\x64\x65\x64\x20\x27".$pid)."\x2f").$pidToNxpl).
"\x27\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x72\x65\x6e\x20\x6c\x69\x73\x74\x2e"))
;($$NXProcess::childrenExitCallback{$pid}=(\&nxDefaultExitCodeHandler));(
$$NXProcess::childrenErrorCallback{$pid}=(\&nxDefaultExitCodeHandler));(
$$NXProcess::childFinishedWithSignal{$pid}=(0x1615+ 958-0x19d3));if (
isChildFinished ($pid)){delete ($$NXProcess::finishedChildren{$pid});}if (
isFinishedWatchDog ($pid)){delete ($$NXProcess::finishedWatchDogList{$pid});}}
else{Logger::debug (((
"\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x73\x61\x6d\x65\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x20\x61\x73\x20\x63\x68\x69\x6c\x64\x2e"));}}sub 
nxDefaultExitCodeHandler{(my $pid=shift (@_));(my $code=shift (@_));
Logger::debug (((
"\x6e\x78\x44\x65\x66\x61\x75\x6c\x74\x45\x78\x69\x74\x43\x6f\x64\x65\x48\x61\x6e\x64\x6c\x65\x72\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x2e"));}sub 
nxDefaultWatchdogExitHandler{(my $pid=shift (@_));Logger::debug (((
"\x6e\x78\x44\x65\x66\x61\x75\x6c\x74\x57\x61\x74\x63\x68\x64\x6f\x67\x45\x78\x69\x74\x48\x61\x6e\x64\x6c\x65\x72\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x5b"
.$pid)."\x5d\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x2e"));}sub removechild{(my $pid
=shift (@_));if (isChildProcess ($pid)){Logger::debug (((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x52\x65\x6d\x6f\x76\x65\x28"
.$pid)."\x29"));(my $pidToNxpl=convertToHandleIfNeeded ($pid));(my $nxplreturn=
libnxh::NXProcessRemove ($pidToNxpl));if (($nxplreturn==(-(0x0433+ 6038-0x1bc8))
)){Common::NXCore::reportErrorFromNXPL (((
"\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x52\x65\x6d\x6f\x76\x65\x28".$pidToNxpl).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));}(my ($name,$lifetime)=
getChildNameAndLifetime ($pid));if (processTerminatedBySignal ($pid)){(my $exitSignal
=getChildExitSignal ($pid));if (($exitSignal!=$NXBITS::SIGTERM)){Logger::warning
 ((((((((((("\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x73\x69\x67\x6e\x61\x6c\x20"
).$exitSignal)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}else{Logger::debug (((((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x73\x69\x67\x6e\x61\x6c\x20"
).$exitSignal)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}}else{(my $exitCode=getChildExitCode (
$pid));if (($exitCode==(0x0519+ 5985-0x1c7a))){Logger::debug (((((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$exitCode)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}else{Logger::warning (((((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$exitCode)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}}delete ($$NXProcess::children{$pid});
}if (exists ($$NXProcess::childrenToLeave{$pid})){delete (
$$NXProcess::childrenToLeave{$pid});}}sub isProcessRunning{(my $pid=shift (@_));
if (((not (defined ($pid)))or ($pid<=(0x0918+ 2594-0x133a)))){return (
(0x0239+ 6494-0x1b97));}if (($pid==$ $)) {
 return ((0x044b+ 872-0x07b2));}if (
isChildProcess ($pid)){return ((0x0607+ 3299-0x12e9));}(my $pidToNxpl=
convertToHandleIfNeeded ($pid));(my $ret=libnxh::NXProcessRunning ($pidToNxpl));
if (($ret==(-(0x1434+ 3868-0x234f)))){(my $errname=libnxh::NXGetErrorName ());if
 ((($errname eq "\x45\x41\x43\x43\x45\x53")or ($errname eq 
"\x45\x50\x45\x52\x4d"))){return ((0x0138+ 1129-0x05a0));}Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x52\x75\x6e\x6e\x69\x6e\x67\x28"
.$pid)."\x2f").$pidToNxpl)."\x29\x20\x3a\x20").$errname));return (
(0x0bbb+ 4516-0x1d5f));}return ($ret);}sub handleSIGUSR1{Logger::debug (
"\x68\x61\x6e\x64\x6c\x65\x53\x49\x47\x55\x53\x52\x31",(0x0faa+ 3722-0x1e34));if
 (defined ($NXBegin::handlerSIGUSR1)){if (($NXBegin::handlerSIGUSR1 ne (""))){
Logger::debug (("\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x3a\x20".
$NXBegin::handlerSIGUSR1),(0x0f93+ 1014-0x1389));&$NXBegin::handlerSIGUSR1 ();}}
else{Logger::debug ("\x49\x67\x6e\x6f\x72\x69\x6e\x67\x20\x55\x53\x52\x31",
(0x05cb+ 398-0x0759));}}sub handleSIGCHLD{(my $children=$NXProcess::children);my (
$status);my ($nxplreturn);foreach my $listpid (keys (%$children)){Logger::debug3
 ((
"\x68\x61\x6e\x64\x6c\x65\x53\x49\x47\x43\x48\x4c\x44\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x63\x68\x69\x6c\x64\x3a\x20"
.$listpid),(0x0399+ 7894-0x226f));($nxplreturn=nxChildProcessCheck ($listpid));
unless ($nxplreturn){removechild ($listpid);my ($callback);if ((
$$NXProcess::finishedChildren{$listpid}==(0x0e24+ 4316-0x1f00))){($callback=
$$NXProcess::childrenExitCallback{$listpid});}else{($callback=
$$NXProcess::childrenErrorCallback{$listpid});}&{$callback;}($listpid,
$$NXProcess::finishedChildren{$listpid});}}handleWatchDogSIG ();
handleWatchdogAsSuperuserSIGCHLD ();}sub getExitValue{(my $pid=shift (@_));(my $exitValue
=$$NXProcess::finishedChildren{$pid});if ((not (defined ($exitValue)))){if ((not
 (isChildProcess ($pid)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid).
"\x2e\x20\x54\x68\x69\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));return ((0x0d8a+ 4583-0x1f71));}else{Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid).
"\x2e\x20\x50\x72\x6f\x63\x65\x73\x73\x20\x73\x74\x69\x6c\x6c\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x1a1a+ 207-0x1ae9));}}return ($exitValue);}sub isChildProcess{(my $pid
=shift (@_));if (exists ($$NXProcess::children{$pid})){return (
(0x1b14+ 2191-0x23a2));}else{return ((0x1568+ 2187-0x1df3));}}sub 
isOnWatchdogProcess{(my $pid=shift (@_));if (exists ($$NXProcess::watchDogList{
$pid})){return ((0x0120+  80-0x016f));}else{return ((0x0f59+ 1010-0x134b));}}sub
 isChildFinished{(my $pid=shift (@_));if (exists ($$NXProcess::finishedChildren{
$pid})){return ((0x09d2+ 3375-0x1700));}else{return ((0x090b+ 6441-0x2234));}}
sub isFinishedWatchDog{(my $pid=shift (@_));if (exists (
$$NXProcess::finishedWatchDogList{$pid})){return ((0x1a32+ 1962-0x21db));}else{
return ((0x0126+ 1106-0x0578));}}sub processTerminatedBySignal{(my $pid=shift (
@_));if (($$NXProcess::childFinishedWithSignal{$pid}==(0x164a+ 2796-0x2135))){
return ((0x1017+ 3177-0x1c7f));}else{return ((0x0054+ 8312-0x20cc));}}sub 
waitProcessDontEndWin32{(my $pid=shift (@_));(my $timeout=shift (@_));(my $timeoutMs
=(0x0d68+ 4963-0x20cb));(my $timeStart=Common::NXTime::getSecondsSinceEpoch ());
if (($timeout eq "\x69\x6e\x66")){Logger::debug (((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid).
"\x27\x20\x75\x73\x69\x6e\x67\x20\x69\x6e\x66\x69\x6e\x69\x74\x65\x20\x61\x73\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
));}else{Logger::debug (((((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x20\x75\x73\x69\x6e\x67\x20").$timeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x73\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
));}if (((not (isChildProcess ($pid)))and (not (isOnWatchdogProcess ($pid))))){
if ((not (isProcessRunning ($pid)))){return ((0x01cf+ 2663-0x0c36));}if ((
$timeout==(0x069f+ 4096-0x169f))){return ((0x0a14+  39-0x0a3a));}Logger::debug (
((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x3a\x20\x70\x69\x64\x20\x5b"
.$pid).
"\x5d\x20\x69\x73\x20\x6e\x6f\x74\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x65\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2c\x20\x61\x64\x64\x69\x6e\x67\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x2e"
));addWatchdog ($pid);}(my $result=nxwaitpid ($pid,$NXBits::WAIT_UNTRACED,
$timeout));if (($result==$pid)){return ((0x0d42+ 3676-0x1b9e));}else{return (
(0x0a6b+ 4303-0x1b39));}}sub waitProcessForceEndWin32{(my $pid=shift (@_));(my $timeout
=shift (@_));(my $handle=shift (@_));(my $treeProcess=(shift (@_)||
(0x2343+ 835-0x2686)));if (waitProcessDontEndWin32 ($pid,$timeout)){(my $killProcess
=(0x0d6f+ 3523-0x1b32));if ((not ($treeProcess))){($killProcess=sigkill ($pid));
}else{($killProcess=winKillTreeProcess ($pid));}if ((not ($killProcess))){
Logger::error (((
"\x46\x6f\x72\x63\x65\x20\x6b\x69\x6c\x6c\x20\x66\x61\x69\x6c\x65\x64\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));return ((-(0x0e69+ 213-0x0f3d)));}Logger::debug2 (((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid).
"\x27\x20\x6b\x69\x6c\x6c\x65\x64\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6f\x66\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
));}(my $exitValue=getExitValue ($pid));return ($exitValue);}sub waitProcess{
return (waitProcessForceEndWin32 (@_));}sub getErrorNoProcessToWait{return (
$NXProcess::errorNoProcessToWait);}sub getStatusRunning{return (
$NXProcess::statusRunning);}sub getStatusExited{return ($NXProcess::statusExited
);}sub getSignalKill{return ($NXProcess::signalKill);}sub getSignalTerm{return (
$NXProcess::signalTerm);}sub getSignalSegv{return ($NXProcess::signalSegv);}sub 
getProcessTree{return ($NXProcess::processTree);}sub getNoProcessTree{return (
$NXProcess::noProcessTree);}sub registerChildName{(my $processName=shift (@_));(my $processPid
=shift (@_));(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,(0x00fb+ 512-0x02fb),
(0x0f91+ 774-0x1294)));Logger::debug2 (((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$processName).
"\x27\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20\x27"
).$processPid).
"\x27\x20\x61\x74\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27").$sec)."\x2c"
).$milisec)."\x27"));($$NXProcess::childrenData{$processPid}={});(
$$NXProcess::childrenData{$processPid}{"\x6e\x61\x6d\x65"}=$processName);(
$$NXProcess::childrenData{$processPid}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"}=$sec);(
$$NXProcess::childrenData{$processPid}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"}=$milisec);}
sub getChildNameAndLifetime{(my $pid=shift (@_));(my $childData=
$$NXProcess::childrenData{$pid});if (defined ($childData)){(my $name=$$childData
{"\x6e\x61\x6d\x65"});(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,(0x07eb+ 1727-0x0eaa),
(0x1770+ 1870-0x1ebb)));(my $startSeconds=$$NXProcess::childrenData{$pid}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"});(my $startMiliseconds=
$$NXProcess::childrenData{$pid}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"});(my $liveTimeSeconds
=($sec-$startSeconds));(my $liveTimeMiliseconds=($milisec-$startMiliseconds));if
 (($liveTimeMiliseconds<(0x0fe0+ 4771-0x2283))){($liveTimeMiliseconds=(
$liveTimeMiliseconds+(0x08af+ 4157-0x1504)));($liveTimeSeconds=($liveTimeSeconds
-(0x1b12+ 345-0x1c6a)));}(my $liveTime=(($liveTimeSeconds."\x2c").sprintf (
"\x25\x30\x33\x64",$liveTimeMiliseconds)));return ($name,$liveTime);}return (
(""),(0x1cc0+ 845-0x200d));}sub waitToTerminateOrKillIfStayAlive{(my $processPid
=shift (@_));(my $sleepTime=shift (@_));if (((not (defined ($processPid)))or (
$processPid<(0x07eb+ 1935-0x0f7a)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x61\x69\x74\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x6f\x72\x20\x6b\x69\x6c\x6c\x20\x69\x66\x20\x73\x74\x61\x79\x20\x61\x6c\x69\x76\x65\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x50\x49\x44\x2e"
);return;}if (((not (defined ($sleepTime)))or ($sleepTime<(0x01f7+ 5690-0x1830))
)){($sleepTime=(0x195d+ 2276-0x2240));}if (isProcessRunning ($processPid)){
nxwaitpid ($processPid,$NXBits::WAIT_UNTRACED,$sleepTime);if (isProcessRunning (
$processPid)){if (sigkill ($processPid)){Logger::debug (((
"\x53\x49\x47\x4b\x49\x4c\x4c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}}}else{Logger::debug (((
"\x43\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$processPid).
"\x27\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
));}}sub waitToTerminateOrKillByScriptIfStayAlive{(my $processPid=shift (@_));(my $sleepTime
=shift (@_));if (((not (defined ($processPid)))or ($processPid<
(0x1434+ 4155-0x246f)))){Logger::warning (
"\x77\x61\x69\x74\x54\x6f\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x4f\x72\x4b\x69\x6c\x6c\x42\x79\x53\x63\x72\x69\x70\x74\x49\x66\x53\x74\x61\x79\x41\x6c\x69\x76\x65\x3a\x20\x70\x69\x64\x20\x6e\x6f\x74\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e"
);return;}if (((not (defined ($sleepTime)))or ($sleepTime<(0x0a18+ 621-0x0c84)))
){($sleepTime=(0x09db+ 6481-0x232b));}if (isProcessRunning ($processPid)){(my $waitpid
=nxwaitpid ($processPid,$NXBits::WAIT_UNTRACED,$sleepTime));if (($waitpid!=
$processPid)){Logger::warning (((((
"\x77\x61\x69\x74\x54\x6f\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x4f\x72\x4b\x69\x6c\x6c\x42\x79\x53\x63\x72\x69\x70\x74\x49\x66\x53\x74\x61\x79\x41\x6c\x69\x76\x65\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid).
"\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x77\x69\x74\x68\x69\x6e\x20"
).$sleepTime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x62\x79\x20\x72\x65\x73\x74\x72\x69\x63\x74\x65\x64\x20\x73\x63\x72\x69\x70\x74\x2e"
));signalProcessByRestrictedScript ($processPid,getSignalKill ());}}else{
Logger::debug (((
"\x77\x61\x69\x74\x54\x6f\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x4f\x72\x4b\x69\x6c\x6c\x42\x79\x53\x63\x72\x69\x70\x74\x49\x66\x53\x74\x61\x79\x41\x6c\x69\x76\x65\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
));}}sub addWatchdogAsSuperuserOnWindows{(my $pid=shift (@_));(my $handle=
Common::NXCore::convertProcessPidToHandleAsSuperuser ($pid));if (($handle!=(-
(0x03fb+ 6286-0x1c88)))){Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x68\x61\x6e\x64\x6c\x65\x20\x27".$handle).
"\x27\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6c\x69\x73\x74\x2e"));(my $return
=libnxh::NXAddProcess ($handle));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x50\x72\x6f\x63\x65\x73\x73\x28"
.$handle)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$return).
"\x27\x2e"));if (($return==(-(0x07a9+ 1515-0x0d93)))){
Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x68\x61\x6e\x64\x6c\x65\x20\x27".
$handle).
"\x27\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6c\x69\x73\x74\x2e"));}
else{addProcessToWatchdogAsSuperuserList ($pid,$handle);}return ($return);}
return ((-(0x0f86+ 1460-0x1539)));}sub addProcessToWatchdogAsSuperuserList{(my $pid
=shift (@_));(my $handle=shift (@_));($$NXProcess::watchDogAsSuperuser{$pid}=
$handle);delete ($$NXProcess::finishedWatchDogList{$pid});}sub 
handleWatchdogAsSuperuserSIGCHLD{foreach my $pid (keys (
%$NXProcess::watchDogAsSuperuser)){(my $handle=$$NXProcess::watchDogAsSuperuser{
$pid});Logger::debug3 (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x20\x77\x69\x74\x68\x20\x68\x61\x6e\x64\x6c\x65\x20\x27").$handle).
"\x27\x2e"));if ((not (libnxh::NXProcessRunning ($pid)))){Logger::debug (((
"\x4e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27".
$pid)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));(my $callback
=$$NXProcess::childrenExitCallback{$pid});Logger::debug (((((
"\x45\x78\x65\x63\x75\x74\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27").$pid
)."\x27\x2e"));delete ($$NXProcess::watchDogAsSuperuser{$pid});Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x68\x61\x6e\x64\x6c\x65\x20\x27".$handle).
"\x27\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6c\x69\x73\x74\x2e"));(my $return
=libnxh::NXRemoveProcess ($handle));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x52\x65\x6d\x6f\x76\x65\x50\x72\x6f\x63\x65\x73\x73\x28"
.$handle)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$return).
"\x27\x2e"));if (($return==(-(0x0f15+ 5374-0x2412)))){
Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x68\x61\x6e\x64\x6c\x65\x20\x27"
.$handle).
"\x27\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6c\x69\x73\x74\x2e"
));}($$NXProcess::finishedWatchDogList{$pid}=(0x103d+ 4758-0x22d2));if ((
$callback ne (""))){&{$callback;}($pid,(0x157b+  17-0x158c));}}}}sub 
setChildExitCode{(my $pid=shift (@_));(my $code=shift (@_));(
$$NXProcess::finishedChildren{$pid}=$code);}sub getChildExitCode{(my $pid=shift 
(@_));if ((not (processTerminatedBySignal ($pid)))){return (
$$NXProcess::finishedChildren{$pid});}return (undef);}sub setChildExitSignal{(my $pid
=shift (@_));(my $sig=shift (@_));($$NXProcess::finishedChildren{$pid}=$sig);(
$$NXProcess::childFinishedWithSignal{$pid}=(0x0a15+ 4707-0x1c77));}sub 
getChildExitSignal{(my $pid=shift (@_));if (processTerminatedBySignal ($pid)){
return ($$NXProcess::finishedChildren{$pid});}return (undef);}sub 
getChildrenOfProcess{(my $pid=shift (@_));(my $commandPath=
Common::NXShellCommands::getPath ("\x70\x73"));if (($commandPath eq 
$Common::NXShellCommands::pathNotFound)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x63\x68\x69\x6c\x64\x72\x65\x6e\x20\x6f\x66\x20\x27"
.$pid).
"\x27\x2e\x20\x50\x72\x6f\x67\x72\x61\x6d\x20\x27\x70\x73\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x70\x72\x65\x73\x65\x6e\x74\x20\x69\x6e\x20\x61\x20\x6b\x6e\x6f\x77\x6e\x20\x70\x61\x74\x68\x2e"
));return (());}(my (@command)=());(my (@options)=());push (@command,
$commandPath);push (@command,"\x2d\x2d\x70\x70\x69\x64",$pid);push (@command,
"\x2d\x6f");push (@command,"\x70\x69\x64\x3d");(my ($stderr,$stdout,$exitValue)=
main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x0af4+ 5941-0x2229))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x63\x68\x69\x6c\x64\x72\x65\x6e\x20\x6f\x66\x20\x27"
.$pid)."\x27\x2e"));return (());}($stdout=~ s/^\s+|\s+$//g );(my (@pids)=split ( /\s+/ ,
$stdout,(0x0ab8+ 2074-0x12d2)));return (@pids);}"\x3f\x3f\x3f";
