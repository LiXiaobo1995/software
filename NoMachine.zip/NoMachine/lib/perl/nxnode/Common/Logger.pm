############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}package 
Logger;no warnings;require Common::NXFile;($debugMode=
"\x64\x69\x73\x61\x62\x6c\x65");($flagPrintProcessNamesToErrorsAndWarnings=
(0x12fd+ 3552-0x20dd));(my $__whoami=
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67");sub main::BEGIN{package main;
require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
BEGIN{require Common::NXTime;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x54\x69\x6d\x65"->import};}sub BEGIN{
require NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->import};}(my (
%__no_log_packages)=());(my $__failed_systemlogfile=(0x0068+ 3480-0x0e00));(my $__previousLogMessage
=(""));(my $__previousLogMessageCount=(0x065b+ 7094-0x2211));(my $__previousStatusMessage
=(""));(my $__previousStatusMessageCount=(0x12f5+ 3886-0x2223));(my $__doNotStoreInHistory
=(0x0316+ 2003-0x0ae9));(my $__storeInHistory=(0x111a+ 2435-0x1a9c));(
@statusDumpBeginPart=());(@statusDumpEndPart=());($loggerWorking=
(0x1a5f+ 369-0x1bcf));($LOG_ERROR=(0x03ff+ 8251-0x2437));($LOG_WARNING=
(0x0a88+ 2017-0x1265));($LOG_NOTICE=(0x1855+ 860-0x1bac));($LOG_INFO=
(0x0aad+ 703-0x0d66));($LOG_DEBUG=(0x04c1+ 8287-0x2519));($LOG_DEBUG2=
(0x0441+ 5892-0x1b3d));($LOG_DEBUG3=(0x0029+ 7239-0x1c67));(my $__level=
$LOG_INFO);sub init{(($__whoami,$__level)=@_);($__failed_systemlogfile=
(0x0860+ 4322-0x1942));openLog ();setLoggerInfo ();(my $message=((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x20\x77\x69\x74\x68\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x27"
.NXBegin::getProcessArgumentsString ())."\x27\x2e"));debug ($message);statusPush
 ($message);}sub initLevel{(my $variables=libnxh::NXInitSyslogConstants ());(
$LOG_ERROR=@$variables[(0x0402+ 220-0x04de)]);($LOG_WARNING=@$variables[
(0x061b+ 2887-0x1161)]);($LOG_NOTICE=@$variables[(0x0074+ 9513-0x259b)]);(
$LOG_INFO=@$variables[(0x1513+ 666-0x17aa)]);($LOG_DEBUG=@$variables[
(0x03db+ 4880-0x16e7)]);($LOG_DEBUG2=@$variables[(0x05a3+ 3745-0x143f)]);(
$LOG_DEBUG3=@$variables[(0x1dc1+ 895-0x213a)]);($__level=$LOG_INFO);}sub openLog
{if (syslogEnabled ()){__openSyslog ();}else{__openLogFile ();}}sub reopenLog{(my $logFile
=shift (@_));if ((not (syslogEnabled ()))){debug (((
"\x53\x77\x69\x74\x63\x68\x69\x6e\x67\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x74\x6f\x20\x27"
.$logFile)."\x27\x2e"));(my $handle=$logfile_fh);__openLogFile ($logFile);if (
defined ($handle)){__redirectDefaultStdoutToNewLogFileIfNeeded ($handle,
$logfile_fh);main::nxclose ($handle);}}}sub 
__redirectDefaultStdoutToNewLogFileIfNeeded{(my $oldHandle=shift (@_));(my $newHandle
=shift (@_));}sub disablePackage{($Logger::__no_log_packages{$_[
(0x03b0+ 8329-0x2439)]}="\x31");}sub __statusPush{(my $message=shift (@_));(my $line
=getFormattedLogLine ($message));if ((scalar (@statusDumpBeginPart)>=
(0x0ddf+ 2081-0x15ce))){(my $length=push (@statusDumpEndPart,$line));if ((
$length>(0x0a31+ 232-0x0ae7))){shift (@statusDumpEndPart);}}else{push (
@statusDumpBeginPart,$line);}}sub statusPush{(my $message=shift (@_));if (
__suppressStatusDump ($message)){return;}__statusPush ($message);}sub 
statusPushError{(my $message=shift (@_));($message=setMessageType ($message,
$LOG_ERROR));statusPush ($message);}sub statusPushWarning{(my $message=shift (@_
));($message=setMessageType ($message,$LOG_WARNING));statusPush ($message);}sub 
statusReset{($__status=(""));}sub statusGet{(my $statusStr=join ((""),
@statusDumpBeginPart));if (scalar (@statusDumpEndPart)){($statusStr.=
"\x0a\x73\x6b\x69\x70\x70\x69\x6e\x67\x20\x2e\x2e\x2e\x0a\x0a");($statusStr.=
join ((""),@statusDumpEndPart));}return ($statusStr);}sub printStatus{(my ($msg,
$statusId,@status)=@_);main::nxwrite (main::nxgetSTDOUT (),((($msg."\x20\x5b").
$statusId)."\x5d\x0a"));while ((my $msg=shift (@status))){($msg=~ s/\n$//gm );(
$msg=~ s/\n/\n        /g );main::nxwrite (main::nxgetSTDOUT (),((
"\x20\x20\x20\x20".$msg)."\x0a"));}}sub logStatus{(my ($level,@msgs)=@_);(my (
$statusId,@status)=statusGet ());multilineLog ($statusId,@msgs,@status);return (
$statusId,@status);}sub __log{(my ($msg,$level,$storeInHistory)=@_);(my (
$package,$filename,$line,$sub)=caller ((0x2271+ 326-0x23b5)));if ((not (defined 
($level)))){main::nxwrite (main::nxgetSTDERR (),((((((((((
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x6c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x66\x72\x6f\x6d\x3a\x20\x28"
.$package)."\x2c\x20").$filename)."\x2c\x20").$line)."\x2c\x20").$sub).
"\x29\x20\x61\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20").$msg)."\x0a"));
return;}if (($__level<$level)){if (($storeInHistory==(0x04a8+ 7352-0x215f))){
storeInHistory ($msg,$level);}return;}if ((not (defined ($GLOBAL::CONFIG_FILE)))
){if (($level==$LOG_ERROR)){main::nxwrite (main::nxgetSTDERR (),($msg."\x0a"));}
return;}(my $logpackage=$package);($logpackage=~ s/^Common::// );if (defined (
$Logger::__no_log_packages{$logpackage})){if ((($level!=$LOG_ERROR)and ($level!=
$LOG_WARNING))){return;}}writeMessageToLog ($msg,$level,$storeInHistory,$sub);}
sub __multilineEntry{(my ($statusId,$level,$store,@msgs)=@_);if ((not (defined (
$statusId)))){warning (
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6d\x75\x6c\x74\x69\x6c\x69\x6e\x65\x45\x6e\x74\x72\x79\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x73\x74\x61\x74\x75\x73\x49\x64\x2e"
);return;}if ((not (@msgs))){warning (
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6d\x75\x6c\x74\x69\x6c\x69\x6e\x65\x45\x6e\x74\x72\x79\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);return;}foreach my $line (@msgs){__log (((("\x3c".$statusId)."\x3e\x20").$line
),$level,$store);}}sub multilineLog{(my ($statusId,@msgs)=@_);__multilineEntry (
$statusId,$LOG_DEBUG,$__doNotStoreInHistory,@msgs);}sub multilineError{(my (
$statusId,@msgs)=@_);__multilineEntry ($statusId,$LOG_ERROR,$__storeInHistory,
@msgs);}sub isMessageDefined{(my $msg=shift (@_));if ((not (defined ($msg)))){
main::nxwrite (main::nxgetSTDERR (),
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x6d\x73\x67\x0a"
);main::nxexit ((0x09fc+ 7173-0x2601));}}sub isLevelDefined{(my $level=shift (@_
));if ((not (defined ($level)))){main::nxwrite (main::nxgetSTDERR (),
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x6c\x65\x76\x65\x6c\x0a"
);main::nxexit ((0x005b+ 332-0x01a6));}}sub isBacktraceDefined{(my ($backtrace,
$sub,$level)=@_);if ((not (defined ($backtrace)))){($sub=~ s/::__ANON__$/::Static/ )
;}return ($sub);}sub isDebugEnabled{return (($debugMode eq 
"\x65\x6e\x61\x62\x6c\x65"));}sub checkBacktrace{(my ($backtrace,$msg)=@_);
return;}sub setLoggerInfo{if ($GLOBAL::SessionLogLevel){($__level=
$GLOBAL::SessionLogLevel);}else{($__level=$LOG_INFO);}if ($GLOBAL::SOFTWARE_NAME
){($__whoami=$GLOBAL::SOFTWARE_NAME);}if (($GLOBAL::SessionLogLevel>
(0x0a9f+ 2004-0x126d))){($debugMode="\x65\x6e\x61\x62\x6c\x65");}}sub 
sendMessageToLogfile{(my ($msg,$level)=@_);if (defined ($logfile_fh)){(my $savedBytes
=libnxh::NXLogWrite ($logfile_fh,__getLogLine ($msg)));if (($savedBytes==(-
(0x0349+ 3931-0x12a3)))){(my $errorString=libnxh::NXGetErrorString ());
main::nxwrite (main::nxgetSTDERR (),((
"\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x6c\x6f\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27"
.$errorString)."\x27"));main::nxexit ((0x1360+ 1846-0x1a95));}}}sub __getLogLine
{(my $text=shift (@_));(my $timeline=Common::NXTime::getLoggerTimeline ());(my $pid
=$ $);
 (my $tid=$pid);(my $processName=sprintf ("\x25\x2d\x38\x73",$__whoami));
(my $message=((((((((($pid."\x20").$tid)."\x20").$timeline)."\x20").$processName
)."\x20").$text)."\x0a"));return ($message);}sub getFormattedLogLine{(my $text=
shift (@_));replaceSpecialCharacters ((\$text));return (__getLogLine ($text));}
sub setLogFile{(my $logfile=(""));($logfile=Common::NXPaths::getNXServerLogPath 
());if (($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){(my $logDir=
Common::NXPaths::getSpecialUsersLogFolderPath ());if ((not (-d ($logDir)))){(my $returnValue
=libnxh::NXMakePath ($logDir,("")));debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x0f88+ 5550-0x2536))){(my $errorNumber
=libnxh::NXGetError ());(my $errorMessage=libnxh::NXGetErrorString ());($success
=(0x045c+ 7222-0x2092));error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$logDir)."\x2e"));error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorMessage)."\x27\x2e"));}}}return ($logfile);}
sub setMessageType{(my ($msg,$level)=@_);if (($level==$LOG_ERROR)){($msg=(
"\x45\x52\x52\x4f\x52\x21\x20".$msg));}elsif (($level==$LOG_WARNING)){($msg=(
"\x57\x41\x52\x4e\x49\x4e\x47\x21\x20".$msg));}return ($msg);}sub stackTrace{(my $backtrace
=Carp::longmess ($_));($backtrace=~ s/\n[\s]+/\n/ );(my (@lines)=split ( /\n/ ,
$backtrace,(0x15b6+ 2102-0x1dec)));multilineLog (
"\x20\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x3a",@lines);return (());}sub 
logFilePath{return (Common::NXPaths::getNXServerLogPath ());}sub 
writeMessageToLog{(my ($msg,$level,$backtrace,$sub)=@_);($msg=prepareLogMessage 
($msg,$level));($sub=isBacktraceDefined ($backtrace,$sub,$level));($msg=
setMessageType ($msg,$level));if (syslogEnabled ()){sendMessageToSyslog ($msg,
$level);}else{if (__suppress ($msg,$level)){return;}sendMessageToLogfile ($msg,
$level);}return;}sub prepareLogMessage{(my ($msg,$level)=@_);
replaceSpecialCharacters ((\$msg));isMessageDefined ($msg);isLevelDefined (
$level);if (printProcessNamesToErrorsAndWarnings ()){if ((($level==$LOG_ERROR)or
 ($level==$LOG_WARNING))){(my $nameString=(("\x50\x72\x6f\x63\x65\x73\x73\x20".
NXBegin::getProcessName ())."\x20\x72\x65\x70\x6f\x72\x74\x65\x64\x3a\x20"));(
$msg=($nameString.$msg));}}return ($msg);}sub replaceSpecialCharacters{(my $ref_message
=shift (@_));chomp ($$ref_message);($$ref_message=~ s/%/%%/g );($$ref_message=~ s/\n/\\n/g )
;}sub storeInHistory{(my ($msg,$level)=@_);($msg=setMessageType ($msg,$level));
statusPush ($msg);}sub closeLogFile{if (syslogEnabled ()){libnxh::NXCloseLog ();
}else{if (defined ($logfile_fh)){main::nxclose ($logfile_fh);undef ($logfile_fh)
;}}}sub setLoggerNotWorking{($loggerWorking=(0x0774+ 1883-0x0ecf));}sub 
isLoggerWorking{return ($loggerWorking);}sub 
printProcessNamesToErrorsAndWarnings{return (
$flagPrintProcessNamesToErrorsAndWarnings);}sub debug{(my $message=shift (@_));(my $storeInHistory
=(shift (@_)||(0x0782+ 7466-0x24ac)));__log ($message,$LOG_DEBUG,$storeInHistory
);}sub debug2{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||
(0x04e4+ 1672-0x0b6c)));__log ($message,$LOG_DEBUG2,$storeInHistory);}sub debug3
{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||(0x16cd+ 1823-0x1dec)
));__log ($message,$LOG_DEBUG3,$storeInHistory);}sub info{(my $message=shift (@_
));(my $storeInHistory=(shift (@_)||(0x0138+ 7262-0x1d96)));__log ($message,
$LOG_INFO,$storeInHistory);}sub notice{(my $message=shift (@_));(my $storeInHistory
=(shift (@_)||(0x0ec8+ 2181-0x174d)));__log ($message,$LOG_NOTICE,
$storeInHistory);}sub warning{(my $message=shift (@_));(my $storeInHistory=(
shift (@_)||(0x0e58+ 2987-0x1a03)));__log ($message,$LOG_WARNING,$storeInHistory
);}sub error{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||
(0x0f1a+ 3926-0x1e70)));__log ($message,$LOG_ERROR,$storeInHistory);}sub 
connection{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||
(0x0677+ 1291-0x0b82)));if (($GLOBAL::EnableConnectionLog==(0x193d+ 2681-0x23b5)
)){__log ($message,$LOG_NOTICE,$storeInHistory);}else{__log ($message,$LOG_DEBUG
,$storeInHistory);}}sub getErrorLevel{return ($LOG_ERROR);}sub getInfoLevel{
return ($LOG_INFO);}sub getWarningLevel{return ($LOG_WARNING);}sub getDebugLevel
{return ($LOG_DEBUG);}sub getDebug2Level{return ($LOG_DEBUG2);}sub 
getDebug3Level{return ($LOG_DEBUG3);}sub getNoticeLevel{return ($LOG_NOTICE);}
sub isErrorLevel{(my $level=shift (@_));if (($level==$LOG_ERROR)){return (
(0x1b24+ 1357-0x2070));}else{return ((0x0172+ 6381-0x1a5f));}}sub isWarningLevel
{(my $level=shift (@_));if (($level==$LOG_WARNING)){return (
(0x1285+ 3275-0x1f4f));}else{return ((0x1e96+ 227-0x1f79));}}sub isInfoLevel{(my $level
=shift (@_));if (($level==$LOG_INFO)){return ((0x15e9+ 1990-0x1dae));}else{
return ((0x0d1a+ 1427-0x12ad));}}sub isDebugLevel{(my $level=shift (@_));if ((
$level==$LOG_DEBUG)){return ((0x1c63+ 651-0x1eed));}else{return (
(0x0d95+ 6467-0x26d8));}}sub isDebug2Level{(my $level=shift (@_));if (($level==
$LOG_DEBUG2)){return ((0x0504+ 3079-0x110a));}else{return ((0x1284+ 3133-0x1ec1)
);}}sub isDebug3Level{(my $level=shift (@_));if (($level==$LOG_DEBUG3)){return (
(0x08c4+ 2217-0x116c));}else{return ((0x1290+ 4428-0x23dc));}}sub isNoticeLevel{
(my $level=shift (@_));if (($level==$LOG_NOTICE)){return ((0x192d+ 2301-0x2229))
;}else{return ((0x19f4+ 707-0x1cb7));}}sub syslogEnabled{if ((
$GLOBAL::EnableSyslogSupport eq "\x31")){return ((0x0d08+ 189-0x0dc4));}else{
return ((0x0d39+ 3891-0x1c6c));}}sub __openSyslog{(my $moduletype=
NXBegin::getModuletype ());libnxh::NXOpenLog ($moduletype);}sub 
sendMessageToSyslog{(my ($msg,$level)=@_);libnxh::NXSysLog ($msg,$level);}sub 
__openLogFile{(my $logFile=(shift (@_)||("")));unless (isLoggerWorking ()){
return ((0x03e3+ 5128-0x17eb));}(my $__logfile=$logFile);if (($logFile eq ("")))
{($__logfile=setLogFile ());}(my $permissions=
Common::NXFile::getServerLogFilePermissions ());if ((not (
Common::NXFile::fileExists ($__logfile)))){(my $createLogFile=main::nxopen (
$__logfile,$NXBits::O_CREAT,$permissions,{"\x45\x41\x43\x43\x45\x53",
"\x73\x69\x6c\x65\x6e\x74"}));main::nxclose ($createLogFile);
Common::NXFile::setServerLogFilePermissions ($__logfile);}($logfile_fh=
main::nxopen ($__logfile,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND
),$permissions,{"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));if ((
not (defined ($logfile_fh)))){__handleOpenLogError ($__logfile);}else{
libnxh::NXDescriptorInheritable ($logfile_fh,(0x0160+ 9450-0x264a));}}sub 
__handleOpenLogError{(my $logfile=shift (@_));(my $error=libnxh::NXGetErrorName 
());(my $errorstring=libnxh::NXGetErrorString ());(my $path=
Common::NXFile::dirname ($logfile));(my $filename=Common::NXFile::basename (
$logfile));setLoggerNotWorking ();if (($error eq "\x45\x4e\x4f\x45\x4e\x54")){
main::nxwrite (main::nxgetSTDERR (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$filename)."\x20\x69\x6e\x20").$path).
"\x20\x2d\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x0a"
));main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$filename)."\x20\x69\x6e\x20").$path).
"\x20\x2d\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x0a"
));}else{main::nxwrite (main::nxgetSTDERR (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$logfile)."\x20\x2d\x20\x27").$errorstring)."\x27\x2e\x0a"));main::nxwrite (
main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$logfile)."\x20\x2d\x20\x27").$errorstring)."\x27\x2e\x0a"));}main::nxexit ();}
sub __suppressStatusDump{(my $message=shift (@_));(my $level=$LOG_DEBUG);(my $statusMessage
=(0x0ae5+ 901-0x0e69));return (__suppress ($message,$level,$statusMessage));}sub
 __suppress{(my $msg=shift (@_));(my $level=shift (@_));(my $statusMessage=shift
 (@_));(my $ref_previousMessageCount=(\$__previousLogMessage));(my $ref_previousMessage
=(\$__previousLogMessageCount));if (($statusMessage==(0x20b9+ 1588-0x26ec))){(
$ref_previousMessage=(\$__previousStatusMessage));($ref_previousMessageCount=(
\$__previousStatusMessageCount));}if ((not ($$ref_previousMessage))){(
$$ref_previousMessage=$msg);($$ref_previousMessageCount=(0x0a31+ 1295-0x0f3f));
return ((0x035f+ 2058-0x0b69));}if (($$ref_previousMessage eq $msg)){(
$$ref_previousMessageCount=($$ref_previousMessageCount+(0x0391+ 1660-0x0a0c)));
return ((0x1ad8+ 153-0x1b70));}else{if (($$ref_previousMessageCount>
(0x0094+ 9585-0x2604))){(my $count=($$ref_previousMessageCount-
(0x1047+ 4539-0x2201)));(my $message=(""));if (($count==(0x0c5a+ 3810-0x1b3b))){
($message=((
"\x50\x72\x65\x76\x69\x6f\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x70\x65\x61\x74\x65\x64\x20"
.$count)."\x20\x74\x69\x6d\x65"));}else{($message=((
"\x50\x72\x65\x76\x69\x6f\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x70\x65\x61\x74\x65\x64\x20"
.$count)."\x20\x74\x69\x6d\x65\x73"));}if (($statusMessage==
(0x12c5+ 1319-0x17eb))){__statusPush ($message);}else{sendMessageToLogfile (
$message,$level);}($$ref_previousMessageCount=(0x0f7a+ 923-0x1314));}(
$$ref_previousMessage=$msg);return ((0x13fd+ 2966-0x1f93));}}sub 
getLogrotateLogTypeNxserverLog{return (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67");}sub 
getLogrotateLogTypeNxdLog{return ("\x6e\x78\x64\x2e\x6c\x6f\x67");}sub 
getLogrotateLogTypeNwebclientLog{return (
"\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e\x6c\x6f\x67");}sub 
getLogrotateLogTypeNxhtdErrorLog{return ("\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67")
;}sub getLogrotateLogTypeNxserviceLog{return (
"\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e\x6c\x6f\x67");}sub updateLogLevel{(my $newLevel
=shift (@_));if (($newLevel!=$__level)){($__level=$newLevel);info (((
"\x53\x65\x74\x20\x6e\x65\x77\x20\x6c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x27".
$newLevel)."\x27\x2e"));}else{debug (((
"\x4c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x27".$newLevel).
"\x27\x20\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x64\x2e"));}}return (
(0x0058+ 5653-0x166c));
