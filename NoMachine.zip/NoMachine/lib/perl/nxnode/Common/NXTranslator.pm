############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXTranslator;no warnings;(my (%__translation)=());sub init{(my $language
=shift (@_));if (__isGerman ($language)){main::nxrequire (((
"\x43\x6f\x6d\x6d\x6f\x6e".$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x47\x65\x72\x6d\x61\x6e\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXGermanMessages::getGermanTranslations ());}elsif (
__isSpanish ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x53\x70\x61\x6e\x69\x73\x68\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXSpanishMessages::getSpanishTranslations ());}elsif (
__isFrench ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x46\x72\x65\x6e\x63\x68\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXFrenchMessages::getFrenchTranslations ());}elsif (
__isItalian ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x49\x74\x61\x6c\x69\x61\x6e\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXItalianMessages::getItalianTranslations ());}elsif (
__isPolish ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x50\x6f\x6c\x69\x73\x68\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXPolishMessages::getPolishTranslations ());}elsif (
__isPortuguese ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x50\x6f\x72\x74\x75\x67\x75\x65\x73\x65\x4d\x65\x73\x73\x61\x67\x65\x73"
));((%__translation)=Common::NXPortugueseMessages::getPortugueseTranslations ())
;}elsif (__isRussian ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x52\x75\x73\x73\x69\x61\x6e\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXRussianMessages::getRussianTranslations ());}(
$Common::NXTranslator::language=$language);}sub translate{(my $message=shift (@_
));(my $result=shift (@_));(my $translation=$__translation{$message});if ((not (
defined ($translation)))){Logger::debug3 (((
"\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$message).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x2e"
));return ((0x0950+ 183-0x0a07));}($$result=$translation);Logger::debug3 (((((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x20\x74\x6f\x20\x27").$translation)."\x27\x2e"));return (
(0x205a+ 161-0x20fa));}sub getLanguage{if (($language ne (""))){return (
$language);}else{return (undef);}}sub __isGerman{(my $language=shift (@_));if ((
$language eq "\x64\x65\x5f\x44\x45")){return ((0x0664+ 4448-0x17c3));}return (
(0x0174+ 5828-0x1838));}sub __isSpanish{(my $language=shift (@_));if (($language
 eq "\x65\x73\x5f\x45\x53")){return ((0x0b84+ 1024-0x0f83));}return (
(0x00e6+ 8867-0x2389));}sub __isFrench{(my $language=shift (@_));if (($language 
eq "\x66\x72\x5f\x46\x52")){return ((0x1c80+ 351-0x1dde));}return (
(0x1444+ 2614-0x1e7a));}sub __isItalian{(my $language=shift (@_));if (($language
 eq "\x69\x74\x5f\x49\x54")){return ((0x1611+ 704-0x18d0));}return (
(0x01e9+ 2115-0x0a2c));}sub __isPolish{(my $language=shift (@_));if (($language 
eq "\x70\x6c\x5f\x50\x4c")){return ((0x0fac+ 2701-0x1a38));}return (
(0x0968+ 4335-0x1a57));}sub __isPortuguese{(my $language=shift (@_));if ((
$language eq "\x70\x74\x5f\x50\x54")){return ((0x0181+ 8557-0x22ed));}return (
(0x0849+ 3883-0x1774));}sub __isRussian{(my $language=shift (@_));if (($language
 eq "\x72\x75\x5f\x52\x55")){return ((0x07c4+ 267-0x08ce));}return (
(0x0b9a+ 4858-0x1e94));}sub __isEnglish{(my $language=shift (@_));if (($language
 eq "\x65\x6e\x5f\x55\x53")){return ((0x00a2+ 3417-0x0dfa));}return (
(0x0398+ 7783-0x21ff));}sub translateTimestampForDateBaseOnLanguage{(my $timestamp
=shift (@_));(my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=
Common::NXTime::getLocalTimeFromTimestamp ($timestamp));($year+=
(0x13bb+ 6602-0x2619));(++$mon);my ($date);if (__isEnglish (getLanguage ())){
return (((((((((sprintf ("\x25\x30\x32\x64",$mon)."\x2f").sprintf (
"\x25\x30\x32\x64",$mday))."\x2f").$year)."\x2c\x20").sprintf (
"\x25\x30\x32\x64",$hour))."\x3a").sprintf ("\x25\x30\x32\x64",$min)));}else{
return (((((((((sprintf ("\x25\x30\x32\x64",$mday)."\x2f").sprintf (
"\x25\x30\x32\x64",$mon))."\x2f").$year)."\x2c\x20").sprintf ("\x25\x30\x32\x64"
,$hour))."\x3a").sprintf ("\x25\x30\x32\x64",$min)));}}return (
(0x0e0f+ 1505-0x13ef));
