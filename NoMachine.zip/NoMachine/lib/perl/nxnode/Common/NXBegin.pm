############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}sub BEGIN{
no warnings;require Common::Logger;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->import};}sub BEGIN{
no warnings;require Common::NXWorkingDir;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72"
->import};}sub BEGIN{no warnings;require Common::NXParser;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->import};}sub
 BEGIN{no warnings;require Common::NXRunCommand;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->import};}sub BEGIN{no warnings;require Common::NXProcess;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73"->import};
}sub BEGIN{no warnings;require Common::NXError;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x45\x72\x72\x6f\x72"->import};}no 
warnings;require Common::NXFile;package NXBegin;($parser=());($stderrFilePath=
(""));($moduletype=(""));($oldSTDIN=undef);($oldSTDOUT=undef);($oldSTDERR=undef)
;($processFinalized=(0x03d1+ 5771-0x1a5b));($SocketsToClose={});(
$workingSessionFD=(-(0x128d+ 1942-0x1a22)));($workingAgentFD=(-
(0x0939+ 5506-0x1eba)));($ExitRequests::receivedSIGINT=
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x49\x4e\x54\x27\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x69\x74\x65\x72\x72\x75\x70\x74"
);($ExitRequests::receivedSIGTERM=
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x54\x45\x52\x4d\x27\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e"
);($GLOBAL::DefaultSTDINDescriptor=(0x06fa+ 5997-0x1e67));(
$GLOBAL::DefaultSTDOUTDescriptor=(0x0258+ 3731-0x10ea));($handlerSIGUSR1=(""));(
$MonitoredHandler=undef);($MonitoredHandlerCallback=undef);(
$processArgumentsString=(""));($emergencyCleanUp=(0x097b+ 592-0x0bcb));sub 
initializeProcess{Common::NXError::registerMessages ();($Carp::MaxEvalLen=
(0x0fe6+ 237-0x10d0));Common::NXCore::closeSocketAtFinish ((0x0b50+ 2971-0x16eb)
);Common::NXCore::closeSocketAtFinish ((0x1673+ 3878-0x2598));
Common::NXCore::closeSocketAtFinish ((0x0ac1+ 5414-0x1fe5));($processFinalized=
(0x14b8+ 135-0x153f));($oldSTDIN=undef);($oldSTDOUT=undef);($oldSTDERR=undef);
Common::NXCore::disableExitFromSelectOnFirstSignal ();($GLOBAL::SessionLogLevel=
(0x0135+ 4848-0x141f));(my $module=shift (@_));($moduletype=$module);
Common::NXCore::loadAllModulesLibraries ();Common::NXCore::initNXPLVariables ();
Logger::initLevel ();if ((isModuletypeNxserver ()or isModuletypeNxnode ())){
Common::NXEnglishMessages::initEnglishMessages ();}libnxh::NXTransSetEnvironment
 ("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d",$ENV{
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d"});setProcessName (@ARGV);($parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);
registerSignals ();}sub initializeProcessAfterFork{Logger::error (
"\x46\x49\x58\x4d\x45\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x61\x66\x74\x65\x72\x20\x66\x6f\x72\x6b\x2e"
);}sub registerSignals{$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}
{"\x54\x45\x52\x4d"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x43\x48\x4c\x44"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x50\x57\x52"});loadSignalHandlers ();}sub redirectSTDERRtoAgentSession{(my $path
=shift (@_));if (defined ($FD_nodeSessionFile)){main::nxclose (
$FD_nodeSessionFile);}($FD_nodeSessionFile=Common::NXCore::nxFileDuplicate (
(0x0471+ 1982-0x0c2d)));main::closeSocketAtFinish ($FD_nodeSessionFile);(
$FD_agentSessionFile=main::nxopen ($path,($NXBits::O_CREAT+$NXBits::O_WRONLY),
$NXBits::UserReadWrite));if (defined ($FD_agentSessionFile)){(my $fd_copy=
Common::NXCore::nxFileClone ($FD_agentSessionFile,(0x00d2+ 1231-0x059f)));
libnxh::NXDescriptorInheritable ($FD_agentSessionFile,(0x02f1+ 7329-0x1f92));
main::closeSocketAtFinish ($FD_agentSessionFile);libnxh::NXDescriptorInheritable
 ((0x091c+ 6085-0x20df),(0x08a7+ 1739-0x0f72));
main::correctSessionFilesOwnershipOnWindows ($path);}}sub 
redirectSTDERRtoNodeSession{if (defined ($FD_agentSessionFile)){(my $fd_copy=
Common::NXCore::nxFileClone ($FD_nodeSessionFile,(0x0123+ 8718-0x232f)));
main::nxclose ($FD_agentSessionFile);($FD_agentSessionFile=undef);}else{(my $file
=(((((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").
$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72").$GLOBAL::DIRECTORY_SLASH).
"\x66\x69\x6c\x65"));(my $dir=(((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x64\x62").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72"));if ((not (-d 
($dir)))){if (($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){(my $returnValue
=libnxh::NXMakePath ($dir,("")));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x03e7+ 6328-0x1c9f))){(my $errorNumber
=libnxh::NXGetError ());(my $errorMessage=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$dir)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorMessage)."\x27\x2e"));}}}(my $correctNXErrorLogPermissions
=(0x2075+   4-0x2079));if (($GLOBAL::CommonLogDirectory eq (""))){(my $logDir=
Common::NXPaths::getDirectoryForLogsPath ());if ((not (-d ($logDir)))){if (
Common::NXCore::isEffectiveUserNXRootOrSystem ()){if (($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){(my $returnValue=
libnxh::NXMakePath ($logDir,("")));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x1a3b+ 1960-0x21e3))){(my $errorNumber
=libnxh::NXGetError ());(my $errorMessage=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$logDir)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$errorNumber)."\x2c\x20\x27").$errorMessage)."\x27\x2e"));main::nxwrite (
main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$logDir)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorMessage).
"\x27\x2e\x0a"));main::nxexit ();}}else{Logger::error (((
"\x4c\x6f\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20".$logDir).
"\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$logDir)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorMessage).
"\x27\x2e\x0a"));main::nxexit ();}}else{(my $user=
Common::NXCore::getEffectiveUsername ());my ($errorMessage);(my $returnValue=
Common::NXPaths::createAccessibleForUserDirectory ((\$errorMessage),$logDir,
$user));if (($returnValue!=(0x23e8+ 487-0x25ce))){main::nxwrite (
main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$logDir)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorMessage).
"\x27\x2e\x0a"));main::nxexit ();}($GLOBAL::THIS_IS_THE_FIRST_LOGIN=
(0x0d6a+ 4121-0x1d82));}}(my $errorPath=Common::NXPaths::getNXServerLogPath ());
if ((not (Common::NXFile::fileExists ($errorPath)))){(
$correctNXErrorLogPermissions=(0x03b4+ 1827-0x0ad6));}($FD_nodeSessionFile=
main::nxopen ($errorPath,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND
),$NXBits::UserReadWrite));($stderrFilePath=$errorPath);}else{(my $errorPath=
Common::NXPaths::getNXServerLogPath ());if ((not (Common::NXFile::fileExists (
$errorPath)))){($correctNXErrorLogPermissions=(0x0538+ 7127-0x210e));}(
$FD_nodeSessionFile=main::nxopen ($errorPath,(($NXBits::O_CREAT+
$NXBits::O_WRONLY)+$NXBits::O_APPEND),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersWrite)));($stderrFilePath=$errorPath);}
if (defined ($FD_nodeSessionFile)){libnxh::NXDescriptorInheritable (
$FD_nodeSessionFile,(0x1584+ 2035-0x1d77));(my $fd_copy=
Common::NXCore::nxFileClone ($FD_nodeSessionFile,(0x0afb+ 827-0x0e34)));
main::closeSocketAtFinish ($FD_nodeSessionFile);if (
$correctNXErrorLogPermissions){Common::NXFile::setServerLogFilePermissions ();}}
else{(my $error=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());if (($error eq "\x45\x4e\x4f\x45\x4e\x54")){(my $path
=Common::NXFile::dirname ($stderrFilePath));(my $filename=
Common::NXFile::basename ($stderrFilePath));main::nxwrite (main::nxgetSTDOUT (),
((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$filename)."\x20\x69\x6e\x20").$path).
"\x20\x2d\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x0a"
));}else{main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$stderrFilePath)."\x20\x2d\x20\x27").$errorstring)."\x27\x2e\x0a"));}
main::nxexit ();}}}sub loadSignalHandlers{if (($moduletype eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){($$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{
"\x49\x4e\x54"}=sub{NXShell::setExitRequest ($ExitRequests::receivedSIGINT);});(
$$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x54\x45\x52\x4d"}=sub{
NXShell::setExitRequest ($ExitRequests::receivedSIGTERM);});}($$parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x48\x55\x50"}=sub{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x48\x55\x50\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x20\x74\x68\x69\x73\x20\x73\x69\x67\x6e\x61\x6c\x20\x69\x73\x20\x69\x67\x6e\x6f\x72\x65\x64\x20\x62\x79\x20\x4e\x58\x20\x53\x65\x72\x76\x65\x72"
);});($$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x55\x53\x52\x31"}=sub{
Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x55\x53\x52\x31\x27\x20\x73\x69\x67\x6e\x61\x6c\x2e"
);Common::NXProcess::handleSIGUSR1 ();});($$parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x55\x53\x52\x32"}=sub{(
$GLOBAL::REQUEST_TERMINATE=(0x02f4+ 6388-0x1be7));Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x55\x53\x52\x32\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x20\x74\x68\x69\x73\x20\x6d\x65\x61\x6e\x73\x20\x2d\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x65\x73\x73\x69\x6f\x6e"
);});($$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x43\x48\x4c\x44"}=sub{
Logger::debug3 (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x43\x48\x4c\x44\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x67\x6f\x69\x6e\x67\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x20\x69\x74"
);Common::NXProcess::handleSIGCHLD ();});($$parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x50\x57\x52"}=sub{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x50\x57\x52\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x20\x67\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x68\x75\x74\x64\x6f\x77\x6e"
);Common::NXCore::exitFromSelectOnFirstSignal ();(my $callback=$$parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x54\x45\x52\x4d"});if (($callback ne (""))){&{
$callback;}();}});}sub unregisterSignals{if ((not (defined ($parser)))){return;}
$parser->unregisterSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{"\x54\x45\x52\x4d"})
;$parser->unregisterSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{"\x43\x48\x4c\x44"}
);$parser->unregisterSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{"\x50\x57\x52"});}
sub finalizeProcess{if ((not ($processFinalized))){(my $firstCaller=(caller (
(0x0992+ 221-0x0a6d)))[(0x0079+ 9845-0x26eb)]);($firstCaller=~ s/:.*//s );if ((
$firstCaller ne "\x4c\x6f\x67\x67\x65\x72")){Logger::debug (
"\x46\x69\x6e\x61\x6c\x69\x7a\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x2e");}(
$processFinalized=(0x0327+ 7702-0x213c));if (($moduletype eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){if ((exists ($INC{
"\x53\x65\x72\x76\x65\x72\x2e\x70\x6d"})and (not (Server::isDaemonProcess ()))))
{if ((exists ($INC{"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32\x2e\x70\x6d"})and (
$SessionStartStateMachine::statesInitialized==(0x05a6+ 2019-0x0d88)))){(my $status
=NXSession2::getStatusBySessionId (Server::getMySessionID ()));if ((((not (
NXSession2::isStatusRunning ($status)))and (not (NXSession2::isStatusForwarded (
$status))))and ($emergencyCleanUp==(0x0be1+ 5000-0x1f69)))){($emergencyCleanUp=
(0x1112+ 557-0x133e));NXSession2::cleanUpLeftoverSession (Server::getMySessionID
 (),((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x63\x6c\x65\x61\x6e\x65\x64\x20\x70\x72\x6f\x70\x65\x72\x6c\x79\x20\x62\x65\x66\x6f\x72\x65\x20\x63\x6c\x6f\x73\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$ $) .  "\x2e"));}}else{(my $sessionId=Server::getMySessionID ());if (((exists 
($INC{"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32\x2e\x70\x6d"})and ($sessionId ne
 ("")))and ($emergencyCleanUp==(0x0d98+ 2159-0x1607)))){($emergencyCleanUp=
(0x00ff+ 9183-0x24dd));NXSession2::cleanNegotiatingSessionIfNeeded ($sessionId);
}}}if (exists ($INC{"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x2e\x70\x6d"})){if (
NXLocate::wasStarted ()){NXLocate::close ();}}if (exists ($INC{
"\x4e\x58\x52\x65\x64\x69\x73\x2e\x70\x6d"})){NXRedis::closeDb (
(0x184b+ 2678-0x22c0));}Common::NXCore::restoreConsoleCPonWindows ();if (((
libnxh::NXShellReverseRunning ()==(0x07a7+ 269-0x08b3))and (
libnxhs::NXForwarderRunning ()==(0x086d+ 3403-0x15b8)))){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x52\x65\x76\x65\x72\x73\x65\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $result=libnxh::NXShellReverseDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x52\x65\x76\x65\x72\x73\x65\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));}Server::shutdownClientConnection ();}if (($moduletype eq
 "\x6e\x78\x6e\x6f\x64\x65")){if (Common::NXCore::isNXLibraryLoaded (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67")){if (($INC{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x2e\x70\x6d"}
eq (""))){Logger::debug (
"\x4d\x6f\x64\x75\x6c\x20\x27\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x2e\x70\x6d\x27\x20\x77\x61\x73\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x65\x64\x2e"
);}else{Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x52\x75\x6e\x6e\x69\x6e\x67\x28\x29\x2e"
);if (libnxdiag::NXAgentRunning ()){Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x52\x75\x6e\x6e\x69\x6e\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27\x31\x27\x2e"
);NXSessionMonitor::send_terminate_to_agent ();
NXSessionMonitor::close_agent_socket ();Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x2e"
);libnxdiag::NXAgentDestroy ();Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x44\x65\x73\x74\x72\x6f\x79\x20\x73\x74\x6f\x70\x2e"
);}Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x52\x75\x6e\x6e\x69\x6e\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27\x30\x27\x2e"
);}}else{Logger::debug (
"\x27\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x27\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x77\x61\x73\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x65\x64\x2e"
);}}if ($INC{("\x43\x6f\x6d\x6d\x6f\x6e".$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x2e\x70\x6d"}){NXConsole::closeConsole ();
}if (Common::NXCore::isNXLibraryLoadedForModule ()){unregisterSignals ();}if (
defined ($FD_nodeSessionFile)){main::nxclose ($FD_nodeSessionFile);undef (
$FD_nodeSessionFile);}Common::NXProcess::leaveOrphans ();foreach my $sock (keys 
(%$SocketsToClose)){if (((((($sock==(0x11c8+ 4063-0x21a7))or ($sock==
(0x0462+ 1245-0x093e)))or ($sock==(0x18db+ 206-0x19a7)))or ($sock==$$parser{
"\x53\x69\x67\x6e\x61\x6c"}))or ($sock==$Logger::logfile_fh))){next;}
main::nxclose ($sock);}Logger::closeLogFile ();}}sub setProcessName{(my (
@arguments)=@_);setProcessArgumentsString ();my ($processName);foreach my $argument
 (@arguments){if (($moduletype eq "\x6e\x78\x73\x65\x72\x76\x65\x72")){if ((
$argument eq "\x2d\x2d\x73\x74\x61\x72\x74\x75\x70")){if (($arguments[
(0x0728+ 552-0x0950)]eq "\x72\x6f\x6f\x74")){($processName=
"\x73\x74\x61\x72\x74\x75\x70\x20\x6d\x6f\x6e\x69\x74\x6f\x72");}elsif ((
$arguments[(0x0738+ 2849-0x1258)]eq "\x2d\x2d\x6d\x6f\x6e\x69\x74\x6f\x72")){(
$processName="\x73\x74\x61\x72\x74\x75\x70\x20\x6d\x6f\x6e\x69\x74\x6f\x72");}
else{($processName="\x73\x74\x61\x72\x74\x75\x70");}}if (($argument eq 
"\x2d\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x6d\x6f\x6e\x69\x74\x6f\x72"))
{($processName=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72");}if 
(($argument eq 
"\x2d\x2d\x76\x69\x72\x74\x75\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e")){(
$processName="\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x69\x6f\x6e");}if ((
$argument eq "\x2d\x2d\x64\x61\x65\x6d\x6f\x6e")){($processName=
"\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e");}}if (($moduletype eq 
"\x6e\x78\x6e\x6f\x64\x65")){if (($argument eq "\x2d\x2d\x48")){($processName=
"\x61\x74\x74\x61\x63\x68\x20\x6e\x6f\x64\x65");}}}if ((not (defined (
$processName)))){(my $cmd_arg=lc ($GLOBAL::SOFTWARE_NAME));($processName=(((
"\x20".$cmd_arg)."\x20").getProcessArgumentsString ()));}($NXBegin::processName=
$processName);}sub getProcessName{(my $processName=$processName);return (
$processName);}sub getProcessArgumentsString{return ($processArgumentsString);}
sub setProcessArgumentsString{(my $string=(""));if (($moduletype eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){
Common::NXCore::convertCommandLineArgumentsOnWindows ();}foreach my $arg (@ARGV)
{if (($string eq (""))){($string=$arg);}else{($string.=("\x20".$arg));}}(
$processArgumentsString=$string);}sub getSignalDescriptor{return ($$parser{
"\x53\x69\x67\x6e\x61\x6c"});}sub getModuletype{return ($moduletype);}sub 
isModuletypeNxserver{if ((getModuletype ()eq "\x6e\x78\x73\x65\x72\x76\x65\x72")
){return ((0x12e6+ 324-0x1429));}return ((0x00c2+ 6065-0x1873));}sub 
isModuletypeNxnode{if ((getModuletype ()eq "\x6e\x78\x6e\x6f\x64\x65")){return (
(0x0317+ 5822-0x19d4));}return ((0x0c36+ 6844-0x26f2));}sub END{if ((not (
$processFinalized))){finalizeProcess ();}}"\x3f\x3f\x3f";
