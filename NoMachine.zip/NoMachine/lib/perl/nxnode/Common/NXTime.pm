############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXTime::getSecondsSinceEpoch{package Common::NXTime;no warnings;(my $seconds
=libnxh::NXGetTime ());return ($seconds);}sub 
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch{package Common::NXTime;no 
warnings;(my $buffer=("\x3a" x (0x15f1+ 515-0x17cc)));my (@arr);my (@result);(my $retval
=libnxh::NXSecondsAndMicrosecondsSinceEpoch ($buffer));if (($retval!=(-
(0x1720+ 3678-0x257d)))){(@arr=split ( /:/ ,$buffer,(0x08c6+ 6529-0x2247)));(
@result=splice (@arr,(0x0a47+ 1560-0x105f),(0x058c+ 7727-0x23b9)));return (
@result);}else{(my $errorNumber=libnxh::NXGetError ());(my $errorString=
libnxh::NXGetErrorString ());syswrite (STDERR,
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x74\x69\x6d\x65\x20\x77\x69\x74\x68\x20\x6d\x69\x63\x72\x6f\x73\x65\x63\x6f\x6e\x64\x20\x70\x72\x65\x63\x69\x73\x69\x6f\x6e\x2e\x0a"
);syswrite (STDERR,((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e\x0a"));main::nxexit ();}}
sub Common::NXTime::getMillisecondsSinceEpoch{package Common::NXTime;no warnings
;(my ($seconds,$microseconds)=getSecondsAndMicrosecondsSinceEpoch ());(my $milliseconds
=int ((($seconds *(0x0c7d+ 751-0x0b84))+($microseconds/(0x2650+ 939-0x2613)))));
return ($milliseconds);}sub Common::NXTime::getLocalTime{package Common::NXTime;
no warnings;my (@arr);my (@result);(my $buffer=("\x3a" x (0x1b58+ 813-0x1e5d)));
(my $retval=libnxh::NXLocalTime ($buffer));if (($retval!=(-(0x1422+ 2065-0x1c32)
))){(@arr=split ( /:/ ,$buffer,(0x012c+ 3434-0x0e96)));(@result=splice (@arr,
(0x0115+ 6258-0x1987),(0x1b50+ 1575-0x216e)));return (@result);}else{(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());syswrite (
STDERR,
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x74\x69\x6d\x65\x2e\x0a"
);syswrite (STDERR,((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e\x0a"));main::nxexit ();}}
sub Common::NXTime::getLocalTimeFromTimestamp{package Common::NXTime;no warnings
;(my $stamp=shift (@_));my (@arr);my (@result);(my $buffer=("\x3a" x 
(0x0a24+ 2746-0x14b6)));(my $retval=libnxh::NXLocalTimeFromTimestamp ($stamp,
$buffer));if (($retval!=(-(0x1ae5+ 771-0x1de7)))){(@arr=split ( /:/ ,$buffer,
(0x0479+ 3927-0x13d0)));(@result=splice (@arr,(0x01f6+ 5055-0x15b5),
(0x0973+ 241-0x0a5b)));return (@result);}else{(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());syswrite (
STDERR,((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x74\x69\x6d\x65\x2e\x20\x41\x72\x67\x75\x6d\x65\x6e\x74\x20\x69\x73\x20"
.$stamp)."\x2e\x0a"));syswrite (STDERR,((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e\x0a"));main::nxexit ();}}
sub Common::NXTime::getDateString{package Common::NXTime;no warnings;(my $string
=libnxh::NXLocalTimeAsString ());return ($string);}sub 
Common::NXTime::getTimestamp{package Common::NXTime;no warnings;(my ($sec,
$microsec)=getSecondsAndMicrosecondsSinceEpoch ());(my (@time)=
getLocalTimeFromTimestamp ($sec));(my $milisec=sprintf ("\x25\x30\x36\x64",
$microsec));($milisec=((substr ($milisec,(0x0f8a+ 1519-0x1579),
(0x072a+ 2645-0x117c))."\x2e").substr ($milisec,(0x0b46+ 4313-0x1c1c))));(my $Timestamp
=((((((sprintf ("\x25\x30\x32\x64",$time[(0x1fe0+ 715-0x22a9)])."\x3a").sprintf 
("\x25\x30\x32\x64",$time[(0x1295+ 511-0x1493)]))."\x3a").sprintf (
"\x25\x30\x32\x64",$time[(0x1d6c+ 1982-0x252a)]))."\x3a").sprintf ($milisec)));
return ($Timestamp);}sub Common::NXTime::getTimestampOnlyMicroseconds{package 
Common::NXTime;no warnings;(my ($sec,$microsec)=
getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf ("\x25\x30\x36\x64"
,$microsec));($milisec=((substr ($milisec,(0x06b6+ 480-0x0896),
(0x0d01+ 6550-0x2694))."\x2e").substr ($milisec,(0x1b57+ 1518-0x2142))));(my $Timestamp
=sprintf ($milisec));return ($Timestamp);}sub Common::NXTime::__getTimeMs{
package Common::NXTime;no warnings;(my ($sec,$microsec)=
getSecondsAndMicrosecondsSinceEpoch ());(my (@time)=getLocalTimeFromTimestamp (
$sec));(my $milisec=sprintf ("\x25\x30\x36\x64",$microsec));($milisec=(substr (
$milisec,(0x026b+ 6994-0x1dbd),(0x0774+ 6621-0x214e)).substr ($milisec,
(0x0e2b+ 4451-0x1f8b))));return ($milisec,@time);}sub Common::NXTime::getTimeMs{
package Common::NXTime;no warnings;(my ($milisec,@time)=__getTimeMs ());(my $TimeMs
=((((sprintf ("\x25\x30\x32\x64",$time[(0x0823+ 1252-0x0d05)]).sprintf (
"\x25\x30\x32\x64",$time[(0x05c6+ 7444-0x22d9)])).sprintf ("\x25\x30\x32\x64",
$time[(0x200f+ 568-0x2247)]))."\x2e").sprintf ($milisec)));return ($TimeMs);}sub
 Common::NXTime::getLoggerTimeline{package Common::NXTime;no warnings;(my (
$milisec,@time)=__getTimeMs ());($milisec=((substr ($milisec,
(0x08cc+ 6877-0x23a9),(0x14b8+ 3069-0x20b2))."\x2e").substr ($milisec,
(0x0aaa+ 1523-0x109a))));(my $Timeline=(sprintf (
"\x25\x30\x34\x64\x2d\x25\x30\x32\x64\x2d\x25\x30\x32\x64\x20\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x20"
,((0x0c05+ 8818-0x270b)+$time[(0x010b+ 9295-0x2555)]),((0x02f9+ 5221-0x175d)+
$time[(0x0601+ 610-0x085f)]),$time[(0x030c+ 931-0x06ac)],$time[
(0x07e5+ 6742-0x2239)],$time[(0x0845+ 5739-0x1eaf)],$time[(0x026f+ 2492-0x0c2b)]
).$milisec));return ($Timeline);}sub 
Common::NXTime::getLoggerTimelineOnlyMicroseconds{package Common::NXTime;no 
warnings;(my ($milisec,@time)=__getTimeMs ());($milisec=((substr ($milisec,
(0x0c52+ 2829-0x175f),(0x0504+ 7601-0x22b2))."\x2e").substr ($milisec,
(0x1650+ 716-0x1919))));(my $Timeline=sprintf ($milisec));return ($Timeline);}
sub Common::NXTime::convertLocalTimeFromTimestampToHumanReadableString{package 
Common::NXTime;no warnings;(my $timestamp=shift (@_));(my (@time)=
getLocalTimeFromTimestamp ($timestamp));(my $timeString=sprintf (
"\x25\x30\x34\x64\x2d\x25\x30\x32\x64\x2d\x25\x30\x32\x64\x20\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x3a\x25\x30\x32\x64"
,((0x1bcd+ 4351-0x2560)+$time[(0x16e7+ 3348-0x23f6)]),($time[
(0x06fc+ 1482-0x0cc2)]+(0x2279+ 186-0x2332)),$time[(0x1e3c+  91-0x1e94)],$time[
(0x0963+ 2625-0x13a2)],$time[(0x1a23+ 487-0x1c09)],$time[(0x0b0c+ 6074-0x22c6)])
);return ($timeString);}sub Common::NXTime::getDateTimeForFileName{package 
Common::NXTime;no warnings;(my $dateTime=getLoggerTimeline ());($dateTime=~ s/ [^ ]*$// )
;($dateTime=~ s/-/./gm );($dateTime=~ s/:/./gm );($dateTime=~ s/ /-/gm );return 
($dateTime);}sub Common::NXTime::getSecondsInWeek{package Common::NXTime;no 
warnings;return (604800);}sub Common::NXTime::convertSecondsToDaysRounded{
package Common::NXTime;no warnings;(my $seconds=shift (@_));(my $days=($seconds/
86400));($days=(int ($days)+(0x0e28+ 1573-0x144c)));return ($days);}package 
Common::NXTime;no warnings;"\x3f\x3f\x3f";
