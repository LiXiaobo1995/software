############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXConsole;no warnings;($consoleInitFD=(-(0x0df9+ 3750-0x1c9e)));($buffer
=(""));($console=(-(0x0d5c+ 4375-0x1e72)));($consoleChildOUT=(-
(0x04c6+ 6441-0x1dee)));($consoleChildIN=(-(0x1970+ 346-0x1ac9)));sub 
__initConsole{if (consoleRuning ()){Logger::debug ((
"\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x46\x44\x23"
.$consoleInitFD));return;}($buffer=("\x20" x (0x21cc+ 891-0x2447)));my (
$consoleDescriptorError);(my $consoleInitFD=createConsoleDescriptor ((
\$consoleDescriptorError),(\$buffer),(0x0da6+ 2566-0x16ac)));(
$NXConsole::consoleInitFD=$consoleInitFD);if (($NXConsole::consoleInitFD==(-
(0x0174+ 5011-0x1506)))){if (((not (defined ($consoleDescriptorError)))or (
$consoleDescriptorError eq ("")))){main::node_finish_error_simple (
"\x65\x47\x55\x49\x43\x6f\x75\x6c\x64\x4e\x6f\x74\x43\x72\x65\x61\x74\x65\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x57\x69\x74\x68\x6f\x75\x74\x52\x65\x61\x73\x6f\x6e"
);}else{main::node_finish_error_simple (
"\x65\x47\x55\x49\x43\x6f\x75\x6c\x64\x4e\x6f\x74\x43\x72\x65\x61\x74\x65\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65"
,$consoleDescriptorError);}}else{Logger::debug ((
"\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x46\x44\x23"
.$NXConsole::consoleInitFD));}}sub closeConsole{if (consoleRuning ()){
Logger::debug ((
"\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x63\x6c\x6f\x73\x69\x6e\x67\x20\x46\x44\x23"
.$consoleInitFD));main::nxclose ($consoleInitFD);($consoleInitFD=(-
(0x0368+ 990-0x0745)));}}sub __setupConsole{($consolePath=libnxh::NXGetConsole (
$consoleInitFD,(\$buffer),(0x02eb+ 9362-0x267d)));if (($consolePath==(-
(0x0f78+ 4039-0x1f3e)))){(my $errorString=Common::NXCore::reportErrorFromNXPL ((
(
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x6f\x6e\x73\x6f\x6c\x65\x20\x70\x61\x74\x68\x20\x66\x6f\x72\x20"
.$consoleInitFD)."\x2e")));main::node_finish_error_simple (
"\x65\x43\x6f\x75\x6c\x64\x4e\x6f\x74\x47\x65\x74\x43\x6f\x6e\x73\x6f\x6c\x65\x50\x61\x74\x68"
,$errorString);}else{Logger::debug (((
"\x4e\x58\x47\x65\x74\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$consolePath)."\x2e"));}}sub __createChildInOut{($consoleChildIN=main::nxopen (
$consolePath,$NXBits::O_RDWR,(0x16b0+ 2016-0x1e90)));if (($consoleChildIN==(-
(0x0843+ 2636-0x128e)))){main::node_finish_error_simple (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x46\x69\x6c\x65",$consolePath);}(
$consoleChildOUT=main::nxopen ($consolePath,$NXBits::O_RDWR,
(0x0ba9+ 6417-0x24ba)));if (($consoleChildOUT==(-(0x0084+ 7182-0x1c91)))){
main::node_finish_error_simple (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x46\x69\x6c\x65",$consolePath);}}
sub __setControllingChildFD{(my $setConsole=libnxh::NXConsoleSetControlling (
getConsoleChildOUT ()));if (($setConsole==(-(0x1f46+ 1899-0x26b0)))){
Common::NXCore::reportErrorFromNXPL (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x53\x65\x74\x43\x6f\x6e\x74\x72\x6f\x6c\x6c\x69\x6e\x67\x28"
.getConsoleDescriptor ())."\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));}
Logger::debug (((
"\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x3a\x3a\x5f\x5f\x73\x65\x74\x43\x6f\x6e\x74\x72\x6f\x6c\x6c\x69\x6e\x67\x43\x68\x69\x6c\x64\x46\x44\x28"
.getConsoleDescriptor ()).("\x29\x20\x72\x65\x74\x75\x72\x6e\x20".$setConsole)))
;}sub __setInheritableChildFD{Common::NXCore::nxDescriptorInheritable (
getConsoleChildIN (),(0x0a96+ 2472-0x143e));
Common::NXCore::nxDescriptorInheritable (getConsoleChildOUT (),
(0x100c+ 2084-0x1830));}sub createConsole{__initConsole ();__setupConsole ();
__createChildInOut ();__setControllingChildFD ();__setInheritableChildFD ();}sub
 getConsoleDescriptor{return ($consoleInitFD);}sub getConsoleChildIN{return (
$consoleChildIN);}sub getConsoleChildOUT{return ($consoleChildOUT);}sub 
createConsoleDescriptor{(my $ref_errorMessag=shift (@_));(my $buffer=shift (@_))
;(my $size=shift (@_));(my ($package,$filename,$line,$sub)=caller (
(0x17ed+ 1674-0x1e76)));if (($sub eq (""))){($sub=$package);}if ((not ((defined 
($buffer)||(!defined ($size)))))){Logger::error (((((((
"\x63\x72\x65\x61\x74\x65\x43\x6f\x6e\x73\x6f\x6c\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x63\x61\x6c\x6c\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e\x20\x42\x75\x66\x66\x65\x72\x20\x3d\x20").$buffer).
"\x2c\x20\x73\x69\x7a\x65\x20\x3d\x20").$size)."\x2e"));nxexit ();}Logger::debug
 (((
"\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e"));(my $ret=libnxh::NXConsole ($buffer,$size));(my $error=
libnxh::NXGetErrorName ());($$ref_errorMessag=libnxh::NXGetErrorString ());if ((
$ret==(-(0x21fa+  40-0x2221)))){Common::NXCore::reportErrorFromNXPL (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x63\x6f\x6e\x73\x6f\x6c\x65\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e"));return ($ret);}Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20\x46\x44\x23"
.$ret)."\x2e"));Common::NXCore::nxDescriptorInheritable ($ret,
(0x0b8d+ 6882-0x266f));Common::NXCore::closeSocketAtFinish ($ret);return ($ret);
}sub consoleRuning{if (($consoleInitFD==(-(0x0648+ 6817-0x20e8)))){return (
(0x015c+ 8635-0x2317));}return ((0x0139+ 8530-0x228a));}"\x3f\x3f\x3f";
