############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXShellCommands;no warnings;($pathNotFound=
"\x5f\x5f\x4e\x4f\x4e\x45\x5f\x5f");($commandSs="\x5f\x5f\x53\x53\x5f\x5f");(
$commandNetstat="\x5f\x5f\x4e\x45\x54\x53\x54\x41\x54\x5f\x5f");sub checkPath{(my $command
=shift (@_));(my $path=checkPathInPathVariable ($command));return ($path);}sub 
checkPathInPathVariable{(my $command=shift (@_));(my $envPath=$ENV{
"\x50\x41\x54\x48"});($envPath=~ s/^PATH=//gm );(my (@paths)=split ( /;/ ,
$envPath,(0x0a44+ 5792-0x20e4)));foreach my $path (@paths){(my $file=(($path.
$GLOBAL::DIRECTORY_SLASH).$command));if (-x ($file)){return ($file);}}return (
$pathNotFound);}sub getPath{(my $command=shift (@_));(my $ref_commandPath=
getReferenceToSavedCommand ($command));if ((not (defined ($$ref_commandPath)))){
($$ref_commandPath=checkPath ($command));}(my $commandPath=$$ref_commandPath);
return ($commandPath);}sub getCommand{(my (@args)=@_);(my $command=shift (@args)
);(my $ref_commandPath=getReferenceToSavedCommand ($command));if ((not (defined 
($$ref_commandPath)))){($$ref_commandPath=checkPath ($command));}(my $commandPath
=$$ref_commandPath);(my (@reply)=());if (($commandPath ne $pathNotFound)){push (
@reply,$commandPath,@args);}else{Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x66\x69\x6e\x64\x20\x52\x46\x42\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2e"
);}return (@reply);}sub getReferenceToSavedCommand{(my $command=shift (@_));(my $refCommand
=((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x43\x6f\x6d\x6d\x61\x6e\x64\x73\x3a\x3a"
.$command)."\x5f\x63\x6f\x6d\x6d\x61\x6e\x64"));return ($refCommand);}sub 
getReferenceToSavedCommandParameters{(my $command=shift (@_));(my $type=shift (
@_));(my $refOptions=((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x43\x6f\x6d\x6d\x61\x6e\x64\x73\x3a\x3a"
.$command).("\x5f\x6f\x70\x74\x69\x6f\x6e\x73\x5f".$type)));return ($refOptions)
;}sub isApplicationInKnownPath{(my $command=shift (@_));(my $refCommand=
getReferenceToSavedCommand ($command));if ((not (defined ($$refCommand)))){(
$$refCommand=checkPath ($command));}(my $commandPath=$$refCommand);if ((
$commandPath ne $pathNotFound)){return ((0x1b45+ 1645-0x21b1));}return (
(0x1307+ 2887-0x1e4e));}sub isPasswordRequestMessage{(my $message=shift (@_));if
 ((((($message=~ /password for/ )or ($message=~ /Password/ ))or ($message=~ /'s password/ )
)or ($message=~ /assword:\ *$/ ))){return ((0x1fcd+ 542-0x21ea));}return (
(0x020b+ 3485-0x0fa8));}sub isNotInSudoersMessage{(my $message=shift (@_));if ((
($message=~ /is not in the sudoers file/ )or ($message=~ /is not allowed to execute/ )
)){return ((0x0337+ 2487-0x0ced));}return ((0x0ba8+ 1551-0x11b7));}sub 
isNotAdministrator{(my $message=shift (@_));if (($message=~ /Only a user with administrative privileges can use option/ )
){return ((0x0348+ 3503-0x10f6));}return ((0x02d1+ 5861-0x19b6));}sub 
getConnectionsForXserversCheck{(my $ref_cmd_out=shift (@_));(my $ref_exit_value=
shift (@_));(my (@command)=getNetStatisticsCommandForListeningUnix ());if ((
$command[(0x1942+ 119-0x19b9)]eq $pathNotFound)){($$ref_exit_value=
(0x0a8f+ 1504-0x106e));return ((0x1567+ 1633-0x1bc8));}my ($cmd_err);(($cmd_err,
$$ref_cmd_out,$$ref_exit_value)=main::run_command ((\@command),("")));if (
$$ref_exit_value){Logger::warning (((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$$ref_exit_value)."\x27\x2e"));Logger::warning (((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x6f\x75\x74\x70\x75\x74\x20\x27"
.$$ref_cmd_out)."\x27\x2e"));Logger::warning (((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x27"
.$cmd_err)."\x27\x2e"));return ((0x0bdb+ 2618-0x1615));}return (
(0x01ea+ 2609-0x0c1a));}sub getListeningConnections{(my $ref_cmd_out=shift (@_))
;(my $ref_exit_value=shift (@_));(my (@command)=getNetStatisticsCommandForAllTcp
 ());if (($command[(0x0255+ 6682-0x1c6f)]eq $pathNotFound)){($$ref_exit_value=
(0x0860+ 5238-0x1cd5));return ((0x0754+ 1894-0x0eba));}my ($cmd_err);(($cmd_err,
$$ref_cmd_out,$$ref_exit_value)=main::run_command ((\@command),("")));if (
$$ref_exit_value){return ((0x02df+ 9238-0x26f5));}return ((0x0531+  59-0x056b));
}sub getExtendedListeningConnectionsForFontServerChecking{(my $ref_cmd_out=shift
 (@_));(my $ref_exit_value=shift (@_));(my (@command)=
getNetStatisticsCommandForListeningTcpExtended ());if (($command[
(0x04a5+ 7528-0x220d)]eq $pathNotFound)){($$ref_exit_value=(0x059d+ 4566-0x1772)
);return ((0x0348+ 3692-0x11b4));}my ($cmd_err);(($cmd_err,$$ref_cmd_out,
$$ref_exit_value)=main::run_command ((\@command),("")));if ($$ref_exit_value){
return ((0x163b+ 988-0x1a17));}return ((0x0719+ 792-0x0a30));}sub 
getNetStatisticsComandWithPrioritySs{(my $commandPath=checkPath ("\x73\x73"));if
 (($commandPath eq $pathNotFound)){($commandPath=checkPath (
"\x6e\x65\x74\x73\x74\x61\x74"));if (($commandPath eq $pathNotFound)){
setNetStatisticsCommandIsNotFound ();}else{setNetStatisticsCommandIsNetstat ();}
}else{setNetStatisticsCommandIsSs ();}return ($commandPath);}sub 
getNetStatisticsComandWithPriorityNetstat{(my $commandPath=checkPath (
"\x6e\x65\x74\x73\x74\x61\x74"));if (($commandPath eq $pathNotFound)){(
$commandPath=checkPath ("\x73\x73"));if (($commandPath eq $pathNotFound)){
setNetStatisticsCommandIsNotFound ();}else{setNetStatisticsCommandIsSs ();}}else
{setNetStatisticsCommandIsNetstat ();}return ($commandPath);}sub 
setNetStatisticsCommand{(my $command=
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73");if (
isNetStatisticsCommandSet ()){return;}(my $ref_commandPath=
getReferenceToSavedCommand ($command));if (
Common::NXInfo::doesOsPreferSsOverNetstat ()){($$ref_commandPath=
getNetStatisticsComandWithPrioritySs ());}else{($$ref_commandPath=
getNetStatisticsComandWithPriorityNetstat ());}}sub 
getNetStatisticsCommandForListeningUnix{setNetStatisticsCommand ();if (
isNetStatisticsCommandNetstat ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6c\x6e",
"\x2d\x2d\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3d\x75\x6e\x69\x78"));}if (
isNetStatisticsCommandSs ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6c\x6e\x78"));}
return ($pathNotFound);}sub getNetStatisticsCommandForAllTcp{
setNetStatisticsCommand ();return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x61\x6e\x74"));}sub
 getNetStatisticsCommandForListeningTcpExtended{setNetStatisticsCommand ();if (
isNetStatisticsCommandNetstat ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6e\x65\x74\x6c"));
}if (isNetStatisticsCommandSs ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6e\x74\x6c"));}
return ($pathNotFound);}sub isNetStatisticsCommandSet{if (defined (
$netStatisticsCommand)){return ((0x13fd+ 2349-0x1d29));}return (
(0x08ac+ 1063-0x0cd3));}sub setNetStatisticsCommandIsNotFound{Logger::warning (
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x2e"
);($netStatisticsCommand=$pathNotFound);}sub setNetStatisticsCommandIsSs{(
$netStatisticsCommand=$commandSs);}sub setNetStatisticsCommandIsNetstat{(
$netStatisticsCommand=$commandNetstat);}sub isNetStatisticsCommandNetstat{if ((
$netStatisticsCommand eq $commandNetstat)){return ((0x08f4+ 4603-0x1aee));}
return ((0x094c+ 124-0x09c8));}sub isNetStatisticsCommandSs{if ((
$netStatisticsCommand eq $commandSs)){return ((0x1b88+ 610-0x1de9));}return (
(0x1197+ 889-0x1510));}sub isNetStatisticsCommandAvailable{
setNetStatisticsCommand ();if (($netStatisticsCommand eq $pathNotFound)){return 
((0x043a+ 4962-0x179c));}return ((0x0713+ 6936-0x222a));}sub 
isDbusDaemonCommandAvailable{(my $dbusDaemonPath=getPath (
"\x64\x62\x75\x73\x2d\x64\x61\x65\x6d\x6f\x6e"));if (($dbusDaemonPath eq 
$pathNotFound)){return ((0x08f8+ 4978-0x1c6a));}return ((0x0663+ 8206-0x2670));}
sub isDbusSendCommandAvailable{(my $dbusSendPath=getPath (
"\x64\x62\x75\x73\x2d\x73\x65\x6e\x64"));if (($dbusSendPath eq $pathNotFound)){
return ((0x0de7+ 5280-0x2287));}return ((0x0600+ 2831-0x110e));}sub 
isNotDbusSendCommandAvailable{return ((!isDbusSendCommandAvailable ()));}sub 
getDbusSendCommand{return (getPath ("\x64\x62\x75\x73\x2d\x73\x65\x6e\x64"));}
"\x3f\x3f\x3f";
