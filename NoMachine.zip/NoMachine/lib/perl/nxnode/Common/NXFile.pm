############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXFile::BEGIN{package Common::NXFile;no warnings;require 
Common::Logger;do{"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->
import};}sub Common::NXFile::dirname{package Common::NXFile;no warnings;(my (
$path)=@_);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x44\x69\x72\x6e\x61\x6d\x65\x20"
.$path)."\x20\x73\x74\x61\x72\x74\x2e"));(my $ret=libnxh::NXGetDirname ($path));
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x44\x69\x72\x6e\x61\x6d\x65\x20\x73\x74\x6f\x70\x2e"
);($ret=~ s/\\$// );return ($ret);}sub Common::NXFile::basename{package 
Common::NXFile;no warnings;(my ($path)=@_);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x42\x61\x73\x65\x6e\x61\x6d\x65\x20"
.$path)."\x20\x73\x74\x61\x72\x74\x2e"));(my $ret=libnxh::NXGetBasename ($path))
;Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x42\x61\x73\x65\x6e\x61\x6d\x65\x20\x73\x74\x6f\x70\x2e"
);return ($ret);}sub Common::NXFile::setPermissions_windows{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $sid=shift (@_));(my $mode=
shift (@_));(my $inherit=(shift (@_)||(0x159f+ 998-0x1985)));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x22c1+ 902-0x2647)));(my $returnVal=(-(0x0e26+ 212-0x0ef9)));if ((not (defined
 ($path)))){if (($silent==(0x0653+ 5485-0x1bc0))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2e"
);}return ($returnVal);}if ((($mode=~ /^$GLOBAL::InheritPermission/ )or (($sid 
ne (""))and ($sid!=(-(0x09ec+ 2039-0x11e2)))))){Logger::debug (((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x53\x65\x63\x75\x72\x69\x74\x79\x49\x6e\x66\x6f\x28"
.$path)."\x2c\x20").$sid)."\x2c\x20").$mode)."\x2c\x20").$inherit).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $result=libnxh::NXSetSecurityInfo (
$path,$sid,$mode,$inherit));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x53\x65\x63\x75\x72\x69\x74\x79\x49\x6e\x66\x6f\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));if ((($result==(0x0d5c+ 2952-0x18e4))or ($result==
(0x05d1+ 3672-0x1428)))){($returnVal=(0x0971+ 6586-0x232b));}else{(
$$ref_errorName=libnxh::NXGetErrorString ());($$ref_errorCode=libnxh::NXGetError
 ());if (($silent==(0x02cd+ 3044-0x0eb1))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20"
.$path)."\x2e\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}}}
else{if (($silent==(0x1243+ 5287-0x26ea))){Logger::error (((
"\x53\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20"
.$path)."\x2e"));}}return ($returnVal);}sub Common::NXFile::setPermissions_unix{
package Common::NXFile;no warnings;(my $path=shift (@_));(my $mode=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x0a92+ 677-0x0d37)));(my $returnVal=(-(0x1559+ 3911-0x249f)));if ((not (
defined ($path)))){if (($silent==(0x002f+ 4644-0x1253))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2e"
);}return ($returnVal);}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x4d\x6f\x64\x65\x28".
$path)."\x2c\x20").$mode)."\x29"));($returnVal=libnxh::NXFileMode ($path,$mode))
;if (($returnVal==(-(0x1620+ 2042-0x1e19)))){($$ref_errorName=
libnxh::NXGetErrorString ());($$ref_errorCode=libnxh::NXGetError ());if ((
$silent==(0x0b64+ 4760-0x1dfc))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20"
.$path)."\x2e\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}}
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x4d\x6f\x64\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnVal)."\x27\x2e"));return ($returnVal);}sub 
Common::NXFile::setOwnershipForUser_windows{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $sid=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0601+ 1586-0x0c33)));(my $returnVal=
setPermissions_windows ($path,$sid,$GLOBAL::OwnerPermission,
(0x01f2+ 9128-0x259a),$ref_errorName,$ref_errorCode,(0x19fa+ 2565-0x23fe)));if (
($returnVal==(-(0x0707+ 4071-0x16ed)))){if (($silent==(0x07ef+ 1735-0x0eb6))){
Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x6f\x72\x20"
.$path)."\x2e\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}}
return ($returnVal);}sub Common::NXFile::setOwnershipForUser_unix{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $uid=shift (@_));(my $gid=
shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x0616+ 7869-0x24d3)));(my $returnVal=(-(0x11b2+ 1049-0x15ca)));
Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x46\x69\x6c\x65\x4f\x77\x6e\x65\x72\x28"
.$path)."\x2c\x20").$uid)."\x2c\x20").$gid)."\x29"));(my $return=
libnxh::NXSetFileOwner ($path,$uid,$gid));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x46\x69\x6c\x65\x4f\x77\x6e\x65\x72\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));if (($return==(-(0x0d57+ 5920-0x2476)))){($$ref_errorName
=libnxh::NXGetErrorString ());($$ref_errorCode=libnxh::NXGetError ());if ((
$silent==(0x0480+ 7212-0x20ac))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20\x27"
.$path)."\x27\x3a\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}
}else{($returnVal=(0x00f9+ 9278-0x2537));}return ($returnVal);}sub 
Common::NXFile::__setOwnershipForUserNX{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $setNXGroup=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0a39+ 2808-0x1531)));(my $returnVal=(-
(0x00c8+ 1536-0x06c7)));($returnVal=setOwnershipForUser_windows ($path,
$GLOBAL::WindowsSIDStringAdmins,$ref_errorName,$ref_errorCode,$silent));return (
$returnVal);}sub Common::NXFile::__setOwnershipForUserNXGroupRoot{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0b16+ 2357-0x144b)));
(my $returnVal=(-(0x0d20+ 5827-0x23e2)));(my $uid=
Common::NXCore::userInfoGetUidByUsername ("\x6e\x78"));(my $gid=
Common::NXCore::userInfoGetGidByUsername ("\x72\x6f\x6f\x74"));($returnVal=
setOwnershipForUser_unix ($path,$uid,$gid,$ref_errorName,$ref_errorCode,$silent)
);return ($returnVal);}sub Common::NXFile::setOwnershipForUserNX{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x24c3+ 113-0x2534)));(my $setNXGroup
=(0x1b98+ 2501-0x255d));return (__setOwnershipForUserNX ($path,$setNXGroup,
$ref_errorName,$ref_errorCode,$silent));}sub 
Common::NXFile::setOwnershipForUserAndGroupNX{package Common::NXFile;no warnings
;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (
@_));(my $silent=(shift (@_)||(0x07d4+ 3905-0x1715)));(my $setNXGroup=
(0x0d5b+ 2379-0x16a5));return (__setOwnershipForUserNX ($path,$setNXGroup,
$ref_errorName,$ref_errorCode,$silent));}sub 
Common::NXFile::setOwnershipForUserNXGroupRoot{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x054c+ 547-0x076f)));return (
__setOwnershipForUserNXGroupRoot ($path,$ref_errorName,$ref_errorCode,$silent));
}sub Common::NXFile::setOwnershipForUserNXSilent{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));return (setOwnershipForUserNX ($path,$ref_errorName,$ref_errorCode,
(0x1703+ 1784-0x1dfa)));}sub Common::NXFile::setOwnershipForUser{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $userName=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x18ca+ 3239-0x2571)));(my $returnVal=(-(0x046b+ 166-0x0510)));if (($silent==
(0x0694+ 2290-0x0f86))){if (($path eq (""))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x2e"
);return ($returnVal);}if (($userName eq (""))){Logger::warning (((
"\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20"
.$path)."\x2e"));return ($returnVal);}}(my $sid=(""));if ((
Common::NXCore::isEffectiveUsernameSystem ()and ($userName eq 
Common::NXCore::getEffectiveUsername ()))){($sid=$GLOBAL::WindowsSIDStringSystem
);}else{($sid=Common::NXCore::userInfoGetUidByUsername ($userName));}($returnVal
=setOwnershipForUser_windows ($path,$sid,$ref_errorName,$ref_errorCode,$silent))
;return ($returnVal);}sub Common::NXFile::setOwnershipForUserSilent{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $userName=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));return (setOwnershipForUser ($path,
$userName,$ref_errorName,$ref_errorCode,(0x1382+ 239-0x1470)));}sub 
Common::NXFile::setOwnershipForOwnerFile{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $fileToGetOwner=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x022c+ 1298-0x073e)));(my ($dev,$ino,
$mode,$nlink,$uid,$gid)=Common::NXCore::NXStat ($fileToGetOwner));(my $returnVal
=(-(0x0b79+ 2058-0x1382)));if (($silent==(0x19cf+ 2742-0x2485))){if (($path eq 
(""))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x2e"
);return ($returnVal);}if (($uid eq (""))){Logger::warning (((
"\x55\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20"
.$path)."\x2e"));return ($returnVal);}}($returnVal=setOwnershipForUser_windows (
$path,$uid,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionsReadWriteForNX{package Common::NXFile;no warnings;
(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (
@_));(my $silent=(shift (@_)||(0x17e7+ 914-0x1b79)));(my $returnVal=(-
(0x12d1+ 2185-0x1b59)));($returnVal=setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringAdmins,($GLOBAL::FullPermission.
$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent));if ((setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringSystem,$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent)==(-(0x0bba+ 2649-0x1612)))){($returnVal=(
-(0x1172+ 3856-0x2081)));}return ($returnVal);}sub 
Common::NXFile::setPermissionsReadWriteForNXSilent{package Common::NXFile;no 
warnings;(my $dbFilePath=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));return (setPermissionsReadWriteForNX ($dbFilePath,$ref_errorName,
$ref_errorCode,(0x081d+ 6961-0x234d)));}sub 
Common::NXFile::setPermissionReadOnlyForNX{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x0b72+ 7062-0x2708)));(my $returnVal=(-(0x008d+ 607-0x02eb)));(
$returnVal=setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,(
$GLOBAL::ReadWritePermission.$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringSystem,
$GLOBAL::ReadWritePermission,$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent)==(-(0x0d22+ 6155-0x252c)))){($returnVal=(-
(0x09c1+ 4476-0x1b3c)));}return ($returnVal);}sub 
Common::NXFile::setPermissionReadOnlyForNXSilent{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));return (setPermissionReadOnlyForNX ($path,$ref_errorName,
$ref_errorCode,(0x194b+ 2549-0x233f)));}sub 
Common::NXFile::setPermissionsReadOnlyForUser{package Common::NXFile;no warnings
;(my $path=shift (@_));(my $sid=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0e67+ 846-0x11b5)));(my $returnVal=(-
(0x09a1+ 6262-0x2216)));($returnVal=setPermissions_windows ($path,$sid,(
$GLOBAL::FullPermission.$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForNX{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x0251+ 4850-0x1543)));(my $returnVal=(-(0x0925+ 4063-0x1903)));(
$returnVal=setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,(
$GLOBAL::FullPermission.$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent));if ((setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringSystem,$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent)==(-(0x0dd4+ 3499-0x1b7e)))){($returnVal=(
-(0x056b+ 1498-0x0b44)));}return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForNXDirectory{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x07ef+ 7342-0x249d)));(my $returnVal=(-
(0x0531+ 1753-0x0c09)));($returnVal=setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringAdmins,($GLOBAL::FullPermission.
$GLOBAL::ClearOldPermissions),($NXBITS::CONTAINER_INHERIT | $NXBITS::OBJECT_INHERIT), $ref_errorName, $ref_errorCode, $silent));
 if
 ((setPermissions_windows ($path,$GLOBAL::WindowsSIDStringSystem,
$GLOBAL::FullPermission,($NXBITS::CONTAINER_INHERIT | $NXBITS::OBJECT_INHERIT), $ref_errorName, $ref_errorCode, $silent) == (-1))) {
 (
$returnVal=(-(0x04fd+ 1138-0x096e)));}return ($returnVal);}sub 
Common::NXFile::setOwnerShipNXAndFullPermissions{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x1846+ 2351-0x2175)));(my $returnVal=
setOwnershipForUserNX ($path,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissionsFullForNX ($path,$ref_errorName,$ref_errorCode,$silent)==(-
(0x0f09+ 1711-0x15b7)))){($returnVal=(-(0x00b7+ 5237-0x152b)));}return (
$returnVal);}sub Common::NXFile::setPermissionsReadWriteForAllReportToStderr{
package Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x17df+ 613-0x1a44)));(my $returnVal=(-(0x1d53+ 1309-0x226f)));($returnVal=
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAllUsers,(
$GLOBAL::ReadWritePermission.$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if (($returnVal
==(-(0x0b6d+ 1447-0x1113)))){main::nxwrite (main::nxgetSTDERR (),((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$path).
"\x20\x74\x6f\x20\x52\x65\x61\x64\x2d\x57\x72\x69\x74\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e\x0a"));}return ($returnVal
);}sub 
Common::NXFile::setPermissionsReadWriteForOwnerAndGroupWriteForAllReportToStderr
{package Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x15b7+  43-0x15e2)));(my $returnVal=(-(0x08c7+ 5458-0x1e18)));($returnVal=
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAllUsers,(
$GLOBAL::ReadWritePermission.$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if (($returnVal
==(-(0x1e81+ 1798-0x2586)))){main::nxwrite (main::nxgetSTDERR (),((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$path).
"\x20\x74\x6f\x20\x52\x65\x61\x64\x2d\x57\x72\x69\x74\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e\x0a"));}return ($returnVal
);}sub Common::NXFile::setPermissionsFullForAllDirectory{package Common::NXFile;
no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0f6c+ 3696-0x1ddc)));(my $returnVal=(-
(0x0c92+ 1975-0x1448)));(my $returnVal=setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringAllUsers,($GLOBAL::FullPermission.
$GLOBAL::ClearOldPermissions),($NXBITS::CONTAINER_INHERIT | $NXBITS::OBJECT_INHERIT), $ref_errorName, $ref_errorCode, $silent));
 return
 ($returnVal);}sub 
Common::NXFile::setPermissionsInheritAndAllowTakeOwnershipIfNeeded{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x08a0+ 3822-0x178e)));
(my $returnVal=(-(0x16a3+ 1395-0x1c15)));(my $sid=(""));($returnVal=
setPermissions_windows ($path,$sid,($GLOBAL::InheritPermission.
$GLOBAL::AllowTakeOwnershipIfNeeded),(0x0a21+ 6273-0x22a2),$ref_errorName,
$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionsInherit{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x11f5+ 4175-0x2244)));(my $returnVal=(-(0x11d9+ 5143-0x25ef)));(my $sid
=(""));($returnVal=setPermissions_windows ($path,$sid,$GLOBAL::InheritPermission
,(0x01fd+ 2323-0x0b10),$ref_errorName,$ref_errorCode,$silent));return (
$returnVal);}sub Common::NXFile::setPermissionsFullForUserDirectory{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x1031+ 1256-0x1519)));(my $returnVal=(-(0x00b6+ 8150-0x208b)));(my $sid=
Common::NXCore::userInfoGetUidByUsername ($user));($returnVal=
setPermissions_windows ($path,$sid,$GLOBAL::FullPermission,(
$NXBITS::CONTAINER_INHERIT | $NXBITS::OBJECT_INHERIT), $ref_errorName, $ref_errorCode, $silent));
 return
 ($returnVal);}sub Common::NXFile::setPermissionsUserNodeRootDirectory{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x200a+ 1232-0x24da)));(my $returnVal=(-(0x119c+ 1655-0x1812)));(my $sid=
Common::NXCore::userInfoGetUidByUsername ($user));($returnVal=
setPermissions_windows ($path,$sid,($GLOBAL::FullPermission.
$GLOBAL::ClearOldPermissions),($NXBITS::CONTAINER_INHERIT | $NXBITS::OBJECT_INHERIT), $ref_errorName, $ref_errorCode, $silent));
 if
 ((setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,
$GLOBAL::FullPermission,($NXBITS::CONTAINER_INHERIT | $NXBITS::OBJECT_INHERIT), $ref_errorName, $ref_errorCode, $silent) == (-1))) {
 (
$returnVal=(-(0x041a+ 8265-0x2462)));}if ((setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringSystem,$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent)==(-(0x0286+ 6694-0x1cab)))){($returnVal=(
-(0x0707+ 4379-0x1821)));}return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForUser{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $user=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x182b+ 637-0x1aa8)));(my $returnVal=(-
(0x1a21+ 2748-0x24dc)));(my $sid=Common::NXCore::userInfoGetUidByUsername ($user
));($returnVal=setPermissions_windows ($path,$sid,($GLOBAL::FullPermission.
$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionsReadWriteForUserAndAdmin{package Common::NXFile;no
 warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName=shift (
@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x1155+ 1467-0x1710)));(my $returnVal=(-(0x0671+ 6361-0x1f49)));(my $sid=
Common::NXCore::userInfoGetUidByUsername ($user));($returnVal=
setPermissions_windows ($path,$sid,($GLOBAL::ReadWritePermission.
$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent));if ((setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringAdmins,$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent)==(-(0x1b8f+ 1643-0x21f9)))){($returnVal=(
-(0x1252+ 744-0x1539)));}if ((setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringSystem,$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent)==(-(0x04a0+ 6423-0x1db6)))){($returnVal=(
-(0x1466+ 3421-0x21c2)));}return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForAll{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x0d11+ 3907-0x1c54)));(my $returnVal=(-(0x0e63+ 1548-0x146e)));(
$returnVal=setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAllUsers,(
$GLOBAL::FullPermission.$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,
$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionReadExecutableForAll{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0203+ 7167-0x1e02)));(my $returnVal=
(0x0e6f+ 4677-0x20b4));($returnVal=setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringAllUsers,($GLOBAL::FullPermission.
$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionFullForOwnerReadExecuteForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x150d+ 3221-0x21a2)));
(my $returnVal=(-(0x13a7+ 3848-0x22ae)));($returnVal=setPermissions_windows (
$path,$GLOBAL::WindowsSIDStringAllUsers,(($GLOBAL::ReadPermission.
$GLOBAL::ExecutePermission).$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,
$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,
$silent)==(-(0x01c4+ 2890-0x0d0d)))){($returnVal=(-(0x0637+ 8295-0x269d)));}if (
(setPermissions_windows ($path,$GLOBAL::WindowsSIDStringSystem,
$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,
$silent)==(-(0x11c2+ 1963-0x196c)))){($returnVal=(-(0x20cc+ 537-0x22e4)));}
return ($returnVal);}sub Common::NXFile::setPermissionReadWriteForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x06f6+ 6362-0x1fd0)));
(my $returnVal=(-(0x01a3+ 9072-0x2512)));($returnVal=setPermissions_windows (
$path,$GLOBAL::WindowsSIDStringAllUsers,($GLOBAL::ReadWritePermission.
$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0219+ 2227-0x0acc)));
(my $returnVal=(-(0x1c2c+ 1708-0x22d7)));($returnVal=setPermissions_windows (
$path,$GLOBAL::WindowsSIDStringAllUsers,(($GLOBAL::ReadPermission.
$GLOBAL::ExecutePermission).$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,
$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,
$silent)==(-(0x04fa+ 7186-0x210b)))){($returnVal=(-(0x0128+ 3687-0x0f8e)));}if (
(setPermissions_windows ($path,$GLOBAL::WindowsSIDStringSystem,
$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,
$silent)==(-(0x12e3+ 2125-0x1b2f)))){($returnVal=(-(0x1d39+ 1079-0x216f)));}
return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAllForce{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x22d1+  81-0x2322)));(my $returnVal
=(-(0x0b51+ 466-0x0d22)));($returnVal=setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringAllUsers,(($GLOBAL::ReadPermission.
$GLOBAL::ExecutePermission).$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,
$GLOBAL::FullForcePermission,$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent)==(-(0x1156+ 4400-0x2285)))){($returnVal=(-
(0x1b98+ 1543-0x219e)));}if ((setPermissions_windows ($path,
$GLOBAL::WindowsSIDStringSystem,$GLOBAL::FullForcePermission,
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent)==(-
(0x08a6+ 7749-0x26ea)))){($returnVal=(-(0x0e73+ 4136-0x1e9a)));}return (
$returnVal);}sub Common::NXFile::setPermission{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $permissions=shift (@_));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x1023+ 253-0x1120)));(my $returnVal=(0x1bc4+ 1954-0x2366));(my $AllUsersPermission
=(($NXBits::UserReadWrite+$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite));if
 (($permissions==$AllUsersPermission)){($returnVal=setPermissions_windows ($path
,$GLOBAL::WindowsSIDStringAllUsers,($GLOBAL::ReadWritePermission.
$GLOBAL::ClearOldPermissions),$NXBits::NO_INHERITANCE,$ref_errorName,
$ref_errorCode,$silent));}if (($permissions==$NXBits::UserReadWrite)){(my $effective_user
=Common::NXCore::getEffectiveUsername ());if (($effective_user eq "\x6e\x78")){(
$returnVal=setPermissionsReadWriteForNX ($path,$ref_errorName,$ref_errorCode,
$silent));}}(my $comparePermission=(($NXBits::UserReadWrite+$NXBits::GroupRead)+
$NXBits::OthersRead));if (($permissions==$comparePermission)){($returnVal=
setPermissionReadWriteForOwnerReadOnlyForAll ($path,$ref_errorName,
$ref_errorCode,$silent));}return ($returnVal);}sub 
Common::NXFile::setPermissionSilent{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $permissions=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(0x065f+ 4447-0x17bd));return (setPermission ($path,
$permissions,$ref_errorName,$ref_errorCode,$silent));}sub 
Common::NXFile::setOwnerShipAndPermissionsForNX{package Common::NXFile;no 
warnings;(my $dbFilePath=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x1143+  72-0x118b)));(my $returnVal=
setOwnershipForUserNX ($dbFilePath,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissionsReadWriteForNX ($dbFilePath,$ref_errorName,$ref_errorCode,$silent)
==(-(0x0b57+ 3337-0x185f)))){($returnVal=(-(0x1006+ 5094-0x23eb)));}return (
$returnVal);}sub Common::NXFile::setOwnerShipAndPermissionsForUserAndGroupNX{
package Common::NXFile;no warnings;(my $dbFilePath=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x0087+ 5842-0x1759)));(my $returnVal=setOwnershipForUserAndGroupNX (
$dbFilePath,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissionsReadWriteForNX ($dbFilePath,$ref_errorName,$ref_errorCode,$silent)
==(-(0x1131+ 2655-0x1b8f)))){($returnVal=(-(0x1062+ 1697-0x1702)));}return (
$returnVal);}sub Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX{package
 Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_))
;(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0b55+ 1681-0x11e6)))
;(my $returnVal=setOwnershipForUserNX ($path,$ref_errorName,$ref_errorCode,
$silent));if ((setPermissionReadOnlyForNX ($path,$ref_errorName,$ref_errorCode,
$silent)==(-(0x1aa7+ 2520-0x247e)))){($returnVal=(-(0x0258+ 527-0x0466)));}
return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForOwnerAndGroupWriteForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x1d29+ 1743-0x23f8)));
(my $returnVal=(-(0x0c2d+ 1604-0x1270)));($returnVal=setPermissions_windows (
$path,$GLOBAL::WindowsSIDStringAllUsers,(($GLOBAL::ReadPermission.
$GLOBAL::ExecutePermission).$GLOBAL::ClearOldPermissions),
$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissions_windows ($path,$GLOBAL::WindowsSIDStringAdmins,
$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,
$silent)==(-(0x0a9a+ 4233-0x1b22)))){($returnVal=(-(0x125f+ 5088-0x263e)));}if (
(setPermissions_windows ($path,$GLOBAL::WindowsSIDStringSystem,
$GLOBAL::FullPermission,$NXBits::NO_INHERITANCE,$ref_errorName,$ref_errorCode,
$silent)==(-(0x0f81+ 1328-0x14b0)))){($returnVal=(-(0x1324+ 3817-0x220c)));}
return ($returnVal);}sub Common::NXFile::directoryExists{package Common::NXFile;
no warnings;(my $path=shift (@_));($path=~ s/\\$// );if ((
libnxh::NXDirectoryExists ($path)==(0x0044+ 4650-0x126d))){return (
(0x209c+ 305-0x21cc));}return ((0x1c9d+ 683-0x1f48));}sub 
Common::NXFile::fileExists{package Common::NXFile;no warnings;(my $path=shift (
@_));if ((libnxh::NXFileExists ($path)==(0x1171+ 4291-0x2233))){return (
(0x094d+ 2200-0x11e4));}return ((0x027b+ 5406-0x1799));}sub 
Common::NXFile::isExists{package Common::NXFile;no warnings;(my $path=shift (@_)
);if ((libnxh::NXExists ($path)==(0x0e3f+ 1804-0x154a))){return (
(0x0343+ 9001-0x266b));}return ((0x2107+ 309-0x223c));}sub 
Common::NXFile::removeFile{package Common::NXFile;no warnings;(my $path=shift (
@_));(my $silent=shift (@_));(my $ref_error=shift (@_));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x52\x65\x6d\x6f\x76\x65\x28"
.$path)."\x29"));if ((libnxh::NXFileRemove ($path)!=(0x0497+ 4026-0x1451))){(my $errorString
=libnxh::NXGetErrorString ());(my $errorCode=libnxh::NXGetError ());if (($silent
!=(0x010f+ 8071-0x2095))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x27"
.$path)."\x27"));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x20".
$errorCode)."\x2c\x20\x27").$errorString)."\x27"));}($$ref_error=$errorString);
return ((0x0f10+ 1879-0x1667));}return ((0x042c+ 5921-0x1b4c));}sub 
Common::NXFile::renameFile{package Common::NXFile;no warnings;(my $oldName=shift
 (@_));(my $newName=shift (@_));(my $silent=shift (@_));(my $ref_error=shift (@_
));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x52\x65\x6e\x61\x6d\x65\x28"
.$oldName)."\x2c\x20").$newName)."\x29"));if ((libnxh::NXFileRename ($oldName,
$newName)!=(0x091a+ 2463-0x12b9))){(my $errorString=libnxh::NXGetErrorString ())
;(my $errorCode=libnxh::NXGetError ());if (($silent!=(0x064c+ 7170-0x224d))){
Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$oldName)."\x27\x20\x74\x6f\x20\x27").$newName)."\x27"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorCode)."\x2c\x20\x27").$errorString)
."\x27"));}($$ref_error=$errorString);return ((0x04e2+ 2206-0x0d80));}return (
(0x1ae9+ 3000-0x26a0));}sub Common::NXFile::createFileReadWriteByAll{package 
Common::NXFile;no warnings;(my $file=shift (@_));(my $ref_error=shift (@_));(my $createHandle
=main::nxopen ($file,$NXBits::O_CREAT,(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite)));if ((not (defined (
$createHandle)))){($$ref_error=libnxh::NXGetErrorString ());return (
(0x0c32+ 2082-0x1454));}main::nxclose ($createHandle);return (
(0x0cfd+ 4869-0x2001));}sub 
Common::NXFile::createFileReadWriteByUserReadByGroupOthers{package 
Common::NXFile;no warnings;(my $file=shift (@_));(my $ref_error=shift (@_));(my $createHandle
=main::nxopen ($file,$NXBits::O_CREAT,(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead)));if ((not (defined ($createHandle)))){
($$ref_error=libnxh::NXGetErrorString ());return ((0x0092+ 514-0x0294));}
main::nxclose ($createHandle);return ((0x1ac2+ 2682-0x253b));}sub 
Common::NXFile::isSameFile{package Common::NXFile;no warnings;(my $fd1=shift (@_
));(my $fd2=shift (@_));if ((libnxh::NXIsSameFile ($fd1,$fd2)==
(0x1806+ 3238-0x24ab))){return ((0x06f3+ 5682-0x1d24));}return (
(0x099f+ 4321-0x1a80));}sub Common::NXFile::compressFile{package Common::NXFile;
no warnings;(my $source=shift (@_));(my $destination=shift (@_));(my $silent=
shift (@_));if ((libnxh::NXCompressFile ($source,$destination)!=
(0x0494+ 1562-0x0aad))){(my $errorString=libnxh::NXGetErrorString ());(my $errorCode
=libnxh::NXGetError ());if (($silent!=(0x01ac+ 4806-0x1471))){Logger::warning ((
(((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6d\x70\x72\x65\x73\x73\x20\x66\x69\x6c\x65\x20\x27"
.$source)."\x27\x20\x74\x6f\x20\x27").$destination)."\x27\x2e"));Logger::warning
 ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorCode)."\x2c\x20\x27").
$errorString)."\x27"));}return ((0x232a+  82-0x237c));}return (
(0x015b+ 1236-0x062e));}sub Common::NXFile::getFileContent{package 
Common::NXFile;no warnings;(my $file=shift (@_));Logger::debug (((
"\x4e\x58\x46\x69\x6c\x65\x3a\x20\x47\x65\x74\x20\x66\x69\x6c\x65\x20\x27".$file
)."\x27\x20\x63\x6f\x6e\x74\x65\x6e\x74\x2e"));(my $fileBody=undef);unless (
fileExists ($file)){return ($fileBody);}(my $fileHandle=main::nxopen ($file,
$NXBits::O_RDONLY));unless (defined ($fileHandle)){return ($fileBody);}while (
main::nxreadLine ($fileHandle,(\$_))){($fileBody.=$_);}main::nxclose (
$fileHandle);return ($fileBody);}sub 
Common::NXFile::setFileContentCreateIfNeeded{package Common::NXFile;no warnings;
(my $file=shift (@_));(my $content=shift (@_));(my $rights=shift (@_));(my $fileHandle
=main::nxopen ($file,(($NXBits::O_WRONLY+$NXBits::O_TRUNC)+$NXBits::O_CREAT),
$rights));unless (defined ($fileHandle)){return ((0x1aaa+ 2626-0x24ec));}if ((
main::nxwrite ($fileHandle,$content)==(-(0x01f2+ 8714-0x23fb)))){main::nxclose (
$fileHandle);return ((0x1357+ 4589-0x2544));}main::nxclose ($fileHandle);return 
((0x01a2+ 1943-0x0938));}sub Common::NXFile::truncateFile{package Common::NXFile
;no warnings;(my $filePath=shift (@_));(my $handle=main::nxopen ($filePath,(
$NXBits::O_WRONLY+$NXBits::O_TRUNC)));if (defined ($handle)){main::nxclose (
$handle);return ((0x1a82+ 131-0x1b04));}return ((0x04df+ 529-0x06f0));}sub 
Common::NXFile::setServerLogFilePermissions{package Common::NXFile;no warnings;(my $path
=Common::NXPaths::getNXServerLogPath ());return (
setServerOrErrorLogFilePermissions ($path));}sub 
Common::NXFile::setServerOrErrorLogFilePermissions{package Common::NXFile;no 
warnings;(my $path=shift (@_));if (($GLOBAL::CommonLogDirectory eq (""))){if (
Common::NXCore::isEffectiveUserNXRootOrSystem ()){setPermissionsReadWriteForNX (
$path);if (Common::NXCore::isEffectiveUsernameRoot ()){setOwnershipForUserNX (
$path);}}else{(my $user=Common::NXCore::getEffectiveUsername ());
setPermissionsReadWriteForUserAndAdmin ($path,$user);}}else{
setCommonServerOrErrorLogFilePermissionsAndOwner ($path);}}sub 
Common::NXFile::setCommonServerOrErrorLogFilePermissionsAndOwner{package 
Common::NXFile;no warnings;(my $path=shift (@_));if (
Common::NXCore::isEffectiveUsernameRoot ()){
setPermissionReadWriteForOwnerAndGroupWriteForAll ($path);}}sub 
Common::NXFile::getServerLogFilePermissions{package Common::NXFile;no warnings;
if (($GLOBAL::CommonLogDirectory ne (""))){(my $permissions=
$NXBits::UserReadWrite);($permissions+=$NXBits::GroupReadWrite);($permissions+=
$NXBits::OthersWrite);return ($permissions);}else{return ($NXBits::UserReadWrite
);}}package Common::NXFile;no warnings;"\x3f\x3f\x3f";
