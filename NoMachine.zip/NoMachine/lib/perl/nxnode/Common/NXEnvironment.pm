############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXEnvironment::getPathVariableWithoutNXPaths{package 
Common::NXEnvironment;no warnings;(my $oldPath=$ENV{"\x50\x41\x54\x48"});(my $path
=($GLOBAL::PathBin.$GLOBAL::PATH_ENVIRONMENT_SEPARATOR));if (($oldPath eq ("")))
{($path.=$GLOBAL::DefaultPath);}else{(my $pathWithoutNXPaths=
removeNXPathsFromPathEnvironment ($oldPath));($path.=$pathWithoutNXPaths);}
return ($path);}sub Common::NXEnvironment::removeNXPathsFromPathEnvironment{
package Common::NXEnvironment;no warnings;(my $path=shift (@_));if (($path=~ /(.*);C:.Program Files.NoMachine.bin/ )
){($path=$1);}return ($path);}package Common::NXEnvironment;no warnings;
"\x3f\x3f\x3f";
