############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXMsg::BEGIN{package Common::NXMsg;no warnings;require 
Common::NXError;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x45\x72\x72\x6f\x72"->import};}package
 Common::NXMsg;no warnings;($GLOBAL::Common::NXMsg::__inBuffer=(""));(
$typeResponse=(0x11b3+ 2840-0x1ccb));($typeRequest=(0x1b36+ 1928-0x22bd));(
$typeError=(0x1c4f+ 255-0x1d4c));sub BEGIN{require Common::NXTranslator;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x54\x72\x61\x6e\x73\x6c\x61\x74\x6f\x72"
->import};}sub __sprinf_reg_exp{(my $format=shift (@_));(my $name=shift (@_));(my (
@message_parameters)=@_);for ((my $i=(0x0d61+ 6239-0x25c0));($i<=$#message_parameters
);(++$i)){($message_parameters[$i]=~ s/^\n//gm );($message_parameters[$i]=~ s/\n$//gm )
;}(my $message=sprintf ($format,@message_parameters));($message=~ s/\n/\n        /gm )
;return ($message);}sub check_msg{(my $index=shift (@_));(my (@parameters)=@_);
if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){
return ((0x191f+ 1687-0x1fb6));}(my $messageNumber=getNumber ($index));if ((not 
(defined ($messageNumber)))){return ((0x03d8+ 8916-0x26ac));}return (
(0x1770+ 2117-0x1fb4));}sub get_msg{(my $index=shift (@_));(my (@parameters)=@_)
;if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){
return ((0x1e0b+ 544-0x202b));}(my $messageNumber=getNumber ($index));if ((not (
defined ($messageNumber)))){return ((0x0e49+ 703-0x1108));}if (($messageNumber==
(0x259d+ 180-0x2651))){($messageNumber=$GLOBAL::MSG_ERROR);}for ((my $i=
(0x03a1+ 8804-0x2605));($i<=$#parameters);(++$i)){($parameters[$i]=~ s/^\n//gm )
;($parameters[$i]=~ s/\n$//gm );}(my $message=(""));if (
Common::NXEnglishMessages::isCustomizableMessage ($index)){(($messageNumber,
$index,$message)=getCustomizedMessage ($index,$messageNumber,(\@parameters)));}
else{($message=Common::NXEnglishMessages::getMessage ($index));}if (
__shouldPackMessage ($index)){($message=constructMessage ($messageNumber,
$message,@parameters));(my $packedMessage=packResponse ($index,$message,
@parameters));return ((""),$packedMessage);}if ((not (
NXBegin::isModuletypeNxnode ()))){Common::NXTranslator::translate ($index,(
\$message));}($message=constructMessage ($messageNumber,$message,@parameters));(my $regExp
=getRegExp ($index));return ($regExp,$message);}sub constructMessage{(my $messageNumber
=shift (@_));(my $message=shift (@_));(my (@parameters)=@_);(my $fullMessage=
(""));(my $messageHead="\x4e\x58\x3e\x20");(my $messageFormat=(($messageHead.
"\x25\x69\x20").$message));if (($message ne (""))){($fullMessage=sprintf (
$messageFormat,$messageNumber,@parameters));($fullMessage=~ s/\n/\n$messageHead$messageNumber /gm )
;}return ($fullMessage);}sub send_response{(my $newline=(0x0191+ 1054-0x05ae));
__sendResponse ($newline,@_);}sub send_response_no_newline{(my $newline=
(0x04f0+ 282-0x060a));__sendResponse ($newline,@_);}sub __sendResponse{(my $newline
=shift (@_));(my $index=$_[(0x02a2+ 342-0x03f8)]);if (isErrorTypeByIndex ($index
)){return (error (@_));}(my ($reg_exp,$message)=get_msg (@_));Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));if ($newline){($message.="\x0a");}main::nxwrite (
main::nxgetSTDOUT (),$message);}sub get_text_msg{(my $index=shift (@_));(my $translate
=shift (@_));(my (@parameters)=@_);for ((my $i=(0x1d99+ 1282-0x229b));($i<=$#parameters
);(++$i)){($parameters[$i]=~ s/^\n//gm );($parameters[$i]=~ s/\n$//gm );}if (((
not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){
Logger::warning (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x55\x6e\x6b\x6e\x6f\x77\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x69\x6e\x64\x65\x78\x20\x27"
.$index)."\x27\x2e"));return ((""));}(my $messageText=(""));if ((($translate==
(0x0513+ 1795-0x0c16))or (Common::NXTranslator::translate ($index,(\$messageText
))==(0x0469+ 7004-0x1fc5)))){($messageText=Common::NXEnglishMessages::getMessage
 ($index));Logger::debug3 (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$messageText)."\x27\x2e"));}(my $message=(""));if (($messageText ne (""))){(
$message=sprintf ($messageText,@parameters));}return ($message);}sub get_text{(my $indexString
=shift (@_));(my (@parameters)=@_);(my $translate=(0x0c24+ 1785-0x131c));return 
(get_text_msg ($indexString,$translate,@parameters));}sub getEnglishText{(my $indexString
=shift (@_));(my (@parameters)=@_);(my $translate=(0x04f2+ 8254-0x2530));return 
(get_text_msg ($indexString,$translate,@parameters));}sub getEnglishTextOneLine{
(my $text=getEnglishText (@_));($text=~ s/\n/ /gm );return ($text);}sub 
sendLogMessage{(my $message=shift (@_));(my $level=shift (@_));(my $storeInHistory
=shift (@_));if (Logger::isErrorLevel ($level)){Logger::error ($message,
$storeInHistory);}elsif (Logger::isWarningLevel ($level)){Logger::warning (
$message,$storeInHistory);}elsif (Logger::isInfoLevel ($level)){Logger::info (
$message,$storeInHistory);}else{Logger::debug ($message,$storeInHistory);}}sub 
__warning{(my $log_level=shift (@_));(my ($reg_exp,$message)=get_msg (@_));if ((
defined ($reg_exp)and ($reg_exp eq (0x1404+ 2275-0x1ce6)))){(my $log_msg=
__sprinf_reg_exp ($reg_exp,@_));sendLogMessage ($log_msg,$log_level,
(0x0f06+ 4045-0x1ed0));}if (((defined ($reg_exp)and ($reg_exp ne ("")))and (
$reg_exp ne (0x07f3+ 5851-0x1ecd)))){(my $log_msg=__sprinf_reg_exp ($reg_exp,@_)
);sendLogMessage ($log_msg,$log_level,(0x01d1+ 7834-0x2068));}if (((not (defined
 ($message)))or ($message eq ("")))){(($reg_exp,$message)=get_msg (
"\x65\x47\x55\x49\x47\x65\x6e\x65\x72\x61\x6c"));}if (isPackedMessage ($message)
){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x63\x6b\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isInfoLevel ($log_level)){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x61\x6c\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isWarningLevel ($log_level)){($message=~ s/(^NX> \d+) *(.*)$/$1 WARNING: $2/gm )
;Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x77\x61\x72\x6e\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}else{($message=~ s/(^NX> \d+) *(.*)$/$1 ERROR: $2/gm );
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x65\x72\x72\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}main::nxwrite (main::nxgetSTDOUT (),($message."\x0a"));}sub
 fatal{__warning (Logger::getErrorLevel (),@_);NXShell::handle_command (
"\x65\x78\x69\x74");}sub error{__warning (Logger::getErrorLevel (),@_);}sub 
warning{__warning (Logger::getWarningLevel (),@_);}sub info{__warning (
Logger::getInfoLevel (),@_);}sub send_request{(my $pRegExp=shift (@_));(my $pMessage
=shift (@_));(my $value=shift (@_));(my ($reg_exp,$message)=get_msg ($pRegExp,
$pMessage,@_));if (defined ($value)){if (($reg_exp eq 
"\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($value=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$value);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x1fe4+  64-0x2004))){Logger::error (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c"
.sprintf ("\x5c\x30\x25\x6f",ord ($1))).
"\x2e\x20\x4e\x6f\x6e\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72"
));return (());}}}}elsif ((not (($value=~ /$reg_exp/ )))){Logger::error (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x76\x61\x6c\x75\x65\x20\x27"
.$value)."\x27"));return (());}return ($value);}if (($message=~ /^NX> (\d\d\d)  $/ )
){($message=(("\x4e\x58\x3e\x20".$1)."\x20"));}else{($message.="\x3a\x20");}
main::nxwrite (main::nxgetSTDOUT (),$message);Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));(my $data=__readnLine ());if ((not (defined ($data)))){
return (());}(my $log_data=$data);($log_data=~ s/(password=)([^&]*)/do {
        ($1 . ('*' x length($2)));
    };/eg )
;($log_data=~ s/(cookie=)([^&]*)/do {
        ($1 . ('*' x length($2)));
    };/eg )
;if (($pRegExp ne "\x63\x6f\x6d\x6d\x61\x6e\x64")){if ((($GLOBAL::PROTO_VERSION 
ne "\x73\x68\x65\x6c\x6c")and ($GLOBAL::PROTO_VERSION ne ("")))){main::nxwrite (
main::nxgetSTDOUT (),($data."\x0a"));}else{main::nxwrite (main::nxgetSTDOUT (),
"\x0a");}}Logger::debug (((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x4d\x73\x67\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$log_data)."\x27"));if (($reg_exp eq 
"\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($data=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$data);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x008c+ 7373-0x1d39))){Logger::error (((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x3a\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c").sprintf (
"\x5c\x30\x25\x6f",ord ($1))).
"\x20\x69\x73\x20\x61\x20\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x61\x6e\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x68\x65\x72\x65"
));return (());}}}}elsif ((not (($data=~ /$reg_exp/ )))){Logger::error (((((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$message)."\x3a\x20").$log_data).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x6d\x61\x74\x63\x68\x20\x77\x69\x74\x68\x20\x27"
).$reg_exp)."\x27"));main::nxwrite (main::nxgetSTDOUT (),"\x0a");return (());}if
 ((($data eq (""))and $GLOBAL::PROTO_VERSION)){main::nxwrite (main::nxgetSTDOUT 
(),"\x0a");}return ($data);}sub __error{main::nxwrite (main::nxgetSTDERR (),
"\x45\x72\x72\x6f\x72\x3a\x20\x66\x61\x74\x61\x6c\x20\x65\x72\x72\x6f\x72\x20\x69\x6e\x20\x6d\x6f\x64\x75\x6c\x65\x20\x4e\x58\x4d\x73\x67\x2c\x20\x63\x68\x65\x63\x6b\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x6d\x6f\x72\x65\x20\x64\x65\x74\x61\x69\x6c\x73\x0a"
);main::nxexit ((0x0d0c+ 4653-0x1f38));}sub __readnLine{(my $maxLengt=(shift (@_
)||(0x1216+ 6820-0x1cba)));(my $data=());(my $endOfLine=(0x096a+ 5858-0x204c));(my $ignoreUntileEOL
=(0x0fb7+ 4380-0x20d3));while ((not ($endOfLine))){(my $readBuff=());(my $bytesToRead
=($maxLengt-length ($GLOBAL::Common::NXMsg::__inBuffer)));if (($bytesToRead<=
(0x01a5+ 3197-0x0e22))){($GLOBAL::Common::NXMsg::__inBuffer=(""));(
$ignoreUntileEOL=(0x1bcc+ 2738-0x267d));Logger::error (
"\x4e\x58\x4d\x73\x67\x3a\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6d\x6f\x72\x65\x20\x74\x68\x61\x6e\x20\x34\x30\x39\x36\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73"
);main::nxwrite (main::nxgetSTDOUT (),(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ERROR_SERVING_REQUEST).
"\x20\x45\x52\x52\x4f\x52\x3a\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6d\x6f\x72\x65\x20\x74\x68\x61\x6e\x20\x34\x30\x39\x36\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73\x3a\x20\x69\x67\x6e\x6f\x72\x69\x6e\x67\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x63\x6f\x6d\x6d\x61\x6e\x64"
));}(my $readBytes=main::nxread (main::nxgetSTDIN (),$readBuff,
(0x24f7+ 160-0x2596)));if ((not (defined ($readBytes)))){(my $errorstring=
libnxh::NXGetErrorString ());main::nxwrite (main::nxgetSTDOUT (),"\x0a");
NXShell::setExitRequest ((
"\x46\x61\x69\x6c\x65\x64\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x3a\x20"
.$errorstring));return (());}if (($readBytes==(0x2487+ 458-0x2651))){
main::nxwrite (main::nxgetSTDOUT (),"\x0a");NXShell::setExitRequest (
$ExitRequests::closedSTDIN);return (());}if (($readBuff eq "\x0a")){((
$ignoreUntileEOL eq (0x0e4a+ 5446-0x238f))and ($ignoreUntileEOL=
(0x1a5a+ 945-0x1e0b)));($data=$GLOBAL::Common::NXMsg::__inBuffer);($endOfLine=
(0x0a75+ 5151-0x1e93));($GLOBAL::Common::NXMsg::__inBuffer=(""));}else{if ((
$ignoreUntileEOL eq (0x12e7+ 953-0x16a0))){($GLOBAL::Common::NXMsg::__inBuffer.=
$readBuff);}}}return ($data);}sub getBrandedMessage{(my $name=shift (@_));(my (
@message_parameters)=@_);if (((not (defined ($name)))or (not (($name=~ /^[\w\d\._-]{1,128}$/ )
)))){return ((0x0b45+ 7028-0x26b9));}(my $message=
Common::NXEnglishMessages::getMessage ($name));if (($message and scalar (
@message_parameters))){($message=sprintf ($message,@message_parameters));}(
$message=~ s/\n/ /gm );return ($message);}sub checkIfAnswerIsNo{(my $answer=
shift (@_));my ($currectShortAnswerForRequest);my ($currectLongAnswerForRequest)
;if (Common::NXTranslator::translate (
"\x61\x4c\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72\x4e\x6f",(
\$currectLongAnswerForRequest))){Common::NXTranslator::translate (
"\x61\x53\x68\x6f\x72\x74\x41\x6e\x73\x77\x65\x72\x4e\x6f",(
\$currectShortAnswerForRequest));}else{($currectShortAnswerForRequest="\x6e");(
$currectLongAnswerForRequest="\x6e\x6f");}if ((($answer eq 
$currectShortAnswerForRequest)or ($answer eq $currectLongAnswerForRequest))){
return ((0x1150+ 3069-0x1d4c));}return ((0x0a3c+ 511-0x0c3b));}sub 
checkIfAnswerIsYes{(my $answer=shift (@_));my ($currectShortAnswerForRequest);my (
$currectLongAnswerForRequest);if (Common::NXTranslator::translate (
"\x61\x4c\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72\x59\x65\x73",(
\$currectLongAnswerForRequest))){Common::NXTranslator::translate (
"\x61\x53\x68\x6f\x72\x74\x41\x6e\x73\x77\x65\x72\x59\x65\x73",(
\$currectShortAnswerForRequest));}else{($currectShortAnswerForRequest="\x79");(
$currectLongAnswerForRequest="\x79\x65\x73");}if ((($answer eq 
$currectShortAnswerForRequest)or ($answer eq $currectLongAnswerForRequest))){
return ((0x06b1+ 5616-0x1ca0));}return ((0x0e3d+ 266-0x0f47));}sub 
register_response{__register ($_[(0x0ced+ 5812-0x23a1)],$_[(0x124a+ 3389-0x1f86)
],getResponseType (),(""));}sub register_error{__register ($_[
(0x0665+ 2276-0x0f49)],$_[(0x084c+ 1856-0x0f8b)],getErrorType (),$_[
(0x164a+ 3462-0x23ce)]);}sub register_request{__register ($_[
(0x068a+ 4673-0x18cb)],$_[(0x0635+ 471-0x080b)],getRequestType (),$_[
(0x1411+ 3123-0x2042)]);}sub __register{(my $index=$_[(0x1ad7+ 2510-0x24a5)]);(my $number
=$_[(0x16d8+ 3958-0x264d)]);(my $type=$_[(0x21cb+ 726-0x249f)]);(my $regExp=$_[
(0x0c36+ 5003-0x1fbe)]);if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ )
)))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x6e\x64\x65\x78\x20\x73\x74\x72\x69\x6e\x67\x20"
.$index),(0x1ad8+  55-0x1b0d));__error ();}if (((not (defined ($number)))or (not
 (($number=~ /^[\d]{1,4}$/ ))))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6e\x75\x6d\x62\x65\x72\x20"
.$number),(0x09a2+ 2527-0x137f));__error ();}if ((((!defined ($regExp))||(
$regExp eq ("")))and isRequestType ($type))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x72\x65\x67\x45\x78\x70\x20"
.$regExp),(0x0ae9+ 3734-0x197d));__error ();}if (isMessageRegistered ($index)){
Logger::error ((("\x4e\x58\x4d\x73\x67\x3a\x20\x4d\x65\x73\x73\x61\x67\x65\x20".
$index).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x2e"
),(0x2388+ 457-0x254f));__error ();}saveMessageData (@_);}sub getNumber{(my $index
=shift (@_));if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ )
)))){return ((0x00e1+ 7233-0x1d22));}(my $messageNumber=$__number{$index});
return ($messageNumber);}sub getRegExp{(my $index=shift (@_));return ($__regExp{
$index});}sub isMessageRegistered{(my $index=shift (@_));(my $messageNumber=
getNumber ($index));if (defined ($messageNumber)){return ((0x0f37+ 2950-0x1abc))
;}return ((0x0a1a+ 4128-0x1a3a));}sub __shouldPackMessage{(my $index=shift (@_))
;if (isErrorMessage ($index)){if (NXBegin::isModuletypeNxnode ()){return (
NXShell::shellModeStarted ());}elsif (NXBegin::isModuletypeNxserver ()){return (
Server::isClientSupportsPackedMessages ());}}return ((0x1e0d+ 543-0x202c));}sub 
packResponse{(my $indexString=shift (@_));(my $message=shift (@_));(my (
@parameters)=@_);(my $messageId=Common::NXEnglishMessages::getMessageId (
$indexString));(my $pack=$messageId);($pack.=("\x2c".main::urlencode ($message))
);foreach my $parameter (@parameters){($pack.=("\x2c".main::urlencode (
$parameter)));}(my $message=(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_PACKED_RESPONSE)
."\x20").$pack)."\x20"));return ($message);}sub unpackResponse{(my $message=
shift (@_));(my ($indexString,$rawMessage,@parameters)=__unpackResponse (
$message));return ($indexString,$rawMessage,@parameters);}sub 
constructAndPackResponse{(my $indexString=shift (@_));(my (@parameters)=@_);(my $messageNumber
=getNumber ($indexString));(my $message=Common::NXEnglishMessages::getMessage (
$indexString));($message=constructMessage ($messageNumber,$message,@parameters))
;(my $packedMessage=packResponse ($indexString,$message,@parameters));return (
$packedMessage);}sub __unpackResponse{(my $message=shift (@_));(my $pack=(""));
if (($message=~ /NX> $GLOBAL::MSG_PACKED_RESPONSE (.*) / )){($pack=$1);}else{
return ((""),(0x11a4+ 1961-0x194d),(""),());}(my (@list)=split ( /,/ ,$pack,
(0x0c1b+ 5354-0x2105)));(my $messageId=shift (@list));(my $rawMessage=shift (
@list));($rawMessage=main::urldecode ($rawMessage));(my $indexString=
Common::NXEnglishMessages::getIndexString ($messageId));(my (@parameters)=());
foreach my $parameter (@list){push (@parameters,main::urldecode ($parameter));}
return ($indexString,$rawMessage,@parameters);}sub isErrorMessage{(my $indexString
=shift (@_));(my $messageNumber=getNumber ($indexString));return (
isErrorMessageNumber ($messageNumber));}sub isErrorMessageNumber{(my $messageNumber
=shift (@_));if ((($messageNumber>=(0x0ab7+ 5399-0x1dda))and ($messageNumber<=
(0x0f0d+ 4393-0x1d85)))){return ((0x0f5d+ 4123-0x1f77));}return (
(0x090a+ 2904-0x1462));}sub saveMessageData{(my $index=shift (@_));(my $number=
shift (@_));(my $type=shift (@_));(my $regExp=shift (@_));($__number{$index}=
$number);($__type{$index}=$type);($__regExp{$index}=$regExp);}sub 
isPackedMessage{(my $message=shift (@_));if (($message=~ /NX> (\d+)/ )){(my $number
=$1);return (isPackedMessageNumber ($number));}return ((0x03f8+ 7713-0x2219));}
sub isPackedMessageNumber{(my $number=shift (@_));if (($number==
$GLOBAL::MSG_PACKED_RESPONSE)){return ((0x16dd+ 3967-0x265b));}return (
(0x1eb4+ 1198-0x2362));}sub getErrorType{return ($typeError);}sub getRequestType
{return ($typeRequest);}sub getResponseType{return ($typeResponse);}sub 
isErrorTypeByIndex{(my $index=shift (@_));if (($__type{$index}==$typeError)){
return ((0x1249+ 4369-0x2359));}return ((0x00ec+ 6651-0x1ae7));}sub 
isRequestType{(my $type=shift (@_));if (($type==$typeRequest)){return (
(0x0db0+ 5605-0x2394));}return ((0x13a1+ 2174-0x1c1f));}sub 
isLastParameterCustomErrorMessage{(my $index=shift (@_));(my (@parameters)=@_);
if ((Common::NXEnglishMessages::getParamCount ($index)<scalar (@parameters))){
return ((0x060b+ 7429-0x230f));}return ((0x0408+ 8527-0x2557));}sub 
getCustomizedMessageIndexNumber{(my $customizedMessageIndex=
Common::NXEnglishMessages::getCustomizedMessageIndex ());(my $messageNumber=
getNumber ($customizedMessageIndex));(my $customizedMessage=
Common::NXEnglishMessages::getMessage ($customizedMessageIndex));return (
$customizedMessageIndex,$messageNumber,$customizedMessage);}sub 
getCustomizedMessage{(my $index=shift (@_));(my $messageNumber=shift (@_));(my $ref_parameters
=shift (@_));if (($GLOBAL::CustomErrorMessages ne (""))){return (
getCustomizedMessageByScript ($index,$messageNumber,$ref_parameters));}elsif (
isLastParameterCustomErrorMessage ($index,@$ref_parameters)){return (
getCustomizedMessageByParameter ($index,$messageNumber,$ref_parameters));}else{(my $message
=Common::NXEnglishMessages::getMessage ($index));return ($messageNumber,$index,
$message);}}sub getCustomizedMessageByParameter{(my $initialIndex=shift (@_));(my $initialMessageNumber
=shift (@_));(my $ref_parameters=shift (@_));(my $initialMessage=
Common::NXEnglishMessages::getMessage ($initialIndex));
Common::NXTranslator::translate ($initialIndex,(\$initialMessage));(
$initialMessage=sprintf ($initialMessage,@$ref_parameters));(my $lastIndex=
scalar ((@$ref_parameters-(0x068c+  25-0x06a4))));($customMessage=
$$ref_parameters[$lastIndex]);(my ($customizedMessageIndex,$messageNumber,
$customizedMessage)=getCustomizedMessageIndexNumber ());($customizedMessage=
sprintf ($customizedMessage,$initialMessage,$customMessage));return (
$messageNumber,$customizedMessageIndex,$customizedMessage);}sub 
getCustomizedMessageByScript{(my $initialIndex=shift (@_));(my $initialMessageNumber
=shift (@_));(my $ref_parameters=shift (@_));(my $initialMessage=
Common::NXEnglishMessages::getMessage ($initialIndex));
Common::NXTranslator::translate ($initialIndex,(\$initialMessage));(
$initialMessage=sprintf ($initialMessage,@$ref_parameters));(my $messageIdForScript
=Common::NXEnglishMessages::getCustomizableMessageId ($initialIndex));
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");(my $customMessage=
NXScripts::getCustomErrorMessage ($messageIdForScript));if (($customMessage ne 
(""))){(my ($customizedMessageIndex,$messageNumber,$customizedMessage)=
getCustomizedMessageIndexNumber ());if ((Server::isClientNxclient ()or 
Server::isClientNxwebclient ())){($customizedMessage=sprintf ($customizedMessage
,$initialMessage,$customMessage));return ($messageNumber,$customizedMessageIndex
,$customizedMessage);}else{push (@$ref_parameters,$customMessage);(
$customizedMessage=(($initialMessage."\x20").$customMessage));return (
$initialMessageNumber,$initialIndex,$customizedMessage);}}return (
$initialMessageNumber,$initialIndex,$initialMessage);}return (
(0x07ef+ 6835-0x22a1));
