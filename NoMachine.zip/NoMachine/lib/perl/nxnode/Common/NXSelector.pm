############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXSelector;no warnings;($NXSelector::globalSelector={});(
$NXSelector::timeoutCallbacks={});(@NXSelector::sortedTimeoutCallbacks=());(
$NXSelector::numberOfWaitingCallbacks=(0x051f+ 6044-0x1cbb));sub new{(my $self={
});($$self{"\x46\x44\x41\x52\x52\x41\x59"}=[]);bless ($self);return ($self);}sub
 add{(my $self=shift (@_));(my $FD_passed=shift (@_));(my $FD_correct=$FD_passed
);if (((not (defined ($FD_passed)))or ($FD_passed==(-(0x130a+ 216-0x13e1))))){(my (
$package,$filename,$line,$sub)=caller ((0x07b1+ 4278-0x1866)));if (($sub eq ("")
)){($sub=$package);}Logger::error (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x46\x44\x23"
.$FD_passed)."\x20\x66\x72\x6f\x6d\x20\x27").$sub)."\x27\x2e"));main::nxexit ();
}if (ref ($FD_passed)){if (($$FD_passed=~ /\*main::(\d+)/ )){($FD_correct=$1);}
else{(my ($package,$filename,$line,$sub)=caller ((0x0210+ 654-0x049d)));if ((
$sub eq (""))){($sub=$package);}Logger::error (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x27"
.$$FD_passed)."\x27\x20\x74\x6f\x20\x69\x6e\x74\x20\x66\x72\x6f\x6d\x20\x27").
$sub)."\x27\x2e"));main::nxexit ();}}if ($self->exists ($FD_correct)){(my (
$package,$filename,$line,$sub)=caller ((0x0a72+ 115-0x0ae4)));if (($sub eq (""))
){($sub=$package);}Logger::warning (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x73\x61\x6d\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$FD_correct)."\x20\x61\x67\x61\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").$sub).
"\x27\x2e"));return ((0x1946+ 815-0x1c74));}Logger::debug2 (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x46\x44\x23"
.$FD_correct)."\x20\x74\x6f\x20\x27").$self)."\x27\x2e"));unshift (@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};},$FD_correct);}sub exists{(my $self=shift (@_))
;(my $fd_check=shift (@_));foreach my $fd (@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};}){if (($fd_check==$fd)){return (
(0x0984+ 7227-0x25be));}}return ((0x216b+ 769-0x246c));}sub remove{(my $self=
shift (@_));(my $del_fd=shift (@_));if ((not (defined ($del_fd)))){(my ($package
,$filename,$line,$sub)=caller ((0x0354+ 1298-0x0865)));if (($sub eq (""))){($sub
=$package);}Logger::error (((
"\x53\x65\x6c\x65\x63\x74\x6f\x72\x20\x72\x65\x6d\x6f\x76\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x20\x66\x72\x6f\x6d\x3a\x20"
.$sub)."\x2e"));return ((0x01f7+ 6931-0x1d0a));}(my (@tmp)=());foreach my $fd (@
{$$self{"\x46\x44\x41\x52\x52\x41\x59"};}){if (($fd!=$del_fd)){push (@tmp,$fd);}
else{Logger::debug2 (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x46\x44\x23"
.$fd)."\x20\x66\x72\x6f\x6d\x20\x27").$self)."\x27\x2e"));}}(@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};}=@tmp);}sub can_read{(my $self=shift (@_));(my $timeout
=shift (@_));(my $silence=shift (@_));(my (@canRead)=@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};});addGlobalDescriptors ((\@canRead));if ((
scalar (@canRead)==(0x118f+ 3686-0x1ff5))){return (());}my (@resultArray);
main::nxselect ((\@canRead),$timeout,(\@resultArray),$silence);return (
@resultArray);}sub handles{(my $self=shift (@_));return (@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};});}sub count{(my $self=shift (@_));return (
scalar (@{$$self{"\x46\x44\x41\x52\x52\x41\x59"};}));}sub addToGlobalSelector{(my $FD
=shift (@_));(my $caption=shift (@_));(my $callback=shift (@_));if ((not (
defined ($FD)))){Logger::warning (
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x2e"
);return ((0x02cb+ 1502-0x08a9));}if (($FD<(0x02d9+ 6479-0x1c28))){
Logger::warning (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x62\x61\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x077a+ 2166-0x0ff0));}if (defined (
$$NXSelector::globalSelector{$FD})){Logger::debug (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x46\x44\x23"
.$FD)."\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x61\x64\x64\x65\x64\x2e"));return (
(0x172f+ 1767-0x1e16));}Logger::debug (((((((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x61\x64\x64\x69\x6e\x67\x20\x46\x44\x23"
.$FD)."\x20\x2d\x20").$caption).
"\x20\x77\x69\x74\x68\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20").$callback).
"\x2e"));($$NXSelector::globalSelector{$FD}={});($$NXSelector::globalSelector{
$FD}{"\x63\x61\x70\x74\x69\x6f\x6e"}=$caption);($$NXSelector::globalSelector{$FD
}{"\x63\x61\x6c\x6c\x62\x61\x63\x6b"}=$callback);return ((0x1141+ 2285-0x1a2d));
}sub removeFromGlobalSelector{(my $FD=shift (@_));if ((not (defined ($FD)))){
Logger::warning (
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x2e"
);return ((0x2387+ 200-0x244f));}if (($FD<(0x0e84+ 2135-0x16db))){
Logger::warning (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x20\x62\x61\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x03ad+ 5236-0x1821));}delete (
$$NXSelector::globalSelector{$FD});return ((0x0489+ 5460-0x19dc));}sub 
addGlobalDescriptors{(my $descriptorArray_ref=shift (@_));foreach my $FD (keys (
%$NXSelector::globalSelector)){(my $exist=(0x079a+ 3407-0x14e9));foreach my $addedFD
 (@$descriptorArray_ref){if (($FD==$addedFD)){($exist=(0x0af4+ 3091-0x1706));
last;}}if (($exist==(0x1a80+ 2254-0x234e))){push (@$descriptorArray_ref,$FD);}}}
sub handleGlobalSelectorDescriptor{(my $FD=shift (@_));if (defined (
$$NXSelector::globalSelector{$FD})){(my $callback=$$NXSelector::globalSelector{
$FD}{"\x63\x61\x6c\x6c\x62\x61\x63\x6b"});if (defined ($callback)){(my $caption=
$$NXSelector::globalSelector{$FD}{"\x63\x61\x70\x74\x69\x6f\x6e"});Logger::debug
 (((((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23"
.$FD)."\x20\x2d\x20").$caption)."\x2e"));&{$callback;}($FD);return (
(0x048d+ 6011-0x1c07));}}return ((0x0233+ 2157-0x0aa0));}sub 
countNonGlobalHandlers{(my $descriptorArray_ref=shift (@_));(my $count=
(0x0a94+ 4138-0x1abe));foreach my $FD (@$descriptorArray_ref){if ((not (defined 
($$NXSelector::globalSelector{$FD})))){(++$count);}}return ($count);}sub 
addTimestampCallback{(my $callback=shift (@_));(my $timestamp=shift (@_));(my $handler
=(shift (@_)||
"\x64\x65\x66\x61\x75\x6c\x74\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72"))
;unless (defined ($callback)){Logger::error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($handler)){
Logger::error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x68\x61\x6e\x64\x6c\x65\x72\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($timestamp)){
Logger::error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x2e"
);Logger::stackTrace ();main::nxexit ();}if (($timestamp<
Common::NXTime::getSecondsSinceEpoch ())){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20"
.$callback).
"\x2c\x20\x62\x65\x63\x75\x61\x73\x65\x20\x67\x69\x76\x65\x6e\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20"
).$timestamp)."\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x70\x61\x73\x73\x2e"));
return ((0x14ad+ 2038-0x1ca3));}if (defined ($$NXSelector::timeoutCallbacks{
$callback})){Logger::debug (((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20"
.$callback)."\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x61\x64\x64\x65\x64\x2e"));
return ((0x1716+ 2953-0x229f));}Logger::debug (((((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x61\x64\x64\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback).
"\x27\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27").
$timestamp)."\x27\x20\x61\x6e\x64\x20\x68\x61\x6e\x64\x6c\x65\x72\x20\x27").
$handler)."\x27\x2e"));($$NXSelector::timeoutCallbacks{$callback}={});(
$$NXSelector::timeoutCallbacks{$callback}{"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"
}=$timestamp);($$NXSelector::timeoutCallbacks{$callback}{
"\x68\x61\x6e\x64\x6c\x65\x72"}=$handler);insertCallbackInSortedArray ($callback
,$timestamp);(++$NXSelector::numberOfWaitingCallbacks);return (
(0x0278+ 7736-0x20af));}sub getNumberOfElementsInTimestampCallbackHash{return (
$NXSelector::numberOfWaitingCallbacks);}sub getTimestampForCallback{(my $callback
=shift (@_));return ($$NXSelector::timeoutCallbacks{$callback}{
"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"});}sub getFirstCallback{return (
$NXSelector::sortedTimeoutCallbacks[(0x0d3a+ 2902-0x1890)]);}sub 
handleAndRemoveTimestampCallback{(my $callback=shift (@_));if (defined (
$$NXSelector::timeoutCallbacks{$callback})){(my $handler=
$$NXSelector::timeoutCallbacks{$callback}{"\x68\x61\x6e\x64\x6c\x65\x72"});
removeFirstTimestampCallback ($callback);Logger::debug2 (((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x20\x77\x69\x74\x68\x20\x66\x75\x6e\x63\x74\x6f\x6e\x20\x27").
$handler)."\x27\x2e"));if (defined ($handler)){if (($handler eq 
"\x64\x65\x66\x61\x75\x6c\x74\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72"))
{NXEvent::handleEvent ($callback);}else{&{$handler;}();}return (
(0x0f2d+ 1841-0x165d));}}return ((0x2078+ 384-0x21f8));}sub 
removeFirstTimestampCallback{(my $callback=shift (@_));Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x2e"));(--$NXSelector::numberOfWaitingCallbacks);delete (
$$NXSelector::timeoutCallbacks{$callback});shift (
@NXSelector::sortedTimeoutCallbacks);return ((0x013c+  61-0x0178));}sub 
removeTimestampCallback{(my $callback=shift (@_));Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x2e"));for ((my $index=(0x009c+ 2745-0x0b55));($index<
$NXSelector::numberOfWaitingCallbacks);(++$index)){if ((
$$NXSelector::timeoutCallbacks{$callback}{"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"
}eq getTimestampForCallbackIndex ($index))){splice (
@NXSelector::sortedTimeoutCallbacks,$index,(0x1112+ 4394-0x223b));(--
$NXSelector::numberOfWaitingCallbacks);delete ($$NXSelector::timeoutCallbacks{
$callback});return;}}}sub findFirstHigherValueIndexInCallbackArray{(my $value=
shift (@_));if (($NXSelector::numberOfWaitingCallbacks==(0x2211+ 1127-0x2678))){
return ((0x16d3+ 3102-0x22f1));}elsif (($NXSelector::numberOfWaitingCallbacks==
(0x0ea1+ 6214-0x26e6))){if (($value<getFirstTimestampCallback ())){return (
(0x0641+ 4107-0x164c));}else{return ((0x0215+ 287-0x0333));}}else{for ((my $index
=(0x0baf+ 6562-0x2551));($index<$NXSelector::numberOfWaitingCallbacks);(++$index
)){if (($value<getTimestampForCallbackIndex ($index))){return ($index);}}return 
($NXSelector::numberOfWaitingCallbacks);}}sub insertCallbackInSortedArray{(my $callback
=shift (@_));(my $timestamp=shift (@_));(my $index=
findFirstHigherValueIndexInCallbackArray ($timestamp));splice (
@NXSelector::sortedTimeoutCallbacks,$index,(0x09d1+ 6565-0x2376),$callback);}sub
 getTimestampForCallbackIndex{(my $index=shift (@_));return (
getTimestampForCallback (getCallbackForIndex ($index)));}sub getCallbackForIndex
{(my $index=shift (@_));return ($NXSelector::sortedTimeoutCallbacks[$index]);}
sub getFirstTimestampCallback{(my $callback=getFirstCallback ());return (
getTimestampForCallback ($callback));}sub isAnyTimestampCallbackWaiting{return (
$NXSelector::numberOfWaitingCallbacks);}sub runFirstTimestampCallback{(my $callback
=getFirstCallback ());handleAndRemoveTimestampCallback ($callback);}sub 
changeCallback{(my $FD=shift (@_));(my $caption=shift (@_));(my $callback=shift 
(@_));if ((not (defined ($FD)))){Logger::warning (
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x2e"
);return ((0x08cd+ 7445-0x25e2));}if (($FD<(0x07c0+ 399-0x094f))){
Logger::warning (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x62\x61\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x0441+ 3430-0x11a7));}if ((not (defined (
$$NXSelector::globalSelector{$FD})))){Logger::debug (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x0b93+ 1889-0x12f4));}Logger::debug (((((((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x46\x44\x23"
.$FD)."\x20\x2d\x20").$caption).
"\x20\x77\x69\x74\x68\x20\x6e\x65\x77\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
).$callback)."\x27\x2e"));($$NXSelector::globalSelector{$FD}{
"\x63\x61\x70\x74\x69\x6f\x6e"}=$caption);($$NXSelector::globalSelector{$FD}{
"\x63\x61\x6c\x6c\x62\x61\x63\x6b"}=$callback);}"\x3f\x3f\x3f";
