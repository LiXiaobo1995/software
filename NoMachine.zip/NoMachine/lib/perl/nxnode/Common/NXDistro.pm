############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXDistro;no warnings;(@NXDistro::linux=("\x4c\x69\x6e\x75\x78",
"\x55\x62\x75\x6e\x74\x75","\x44\x65\x62\x69\x61\x6e",
"\x4f\x70\x65\x6e\x20\x53\x75\x73\x65","\x52\x65\x64\x20\x48\x61\x74",
"\x53\x4c\x45\x44","\x4d\x61\x6e\x64\x72\x69\x76\x61","\x46\x65\x64\x6f\x72\x61"
,"\x58\x61\x6e\x64\x72\x6f\x73"));sub isLinux{(my $distribution=shift (@_));
foreach my $single (@NXDistro::linux){if ((lc ($single)eq lc ($distribution))){
return ((0x06d1+ 1473-0x0c91));}}return ((0x187d+ 1296-0x1d8d));}return (
(0x1726+ 2794-0x220f));
