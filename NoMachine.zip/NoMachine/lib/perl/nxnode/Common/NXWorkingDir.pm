############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXWorkingDir;no warnings;require Common::NXFile;(
$NXWorkingDir::oldSTDERR=(""));($NXWorkingDir::TmpFolderPath=(""));(
$NXWorkingDir::TypeOfService=(""));sub initBackup{(my $self=shift (@_));(my $type
=shift (@_));(my $backup=(($NXWorkingDir::TmpFolderPath.$GLOBAL::DIRECTORY_SLASH
).($type."\x2e\x6c\x6f\x67")));(my $backupLoggerInt=main::nxopen ($backup,((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite)));
libnxh::NXDescriptorInheritable ($backupLoggerInt,(0x07a7+ 5337-0x1c80));return 
($backupLoggerInt);}sub chkLogClean{return ($GLOBAL::SessionLogClean);}sub 
closeTmp{return ((0x02b4+ 4570-0x148d));(my $tempFilePath=__getTmpFolderPath ())
;(my $logClean=chkLogClean ());if ($logClean){opendir (my $dir_handle,
$tempFilePath);while (defined ((my $item=readdir ($dir_handle)))){(my $tmp_path=
(($tempFilePath.$GLOBAL::DIRECTORY_SLASH).$item));if (Common::NXFile::fileExists
 ($tmp_path)){if ((not (unlink ($tmp_path)))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x5b"
.$tmp_path)."\x5d\x20").$!));}}}closedir ($dir_handle);if ((-d ($tempFilePath)
and (not (rmdir ($tempFilePath))))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x5b"
.$tempFilePath)."\x5d\x20").$!));}else{Logger::debug (((
"\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x5b".$tempFilePath).
"\x5d\x20\x72\x65\x6d\x6f\x76\x65\x64\x2e"));}}else{(my $pid=$ $);
 (my $type=
__getTypeOfService ());(my $tempFilePathNew=((NXPaths::getServerLogDir ().
$GLOBAL::DIRECTORY_SLASH).((("\x54\x2d\x43\x2d".$pid)."\x2d").$type)));(my $number
=(0x04a5+ 594-0x06f7));while (Common::NXFile::isExists ($tempFilePathNew)){(
$number+=(0x155a+ 3058-0x214b));($tempFilePathNew=((NXPaths::getServerLogDir ().
$GLOBAL::DIRECTORY_SLASH).((((("\x54\x2d\x43\x2d".$pid)."\x2d").$type)."\x2d").
$number)));}if ((not (rename ($tempFilePath,$tempFilePathNew)))){Logger::warning
 ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27"
.$tempFilePath)."\x27\x20\x74\x6f\x20\x27").$tempFilePathNew)."\x27\x20").$!));}
else{Logger::debug ((((("\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27".
$tempFilePath)."\x27\x20\x72\x65\x6e\x61\x6d\x65\x64\x20\x74\x6f\x20\x27").
$tempFilePathNew)."\x27\x2e"));}}}sub __setTmpFolderPath{(my $param=shift (@_));
($NXWorkingDir::TmpFolderPath=$param);}sub __getTmpFolderPath{return (
$NXWorkingDir::TmpFolderPath);}sub __setTypeOfService{(my $param=shift (@_));(
$NXWorkingDir::TypeOfService=$param);}sub __getTypeOfService{return (
$NXWorkingDir::TypeOfService);}return ((0x0489+ 5405-0x19a5));
