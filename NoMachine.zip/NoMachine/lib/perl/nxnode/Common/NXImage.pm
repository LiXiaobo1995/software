############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXImage::import{package Common::NXImage;no warnings;(my $source=
shift (@_));(my $destination=shift (@_));(my $tempDestination=($destination.
"\x2e\x70\x61\x72\x74"));if ((__import ($source,$tempDestination)<
(0x032b+ 6638-0x1d19))){return ((0x06c0+ 5847-0x1d97));}if ((not (rename (
$tempDestination,$destination)))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$tempDestination)."\x27\x20\x74\x6f\x20\x27").$destination).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x20").$!)."\x2e"));if ((not (
unlink ($tempDestination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$tempDestination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}
return ((0x1740+ 2237-0x1ffd));}return ((0x1ae4+ 2305-0x23e4));}sub 
Common::NXImage::delete{package Common::NXImage;no warnings;(my $path=shift (@_)
);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x44\x65\x6c\x65\x74\x65\x28"
.$path)."\x29"));(my $return=libnxhc::NXImageDelete ($path));Logger::debug ((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x44\x65\x6c\x65\x74\x65\x28"
.$path)."\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$return));if (($return<
(0x10ea+ 3968-0x206a))){(my $errorNumber=libnxh::NXShellGetError ());(my $errorString
=libnxh::NXGetSystemErrorString ($errorNumber));Logger::warning (((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x69\x6d\x61\x67\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));}return ($return);}sub 
Common::NXImage::list{package Common::NXImage;no warnings;(my $path=shift (@_));
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x4c\x69\x73\x74\x28"
.$path)."\x29"));(my $buffer=libnxhc::NXImageList ($path));Logger::debug ((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x4c\x69\x73\x74\x28"
.$path)."\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$buffer));(my (@files)=());if (
defined ($buffer)){(@files=split ( /\n/ ,$buffer,(0x0212+ 6296-0x1aaa)));}return
 (@files);}sub Common::NXImage::isoCreate{package Common::NXImage;no warnings;(my $output
=shift (@_));(my $input=shift (@_));(my $label=shift (@_));(my $joliet=shift (@_
));Logger::debug (((((((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x73\x6f\x43\x72\x65\x61\x74\x65\x28"
.$output)."\x2c\x20").$input)."\x2c\x20").$label)."\x2c\x20").$joliet)."\x29"));
(my $return=libnxhc::NXIsoCreate ($output,$input,$label,$joliet));Logger::debug 
(((((((((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x73\x6f\x43\x72\x65\x61\x74\x65\x28"
.$output)."\x2c\x20").$input)."\x2c\x20").$label)."\x2c\x20").$joliet).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$return)."\x2e"));if (($return==
(0x07a4+ 4787-0x1a57))){(my $errorNumber=NXPL::NXShellGetError ());(my $errorString
=NXPL::NXGetSystemErrorString ($errorNumber));Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x49\x53\x4f\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));}return ($return);}sub 
Common::NXImage::replace{package Common::NXImage;no warnings;(my $source=shift (
@_));(my $destination=shift (@_));(my $tempDestination=($destination.
"\x2e\x70\x61\x72\x74"));if ((__import ($source,$tempDestination)<
(0x002f+ 384-0x01af))){return ((0x1ae2+ 1228-0x1fae));}if ((not (unlink (
$destination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$destination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));if ((
not (unlink ($tempDestination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$tempDestination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}
return ((0x0290+ 6843-0x1d4b));}if ((not (rename ($tempDestination,$destination)
))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$tempDestination)."\x27\x20\x74\x6f\x20\x27").$destination).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x20").$!)."\x2e"));if ((not (
unlink ($tempDestination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$tempDestination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}
return ((0x024f+ 6860-0x1d1b));}return ((0x02c6+ 6521-0x1c3e));}sub 
Common::NXImage::__import{package Common::NXImage;no warnings;(my $source=shift 
(@_));(my $destination=shift (@_));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x49\x6d\x70\x6f\x72\x74\x28"
.$source)."\x2c\x20").$destination)."\x29"));(my $return=libnxhc::NXImageImport 
($source,$destination));Logger::debug ((((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x49\x6d\x70\x6f\x72\x74\x28"
.$source)."\x2c\x20").$destination)."\x29\x20\x72\x65\x74\x75\x72\x6e\x20").
$return));if (($return<(0x0973+ 2710-0x1409))){(my $errorNumber=
libnxh::NXShellGetError ());(my $errorString=libnxh::NXGetSystemErrorString (
$errorNumber));Logger::warning (((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x69\x6d\x70\x6f\x72\x74\x20\x69\x6d\x61\x67\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));if (Common::NXFile::isExists (
$destination)){if ((not (unlink ($destination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$destination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}}}
return ($return);}package Common::NXImage;no warnings;"\x3f\x3f\x3f";
