############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXRunCommand::BEGIN{package Common::NXRunCommand;no warnings;require
 strict;do{"\x73\x74\x72\x69\x63\x74"->unimport ("\x72\x65\x66\x73")};}sub 
Common::NXRunCommand::BEGIN{package Common::NXRunCommand;no warnings;require 
Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
Common::NXRunCommand::BEGIN{package Common::NXRunCommand;no warnings;require 
Exception::Log;do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->
import};}package Common::NXRunCommand;no warnings;(@NXRunCommand::command=());(
@NXRunCommand::environment=());($NXRunCommand::filename=(""));(
@NXRunCommand::commandrest=());($NXRunCommand::priority=(0x018b+ 4577-0x1307));(
$NXRunCommand::childpid=(0x05b8+ 982-0x098e));($NXRunCommand::flag_typeNX=
(0x09d3+ 4692-0x1c27));($NXRunCommand::flag_runInBg=(0x1c73+ 2613-0x26a8));(
$NXRunCommand::flag_closeCMDIN=(0x01f3+ 4110-0x1200));(
$NXRunCommand::flag_noLogStdout=(0x18f0+ 1253-0x1dd4));(
$NXRunCommand::flag_stdin_redirect=(0x0986+  28-0x09a2));(
$NXRunCommand::flag_stdout_redirect=(0x0ea4+ 3065-0x1a9d));(
$NXRunCommand::flag_stderr_redirect=(0x1fbb+ 729-0x2294));(
$NXRunCommand::flag_stdinfd_redirect=(0x0a38+ 4822-0x1d0e));(
$NXRunCommand::flag_stdoutfd_redirect=(0x00df+ 9247-0x24fe));(
$NXRunCommand::saveStdinTo=(""));($NXRunCommand::flag_saveStdin=
(0x17c3+ 402-0x1955));($NXRunCommand::saveStdoutTo=(""));(
$NXRunCommand::flag_saveStdout=(0x1bb2+ 2519-0x2589));(
$NXRunCommand::saveStderrTo=(""));($NXRunCommand::flag_saveStderr=
(0x1720+ 3648-0x2560));($NXRunCommand::flag_setStderrAsPipe=
(0x040c+ 3818-0x12f6));($NXRunCommand::flag_ERRinOUT=(0x1203+ 3089-0x1e14));(
$NXRunCommand::flag_runFunction=(0x22e3+ 208-0x23b3));(
$NXRunCommand::functionToRun=(""));(@NXRunCommand::functionToRunParameters=());(
$NXRunCommand::flag_callFunctionAfterRun=(0x180d+ 3443-0x2580));(
$NXRunCommand::flag_callFunctionAfterExit=(0x02cf+ 7810-0x2151));(
$NXRunCommand::flag_callFunctionAfterError=(0x07a9+ 3619-0x15cc));(
$NXRunCommand::flag_closeAfterRun=(0x0449+ 4262-0x14ef));(
@NXRunCommand::handlesToCloseAfterRun=());($NXRunCommand::flag_nxexecSTD=
(0x0a87+ 1662-0x1105));($NXRunCommand::FunctionAfterExit=(""));(
$NXRunCommand::FunctionAfterError=(""));($NXRunCommand::timeoutForOperation=
(0x154d+ 923-0x18ca));($NXRunCommand::useScriptToKill=(0x008b+ 3759-0x0f3a));(
$NXRunCommand::finishOnSigchld=(0x027b+ 767-0x057a));(
$NXRunCommand::stdinLogEnabled=(0x1a6a+ 329-0x1bb2));(
$NXRunCommand::flag_execCommand=(0x1138+ 4847-0x2427));(my $__stderrBuffer=(""))
;sub new{(my $class=shift (@_));(my $self=bless ({},$class));(
@NXRunCommand::command=());(@NXRunCommand::environment=());(
$NXRunCommand::filename=(""));(@NXRunCommand::commandrest=());(
$NXRunCommand::priority=(0x10b1+ 2300-0x1948));($NXRunCommand::childpid=
(0x04aa+ 5957-0x1bef));($NXRunCommand::flag_typeNX=(0x0d6d+ 5913-0x2486));(
$NXRunCommand::flag_runInBg=(0x08e9+ 4842-0x1bd3));(
$NXRunCommand::flag_closeCMDIN=(0x1043+ 5266-0x24d4));(
$NXRunCommand::flag_stdin_redirect=(0x0dfd+ 178-0x0eaf));(
$NXRunCommand::flag_stdout_redirect=(0x13af+ 4345-0x24a8));(
$NXRunCommand::flag_stderr_redirect=(0x012f+ 5607-0x1716));(
$NXRunCommand::flag_stdinfd_redirect=(0x08d6+ 2576-0x12e6));(
$NXRunCommand::flag_stdoutfd_redirect=(0x12cc+ 345-0x1425));(
$NXRunCommand::saveStdinTo=undef);($NXRunCommand::flag_saveStdin=
(0x0486+ 3576-0x127e));($NXRunCommand::saveStdoutTo=undef);(
$NXRunCommand::flag_saveStdout=(0x16d0+ 3942-0x2636));(
$NXRunCommand::saveStderrTo=undef);($NXRunCommand::flag_saveStderr=
(0x0008+ 1052-0x0424));($NXRunCommand::flag_setStderrAsPipe=
(0x01f3+ 9130-0x259d));($NXRunCommand::flag_ERRinOUT=(0x1fff+ 1473-0x25c0));(
$NXRunCommand::stdin_redirect=undef);($NXRunCommand::stdout_redirect=undef);(
$NXRunCommand::stderr_redirect=undef);($NXRunCommand::stdin_redirected=undef);(
$NXRunCommand::stdout_redirected=undef);($NXRunCommand::stderr_redirected=undef)
;($NXRunCommand::savepid=undef);($NXRunCommand::savePidToFile=undef);(
$NXRunCommand::parentStdin=undef);($NXRunCommand::parentStdout=undef);(
$NXRunCommand::parentStderr=undef);($NXRunCommand::childStdin=undef);(
$NXRunCommand::childStdout=undef);($NXRunCommand::childStderr=undef);(
$NXRunCommand::childStdinInt=undef);($NXRunCommand::childStdoutInt=undef);(
$NXRunCommand::parentStdinInt=undef);($NXRunCommand::parentStdoutInt=undef);(
$NXRunCommand::childStderrInt=undef);($NXRunCommand::parentStderrInt=undef);(
$NXRunCommand::flag_runFunction=(0x1b21+ 1627-0x217c));(
$NXRunCommand::functionToRun=(""));(@NXRunCommand::functionToRunParameters=());(
$NXRunCommand::flag_callFunctionAfterRun=(0x00dd+ 1747-0x07b0));(
$NXRunCommand::flag_noLogStdout=(0x0af2+ 5831-0x21b8));(
$NXRunCommand::flag_nxexecSTD=(0x03c7+ 507-0x05c2));(
$NXRunCommand::flag_closeAfterRun=(0x18ec+ 3245-0x2599));(
@NXRunCommand::handlesToCloseAfterRun=());($NXRunCommand::FunctionAfterExit=("")
);($NXRunCommand::FunctionAfterError=(""));($NXRunCommand::timeoutForOperation=
(0x0b90+ 1465-0x112b));($NXRunCommand::useScriptToKill=(0x03a0+ 8428-0x248c));(
$NXRunCommand::finishOnSigchld=(0x0324+ 7469-0x2051));(
$NXRunCommand::stdinLogEnabled=(0x08fc+ 4887-0x1c12));(
$NXRunCommand::flag_callFunctionAfterExit=(0x0566+ 8112-0x2516));(
$NXRunCommand::flag_callFunctionAfterError=(0x0ca9+ 1872-0x13f9));
cleanFileNameForSetPid ();return ($self);}sub __setupParentChildStdin{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x5f\x5f\x73\x65\x74\x75\x70\x50\x61\x72\x65\x6e\x74\x43\x68\x69\x6c\x64\x53\x74\x64\x69\x6e\x20\x73\x74\x61\x72\x74\x65\x64"
);if (stdinFD_redirect ()){($NXRunCommand::childStdinInt=getStdin_redirect ());
unless (libnxh::NXDescriptorInheritable ($NXRunCommand::childStdinInt,
(0x0d55+ 3274-0x1a1e))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdinInt));main::nxexit ();}Logger::debug2 ((
"\x43\x68\x69\x6c\x64\x20\x73\x74\x64\x69\x6e\x46\x44\x20\x73\x65\x74\x20\x74\x6f\x3a\x20"
.$NXRunCommand::childStdinInt));return;}else{Logger::debug2 (
"\x43\x68\x69\x6c\x64\x20\x73\x74\x64\x69\x6e\x46\x44\x20\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x2e"
);}unless (main::nxPipeCreateMono ((\$NXRunCommand::childStdinInt),(
\$NXRunCommand::parentStdinInt))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6d\x6f\x6e\x6f\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20\x63\x68\x69\x6c\x64\x20\x73\x74\x64\x69\x6e\x2e"
);Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString));main::nxexit ();}libnxh::NXDescriptorInheritable (
$NXRunCommand::childStdinInt,(0x1bbd+ 1030-0x1fc2));
libnxh::NXDescriptorInheritable ($NXRunCommand::parentStdinInt,
(0x0f84+ 1979-0x173f));if (saveStdin ()){($$NXRunCommand::saveStdinTo=
getParentStdinInt ());Logger::debug2 (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x61\x76\x65\x20\x70\x61\x72\x65\x6e\x74\x20\x73\x74\x64\x69\x6e\x20\x61\x73\x20\x46\x44\x23"
.$$NXRunCommand::saveStdinTo).("\x20\x69\x6e\x20".$NXRunCommand::saveStdinTo)));
}}sub __setupParentChildStdout{Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x5f\x5f\x73\x65\x74\x75\x70\x50\x61\x72\x65\x6e\x74\x43\x68\x69\x6c\x64\x53\x74\x64\x6f\x75\x74\x20\x73\x74\x61\x72\x74\x65\x64"
);if (stdoutFD_redirect ()){($NXRunCommand::childStdoutInt=getStdout_redirect ()
);unless (libnxh::NXDescriptorInheritable ($NXRunCommand::childStdoutInt,
(0x1524+ 891-0x189e))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdoutInt));main::nxexit ();}Logger::debug2 ((
"\x43\x68\x69\x6c\x64\x20\x73\x74\x64\x6f\x75\x74\x46\x44\x20\x73\x65\x74\x20\x74\x6f\x3a\x20"
.$NXRunCommand::childStdoutInt));return;}elsif (stdout_redirect ()){
Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.getStdout_redirect ()));($NXRunCommand::childStdoutInt=main::nxopen (
getStdout_redirect (),(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND),
$NXBits::UserReadWrite));if ((not (defined ($NXRunCommand::childStdoutInt)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x66\x6f\x72\x20\x73\x75\x62\x70\x72\x6f\x63\x65\x73\x2e"
);Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));main::nxexit ();}unless (
libnxh::NXDescriptorInheritable ($NXRunCommand::childStdoutInt,
(0x114f+ 2389-0x1aa3))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdoutInt));main::nxexit ();}Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x73\x74\x64\x6f\x75\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x46\x44\x23"
.$NXRunCommand::childStdoutInt));}else{unless (main::nxPipeCreateMono ((
\$NXRunCommand::parentStdoutInt),(\$NXRunCommand::childStdoutInt))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6d\x6f\x6e\x6f\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20\x63\x68\x69\x6c\x64\x20\x73\x74\x64\x6f\x75\x74\x2e"
);Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));main::nxexit ();}
libnxh::NXDescriptorInheritable ($NXRunCommand::parentStdoutInt,
(0x1a95+ 1153-0x1f16));libnxh::NXDescriptorInheritable (
$NXRunCommand::childStdoutInt,(0x2064+ 156-0x20ff));if (saveStdout ()){(
$$NXRunCommand::saveStdoutTo=getParentStdoutInt ());Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6f\x70\x65\x6e\x20\x46\x44\x23"
.$$NXRunCommand::saveStdoutTo).("\x20\x69\x6e\x20".$NXRunCommand::saveStdoutTo))
);}}}sub __setupParentChildStderr{if (ERRinOUT ()){(
$NXRunCommand::childStderrInt=$NXRunCommand::childStdoutInt);}elsif (
stderr_redirect ()){Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x74\x64\x65\x72\x72\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x3a\x20"
.getStderr_redirect ()));($NXRunCommand::childStderrInt=main::nxopen (
getStderr_redirect (),(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND),
$NXBits::UserReadWrite));if ((not (defined ($NXRunCommand::childStderrInt)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x66\x6f\x72\x20\x73\x75\x62\x70\x72\x6f\x63\x65\x73\x2e"
);Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString));main::nxexit ();}unless (
libnxh::NXDescriptorInheritable ($NXRunCommand::childStderrInt,
(0x0162+ 7465-0x1e8a))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStderrInt));main::nxexit ();}Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x73\x74\x64\x65\x72\x72\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x46\x44\x23"
.getChildStderrInt ()));}elsif (isSetStderrAsPipe ()){unless (
main::nxPipeCreateMono ((\$NXRunCommand::parentStderrInt),(
\$NXRunCommand::childStderrInt))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6d\x6f\x6e\x6f\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20\x63\x68\x69\x6c\x64\x20\x73\x74\x64\x65\x72\x72\x2e"
);Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString));main::nxexit ();}libnxh::NXDescriptorInheritable (
$NXRunCommand::parentStderrInt,(0x1053+ 534-0x1269));
libnxh::NXDescriptorInheritable ($NXRunCommand::childStderrInt,
(0x062b+ 7050-0x21b4));}else{(my $errorLogFile=
Common::NXPaths::getNXServerLogPath ());Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x6f\x69\x6e\x67\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x74\x6f\x20\x66\x69\x6c\x65\x3a\x20"
.$errorLogFile));(my $needToFixPermissions=(0x01a2+ 3189-0x0e17));if ((not (
Common::NXFile::fileExists ($errorLogFile)))){($needToFixPermissions=
(0x04d8+ 1902-0x0c45));}($NXRunCommand::childStderrInt=main::nxopen (
$errorLogFile,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND),((
$NXBits::UserReadWrite+$NXBits::GroupReadWrite)+$NXBits::OthersWrite)));unless (
$NXRunCommand::childStderrInt){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x74\x6f\x20"
.Common::NXPaths::getNXServerLogPath ())."\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorString)."\x2e"));main::nxexit ();}if ($needToFixPermissions){
Common::NXFile::setServerLogFilePermissions ();}unless (
libnxh::NXDescriptorInheritable ($NXRunCommand::childStderrInt,
(0x0800+ 6050-0x1fa1))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStderrInt));main::nxexit ();}Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x73\x74\x64\x65\x72\x72\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x69\x6e\x20\x46\x44\x23"
.getChildStderrInt ()));}}sub setChildDescriptors{my ($parentSocket);my (
$childSocket);my ($stderr_in);Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x43\x68\x69\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x73\x74\x61\x72\x74\x65\x64"
);if (isTypeNX ()){Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x43\x68\x69\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x66\x6f\x72\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x66\x20\x74\x79\x70\x65\x20\x4e\x58"
);main::nxPipeCreateBi ((\$parentSocket),(\$childSocket));(
$NXRunCommand::childStdin=$childSocket);($NXRunCommand::childStdout=$childSocket
);main::nxPipeCreateMono ((\$stderr_in),(\$NXRunCommand::childStderr));(
$NXRunCommand::parentStdin=$parentSocket);($NXRunCommand::parentStdout=
$parentSocket);($NXRunCommand::parentStderr=$stderr_in);}else{
__setupParentChildStdin ();__setupParentChildStdout ();__setupParentChildStderr 
();Logger::debug (((((((((((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x73\x65\x74\x2e\x20\x43\x68\x69\x6c\x64\x3a\x20\x46\x44\x23"
.getChildStdinInt ())."\x2c\x20\x46\x44\x23").getChildStdoutInt ()).
"\x2c\x20\x46\x44\x23").getChildStderrInt ()).
"\x2e\x20\x50\x61\x72\x65\x6e\x74\x3a\x20\x46\x44\x23").getParentStdinInt ()).
"\x2c\x20\x46\x44\x23").getParentStdoutInt ())."\x2e"));}}sub 
closeChildDescriptors{if (isTypeNX ()){main::nxclose (getChildStdinInt ());
main::nxclose (getChildStderrInt ());}else{if ((not (stdinFD_redirect ()))){
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x69\x6e"
);main::nxclose (getChildStdinInt ());}if ((getChildStdoutInt ()==
getChildStderrInt ())){Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x6f\x75\x74\x2f\x43\x68\x69\x6c\x64\x53\x74\x64\x65\x72\x72"
);main::nxclose (getChildStderrInt ());}else{if ((not (stdoutFD_redirect ()))){
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x6f\x75\x74"
);main::nxclose (getChildStdoutInt ());}Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x65\x72\x72"
);main::nxclose (getChildStderrInt ());}}Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x68\x69\x6c\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);}sub getChildStderr{if (defined ($NXRunCommand::childStderrInt)){return (
$NXRunCommand::childStderrInt);}return ($NXRunCommand::childStderr);}sub 
setOptions{(my $self=shift (@_));(my (@options)=@_);(my $getpriority=
(0x0590+ 4793-0x1849));(my $getstdin=(0x0881+ 6094-0x204f));(my $getstdout=
(0x1953+ 668-0x1bef));(my $getstderr=(0x1489+ 2470-0x1e2f));(my $getsavepid=
(0x1b17+ 2979-0x26ba));(my $getVarForStdin=(0x09fb+ 6936-0x2513));(my $getVarForStdout
=(0x03c9+ 7995-0x2304));(my $getVarForStderr=(0x0843+ 3587-0x1646));(my $getenv=
(0x11cf+ 2921-0x1d38));(my $getfunction=(0x03d6+ 8056-0x234e));(my $getfunctionParameters
=(0x1b3d+ 2649-0x2596));(my $getStdinDescriptor=(0x0404+ 7906-0x22e6));(my $getStdoutDescriptor
=(0x2073+ 883-0x23e6));(my $getfunctionafterexit=(0x0c58+ 6543-0x25e7));(my $getfunctionaftererror
=(0x05f6+ 7816-0x247e));(my $getFileNameForSavePid=(0x19e2+ 3219-0x2675));(my (
@environment)=());(my $getTimeout=(0x14a7+ 3924-0x23fb));(my $getFileNameToSavePid
=(0x16b1+ 3391-0x23f0));(my $getStdoutFD=(0x159d+ 2339-0x1ec0));(my $getStdinFD=
(0x1d34+ 1802-0x243e));(my $getHandleToClose=(0x09b0+ 5083-0x1d8b));foreach my $key
 (@options){if ($getTimeout){($getTimeout=(0x1680+ 3798-0x2556));setTimeout (
$key);next;}if ($getfunction){($getfunction=(0x17c1+ 903-0x1b48));(
$getfunctionParameters=(0x0c8f+ 5335-0x2165));setFunctionToCall ($key);next;}if 
($getfunctionafterexit){($getfunction=(0x2311+ 616-0x2579));(
$NXRunCommand::FunctionAfterExit=$key);next;}if ($getfunctionaftererror){(
$getfunction=(0x052f+ 8239-0x255e));($NXRunCommand::FunctionAfterError=$key);
next;}if ($getFileNameToSavePid){($getFileNameToSavePid=(0x0e13+ 2754-0x18d5));
setFileNameForSetPid ($key);next;}if ($getfunctionParameters){Logger::debug (
"\x6e\x78\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x68\x65\x20\x72\x65\x73\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x61\x72\x65\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x6f\x72\x20\x74\x68\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x2e"
);addToFunctionParameters ($key);next;}if ($getpriority){($getpriority=
(0x1404+ 2764-0x1ed0));setPriority ($key);next;}if ($getstdin){($getstdin=
(0x1b20+ 2144-0x2380));setStdin_redirect ($key);next;}if ($getstdout){(
$getstdout=(0x1604+ 3681-0x2465));setStdout_redirect ($key);next;}if ($getstderr
){($getstderr=(0x0200+ 6008-0x1978));setStderr_redirect ($key);next;}if (
$getVarForStdin){($getVarForStdin=(0x06ed+ 3926-0x1643));$self->setSaveStdinTo (
$key);next;}if ($getVarForStdout){($getVarForStdout=(0x0a5f+ 1625-0x10b8));$self
->setSaveStdoutTo ($key);next;}if ($getVarForStderr){($getVarForStderr=
(0x0118+ 322-0x025a));$self->setSaveStderrTo ($key);next;}if ($getsavepid){
setVarToSavePid ($key);Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x70\x69\x64\x20\x74\x6f\x20\x27"
.$NXRunCommand::savepid)."\x27\x2e"));($getsavepid=(0x0c16+ 5075-0x1fe9));next;}
if ($getenv){push (@environment,$key);($getenv=(0x040d+ 5383-0x1914));next;}if (
$getStdoutFD){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6c\x6c\x3a\x20\x73\x65\x74\x53\x74\x64\x6f\x75\x74\x46\x44\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x28"
.$key)."\x29"));setStdoutFD_redirect ($key);($getStdoutFD=(0x1247+ 4795-0x2502))
;next;}if ($getStdinFD){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6c\x6c\x3a\x20\x73\x65\x74\x53\x74\x64\x69\x6e\x46\x44\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x28"
.$key)."\x29"));setStdinFD_redirect ($key);($getStdinFD=(0x16d2+ 2484-0x2086));
next;}if ($getHandleToClose){addHandleToClose ($key);($getHandleToClose=
(0x1277+ 3100-0x1e93));next;}if (($key eq "\x74\x69\x6d\x65\x6f\x75\x74")){(
$getTimeout=(0x082d+ 3033-0x1405));next;}if (($key eq 
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e")){($getHandleToClose=
(0x087d+ 1818-0x0f96));next;}if (($key eq "\x6e\x78\x65\x78\x65\x63\x53\x54\x44"
)){setNxexecSTD ();next;}if (($key eq "\x74\x79\x70\x65\x4e\x58")){setTypeNX ();
next;}if (($key eq "\x73\x65\x74\x5f\x70\x72\x69\x6f\x72\x69\x74\x79")){(
$getpriority=(0x08f9+ 3621-0x171d));next;}if (($key eq 
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67")){setRunCommandInBG ();next;}if (($key eq
 "\x73\x74\x64\x69\x6e")){($getstdin=(0x0fe2+ 543-0x1200));next;}if (($key eq 
"\x73\x74\x64\x6f\x75\x74")){($getstdout=(0x18a9+ 625-0x1b19));next;}if (($key 
eq "\x73\x74\x64\x65\x72\x72")){($getstderr=(0x02a7+ 8713-0x24af));next;}if ((
$key eq "\x73\x65\x74\x20\x73\x74\x64\x69\x6e\x20\x61\x73\x20\x76\x61\x72")){(
$getVarForStdin=(0x020b+ 7315-0x1e9d));next;}if (($key eq 
"\x73\x65\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x61\x73\x20\x76\x61\x72")){(
$getVarForStdout=(0x0cf3+ 4085-0x1ce7));next;}if (($key eq 
"\x73\x65\x74\x20\x73\x74\x64\x65\x72\x72\x20\x61\x73\x20\x76\x61\x72")){(
$getVarForStderr=(0x0e8c+ 4048-0x1e5b));next;}if (($key eq 
"\x73\x65\x74\x20\x73\x74\x64\x65\x72\x72\x20\x61\x73\x20\x70\x69\x70\x65")){
$self->setStderrAsPipe;next;}if (($key eq "\x67\x65\x74\x20\x70\x69\x64")){(
$getsavepid=(0x12c2+ 4575-0x24a0));next;}if (($key eq 
"\x73\x61\x76\x65\x50\x69\x64\x54\x6f\x46\x69\x6c\x65")){($getFileNameToSavePid=
(0x1cc8+ 911-0x2056));next;}if (($key eq "\x73\x65\x74\x20\x65\x6e\x76")){(
$getenv=(0x1e09+ 403-0x1f9b));next;}if (($key eq 
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e")){
setNotCloseCMDIN ();next;}if (($key eq 
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x6f\x75\x74\x20\x6f\x70\x65\x6e")){
setNotCloseCMDOUT ();next;}if (($key eq "\x45\x52\x52\x69\x6e\x4f\x55\x54")){
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key).
"\x27\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x75\x73\x65\x64\x20\x61\x73\x20\x73\x74\x64\x65\x72\x72\x2e"
));setERRinOUT ();next;}if (($key eq 
"\x66\x75\x6c\x6c\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74")){
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key)."\x27\x20\x73\x65\x74"));setFullEnv ();next;}if (($key eq 
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e")){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key)."\x27\x20\x73\x65\x74\x20\x67\x65\x74\x53\x74\x64\x69\x6e\x46\x44"));(
$getStdinFD=(0x1781+ 747-0x1a6b));next;}if (($key eq 
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74")){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key)."\x27\x20\x73\x65\x74\x20\x67\x65\x74\x53\x74\x64\x4f\x75\x74\x46\x44"));(
$getStdoutFD=(0x0e13+ 1870-0x1560));next;}if (($key eq 
"\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e")){setCallFunction ();(
$getfunction=(0x1b0d+ 2077-0x2329));next;}if (($key eq 
"\x6e\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x6f\x75\x74")){setNoLogStdout ();next;
}if (($key eq "\x73\x74\x64\x69\x6e\x6e\x6f\x72\x65\x64\x69\x72\x65\x63\x74")){
setCloseCMDIN ();next;}if (($key eq 
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e")){
setCallFunctionAfterRun ();($getfunction=(0x12e1+ 4641-0x2501));next;}if (($key 
eq 
"\x63\x61\x6c\x6c\x20\x61\x66\x74\x65\x72\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74"
)){setCallFunctionAfterExit ();($getfunctionafterexit=(0x1498+ 3979-0x2422));
next;}if (($key eq 
"\x63\x61\x6c\x6c\x20\x61\x66\x74\x65\x72\x20\x65\x72\x72\x6f\x72\x20\x65\x78\x69\x74"
)){setCallFunctionAfterError ();($getfunctionaftererror=(0x06b7+ 4852-0x19aa));
next;}if (($key eq 
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c")){
setUseScriptToKill ();next;}if (($key eq 
"\x66\x69\x6e\x69\x73\x68\x20\x6f\x6e\x20\x73\x69\x67\x63\x68\x6c\x64")){
setFinishOnSigchld ();next;}if (($key eq 
"\x6e\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x69\x6e")){setNoLogStdin ();next;}
Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key).
"\x27\x20\x73\x74\x69\x6c\x6c\x20\x6e\x65\x65\x64\x73\x20\x74\x6f\x20\x62\x65\x20\x68\x61\x6e\x64\x6c\x65\x64\x2e"
));next;}$self->setEnvironment (@environment);}sub setEnvironment{(my $self=
shift (@_));(my (@environment)=@_);if (($NXRunCommand::flag_fullENV==
(0x0507+ 4032-0x14c6))){(@NXRunCommand::environment=sort (@environment));return;
}if ((scalar (@environment)==(0x18e6+ 881-0x1c57))){(@NXRunCommand::environment=
(""));return;}(@NXRunCommand::environment=sort (@environment));}sub setCommand{(my $self
=shift (@_));(my (@command)=@_);Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x27"
.join ($",@command))."\x27\x2e"));($NXRunCommand::filename=$command[
(0x097a+ 3411-0x16cd)]);unshift (@command,$NXRunCommand::filename);(
@NXRunCommand::command=@command);}sub setCommandForExec{(my $self=shift (@_));(my (
@command)=@_);Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x65\x78\x65\x63\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x27"
.join ($",@command))."\x27\x2e"));($NXRunCommand::filename=$command[
(0x0a3d+ 3625-0x1866)]);(@NXRunCommand::command=@command);}sub handleParentStdin
{if ((stdin_redirect ()and ($NXRunCommand::stdin_redirect ne ("")))){if (
isStdinLogEnabled ()){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x72\x79\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6f\x6e\x20\x73\x74\x64\x69\x6e\x3a\x20\x5b"
.$NXRunCommand::stdin_redirect)."\x5d"));}else{Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x72\x79\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6f\x6e\x20\x73\x74\x64\x69\x6e\x2e"
);}(my $write=main::nxwrite (getParentStdinInt (),$NXRunCommand::stdin_redirect)
);if (isStdinLogEnabled ()){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x77\x72\x69\x74\x65\x20\x5b"
.$write)."\x5d"));}}if (closeCMDINonStart ()){main::nxclose (getParentStdinInt 
());undef ($NXRunCommand::parentStdinInt);}}sub handleParentStdout{if ((not (
defined (getParentStdoutInt ())))){return;}if (((not (stdout_redirect ()))and (
not (saveStdout ())))){Logger::debug (
"\x68\x61\x6e\x64\x6c\x65\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x6f\x75\x74\x20\x63\x6c\x6f\x73\x69\x6e\x67\x20\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x6f\x75\x74"
);main::nxclose (getParentStdoutInt ());undef ($NXRunCommand::parentStdoutInt);}
}sub handleParentStderr{if ((not (defined (getParentStderrInt ())))){return;}if 
((not (stderr_redirect ()))){main::nxclose (getParentStderrInt ());undef (
$NXRunCommand::parentStderrInt);}}sub handlePid{(my $pid=shift (@_));(
$NXRunCommand::childpid=$pid);savePidToVar ();savePidToFile ();if (
callFunctionAfterExit ()){Common::NXProcess::setExitCallback ($pid,
$NXRunCommand::FunctionAfterExit);}if (callFunctionAfterError ()){
Common::NXProcess::setErrorCallback ($pid,$NXRunCommand::FunctionAfterError);}}
sub __callbackStdout{(my $self=shift (@_));(my $handleHash=shift (@_));(my $buffer
=shift (@_));(my $bytesRead=shift (@_));if (($bytesRead<=(0x118d+ 953-0x1546))){
$self->removeAndCloseHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->
setExit ($handleHash,(0x070c+ 6540-0x2098),$buffer);}else{($$handleHash{
"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"}{"\x63\x6d\x64\x5f\x6f\x75\x74"}.=
$buffer);($$handleHash{"\x45\x78\x69\x74\x52\x65\x73\x75\x6c\x74"}.=$buffer);(
$buffer=(""));}}sub __callbackStderr{(my $self=shift (@_));(my $handleHash=shift
 (@_));(my $buffer=shift (@_));(my $bytesRead=shift (@_));if (($bytesRead<=
(0x0afc+ 810-0x0e26))){$self->removeAndCloseHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});}else{($__stderrBuffer.=$buffer);($buffer=(""));}}
sub run{(my $buf_stdout=(""));(my $exit_value=(-(0x0876+ 1953-0x1016)));(my $timeout
=getTimeout ());my ($child_pid);my ($code);if (callFunction ()){($exit_value=
&$NXRunCommand::functionToRun (@NXRunCommand::functionToRunParameters));
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$exit_value)."\x2e"));return ((""),(""),$exit_value);}if (nxexecSTD ()){
libnxh::NXDescriptorInheritable (main::nxgetSTDIN (),(0x1f58+ 1453-0x2504));
libnxh::NXDescriptorInheritable (main::nxgetSTDOUT (),(0x058d+ 6249-0x1df5));
libnxh::NXDescriptorInheritable (main::nxgetSTDERR (),(0x0796+ 2014-0x0f73));(
$NXRunCommand::childStdinInt=main::nxgetSTDIN ());($NXRunCommand::childStdoutInt
=main::nxgetSTDOUT ());($NXRunCommand::childStderrInt=main::nxgetSTDERR ());}
else{setChildDescriptors ();}if (isExecCommand ()){(my $error=(""));
Common::NXProcess::nxProcessExec ($NXRunCommand::filename,(
\@NXRunCommand::command),(\@NXRunCommand::environment),(\$error));return ($error
);}($child_pid=Common::NXProcess::nxProcessCreate ($NXRunCommand::filename,(
\@NXRunCommand::command),(\@NXRunCommand::environment),getChildStdinInt (),
getChildStdoutInt (),getChildStderrInt (),getPriority ()));(my $error=
libnxh::NXGetErrorName ());(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());if (closeAfterRun ()){foreach my $handle (
@NXRunCommand::handlesToCloseAfterRun){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x6c\x6f\x73\x65\x20\x61\x66\x74\x65\x72\x20\x72\x75\x6e\x20\x2d\x20\x63\x6c\x6f\x73\x65\x20\x46\x44\x23"
.$handle)."\x2e"));main::nxclose ($handle);}}if (nxexecSTD ()){
libnxh::NXDescriptorInheritable (main::nxgetSTDIN (),(0x10b3+ 2332-0x19cf));
libnxh::NXDescriptorInheritable (main::nxgetSTDOUT (),(0x0458+ 7555-0x21db));
libnxh::NXDescriptorInheritable (main::nxgetSTDERR (),(0x09bf+ 5994-0x2129));}
else{closeChildDescriptors ();}if (($child_pid<=(0x002c+ 6215-0x1873))){(my $processName
=NXBegin::getProcessName ());Logger::error (((((
"\x43\x61\x6e\x27\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x65\x77\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.join ($",@NXRunCommand::command))."\x27\x20\x66\x72\x6f\x6d\x20").$processName)
."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));if ((((not (
stdin_redirect ()))and defined (getParentStdinInt ()))and (not (saveStdin ()))))
{main::nxclose (getParentStdinInt ());}if ((((not (stdout_redirect ()))and 
defined (getParentStdoutInt ()))and (not (saveStdout ())))){main::nxclose (
getParentStdoutInt ());}if ((((not (stderr_redirect ()))and defined (
getParentStderrInt ()))and (not (saveStderr ())))){main::nxclose (
getParentStderrInt ());}main::nxexit ((0x04b6+ 721-0x0786));return ((""),(""),(-
(0x1914+ 466-0x1ae5)));}handlePid ($child_pid);handleParentStdin ();if (
runCommandInBg ()){handleParentStdout ();handleParentStderr ();Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2e"
);($exit_value=(0x08d3+ 1145-0x0d4c));if (callFunctionAfterRun ()){push (
@NXRunCommand::functionToRunParameters,getChildPid ());($exit_value=
&$NXRunCommand::functionToRun (@NXRunCommand::functionToRunParameters));
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$exit_value)."\x2e"));}return ((""),(""),$exit_value);}($__stderrBuffer=(""));(my $flag_closed_stdout
=(0x0b80+  69-0x0bc4));(my $parentStdout=getParentStdoutInt ());(my $parentStderr
=getParentStderrInt ());(my $parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);(my $params
={"\x63\x6d\x64\x4f\x75\x74",("")});(my $signalFd=$$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});$parser->add ($signalFd);$parser->setTimeout (
$timeout);if (finishOnSigchld ()){$parser->setFinishOnSigchld ($child_pid);}if (
(not (stdout_redirect ()))){if ((not ($parser->add ($parentStdout,(
\&__callbackStdout),
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x53\x74\x64\x6f\x75\x74"
,$params)))){Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x46\x44\x23"
.$parentStdout).
"\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"));}else{
$parser->setAsStdout ($parentStdout);Logger::debug2 (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x61\x64\x64\x65\x64\x20\x46\x44\x23"
.$parentStdout).
"\x20\x74\x6f\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20\x73\x65\x74"
));($flag_closed_stdout=(0x1fb5+ 110-0x2023));}}if (isSetStderrAsPipe ()){if ((
not ($parser->add ($parentStderr,(\&__callbackStderr),
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x53\x74\x64\x65\x72\x72"
,$params)))){Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x46\x44\x23"
.$parentStderr).
"\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"));}else{
$parser->setHandleStdoutStderr;Logger::debug2 (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x61\x64\x64\x65\x64\x20\x46\x44\x23"
.$parentStderr).
"\x20\x74\x6f\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20\x73\x65\x74"
));}}(my $timedout=(0x0797+ 1356-0x0ce3));if ((not ($flag_closed_stdout))){&try 
(sub{(($code,$buf_stdout)=$parser->run);},
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->catch (&with (sub{
Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x69\x6d\x65\x6f\x75\x74\x20\x77\x68\x69\x6c\x65\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.join ($",@NXRunCommand::command)).
"\x27\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2e"));($timedout=(0x05f4+ 686-0x08a1)
);if ((not ($flag_closed_stdout))){main::nxclose ($parentStdout);}})));}(my $res
=(0x0818+ 2774-0x12ee));if ((not ($timedout))){($res=
Common::NXProcess::nxwaitpid ($child_pid,$NXBits::WAIT_UNTRACED,$timeout));if ((
$res==(0x18b8+ 2856-0x23e0))){Logger::debug2 (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x77\x65\x20\x64\x69\x64\x6e\x27\x74\x20\x72\x65\x63\x65\x69\x76\x65\x20\x53\x49\x47\x43\x48\x4c\x44\x20\x69\x6e\x20\x74\x69\x6d\x65\x2e"
);killProcess ($child_pid);return ($__stderrBuffer,$buf_stdout,
(0x07cf+ 1567-0x0ded));}}else{($res=Common::NXProcess::nxwaitpid ($child_pid,
$NXBits::WAIT_NOHANG));if (($res==(0x0583+ 4290-0x1645))){killProcess (
$child_pid);($res=Common::NXProcess::nxwaitpid ($child_pid,
$NXBits::WAIT_UNTRACED,$timeout));}}Logger::debug2 ((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6e\x78\x77\x61\x69\x74\x70\x69\x64\x20"
.$child_pid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$res));($exit_value=
Common::NXProcess::getExitValue ($child_pid));Logger::debug (((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$child_pid).
"\x27\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x77\x61\x73\x20\x27").
$exit_value)."\x27"));if (logStdout ()){Logger::debug (((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$child_pid)."\x27\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x61\x73\x20\x27").
$buf_stdout)."\x27"));}Logger::debug (((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$child_pid)."\x27\x20\x73\x74\x64\x65\x72\x72\x20\x77\x61\x73\x20\x27").
$__stderrBuffer)."\x27"));Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x72\x65\x74\x75\x72\x6e\x3a\x20"
.$exit_value));return ($__stderrBuffer,$buf_stdout,$exit_value);}sub 
setRunCommandInBG{($NXRunCommand::flag_runInBg=(0x126a+ 2642-0x1cbb));}sub 
runCommandInBg{return ($NXRunCommand::flag_runInBg);}sub setPriority{(my $priority
=shift (@_));($NXRunCommand::priority=$priority);}sub getPriority{return (
$NXRunCommand::priority);}sub savePidToVar{if (defined ($NXRunCommand::savepid))
{(my $var=getVarToSavePid ());Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x61\x76\x69\x6e\x67\x20\x70\x69\x64\x20\x69\x6e\x20"
.$var));($$var=$NXRunCommand::childpid);}}sub getVarToSavePid{return (
$NXRunCommand::savepid);}sub setVarToSavePid{(my $var=shift (@_));(
$NXRunCommand::savepid=$var);}sub setStdin_redirect{(my $fh=shift (@_));(
$NXRunCommand::stdin_redirect=$fh);($NXRunCommand::flag_stdin_redirect=
(0x1d8a+ 1275-0x2284));}sub setStdinFD_redirect{(my $fh=shift (@_));
Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x20\x73\x74\x64\x69\x6e\x46\x44\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x61\x73\x3a\x20"
.$fh));($NXRunCommand::stdin_redirect=$fh);($NXRunCommand::flag_stdinfd_redirect
=(0x0e8a+ 333-0x0fd6));}sub setStdoutFD_redirect{(my $fh=shift (@_));
Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x20\x73\x74\x64\x6f\x75\x74\x46\x44\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x61\x73\x3a\x20"
.$fh));($NXRunCommand::stdout_redirect=$fh);(
$NXRunCommand::flag_stdoutfd_redirect=(0x0354+ 4503-0x14ea));}sub 
setStdout_redirect{(my $fh=shift (@_));($NXRunCommand::stdout_redirect=$fh);(
$NXRunCommand::flag_stdout_redirect=(0x1894+ 2480-0x2243));}sub 
setStderr_redirect{(my $fh=shift (@_));($NXRunCommand::stderr_redirect=$fh);(
$NXRunCommand::flag_stderr_redirect=(0x11e2+ 492-0x13cd));}sub getStdin_redirect
{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x53\x74\x64\x69\x6e\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::stdin_redirect));return ($NXRunCommand::stdin_redirect);}sub 
getStdout_redirect{return ($NXRunCommand::stdout_redirect);}sub 
getStderr_redirect{return ($NXRunCommand::stderr_redirect);}sub stdinFD_redirect
{return ($NXRunCommand::flag_stdinfd_redirect);}sub stdin_redirect{return (
$NXRunCommand::flag_stdin_redirect);}sub stdoutFD_redirect{return (
$NXRunCommand::flag_stdoutfd_redirect);}sub stdout_redirect{return (
$NXRunCommand::flag_stdout_redirect);}sub stderr_redirect{return (
$NXRunCommand::flag_stderr_redirect);}sub setTypeNX{($NXRunCommand::flag_typeNX=
(0x0776+ 3399-0x14bc));}sub isTypeNX{return ($NXRunCommand::flag_typeNX);}sub 
getChildPid{return ($NXRunCommand::childpid);}sub setSaveStdinTo{(my $self=shift
 (@_));(my $fh=shift (@_));($NXRunCommand::saveStdinTo=$fh);(
$NXRunCommand::flag_saveStdin=(0x06ea+ 403-0x087c));}sub setSaveStdoutTo{(my $self
=shift (@_));(my $fh=shift (@_));($NXRunCommand::saveStdoutTo=$fh);(
$NXRunCommand::flag_saveStdout=(0x0276+ 6695-0x1c9c));}sub setSaveStderrTo{(my $self
=shift (@_));(my $fh=shift (@_));($NXRunCommand::saveStderrTo=$fh);(
$NXRunCommand::flag_saveStderr=(0x1451+ 689-0x1701));}sub setStderrAsPipe{(my $self
=shift (@_));($NXRunCommand::flag_setStderrAsPipe=(0x140d+ 2190-0x1c9a));}sub 
saveStdin{return ($NXRunCommand::flag_saveStdin);}sub saveStdout{return (
$NXRunCommand::flag_saveStdout);}sub saveStderr{return (
$NXRunCommand::flag_saveStderr);}sub isSetStderrAsPipe{return (
$NXRunCommand::flag_setStderrAsPipe);}sub getParentStderrInt{return (
$NXRunCommand::parentStderrInt);}sub closeCMDINonStart{return (
$NXRunCommand::flag_closeCMDIN);}sub closeCMDOUTonStart{return (
$NXRunCommand::flag_closeCMDOUT);}sub setCloseCMDIN{Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x43\x4d\x44\x5f\x49\x4e\x20\x74\x6f\x20\x62\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($NXRunCommand::flag_closeCMDIN=(0x0bea+ 6161-0x23fa));}sub setNotCloseCMDIN{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x43\x4d\x44\x5f\x49\x4e\x20\x6e\x6f\x74\x20\x74\x6f\x20\x62\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($NXRunCommand::flag_closeCMDIN=(0x1397+ 1787-0x1a92));}sub setNotCloseCMDOUT{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x43\x4d\x44\x5f\x4f\x55\x54\x20\x6e\x6f\x74\x20\x74\x6f\x20\x62\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($NXRunCommand::flag_closeCMDOUT=(0x0069+ 2537-0x0a52));}sub setERRinOUT{(
$NXRunCommand::flag_ERRinOUT=(0x02f5+ 1246-0x07d2));}sub ERRinOUT{return (
$NXRunCommand::flag_ERRinOUT);}sub setFullEnv{($NXRunCommand::flag_fullENV=
(0x0098+ 4109-0x10a4));}sub getParentStdin{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x69\x6e\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::parentStdin));return ($NXRunCommand::parentStdin);}sub 
getParentStdout{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x6f\x75\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::parentStdout));return ($NXRunCommand::parentStdout);}sub 
getParentStderr{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x65\x72\x72\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::parentStderr));return ($NXRunCommand::parentStderr);}sub 
getChildStdinInt{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x43\x68\x69\x6c\x64\x53\x74\x64\x69\x6e\x20\x72\x65\x74\x75\x72\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdinInt));return ($NXRunCommand::childStdinInt);}sub 
getChildStdoutInt{return ($NXRunCommand::childStdoutInt);}sub getChildStderrInt{
return ($NXRunCommand::childStderrInt);}sub getParentStdinInt{return (
$NXRunCommand::parentStdinInt);}sub getParentStdoutInt{return (
$NXRunCommand::parentStdoutInt);}sub callFunction{return (
$NXRunCommand::flag_runFunction);}sub setCallFunction{(
$NXRunCommand::flag_runFunction=(0x0494+ 2142-0x0cf1));}sub 
addToFunctionParameters{(my $parameters=shift (@_));push (
@NXRunCommand::functionToRunParameters,$parameters);}sub setNoLogStdout{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x6e\x6f\x74\x20\x74\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x6f\x75\x74\x2e"
);($NXRunCommand::flag_noLogStdout=(0x0006+ 2426-0x097f));}sub logStdout{return 
((!$NXRunCommand::flag_noLogStdout));}sub setFunctionToCall{(my $function=shift 
(@_));($NXRunCommand::functionToRun=("\x3a\x3a".$function));(
@NXRunCommand::functionToRunParameters=());}sub setCallFunctionAfterRun{(
$NXRunCommand::flag_callFunctionAfterRun=(0x06d7+ 1076-0x0b0a));}sub 
setCallFunctionAfterExit{($NXRunCommand::flag_callFunctionAfterExit=
(0x1680+ 1789-0x1d7c));}sub setCallFunctionAfterError{(
$NXRunCommand::flag_callFunctionAfterError=(0x1c3f+ 1313-0x215f));}sub 
callFunctionAfterRun{return ($NXRunCommand::flag_callFunctionAfterRun);}sub 
callFunctionAfterExit{return ($NXRunCommand::flag_callFunctionAfterExit);}sub 
callFunctionAfterError{return ($NXRunCommand::flag_callFunctionAfterError);}sub 
setFileNameForSetPid{(my $fileName=shift (@_));Logger::debug2 ((
"\x73\x65\x74\x46\x69\x6c\x65\x4e\x61\x6d\x65\x46\x6f\x72\x53\x65\x74\x50\x69\x64\x20\x69\x6e\x20\x66\x69\x6c\x65\x3a\x20"
.$fileName));($NXRunCommand::fileNameForSetPid=$fileName);}sub 
cleanFileNameForSetPid{Logger::debug2 (
"\x63\x6c\x65\x61\x6e\x46\x69\x6c\x65\x4e\x61\x6d\x65\x46\x6f\x72\x53\x65\x74\x50\x69\x64"
);if (defined ($NXRunCommand::fileNameForSetPid)){undef (
$NXRunCommand::fileNameForSetPid);}}sub savePidToFile{if (defined (
$NXRunCommand::fileNameForSetPid)){Logger::debug2 ((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x70\x69\x64\x20".
$NXRunCommand::childpid)."\x20\x69\x6e\x20\x66\x69\x6c\x65\x20").
$NXRunCommand::fileNameForSetPid));(my $file=main::nxopen (
$NXRunCommand::fileNameForSetPid,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+
$NXBits::O_TRUNC),(($NXBits::UserReadWrite+$NXBits::GroupRead)+
$NXBits::OthersRead)));if ((not (defined ($file)))){Common::NXCore::assertExit 
();return ((0x07e5+ 6838-0x229b));}main::nxwrite ($file,($NXRunCommand::childpid
."\x0a"));main::nxclose ($file);}else{Logger::debug2 (((
"\x4e\x6f\x74\x20\x73\x61\x76\x65\x20\x70\x69\x64\x20".$NXRunCommand::childpid).
"\x20\x69\x6e\x20\x61\x6e\x79\x20\x66\x69\x6c\x65\x2e"));}}sub killProcess{(my $child_pid
=shift (@_));if (useScriptToKill ()){
Common::NXProcess::signalProcessByRestrictedScript ($child_pid,
Common::NXProcess::getSignalKill ());}else{if (Common::NXProcess::sigkill (
$child_pid)){Logger::debug ((
"\x53\x49\x47\x4b\x49\x4c\x4c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$child_pid));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$child_pid)."\x2e"));}}}sub closeAfterRun{return (
$NXRunCommand::flag_closeAfterRun);}sub addHandleToClose{(my $handle=shift (@_))
;($NXRunCommand::flag_closeAfterRun=(0x0a15+ 373-0x0b89));push (
@NXRunCommand::handlesToCloseAfterRun,$handle);}sub setNxexecSTD{(
$NXRunCommand::flag_nxexecSTD=(0x0655+ 4151-0x168b));}sub nxexecSTD{return (
$NXRunCommand::flag_nxexecSTD);}sub setTimeout{(my $timeout=shift (@_));(
$NXRunCommand::timeoutForOperation=$timeout);}sub getTimeout{return (
$NXRunCommand::timeoutForOperation);}sub setUseScriptToKill{(
$NXRunCommand::useScriptToKill=(0x0924+ 5553-0x1ed4));}sub useScriptToKill{
return ($NXRunCommand::useScriptToKill);}sub finishOnSigchld{return (
$NXRunCommand::finishOnSigchld);}sub setFinishOnSigchld{(
$NXRunCommand::finishOnSigchld=(0x002f+ 6233-0x1887));}sub setNoLogStdin{return 
(($NXRunCommand::stdinLogEnabled=(0x1b77+ 1839-0x22a6)));}sub isStdinLogEnabled{
return ($NXRunCommand::stdinLogEnabled);}sub setExecCommand{(
$NXRunCommand::flag_execCommand=(0x14a5+ 3414-0x21fa));}sub isExecCommand{if ((
$NXRunCommand::flag_execCommand==(0x054c+ 4649-0x1774))){return (
(0x03b7+ 4738-0x1638));}return ((0x0c0d+ 1430-0x11a3));}return (
(0x0298+ 8027-0x21f2));
