############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXLicense;no warnings;(my $virtualSessionSupport=(0x10a9+ 3916-0x1ff5));
(my $physicalSessionSupport=(0x0dd0+ 3500-0x1b7c));(my $foreignSessionSupport=
(0x023b+ 4639-0x145a));(my $customFreeSubscriptionMessage=(0x19ef+ 460-0x1bbb));
($licenseFormat="\x34");sub isPhysicalSessionSupportEnabled{return (
$physicalSessionSupport);}sub isVirtualSessionSupportEnabled{return (
$virtualSessionSupport);}sub isForeignSessionSupportEnabled{return (
$foreignSessionSupport);}sub isVirtualSessionSupportDisabled{return ((!
isVirtualSessionSupportEnabled ()));}sub isCustomFreeSubscriptionMessage{return 
($customFreeSubscriptionMessage);}sub enablePhysicalSessionSupport{(
$physicalSessionSupport=(0x1d76+ 1843-0x24a8));}sub enableVirtualSessionSupport{
($virtualSessionSupport=(0x0392+ 4090-0x138b));}sub enableForeignSessionSupport{
($foreignSessionSupport=(0x03f4+ 3090-0x1005));}sub 
enableCustomFreeSubscriptionMessage{($customFreeSubscriptionMessage=
(0x0cd2+ 5788-0x236d));}sub chk_license{(my $subscription_mode=(shift (@_)||("")
));(my $selected_server_id=(shift (@_)||"\x30"));(my (@licenses)=());if ((
$subscription_mode ne (""))){($subscription_mode=(0x0af2+ 1453-0x109e));}else{(
$subscription_mode=(0x0e4b+ 1762-0x152d));}(my (@licenseFile)=
load_license_from_file ());(my (@licencje)=convertToArray (@licenseFile));undef 
(@licenseFile);(my (@parsed_licenses)=convertArrayToLicArray (@licencje));if (($#parsed_licenses
==(-(0x0eba+   8-0x0ec1)))){Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);Common::NXMsg::error (
"\x65\x4e\x6f\x64\x65\x43\x61\x6e\x6e\x6f\x74\x50\x65\x72\x66\x6f\x72\x6d\x4f\x70\x65\x72\x61\x74\x69\x6f\x6e"
);main::nxexit ((0x0026+ 3203-0x0ca8));}(my $num=(-(0x20b4+ 766-0x23b1)));
foreach my $lic (@parsed_licenses){(++$num);($lic=verify_entry ($lic));if ((
$selected_server_id ne "\x30")){if ((defined ($$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"})and ($$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"}eq $selected_server_id))){if ((
$subscription_mode==(0x129a+ 2839-0x1db0))){show_lic ($lic);}return (
(0x0627+ 2603-0x1052));}else{next;}}if (defined ($$lic{"\x65\x72\x72\x6f\x72"}))
{if (($subscription_mode==(0x1675+ 142-0x1702))){show_lic ($lic);next;}else{if (
($num eq$#parsed_licenses)){if (Common::NXMsg::check_msg ($$lic{
"\x65\x72\x72\x6f\x72"})){Common::NXMsg::error ($$lic{"\x65\x72\x72\x6f\x72"});}
main::nxexit ((0x0eb3+ 3453-0x1c2f));}next;}}if (defined ($$lic{
"\x50\x72\x6f\x64\x75\x63\x74"})){($GLOBAL::PRODUCT_NAME=$$lic{
"\x50\x72\x6f\x64\x75\x63\x74"});}if (($$lic{
"\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64\x5f\x6d\x64\x35"}ne $$lic{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"})){
Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);main::nxexit ((0x00e1+ 4300-0x11ac));}if (($GLOBAL::SERVER_PRODUCT_KEY ne ("")
)){if (($$lic{"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"}eq 
$GLOBAL::SERVER_PRODUCT_KEY)){if (($$lic{
"\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64\x5f\x6d\x64\x35"}ne $$lic{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"})){
Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);main::nxexit ((0x2067+ 1311-0x2585));}else{set_product ($lic);return ($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x54\x79\x70\x65"});}}}
elsif (($subscription_mode eq (0x06f0+ 1885-0x0e4c))){show_lic ($lic);}elsif (((
$$lic{"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"}ne (""))and (
$selected_server_id eq ("")))){next;}else{set_product ($lic);return ($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x54\x79\x70\x65"});}}if ((
defined ($selected_server_id)and ($selected_server_id ne "\x30"))){
Common::NXMsg::error (
"\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x6f\x72\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
,$selected_server_id);Common::NXMsg::send_response ("\x65\x42\x79\x65");return (
(0x0c28+ 5071-0x1ff7));}return ("\x4d\x69\x73\x73\x65\x64");}sub validate{(my $subscription_key
=(""));(my $subscription_type=(""));sub BEGIN{require Time::Local;do{
"\x54\x69\x6d\x65\x3a\x3a\x4c\x6f\x63\x61\x6c"->import};}(my $date=
Common::NXTime::getDateString ());chomp ($date);(my (@mon_list)=("\x4a\x61\x6e",
"\x46\x65\x62","\x4d\x61\x72","\x41\x70\x72","\x4d\x61\x79","\x4a\x75\x6e",
"\x4a\x75\x6c","\x41\x75\x67","\x53\x65\x70","\x4f\x63\x74","\x4e\x6f\x76",
"\x44\x65\x63"));(my (@day_list)=("\x53\x75\x6e","\x4d\x6f\x6e","\x54\x75\x65",
"\x57\x65\x64","\x54\x68\x75","\x46\x72\x69","\x53\x61\x74"));my ($sec,$min,
$hour,$mday,$mon,$year,$tz);if (($date=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*)(\d\d\d\d)/ )
){(($sec,$min,$hour,$mday,$mon,$year,$tz)=($6,$5,$4,$3,$2,$8,$7));($mon=~ s/Jan/00/i )
;($mon=~ s/Feb/01/i );($mon=~ s/Mar/02/i );($mon=~ s/Apr/03/i );($mon=~ s/May/04/i )
;($mon=~ s/Jun/05/i );($mon=~ s/Jul/06/i );($mon=~ s/Aug/07/i );($mon=~ s/Sep/08/i )
;($mon=~ s/Oct/09/i );($mon=~ s/Nov/10/i );($mon=~ s/Dec/11/i );if (($tz eq ("")
)){($tz="\x43\x45\x53\x54");($date=~ s/(\d\d\d\d)$/$tz $1/ );}}else{
Common::NXMsg::error (
"\x65\x44\x61\x74\x65\x49\x6e\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x46\x6f\x72\x6d\x61\x74"
,$date);main::nxexit ((0x05ad+ 3452-0x1328));}(my $Nts=Time::Local::timelocal (
$sec,$min,$hour,$mday,$mon,$year));($Nts+=2592000);(my ($sec,$min,$hour,$mday,
$mon,$year,$wday,$yday,$isdst)=Common::NXTime::getLocalTimeFromTimestamp ($Nts))
;($year+=(0x0b5b+ 6815-0x1e8e));(my $expiryDate=((((((((((($day_list[$wday].
"\x20").$mon_list[$mon])."\x20").$mday)."\x20").sprintf ("\x25\x30\x32\x64",
$hour))."\x3a").sprintf ("\x25\x30\x32\x64",$min))."\x3a").sprintf (
"\x25\x30\x32\x64",$sec)).((("\x20".$tz)."\x20").$year)));(my $KEY_FD=
main::nxopen (($GLOBAL::PRODUCT_KEY_FILE."\x2e\x73\x61\x6d\x70\x6c\x65"),
$NXBits::O_RDONLY,(0x0bf4+ 3952-0x1b64)));if ((not (defined ($KEY_FD)))){
main::nxexit ((0x03f8+ 838-0x073d));}(my $content=(""));while (main::nxreadLine 
($KEY_FD,(\$_))){if (( /^----- Begin subscription data -----(\r*)$/ .. /^----- End subscription data -----(\r*)$/ )
){($content.=$_);}}main::nxclose ($KEY_FD);($content=~ s/\r+//gm );if (($content
=~ /^Subscription Type: +(.*)$/m )){($subscription_type=$1);}if ((not (($content
=~ /^Virtual Desktops: +(.*)$/m )))){($licenseFormat="\x33");}if ((
$subscription_type ne "\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e")){main::nxexit 
((0x11b4+ 211-0x1286));}if (($content=~ /^Subscription Key: +(.*)$/m )){(
$subscription_key=$1);}($content=~ s/^(Date: +).*$/$1/m );($content=~ s/^(Expiry: +).*$/$1/m )
;($content=~ s/^(Subscription Key: +).*$/$1/m );($content=~ s/----- Begin subscription data -----\n//m )
;($content=~ s/----- End subscription data -----\n*//m );($content=~ s/(^Date:                   )/$1$date/m )
;($content=~ s/(^Expiry:                 )/$1$expiryDate/m );my (
$c_subscription_key);(my $add_chr=substr (Common::NXCore::digestMd5Hex ($date),
(0x0b57+ 3542-0x192d),(0x0dc5+ 5368-0x22b5)));if (($licenseFormat eq "\x33")){(
$c_subscription_key=Common::NXCore::digestMd5Hex (($content.
$GLOBAL::PRODUCT_KEY_SALT)));}else{($c_subscription_key=(
Common::NXCore::digestMd5Hex (($content.$GLOBAL::PRODUCT_KEY_SALT)).$add_chr));}
($content=~ s/(^Subscription Key:       )/$1$c_subscription_key/m );($KEY_FD=
main::nxopen (($GLOBAL::PRODUCT_KEY_FILE."\x2e\x73\x61\x6d\x70\x6c\x65"),((
$NXBits::O_WRONLY+$NXBits::O_TRUNC)+$NXBits::O_CREAT),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite)));if ((not (defined ($KEY_FD)
))){main::nxexit ((0x1c41+ 1749-0x2315));}main::nxwrite ($KEY_FD,((
"\x0a\x2d\x2d\x2d\x2d\x2d\x20\x42\x65\x67\x69\x6e\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x64\x61\x74\x61\x20\x2d\x2d\x2d\x2d\x2d\x0a"
.$content).
"\x2d\x2d\x2d\x2d\x2d\x20\x45\x6e\x64\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x64\x61\x74\x61\x20\x2d\x2d\x2d\x2d\x2d\x0a\x0a"
));main::nxclose ($KEY_FD);}sub serverLicExist{if (Common::NXFile::isExists (
$GLOBAL::NXSERVER_PRODUCT_KEY_FILE)){return ((0x01af+ 852-0x0502));}else{return 
((0x041c+ 8467-0x252f));}}sub set_product{(my $lic=shift (@_));(
$GLOBAL::PRODUCT_ID=$$lic{
"\x50\x72\x6f\x64\x75\x63\x74\x5f\x49\x64\x5f\x65\x78\x74"});(
$GLOBAL::CONNECTIONS_LIMIT=$$lic{"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}
);($$lic{"\x50\x72\x6f\x64\x75\x63\x74"}=~ s/NoMachine Portal Server/NoMachine Cloud Server/ )
;($$lic{"\x50\x72\x6f\x64\x75\x63\x74"}=~ s/NoMachine Enterprise Server/NoMachine Cloud Server/ )
;($GLOBAL::PRODUCT_NAME=$$lic{"\x50\x72\x6f\x64\x75\x63\x74"});if (
libnxh::NXIsValidAcronymId ($$lic{"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"})){
($GLOBAL::SUBSCRIPTION_ID=$$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"});
enablePhysicalSessionSupport ();if ((not (libnxh::NXIsEnterpriseDesktopNode (
$$lic{"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"})))){
enableVirtualSessionSupport ();enableForeignSessionSupport ();}if (
libnxh::NXIsNomachineFreeServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"})){
enableCustomFreeSubscriptionMessage ();}}else{Common::NXMsg::error (
"\x65\x47\x55\x49\x49\x6e\x76\x61\x6c\x69\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"
);Common::NXMsg::error (
"\x65\x4e\x6f\x64\x65\x43\x61\x6e\x6e\x6f\x74\x50\x65\x72\x66\x6f\x72\x6d\x4f\x70\x65\x72\x61\x74\x69\x6f\x6e"
);Logger::error (
"\x54\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x69\x74\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x63\x6f\x6e\x74\x61\x63\x74\x20\x74\x68\x65"
);Logger::error (
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x53\x61\x6c\x65\x73\x20\x54\x65\x61\x6d\x20\x74\x6f\x20\x67\x65\x74\x20\x61\x20\x73\x75\x69\x74\x61\x62\x6c\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x2e"
);Logger::error (
"\x54\x68\x65\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x6e\x6f\x64\x65\x20\x63\x61\x6e\x6e\x6e\x6f\x74\x20\x70\x65\x72\x66\x6f\x72\x6d\x20\x74\x68\x65\x20\x72\x65\x71\x75\x65\x73\x74\x65\x64\x20\x6f\x70\x65\x72\x61\x74\x69\x6f\x6e\x2e"
);main::nxexit ((0x1782+ 813-0x1aaf));}}sub 
setProductAndWelcomeStringBaseOnHardcodedID{(my $productId=
libnxh::NXTransGetEnvironment ("\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"));if ((
$productId eq (""))){($productId=$ENV{"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"});}
(my $acronymId=libnxh::NXParseServerProductId ($productId));if (
libnxh::NXIsValidAcronymId ($acronymId)){enablePhysicalSessionSupport ();if ((
not (libnxh::NXIsEnterpriseDesktop ($acronymId)))){enableVirtualSessionSupport 
();enableForeignSessionSupport ();}if (libnxh::NXIsNomachineFreeServer (
$acronymId)){enableCustomFreeSubscriptionMessage ();}}($GLOBAL::PRODUCT_ID=
$productId);($GLOBAL::PRODUCT_NAME=libnxh::NXParseProductName ($productId));(
$GLOBAL::WELCOME_STR=(($GLOBAL::PRODUCT_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_RELEASE));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}sub 
show_lic{(my $lic=shift (@_));if (defined ($$lic{"\x65\x72\x72\x6f\x72"})){
Common::NXMsg::send_response ("\x69\x50\x72\x6f\x64\x75\x63\x74\x4b\x65\x79",
$$lic{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"});if (
Common::NXMsg::check_msg ($$lic{"\x65\x72\x72\x6f\x72"})){Common::NXMsg::error (
$$lic{"\x65\x72\x72\x6f\x72"});}return;}if (($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x54\x79\x70\x65"}eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e")){Logger::warning (
Common::NXMsg::getBrandedMessage (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e"
,$$lic{"\x45\x78\x70\x69\x72\x79"}));Common::NXMsg::send_response (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e"
,$$lic{"\x45\x78\x70\x69\x72\x79"});return;}elsif (($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x54\x79\x70\x65"}eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64")){
Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
);return;}elsif ((($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"}eq 
"\x4e\x6f\x6e\x65")and isCustomFreeSubscriptionMessage ())){
Common::NXMsg::send_response (
"\x77\x43\x6d\x64\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x46\x72\x65\x65"
);return;}elsif (((($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"}eq 
"\x4e\x6f\x6e\x65")or ($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"}eq 
"\x50\x61\x72\x74\x6e\x65\x72"))or ($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"}eq 
"\x44\x65\x76\x65\x6c\x6f\x70\x65\x72"))){Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x55\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x64"
);return;}elsif (($$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x54\x79\x70\x65"}eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64\x45\x78\x70\x69\x72\x65\x64")){main::nxwrite (
main::nxgetSTDOUT (),main::subscriptionInfo ($$lic{
"\x50\x72\x6f\x64\x75\x63\x74\x5f\x49\x64\x5f\x65\x78\x74"},$$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"},$$lic{
"\x70\x65\x72\x69\x6f\x64"},$$lic{
"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"},$$lic{
"\x45\x78\x70\x69\x72\x79"}));Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x78\x70\x69\x72\x65\x64"
);return;}Common::NXMsg::send_response (
"\x69\x50\x72\x6f\x64\x75\x63\x74\x4b\x65\x79",$$lic{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"});main::nxwrite (
main::nxgetSTDOUT (),main::subscriptionInfo ($$lic{
"\x50\x72\x6f\x64\x75\x63\x74\x5f\x49\x64\x5f\x65\x78\x74"},$$lic{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"},$$lic{
"\x70\x65\x72\x69\x6f\x64"},$$lic{
"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"},$$lic{
"\x45\x78\x70\x69\x72\x79"},"\x20\x20"));}sub verify_entry{(my $lic=shift (@_));my (
$sec,$min,$hour,$mday,$mon,$year);if (($$lic{"\x55\x73\x65\x72\x73"}=~ /nlimited$/ )
){($$lic{"\x55\x73\x65\x72\x73"}=(0x03a4+ 6695-0x1dcb));}if (($$lic{
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /nlimited$/ )){($$lic{
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=(0x066b+ 5414-0x1b91));}($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}=libnxh::NXParseNodeProductId ($$lic{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));if (((((((((((((not (
libnxh::NXIsTerminalServerNode ($$lic{"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"
})))and (not (libnxh::NXIsSmallBusinessServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsEnterpriseServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsEnterpriseDesktopNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsQuickServerNode ($$lic{"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))
))and (not (libnxh::NXIsEnterpriseCloudServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsSmallBusinessTerminalServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsEnterpriseCloudServerClusterNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsEnterpriseTerminalServerClusterNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsSmallBusinessCloudServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsEnterpriseTerminalServerNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))and (not (
libnxh::NXIsEnterpriseTerminalServersNode ($$lic{
"\x61\x63\x72\x6f\x6e\x79\x6d\x5f\x69\x64"}))))){if (((not (defined ($$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"})))or ($$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"}eq ("")))){Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);main::nxexit ((0x02d1+ 3428-0x1034));}}if (($$lic{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}ne $GLOBAL::BUILD_PLATFORM)){
unless ((($GLOBAL::BUILD_PLATFORM eq "\x52")and (($$lic{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}eq "\x4c")||($$lic{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}eq "\x41")))){($$lic{
"\x65\x72\x72\x6f\x72"}=
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x6c\x61\x74\x66\x6f\x72\x6d\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);return ($lic);}}if (($$lic{"\x45\x78\x70\x69\x72\x79"}ne 
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64")){if (($$lic{"\x45\x78\x70\x69\x72\x79"}
=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*) (\d\d\d\d)/ )){(($sec,$min,
$hour,$mday,$mon,$year)=($6,$5,$4,$3,$2,$8));($mon=month2digit ($mon));}elsif ((
$$lic{"\x45\x78\x70\x69\x72\x79"}=~ /^.*(\d\d\d\d)-(\d\d)-(\d\d)/ )){($year=$1);
($mon=$2);($mday=$3);}else{($$lic{"\x65\x72\x72\x6f\x72"}=
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x78\x70\x69\x72\x79\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);return ($lic);}(my $expiry=(($year.sprintf ("\x25\x30\x32\x64",$mon)).sprintf 
("\x25\x30\x32\x64",$mday)));(my $expiry_timestamp=Time::Local::timelocal ($sec,
$min,$hour,$mday,($mon-(0x0462+ 7813-0x22e6)),$year));my (@ltime);(@ltime=
Common::NXTime::getLocalTime ());(my $now=($ltime[(0x0f17+ 2276-0x17f6)]+
(0x0c12+ 1241-0x097f)));($now=($now.sprintf ("\x25\x30\x32\x64",($ltime[
(0x0236+ 7727-0x2061)]+(0x0bcd+ 420-0x0d70)))));($now=($now.sprintf (
"\x25\x30\x32\x64",$ltime[(0x0ab4+ 1177-0x0f4a)])));if (($$lic{
"\x44\x61\x74\x65"}=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*) (\d\d\d\d)/ )
){(($sec,$min,$hour,$mday,$mon,$year)=($6,$5,$4,$3,$2,$8));($mon=month2digit (
$mon));}elsif (($$lic{"\x44\x61\x74\x65"}=~ /^.*(\d\d\d\d)-(\d\d)-(\d\d)/ )){(
$year=$1);($mon=$2);($mday=$3);}else{($$lic{"\x65\x72\x72\x6f\x72"}=
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x44\x61\x74\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);return ($lic);}(my $date=(($year.sprintf ("\x25\x30\x32\x64",$mon)).sprintf (
"\x25\x30\x32\x64",$mday)));(my $date_timestamp=Time::Local::timelocal ($sec,
$min,$hour,$mday,($mon-(0x1c83+ 380-0x1dfe)),$year));(my $period=(
$expiry_timestamp-$date_timestamp));($period=($period/86400));if ((($period eq 
(0x0a4b+ 3818-0x17c8))or ($period eq 366))){($$lic{"\x70\x65\x72\x69\x6f\x64"}=
"\x31\x20\x79\x65\x61\x72");}else{($$lic{"\x70\x65\x72\x69\x6f\x64"}=(int (
$period)."\x20\x64\x61\x79\x73"));}}else{($$lic{"\x70\x65\x72\x69\x6f\x64"}=
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64");}if (($$lic{
"\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64\x5f\x6d\x64\x35"}ne $$lic{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"})){($$lic{
"\x65\x72\x72\x6f\x72"}=
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);return ($lic);}if ((not (defined ($$lic{"\x62\x75\x69\x6c\x64\x64\x61\x79"})))
){(($$lic{"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"
},$$lic{"\x62\x75\x69\x6c\x64\x64\x61\x79"})=buildday_formated ());}return ($lic
);}sub month2digit{(my $mon=shift (@_));($mon=~ s/Jan/00/i );($mon=~ s/Feb/01/i )
;($mon=~ s/Mar/02/i );($mon=~ s/Apr/03/i );($mon=~ s/May/04/i );($mon=~ s/Jun/05/i )
;($mon=~ s/Jul/06/i );($mon=~ s/Aug/07/i );($mon=~ s/Sep/08/i );($mon=~ s/Oct/09/i )
;($mon=~ s/Nov/10/i );($mon=~ s/Dec/11/i );(++$mon);return ($mon);}sub 
take_product_id{(my $content=shift (@_));my ($product_id);if (($content=~ /^Product Id: +(.)(.*)$/m )
){($product_id=$2);}return ($product_id);}sub take_platform_id{(my $content=
shift (@_));my ($platform_id);if (($content=~ /^Product Id: +(.)(.*)$/m )){(
$platform_id=$1);}return ($platform_id);}sub take_field_from_license{(my $field=
shift (@_));(my $content=shift (@_));if (($content=~ /^$field: +(.*)$/m )){(my $value
=$1);return ($value);}return;}sub convertArrayToLicArray{(my (@licencje)=@_);(my (
@result)=());foreach my $entry (@licencje){my ($tmp);($$tmp{
"\x43\x75\x73\x74\x6f\x6d\x65\x72"}=take_field_from_license (
"\x43\x75\x73\x74\x6f\x6d\x65\x72",$entry));($$tmp{"\x44\x61\x74\x65"}=
take_field_from_license ("\x44\x61\x74\x65",$entry));($$tmp{
"\x50\x72\x6f\x64\x75\x63\x74"}=take_field_from_license (
"\x50\x72\x6f\x64\x75\x63\x74",$entry));($$tmp{
"\x50\x72\x6f\x64\x75\x63\x74\x5f\x49\x64\x5f\x65\x78\x74"}=
take_field_from_license ("\x50\x72\x6f\x64\x75\x63\x74\x20\x49\x64",$entry));(
$$tmp{"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x49\x64"}=
take_field_from_license (
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x49\x64",$entry));($$tmp{
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x54\x79\x70\x65"}=
take_field_from_license (
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x54\x79\x70\x65",$entry));
($$tmp{"\x45\x78\x70\x69\x72\x79"}=take_field_from_license (
"\x45\x78\x70\x69\x72\x61\x74\x69\x6f\x6e\x7c\x45\x78\x70\x69\x72\x79",$entry));
($$tmp{"\x55\x73\x65\x72\x73"}=take_field_from_license ("\x55\x73\x65\x72\x73",
$entry));($$tmp{"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=
take_field_from_license ("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73",$entry))
;($$tmp{"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"}=take_field_from_license (
"\x53\x65\x72\x76\x65\x72\x20\x4b\x65\x79",$entry));($$tmp{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"}=take_field_from_license (
"\x50\x72\x6f\x64\x75\x63\x74\x20\x4b\x65\x79",$entry));($$tmp{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"}=
take_field_from_license (
"\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x4b\x65\x79",$entry));(
$$tmp{"\x76\x69\x72\x74\x75\x61\x6c\x5f\x64\x65\x73\x6b\x74\x6f\x70\x73"}=
take_field_from_license (
"\x56\x69\x72\x74\x75\x61\x6c\x20\x44\x65\x73\x6b\x74\x6f\x70\x73",$entry));(
$$tmp{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=take_platform_id ($entry))
;($$tmp{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=take_product_id ($entry));(
$$tmp{"\x6c\x69\x63\x65\x6e\x73\x65\x5f\x66\x69\x6c\x65"}=$entry);($$tmp{
"\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64\x5f\x6d\x64\x35"}=
calculate_license_md5 ($entry));($$tmp{
"\x6c\x69\x63\x65\x6e\x73\x65\x5f\x76\x65\x72\x73\x69\x6f\x6e"}="\x34");if ((((
$$tmp{"\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64\x5f\x6d\x64\x35"}ne (""))and (
$$tmp{"\x50\x72\x6f\x64\x75\x63\x74\x5f\x49\x64\x5f\x65\x78\x74"}ne ("")))and (
$$tmp{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"}ne ("")))){push (@result,
$tmp);}}return (@result);}sub calculate_license_md5{(my $content=shift (@_));(my $date_formated
=(""));if (($content=~ /^Date: +(.*)$/m )){($date_formated=$1);}(my $add_chr=
substr (Common::NXCore::digestMd5Hex ($date_formated),(0x0eaa+ 1560-0x14c2),
(0x1e0a+ 1278-0x2300)));($content=~ s/^(Subscription Key: +).*$/$1/m );($content
=~ s/----- Begin subscription data -----\n//m );($content=~ s/----- End subscription data -----\n*//m )
;if (($content=~ /Virtual Desktops:/ )){return ((Common::NXCore::digestMd5Hex ((
$content.$GLOBAL::PRODUCT_KEY_SALT)).$add_chr));}else{return (
Common::NXCore::digestMd5Hex (($content.$GLOBAL::PRODUCT_KEY_SALT)));}}sub 
buildday_formated{(Common::NXCore::decodeDate ($GLOBAL::BUILD_DAY)=~ /(\d{4})(\d{2})(\d{2})/ )
;(my $buildday_timestamp=Time::Local::timelocal ((0x1782+ 377-0x18fb),
(0x14d7+ 3824-0x23c7),(0x0071+ 548-0x0289),$3,($2-(0x133f+ 380-0x14ba)),$1));my (
$wday,$yday,$isdst);(my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=
Common::NXTime::getLocalTimeFromTimestamp ($buildday_timestamp));($year+=
(0x0cea+ 1400-0x0af6));(my (@mon_list)=("\x4a\x61\x6e","\x46\x65\x62",
"\x4d\x61\x72","\x41\x70\x72","\x4d\x61\x79","\x4a\x75\x6e","\x4a\x75\x6c",
"\x41\x75\x67","\x53\x65\x70","\x4f\x63\x74","\x4e\x6f\x76","\x44\x65\x63"));(my (
@day_list)=("\x53\x75\x6e","\x4d\x6f\x6e","\x54\x75\x65","\x57\x65\x64",
"\x54\x68\x75","\x46\x72\x69","\x53\x61\x74"));(my $buildday_formated=((((((((((
($day_list[$wday]."\x20").$mon_list[$mon])."\x20").$mday)."\x20").sprintf (
"\x25\x30\x32\x64",$hour))."\x3a").sprintf ("\x25\x30\x32\x64",$min))."\x3a").
sprintf ("\x25\x30\x32\x64",$sec)).("\x20\x43\x45\x54\x20".$year)));(my $buildday
=$year);($buildday=($buildday.sprintf ("\x25\x30\x32\x64",($mon+
(0x0228+ 5967-0x1976)))));($buildday=($buildday.sprintf ("\x25\x30\x32\x64",
$mday)));return ($buildday_formated,$buildday);}sub convertToArray{(my (
@licenseFile)=@_);(my (@licencje)=());my ($tagON);my ($lic);(my $FoundLicense=
(0x0329+ 8220-0x2345));foreach my $line (@licenseFile){if (($line=~ /^----- Begin subscription data -----(\r*)$/ )
){($lic=(""));($tagON=(0x0a78+ 5621-0x206c));}if (($tagON==(0x0f66+ 4119-0x1f7c)
)){($lic.=($line."\x0a"));}if (($line=~ /^----- End subscription data -----(\r*)$/ )
){if (($lic ne (""))){push (@licencje,$lic);}($tagON=(0x09cc+ 3826-0x18be));(
$lic=(""));}}return (@licencje);}sub load_license_from_file{Logger::debug (((
"\x52\x65\x61\x64\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x77\x69\x74\x68\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x20\x27"
.$>)."\x27\x2e"));(my $content=(""));(my $FILE=main::nxopen (
$GLOBAL::PRODUCT_KEY_FILE,$NXBits::O_RDONLY,(0x0bc8+ 3781-0x1a8d),{
"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));if ($FILE){while (
main::nxreadLine ($FILE,(\$_))){($content.=$_);}main::nxclose ($FILE);}else{(my (
@command)=$GLOBAL::CommandNXexec);push (@command,
"\x2d\x2d\x73\x65\x72\x76\x65\x72");push (@command,
"\x2d\x2d\x6e\x6f\x64\x65\x6c\x69\x63\x65\x6e\x73\x65");(my (@params)=());push (
@params,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (@params,
"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68")));push (@params,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@params)));if (
$exit_value){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x73\x73\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$GLOBAL::PRODUCT_KEY_FILE).
"\x27\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x6e\x78\x65\x78\x65\x63\x2e"));
Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);Common::NXMsg::error (
"\x65\x4e\x6f\x64\x65\x43\x61\x6e\x6e\x6f\x74\x50\x65\x72\x66\x6f\x72\x6d\x4f\x70\x65\x72\x61\x74\x69\x6f\x6e"
);main::nxexit ((0x0724+ 4411-0x185f));}else{Logger::debug (((((((
"\x28\x63\x6d\x64\x5f\x65\x72\x72\x2c\x20\x63\x6d\x64\x5f\x6f\x75\x74\x2c\x20\x65\x78\x69\x74\x5f\x76\x61\x6c\x75\x65\x29\x20\x28"
.$cmd_err)."\x2c\x20").$cmd_out)."\x2c\x20").$exit_value)."\x29\x2e"));($content
=$cmd_out);}}($content=Common::NXCore::extractLicenseBodyFromLicenseFile (
$content));return (split ( /\n/ ,$content,(0x029a+ 943-0x0649)));}sub 
subscriptiondel{(my $subscriptionId=(shift (@_)||("")));my ($content);(my (
@licenseFile)=load_license_from_file ());(my (@licencje)=convertToArray (
@licenseFile));(my (@parsed_licenses)=convertArrayToLicArray (@licencje));(my $flag_found_subscription
=(0x2345+ 137-0x23ce));(my $tmpLicFile=($GLOBAL::PRODUCT_KEY_FILE.
"\x2e\x74\x6d\x70"));(my $FH=main::nxopen ($tmpLicFile,$NXBits::O_WRONLY,
(0x030a+ 429-0x04b7)));if ((not (defined ($FH)))){(my $errorString=
libnxh::NXGetErrorString ());Common::NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x50\x72\x6f\x64\x75\x63\x74\x4b\x65\x79"
,$tmpLicFile,$errorString);return;}foreach my $lic (@parsed_licenses){if (($$lic
{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"}ne $subscriptionId)){
main::nxwrite ($FH,$$lic{"\x63\x6f\x6e\x74\x65\x6e\x74"});}else{(
$flag_found_subscription=(0x11ca+ 3820-0x20b5));}}main::nxclose ($FH);if ((
$flag_found_subscription==(0x1837+ 2435-0x21ba))){Common::NXMsg::error (
"\x65\x4e\x6f\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x41\x73\x73\x6f\x63\x69\x61\x74\x65\x64"
,$subscriptionId);unlink ($tmpLicFile);return;}(my (@command)=(
"\x2f\x62\x69\x6e\x2f\x63\x70",$tmpLicFile,$GLOBAL::PRODUCT_KEY_FILE));(my (@opt
)=());(my ($stderr,$stdout,$result_status)=run_command ((\@command),(\@opt)));if
 (($result_status==(0x0b71+ 3139-0x17b4))){Common::NXMsg::send_response (
"\x69\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x44\x65\x6c\x65\x74\x65\x64"
);}else{Common::NXMsg::error (
"\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x43\x61\x6e\x6e\x6f\x74\x42\x65\x44\x65\x6c\x65\x74\x65\x64"
,$stderr);}return;}sub subscriptionadd{(my $sfile=(shift (@_)||("")));my (
$content);if (($sfile eq (""))){Common::NXMsg::error (
"\x65\x4e\x6f\x50\x61\x74\x68\x54\x6f\x4c\x69\x63\x65\x6e\x73\x65\x46\x69\x6c\x65"
);Common::NXMsg::error (
"\x65\x41\x64\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65"
);return ((0x1ad6+ 1306-0x1ff0));}if ((not (Common::NXFile::fileExists ($sfile))
)){Common::NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x46\x69\x6c\x65",$sfile);
Common::NXMsg::error ("\x65\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74",
$sfile);return ((0x0642+ 3404-0x138e));}(my $KEY_FD=main::nxopen ($sfile,
$NXBits::O_RDONLY,(0x18e6+ 1196-0x1d92)));if ((not (defined ($KEY_FD)))){(my $error
=libnxh::NXGetError ());if ((Common::NXCore::ErrnoENOENT ()==$error)){
Common::NXMsg::error (
"\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
,$sfile);return ((0x0156+ 2555-0x0b51));}else{Common::NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65"
,$sfile);return ((0x0e6f+ 5343-0x234e));}}else{while (main::nxreadLine ($KEY_FD,
(\$_))){($content.=$_);}main::nxclose ($KEY_FD);}(my (@tmp)=split ( /\n/ ,
$content,(0x0e59+ 4710-0x20bf)));(my (@licencje)=convertToArray (@tmp));(my (
@parsed_licenses)=convertArrayToLicArray (@licencje));if (($#parsed_licenses==(-
(0x1182+ 2581-0x1b96)))){Common::NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65"
,$sfile);Common::NXMsg::error (
"\x65\x49\x6e\x76\x61\x6c\x69\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"
);return ((0x0d74+ 757-0x1069));}(my $SUB_FD=main::nxopen (
$GLOBAL::PRODUCT_KEY_FILE,(($NXBits::O_WRONLY+$NXBits::O_APPEND)+
$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead)+
$NXBits::OthersRead)));if ((not (defined ($SUB_FD)))){(my $errorString=
libnxh::NXGetErrorString ());Common::NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x4c\x69\x63\x65\x6e\x73\x65\x46\x69\x6c\x65"
,$errorString);return ((0x0492+ 1645-0x0aff));}main::nxwrite ($SUB_FD,$content);
main::nxclose ($SUB_FD);Common::NXMsg::send_response (
"\x69\x41\x64\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x31"
,$sfile);Common::NXMsg::send_response (
"\x69\x41\x64\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x32"
);return ((0x20cc+ 1364-0x2620));}sub serverlist{(my (@licenseFile)=
load_license_from_file ());(my (@licencje)=convertToArray (@licenseFile));(my (
@parsed_licenses)=convertArrayToLicArray (@licencje));(my $flag_found_any_license
=(0x06f9+ 4830-0x19d7));if (($#parsed_licenses==(-(0x1849+ 439-0x19ff)))){
Common::NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);Common::NXMsg::error (
"\x65\x4e\x6f\x64\x65\x43\x61\x6e\x6e\x6f\x74\x50\x65\x72\x66\x6f\x72\x6d\x4f\x70\x65\x72\x61\x74\x69\x6f\x6e"
);main::nxexit ((0x097d+ 1234-0x0e4e));}foreach my $lic (@parsed_licenses){if ((
defined ($$lic{"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"})and $$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"})){($flag_found_any_license=
(0x10b7+ 5078-0x248c));Common::NXMsg::send_response (
"\x69\x53\x65\x72\x76\x65\x72\x4b\x65\x79",$$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"});($GLOBAL::NODE_ROOT=
$GLOBAL::NX_SYSTEM);(my $keyfile=((((((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).$$lic{
"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"}).
"\x2e\x6e\x6f\x64\x65\x2e\x69\x64\x5f\x64\x73\x61\x2e\x70\x75\x62"));if (
Common::NXFile::fileExists ($keyfile)){Common::NXMsg::send_response (
"\x69\x55\x73\x69\x6e\x67\x4b\x65\x79",$keyfile);}else{Common::NXMsg::error (
"\x65\x4e\x6f\x74\x48\x61\x76\x69\x6e\x67\x56\x61\x6c\x69\x64\x4b\x65\x79",$$lic
{"\x73\x65\x72\x76\x65\x72\x5f\x6b\x65\x79"});}}}if (($flag_found_any_license==
(0x04d6+ 2421-0x0e4b))){Common::NXMsg::error (
"\x65\x4e\x6f\x53\x65\x72\x76\x65\x72\x41\x73\x73\x6f\x63\x69\x61\x74\x65\x64");
}return;}return ((0x037f+ 7517-0x20db));
