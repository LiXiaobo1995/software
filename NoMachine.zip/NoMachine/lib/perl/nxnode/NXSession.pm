############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSession::BEGIN{package NXSession;no warnings;require Common::Logger;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->import};}package 
NXSession;no warnings;($playerConnected="\x6e\x6f\x74\x53\x65\x74");(
$__sessionType=(""));$__ref_parameters;($sessionCloseStarted=
(0x1754+ 1140-0x1bc8));sub playerConnectedThroughNXD{Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x54\x68\x72\x6f\x75\x67\x68\x4e\x58\x44"
);($playerConnected="\x6e\x78\x64");}sub playerConnectedThroughSSHD{
Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x54\x68\x72\x6f\x75\x67\x68\x53\x53\x48\x44"
);($playerConnected="\x73\x73\x68\x64");}sub playerIsConnected{if ((
$playerConnected eq "\x6e\x6f\x74\x53\x65\x74")){Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x49\x73\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x30"
);return ((0x0bd7+ 483-0x0dba));}Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x49\x73\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x31"
);return ((0x1527+ 4121-0x253f));}sub playerIsConnectedThroughNXD{if ((
$playerConnected eq "\x6e\x78\x64")){Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x49\x73\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x54\x68\x72\x6f\x75\x67\x68\x4e\x58\x44\x20\x31"
);return ((0x076b+ 1628-0x0dc6));}Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x49\x73\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x54\x68\x72\x6f\x75\x67\x68\x4e\x58\x44\x20\x30"
);return ((0x0100+ 8771-0x2343));}sub playerIsConnectedThroughSSHD{if ((
$playerConnected eq "\x73\x73\x68\x64")){Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x49\x73\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x54\x68\x72\x6f\x75\x67\x68\x53\x53\x48\x44\x20\x31"
);return ((0x1623+ 636-0x189e));}Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x6c\x61\x79\x65\x72\x49\x73\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x54\x68\x72\x6f\x75\x67\x68\x53\x53\x48\x44\x20\x30"
);return ((0x18b0+ 1565-0x1ecd));}sub addConnectionVariableToEnvironmentArray{(my $ref_array
=shift (@_));(my $nxConnectionEnv=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (($nxConnectionEnv 
ne (""))){push (@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$nxConnectionEnv));
Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x61\x64\x64\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x56\x61\x72\x69\x61\x62\x6c\x65\x54\x6f\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x41\x72\x72\x61\x79\x20\x73\x65\x74\x20\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"
);}else{(my $sshConnectionEnv=libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if ((
$sshConnectionEnv ne (""))){push (@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$sshConnectionEnv
));Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x61\x64\x64\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x56\x61\x72\x69\x61\x62\x6c\x65\x54\x6f\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x41\x72\x72\x61\x79\x20\x73\x65\x74\x20\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"
);}(my $sshClientEnv=libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"));if (($sshClientEnv ne (""))){push (
@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54\x3d".$sshClientEnv));Logger::debug (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x61\x64\x64\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x56\x61\x72\x69\x61\x62\x6c\x65\x54\x6f\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x41\x72\x72\x61\x79\x20\x73\x65\x74\x20\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"
);}}}sub setSessionType{(my $sessionType=shift (@_));($__sessionType=
$sessionType);}sub getSessionType{return ($__sessionType);}sub 
setParametersReference{(my $ref_parameters=shift (@_));($__ref_parameters=
$ref_parameters);}sub getParametersReference{return ($__ref_parameters);}sub 
isRestoreSession{if (($GLOBAL::parameters{
"\x72\x65\x73\x74\x6f\x72\x65\x73\x65\x73\x73\x69\x6f\x6e"}eq "\x31")){return (
(0x0478+ 2951-0x0ffe));}return ((0x0925+ 3153-0x1576));}sub isNotRestoreSession{
return ((!isRestoreSession ()));}sub isFirstAttach{if (($GLOBAL::parameters{
"\x66\x69\x72\x73\x74\x41\x74\x74\x61\x63\x68"}eq "\x31")){return (
(0x2128+ 1281-0x2628));}return ((0x1166+ 477-0x1343));}sub isNotFirstAttach{
return ((!isFirstAttach ()));}sub considerBeforeSessionStart{if ((
isNotRestoreSession ()and isNotFirstAttach ())){NXEvent::beforeSessionStart ();}
}sub considerAfterSessionStart{if ((isNotRestoreSession ()and isNotFirstAttach 
())){NXEvent::afterSessionStart ();}}sub considerBeforeSessionClose{if (((
isNotSessionCloseStarted ()and getSessionType ())and (
Common::NXSessionType::isVirtual (getSessionType ())||
Common::NXSessionType::isAttach (getSessionType ())))){if ((isNotRestoreSession 
()and isNotFirstAttach ())){NXEvent::beforeSessionClose ();}}}sub 
considerAfterSessionClose{if ((getSessionType ()and (
Common::NXSessionType::isVirtual (getSessionType ())||
Common::NXSessionType::isAttach (getSessionType ())))){if ((isNotRestoreSession 
()and isNotFirstAttach ())){NXEvent::afterSessionClose ();}}}sub 
considerAfterSessionFailure{if (((getSessionType ()and 
Common::NXSessionType::isVirtual (getSessionType ()))or 
Common::NXSessionType::isAttach (getSessionType ()))){if ((isNotRestoreSession 
()and isNotFirstAttach ())){NXEvent::afterSessionFailure ();}}}sub 
considerAfterLocalSessionClose{if (Common::NXSessionType::isPhysical (
getSessionType ())){NXEvent::afterLocalSessionClose ();}}sub 
considerAfterLocalSessionFailure{if (Common::NXSessionType::isPhysical (
getSessionType ())){NXEvent::afterLocalSessionFailure ();}}sub 
setSessionCloseStarted{($sessionCloseStarted=(0x0abc+ 3156-0x170f));}sub 
isSessionCloseStarted{return ($sessionCloseStarted);}sub 
isNotSessionCloseStarted{return ((!isSessionCloseStarted ()));}return (
(0x1486+ 1836-0x1bb1));
