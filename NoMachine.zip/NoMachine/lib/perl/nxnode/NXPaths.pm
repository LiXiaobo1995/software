############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXPaths::BEGIN{package NXPaths;no warnings;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}package
 NXPaths;no warnings;require Common::NXFile;sub getServerLogDir{(my $LogDir=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));return ($LogDir);
}sub getNodeRootDirectory{(my $directory=
Common::NXPaths::getNodeRootDirectoryPath ());if ((not (Common::NXFile::isExists
 ($directory)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x72\x6f\x6f\x74\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$directory)."\x2e"));my ($createDirectoryError);if ((
Common::NXPaths::createNodeRootDirectory ((\$createDirectoryError),$directory)==
(0x1f59+ 356-0x20bd))){main::checkin_session_dir (undef);
main::node_finish_error_simple (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72\x65\x63\x74\x6f\x72\x79"
,$directory,$createDirectoryError);}}return ($directory);}sub 
__pathToEffectiveUserDirectory{if (Common::NXCore::isEffectiveUsernameSystem ())
{return (Common::NXPaths::getNxDirectoryInHomeOfDesktopOwnerOnWindows ());}
return (get_user_nx_dir ());}sub __getEffectiveUser{(my ($user,$tmp)=
NXLocalSession::getDisplayOwnerAndType ());return ($user);}sub 
__getNXDirectoryForEffectiveUser{(my $directory=__pathToEffectiveUserDirectory 
());if ((not (Common::NXFile::directoryExists ($directory)))){(my $user=
__getEffectiveUser ());Logger::debug (((((
"\x27\x2e\x6e\x78\x27\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x66\x6f\x72\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x73\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$directory)."\x20\x66\x6f\x72\x20").$user)."\x2e"));my ($createDirectoryError);
if ((Common::NXPaths::createAccessibleForUserDirectory ((\$createDirectoryError)
,$directory,$user)==(0x1102+ 1381-0x1667))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27"
.$directory)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20\x27").
$createDirectoryError)."\x27"));main::clean_and_die (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72\x65\x63\x74\x6f\x72\x79"
,$directory,$createDirectoryError);}}return ($directory);}sub 
getClientMonitorRootDirectory{return (__getNXDirectoryForEffectiveUser ());}sub 
getClientMonitorNxHomeDirectory{return (__getNXDirectoryForEffectiveUser ());}
sub getNxConfigPath{return (__getNXDirectoryForEffectiveUser ());}sub 
get_user_nx_dir{(my $loginName=Common::NXCore::getLoginNameWindows ());(my $systemUser
=libnxh::NXIsSystemUser ($loginName));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x49\x73\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72\x28"
.$loginName)."\x29\x20\x5b").$systemUser)."\x5d"));if (($systemUser==
(0x0709+ 281-0x0822))){return (getMirrorPath ());}if (($loginName eq "\x6e\x78")
){return (getMirrorPath ());}return (((
Common::NXPaths::getEffectiveUserHomeDirectory ().$GLOBAL::DIRECTORY_SLASH).
"\x2e\x6e\x78"));}sub getClientMonitorSessionDirBaseOnLongID{(my $longSessionId=
shift (@_));(my $path=(shift (@_)||getClientMonitorRootDirectory ()));return (((
($path.$GLOBAL::DIRECTORY_SLASH).$GLOBAL::ClientDirectoryPrefix).$longSessionId)
);}sub longClientMonitorPathToTerminateDir{(my $longSessionId=shift (@_));(my $path
=(shift (@_)||getClientMonitorRootDirectory ()));return ((((($path.
$GLOBAL::DIRECTORY_SLASH)."\x54\x2d").$GLOBAL::ClientDirectoryPrefix).
$longSessionId));}sub longClientMonitorPathToFailedDir{(my $longSessionId=shift 
(@_));(my $path=(shift (@_)||getClientMonitorRootDirectory ()));return (((((
$path.$GLOBAL::DIRECTORY_SLASH)."\x46\x2d").$GLOBAL::ClientDirectoryPrefix).
$longSessionId));}sub longSessionIdPathToAgentMDir{(my $longSessionId=shift (@_)
);(my $path=(shift (@_)||getNodeRootDirectory ()));return (((($path.
$GLOBAL::DIRECTORY_SLASH)."\x43\x2d").$longSessionId));}sub 
longSessionIdPathToTerminateDir{(my $longSessionId=shift (@_));(my $path=(shift 
(@_)||getNodeRootDirectory ()));return (((($path.$GLOBAL::DIRECTORY_SLASH).
"\x54\x2d\x43\x2d").$longSessionId));}sub longSessionIdPathToFailedDir{(my $longSessionId
=shift (@_));(my $path=(shift (@_)||getNodeRootDirectory ()));return (((($path.
$GLOBAL::DIRECTORY_SLASH)."\x46\x2d\x43\x2d").$longSessionId));}sub 
sessionDirPathToOptionsFile{(my $sessionDir=shift (@_));return ((($sessionDir.
$GLOBAL::DIRECTORY_SLASH)."\x6f\x70\x74\x69\x6f\x6e\x73"));}sub 
sessionDirPathToLocalXauthorityScript{(my $sessionDir=shift (@_));return (((
$sessionDir.$GLOBAL::DIRECTORY_SLASH).
"\x61\x75\x74\x68\x6f\x72\x69\x74\x79\x73\x63\x72\x69\x70\x74"));}sub 
sessionDirPathToLocalXauthorityFile{(my $sessionDir=shift (@_));return (((
$sessionDir.$GLOBAL::DIRECTORY_SLASH)."\x61\x75\x74\x68\x6f\x72\x69\x74\x79"));}
sub sessionDirPathToLocalSessionFile{(my $sessionDir=shift (@_));return (((
$sessionDir.$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x73\x73\x69\x6f\x6e"));}sub 
sessionDirPathToAudioDir{(my $sessionDir=shift (@_));return ((($sessionDir.
$GLOBAL::DIRECTORY_SLASH)."\x61\x75\x64\x69\x6f"));}sub 
sessionDirPathToPulseNativeSocket{(my $sessionDir=shift (@_));(my $audioPath=
sessionDirPathToAudioDir ($sessionDir));return ((($audioPath.
$GLOBAL::DIRECTORY_SLASH)."\x6e\x61\x74\x69\x76\x65\x2e\x73\x6f\x63\x6b\x65\x74"
));}sub sessionDirPathToPulseCliSocket{(my $sessionDir=shift (@_));(my $audioPath
=sessionDirPathToAudioDir ($sessionDir));return ((($audioPath.
$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x69\x2e\x73\x6f\x63\x6b\x65\x74"));}sub 
runDirPath{(my $varDir=$GLOBAL::VAR_ROOT);return ((($varDir.
$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e"));}sub nxdeviceDirPath{return (((
__getNXDirectoryForEffectiveUser ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x64\x65\x76\x69\x63\x65"));}sub nxdeviceSessionDirPath{(my $sessionId=
shift (@_));(my $varDir=nxdeviceDirPath ());return (((($varDir.
$GLOBAL::DIRECTORY_SLASH)."\x44\x2d").$sessionId));}sub getAudioNativeSocketPath
{(my $display=shift (@_));(my $sessionId=shift (@_));(my $sessionDir=
nxdeviceSessionDirPath ((($display."\x2d").$sessionId)));(my $path=((
sessionDirPathToAudioDir ($sessionDir).$GLOBAL::DIRECTORY_SLASH).
"\x6e\x61\x74\x69\x76\x65\x2e\x73\x6f\x63\x6b\x65\x74"));return ($path);}sub 
getAudioInFifoPath{(my $display=shift (@_));(my $sessionId=shift (@_));(my $sessionDir
=nxdeviceSessionDirPath ((($display."\x2d").$sessionId)));(my $path=((
sessionDirPathToAudioDir ($sessionDir).$GLOBAL::DIRECTORY_SLASH).
"\x61\x75\x64\x69\x6f\x5f\x69\x6e\x2e\x66\x69\x66\x6f"));return ($path);}sub 
getVoiceOutFifoPath{(my $display=shift (@_));(my $sessionId=shift (@_));(my $sessionDir
=nxdeviceSessionDirPath ((($display."\x2d").$sessionId)));(my $path=((
sessionDirPathToAudioDir ($sessionDir).$GLOBAL::DIRECTORY_SLASH).
"\x76\x6f\x69\x63\x65\x5f\x6f\x75\x74\x2e\x66\x69\x66\x6f"));return ($path);}sub
 getMirrorPath{return (getNodeRootDirectory ());return (((((
Common::NXPaths::getEffectiveUserHomeDirectory ().$GLOBAL::DIRECTORY_SLASH).
"\x2e\x6e\x78").$GLOBAL::DIRECTORY_SLASH)."\x6d\x69\x72\x72\x6f\x72"));}sub 
getPathToSocketFileForPassDescriptorToAnotherNode{(my $sessionID=shift (@_));(my $socketPath
=(((Common::NXPaths::windowsGetTempPath ().$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x73\x73\x69\x6f\x6e\x2d").$sessionID));return ($socketPath);}sub 
getPathToServerDB{(my $path=(((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x64\x62").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72"));return ($path
);}sub createAndCorrectUserNXDirectoryOnWindows{(my $nxDirectoryPath=shift (@_))
;(my $ref_errorName=shift (@_));if (($nxDirectoryPath eq (""))){return (
(0x02a1+ 1366-0x07f7));}if ((not (Common::NXPaths::makePath ($ref_errorName,
$nxDirectoryPath)))){return ((0x0af3+ 1705-0x119c));}else{(my $change=
correctUserNXDirectoryPermissionsOnWindows ($nxDirectoryPath));return ($change);
}}sub correctTmpNXDirectoryPermissionsOnWindows{(my $nxDirectoryPath=shift (@_))
;if (($nxDirectoryPath eq (""))){($nxDirectoryPath=
Common::NXPaths::getFailbackHomeDirectoryPathFromNXTemp ());}if ((
Common::NXFile::setPermissionsFullForAllDirectory ($nxDirectoryPath)==(-
(0x16c0+ 812-0x19eb)))){return ((0x0bb1+ 1203-0x1064));}
Common::NXCore::setHiddenAttributeOnWindows ($nxDirectoryPath);return (
(0x0ca1+ 6520-0x2618));}sub correctUserNXDirectoryPermissionsOnWindows{(my $nxDirectoryPath
=shift (@_));my ($error);if (($nxDirectoryPath eq (""))){($nxDirectoryPath=
Common::NXPaths::getNxDirectoryInHomeOfDesktopOwnerOnWindows ((\$error)));}if ((
(not (Common::NXFile::directoryExists ($nxDirectoryPath)))and defined ($error)))
{main::clean_and_die (
"\x65\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x57\x69\x74\x68\x53\x79\x73\x74\x65\x6d\x45\x72\x72\x6f\x72"
,$nxDirectoryPath,$error);}if (($nxDirectoryPath eq 
Common::NXPaths::getFailbackHomeDirectoryPathFromNXTemp ())){return (
correctTmpNXDirectoryPermissionsOnWindows ($nxDirectoryPath));}(my ($user,$tmp)=
NXLocalSession::getDisplayOwnerAndType ());if (($user eq 
"\x64\x65\x74\x61\x63\x68\x65\x64")){return ((0x163c+ 3938-0x259e));}if ((
Common::NXFile::setPermissionsInheritAndAllowTakeOwnershipIfNeeded (
$nxDirectoryPath)==(-(0x0d20+ 5612-0x230b)))){return ((0x1a1f+  88-0x1a77));}
Common::NXCore::setHiddenAttributeOnWindows ($nxDirectoryPath);if ((($user eq 
(""))and Common::NXCore::isEffectiveUsernameSystem ())){($user=
"\x53\x59\x53\x54\x45\x4d");}if ((Common::NXFile::setOwnershipForUser (
$nxDirectoryPath,$user)==(-(0x16bb+ 138-0x1744)))){return ((0x0710+ 6938-0x222a)
);}return ((0x0ce7+ 4939-0x2031));}sub getLogoutScript{return (((((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x73\x63\x72\x69\x70\x74\x73").
$GLOBAL::DIRECTORY_SLASH)."\x65\x6e\x76").$GLOBAL::DIRECTORY_SLASH).
"\x66\x6f\x72\x63\x65\x6c\x6f\x67\x6f\x75\x74\x2e\x62\x61\x74"));}return (
(0x1493+ 3177-0x20fb));
