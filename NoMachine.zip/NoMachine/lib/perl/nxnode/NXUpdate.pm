############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUpdate::BEGIN{package NXUpdate;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXUpdate::BEGIN{package 
NXUpdate;no warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import (
"\x3a\x74\x72\x79")};}sub NXUpdate::BEGIN{package NXUpdate;no warnings;require 
POSIX;do{"\x50\x4f\x53\x49\x58"->import ("\x3a\x73\x69\x67\x6e\x61\x6c\x5f\x68",
"\x3a\x65\x72\x72\x6e\x6f\x5f\x68",
"\x3a\x73\x79\x73\x5f\x77\x61\x69\x74\x5f\x68")};}sub NXUpdate::BEGIN{package 
NXUpdate;no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}package 
NXUpdate;no warnings;require Common::NXFile;($updatePid=(0x0d45+ 4163-0x1d88));
sub setUpdateCommand{(my $mode=(shift (@_)||("")));(my $ignore=(shift (@_)||("")
));my (@command,@parameters);push (@parameters,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");my ($userName,$home,$userGroup,$nx_root)
;push (@command,$GLOBAL::CommandClientBin);if (($mode ne "\x61\x73\x6b")){push (
@command,"\x2d\x2d\x75\x70\x64\x61\x74\x65","\x63\x68\x65\x63\x6b",
"\x2d\x2d\x73\x69\x6c\x65\x6e\x74");}else{(my $homeDir=((
Common::NXPaths::getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));
push (@command,"\x2d\x2d\x75\x70\x64\x61\x74\x65","\x61\x73\x6b",
"\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64","\x2d\x2d\x72\x6f\x6f\x74",
$homeDir);}if (($mode ne "\x61\x73\x6b")){if (($ignore ne (""))){push (@command,
"\x2d\x2d\x69\x67\x6e\x6f\x72\x65",$ignore);}}foreach my $key (keys (%ENV)){if (
(((((($key ne "\x4e\x58\x5f\x52\x4f\x4f\x54")and ($key ne 
"\x55\x53\x45\x52\x4e\x41\x4d\x45"))and ($key ne "\x48\x4f\x4d\x45"))and ($key 
ne "\x4e\x58\x5f\x55\x53\x45\x52"))and ($key ne 
"\x4e\x58\x5f\x47\x52\x4f\x55\x50"))and ($key ne 
"\x4e\x58\x5f\x43\x4f\x4e\x46\x49\x47"))){push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(($key."\x3d").libnxh::NXTransGetEnvironment (
$key)));}}($userName=__getUserName ());($userGroup=
Common::NXCore::getEffectiveUserGroupID ());($home=
Common::NXPaths::getUserHomeDirectory ($userName));($nx_root=(($home.
$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x6e\x61\x6d\x65\x3a\x20".$userName).
"\x2c\x20\x67\x72\x6f\x75\x70\x3a\x20").$userGroup)."\x2e"));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x52\x4f\x4f\x54\x3d".$nx_root));
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x46\x49\x47\x3d".$nx_root));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$home));push (@parameters
,"\x73\x65\x74\x20\x65\x6e\x76",("\x55\x53\x45\x52\x4e\x41\x4d\x45\x3d".
$userName));push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x55\x53\x45\x52\x3d".$userName));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x47\x52\x4f\x55\x50\x3d".
$userGroup));return ((\@command),(\@parameters));}sub checkCommand{return (
(0x0944+ 4818-0x1c15));if ((-x ($GLOBAL::CommandNXexec)and 
Common::NXFile::fileExists ($GLOBAL::SCRIPT_NXUPDATE))){return (
(0x02f7+ 7223-0x1f2d));}else{if (-x (Common::NXCore::getNXExecCommand ())){
Logger::debug2 (((
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20".
Common::Core::getNXExecCommand ())."\x2e"));}else{Logger::debug2 (((
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x73\x63\x72\x69\x70\x74\x3a\x20".
$GLOBAL::SCRIPT_NXUPDATE)."\x2e"));}return ((0x0661+ 649-0x08ea));}}sub 
handleSilentUpdate{(my $ignore=(shift (@_)||("")));(my ($cmd_err,$cmd_out,
$exit_value)=(""));(my $pid=(0x1b43+ 827-0x1e7e));if ((checkCommand ()==
(0x0ab3+ 6316-0x235f))){return;}(my $udpateMode="\x73\x69\x6c\x65\x6e\x74");(my (
$command,$options)=setUpdateCommand ($udpateMode,$ignore));my (@parameters);push
 (@parameters,"\x67\x65\x74\x20\x70\x69\x64",(\$pid));push (@parameters,
@$options);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x5b"
.join ($",@$command))."\x5d\x2c\x20\x6f\x70\x74\x69\x6f\x6e\x73\x3a\x20\x5b").
join ($",@parameters))."\x5d"));(($cmd_err,$cmd_out,$exit_value)=
main::nxRunCommand ((\@$command),(\@parameters)));if ((($pid ne (""))and ($pid>
(0x0fbb+ 4220-0x2037)))){Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20\x63\x68\x65\x63\x6b\x20\x2d\x2d\x73\x69\x6c\x65\x6e\x74\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));Common::NXProcess::setCallbackSIGCHLD ($pid,(
\&sendRemoveSilentUpdatePidToServer));sendUpdatePidToServer ($pid);}else{
Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20\x63\x68\x65\x63\x6b\x20\x2d\x2d\x73\x69\x6c\x65\x6e\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x3a\x20"
.$exit_value)."\x2e"));}}sub handleBackgroundAsk{(my ($cmd_err,$cmd_out,
$exit_value)=(""));(my $pid=(0x01f4+ 6537-0x1b7d));if ((checkCommand ()==
(0x1d8a+ 747-0x2075))){return;}(my $udpateMode="\x61\x73\x6b");(my ($command,
$options)=setUpdateCommand ($udpateMode));my (@parameters);push (@parameters,
"\x67\x65\x74\x20\x70\x69\x64",(\$pid));push (@parameters,@$options);
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x5b"
.join ($",@$command))."\x5d\x2c\x20\x6f\x70\x74\x69\x6f\x6e\x73\x3a\x20\x5b").
join ($",@parameters))."\x5d"));(($cmd_err,$cmd_out,$exit_value)=
main::nxRunCommand ((\@$command),(\@parameters)));if ((($pid ne (""))and ($pid>
(0x1d12+ 2219-0x25bd)))){Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20\x61\x73\x6b\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));Common::NXProcess::setCallbackSIGCHLD ($pid,(
\&sendRemoveUpdatePidToServer));sendUpdatePidToServer ($pid);}else{Logger::debug
 (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20\x61\x73\x6b\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x3a\x20"
.$exit_value)."\x2e"));}}sub setXauthorityFile{(my $nxDir=shift (@_));(my $username
=shift (@_));(my $xauth=Agent::getLocalXauthorityFilePath ());if ((not (
Common::NXFile::isExists ($nxDir)))){if ((not (mkdir ($nxDir)))){Logger::warning
 (((("\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6b\x64\x69\x72\x20".$nxDir).
"\x20\x3a\x20").$!));return ((0x1677+ 3627-0x24a2));}else{Logger::debug2 (((
"\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20".$nxDir).
"\x20\x63\x72\x65\x61\x74\x65\x64\x2e"));
Common::NXFile::setPermissionsFullForUser ($nxDir,$username);}}($newDir=(($nxDir
.$GLOBAL::DIRECTORY_SLASH)."\x74\x65\x6d\x70"));if ((not (
Common::NXFile::isExists ($newDir)))){if ((not (mkdir ($newDir)))){
Logger::warning (((("\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6b\x64\x69\x72\x20".
$newDir)."\x20\x3a\x20").$!));return ((0x1c85+ 1409-0x2206));}else{
Logger::debug2 ((("\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20".$newDir).
"\x20\x63\x72\x65\x61\x74\x65\x64\x2e"));
Common::NXFile::setPermissionsFullForAll ($newDir);}}(my (@auth)=split ( /\// ,
$xauth,(0x01ad+ 884-0x0521)));($newXAuthFile=(($newDir.$GLOBAL::DIRECTORY_SLASH)
.$auth[$#auth]));(my ($retValue,$outMsg)=Common::NXCore::copyFile ($xauth,
$newXAuthFile));if (($retValue ne (0x0205+ 4528-0x13b5))){Logger::error ((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x63\x6f\x70\x79\x3a\x20"
.$xauth)."\x2c\x20\x74\x6f\x3a\x20").$newXAuthFile).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$outMsg));return;}Logger::debug 
((((("\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x63\x6f\x70\x69\x65\x64\x3a\x20".
$xauth)."\x2c\x20\x74\x6f\x3a\x20").$newXAuthFile)."\x2e"));($xauth=
$newXAuthFile);return ($xauth);}sub sendUpdatePidToServer{($updatePid=shift (@_)
);Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x75\x70\x64\x61\x74\x65\x20\x70\x69\x64\x3a\x20"
.$updatePid)."\x2c\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e"));(my $pid
=main::urlencode ($updatePid));(my $msg=((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPDATE_PID)."\x20").$pid));main::nxwrite (main::nxgetSTDOUT (),(
$msg."\x0a"));}sub sendRemoveSilentUpdatePidToServer{(my $pid=shift (@_));(my $exit_status
=shift (@_));(my $isEAGAIN=(0x066d+ 6325-0x1f22));if (($exit_status==EAGAIN ()))
{($isEAGAIN=(0x19d4+ 2377-0x231c));}($pid=main::urlencode ($pid));(my $msg=(((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_UPDATE_REMOVE_PID)."\x20\x70\x69\x64\x3d").$pid)
."\x20\x65\x61\x67\x61\x69\x6e\x3d").$isEAGAIN));main::nxwrite (
main::nxgetSTDOUT (),($msg."\x0a"));}sub sendRemoveUpdatePidToServer{(my $pid=
shift (@_));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x20\x70\x69\x64\x3a\x20"
.$updatePid)."\x2c\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e"));($pid=
main::urlencode ($pid));(my $msg=((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPDATE_REMOVE_PID)."\x20\x70\x69\x64\x3d").$pid));main::nxwrite (
main::nxgetSTDOUT (),($msg."\x0a"));}sub __getUserName{(my ($userName,$tmp)=
NXLocalSession::getDisplayOwnerAndType ());return ($userName);}sub getUpdatePid{
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x50\x49\x44\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20"
.$UpdatePid)."\x2e"));send_response_message ($GLOBAL::MSG_UPDATE_PID,$UpdatePid)
;return;}return ((0x179b+ 1314-0x1cbc));
