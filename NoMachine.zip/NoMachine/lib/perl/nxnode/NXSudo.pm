############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXSudo;no warnings;($certificate=(""));($commandPid=(-
(0x18d3+ 3221-0x2567)));($pipeIn=(-(0x03ef+ 7752-0x2236)));($pipeOut=(-
(0x20c9+ 373-0x223d)));($commandSTDIN=(-(0x1d3d+ 118-0x1db2)));($commandSTDOUT=(
-(0x1451+ 955-0x180b)));($selector=(-(0x1254+ 4434-0x23a5)));($signalFd=(-
(0x04cb+ 2516-0x0e9e)));sub __setSudoProcesOUT{(my $descriptor=shift (@_));(
$stdoutFH=$descriptor);}sub __setSudoProcesIN{(my $descriptor=shift (@_));(
$stdinFH=$descriptor);}sub __getSudoProcesSTDOUT{return ($stdoutFH);}sub 
__getSudoProcesSTDIN{return ($stdinFH);}sub __createConsole{main::nxrequire (
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65");
NXConsole::createConsole ();}sub __addConsoleToOptions{(my $ref_options=shift (
@_));push (@$ref_options,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",
NXConsole::getConsoleChildIN ());push (@$ref_options,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",
NXConsole::getConsoleChildOUT ());push (@$ref_options,
"\x45\x52\x52\x69\x6e\x4f\x55\x54");push (@$ref_options,
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",
NXConsole::getConsoleChildIN ());push (@$ref_options,
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",
NXConsole::getConsoleChildOUT ());}sub __setPipeIn{(my $desc=shift (@_));(
$pipeIn=$desc);}sub __setPipeOut{(my $desc=shift (@_));($pipeOut=$desc);}sub 
__getPipeIn{return ($pipeIn);}sub __getPipeOut{return ($pipeOut);}sub 
__setPipeAsCommandDescriptors{__setSudoProcesOUT (__getPipeIn ());
__setSudoProcesIN (__getPipeIn ());}sub __setConsoleAsCommandDescriptors{
__setSudoProcesOUT (NXConsole::getConsoleDescriptor ());__setSudoProcesIN (
NXConsole::getConsoleDescriptor ());}sub __createPipe{(my $socketServer=(-
(0x0d27+ 1128-0x118e)));(my $socketNode=(-(0x03af+ 3080-0x0fb6)));(my $nxpipeReturn
=main::nxPipeCreateBi ((\$socketServer),(\$socketNode)));Logger::debug (((((((
"\x3a\x3a\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x42\x69\x28".
$socketServer)."\x2c\x20").$socketNode)."\x29\x20\x5b").$nxpipeReturn)."\x5d"));
__setPipeIn ($socketServer);__setPipeOut ($socketNode);(my $setInheritableReturn
=libnxh::NXDescriptorInheritable (__getPipeOut (),(0x0d9c+ 3231-0x1a3a)));
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.__getPipeOut ()).(("\x2c\x20\x31\x29\x20\x5b".$setInheritableReturn)."\x5d")));
}sub __addPipeToOptions{(my $ref_options=shift (@_));push (@$ref_options,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",__getPipeOut ());push (
@$ref_options,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",
__getPipeOut ());push (@$ref_options,
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",__getPipeOut ());}sub 
__prepareSTDDescriptors{(my $ref_options=shift (@_));__createPipe ();
__addPipeToOptions ($ref_options);__setPipeAsCommandDescriptors ();}sub 
__argumentsAdd{(my $ref_command=shift (@_));if (defined ($GLOBAL::parameters{
"\x68\x6f\x73\x74"})){push (@$ref_command,$GLOBAL::parameters{"\x68\x6f\x73\x74"
});}elsif (defined ($GLOBAL::parameters{"\x6e\x6f\x64\x65"})){push (
@$ref_command,$GLOBAL::parameters{"\x6e\x6f\x64\x65"});}elsif (defined (
$GLOBAL::parameters{"\x73\x65\x72\x76\x65\x72"})){push (@$ref_command,
$GLOBAL::parameters{"\x73\x65\x72\x76\x65\x72"});}foreach my $elem (keys (
%GLOBAL::parameters)){if ((((($elem ne "\x63\x6f\x6d\x6d\x61\x6e\x64")and ($elem
 ne "\x68\x6f\x73\x74"))and ($elem ne "\x6e\x6f\x64\x65"))and ($elem ne 
"\x73\x65\x72\x76\x65\x72"))){push (@$ref_command,((("\x2d\x2d".$elem)."\x3d").
$GLOBAL::parameters{$elem}));}}}sub __startingParsingLoop{($selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;($signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});Logger::debug (((
"\x73\x75\x64\x6f\x50\x72\x6f\x63\x65\x73\x53\x54\x44\x4f\x55\x54\x20\x27".
__getSudoProcesSTDOUT ())."\x27"));$selector->add (__getSudoProcesSTDOUT ());
Logger::debug ((("\x6e\x78\x67\x65\x74\x53\x54\x44\x49\x4e\x20\x27".
main::nxgetSTDIN ())."\x27"));$selector->add (main::nxgetSTDIN ());Logger::debug
 ((("\x73\x69\x67\x6e\x61\x6c\x46\x64\x20\x27".$signalFd)."\x27"));$selector->
add ($signalFd);(my $loopTimeout=(-(0x1724+ 2052-0x1f27)));(my $waitingForStdoutToClose
=(0x13af+ 251-0x14aa));while ((my (@ready)=$selector->can_read ($loopTimeout))){
foreach my $fh (@ready){Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x5b".$fh)."\x5d"));if (($fh==
__getSudoProcesSTDOUT ())){parseCommandOutput ();}elsif (($fh==main::nxgetSTDIN 
())){parseMsgFromServer ();}else{parseSignalMsg ();}}if ((__sudoProcesFinished 
()and __sudoProcessCloseStdout ())){Logger::debug (
"\x5f\x5f\x73\x74\x61\x72\x74\x69\x6e\x67\x50\x61\x72\x73\x69\x6e\x67\x4c\x6f\x6f\x70\x20\x6c\x61\x73\x74"
);last;}elsif (__sudoProcesFinished ()){if ((not ($waitingForStdoutToClose))){
Logger::debug (
"\x5f\x5f\x73\x74\x61\x72\x74\x69\x6e\x67\x50\x61\x72\x73\x69\x6e\x67\x4c\x6f\x6f\x70\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2c\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x74\x64\x6f\x75\x74\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x2e"
);($waitingForStdoutToClose=(0x12d6+ 843-0x1620));($loopTimeout=
(0x0ed6+ 2427-0x165d));}}else{Logger::debug (
"\x5f\x5f\x73\x74\x61\x72\x74\x69\x6e\x67\x50\x61\x72\x73\x69\x6e\x67\x4c\x6f\x6f\x70\x20\x6e\x6f\x74\x20\x6c\x61\x73\x74\x20\x79\x65\x74"
);}}if ($waitingForStdoutToClose){Logger::debug (
"\x5f\x5f\x73\x74\x61\x72\x74\x69\x6e\x67\x50\x61\x72\x73\x69\x6e\x67\x4c\x6f\x6f\x70\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x62\x75\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x61\x73\x20\x6e\x6f\x74\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);__removeFromSelector (__getSudoProcesSTDOUT ());__setSudoProcessCloseStdout ()
;}Logger::debug (
"\x5f\x5f\x73\x74\x61\x72\x74\x69\x6e\x67\x50\x61\x72\x73\x69\x6e\x67\x4c\x6f\x6f\x70\x20\x66\x69\x6e\x69\x73\x68\x65\x64"
);__releaseSudoFinishedMessage ();}sub __releaseSudoFinishedMessage{(my $message
=("\x4e\x58\x3e\x20".$GLOBAL::MSG_SUDO_FINISHED));main::nxwrite (
main::nxgetSTDOUT (),($message."\x0a"));($GLOBAL::parameters{"\x68\x6f\x73\x74"}
=undef);($GLOBAL::parameters{"\x6e\x6f\x64\x65"}=undef);}sub 
__removeFromSelector{(my $fd=shift (@_));$selector->remove ($fd);}sub 
__sudoProcesFinished{Logger::debug ((
"\x5f\x5f\x73\x75\x64\x6f\x50\x72\x6f\x63\x65\x73\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x72\x65\x74\x75\x72\x6e\x20"
.$sudoProcessFinished));return ($sudoProcessFinished);}sub 
__setSudoProcesFinished{($sudoProcessFinished=(0x0a45+ 3113-0x166d));}sub 
__setSudoProcesStarted{($sudoProcessFinished=(0x13c5+ 149-0x145a));}sub 
__cleanParser{__removeFromSelector (__getSudoProcesSTDOUT ());
__removeFromSelector ($signalFd);__removeFromSelector (main::nxgetSTDIN ());}sub
 __sudoProcessCloseStdout{Logger::debug ((
"\x5f\x5f\x73\x75\x64\x6f\x50\x72\x6f\x63\x65\x73\x73\x43\x6c\x6f\x73\x65\x53\x74\x64\x6f\x75\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$sudoProcessCloseStdout));return ($sudoProcessCloseStdout);}sub 
__setSudoProcessCloseStdout{($sudoProcessCloseStdout=(0x1681+ 3019-0x224b));}sub
 __setSudoProcessOpenStdout{($sudoProcessCloseStdout=(0x06d1+ 7904-0x25b1));}sub
 parseCommandOutput{(my $read_buf=(""));(my $bytes_read=main::nxread (
__getSudoProcesSTDOUT (),(\$read_buf),(0x178f+ 939-0x0b3a)));if ((($bytes_read 
eq (0x10ba+ 5264-0x254a))or (not (defined ($bytes_read))))){Logger::debug (
"\x53\x75\x64\x6f\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x63\x6c\x6f\x73\x65\x20\x73\x74\x64\x6f\x75\x74\x2e"
);__removeFromSelector (__getSudoProcesSTDOUT ());__setSudoProcessCloseStdout ()
;}else{(my $sudoMessage=Common::NXCore::urlencode ($read_buf));(my $message=((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_SUDO_OUTPUT).
"\x20\x73\x75\x64\x6f\x20\x6f\x75\x74\x70\x75\x74\x20\x69\x73\x3a\x20").
$sudoMessage)."\x20"));Logger::debug2 (((
"\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x20\x73\x75\x64\x6f\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x75\x74\x70\x75\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x27"
.$message)."\x27\x2e"));main::nxwrite (main::nxgetSTDOUT (),($message."\x0a"));}
}sub parseMsgFromServer{my ($read_buf);Logger::debug (((
"\x54\x72\x79\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x46\x44\x23".main::nxgetSTDIN 
())."\x2e"));(my $bytes_read=main::nxread (main::nxgetSTDIN (),(\$read_buf),
(0x1184+ 3408-0x0ed4)));if (((not (defined ($bytes_read)))or ($bytes_read==
(0x08c7+ 6946-0x23e9)))){(my $error=libnxh::NXGetErrorName ());Logger::debug (((
(((("\x3a\x3a\x6e\x78\x72\x65\x61\x64\x28".$fh)."\x2c\x20").$read_buf).
"\x2c\x20\x34\x30\x39\x36\x29\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").
$error)."\x27\x2e"));if (($error eq "\x45\x41\x47\x41\x49\x4e")){return (
(0x0a79+ 1361-0x0fca));}}if (($bytes_read==(0x1482+ 3768-0x233a))){Logger::debug
 (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2c\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x2e"
);finishCommand ();}elsif (($read_buf=~ /NX> $GLOBAL::MSG_TO_SUDO_PROCES (.*) / )
){(my $msgToSudo=$1);(my $writeResult=main::nxwrite (__getSudoProcesSTDIN (),
Common::NXCore::urldecode ($msgToSudo)));Logger::debug (((
"\x57\x72\x69\x74\x65\x20\x74\x6f\x20\x73\x75\x64\x6f\x20\x70\x72\x6f\x63\x65\x73\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x3a\x20"
.$writeResult)."\x2e"));}elsif (($read_buf=~ /NX> $GLOBAL::MSG_REQUEST_FOR_PING/ )
){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x73\x65\x6e\x64\x20\x70\x69\x6e\x67\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72"
,(0x1177+ 5329-0x2648));NXPingMonitor::handleRequestForPingMessage ();}elsif ((
$read_buf=~ /NX> $GLOBAL::MSG_NODE_PONG/ )){Logger::debug (
"\x47\x6f\x74\x20\x70\x69\x6e\x67\x20\x72\x65\x70\x6c\x79\x20\x66\x72\x6f\x6d\x20\x4e\x58\x20\x73\x65\x72\x76\x65\x72"
,(0x168c+ 542-0x18aa));}elsif (($read_buf=~ /NX> $GLOBAL::MSG_PASSWORD_ANSWER password=(.*) / )
){(my $password=$1);(my $bytes=main::nxwrite (__getSudoProcesSTDIN (),($password
."\x0a\x0a\x0a")));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x74\x6f\x20\x73\x75\x64\x6f\x20\x5b"
.$bytes)."\x5d"));}else{removeEOLFromBuffer ((\$read_buf));(my $bytes=
main::nxwrite (__getSudoProcesSTDIN (),($read_buf."\x0a")));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x27".$read_buf).
"\x27\x20\x74\x6f\x20\x73\x75\x64\x6f\x2e"));}}sub parseSignalMsg{Logger::debug3
 (
"\x53\x49\x47\x4e\x41\x4c\x20\x61\x72\x72\x69\x76\x65\x20\x62\x75\x74\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x68\x61\x6e\x64\x6c\x65\x64\x2e"
);}sub runAsSudo{(my $line=shift (@_));if (__dropWindowsNotAdmins ()){return (
(0x0e48+ 6112-0x2628));}main::parse_arguments ($line);(my $commandToRun=
$GLOBAL::parameters{"\x63\x6f\x6d\x6d\x61\x6e\x64"});Logger::debug (((
"\x72\x75\x6e\x41\x73\x53\x75\x64\x6f\x20\x27".$commandToRun)."\x27"));(my (
@options)=());push (@options,"\x67\x65\x74\x20\x70\x69\x64",(\$commandPid));
__prepareSTDDescriptors ((\@options));__setSudoProcessOpenStdout ();push (
@options,"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");
push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x6f\x75\x74\x20\x6f\x70\x65\x6e");
Common::NXCore::cleanOutLanguageCasesInEnvironemt ();push (@options,
"\x66\x75\x6c\x6c\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74");push (
@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");(my (@command)=());
__addSudoCommand ((\@command));push (@command,("\x2d\x2d".$commandToRun));
__argumentsAdd ((\@command));main::nxRunCommand ((\@command),(\@options));
setSIGCHLD ();__setSudoProcesStarted ();__startingParsingLoop ();}sub setSIGCHLD
{Logger::debug ((
"\x73\x65\x74\x53\x49\x47\x43\x48\x4c\x44\x3a\x20\x72\x65\x67\x69\x73\x74\x65\x72\x20\x53\x49\x47\x43\x48\x4c\x44\x20\x6f\x66\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$commandPid));Common::NXProcess::setCallbackSIGCHLD ($commandPid,(
\&sudoCommandExit));}sub sudoCommandExit{Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x53\x49\x47\x43\x48\x4c\x44\x20\x6f\x66\x20\x73\x75\x64\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
);__setSudoProcesFinished ();Common::NXCore::exitFromSelectOnFirstSignal ();
Common::NXCore::exitFromSelectWithSignalFD ();}sub finishCommand{
main::disableNodeShell ();main::node_finish_ok ();}sub removeEOLFromBuffer{(my $ref_buffer
=shift (@_));Logger::debug ((
"\x72\x65\x6d\x6f\x76\x65\x45\x4f\x4c\x46\x72\x6f\x6d\x42\x75\x66\x66\x65\x72\x3a\x20\x65\x6e\x74\x65\x72\x20\x77\x69\x74\x68\x20"
.$$ref_buffer));($$ref_buffer=~ s/\r\n//g );($$ref_buffer=~ s/\n//gs );
Logger::debug ((
"\x72\x65\x6d\x6f\x76\x65\x45\x4f\x4c\x46\x72\x6f\x6d\x42\x75\x66\x66\x65\x72\x3a\x20\x66\x69\x6e\x69\x73\x68\x20\x77\x69\x74\x68\x20"
.$$ref_buffer));}sub removeEOLfromBeginBuffer{(my $ref_buffer=shift (@_));(
$$ref_buffer=~ s/\015//gs );($$ref_buffer=~ s/^\n//gs );}sub __addSudoCommand{(my $ref_command
=shift (@_));push (@$ref_command,(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH
)."\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65"));}sub __dropWindowsNotAdmins
{if ((not (Common::NXCore::isEffectiveUserAdministratorWindows ()))){(my $error=
"\x55\x73\x65\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
);(my $sudoMessage=((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ERROR).
"\x20\x45\x52\x52\x4f\x52\x3a\x20").$error));($sudoMessage=
Common::NXCore::urlencode ($sudoMessage));(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_PASS_MESSAGE_TO_USER).
"\x20\x50\x61\x73\x73\x20\x74\x6f\x20\x75\x73\x65\x72\x20").$sudoMessage)."\x20"
));main::nxwrite (main::nxgetSTDOUT (),($message."\x0a"));return (
(0x01a4+ 1291-0x06ae));}return ((0x154a+ 4473-0x26c3));}"\x3f\x3f\x3f";
