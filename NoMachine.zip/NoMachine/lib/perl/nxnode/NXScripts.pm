############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXScripts::script_run_command{package NXScripts;no warnings;(my ($scriptName
,$scriptOption,$scriptFunction,$session_id,$username,$session_type,$display,
@optional_params)=@_);if ($GLOBAL::SCRIPT_DEBUG){Logger::debug ((((((((((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$scriptFunction)."\x20\x5b").
$session_id)."\x2c").$username)."\x2c").$session_type)."\x5d").("\x20".
$scriptOption)));}if ($scriptName){if ($GLOBAL::SCRIPT_DEBUG){Logger::debug ((((
("\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$scriptFunction)."\x20\x5b").
$scriptName)."\x5d"),(0x1810+ 1818-0x1f2a));}if (-x ($scriptName)){(my (@command
)=($scriptName,$session_id,$username,$session_type,$display,@optional_params));(my (
@parameters)=main::set_environement ());(my ($cmd_err,$cmd_out,$exit_value)=
main::run_command ((\@command),(\@parameters)));if ($GLOBAL::SCRIPT_DEBUG){
Logger::debug (((((((("\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$scriptFunction
)."\x20\x72\x65\x74\x75\x72\x6e\x3a\x5b").$cmd_err)."\x2c").$cmd_out)."\x2c").(
$exit_value."\x5d")));}if ((not ($exit_value))){return ((0x0f9a+ 5140-0x23ae));}
else{Logger::debug (((((
"\x65\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x63\x75\x73\x74\x6f\x6d\x20\x73\x63\x72\x69\x70\x74\x3a\x20"
.$scriptName).
"\x20\x66\x61\x69\x6c\x65\x64\x20\x6f\x6e\x20\x65\x76\x65\x6e\x74\x3a\x20").
$scriptOption)."\x2e"));return ($exit_value);}}else{if ($GLOBAL::SCRIPT_DEBUG){
Logger::debug ((("\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$scriptFunction).
"\x20\x64\x65\x66\x69\x6e\x65\x64\x20\x62\x75\x74\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74"
));}}}return ((0x0fc8+ 3069-0x1bc5));}sub NXScripts::script_check_parameters{
package NXScripts;no warnings;(my ($session_type,$session_id,$username,$display,
$main_session_id,$main_session_type)=@_);if ((not ($session_type))){(
$session_type=NXSession::getSessionType ());}if ((not ($session_id))){(
$session_id=$GLOBAL::SESSION_ID);}if (Common::NXSessionType::isPhysical (
$session_type)){if ((not ($username))){($username=
Common::NXCore::getEffectiveUsername ());}if ((not ($display))){($display=
Agent::getAgentDisplay ());}}else{if ((not ($username))){($username=
$GLOBAL::USERNAME);}if ((not ($display))){($display=$GLOBAL::parameters{
"\x64\x69\x73\x70\x6c\x61\x79"});}}if (Common::NXSessionType::isAttach (
NXSession::getSessionType ())){if ((not ($main_session_id))){($main_session_id=
$GLOBAL::parameters{
"\x61\x74\x74\x61\x63\x68\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x69\x64"});}if ((
not ($main_session_type))){($main_session_type=$GLOBAL::parameters{
"\x61\x74\x74\x61\x63\x68\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x74\x79\x70\x65"})
;}return ($session_id,$username,$session_type,$display,$main_session_id,
$main_session_type);}else{return ($session_id,$username,$session_type,$display);
}}sub NXScripts::script_before_start_session{package NXScripts;no warnings;if (
Common::NXSessionType::isAttach (NXSession::getSessionType ())){(my ($session_id
,$username,$session_type,$display,$main_session_id,$main_session_type)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptBeforeSessionStart,
"\x62\x65\x66\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x74\x61\x72\x74"
,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display,$main_session_id,
$main_session_type));}else{(my ($session_id,$username,$session_type,$display)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptBeforeSessionStart,
"\x62\x65\x66\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x74\x61\x72\x74"
,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display));}}sub 
NXScripts::script_after_start_session{package NXScripts;no warnings;if (
Common::NXSessionType::isAttach (NXSession::getSessionType ())){(my ($session_id
,$username,$session_type,$display,$main_session_id,$main_session_type)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterSessionStart,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x74\x61\x72\x74",
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display,$main_session_id,
$main_session_type));}else{(my ($session_id,$username,$session_type,$display)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterSessionStart,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x74\x61\x72\x74",
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display));}}sub 
NXScripts::script_before_suspend{package NXScripts;no warnings;(my ($session_id,
$username,$session_type,$display)=script_check_parameters (@_));return (
script_run_command ($GLOBAL::UserScriptBeforeSessionDisconnect,
"\x62\x65\x66\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74"
,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x75\x73\x70\x65\x6e\x64"
,$session_id,$username,$session_type,$display));}sub 
NXScripts::script_after_suspend{package NXScripts;no warnings;(my ($session_id,
$username,$session_type,$display)=script_check_parameters (@_));return (
script_run_command ($GLOBAL::UserScriptAfterSessionDisconnect,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74"
,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x75\x73\x70\x65\x6e\x64"
,$session_id,$username,$session_type,$display));}sub 
NXScripts::script_before_session_reconnecting{package NXScripts;no warnings;(my (
$session_id,$username,$session_type,$display)=script_check_parameters (@_));
return (script_run_command ($GLOBAL::UserScriptBeforeSessionReconnect,
"\x62\x65\x66\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74"
,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,$session_id,$username,$session_type,$display));}sub 
NXScripts::script_after_session_reconnecting{package NXScripts;no warnings;(my (
$session_id,$username,$session_type,$display)=script_check_parameters (@_));
return (script_run_command ($GLOBAL::UserScriptAfterSessionReconnect,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74"
,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,$session_id,$username,$session_type,$display));}sub 
NXScripts::script_before_close_session{package NXScripts;no warnings;if (
Common::NXSessionType::isAttach (NXSession::getSessionType ())){(my ($session_id
,$username,$session_type,$display,$main_session_id,$main_session_type)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptBeforeSessionClose,
"\x62\x65\x66\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65"
,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display,$main_session_id,
$main_session_type));}else{(my ($session_id,$username,$session_type,$display)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptBeforeSessionClose,
"\x62\x65\x66\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65"
,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display));}}sub 
NXScripts::script_after_close_session{package NXScripts;no warnings;if (
Common::NXSessionType::isAttach (NXSession::getSessionType ())){(my ($session_id
,$username,$session_type,$display,$main_session_id,$main_session_type)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterSessionClose,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65",
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display,$main_session_id,
$main_session_type));}else{(my ($session_id,$username,$session_type,$display)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterSessionClose,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65",
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$session_id,$username,$session_type,$display));}}sub 
NXScripts::script_after_session_failure{package NXScripts;no warnings;if (
Common::NXSessionType::isAttach (NXSession::getSessionType ())){(my ($session_id
,$username,$session_type,$display,$main_session_id,$main_session_type)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterSessionFailure,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x61\x69\x6c\x75\x72\x65"
,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,$session_id,$username,$session_type,$display,$main_session_id,
$main_session_type));}else{(my ($session_id,$username,$session_type,$display)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterSessionFailure,
"\x61\x66\x74\x65\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x61\x69\x6c\x75\x72\x65"
,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,$session_id,$username,$session_type,$display));}}sub 
NXScripts::runVirtualDesktopVariablesScript{package NXScripts;no warnings;(my $ref_environment
=shift (@_));(my (@command)=$GLOBAL::VirtualDesktopVariables);return (
main::run_command ((\@command),$ref_environment));}sub 
NXScripts::script_after_remote_resize{package NXScripts;no warnings;(my $width=
shift (@_));(my $height=shift (@_));if ((not (
$GLOBAL::UserScriptAfterRemoteResize))){return ((0x07eb+ 6635-0x21d6));}if (
Common::NXSessionType::isAttach (NXSession::getSessionType ())){(my ($session_id
,$username,$session_type,$display,$main_session_id,$main_session_type)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterRemoteResize,
"\x61\x66\x74\x65\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x72\x65\x73\x69\x7a\x65",
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x72\x65\x6d\x6f\x74\x65\x5f\x72\x65\x73\x69\x7a\x65"
,$session_id,$username,$session_type,$display,$width,$height,$main_session_id,
$main_session_type));}else{(my ($session_id,$username,$session_type,$display)=
script_check_parameters (@_));return (script_run_command (
$GLOBAL::UserScriptAfterRemoteResize,
"\x61\x66\x74\x65\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x72\x65\x73\x69\x7a\x65",
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x72\x65\x6d\x6f\x74\x65\x5f\x72\x65\x73\x69\x7a\x65"
,$session_id,$username,$session_type,$display,$width,$height));}}package 
NXScripts;no warnings;"\x3f\x3f\x3f";
