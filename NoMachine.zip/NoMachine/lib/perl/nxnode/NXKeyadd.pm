############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXKeyadd::BEGIN{package NXKeyadd;no warnings;require POSIX;do{()};}package 
NXKeyadd;no warnings;$clientPublicKey;sub getClientPublicKey{return (
$clientPublicKey);}sub setClientPublicKey{($clientPublicKey=shift (@_));
Logger::debug (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x5b"
.$clientPublicKey)."\x5d"));}sub runKeyAdd{(my $line=shift (@_));Logger::debug (
(("\x72\x75\x6e\x4b\x65\x79\x41\x64\x64\x20\x6c\x69\x6e\x65\x20\x5b".$line).
"\x5d"));main::parse_arguments ($line);(my $key=$GLOBAL::parameters{
"\x6b\x65\x79"});if (($GLOBAL::parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}eq 
(""))){($GLOBAL::parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}="\x4e\x58");}
Logger::debug ((((("\x6b\x65\x79\x20\x5b".$GLOBAL::parameters{"\x6b\x65\x79"}).
"\x5d\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x5b").$GLOBAL::parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"})."\x5d"));(my (@options)=());my (
$nxserverPid);push (@options,"\x67\x65\x74\x20\x70\x69\x64",(\$nxserverPid));my (
$socketServer);my ($socketNode);(my $nxpipeReturn=main::nxPipeCreateBi ((
\$socketServer),(\$socketNode)));Logger::debug (((((((
"\x3a\x3a\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x42\x69\x28".
$socketServer)."\x2c\x20").$socketNode)."\x29\x20\x5b").$nxpipeReturn)."\x5d"));
(my $setInheritableReturn=libnxh::NXDescriptorInheritable ($socketNode,
(0x128b+ 2699-0x1d15)));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.$socketNode)."\x2c\x20\x31\x29\x20\x5b").$setInheritableReturn)."\x5d"));push (
@options,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$socketNode);push (
@options,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$socketNode);
push (@options,"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",
$socketNode);push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");push (
@options,"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x6f\x75\x74\x20\x6f\x70\x65\x6e")
;Common::NXCore::cleanOutLanguageCasesInEnvironemt ();push (@options,
"\x66\x75\x6c\x6c\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74");push (
@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");(my (@command)=());push (
@command,(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65"));
push (@command,"\x2d\x2d\x6b\x65\x79\x61\x64\x64");push (@command,
"\x2d\x2d\x70\x61\x63\x6b\x65\x64\x2d\x6d\x65\x73\x73\x61\x67\x65\x73",
(0x0909+ 649-0x0b91));main::nxRunCommand ((\@command),(\@options));(my $selector
="\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new
);(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($socketServer);$selector->add (main::nxgetSTDIN ());my (
$read_buf);my ($bytes_read);(my $pwdalreadysent=(0x02ca+ 3417-0x1023));while ((my (
@ready)=$selector->can_read)){Logger::debug (((
"\x63\x61\x6e\x5f\x72\x65\x61\x64\x20\x5b".join ($",@ready))."\x5d"));foreach my $fh
 (@ready){Logger::debug ((("\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x5b".$fh).
"\x5d"));if (($fh==$socketServer)){($bytes_read=main::nxread ($fh,(\$read_buf),
(0x15f3+ 6880-0x20d3)));Logger::debug (((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x6b\x65\x79\x61\x64\x64\x20\x5b"
.$read_buf)."\x5d\x20\x5b").$bytes_read)."\x5d"));if ((($bytes_read eq 
(0x2012+ 1424-0x25a2))or (not (defined ($bytes_read))))){Logger::debug (
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x6b\x65\x79\x61\x64\x64\x2e"
);$selector->remove ($fh);$selector->remove ($signalFd);return (
(0x1b63+ 983-0x1f3a));}chomp ($read_buf);($read_buf=~ s/\015//gs );($read_buf=~ s/^\n//gs )
;Logger::debug (((((
"\x46\x69\x6c\x74\x65\x72\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x5b".
$read_buf)."\x5d\x20\x5b").$bytes_read)."\x5d"));($bytes_read=length ($read_buf)
);if (Common::NXShellCommands::isNotInSudoersMessage ($read_buf)){(my $error=
"\x55\x73\x65\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x69\x6e\x20\x73\x75\x64\x6f\x65\x72\x73\x20\x66\x69\x6c\x65\x2e"
);Logger::warning ($error);(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ERROR_NOT_SUDOERS)."\x20\x65\x72\x72\x6f\x72\x3d").main::urlencode 
($error))."\x20\x0a"));main::nxwrite (main::nxgetSTDOUT (),$message);$selector->
remove ($socketServer);$selector->remove ($signalFd);if ($selector->exists (
main::nxgetSTDIN ())){$selector->remove (main::nxgetSTDIN ());}}elsif (
Common::NXShellCommands::isNotAdministrator ($read_buf)){(my $error=
"\x55\x73\x65\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
);Logger::warning ($error);(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ERROR_NOT_ADMINISTRATOR)."\x20\x65\x72\x72\x6f\x72\x3d").
main::urlencode ($error))."\x20\x0a"));main::nxwrite (main::nxgetSTDOUT (),
$message);$selector->remove ($socketServer);$selector->remove ($signalFd);if (
$selector->exists (main::nxgetSTDIN ())){$selector->remove (main::nxgetSTDIN ())
;}}elsif (Common::NXShellCommands::isPasswordRequestMessage ($read_buf)){if ((
$pwdalreadysent==(0x0ba9+ 1991-0x1370))){(my $message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ASK_FOR_PASSWORD)."\x20\x0a"));(my $writtenbytes=main::nxwrite (
main::nxgetSTDOUT (),$message));Logger::debug (((((
"\x41\x73\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x75\x64\x6f\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x5b"
.$message)."\x5d\x20\x5b").$writtenbytes)."\x5d"));($pwdalreadysent=
(0x00ef+ 623-0x035d));}else{(my $bytes=main::nxwrite ($socketServer,
"\x0a\x0a\x0a"));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x65\x6d\x70\x74\x79\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x5b"
.$bytes)."\x5d"));(my $error=
"\x53\x75\x64\x6f\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68"
);Logger::warning ($error);(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ERROR_SUDO_PASS_NOT_MATCH)."\x20\x65\x72\x72\x6f\x72\x3d").
main::urlencode ($error))."\x20\x0a"));main::nxwrite (main::nxgetSTDOUT (),
$message);}}elsif (($read_buf=~ /NX> $GLOBAL::MSG_NODE_ERROR_INITIALIZATION / ))
{(my $message=("\x4e\x58\x3e\x20\x70\x61\x72\x61\x6d\x73\x3d\x6b\x65\x79\x3d".
main::urlencode ($GLOBAL::parameters{"\x6b\x65\x79"})));($message.=(
"\x26\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3d".$GLOBAL::parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}));($message.=(("\x26\x75\x75\x69\x64\x3d".
$GLOBAL::parameters{"\x75\x75\x69\x64"})."\x20"));(my $bytes=main::nxwrite (
$socketServer,($message."\x0a")));Logger::debug (((((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x6b\x65\x79\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x6b\x65\x79\x61\x64\x64\x20\x5b"
.$message)."\x5d\x20\x5b").$bytes)."\x5d"));}elsif (($read_buf=~ /NX> $GLOBAL::MSG_KEY_ADDED / )
){(my $bytes=main::nxwrite (main::nxgetSTDOUT (),($read_buf."\x0a")));
Logger::debug (((((
"\x4b\x65\x79\x20\x61\x64\x64\x65\x64\x20\x63\x6f\x72\x72\x65\x63\x74\x6c\x79\x2e\x20\x5b"
.$read_buf)."\x5d\x20\x5b").$bytes)."\x5d"));$selector->remove ($socketServer);
$selector->remove ($signalFd);if ($selector->exists (main::nxgetSTDIN ())){
$selector->remove (main::nxgetSTDIN ());}}elsif (Common::NXMsg::isPackedMessage 
($read_buf)){(my $bytes=main::nxwrite (main::nxgetSTDOUT (),($read_buf."\x0a")))
;Logger::debug (((((
"\x50\x61\x73\x73\x69\x6e\x67\x20\x70\x61\x63\x6b\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x5b"
.$read_buf)."\x5d\x20\x5b").$bytes)."\x5d"));$selector->remove ($socketServer);
$selector->remove ($signalFd);if ($selector->exists (main::nxgetSTDIN ())){
$selector->remove (main::nxgetSTDIN ());}}}elsif (($fh==main::nxgetSTDIN ())){my (
$read_buf);(my $bytes_read=main::nxread ($fh,(\$read_buf),(0x17ba+ 3516-0x1576))
);if (($bytes_read==(0x0c53+ 5516-0x21df))){Logger::debug (
"\x52\x65\x6d\x6f\x76\x65\x20\x53\x54\x44\x49\x4e\x2e");$selector->remove ($fh);
}elsif (($read_buf=~ /NX> $GLOBAL::MSG_PASSWORD_ANSWER password=(.*) / )){(my $password
=$1);(my $bytes=main::nxwrite ($socketServer,($password."\x0a\x0a\x0a")));
Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x74\x6f\x20\x73\x75\x64\x6f\x20\x5b"
.$bytes)."\x5d"));$selector->remove (main::nxgetSTDIN ());}}}}
handleProcessAfterFinish ($nxserverPid);}sub handleProcessAfterFinish{(my $pid=
shift (@_));Common::NXProcess::waitToTerminateOrKillIfStayAlive ($pid,
(0x1bb1+ 2780-0x2688));}"\x3f\x3f\x3f";
