############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTools::BEGIN{package NXTools;no warnings;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
NXTools::BEGIN{package NXTools;no warnings;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
NXTools::getWindowsSystemPath{package NXTools;no warnings;(my $systemPath=(""));
if ((defined ($ENV{
"\x53\x79\x73\x74\x65\x6d\x44\x69\x72\x65\x63\x74\x6f\x72\x79"})and (length (
$ENV{"\x53\x79\x73\x74\x65\x6d\x44\x69\x72\x65\x63\x74\x6f\x72\x79"})>
(0x01e9+ 3389-0x0f26)))){($systemPath=$ENV{
"\x53\x79\x73\x74\x65\x6d\x44\x69\x72\x65\x63\x74\x6f\x72\x79"});}elsif ((
defined ($ENV{"\x57\x69\x6e\x44\x69\x72"})and (length ($ENV{
"\x57\x69\x6e\x44\x69\x72"})>(0x00c1+ 8113-0x2072)))){($systemPath=(($ENV{
"\x57\x69\x6e\x44\x69\x72"}.$GLOBAL::DIRECTORY_SLASH).
"\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif ((defined ($ENV{
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"})and (length ($ENV{
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"})>(0x0183+ 9400-0x263b)))){(
$systemPath=(($ENV{"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"}.
$GLOBAL::DIRECTORY_SLASH)."\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif ((defined 
($ENV{"\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"})and (length ($ENV{
"\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"})>(0x0391+ 4084-0x1385)))){(
$systemPath=(((($ENV{"\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"}.
$GLOBAL::DIRECTORY_SLASH)."\x57\x69\x6e\x64\x6f\x77\x73").
$GLOBAL::DIRECTORY_SLASH)."\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif ((defined 
($ENV{"\x48\x4f\x4d\x45\x44\x52\x49\x56\x45"})and (length ($ENV{
"\x48\x4f\x4d\x45\x44\x52\x49\x56\x45"})>(0x0a29+ 261-0x0b2e)))){($systemPath=((
(($ENV{"\x48\x4f\x4d\x45\x44\x52\x49\x56\x45"}.$GLOBAL::DIRECTORY_SLASH).
"\x57\x69\x6e\x64\x6f\x77\x73").$GLOBAL::DIRECTORY_SLASH).
"\x53\x79\x73\x74\x65\x6d\x33\x32"));}else{Logger::debug (
"\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x79\x73\x74\x65\x6d\x50\x61\x74\x68\x28\x29\x3a\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x65\x74\x20\x70\x61\x74\x68"
);return ((""));}Logger::debug (((
"\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x79\x73\x74\x65\x6d\x50\x61\x74\x68\x28\x29\x3a\x20\x73\x65\x74\x20\x70\x61\x74\x68\x20\x74\x6f\x20\x5b"
.$systemPath)."\x5d"));return ($systemPath);}sub 
NXTools::getPortAgentMBaseOnDisplay{package NXTools;no warnings;(my $display=
shift (@_));(my $port=($display+getAgentMirrorPortOffset ()));return ($port);}
sub NXTools::getAgentMirrorPortOffset{package NXTools;no warnings;return (
$GLOBAL::PORT_DISPLAY_MIRROR_DELTA);}sub NXTools::getLang{package NXTools;no 
warnings;(my $envLang=libnxh::NXTransGetEnvironment ("\x4c\x41\x4e\x47"));if ((
$envLang eq (""))){Logger::debug2 (
"\x4c\x41\x4e\x47\x20\x65\x6e\x76\x20\x76\x61\x72\x69\x61\x62\x6c\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2c\x20\x6c\x65\x74\x27\x73\x20\x74\x72\x79\x20\x2e\x64\x6d\x72\x63\x2e"
);($envLang=getLangFromDmrcFile ());if (($envLang eq (""))){Logger::debug2 (
"\x4c\x41\x4e\x47\x20\x65\x6e\x76\x20\x76\x61\x72\x69\x61\x62\x6c\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2c\x20\x67\x65\x74\x74\x69\x6e\x67\x20\x6c\x61\x6e\x67\x75\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x64\x61\x65\x6d\x6f\x6e\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x2e"
);($envLang=getServerDaemonLang ());}}return ($envLang);}sub 
NXTools::getLangFromDmrcFile{package NXTools;no warnings;return ((""));(my $filename
=(Common::NXPaths::getEffectiveUserHomeDirectory ()."\x2f\x2e\x64\x6d\x72\x63"))
;(my $DMRC_FILE_HANDLE=main::nxopen ($filename,$NXBits::O_RDONLY,
(0x1199+ 2821-0x1c9e),{"\x41\x4c\x4c","\x73\x69\x6c\x65\x6e\x74"}));(my $errorstring
=libnxh::NXGetErrorString ());my ($line);(my $found=(""));if ((not (defined (
$DMRC_FILE_HANDLE)))){Logger::debug ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x74\x65\x72\x6d\x69\x6e\x65\x20\x4c\x41\x4e\x47\x20\x62\x61\x73\x65\x64\x20\x6f\x6e\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$filename)."\x3a\x20").$errorstring));return ((""));}else{while (
main::nxreadLine ($DMRC_FILE_HANDLE,(\$line))){chomp ($line);if (($line=~ /^Language=(.*)$/ )
){($found=$1);last;}}main::nxclose ($DMRC_FILE_HANDLE);}return ($found);}sub 
NXTools::getServerDaemonLang{package NXTools;no warnings;return (
$GLOBAL::parameters{"\x65\x6e\x76\x4c\x61\x6e\x67"});}sub NXTools::setWidth{
package NXTools;no warnings;(my $refTable=shift (@_));(my $name=shift (@_));(my $value
=shift (@_));if (($$refTable{$name}<length ($value))){($$refTable{$name}=length 
($value));}}sub NXTools::printWidth{package NXTools;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable{
$name}+(0x1110+ 4826-0x23e9)));(my $message=sprintf ((((("\x25\x2d".$width).
"\x2e").$width)."\x73"),$value));if ((main::nxwrite (main::nxgetSTDOUT (),
$message)==(-(0x028a+ 5307-0x1744)))){return ((-(0x0e03+ 3736-0x1c9a)));}}sub 
NXTools::printMark{package NXTools;no warnings;(my $refTable=shift (@_));(my $name
=shift (@_));(my $value=shift (@_));(my $width=($$refTable{$name}+
(0x229a+ 536-0x24b1)));(my $message=sprintf ((((("\x25\x2d".$width)."\x2e").
$width)."\x73"),("\x2d" x $$refTable{$name})));if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x074f+ 6458-0x2088)))){return ((-
(0x1cd8+ 972-0x20a3)));}}sub NXTools::printTable{package NXTools;no warnings;(my $ref_labels
=shift (@_));(my $ref_values=shift (@_));(my (%table)=());for ((my $i=
(0x177b+ 2859-0x22a6));($i<@$ref_labels);(++$i)){setWidth ((\%table),$i,
@$ref_labels[$i]);}foreach my $value (values (%$ref_values)){for ((my $i=
(0x05a4+ 1690-0x0c3e));($i<@$ref_labels);(++$i)){(my $name=@$ref_labels[$i]);
setWidth ((\%table),$i,$$value{$name});}}for ((my $i=(0x1860+ 1944-0x1ff8));($i<
@$ref_labels);(++$i)){printWidth ((\%table),$i,@$ref_labels[$i]);}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x0b52+ 3277-0x181e)))){return (
(-(0x01fb+ 8661-0x23cf)));}for ((my $i=(0x0a50+ 365-0x0bbd));($i<@$ref_labels);(
++$i)){if (printMark ((\%table),$i)){return ((-(0x03d4+ 5757-0x1a50)));}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x1295+ 2072-0x1aac)))){return (
(-(0x04ab+ 3219-0x113d)));}foreach my $key (sort (keys (%$ref_values))){(my $value
=$$ref_values{$key});for ((my $i=(0x19d8+ 364-0x1b44));($i<@$ref_labels);(++$i))
{(my $name=@$ref_labels[$i]);if (printWidth ((\%table),$i,$$value{$name})){
return ((-(0x002a+ 2268-0x0905)));}}if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x06d1+ 7048-0x2258)))){return ((-(0x0b1b+ 2783-0x15f9)));}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x19d5+ 1466-0x1f8e)))){return (
(-(0x0fa6+ 4582-0x218b)));}return ((0x195b+ 3019-0x2526));}package NXTools;no 
warnings;"\x3f\x3f\x3f";
