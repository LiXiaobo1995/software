############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXPingMonitor;no warnings;(my $__pingTime=(0x1936+ 2386-0x2288));(my $__pongTime
=(0x0ff4+ 4144-0x2024));(my $__interval=(0x10f2+ 2114-0x1934));(my $__timeout=
(0x15c7+ 859-0x1922));(my $__errorTimeout=(0x012c+ 688-0x03dc));sub initialize{
__setTimeBetweenPings ();__setTimeoutForPingResponse ();__sendPing ();}sub 
__setTimeBetweenPings{($__interval=(0x08d0+ 920-0x0c4a));Logger::debug (((
"\x4e\x58\x50\x69\x6e\x67\x4d\x6f\x6e\x69\x74\x6f\x72\x3a\x20\x54\x69\x6d\x65\x20\x62\x65\x74\x77\x65\x65\x6e\x20\x70\x69\x6e\x67\x73\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x72\x76\x65\x72\x3a\x20"
.$__interval)."\x2e"));}sub __setTimeoutForPingResponse{if ((not ((
$GLOBAL::NodeConnectionTimeout=~ /\d+/ )))){Logger::warning (
"\x4e\x58\x50\x69\x6e\x67\x4d\x6f\x6e\x69\x74\x6f\x72\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x74\x68\x65\x20\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x69\x6d\x65\x6f\x75\x74\x20\x6b\x65\x79\x2e\x20\x55\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x2e"
);($GLOBAL::NodeConnectionTimeout=(0x0975+ 5540-0x1ea1));}($__timeout=
$GLOBAL::NodeConnectionTimeout);Logger::debug (((
"\x4e\x58\x50\x69\x6e\x67\x4d\x6f\x6e\x69\x74\x6f\x72\x3a\x20\x54\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x70\x69\x6e\x67\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3a\x20"
.$__timeout)."\x2e"));}sub checkTimesAndSendPingIfNecessary{if ((__isPingEnabled
 ()==(0x1039+ 1395-0x15ac))){return;}if ((__isTimeoutForPingRespose ()==
(0x0c8a+ 436-0x0e3d))){if ((__isErrorServerDidNotReply ()==(0x04cd+ 2290-0x0dbe)
)){Logger::error (((
"\x53\x65\x72\x76\x65\x72\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x72\x65\x70\x6c\x79\x20\x73\x69\x6e\x63\x65\x20"
.$__timeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));NXSessionMonitor::__setSessionStatus ($NXSessionMonitor::statusError,((
"\x4c\x6f\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x4e\x58\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x6e\x6f\x20\x72\x65\x70\x6c\x69\x65\x73\x20\x69\x6e\x20"
.$__timeout)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));return;}
__setErrorServerDidNotReply ();Logger::warning (((
"\x53\x65\x72\x76\x65\x72\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x72\x65\x70\x6c\x79\x20\x73\x69\x6e\x63\x65\x20"
.$__timeout)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));__sendPing ();return;}if (
(__isPingTime ()==(0x010a+ 7150-0x1cf7))){__sendPing ();return;}}sub handlePong{
Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x70\x6f\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);__clearErrorServerDidNotReply ();__setPongTime ();__resetPingTime ();}sub 
handleRequestForPingMessage{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x73\x65\x6e\x64\x20\x70\x69\x6e\x67\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x72\x76\x65\x72\x2e"
);__sendPing ();}sub __sendPing{Logger::debug (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);(my $message=(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_NODE_PING)."\x20").
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_NODE_PING})."\x0a"));(my $bytes=
main::nxwrite (main::nxgetSTDOUT (),$message));if (($bytes==(-
(0x1714+ 1500-0x1cef)))){NXSessionMonitor::__setSessionStatus (
$NXSessionMonitor::statusError,
"\x4c\x6f\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x4e\x58\x20\x73\x65\x72\x76\x65\x72\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x70\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x2e"
);return;}__resetPongTime ();__setPingTime ();}sub __isPingEnabled{if ((
$__timeout==(0x1990+ 2984-0x2538))){return ((0x01e2+ 9153-0x25a3));}return (
(0x0541+ 4592-0x1730));}sub __setPingTime{($__pingTime=
Common::NXTime::getSecondsSinceEpoch ());}sub __resetPingTime{($__pingTime=
(0x018a+ 7436-0x1e96));}sub __isPingTime{if (($__pongTime==(0x15ab+ 415-0x174a))
){return ((0x115a+ 3642-0x1f94));}(my $time=Common::NXTime::getSecondsSinceEpoch
 ());if (($time>=($__pongTime+$__interval))){return ((0x0e84+ 2586-0x189d));}
return ((0x0de7+ 2434-0x1769));}sub __isTimeoutForPingRespose{if (($__pingTime==
(0x22ea+ 628-0x255e))){return ((0x0e30+ 5774-0x24be));}(my $time=
Common::NXTime::getSecondsSinceEpoch ());if (($__pingTime>$time)){($__pingTime=
Common::NXTime::getSecondsSinceEpoch ());}if (($time>=($__pingTime+$__timeout)))
{return ((0x1090+ 3723-0x1f1a));}return ((0x06c7+ 1132-0x0b33));}sub 
__setErrorServerDidNotReply{($__errorTimeout=(0x047a+ 4695-0x16d0));}sub 
__isErrorServerDidNotReply{return ($__errorTimeout);}sub 
__clearErrorServerDidNotReply{($__errorTimeout=(0x0554+ 6191-0x1d83));}sub 
__setPongTime{($__pongTime=Common::NXTime::getSecondsSinceEpoch ());}sub 
__resetPongTime{($__pongTime=(0x1431+ 604-0x168d));}return (
(0x0e86+ 5332-0x2359));
