############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub AskAgentMirror::BEGIN{package AskAgentMirror;no warnings;require 
Common::NXParser;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->import};}sub
 AskAgentMirror::getDisplayOwner{package AskAgentMirror;no warnings;(my $answer=
__askMirrorAgentForUser (
"\x67\x65\x74\x44\x69\x73\x70\x6c\x61\x79\x4f\x77\x6e\x65\x72",
"\x76\x61\x6c\x75\x65"));($answer=~ s/\ $// );(my $displayOwner=(""));if ((
$answer=~ /attached:(.*)/ )){($displayOwner=$1);}Logger::debug2 (((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x64\x69\x73\x70\x6c\x61\x79\x20\x6f\x77\x6e\x65\x72\x20\x5b"
.$displayOwner)."\x5d\x2e"));return ($displayOwner);}sub 
AskAgentMirror::addSshKey{package AskAgentMirror;no warnings;(my $loginEncode=
shift (@_));(my $usersHome=shift (@_));__getPropertyFromMirrorAgent ((((
"\x4e\x58\x3e\x20\x61\x64\x64\x53\x73\x68\x4b\x65\x79\x20".$loginEncode)."\x20")
.$usersHome));}sub AskAgentMirror::getGeometry{package AskAgentMirror;no 
warnings;return (__askMirrorAgentForUser (
"\x67\x65\x74\x44\x69\x73\x70\x6c\x61\x79\x47\x65\x6f\x6d\x65\x74\x72\x79"));}
sub AskAgentMirror::getCookie{package AskAgentMirror;no warnings;(my (
$exit_value,$reply)=__getPropertyFromMirrorAgent ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_GET_COOKIE_FROM_MIRROR_AGENT).
"\x20\x67\x65\x74\x43\x6f\x6f\x6b\x69\x65")));if (($reply=~ /cookie: (.*)/ )){(my $cookie
=$1);return ($cookie);}return;}sub AskAgentMirror::getDisplay{package 
AskAgentMirror;no warnings;(my ($exit_value,$reply)=__getPropertyFromMirrorAgent
 ((("\x4e\x58\x3e\x20".$GLOBAL::MSG_GET_DISPLAY_FROM_MIRROR_AGENT).
"\x20\x67\x65\x74\x44\x69\x73\x70\x6c\x61\x79")));if (($reply=~ /(\d+)$/ )){(my $display
=$1);return ($display);}return;}sub AskAgentMirror::getLocalSessionTypeWindows{
package AskAgentMirror;no warnings;(my $answer=__askMirrorAgentForUser (
"\x67\x65\x74\x44\x69\x73\x70\x6c\x61\x79\x4f\x77\x6e\x65\x72",
"\x76\x61\x6c\x75\x65"));(my $localSessionType=
"\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77");if ((not (($answer=~ /detached/ )
))){($localSessionType="\x64\x65\x73\x6b\x74\x6f\x70");}Logger::debug2 (((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x69\x73\x20\x5b"
.$localSessionType)."\x5d\x2e"));return ($localSessionType);}sub 
AskAgentMirror::waitForCookieFile{package AskAgentMirror;no warnings;(my $loop=
(0x0884+ 3461-0x15ff));do{if (main::areMirrorCookieFilesReady ()){return (
(0x07ea+ 7055-0x2379));}main::nxsleep (0.2)}while (--$loop);return ((-
(0x1174+ 3377-0x1ea4)));}sub AskAgentMirror::sendMessage{package AskAgentMirror;
no warnings;(my $message=shift (@_));return (__getPropertyFromMirrorAgent (
$message));}sub AskAgentMirror::__callbackAgentParser{package AskAgentMirror;no 
warnings;(my $self=shift (@_));(my $handleHash=shift (@_));(my $buffer=shift (@_
));(my $dataSize=shift (@_));(my $parameters=$$handleHash{
"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});if (($dataSize==
(0x197f+ 260-0x1a83))){$self->removeAndCloseHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});}else{($$parameters{"\x63\x6d\x64\x5f\x6f\x75\x74"}
.=$buffer);($buffer=(""));(my $logstr_cmd_out=$$parameters{
"\x63\x6d\x64\x5f\x6f\x75\x74"});($logstr_cmd_out=~ s/(cookie: )[^\n]*/$1******/gm )
;Logger::debug ((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x61\x67\x65\x6e\x74\x3a\x20".
$logstr_cmd_out));}(my $answer=(""));(my $ret=(0x0ef7+ 140-0x0f82));(my $request
=$$parameters{"\x72\x65\x71\x75\x65\x73\x74"});if (($$parameters{
"\x63\x6d\x64\x5f\x6f\x75\x74"}=~ /$request/ )){if (($$parameters{
"\x63\x6d\x64\x5f\x6f\x75\x74"}=~ /$request (.*)/ )){($answer=$1);($ret=
(0x020c+ 2090-0x0a36));(my $log_answer=$answer);($log_answer=~ s/(cookie: )[^\n]*/$1******/gm )
;Logger::debug ((("\x52\x65\x61\x64\x20\x61\x6e\x73\x77\x65\x72\x20\x5b".
$log_answer)."\x5d"));}Logger::debug ((
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x73\x6f\x63\x6b\x65\x74\x20\x74\x6f\x20\x61\x67\x65\x6e\x74\x20\x6f\x6e\x20\x70\x6f\x72\x74\x3a\x20"
.$$parameters{"\x70\x6f\x72\x74"}));$self->removeAndCloseHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($handleHash,$ret,$answer);}}sub 
AskAgentMirror::__callbackTimeout{package AskAgentMirror;no warnings;(my $self=
shift (@_));(my $refParameters=shift (@_));Logger::warning (((
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x5b".$refParameters).
"\x5d\x20\x77\x68\x69\x6c\x65\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x20\x61\x6e\x73\x77\x65\x72\x2e"
));$self->removeAllHandles;}sub AskAgentMirror::__getPropertyFromMirrorAgent{
package AskAgentMirror;no warnings;(my $request=shift (@_));(my $answer=(""));
Logger::debug2 (
"\x41\x63\x71\x75\x69\x72\x69\x6e\x67\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e\x20\x63\x6f\x6f\x6b\x69\x65\x20\x74\x6f\x20\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x2e"
);(my (@arrayCookie)=main::getMirrorNodeCookieAndPort ());while (scalar (
@arrayCookie)){(my $cookie=shift (@arrayCookie));(my $port=shift (@arrayCookie))
;Logger::debug (((((
"\x54\x72\x79\x20\x74\x6f\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x5b"
.$port)."\x5d\x20\x77\x69\x74\x68\x20\x5b").$cookie)."\x5d"));(my $ret=
(0x0203+ 7565-0x1f8f));(my $sock=main::nxConnectLocal ($port));if (($sock==(-
(0x2509+ 125-0x2585)))){Logger::debug ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x20\x6f\x6e\x20\x70\x6f\x72\x74\x3a\x20"
.$port));next;}Logger::debug ((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20".$request)
);(my $auth_string=(
"\x4e\x58\x3e\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6f\x6f\x6b\x69\x65\x3d"
.$cookie));(my $bytes=main::nxwrite ($sock,($auth_string."\x0a")));Logger::debug
 ((("\x5b".$bytes).
"\x5d\x20\x77\x61\x73\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x2e"
));($bytes=main::nxwrite ($sock,($request."\x0a")));Logger::debug ((("\x5b".
$bytes).
"\x5d\x20\x77\x61\x73\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x2e"
));(my $parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);(my $params
={"\x72\x65\x71\x75\x65\x73\x74",$request,"\x63\x6d\x64\x5f\x6f\x75\x74",(""),
"\x70\x6f\x72\x74",$port});$parser->add ($sock,(\&__callbackAgentParser),
"\x41\x73\x6b\x41\x67\x65\x6e\x74\x4d\x69\x72\x72\x6f\x72\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x41\x67\x65\x6e\x74\x50\x61\x72\x73\x65\x72"
,$params);$parser->setTimeout ((0x0c98+ 1157-0x1118));$parser->
setCallbackTimeout ((\&__callbackTimeout),$params);(my $signalFd=
$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$parser->add ($signalFd);(my (
$code,$result)=$parser->run);unless (($result eq (""))){return ($code,$result);}
}}sub AskAgentMirror::__askMirrorAgentForUser{package AskAgentMirror;no warnings
;(my $msg=shift (@_));(my $field=(shift (@_)||"\x76\x61\x6c\x75\x65"));(my (
$exit_value,$reply)=__getPropertyFromMirrorAgent (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_GET_DISPLAY_PROPERTY_FROM_MIRROR_AGENT)."\x20").$msg)));if (($reply
=~ /error=(\d+),$field=(.*)$/ )){(my $error=$1);(my $value=$2);if (($error==
(0x109a+ 5597-0x2677))){return ($value);}}return;}package AskAgentMirror;no 
warnings;return ((0x015d+ 1535-0x075b));
