############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXClusterAdd::nodeAdd{package NXClusterAdd;no warnings;(my $line=shift (@_))
;(my (@options)=());my ($nxserverPid);push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$nxserverPid));main::nxrequire (
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65");my (
$socketServer);my ($socketNode);(my $nxpipeReturn=main::nxPipeCreateBi ((
\$socketServer),(\$socketNode)));Logger::debug (((((((
"\x3a\x3a\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x42\x69\x28".
$socketServer)."\x2c\x20").$socketNode)."\x29\x20\x5b").$nxpipeReturn)."\x5d"));
(my $setInheritableReturn=libnxh::NXDescriptorInheritable ($socketNode,
(0x0afd+ 222-0x0bda)));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.$socketNode)."\x2c\x20\x31\x29\x20\x5b").$setInheritableReturn)."\x5d"));push (
@options,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$socketNode);push (
@options,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$socketNode);
push (@options,"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",
$socketNode);push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");push (
@options,"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x6f\x75\x74\x20\x6f\x70\x65\x6e")
;Common::NXCore::cleanOutLanguageCasesInEnvironemt ();push (@options,
"\x66\x75\x6c\x6c\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74");push (
@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");(my (@command)=());push (
@command,(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65"));
push (@command,
"\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x6e\x6f\x64\x65\x61\x64\x64");
main::nxRunCommand ((\@command),(\@options));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($socketServer);$selector->add (main::nxgetSTDIN ());my (
$read_buf);my ($bytes_read);(my $pwdalreadysent=(0x0ac1+ 3619-0x18e4));(my $buffer
=(""));(my $paramsAlreadySend=(0x0f26+ 308-0x105a));while ((my (@ready)=
$selector->can_read)){Logger::debug (((
"\x63\x61\x6e\x5f\x72\x65\x61\x64\x20\x5b".join ($",@ready))."\x5d"));foreach my $fh
 (@ready){Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x46\x48\x20\x5b".$fh)."\x5d"));if (($fh==
$socketServer)){($read_buf=(""));($bytes_read=main::nxread ($fh,(\$read_buf),
(0x12ab+ 3404-0x0ff7)));Logger::debug (((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x4e\x6f\x64\x65\x41\x64\x64\x20\x5b"
.$read_buf)."\x5d\x20\x5b").$bytes_read)."\x5d"));if ((($bytes_read eq 
(0x0729+ 1205-0x0bde))or (not (defined ($bytes_read))))){Logger::debug (
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x4e\x6f\x64\x65\x41\x64\x64\x2e"
);(my $message=
"\x53\x75\x64\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6f\x6e\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x65\x6e\x64\x73\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x6c\x79"
);(my $bytes=main::nxwrite (main::nxgetSTDOUT (),($message."\x0a")));
main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_CLUSTER_NODE_PARAMS)."\x20\x65\x72\x72\x6f\x72\x3d").
main::urlencode ($message))."\x20\x0a"));$selector->remove ($fh);$selector->
remove ($signalFd);return ((0x0ff4+ 5592-0x25cc));}($buffer.=$read_buf);
Logger::debug (((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x62\x75\x66\x66\x65\x72\x20\x5b".$buffer).
"\x5d\x2e"));if (Common::NXShellCommands::isNotInSudoersMessage ($read_buf)){(my $message
=
"\x55\x73\x65\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x69\x6e\x20\x73\x75\x64\x6f\x65\x72\x73\x20\x66\x69\x6c\x65"
);Logger::warning ($message);main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_CLUSTER_NODE_PARAMS).
"\x20\x65\x72\x72\x6f\x72\x3d").main::urlencode ($message))."\x20\x0a"));
$selector->remove ($socketServer);$selector->remove ($signalFd);return (
(0x0624+ 4522-0x17cd));}elsif (Common::NXShellCommands::isNotAdministrator (
$read_buf)){(my $message=
"\x55\x73\x65\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72"
);Logger::warning ($message);main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_CLUSTER_NODE_PARAMS).
"\x20\x65\x72\x72\x6f\x72\x3d").main::urlencode ($message))."\x20\x0a"));
$selector->remove ($socketServer);$selector->remove ($signalFd);return (
(0x0bcd+ 809-0x0ef5));}elsif (Common::NXShellCommands::isPasswordRequestMessage 
($read_buf)){if (($pwdalreadysent==(0x091c+ 2187-0x11a7))){(my $message=((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_ASK_FOR_PASSWORD).
"\x20\x50\x61\x73\x73\x77\x6f\x72\x64\x20\x6e\x65\x65\x64\x65\x64\x2e\x20\x43\x6c\x75\x73\x74\x65\x72\x20\x61\x64\x64\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x0a"
));(my $writtenbytes=main::nxwrite (main::nxgetSTDOUT (),$message));
Logger::debug (((((
"\x41\x73\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x75\x64\x6f\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x5b"
.$message)."\x5d\x20\x5b").$writtenbytes)."\x5d"));($pwdalreadysent=
(0x0fb2+ 2534-0x1997));}else{(my $bytes=main::nxwrite ($socketServer,
"\x0a\x0a\x0a"));(my $error=
"\x53\x75\x64\x6f\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68"
);(my $message=(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_CLUSTER_NODE_PARAMS).
"\x20\x65\x72\x72\x6f\x72\x3d").main::urlencode ($error))."\x20\x0a"));(my $writtenbytes
=main::nxwrite (main::nxgetSTDOUT (),$message));(my $bytes=main::nxwrite (
main::nxgetSTDOUT (),($message."\x0a")));$selector->remove ($socketServer);
$selector->remove ($signalFd);if ($selector->exists (main::nxgetSTDIN ())){
$selector->remove (main::nxgetSTDIN ());}return ((0x0079+ 6819-0x1b1b));}}elsif 
(($read_buf=~ /NX> $GLOBAL::MSG_CLUSTER_NODE_PARAMS/ )){if (($paramsAlreadySend
==(0x0c2f+ 2906-0x1789))){if (($pwdalreadysent==(0x0182+ 8576-0x2302))){
Logger::debug (((((
"\x53\x75\x64\x6f\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x64\x6f\x20\x6e\x6f\x74\x20\x6e\x65\x65\x64\x20\x5b"
.$message)."\x5d\x20\x5b").$writtenbytes)."\x5d"));}(my $message=((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_CLUSTER_NODE_PARAMS).
"\x20\x70\x61\x72\x61\x6d\x73\x3d").$line)."\x20"));my (@bits);push (@bits,
substr ($message,(0x0102+ 9255-0x2529),(0x04a6+ 2204-0x095a),("")))while length 
($message);foreach my $byte (@bits){(my $bytes=main::nxwrite ($socketServer,
$byte));Logger::debug ((((("\x53\x65\x6e\x74\x20".$bytes).
"\x20\x62\x79\x74\x65\x73\x20\x27").$byte).
"\x27\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x6e\x6f\x64\x65\x61\x64\x64\x2e"
));}($paramsAlreadySend=(0x1128+ 4919-0x245e));}else{Logger::debug (
"\x50\x72\x65\x76\x65\x6e\x74\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x69\x6e\x20\x6c\x6f\x6f\x70\x2e"
);}}if (($buffer=~ /NX> $GLOBAL::MSG_CLUSTER_NODE_PARAMS_RESULT params=(.*) / ))
{Logger::debug (((
"\x4b\x65\x79\x20\x66\x72\x6f\x6d\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x72\x65\x73\x75\x6c\x74\x3a\x20\x5b"
.$1)."\x5d"));(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_CLUSTER_NODE_PARAMS)."\x20\x70\x61\x72\x61\x6d\x73\x3d").$1)."\x20"
));(my $bytes=main::nxwrite (main::nxgetSTDOUT (),($message."\x0a")));$selector
->remove ($socketServer);$selector->remove ($signalFd);if ($selector->exists (
main::nxgetSTDIN ())){$selector->remove (main::nxgetSTDIN ());}}elsif (($buffer
=~ /NX> $GLOBAL::MSG_CLUSTER_NODE_PARAMS_RESULT error=(.*) / )){Logger::debug ((
(
"\x45\x72\x72\x6f\x72\x20\x66\x72\x6f\x6d\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x3a\x20\x5b"
.$1)."\x5d"));(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_CLUSTER_NODE_PARAMS)."\x20\x65\x72\x72\x6f\x72\x3d").$1)."\x20"));(my $bytes
=main::nxwrite (main::nxgetSTDOUT (),($message."\x0a")));$selector->remove (
$socketServer);$selector->remove ($signalFd);if ($selector->exists (
main::nxgetSTDIN ())){$selector->remove (main::nxgetSTDIN ());}}}elsif (($fh==
main::nxgetSTDIN ())){my ($read_buf);(my $bytes_read=main::nxread ($fh,(
\$read_buf),(0x15a1+ 5953-0x1ce2)));Logger::debug (((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x53\x54\x44\x49\x4e\x20\x5b".$read_buf
)."\x5d\x20\x5b").$bytes_read)."\x5d"));if (($bytes_read==(0x06e8+ 1716-0x0d9c))
){Logger::debug ("\x52\x65\x6d\x6f\x76\x65\x20\x53\x54\x44\x49\x4e\x2e");
$selector->remove ($fh);}elsif (($read_buf=~ /NX> $GLOBAL::MSG_PASSWORD_ANSWER password=(.*) / )
){(my $password=$1);(my $bytes=main::nxwrite ($socketServer,($password.
"\x0a\x0a\x0a")));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x74\x6f\x20\x73\x75\x64\x6f\x20\x5b"
.$bytes)."\x5d"));$selector->remove (main::nxgetSTDIN ());}}}}}package 
NXClusterAdd;no warnings;return ((0x05b3+ 3508-0x1366));
