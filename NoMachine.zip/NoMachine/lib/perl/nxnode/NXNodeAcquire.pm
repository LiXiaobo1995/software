############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXNodeAcquire;no warnings;(my $line=(""));(my $ready=
(0x0882+ 2251-0x114d));(my $state="\x69\x6d\x70\x6f\x72\x74");(my $proxy=(-
(0x091f+ 6193-0x214f)));%options;sub init{($line=shift (@_));($ready=
(0x0995+ 1129-0x0dfd));($state="\x69\x6d\x70\x6f\x72\x74");}sub run{while ((
$ready==(0x0ecc+ 3624-0x1cf3))){__handleState ();}}sub __handleState{(my $function
=("\x5f\x5f".$state));Logger::debug (((
"\x4e\x6f\x64\x65\x20\x61\x63\x71\x75\x69\x72\x65\x20\x73\x74\x61\x74\x65\x20\x6d\x61\x63\x68\x69\x6e\x65\x20\x27"
.$function)."\x27\x2e"));return (\(&$function (@_)));}sub __nextState{($state=
shift (@_));}sub __import{($line=~ s/Acquire descriptor // );($line=~ s/"//g );(
$line=~ s/\s*$// );((%options)=());(my (@args)=split ( / / ,$line,
(0x0719+ 1934-0x0ea7)));foreach my $pair (@args){(my ($key,$value)=split ( /=/ ,
$pair,(0x0360+ 4334-0x144b)));($options{$key}=$value);}__nextState (
"\x61\x63\x71\x75\x69\x72\x65");}sub __acquire{(my $pid=$options{"\x70\x69\x64"}
);(my $fd=($options{"\x66\x64"}||(0x0648+ 4261-0x16ec)));(my $path=
main::urldecode ($options{"\x73\x6f\x63\x6b\x65\x74\x50\x61\x74\x68"}));(my $cookie
=$options{"\x63\x6f\x6f\x6b\x69\x65"});($proxy=Common::NXDescriptor::acquire (
$pid,$fd,$path,$cookie));if (($proxy==(-(0x1385+ 1794-0x1a86)))){Logger::warning
 (((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x63\x71\x75\x69\x72\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x66\x72\x6f\x6d\x20\x70\x69\x64\x20"
.$pid)."\x20\x61\x6e\x64\x20\x27").$path)."\x27\x2e"));Logger::warning (
"\x53\x6b\x69\x70\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x6e\x65\x77\x20\x70\x72\x6f\x78\x79\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);return (__nextState ("\x62\x72\x65\x61\x6b"));}__nextState (
"\x75\x70\x64\x61\x74\x65");}sub __break{($ready=(0x04e8+ 7153-0x20d9));}sub 
__update{main::nxrequire ("\x4e\x58\x4f\x70\x74\x69\x6f\x6e\x73\x46\x69\x6c\x65"
);if ((NXOptionsFile::updateSessionParameters ((\%options),$proxy)==
(0x03df+ 7451-0x20f9))){return (__nextState ("\x62\x72\x65\x61\x6b"));}(my $type
=$options{"\x74\x79\x70\x65"});(my $ssl=$options{
"\x73\x73\x6c\x43\x6f\x6e\x74\x65\x78\x74"});if (($ssl ne (""))){(my $sslContext
=main::urldecode ($ssl));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x53\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x28"
.$sslContext)."\x29\x2e"));(my $result=libnxh::NXEncryptorSetContext (
$sslContext));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x53\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x72\x65\x73\x75\x6c\x74\x20\x27"
.$result)."\x27\x2e"));}NXOptionsFile::saveOptionsFile ();__nextState (
"\x62\x72\x65\x61\x6b");}sub getTimeout{return ("\x69\x6e\x66");}return (
(0x12f2+ 3576-0x20e9));
