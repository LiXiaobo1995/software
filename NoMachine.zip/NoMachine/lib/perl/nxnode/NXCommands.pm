############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXCommands;no warnings;(my $__mkdir_command=(""));sub BEGIN{require 
strict;do{"\x73\x74\x72\x69\x63\x74"->unimport ("\x72\x65\x66\x73")};}sub BEGIN{
require strict;do{"\x73\x74\x72\x69\x63\x74"->unimport ("\x73\x75\x62\x73")};}(my $__date_command
=(""));(my $__touch_command=(""));(my $__xauth_command=(""));(my $__hostname_command
=(""));(my $__mkfifo_command=(""));(my $__xdpyinfo_command=(""));(my $__xrdb_command
=(""));(my $__xhost_command=(""));(my $__id_command=(""));(my $__ps_command=("")
);(my $__mv_command=(""));(my $__cp_command=(""));(my $__grep_command=(""));(my $__gzip_command
=(""));(my $__pactl_command=(""));(my $__pacmd_command=(""));(my $__amixer_command
=(""));(my $__lpstat_command=(""));(my $__lpinfo_command=(""));(my $__lpoptions_command
=(""));(my $__xprop_command=(""));(my $__cklistsessions_command=(""));(my $__last_command
=(""));(my $__sc_command=(""));(my $__net_command=(""));(my $__lsbrelease_command
=(""));(my $__dbuslaunch_command=(""));(my $__pwcli_command=(""));(my $__pwloopback_command
=(""));((%screenLockCommands)=(NXLocalSession::getUnknownDE (),[[
"\x78\x64\x67\x2d\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72",
"\x6c\x6f\x63\x6b"],["\x78\x6c\x6f\x63\x6b"],[
"\x78\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x6c"],["\x78\x66\x6c\x6f\x63\x6b\x34"],["\x64\x6d\x2d\x74\x6f\x6f\x6c",
"\x6c\x6f\x63\x6b"]],NXLocalSession::getGnomeDE (),[[
"\x67\x6e\x6f\x6d\x65\x2d\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x2d\x6c\x6f\x63\x6b"]],NXLocalSession::getKdeDE (),[["\x64\x63\x6f\x70",
"\x6b\x64\x65\x73\x6b\x74\x6f\x70",
"\x4b\x53\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x49\x66\x61\x63\x65",
"\x6c\x6f\x63\x6b"],["\x6b\x64\x65\x73\x6b\x74\x6f\x70\x5f\x6c\x6f\x63\x6b",
"\x2d\x2d\x66\x6f\x72\x63\x65\x6c\x6f\x63\x6b"]],NXLocalSession::getXfceDE (),[[
"\x6c\x69\x67\x68\x74\x2d\x6c\x6f\x63\x6b\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x6c"]],NXLocalSession::getCinnamonDE (),[[
"\x63\x69\x6e\x6e\x61\x6d\x6f\x6e\x2d\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x2d\x6c\x6f\x63\x6b"],[
"\x67\x6e\x6f\x6d\x65\x2d\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x2d\x6c\x6f\x63\x6b"]],NXLocalSession::getMateDE (),[[
"\x6d\x61\x74\x65\x2d\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x2d\x6c\x6f\x63\x6b"]],NXLocalSession::getLxdeDE (),[[
"\x6c\x78\x6c\x6f\x63\x6b"],[
"\x6c\x69\x67\x68\x74\x2d\x6c\x6f\x63\x6b\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x6c"]],NXLocalSession::getBudgieDE (),[[
"\x67\x6e\x6f\x6d\x65\x2d\x73\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x2d\x63\x6f\x6d\x6d\x61\x6e\x64"
,"\x2d\x2d\x6c\x6f\x63\x6b"]],NXLocalSession::getTrinityDE (),[[
"\x64\x63\x6f\x70","\x6b\x64\x65\x73\x6b\x74\x6f\x70",
"\x4b\x53\x63\x72\x65\x65\x6e\x73\x61\x76\x65\x72\x49\x66\x61\x63\x65",
"\x6c\x6f\x63\x6b"],["\x6b\x64\x65\x73\x6b\x74\x6f\x70\x5f\x6c\x6f\x63\x6b",
"\x2d\x2d\x66\x6f\x72\x63\x65\x6c\x6f\x63\x6b"]]));sub init{($__id_command=
check_path ("\x69\x64"));($__ps_command=check_path ("\x70\x73"));($__mv_command=
check_path ("\x6d\x76"));($__cp_command=check_path ("\x63\x70"));(
$__gzip_command=check_path ("\x67\x7a\x69\x70"));($__pactl_command=check_path (
"\x70\x61\x63\x74\x6c"));($__pacmd_command=check_path ("\x70\x61\x63\x6d\x64"));
($__amixer_command=check_path ("\x61\x6d\x69\x78\x65\x72"));($__mkdir_command=
check_path ("\x6d\x6b\x64\x69\x72"));($__date_command=check_path (
"\x64\x61\x74\x65"));($__grep_command=check_path ("\x67\x72\x65\x70"));(
$__touch_command=check_path ("\x74\x6f\x75\x63\x68"));($__mkfifo_command=
check_path ("\x6d\x6b\x66\x69\x66\x6f"));($__lpstat_command=check_path (
"\x6c\x70\x73\x74\x61\x74"));($__lpinfo_command=check_path (
"\x6c\x70\x69\x6e\x66\x6f"));($__lpoptions_command=check_path (
"\x6c\x70\x6f\x70\x74\x69\x6f\x6e\x73"));($__cklistsessions_command=check_path (
"\x63\x6b\x2d\x6c\x69\x73\x74\x2d\x73\x65\x73\x73\x69\x6f\x6e\x73"));(
$__last_command=check_path ("\x6c\x61\x73\x74"));($__lsbrelease_command=
check_path ("\x6c\x73\x62\x5f\x72\x65\x6c\x65\x61\x73\x65"));(
$__dbuslaunch_command=check_path ("\x64\x62\x75\x73\x2d\x6c\x61\x75\x6e\x63\x68"
));($__pwcli_command=check_path ("\x70\x77\x2d\x63\x6c\x69"));(
$__pwmetadata_command=check_path ("\x70\x77\x2d\x6d\x65\x74\x61\x64\x61\x74\x61"
));($__pwloopback_command=check_path (
"\x70\x77\x2d\x6c\x6f\x6f\x70\x62\x61\x63\x6b"));($__hostname_command=check_path
 ("\x68\x6f\x73\x74\x6e\x61\x6d\x65"));($__xauth_command=check_path (
"\x78\x61\x75\x74\x68","\x2f\x75\x73\x72\x2f\x58\x31\x31\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x52\x36\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x2f\x62\x69\x6e"));($__xprop_command=check_path (
"\x78\x70\x72\x6f\x70","\x2f\x75\x73\x72\x2f\x58\x31\x31\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x52\x36\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x2f\x62\x69\x6e"));($__xrdb_command=check_path (
"\x78\x72\x64\x62","\x2f\x75\x73\x72\x2f\x58\x31\x31\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x52\x36\x2f\x62\x69\x6e"));($__xhost_command=
check_path ("\x78\x68\x6f\x73\x74",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x52\x36\x2f\x62\x69\x6e"));(
$__xdpyinfo_command=check_path ("\x78\x64\x70\x79\x69\x6e\x66\x6f",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x2f\x62\x69\x6e",
"\x2f\x75\x73\x72\x2f\x58\x31\x31\x52\x36\x2f\x62\x69\x6e"));}sub check_path{
return ((""));}sub check_path_win32{(my $command=shift (@_));(my $envPath=$ENV{
"\x50\x41\x54\x48"});($envPath=~ s/^PATH=//gm );(my (@paths)=split ( /;/ ,
$envPath,(0x18a8+ 1077-0x1cdd)));foreach my $path (@paths){(my $file=(($path.
$GLOBAL::DIRECTORY_SLASH).$command));if (-x ($file)){return ($file);}}return (
(""));}sub dbuslaunch_command{(my (@args)=@_);(my (@reply)=());if ((
$__dbuslaunch_command ne (""))){push (@reply,$__dbuslaunch_command,@args);}else{
push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",
main::shell_quote ($GLOBAL::CommandDbusLaunch,@args));}return (@reply);}sub 
pwcli_command{(my (@args)=@_);(my (@reply)=());if (($__pwcli_command ne (""))){
push (@reply,$__pwcli_command,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandPwcli,@args));}return (@reply);}sub pwmetadata_command{(my (
@args)=@_);(my (@reply)=());if (($__pwmetadata_command ne (""))){push (@reply,
$__pwmetadata_command,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandPwmetadata,@args));}return (@reply);}sub pwloopback_command{(my (
@args)=@_);(my (@reply)=());if (($__pwloopback_command ne (""))){push (@reply,
$__pwloopback_command,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandPwloopback,@args));}return (@reply);}sub sc_command{(my (@args)=
@_);(my (@reply)=());if (($__sc_command eq (""))){($__sc_command=
check_path_win32 ($GLOBAL::CommandSC));}push (@reply,$__sc_command,@args);return
 (@reply);}sub net_command{(my (@args)=@_);(my (@reply)=());if (($__net_command 
eq (""))){(my $windowsPath=libnxh::NXTransGetEnvironment (
"\x77\x69\x6e\x64\x69\x72"));(my $file=(((($windowsPath.$GLOBAL::DIRECTORY_SLASH
)."\x53\x79\x73\x74\x65\x6d\x33\x32").$GLOBAL::DIRECTORY_SLASH).
$GLOBAL::CommandNet));if (-x ($file)){($__net_command=$file);}}if ((
$__net_command eq (""))){($__net_command=check_path_win32 ($GLOBAL::CommandNet))
;}if (($__net_command eq (""))){($__net_command=$GLOBAL::CommandNet);}push (
@reply,$__net_command,@args);return (@reply);}sub id_command{(my (@args)=@_);(my (
@reply)=());if (($__id_command ne (""))){push (@reply,$__id_command,@args);}else
{push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",
main::shell_quote ($GLOBAL::CommandID,@args));}return (@reply);}sub ps_command{(my (
@args)=@_);(my (@reply)=());if (($__ps_command ne (""))){push (@reply,
$__ps_command,@args);}else{push (@reply,$GLOBAL::CommandPS,@args);}return (
@reply);}sub mv_command{(my (@args)=@_);(my (@reply)=());if (($__mv_command ne 
(""))){push (@reply,$__mv_command,@args);}else{push (@reply,$GLOBAL::CommandBash
,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote ("\x6d\x76",@args))
;}return (@reply);}sub cp_command{(my (@args)=@_);(my (@reply)=());if ((
$__cp_command ne (""))){push (@reply,$__cp_command,@args);}else{push (@reply,
$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote
 ("\x63\x70",@args));}return (@reply);}sub grep_command{(my (@args)=@_);(my (
@reply)=());if (($__grep_command ne (""))){push (@reply,$__grep_command,@args);}
else{push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63"
,main::shell_quote ("\x67\x72\x65\x70",@args));}return (@reply);}sub 
pactl_command{(my (@args)=@_);(my (@reply)=());if (($__pactl_command ne (""))){
push (@reply,$__pactl_command,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandPactl,@args));}return (@reply);}sub pacmd_command{(my (@args)=@_
);(my (@reply)=());if (($__pacmd_command ne (""))){push (@reply,$__pacmd_command
,@args);}else{push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e",
"\x2d\x63",main::shell_quote ($GLOBAL::CommandPacmd,@args));}return (@reply);}
sub amixer_command{(my (@args)=@_);(my (@reply)=());if (($__amixer_command ne 
(""))){push (@reply,$__amixer_command,@args);}else{push (@reply,
$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote
 ($GLOBAL::CommandAmixer,@args));}return (@reply);}sub xhost_command{(my $option
=shift (@_));(my (@reply)=());if (($__xhost_command ne (""))){push (@reply,
$__xhost_command,$option);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandXhost,$option));}return (@reply);}sub xrdb_command{(my $option=
shift (@_));(my (@reply)=());if (($__xrdb_command ne (""))){push (@reply,
$__xrdb_command,$option);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandXrdb,$option));}return (@reply);}sub xdpyinfo_command{(my (@args
)=@_);(my (@reply)=());if (($__xdpyinfo_command ne (""))){push (@reply,
$__xdpyinfo_command,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandXdpyInfo,@args));}return (@reply);}sub mkfifo_command{(my $fifo=
shift (@_));(my (@reply)=());if (($__mkfifo_command ne (""))){push (@reply,
$__mkfifo_command,$fifo);}else{push (@reply,"\x6d\x6b\x66\x69\x66\x6f",$fifo);}
return (@reply);}sub hostname_command{(my (@reply)=());push (@reply,
$__hostname_command);return (@reply);}sub xprop_command{(my (@args)=@_);(my (
@reply)=());if (($__xprop_command ne (""))){Logger::debug2 ((
"\x70\x75\x73\x68\x20".$__xprop_command));push (@reply,$__xprop_command);push (
@reply,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote (
$GLOBAL::CommandXprop,@args));}return (@reply);}sub xauth_command{(my (@args)=@_
);Logger::debug (((((
"\x78\x61\x75\x74\x68\x5f\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x5b".
$GLOBAL::CommandXauth)."\x5d\x5b").$__xauth_command)."\x5d"));(my (@reply)=());(my $xauthcmd
=xauth_command_path ());if (($xauthcmd=~ /nxauth/ )){push (@reply,$xauthcmd,
@args);}else{push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e",
"\x2d\x63",main::shell_quote ($xauthcmd,@args));}return (@reply);}sub 
xauth_command_path{Logger::debug (((((
"\x78\x61\x75\x74\x68\x5f\x63\x6f\x6d\x6d\x61\x6e\x64\x5f\x70\x61\x74\x68\x20\x5b"
.$GLOBAL::CommandXauth)."\x5d\x5b").$__xauth_command)."\x5d"));(my $xauthcmd=(((
($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH).$GLOBAL::CommandXauth));if ((($__xauth_command eq ("")
)or-x ($xauthcmd))){return ($xauthcmd);}else{return ($__xauth_command);}}sub 
date_command{(my (@args)=@_);(my (@reply)=());if (($__date_command ne (""))){
push (@reply,$__date_command,@args);}else{push (@reply,$GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote ("\x64\x61\x74\x65",
@args));}return (@reply);}sub touch_command{(my (@args)=@_);(my (@reply)=());if 
(($__touch_command ne (""))){push (@reply,$__touch_command,@args);}else{push (
@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",
main::shell_quote ("\x74\x6f\x75\x63\x68",@args));}return (@reply);}sub 
mkdir_command{(my $dir=shift (@_));(my $arg=shift (@_));(my (@reply)=());if ((
$__mkdir_command ne (""))){push (@reply,$__mkdir_command);if (($arg ne (""))){
push (@reply,$arg);}push (@reply,$dir);}else{push (@reply,($ENV{
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"}.
"\x5c\x53\x79\x73\x74\x65\x6d\x33\x32\x5c\x63\x6d\x64\x2e\x65\x78\x65"),((((
"\x63\x6d\x64\x20\x2f\x43\x20".$GLOBAL::CommandMkDir)."\x20\x22").$dir)."\x22"))
;}return (@reply);}sub cklistsessions_command{(my (@args)=@_);(my (@reply)=());
if (($__cklistsessions_command ne (""))){push (@reply,$__cklistsessions_command,
@args);}else{push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e",
"\x2d\x63",main::shell_quote (
"\x63\x6b\x2d\x6c\x69\x73\x74\x2d\x73\x65\x73\x73\x69\x6f\x6e\x73",@args));}
return (@reply);}sub last_command{(my (@args)=@_);(my (@reply)=());if ((
$__last_command ne (""))){push (@reply,$__last_command,@args);}else{push (@reply
,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",
main::shell_quote ("\x6c\x61\x73\x74",@args));}return (@reply);}sub 
isScreenLockCommandsExistByDE{(my $desktopEnvironment=shift (@_));if (exists (
$screenLockCommands{$desktopEnvironment})){return ((0x008b+ 7093-0x1c3f));}
return ((0x0f57+ 2744-0x1a0f));}sub getScreenLockCommandsByDE{(my $desktopEnvironment
=shift (@_));return ($screenLockCommands{$desktopEnvironment});}"\x3f\x3f\x3f";
