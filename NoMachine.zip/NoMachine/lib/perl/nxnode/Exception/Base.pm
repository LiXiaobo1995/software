############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::Base::BEGIN{package Exception::Base;no warnings;require base;do{
"\x62\x61\x73\x65"->import ("\x45\x72\x72\x6f\x72")};}sub Exception::Base::new{
package Exception::Base;no warnings;(my $self=shift (@_));(my $text=(("").shift 
(@_)));(my (@args)=());(local $Error::Depth=($Error::Depth+(0x0065+ 1701-0x0709)
));(local $Error::Debug=(0x1adc+ 2869-0x2610));(my ($pkg,$file,$line,$sub)=
caller ($Error::Depth));$self->SUPER::new ((-"\x74\x65\x78\x74"),$text,(-
"\x63\x73\x75\x62"),$sub,@args);}sub Exception::Base::notify{package 
Exception::Base;no warnings;(my $self=shift (@_));(my $text=$self->text);
main::nxwrite (main::nxgetSTDOUT (),((((
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x20".$text)."\x20").$self->csub).
"\x0a"));(my $trace=$self->stacktrace);main::nxwrite (main::nxgetSTDOUT (),
$trace);}sub Exception::Base::csub{package Exception::Base;no warnings;(my $self
=shift (@_));(exists ($$self{"\x2d\x63\x73\x75\x62"})?$$self{
"\x2d\x63\x73\x75\x62"}:undef);}package Exception::Base;no warnings;
"\x3f\x3f\x3f";
