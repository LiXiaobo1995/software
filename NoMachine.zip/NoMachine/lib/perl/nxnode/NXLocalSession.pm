############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}package
 NXLocalSession;no warnings;($serverSocket=undef);($sessionMode=(""));(
$displayOwner=undef);($waitingForNewServerDaemon=(0x0f88+ 3798-0x1e5e));(
$isLoginWindow=(0x1887+ 2870-0x23bd));($currentDE=(""));($unknownDE=
"\x75\x6e\x6b\x6e\x6f\x77\x6e");($gnomeDE="\x67\x6e\x6f\x6d\x65");($kdeDE=
"\x6b\x64\x65");($xfceDE="\x78\x66\x63\x65");($cinnamonDE=
"\x63\x69\x6e\x6e\x61\x6d\x6f\x6e");($mateDE="\x6d\x61\x74\x65");($lxdeDE=
"\x6c\x78\x64\x65");($pantheonDE="\x70\x61\x6e\x74\x68\x65\x6f\x6e");(
$enlightenmentDE="\x65\x6e\x6c\x69\x67\x68\x74\x65\x6e\x6d\x65\x6e\x74");(
$budgieDE="\x62\x75\x64\x67\x69\x65");($trinityDE="\x74\x72\x69\x6e\x69\x74\x79"
);($commonDE="\x63\x6f\x6d\x6d\x6f\x6e");($dbusAddress=(""));($xdgSessionPath=
(""));($xdgSessionId=(""));($applicationXauthorityEnv=(""));(@appPathEnvArray=()
);($dbusReplyTimeout="\x31\x35\x30\x30");($dbusLockString=
"\x53\x63\x72\x65\x65\x6e\x20\x6c\x6f\x63\x6b\x65\x64\x20\x62\x79\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65"
);($lockScreen=(0x0451+ 5033-0x17fa));($logoutOnDisconnect=(0x0180+ 4838-0x1466)
);($lockScreenAnswerTimeout="\x32");($lockScreenBeforeTerminate=(""));(
$logoutBeforeTerminate=(""));($logoutOnDisconnectTimeout=(0x0426+ 496-0x0616));(
$logoutInitiated=(0x069c+ 586-0x08e6));($logoutTime=(0x0dc0+ 5616-0x23b0));sub 
handleStartLocalSessionNodeLinux{(my $refParameters=shift (@_));sub BEGIN{
require Agent;do{"\x41\x67\x65\x6e\x74"->import};}sub BEGIN{require 
NXClientMonitor;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x4d\x6f\x6e\x69\x74\x6f\x72"->import};}sub 
NXClientMonitor::BEGIN{package NXClientMonitor;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
BEGIN{require Agent;do{"\x41\x67\x65\x6e\x74"->import};}sub BEGIN{require 
NXClientMonitor;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x4d\x6f\x6e\x69\x74\x6f\x72"->import};}sub 
BEGIN{require NXLocalSession;do{
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e"->import};}sub BEGIN{
require NXSessionMonitor;do{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"->import};}(my (
%agentParameters)=());sub BEGIN{require NXLocalSession;do{
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e"->import};}sub BEGIN{
require NXSessionMonitor;do{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"->import};}if 
(Common::NXSessionType::isForeignMaster ($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"})){($agentParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"}=
Common::NXSessionType::getForeignDesktop ());}else{($agentParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"}=$$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"});(my $message=
getRegisterIntoServerMessage ($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"},"\x65\x6d\x70\x74\x79"));(my $bytes=
main::nxwrite (main::nxgetSTDOUT (),($message."\x0a")));Logger::debug (((((
"\x53\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20".$message)."\x20\x5b")
.$bytes)."\x5d\x20\x74\x6f\x20\x64\x61\x65\x6d\x6f\x6e\x2e"));}
NXSession::setSessionType ($agentParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"});($agentParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}=$$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"});($agentParameters{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}=$$refParameters{
"\x70\x72\x69\x6f\x72\x69\x74\x79"});($agentParameters{
"\x78\x73\x65\x72\x76\x65\x72\x44\x69\x73\x70\x6c\x61\x79"}=$$refParameters{
"\x6c\x6f\x63\x61\x6c\x5f\x64\x69\x73\x70\x6c\x61\x79"});($agentParameters{
"\x78\x73\x65\x72\x76\x65\x72\x43\x6f\x6f\x6b\x69\x65"}=$$refParameters{
"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"});($agentParameters{
"\x71\x6d\x70\x53\x6f\x63\x6b\x65\x74"}=$$refParameters{
"\x71\x6d\x70\x53\x6f\x63\x6b\x65\x74"});if (($$refParameters{
"\x65\x6e\x63\x64\x65\x76"}ne (""))){($agentParameters{
"\x65\x6e\x63\x64\x65\x76"}=$$refParameters{"\x65\x6e\x63\x64\x65\x76"});}if (
Agent::init ((\%agentParameters))){Agent::start ();}
NXClientMonitor::setLocalCookie ($$refParameters{
"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"});
NXClientMonitor::setLocalDisplay ($$refParameters{
"\x6c\x6f\x63\x61\x6c\x5f\x64\x69\x73\x70\x6c\x61\x79"});if (($$refParameters{
"\x58\x73\x65\x72\x76\x65\x72\x50\x69\x64"}ne (""))){
NXClientMonitor::setXserverPid ($$refParameters{
"\x58\x73\x65\x72\x76\x65\x72\x50\x69\x64"});
NXClientMonitor::setSessionPidWithoutWatchdog ($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x50\x69\x64"});}else{
NXClientMonitor::setSessionPid ($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x50\x69\x64"});}NXClientMonitor::setNXWmRunning (
$$refParameters{"\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67"});
NXClientMonitor::setSSHAuthSock ($$refParameters{
"\x53\x53\x48\x41\x75\x74\x68\x53\x6f\x63\x6b"});NXSessionMonitor::monitorStatus
 ("\x6c\x6f\x63\x61\x6c");Agent::terminate ();NXClientMonitor::terminate ();}sub
 handleStartLocalSessionNode{(my $refParameters=shift (@_));if (
Common::NXSessionType::isForeignMaster ($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"})){Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return (handleStartLocalSessionNodeLinux ($refParameters));}}sub 
checkLocalSession{return (checkLocalSessionWindows ());}sub unregisterFromServer
{(my $sock=getServerSocket ());if (defined ($sock)){($message.=((
"\x20\x4e\x58\x3e\x20".
$GLOBAL::MSG_UNREGISTER_LOCAL_NODE_FROM_SERVER_STARTUP_MONITOR).
"\x20\x75\x6e\x72\x65\x67\x69\x73\x74\x65\x72\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e"
));(my $writtenbytes=main::nxwrite ($sock,($message."\x0a")));}}sub 
checkLocalSessionApple{(my $localSessionType="\x64\x65\x73\x6b\x74\x6f\x70");(my $displayOwner
=Common::NXCore::nxGetDesktopOwner ());if (($displayOwner eq 
"\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77")){($localSessionType=
"\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77");($displayOwner=
"\x72\x6f\x6f\x74");setLoginWindowMode ();}else{setDesktopMode ();}Logger::debug
 (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x43\x68\x65\x63\x6b\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x70\x70\x6c\x65\x20\x6f\x77\x6e\x65\x72\x20\x27"
.$displayOwner)."\x27\x20\x74\x79\x70\x65\x20\x27").$localSessionType).
"\x27\x2e"));($displayOwner=Common::NXCore::getEffectiveUsername ());(
$desktopOwnerID=Common::NXCore::userInfoGetUidByUsername ($displayOwner));(my $display
=Agent::getAgentDisplay ());(my $cookie=Agent::getAgentCookie ());Logger::debug2
 ((((("\x64\x69\x73\x70\x6c\x61\x79\x20\x3d\x20\x27".$display).
"\x27\x2c\x20\x63\x6f\x6f\x6b\x69\x65\x20\x3d\x20\x27").$cookie)."\x27\x2e"));(my $session
=((main::urlencode ($desktopOwnerID)."\x3a").main::urlencode ($displayOwner)));(
$session.=((("\x3a".main::urlencode ($display))."\x3a").main::urlencode (
"\x6d\x61\x63")));($session.=((("\x3a".main::urlencode ($localSessionType)).
"\x3a").main::urlencode ("\x65\x6d\x70\x74\x79")));($session.=((("\x3a".
main::urlencode ("\x30"))."\x3a").main::urlencode ("\x65\x6d\x70\x74\x79")));(
$session.=("\x3a".main::urlencode ($cookie)));($session.=("\x3a".main::urlencode
 ("\x65\x6d\x70\x74\x79")));($session.="\x20");return ($session,
$localSessionType);}sub checkLocalSessionWindows{(my ($displayOwner,
$localSessionType)=getDisplayOwnerAndType ());(my $display=
Agent::getAgentDisplay ());(my $cookie=Agent::getAgentCookie ());Logger::debug2 
((((("\x64\x69\x73\x70\x6c\x61\x79\x20\x3d\x20\x27".$display).
"\x27\x2c\x20\x63\x6f\x6f\x6b\x69\x65\x20\x3d\x20\x27").$cookie)."\x27\x2e"));
Logger::debug2 (((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x69\x73\x20\x27"
.$localSessionType)."\x27\x2e"));(my $session=((main::urlencode ("\x30")."\x3a")
.main::urlencode ($displayOwner)));($session.=((("\x3a".main::urlencode (
$display))."\x3a").main::urlencode ("\x77\x69\x6e\x64\x6f\x77\x73")));($session
.=((("\x3a".main::urlencode ($localSessionType))."\x3a").main::urlencode (
"\x65\x6d\x70\x74\x79")));($session.=((("\x3a".main::urlencode ("\x30"))."\x3a")
.main::urlencode ("\x65\x6d\x70\x74\x79")));($session.=("\x3a".main::urlencode (
$cookie)));($session.=("\x3a".main::urlencode ("\x65\x6d\x70\x74\x79")));(
$session.="\x20");return ($session,$localSessionType);}sub 
registerIntoServerAfterServerCrash{(my $sessionString=shift (@_));(my $sessionId
=Agent::getSessionId ());(my $message.=((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_REGISTER_LOCAL_NODE_IN_SERVER_STARTUP_MONITOR_AFTER_SERVER_CRASH).
"\x20").$sessionId)."\x20").$sessionString));(my $value=registerIntoServer (
$sessionString,$sessionId,$message));return ($value);}sub registerIntoServer{(my $sessionString
=shift (@_));(my $sessionId=shift (@_));(my $messageToServer=shift (@_));
Logger::debug (((((
"\x52\x65\x67\x69\x73\x74\x65\x72\x20\x69\x6e\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x73\x65\x73\x73\x69\x6f\x6e\x53\x74\x72\x69\x6e\x67\x20\x27"
.$sessionString)."\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x64\x20\x27").
$sessionId)."\x27"));(my $path=NXPaths::getPathToServerDB ());(my $monitorCookieFile
=(($path.$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));(my $monitorPortFile
=(($path.$GLOBAL::DIRECTORY_SLASH)."\x70\x6f\x72\x74"));my ($cookie);my ($port);
(my $sock=(-(0x0f1c+ 2531-0x18fe)));(my $startTime=main::nxTime ());(my $timeout
=$GLOBAL::registerIntoServerTimeout);while ((main::nxTime ()<($startTime+
$timeout))){unless ((Common::NXFile::isExists ($monitorCookieFile)and 
Common::NXFile::isExists ($monitorPortFile))){main::nxsleep (
$GLOBAL::sleepTimeWhileWaitingForEvent);next;}(my $FH=main::nxopen (
$monitorCookieFile,$NXBits::O_RDONLY,(0x0390+ 6653-0x1d8d)));unless (defined (
$FH)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".
$monitorCookieFile)."\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));
return ((0x071c+ 651-0x09a7));}(my $bytes_read=main::nxread ($FH,(\$cookie),
(0x1246+ 1290-0x0750)));main::nxclose ($FH);($FH=main::nxopen ($monitorPortFile,
$NXBits::O_RDONLY,(0x0152+ 5923-0x1875)));unless (defined ($FH)){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".
$monitorPortFile)."\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));return ((0x14b2+ 1783-0x1ba9));}($bytes_read=
main::nxread ($FH,(\$port),(0x11b2+ 1595-0x07ed)));main::nxclose ($FH);chomp (
$cookie);chomp ($port);if (($sock==(-(0x0f14+ 4205-0x1f80)))){($sock=
main::nxConnectLocal ($port));}if (($sock==(-(0x0eab+ 3469-0x1c37)))){
main::nxsleep ((0x00f5+ 7122-0x1cc6));}else{(my $message=(("\x4e\x58\x3e\x20".
$cookie)."\x20"));if (($messageToServer ne (""))){($message.=$messageToServer);}
else{($message.=getRegisterIntoServerMessage ($sessionId,$sessionString));}(my $writtenbytes
=main::nxwrite ($sock,($message."\x0a")));if (($writtenbytes==(-
(0x0425+ 762-0x071e)))){Logger::debug ((((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x27"
.$message)."\x27\x20\x2d\x20").$writtenbytes));main::nxsleep (
(0x0633+ 1029-0x0a37));}else{($mirror{
"\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74"}=$sock);setServerSocket (
$sock);return ((0x115d+ 5078-0x2532));}}}return ((0x0386+ 8537-0x24df));}sub 
getRegisterIntoServerMessage{(my $sessionId=shift (@_));(my $sessionString=shift
 (@_));(my $message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_REGISTER_LOCAL_NODE_IN_SERVER_STARTUP_MONITOR)."\x20"));($message.=
(($sessionId."\x20").$sessionString));return ($message);}sub 
getDisplayOwnerAndType{Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x4f\x77\x6e\x65\x72\x20\x27"
.$displayOwner)."\x27\x20\x6d\x6f\x64\x65\x20\x27").$sessionMode)."\x27\x2e"));
return ($displayOwner,$sessionMode);}sub setDisplayOwnerAndType{(my $displayOwner
=shift (@_));if (($displayOwner eq "\x64\x65\x74\x61\x63\x68\x65\x64")){
setLoginWindowMode ();($NXLocalSession::displayOwner=
Common::NXCore::getEffectiveUsername ());}else{setDesktopMode ();(
$NXLocalSession::displayOwner=$displayOwner);}}sub setServerSocket{(my $socket=
shift (@_));Logger::debug2 (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x73\x65\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x2e"));($serverSocket=$socket);}sub getServerSocket{(my $socket=
$serverSocket);return ($socket);}sub writeToServer{(my $message=shift (@_));(my $writtenbytes
=main::nxwrite ($serverSocket,$message));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x4d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message).
"\x27\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
));}sub parseServerSocket{(my $socket=shift (@_));(my $buffer=shift (@_));
Logger::debug (((((
"\x50\x61\x72\x73\x69\x6e\x67\x20\x62\x75\x66\x66\x65\x72\x20\x27".$buffer).
"\x27\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").$socket)."\x2e"));(my (@messages)=
split ( /\n/ ,$buffer,(0x0990+ 1469-0x0f4d)));foreach my $line (@messages){
Logger::debug ((("\x50\x61\x72\x73\x69\x6e\x67\x20\x6c\x69\x6e\x65\x20\x27".
$line)."\x27\x2e"));if (($line=~ s/^NX> $GLOBAL::MSG_MAKE_UPDATE(.*)//g )){
main::nxrequire ("\x4e\x58\x55\x70\x64\x61\x74\x65");(my $ignore=(""));(my $tempLine
=$1);if (($tempLine=~ /ask/ )){NXUpdate::handleBackgroundAsk ();}else{if (((
$tempLine=~ /ignore=(\d+\.\d+\.\d+_\d+)/ )or ($tempLine=~ /ignore=(\d+\.\d+\.\d+)/ )
)){($ignore=$1);}NXUpdate::handleSilentUpdate ($ignore);}}if (($line=~ s/^NX> $GLOBAL::MSG_NODE_PONG.*//g )
){Logger::debug (
"\x47\x6f\x74\x20\x70\x69\x6e\x67\x20\x72\x65\x70\x6c\x79\x20\x66\x72\x6f\x6d\x20\x4e\x58\x20\x73\x65\x72\x76\x65\x72"
,(0x1a97+ 2998-0x264d));($__pingMessagesSent=(0x18bf+ 3446-0x2635));(
$__pingWarningLogged=(0x0805+ 7254-0x245b));next;}if (($line=~ s/^NX> $GLOBAL::MSG_NOTIFY_NODE_MASTER_SWITCHED (.*)//g )
){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x6d\x61\x73\x74\x65\x72\x20\x73\x77\x69\x74\x63\x68\x3a\x20\x68\x61\x6e\x64\x6c\x65\x53\x77\x69\x74\x63\x68\x4d\x61\x73\x74\x65\x72"
,(0x1b45+ 710-0x1e0b));NXSessionMonitor::handleSwitchMaster ($1);next;}if ((
$line=~ s/^NX> $GLOBAL::MSG_PASS_TO_MONITOR option=(.*) (.*)//g )){(my $option=
$1);(my $message=$2);NXClientMonitor::sendOption ($message,$option);}if (($line
=~ s/^NX> $GLOBAL::MSG_SERVER_STATUS_TO_NXCLIENT//g )){(my $value=
main::urldecode ($line));($value=~ s/serverstatus// );($value=~ s/^\s+// );(my $option
="\x73\x65\x72\x76\x65\x72\x73\x74\x61\x74\x75\x73");
NXClientMonitor::sendServerStatusToNXClient ($value,$option);next;}if (($line=~ s/^NX> $GLOBAL::MSG_UPNP_STATUS_TO_NXCLIENT//g )
){(my $value=main::urldecode ($line));($value=~ s/upnpstatus// );($value=~ s/^\s+// )
;(my $option="\x75\x70\x6e\x70\x73\x74\x61\x74\x75\x73");
NXClientMonitor::sendUPnPStatusToNXClient ($value,$option);next;}if (($line=~ s/^NX> $GLOBAL::MSG_SERVICES_STATUS_FOR_CLIENT//g )
){Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x73\x74\x61\x74\x75\x73\x20\x66\x6f\x72\x20\x63\x6c\x69\x65\x6e\x74\x3a\x20"
.$line)."\x2e"));NXClientMonitor::handleServicestatus ($line);next;}if (($line=~ s/^NX> $GLOBAL::REQUEST_FOR_DISCONNECT.*//g )
){NXSessionMonitor::__handleFIFOProto200 ();}if (($line=~ s/^NX> $GLOBAL::MSG_NODE_TERMINATE_ON_REQUEST (.*)//g )
){(my $msg=$1);Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72"
,(0x0586+ 4738-0x1808));($GLOBAL::NORMAL_SHUTDOWN="\x79\x65\x73");if (($msg=~ /immediate/g )
){eval{NXSessionMonitor::killSession ((0x025b+ 2633-0x0ca3));};if ($@){
Logger::debug (((
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x3a\x20"
.$@)."\x2e"));}}else{eval{NXSessionMonitor::killSession ((0x1132+ 5308-0x25ee),
NXSessionMonitor::getKillAgentSinceTeardownReceived ());};if ($@){Logger::debug 
(((
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x3a\x20"
.$@)."\x2e"));}}next;}if (($line=~ s/^NX> $GLOBAL::MSG_CLOSE_MONITOR.*//g )){
Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x63\x6c\x6f\x73\x65\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72"
,(0x0b94+ 1361-0x10e5));eval{NXSessionMonitor::killMonitor ();};if ($@){
Logger::debug (((
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x3a\x20"
.$@)."\x2e"));}next;}if (($line=~ s/^NX> $GLOBAL::MSG_REQUEST_FOR_PING (.*)//g )
){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x73\x65\x6e\x64\x20\x70\x69\x6e\x67\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72"
,(0x0904+ 3057-0x14f5));NXPingMonitor::handleRequestForPingMessage ();next;}if (
($line=~ s/^NX> $GLOBAL::MSG_MAIN_SESSION_TERMINATE (.*)//g )){(my $msg=$1);
main::nxwrite ($reply_socket,(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_MAIN_SESSION_TERMINATE)."\x20").$msg)."\x0a"));next;}if (($line=~ s/^NX> $GLOBAL::MSG_MAIN_SESSION_NOT_TERMINATE (.*)//g )
){(my $msg=$1);main::nxwrite ($reply_socket,(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_MAIN_SESSION_NOT_TERMINATE)."\x20\x45\x52\x52\x4f\x52\x3a\x20").
$msg)."\x0a"));next;}if (($line=~ s/^NX> $GLOBAL::MSG_MESSAGE_FROM_SERVER (.*)//g )
){(my $message=$1);(my $log_message=$message);($log_message=~ s/(send-pulse-cookie )[^\n]*/$1******/gm )
;($log_message=main::hideOutput ($log_message));Logger::debug (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x5b"
.$log_message)."\x5d"),(0x1c93+ 2616-0x26ca));
NXSessionMonitor::handleMessageFromServer ($message);next;}if ((($line=~ s/\nNX> $GLOBAL::MSG_LOCAL_RECORDING (.*)//g )
or ($line=~ s/^NX> $GLOBAL::MSG_LOCAL_RECORDING (.*)//g ))){(my $message=$1);
Logger::debug (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x5b"
.$message)."\x5d"),(0x05ed+ 4684-0x1838));handleLocalRecording ($message);next;}
if ((($line=~ s/\nNX> $GLOBAL::MSG_ANYWHERE (.*)//g )or ($line=~ s/^NX> $GLOBAL::MSG_ANYWHERE (.*)//g )
)){(my $message=$1);Logger::debug (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x41\x6e\x79\x77\x68\x65\x72\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x27"
.$message)."\x27"),(0x1689+ 2992-0x2238));handleAnywhere ($message);next;}if (((
$line=~ s/\nNX> $GLOBAL::MSG_DESKTOP_SHARING (.*)//g )or ($line=~ s/^NX> $GLOBAL::MSG_DESKTOP_SHARING (.*)//g )
)){(my $message=$1);Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x20"
.$message)."\x27\x2e"),(0x0dca+ 5040-0x2179));handleDesktopSharing ($message);
next;}if ((($line=~ s/\nNX> $GLOBAL::MGS_SERVER_VERSION (.*)//g )or ($line=~ s/^NX> $GLOBAL::MGS_SERVER_VERSION (.*)//g )
)){(my $message=$1);Logger::debug (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x5b"
.$message)."\x5d"),(0x1301+ 4181-0x2355));handleServerVersionAndProduct (
$message);next;}if ((($line=~ s/\nNX> $GLOBAL::MGS_FILE_TRANSFER (.*)//g )or (
$line=~ s/^NX> $GLOBAL::MGS_FILE_TRANSFER (.*)//g ))){(my $message=$1);
Logger::debug (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x5b"
.$message)."\x5d"),(0x1235+ 805-0x1559));handleFileTransferStatus ($message);
next;}if (($line=~ s/^NX> $GLOBAL::MSG_MESSAGE (.*)//g )){(my $message=$1);
Logger::debug ((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x75\x73\x65\x72\x3a\x20"
.$message),(0x0657+ 3340-0x1363));main::send_message ((""),main::urldecode (
$message));next;}if (($line=~ s/^NX> $GLOBAL::MSG_CONNECT_AGENT connectAgent//g )
){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x6f\x72\x20\x73\x74\x61\x72\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65"
);NXSessionMonitor::connectAgent ();}if (($line=~ s/^NX> $GLOBAL::MSG_SEND_MESSAGE.*: (.*)//g )
){(my $message=$1);main::send_message ((""),main::urldecode ($message));}if (((
$line=~ s/^NX> $GLOBAL::MSG_ASK_NODE_FOR_ATTACH (.*)//g )or ($line=~ s/^NX> $GLOBAL::MSG_IGNORE_ATTACH_TO_NODE (.*)//g )
)){(my $message=$1);Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x61\x73\x6b\x20\x66\x6f\x72\x20\x61\x74\x74\x61\x63\x68\x20\x27"
.$message)."\x27\x2e"));NXClientMonitor::askForAttach ($message);}if (($line=~ s/^NX> $GLOBAL::MSG_SEND_TO_ADMIN (.*)//g )
){(my $message=$1);($message=main::urldecode ($message));
showWarningPopupForAdmin ($message);}if (($line=~ s/^(NX> 99\d{1}.*)//g )){(my $message
=$1);(my $log_message=$message);($log_message=main::hideOutput ($log_message));
Logger::debug2 (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x5b"
.$log_message)."\x5d"));if (($message=~ /$GLOBAL::MSG_ATTACHED_USER_MONITOR MONITOR ON type=(.*) / )
){setSessionMode ($1);}elsif (($message=~ /$GLOBAL::MSG_ATTACHED_USER_MONITOR Attached user.*/ )
){unsetLogoutWithTimeoutInitiated ();}NXClientMonitor::sendToNxmonitor ($message
,NXSessionMonitor::getSelectorReference ());}if (($line=~ s/^NX> $GLOBAL::MSG_ASK_NODE_FOR_DISCONNECT (.*)//g )
){(my $message=$1);Logger::debug2 (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x5b"
.$message)."\x5d"));NXClientMonitor::askForAttach ($message);}if (($line=~ s/^NX> $GLOBAL::MSG_ASK_NODE_FOR_CONFIRM_SESSION_TYPE (.*)//g )
){(my $message=$1);NXSessionMonitor::handleConfirmSessionType ($message);}if ((
$line=~ s/^NX> $GLOBAL::MSG_NODE_DESCRIPTOR_ACQUIRE (.*)//g )){(my $message=$1);
NXSessionMonitor::handleAcquireFd ($message);}if (($line=~ s/^NX> $GLOBAL::MSG_NODE_DESCRIPTOR_ACQUIRE_CONNECT (.*)//g )
){(my $message=$1);NXSessionMonitor::handleAcquireFdConnect ($message);}if ((
$line=~ s/^NX> $GLOBAL::MSG_SET_SESSION_MODE Session mode (.*)//g )){(my $message
=$1);NXSessionMonitor::handleSessionMode ($message);}if (($line=~ s/^NX> $GLOBAL::MSG_SET_SCREEN_BLANKING Screen blanking (.*)//g )
){(my $message=$1);NXSessionMonitor::handleScreenBlanking ($message);}if (($line
=~ s/^NX> $GLOBAL::MSG_SET_SCREEN_BLANKING_EFFECT Screen blanking effect (.*)//g )
){(my $message=$1);NXSessionMonitor::handleScreenBlankingEffect ($message);}if (
($line=~ s/^NX> $GLOBAL::MSG_START_AGENT (.*)//g )){if (Agent::isAgentWorking ()
){Logger::debug (
"\x41\x67\x65\x6e\x74\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x77\x6f\x72\x6b\x69\x6e\x67\x2e"
);}else{Agent::start ();main::handleAgentStarted ();}}if (($line=~ s/^NX> $GLOBAL::MSG_LOCK_AT_DISCONNECT (.*)//g )
){lockScreen ();}if (($line=~ s/^NX> $GLOBAL::MSG_LOCK_BEFORE_TERMINATE value=(.*) //g )
){(my $value=$1);setLockScreenBeforeTerminateValue ($value);}if (($line=~ s/^NX> $GLOBAL::MSG_LOCK_SCREEN_VALUE LockScreen=(.*) //g )
){(my $value=$1);setLockScreenValue ($value);}if (($line=~ s/^NX> $GLOBAL::MSG_LOCK_BY_USER (.*)//g )
){lockScreen ();}if (($line=~ s/^NX> $GLOBAL::MSG_LOGOUT_ON_DISCONNECT (.*)//g )
){initiateLogout ();}if (($line=~ s/^NX> $GLOBAL::MSG_LOGOUT_BEFORE_TERMINATE value=(.*) //g )
){(my $value=$1);setLogoutBeforeTerminateValue ($value);}if (($line=~ s/^NX> $GLOBAL::MSG_LOGOUT_ON_DISCONNECT_VALUE value=(.*) timeout=(.*) //g )
){(my $value=$1);(my $timeout=$2);setLogoutOnDisconnectValue ($value,$timeout);}
if (($line=~ s/^NX> $GLOBAL::MSG_DEBUG_LOG_LEVEL (.*)//g )){
NXSessionMonitor::handleDebugLogLevelMessage ($1);}if (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_DISPLAY_MONITOR_ICON Display monitor icon status (.*)//g )
){NXSessionMonitor::handleDisplayMonitorIcon ($1);next;}if (($line=~ s/NX> $GLOBAL::MSG_UPDATE_SOUND_ALERT Sound alert status (.*)//g )
){NXSessionMonitor::handleSoundAlert ($1);next;}if (($line=~ s/NX> $GLOBAL::MSG_UPDATE_SHOW_DESKTOP_VIEWED Show desktop viewed status (.*)//g )
){NXSessionMonitor::handleShowDesktopViewed ($1);next;}}}sub 
handleLocalRecording{(my $message=shift (@_));if (($message=~ s/^local-recording (\d+)//g )
){NXLocalRecord::setIfLocalRecordingIsAvaliable ($1);if (
NXClientMonitor::isRunning ()){NXClientMonitor::sendLocalRecordingOptions ();}}
else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}}sub handleAnywhere{(my $message=shift (@_));if ((
$message=~ s/^default,(.*)//g )){NXClientMonitor::setAnywhereDefaultStatus ($1);
if (NXClientMonitor::isRunning ()){NXClientMonitor::sendAnywhereDefaultStatus ()
;}}elsif (($message=~ s/^notification,(.*)//g )){if (NXClientMonitor::isRunning 
()){NXClientMonitor::sendAnywhereNotification ($1);}}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}}sub handleServerVersionAndProduct{(my $message=shift (
@_));if (($message=~ s/^server-version (.*)//g )){
NXClientMonitor::setServerVersion ($1);if (NXClientMonitor::isRunning ()){
NXClientMonitor::sendProductVersion ();}}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}}sub handleFileTransferStatus{(my $message=shift (@_));
if (($message=~ s/^filetransfer (.*)//g )){NXClientMonitor::setFileTransfer ($1)
;if (NXClientMonitor::isRunning ()){NXClientMonitor::sendFileTransferOptions ();
}}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}}sub handleDesktopSharing{(my $message=shift (@_));
Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x2e"
);if (($message=~ s/^Desktop sharing value=(\d+)//g )){
NXClientMonitor::setDesktopSharing ($1);if (NXClientMonitor::isRunning ()){
NXClientMonitor::sendDesktopSharingOptions ();}}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}}sub askForAttachesAndQuerries{(my $message=((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_ASK_ATTACHED)."\x20").$GLOBAL::MESSAGES_FORMAT{
$GLOBAL::MSG_ASK_ATTACHED})."\x0a"));writeToServer ($message);($message=((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_ASK_ATTACH_QUERIES)."\x20").
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_ASK_ATTACH_QUERIES})."\x0a"));
writeToServer ($message);}sub waitingForNewServerDaemon{return (
$waitingForNewServerDaemon);}sub setWaitingForNewServerDaemon{(
$waitingForNewServerDaemon=(0x076c+ 6131-0x1f5e));}sub 
setNotWaitingForNewServerDaemon{($waitingForNewServerDaemon=(0x0187+ 925-0x0524)
);}sub lockScreen{if (isLoginWindowMode ()){Logger::debug (
"\x53\x6b\x69\x70\x20\x73\x63\x72\x65\x65\x6e\x20\x6c\x6f\x63\x6b\x20\x77\x68\x65\x6e\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x75\x6e\x64\x65\x72\x20\x6c\x6f\x67\x69\x6e\x20\x77\x69\x6e\x64\x6f\x77\x2e"
);return;}Logger::debug (
"\x49\x6e\x69\x74\x69\x61\x74\x69\x6e\x67\x20\x73\x63\x72\x65\x65\x6e\x20\x6c\x6f\x63\x6b\x2e"
);my ($result);($result=__lockScreenOnWindows ());if (($result==
(0x20a9+ 363-0x2214))){Logger::error (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x6c\x6f\x63\x6b\x20\x73\x63\x72\x65\x65\x6e\x2e"
);}}sub initiateLogout{if ((getLogoutOnDisconnectTimeout ()>
(0x0646+ 5556-0x1bfa))){setLogoutWithTimeoutInitiated ();setLogoutTime ((
Common::NXTime::getSecondsSinceEpoch ()+getLogoutOnDisconnectTimeout ()));}else{
logout ();}}sub logout{if (isLoginWindowMode ()){Logger::debug (
"\x53\x6b\x69\x70\x20\x6c\x6f\x67\x6f\x75\x74\x20\x77\x68\x65\x6e\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x75\x6e\x64\x65\x72\x20\x6c\x6f\x67\x69\x6e\x20\x77\x69\x6e\x64\x6f\x77\x2e"
);return;}Logger::debug (
"\x49\x6e\x69\x74\x69\x61\x74\x69\x6e\x67\x20\x6c\x6f\x67\x6f\x75\x74\x2e");my (
$result);($result=__logoutOnWindows ());if (($result==(0x110d+ 2556-0x1b09))){
Logger::error (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x6c\x6f\x67\x20\x6f\x75\x74\x2e");}}
sub __logoutOnApple{(my (@command)=());(my (@options)=());push (@command,
NXPaths::getLogoutScript ());push (@command,Common::NXCore::getEffectiveUsername
 ());(my ($stderr,$stdout,$exitValue)=main::nxRunCommand ((\@command),(\@options
)));if (($exitValue!=(0x1148+ 3960-0x20c0))){return ((0x0741+ 4281-0x17fa));}
return ((0x140a+ 3974-0x238f));}sub __logoutOnWindows{(my (@command)=());(my (
@options)=());push (@command,NXPaths::getLogoutScript ());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (@options
,"\x73\x65\x74\x20\x65\x6e\x76",("\x44\x49\x53\x50\x4c\x41\x59\x3d\x3a".
NXClientMonitor::getLocalDisplay ()));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x28\x78\x38\x36\x29\x3d"
.libnxh::NXTransGetEnvironment (
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x28\x78\x38\x36\x29"
)));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x57\x36\x34\x33\x32\x3d"
.libnxh::NXTransGetEnvironment (
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x57\x36\x34\x33\x32"
)));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x43\x6f\x6d\x53\x70\x65\x63\x3d".
libnxh::NXTransGetEnvironment ("\x43\x6f\x6d\x53\x70\x65\x63")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x46\x50\x5f\x4e\x4f\x5f\x48\x4f\x53\x54\x5f\x43\x48\x45\x43\x4b\x3d".
libnxh::NXTransGetEnvironment (
"\x46\x50\x5f\x4e\x4f\x5f\x48\x4f\x53\x54\x5f\x43\x48\x45\x43\x4b")));push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x77\x69\x6e\x64\x69\x72\x3d".
libnxh::NXTransGetEnvironment ("\x77\x69\x6e\x64\x69\x72")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45\x3d".libnxh::NXTransGetEnvironment
 ("\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x55\x53\x45\x52\x4e\x41\x4d\x45\x3d".
libnxh::NXTransGetEnvironment ("\x55\x53\x45\x52\x4e\x41\x4d\x45")));push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x50\x53\x4d\x6f\x64\x75\x6c\x65\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment (
"\x50\x53\x4d\x6f\x64\x75\x6c\x65\x50\x61\x74\x68")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x55\x53\x45\x52\x44\x4f\x4d\x41\x49\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x55\x53\x45\x52\x44\x4f\x4d\x41\x49\x4e")));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x3d".
libnxh::NXTransGetEnvironment (
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73")));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x50\x50\x44\x41\x54\x41\x3d".libnxh::NXTransGetEnvironment (
"\x41\x50\x50\x44\x41\x54\x41")));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",
("\x48\x4f\x4d\x45\x3d".Common::NXPaths::getUserRealHomeDirectoryByEffectiveUser
 ()));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".$ENV
{"\x50\x41\x54\x48"}));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));(my ($stderr,$stdout,$exitValue)=
main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x16d0+ 251-0x17cb))){return ((0x1b2c+ 1257-0x2015));}return (
(0x06e6+ 5728-0x1d45));}sub __logoutOnLinux{if (isNotDEIdentified ()){
__identifyDesktopEnvironment ();retrieveEnvVariables ();}(my (@command)=());(my (
@options)=());push (@command,NXPaths::getLogoutScript ());push (@command,
Common::NXCore::getEffectiveUsername ());push (@command,getCurrentDE ());(my $dbusAddress
=getDbusAddress ());if (($dbusAddress ne (""))){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x44\x42\x55\x53\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x42\x55\x53\x5f\x41\x44\x44\x52\x45\x53\x53\x3d"
.$dbusAddress));}(my $display=NXClientMonitor::getLocalDisplay ());if (($display
 ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x44\x49\x53\x50\x4c\x41\x59\x3d\x3a".$display));}push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x58\x44\x47\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x50\x41\x54\x48\x3d".
getXdgSessionPath ()));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x58\x44\x47\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x49\x44\x3d".getXdgSessionId 
()));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".
Common::NXPaths::getUserRealHomeDirectoryByEffectiveUser ()));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59\x3d".
__getXauthority ()));(my ($stderr,$stdout,$exitValue)=main::nxRunCommand ((
\@command),(\@options)));if (($exitValue!=(0x0445+ 2036-0x0c39))){return (
(0x1d05+ 517-0x1f0a));}return ((0x07f7+ 7424-0x24f6));}sub __lockScreenOnWindows
{(my $result=libnxhn::NXLockScreen ());if (($result==(-(0x1bf7+ 832-0x1f36)))){
Common::NXCore::reportErrorFromNXPL ();return ((0x1c62+ 1261-0x214f));}return (
(0x0cad+ 6006-0x2422));}sub __lockScreenOnApple{my ($result);if ((
$GLOBAL::CurrentNodeIsActive==(0x1b80+ 1685-0x2215))){Logger::debug (
"\x53\x6b\x69\x70\x20\x73\x63\x72\x65\x65\x6e\x20\x6c\x6f\x63\x6b\x20\x77\x68\x65\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x63\x74\x69\x76\x65\x2e"
);return ((0x0569+ 3400-0x12b0));}(my ($major,$minor,$patch)=__getMacVersion ())
;if (($major eq (""))){return ((0x1cf9+ 2225-0x25aa));}if (
__isNotSystemSupportsLockOrLoginApiOnApple ($major,$minor,$patch)){(my (@command
)=());(my (@options)=());push (@command,
"\x2f\x53\x79\x73\x74\x65\x6d\x2f\x4c\x69\x62\x72\x61\x72\x79\x2f\x43\x6f\x72\x65\x53\x65\x72\x76\x69\x63\x65\x73\x2f\x4d\x65\x6e\x75\x20\x45\x78\x74\x72\x61\x73\x2f\x55\x73\x65\x72\x2e\x6d\x65\x6e\x75\x2f\x43\x6f\x6e\x74\x65\x6e\x74\x73\x2f\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x2f\x43\x47\x53\x65\x73\x73\x69\x6f\x6e"
);push (@command,"\x2d\x73\x75\x73\x70\x65\x6e\x64");(my $display=
NXClientMonitor::getLocalDisplay ());if (($display ne (""))){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x44\x49\x53\x50\x4c\x41\x59\x3d\x3a".$display)
);}(my ($stderr,$stdout,$exitValue)=main::nxRunCommand ((\@command),(\@options))
);if (($exitValue!=(0x06af+ 5212-0x1b0b))){return ((0x071a+ 1271-0x0c11));}}
elsif (__isSystemSupportsLockApiOnApple ($major,$minor,$patch)){($result=
libnxhn::NXLockScreen ());if (($result==(-(0x0045+ 9781-0x2679)))){
Common::NXCore::reportErrorFromNXPL ();return ((0x20af+ 1482-0x2679));}}else{(
$result=libnxhn::NXSwitchToLoginScreen ());if (($result==(-(0x103d+ 3279-0x1d0b)
))){return ((0x0eed+ 1757-0x15ca));}}return ((0x0937+ 5570-0x1ef8));}sub 
__getMacVersion{(my $majorVersion=(""));(my $minorVersion=(""));(my $patchVersion
=(""));(my $distro=lc (Common::NXInfo::getDistroInfo ()));if (($distro=~ /mac[^\d]*(\d+)\.(\d+)\.(\d+)/ )
){($majorVersion=$1);($minorVersion=$2);($patchVersion=$3);}elsif (($distro=~ /mac[^\d]*(\d+)\.(\d+)/ )
){($majorVersion=$1);($minorVersion=$2);}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x69\x64\x65\x6e\x74\x69\x66\x79\x20\x4d\x61\x63\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x66\x72\x6f\x6d\x20\x4f\x53\x20\x69\x6e\x66\x6f\x20\x27"
.$distro)."\x27\x2e"));}return ($majorVersion,$minorVersion,$patchVersion);}sub 
__isNotSystemSupportsLockOrLoginApiOnApple{(my $major=shift (@_));(my $minor=
shift (@_));(my $patch=shift (@_));if (((($major==(0x08ff+ 2271-0x11d4))and (
$minor==(0x0389+ 8885-0x2632)))and ($patch==(0x0573+ 1212-0x0a29)))){return (
(0x0496+ 3495-0x123c));}}sub __isSystemSupportsLockApiOnApple{(my $major=shift (
@_));(my $minor=shift (@_));(my $patch=shift (@_));if ((($major>
(0x105c+ 2607-0x1a81))or (($major==(0x044c+ 6017-0x1bc3))and ($minor>=
(0x06d8+ 4201-0x1737))))){return ((0x1598+ 189-0x1654));}}sub 
__lockScreenOnLinux{if (isNotDEIdentified ()){__identifyDesktopEnvironment ();
retrieveEnvVariables ();}(my $result=__lockScreenWithDbusMessage ());if ((
$result==(0x1a9f+ 1227-0x1f6a))){Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x63\x6b\x20\x73\x63\x72\x65\x65\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x62\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x2e\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x75\x73\x65\x20\x73\x63\x72\x65\x65\x6e\x20\x6c\x6f\x63\x6b\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x2e"
);return (__lockScreenWithLockerApp ());}return ($result);}sub 
__isDbusDaemonInstalled{if (
Common::NXShellCommands::isDbusDaemonCommandAvailable ()){return (
(0x1b11+ 276-0x1c24));}return ((0x00c8+ 482-0x02aa));}sub retrieveEnvVariables{(my $pid
=shift (@_));(my $ignorePhysicalDbus=shift (@_));if (($pid eq (""))){($pid=
NXClientMonitor::getSessionPid ());}__retrieveEnvVariablesFromPid ($pid);(my $dbusAddress
=getDbusAddress ());if (((($dbusAddress ne (""))and ($ignorePhysicalDbus==
(0x06b7+ 1940-0x0e4a)))and (not (($dbusAddress=~ /^unix:abstract/ ))))){
Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x64\x62\x75\x73\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
.$dbusAddress)."\x27\x2e"));($dbusAddress=(""));}if (($dbusAddress ne (""))){
return;}if ((not (__isDbusDaemonInstalled ()))){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x44\x62\x75\x73\x20\x6e\x6f\x74\x20\x69\x6e\x73\x74\x61\x6c\x6c\x65\x64\x2e"
);return;}(my (@children)=Common::NXProcess::getChildrenOfProcess ($pid));
foreach my $pid (@children){Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x2e"));__retrieveEnvVariablesFromPid ($pid);(my $dbusAddress=
getDbusAddress ());if (((($dbusAddress ne (""))and ($ignorePhysicalDbus==
(0x00d5+ 5674-0x16fe)))and (not (($dbusAddress=~ /^unix:abstract/ ))))){
Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x64\x62\x75\x73\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
.$dbusAddress)."\x27\x2e"));($dbusAddress=(""));}if (($dbusAddress ne (""))){
return;}(my (@grandchildren)=Common::NXProcess::getChildrenOfProcess ($pid));
foreach my $pid (@grandchildren){Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x67\x72\x61\x6e\x64\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x2e"));__retrieveEnvVariablesFromPid ($pid);(my $dbusAddress=
getDbusAddress ());if (((($dbusAddress ne (""))and ($ignorePhysicalDbus==
(0x01e8+ 3430-0x0f4d)))and (not (($dbusAddress=~ /^unix:abstract/ ))))){
Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x64\x62\x75\x73\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
.$dbusAddress)."\x27\x2e"));($dbusAddress=(""));}if (($dbusAddress ne (""))){
return;}}}Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x64\x62\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x62\x75\x73\x20\x61\x64\x64\x72\x65\x73\x73\x2e"
);}sub __retrieveEnvVariablesFromPid{(my $pid=shift (@_));(my $path=((
"\x2f\x70\x72\x6f\x63\x2f".$pid)."\x2f\x65\x6e\x76\x69\x72\x6f\x6e"));(my $handle
=main::nxopen ($path,$NXBits::O_RDONLY,(0x0268+ 7872-0x2128)));if ((not (defined
 ($handle)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x65\x69\x76\x65\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x20\x66\x72\x6f\x6d\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));return ((0x12e6+ 4302-0x23b4));}(my $line=(""));(my $fileContent
=(""));while (main::nxread ($handle,(\$_),5120)){($line=$_);($fileContent.=$line
);}main::nxclose ($handle);if (($fileContent=~ /\bDBUS_SESSION_BUS_ADDRESS=([^\0]*)/ )
){__setDbusAddress ($1);}if (($fileContent=~ /\bXDG_SESSION_PATH=([^\0]*)/ )){
__setXdgSessionPath ($1);}if (($fileContent=~ /\bXDG_SESSION_ID=([^\0]*)/ )){
__setXdgSessionId ($1);}if (($fileContent=~ /\bXAUTHORITY=([^\0]*)/ )){
__setApplicationXauthorityEnv ($1);}if (($fileContent=~ /\bPATH=([^\0]*)/ )){(my (
@paths)=split ( /:/ ,$1,(0x0424+ 6885-0x1f09)));__setApplicationPathEnvArray (
@paths);}}sub __setDbusAddress{($dbusAddress=shift (@_));}sub getDbusAddress{
return ($dbusAddress);}sub __setXdgSessionPath{($xdgSessionPath=shift (@_));}sub
 getXdgSessionPath{return ($xdgSessionPath);}sub __setXdgSessionId{(
$xdgSessionId=shift (@_));}sub getXdgSessionId{return ($xdgSessionId);}sub 
__setApplicationPathEnvArray{(@appPathEnvArray=@_);}sub 
getApplicationPathEnvArray{return (@appPathEnvArray);}sub 
__setApplicationXauthorityEnv{($applicationXauthorityEnv=shift (@_));}sub 
__getXauthority{if ($applicationXauthorityEnv){return ($applicationXauthorityEnv
);}return (Agent::getLocalXauthorityFilePath ());}sub isLoginWindowMode{if ((
$sessionMode eq "\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77")){return (
(0x230d+   6-0x2312));}return ((0x0fff+  79-0x104e));}sub isDesktopMode{if ((
$sessionMode eq "\x64\x65\x73\x6b\x74\x6f\x70")){return ((0x02fd+ 3558-0x10e2));
}return ((0x02df+ 916-0x0673));}sub setLoginWindowMode{($sessionMode=
"\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77");Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x53\x65\x74\x20\x6c\x6f\x67\x69\x6e\x20\x77\x69\x6e\x64\x6f\x77\x20\x6d\x6f\x64\x65\x2e"
);}sub setDesktopMode{($sessionMode="\x64\x65\x73\x6b\x74\x6f\x70");
Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x53\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6d\x6f\x64\x65\x2e"
);}sub setNoDesktopMode{($sessionMode="\x6e\x6f\x44\x65\x73\x6b\x74\x6f\x70");
Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x53\x65\x74\x20\x6e\x6f\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6d\x6f\x64\x65\x2e"
);}sub setSessionMode{($sessionMode=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x53\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6d\x6f\x64\x65\x20\x27"
.$sessionMode)."\x27\x2e"));}sub __getDEApplicationNameAndArgs{(my $pid=
NXClientMonitor::getSessionPid ());(my $path=(("\x2f\x70\x72\x6f\x63\x2f".$pid).
"\x2f\x63\x6d\x64\x6c\x69\x6e\x65"));(my $handle=main::nxopen ($path,
$NXBits::O_RDONLY,(0x0d89+ 2652-0x17e5)));if ((not (defined ($handle)))){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x65\x69\x76\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6e\x61\x6d\x65\x20\x61\x6e\x64\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x72\x6f\x6d\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));return ((""),(""));}(my $cmdline=(""));(my $line=(""));(my $result
=main::nxreadLine ($handle,(\$line)));main::nxclose ($handle);if (($result==
(0x06c5+ 6876-0x21a1))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x65\x69\x76\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6e\x61\x6d\x65\x20\x61\x6e\x64\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x72\x6f\x6d\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));return ((""),(""));}(my (@args)=split ( /[\0\s]/ ,$line,
(0x0067+ 2668-0x0ad3)));(my $name=Common::NXFile::basename (shift (@args)));
return ($name,join ($",@args));}sub __identifyDesktopEnvironment{(my ($name,
$args)=__getDEApplicationNameAndArgs ());if (($name eq (""))){__setUnknownDE ();
return;}elsif (($name=~ /x-session-manag/i )){(my $result=
VirtualSessions::getDefaultSessionManager ((\$name)));if (($result==
(0x0443+ 4443-0x159e))){__setUnknownDE ();return;}}(my $cmdLine=(($name."\x20").
$args));if ((($cmdLine=~ /kde/i )or ($cmdLine=~ /kwrapper/i ))){__setKdeDE ();}
elsif (($cmdLine=~ /xfce/i )){__setXfceDE ();}elsif (($cmdLine=~ /cinnamon/i )){
__setCinnamonDE ();}elsif (($cmdLine=~ /mate/i )){__setMateDE ();}elsif (((
$cmdLine=~ /lxde/i )or ($cmdLine=~ /lxsession/i ))){__setLxdeDE ();}elsif ((
$cmdLine=~ /pantheon/i )){__setPantheonDE ();}elsif (($cmdLine=~ /enlightenment/i )
){__setEnlightenmentDE ();}elsif (($cmdLine=~ /budgie/i )){__setBudgieDE ();}
elsif (($cmdLine=~ /tde/i )){__setTrinityDE ();}elsif (($cmdLine=~ /gnome/i )){
__setGnomeDE ();}elsif (($cmdLine=~ /dt/i )){__setCommonDE ();}else{
__setUnknownDE ();}}sub getCurrentDE{return ($currentDE);}sub __setCurrentDE{(
$currentDE=shift (@_));}sub getUnknownDE{return ($unknownDE);}sub getGnomeDE{
return ($gnomeDE);}sub getKdeDE{return ($kdeDE);}sub getXfceDE{return ($xfceDE);
}sub getCinnamonDE{return ($cinnamonDE);}sub getMateDE{return ($mateDE);}sub 
getLxdeDE{return ($lxdeDE);}sub getPantheonDE{return ($pantheonDE);}sub 
getEnlightenmentDE{return ($enlightenmentDE);}sub getBudgieDE{return ($budgieDE)
;}sub getTrinityDE{return ($trinityDE);}sub getCommonDE{return ($commonDE);}sub 
__setGnomeDE{__setCurrentDE ($gnomeDE);}sub __setKdeDE{__setCurrentDE ($kdeDE);}
sub __setXfceDE{__setCurrentDE ($xfceDE);}sub __setCinnamonDE{__setCurrentDE (
$cinnamonDE);}sub __setMateDE{__setCurrentDE ($mateDE);}sub __setLxdeDE{
__setCurrentDE ($lxdeDE);}sub __setPantheonDE{__setCurrentDE ($pantheonDE);}sub 
__setEnlightenmentDE{__setCurrentDE ($enlightenmentDE);}sub __setbudgieDE{
__setCurrentDE ($budgieDE);}sub __setTrinityDE{__setCurrentDE ($trinityDE);}sub 
__setCommonDE{__setCurrentDE ($commonDE);}sub __setUnknownDE{__setCurrentDE (
$unknownDE);}sub isUnknownDE{if (($currentDE eq $unknownDE)){return (
(0x0254+ 6458-0x1b8d));}return ((0x08ab+ 473-0x0a84));}sub isNotDEIdentified{if 
(($currentDE eq (""))){return ((0x1c1c+ 2042-0x2415));}return (
(0x0efa+ 886-0x1270));}sub __lockScreenWithDbusMessage{my (@commands);(my $result
=__getAvailableDbusCommands ((\@commands)));if (($result!=(0x0c80+ 4439-0x1dd7))
){($result=__runAvailableCommands ((\@commands)));}return ($result);}sub 
__dbusListNamesSystem{(my $dbusAddress=(""));(my $system=(0x05ea+ 3905-0x152a));
return (__dbusListNames (@_,$dbusAddress,$system));}sub __dbusListNames{(my $commandPath
=shift (@_));(my $dbusAddress=shift (@_));(my $system=shift (@_));my (@options);
if (($dbusAddress ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x44\x42\x55\x53\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x42\x55\x53\x5f\x41\x44\x44\x52\x45\x53\x53\x3d"
.$dbusAddress));}my (@listNamesCommand);push (@listNamesCommand,$commandPath);if
 (($system==(0x0445+ 542-0x0662))){push (@listNamesCommand,
"\x2d\x2d\x73\x79\x73\x74\x65\x6d");}else{push (@listNamesCommand,
"\x2d\x2d\x73\x65\x73\x73\x69\x6f\x6e");}push (@listNamesCommand,
"\x2d\x2d\x64\x65\x73\x74\x3d\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x42\x75\x73"
);push (@listNamesCommand,
"\x2d\x2d\x74\x79\x70\x65\x3d\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c");push
 (@listNamesCommand,"\x2d\x2d\x70\x72\x69\x6e\x74\x2d\x72\x65\x70\x6c\x79");push
 (@listNamesCommand,
"\x2f\x6f\x72\x67\x2f\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2f\x44\x42\x75\x73"
);push (@listNamesCommand,
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x42\x75\x73\x2e\x4c\x69\x73\x74\x4e\x61\x6d\x65\x73"
);(my ($stderr,$stdout,$exitValue)=main::nxRunCommand ((\@listNamesCommand),(
\@options)));if (($exitValue!=(0x03ba+ 2202-0x0c54))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x64\x62\x75\x73\x20\x6e\x61\x6d\x65\x73\x2e"
);return ((""));}return ($stdout);}sub __getAvailableSystemDbusCommands{(my $commandPath
=shift (@_));(my $ref_commands=shift (@_));(my $result=__dbusListNamesSystem (
$commandPath));(my (@services)=__parseSystemListNamesOutput ($result));foreach my $service
 (@services){if (($service=~ /org.freedesktop.DisplayManager/ )){my (@command);
push (@command,$commandPath);push (@command,"\x2d\x2d\x73\x79\x73\x74\x65\x6d");
push (@command,"\x2d\x2d\x70\x72\x69\x6e\x74\x2d\x72\x65\x70\x6c\x79");push (
@command,
"\x2d\x2d\x74\x79\x70\x65\x3d\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c");push
 (@command,("\x2d\x2d\x64\x65\x73\x74\x3d".$service));push (@command,
getXdgSessionPath ());push (@command,($service.
"\x2e\x53\x65\x73\x73\x69\x6f\x6e\x2e\x4c\x6f\x63\x6b"));push (@$ref_commands,(
\@command));return ((0x193f+ 3277-0x260b));}}return ((0x1015+ 2699-0x1aa0));}sub
 __getAvailableSessionDbusCommands{(my $commandPath=shift (@_));(my $ref_commands
=shift (@_));(my $dbusAddress=getDbusAddress ());if (($dbusAddress eq (""))){
return ((0x0b7b+ 928-0x0f1b));}(my $result=__dbusListNames ($commandPath,
$dbusAddress));(my (@services)=__parseListNamesOutput ($result));foreach my $service
 (@services){(my (@parts)=split ( /\./ ,$service,(0x16e1+  66-0x1723)));my (
@command);push (@command,$commandPath);push (@command,
"\x2d\x2d\x74\x79\x70\x65\x3d\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c");push
 (@command,("\x2d\x2d\x64\x65\x73\x74\x3d".$service));push (@command,
"\x2d\x2d\x70\x72\x69\x6e\x74\x2d\x72\x65\x70\x6c\x79");push (@command,(
"\x2d\x2d\x72\x65\x70\x6c\x79\x2d\x74\x69\x6d\x65\x6f\x75\x74\x3d".
$dbusReplyTimeout));if (($service=~ /org.kde.screensaver/ )){push (@command,
"\x2f\x53\x63\x72\x65\x65\x6e\x53\x61\x76\x65\x72");push (@command,
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x53\x63\x72\x65\x65\x6e\x53\x61\x76\x65\x72\x2e\x4c\x6f\x63\x6b"
);}elsif (($service=~ /com.canonical.Unity/ )){push (@command,
"\x2f\x63\x6f\x6d\x2f\x63\x61\x6e\x6f\x6e\x69\x63\x61\x6c\x2f\x55\x6e\x69\x74\x79\x2f\x53\x65\x73\x73\x69\x6f\x6e"
);push (@command,
"\x63\x6f\x6d\x2e\x63\x61\x6e\x6f\x6e\x69\x63\x61\x6c\x2e\x55\x6e\x69\x74\x79\x2e\x53\x65\x73\x73\x69\x6f\x6e\x2e\x4c\x6f\x63\x6b"
);}elsif (($service=~ /org.freedesktop.ScreenSaver/ )){push (@command,
"\x2f\x53\x63\x72\x65\x65\x6e\x53\x61\x76\x65\x72");push (@command,
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x53\x63\x72\x65\x65\x6e\x53\x61\x76\x65\x72\x2e\x4c\x6f\x63\x6b"
);}else{push (@command,((((("\x2f".$parts[(0x05b6+ 4470-0x172c)])."\x2f").$parts
[(0x146a+ 1226-0x1933)])."\x2f").$parts[(0x08f2+ 4979-0x1c63)]));push (@command,
($service."\x2e\x4c\x6f\x63\x6b"));}if (($service=~ /org.cinnamon.ScreenSaver/i )
){push (@command,("\x73\x74\x72\x69\x6e\x67\x3a".$dbusLockString));}if ((
getCurrentDE ()=~ /$parts[1]/i )){unshift (@$ref_commands,(\@command));}else{
push (@$ref_commands,(\@command));}}if ((scalar (@$ref_commands)==
(0x002c+ 4488-0x11b4))){return ((0x06dd+ 2422-0x1053));}return (
(0x01f2+ 6410-0x1afb));}sub __getAvailableDbusCommands{(my $ref_commands=shift (
@_));if (Common::NXShellCommands::isNotDbusSendCommandAvailable ()){
Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x63\x61\x74\x65\x20\x64\x62\x75\x73\x20\x73\x65\x6e\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e"
);return ((0x1c47+ 2291-0x253a));}(my $commandPath=
Common::NXShellCommands::getDbusSendCommand ());(my $result=
__getAvailableSessionDbusCommands ($commandPath,$ref_commands));if (($result==
(0x06f2+ 263-0x07f9))){($result=__getAvailableSystemDbusCommands ($commandPath,
$ref_commands));}return ($result);}sub __runAvailableCommands{(my $ref_commands=
shift (@_));my (@options);(my $dbusAddress=getDbusAddress ());if (($dbusAddress 
ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x44\x42\x55\x53\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x42\x55\x53\x5f\x41\x44\x44\x52\x45\x53\x53\x3d"
.$dbusAddress));}(my $display=NXClientMonitor::getLocalDisplay ());if (($display
 ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x44\x49\x53\x50\x4c\x41\x59\x3d\x3a".$display));}push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x58\x44\x47\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x50\x41\x54\x48\x3d".
getXdgSessionPath ()));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x58\x44\x47\x5f\x53\x45\x53\x53\x49\x4f\x4e\x5f\x49\x44\x3d".getXdgSessionId 
()));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".
Common::NXPaths::getUserRealHomeDirectoryByEffectiveUser ()));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59\x3d".
__getXauthority ()));push (@options,"\x45\x52\x52\x69\x6e\x4f\x55\x54");my (
$stderr,$stdout,$exitValue);for ((my $i=(0x055b+ 6131-0x1d4e));($i<scalar (
@$ref_commands));(++$i)){(($stderr,$stdout,$exitValue)=main::nxRunCommand (
$$ref_commands[$i],(\@options)));if (($exitValue==(0x1284+ 660-0x1518))){last;}
else{if (($stdout=~ /org.freedesktop.DBus.Error.NoReply/i )){($exitValue=
(0x1af2+ 175-0x1ba1));last;}else{if (($stdout ne (""))){Logger::warning (((
"\x4c\x6f\x63\x6b\x20\x73\x63\x72\x65\x65\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27"
.$stdout)."\x27\x2e"));}else{Logger::warning (
"\x4c\x6f\x63\x6b\x20\x73\x63\x72\x65\x65\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x2e"
);}}}}return ((!$exitValue));}sub __parseListNamesOutput{(my $output=shift (@_))
;(my (@lines)=split ( /\n/ ,$output,(0x0032+ 5204-0x1486)));my (@result);foreach my $line
 (@lines){if (($line=~ /"(.*screensaver)"/i )){push (@result,$1);}elsif (($line
=~ /"(com.canonical.Unity)"/ )){push (@result,$1);}}return (@result);}sub 
__parseSystemListNamesOutput{(my $output=shift (@_));(my (@lines)=split ( /\n/ ,
$output,(0x133a+ 3389-0x2077)));my (@result);foreach my $line (@lines){if ((
$line=~ /"(.*DisplayManager)"/i )){push (@result,$1);}}return (@result);}sub 
__lockScreenWithLockerApp{my (@commands);(my $result=
__getAvailableLockerAppCommands ((\@commands)));if (($result!=
(0x1cc4+ 1975-0x247b))){($result=__runAvailableCommands ((\@commands)));}else{
Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x63\x61\x74\x65\x20\x61\x6e\x79\x20\x6f\x66\x20\x73\x63\x72\x65\x65\x6e\x20\x6c\x6f\x63\x6b\x65\x72\x20\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x73\x2e"
);}return ($result);}sub __getAvailableLockerAppCommands{(my $ref_commands=shift
 (@_));if ((not (isUnknownDE ()))){__getLockerCommandsByDE ($ref_commands,
getCurrentDE ());}__getGeneralLockerCommands ($ref_commands);if ((scalar (
@$ref_commands)==(0x0850+ 648-0x0ad8))){return ((0x01d8+ 2870-0x0d0e));}return (
(0x0d2a+ 5141-0x213e));}sub __getLockerCommandsByDE{(my $ref_commands=shift (@_)
);(my $desktopEnvironment=shift (@_));if (
NXCommands::isScreenLockCommandsExistByDE ($desktopEnvironment)){(my $commands=
NXCommands::getScreenLockCommandsByDE ($desktopEnvironment));for ((my $i=
(0x13e6+ 1267-0x18d9));($i<scalar (@$commands));(++$i)){(my $ref_current=
$$commands[$i]);(my (@current)=@$ref_current);($current[(0x088b+ 1764-0x0f6f)]=
NXCommands::check_path ($current[(0x062a+ 1438-0x0bc8)],
getApplicationPathEnvArray ()));if (($current[(0x05e0+ 3860-0x14f4)]ne (""))){
push (@$ref_commands,(\@current));}}}}sub __getGeneralLockerCommands{(my $ref_commands
=shift (@_));__getLockerCommandsByDE ($ref_commands,getUnknownDE ());}sub 
setLockScreenValue{($lockScreen=shift (@_));}sub isLockScreenEnabled{if ((
$lockScreen eq "\x31")){return ((0x1dc7+ 1280-0x22c6));}return (
(0x07c4+ 5210-0x1c1e));}sub isLockScreenDisabled{return ((!isLockScreenEnabled 
()));}sub setLogoutOnDisconnectValue{($logoutOnDisconnect=shift (@_));(
$logoutOnDisconnectTimeout=shift (@_));}sub isLogoutOnDisconnectEnabled{if ((
$logoutOnDisconnect eq "\x31")){return ((0x14ca+ 1699-0x1b6c));}return (
(0x0b4a+ 4537-0x1d03));}sub setLogoutWithTimeoutInitiated{Logger::debug (
"\x53\x74\x61\x72\x74\x20\x73\x74\x61\x72\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x74\x69\x6d\x65\x72\x2e"
);($logoutInitiated=(0x027f+ 8833-0x24ff));}sub unsetLogoutWithTimeoutInitiated{
Logger::debug (
"\x53\x74\x6f\x70\x20\x6c\x6f\x67\x6f\x75\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x74\x69\x6d\x65\x72\x2e"
);($logoutInitiated=(0x1e6d+ 2108-0x26a9));}sub isLogoutWithTimeoutInitiated{
return ($logoutInitiated);}sub setLogoutTime{($logoutTime=shift (@_));}sub 
getLogoutTime{return ($logoutTime);}sub getLogoutOnDisconnectTimeout{return (
$logoutOnDisconnectTimeout);}sub isLogoutOnDisconnectDisabled{return ((!
isLogoutOnDisconnectEnabled ()));}sub setLockScreenBeforeTerminateValue{(
$lockScreenBeforeTerminate=shift (@_));}sub setLockScreenBeforeTerminateDisabled
{($lockScreenBeforeTerminate="\x30");}sub isLockScreenBeforeTerminateEnabled{if 
(($lockScreenBeforeTerminate eq "\x31")){return ((0x0b0f+ 7098-0x26c8));}return 
((0x0f6a+ 1001-0x1353));}sub isLockScreenBeforeTerminateValueSet{if ((
$lockScreenBeforeTerminate ne (""))){return ((0x0307+ 5075-0x16d9));}return (
(0x0cf4+ 4551-0x1ebb));}sub setLogoutBeforeTerminateValue{(
$logoutBeforeTerminate=shift (@_));}sub setLogoutBeforeTerminateDisabled{(
$logoutBeforeTerminate="\x30");}sub isLogoutBeforeTerminateEnabled{if ((
$logoutBeforeTerminate eq "\x31")){return ((0x04df+ 6504-0x1e46));}return (
(0x1f11+ 511-0x2110));}sub isLogoutBeforeTerminateValueSet{if ((
$logoutBeforeTerminate ne (""))){return ((0x0d29+ 5976-0x2480));}return (
(0x01a6+ 3941-0x110b));}sub logoutOrLockScreenBeforeTerminateIfNeeded{if (((
isLogoutOnDisconnectDisabled ()and isLockScreenDisabled ())or isLoginWindowMode 
())){return;}if (isLogoutBeforeTerminateValueSet ()){if (
isLogoutBeforeTerminateEnabled ()){logout ();}return;}if (
isLockScreenBeforeTerminateValueSet ()){if (isLockScreenBeforeTerminateEnabled 
()){lockScreen ();}return;}if (Common::NXCore::isNxstdinClosed ()){Logger::debug
 (
"\x53\x54\x44\x49\x4e\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x6f\x73\x65\x64\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);return;}(my ($code,$result)=main::send_request_message (
$GLOBAL::MSG_ASK_IF_LOGOUT_OR_LOCK_NEEDED,
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x63\x61\x6c\x6c\x62\x61\x63\x6b\x49\x66\x4c\x6f\x67\x6f\x75\x74\x4f\x72\x4c\x6f\x63\x6b\x53\x63\x72\x65\x65\x6e\x4e\x65\x65\x64\x65\x64"
,(\&callbackIfLogoutOrLockScreenNeeded),$lockScreenAnswerTimeout,
$GLOBAL::SESSION_ID));if (($code!=(0x0fc2+ 3403-0x1d0d))){Logger::error (
"\x44\x69\x64\x20\x6e\x6f\x74\x20\x72\x65\x63\x65\x69\x76\x65\x20\x61\x6e\x73\x77\x65\x72\x20\x69\x66\x20\x77\x65\x20\x73\x68\x6f\x75\x6c\x64\x20\x6c\x6f\x67\x6f\x75\x74\x20\x6f\x72\x20\x6c\x6f\x63\x6b\x20\x73\x63\x72\x65\x65\x6e\x2e"
);}}sub callbackIfLogoutOrLockScreenNeeded{(my $self=shift (@_));(my $handleHash
=shift (@_));(my $readBuffer=shift (@_));(my $readBytes=shift (@_));(my $lock=
(0x02b3+ 6294-0x1b49));(my $logout=(0x1400+ 500-0x15f4));(my $finish=
(0x05eb+ 7805-0x2468));if (($readBuffer=~ /NX> $GLOBAL::MSG_LOGOUT_ON_DISCONNECT .*/ )
){($logout=(0x132c+ 1305-0x1844));($finish=(0x06fc+ 6092-0x1ec7));}elsif ((
$readBuffer=~ /NX> $GLOBAL::MSG_LOGOUT_BEFORE_TERMINATE value=(.*) / )){(my $value
=$1);if (($value eq "\x31")){($logout=(0x0551+ 8331-0x25db));}($finish=
(0x0af2+ 2949-0x1676));}elsif (($readBuffer=~ /NX> $GLOBAL::MSG_LOCK_AT_DISCONNECT .*/ )
){($lock=(0x16a0+ 4143-0x26ce));($finish=(0x1984+ 3008-0x2543));}elsif ((
$readBuffer=~ /NX> $GLOBAL::MSG_LOCK_BEFORE_TERMINATE value=(.*) / )){(my $value
=$1);if (($value eq "\x31")){($lock=(0x063c+ 5899-0x1d46));}($finish=
(0x0e6d+ 620-0x10d8));}else{return;}if (($logout==(0x18eb+ 3035-0x24c5))){logout
 ();}elsif (($lock==(0x11dd+ 829-0x1519))){lockScreen ();}if (($finish==
(0x06aa+ 6589-0x2066))){$self->removeHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($handleHash,(0x0f62+  12-0x0f6e),
(0x056d+ 7964-0x2489));}}sub getLocalSessionString{(my $refParameters=shift (@_)
);($displayOwner=Common::NXCore::getEffectiveUsername ());($desktopOwnerID=
Common::NXCore::userInfoGetUidByUsername ($displayOwner));(my $session=
main::urlencode ($desktopOwnerID));($session.=("\x3a".main::urlencode (
$displayOwner)));($session.=("\x3a".main::urlencode ($$refParameters{
"\x6c\x6f\x63\x61\x6c\x5f\x64\x69\x73\x70\x6c\x61\x79"})));($session.=("\x3a".
main::urlencode ("\x6c\x69\x6e\x75\x78")));($session.=("\x3a".main::urlencode (
"\x64\x65\x73\x6b\x74\x6f\x70")));($session.=("\x3a".main::urlencode (
"\x65\x6d\x70\x74\x79")));($session.=("\x3a".main::urlencode ($ $)));
 ($session
.=("\x3a".main::urlencode ($$refParameters{
"\x61\x75\x74\x68\x6f\x72\x69\x74\x79"})));($session.=("\x3a".main::urlencode (
$$refParameters{"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"})));($session.=(
"\x3a".main::urlencode ("\x65\x6d\x70\x74\x79")));($session.=("\x3a".
main::urlencode ($$refParameters{"\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67"}
)));($session.=("\x3a".main::urlencode ($$refParameters{"\x73\x65\x61\x74"})));(
$session.=("\x3a".main::urlencode ($$refParameters{
"\x4b\x52\x42\x54\x69\x63\x6b\x65\x74"})));($session.=("\x3a".main::urlencode (
$$refParameters{"\x53\x53\x48\x41\x75\x74\x68\x53\x6f\x63\x6b"})));($session.=(
"\x3a".main::urlencode ($ $)));
 ($session.="\x20");return ($session);}sub 
prepareParametersForQuick{(my $refParameters=shift (@_));(my $envDisplay=
libnxh::NXTransGetEnvironment ("\x44\x49\x53\x50\x4c\x41\x59"));if ((not ((
defined ($envDisplay)||($envDisplay eq ("")))))){Logger::error (
"\x70\x72\x65\x70\x61\x72\x65\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x46\x6f\x72\x51\x75\x69\x63\x6b\x3a\x20\x65\x6d\x70\x74\x79\x20\x44\x49\x53\x50\x4c\x41\x59\x20\x66\x72\x6f\x6d\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x2e"
);return ((-(0x136d+ 3162-0x1fc6)));}(my $display=__standarizeDisplay (
$envDisplay));if (((not (defined ($display)))or (not (($display=~ /^\d+$/ ))))){
Logger::error (((((
"\x70\x72\x65\x70\x61\x72\x65\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x46\x6f\x72\x51\x75\x69\x63\x6b\x3a\x20\x77\x72\x6f\x6e\x67\x20\x64\x69\x73\x70\x6c\x61\x79\x20\x27"
.$display).
"\x27\x20\x66\x72\x6f\x6d\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x20\x27"
).$envDisplay)."\x27\x2e"));return ((-(0x1d93+ 374-0x1f08)));}(my $envXauthority
=libnxh::NXTransGetEnvironment ("\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59"));if 
((not ((defined ($envXauthority)||($envXauthority eq ("")))))){Logger::error (
"\x70\x72\x65\x70\x61\x72\x65\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x46\x6f\x72\x51\x75\x69\x63\x6b\x3a\x20\x65\x6d\x70\x74\x79\x20\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59\x20\x66\x72\x6f\x6d\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x2e"
);return ((-(0x0b6f+ 2753-0x162f)));}(my ($cookie,$wmRunning)=
__getCookieAndWMRunningFromAuthority ($envXauthority,$display));if (($cookie eq 
(""))){Logger::error (((
"\x70\x72\x65\x70\x61\x72\x65\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x46\x6f\x72\x51\x75\x69\x63\x6b\x3a\x20\x77\x72\x6f\x6e\x67\x20\x63\x6f\x6f\x6b\x69\x65\x20\x66\x72\x6f\x6d\x20\x61\x75\x74\x68\x6f\x72\x69\x74\x79\x20\x66\x69\x6c\x65\x20\x27"
.$envXauthority)."\x27\x2e"));return ((-(0x0f16+ 1982-0x16d3)));}(
$$refParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}=main::get_unique_id ());
($$refParameters{"\x70\x72\x69\x6f\x72\x69\x74\x79"}=
"\x72\x65\x61\x6c\x74\x69\x6d\x65");($$refParameters{
"\x6c\x6f\x63\x61\x6c\x5f\x64\x69\x73\x70\x6c\x61\x79"}=$display);(
$$refParameters{"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"}=$cookie);(
$$refParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"}=
Common::NXSessionType::getPhysicalDesktop ());($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x50\x69\x64"}=$ $);
 ($$refParameters{
"\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67"}=$wmRunning);($$refParameters{
"\x61\x75\x74\x68\x6f\x72\x69\x74\x79"}=$envXauthority);($$refParameters{
"\x53\x53\x48\x41\x75\x74\x68\x53\x6f\x63\x6b"}="\x65\x6d\x70\x74\x79");(my $envKRBTicket
=libnxh::NXTransGetEnvironment ("\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45"));if 
(($envKRBTicket ne (""))){($$refParameters{
"\x4b\x52\x42\x54\x69\x63\x6b\x65\x74"}=$envKRBTicket);}else{($$refParameters{
"\x4b\x52\x42\x54\x69\x63\x6b\x65\x74"}="\x65\x6d\x70\x74\x79");}(my $envSeat=
libnxh::NXTransGetEnvironment ("\x58\x44\x47\x5f\x53\x45\x41\x54"));if ((
$envSeat ne (""))){($$refParameters{"\x73\x65\x61\x74"}=$envSeat);}else{(
$$refParameters{"\x73\x65\x61\x74"}="\x65\x6d\x70\x74\x79");}}sub 
__standarizeDisplay{(my $display=shift (@_));if (($display=~ /.*?(\d+)/ )){(
$display=$1);}elsif (($display=~ /.*?(\d+).(\d+)/ )){($display=$1);}return (
$display);}sub __getCookieAndWMRunningFromAuthority{(my $authority=shift (@_));(my $display
=shift (@_));(my $cookie="\x65\x6d\x70\x74\x79");(my $wmRunning=
Common::NXCore::isWMRunningByDisplay (("\x3a".$display)));if (($wmRunning==(-
(0x0790+ 175-0x083e)))){($cookie=(""));}else{($cookie=
__extractCookieFromAuthorityFile ());}return ($cookie,$wmRunning);}sub 
__extractCookieFromAuthorityFile{(my $authorityFile=shift (@_));(my $display=
shift (@_));(my (@xauthPath)=Common::NXShellCommands::getCommand (
"\x78\x61\x75\x74\x68"));(my $count=@xauthPath);(my $cookie=
"\x65\x6d\x70\x74\x79");if (($count!=(0x0695+ 4099-0x1697))){Logger::error (
"\x6c\x6f\x63\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20\x78\x61\x75\x74\x68\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x73\x74\x61\x6e\x64\x61\x72\x64\x20\x70\x61\x74\x68\x73\x2e\x20\x43\x6f\x6e\x74\x61\x63\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
);return ((""));}(my $invalidCharactersDetected=
__checkIfCookieFilePathContainsInvalidCharacters ($authorityFile));my (
$cookieFileLink);if ($invalidCharactersDetected){($cookieFileLink=
__createLinkToAuthorityFileAndReturnPath ($authorityFile));if (($cookieFileLink 
ne (""))){($authorityFile=$cookieFileLink);}else{Logger::error (((
"\x6c\x6f\x63\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20\x63\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6c\x69\x6e\x6b\x20\x74\x6f\x20\x27"
.$authorityFile)."\x27\x2e"));return ((""));}}(my (@command)=(@xauthPath,
"\x6c\x69\x73\x74"));(my (@parameters)=(
"\x6e\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x6f\x75\x74",
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c",
"\x66\x75\x6c\x6c\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74"));(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if ($invalidCharactersDetected){Common::NXFile::removeFile ($cookieFileLink);}
chomp ($cmd_out);(my (@xauthLines)=split ( /\n/ ,$cmd_out,(0x06fa+ 2607-0x1129))
);if (($exit_value>(0x177b+ 1777-0x1e6c))){Logger::error (((
"\x6c\x6f\x63\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20\x78\x61\x75\x74\x68\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.join ($",@command))."\x27\x20\x66\x61\x69\x6c\x65\x64\x2e"));return ((""));}
foreach my $item (@xauthLines){($cookie=(""));if (($item=~ /:\d+\s+MIT-MAGIC-COOKIE-1\s+(\w{32})/ )
){($cookie=$1);}elsif (($item=~ /:\s+MIT-MAGIC-COOKIE-1\s+(\w{32})/ )){($cookie=
$1);}return ($cookie);}return ((""));}sub 
__checkIfCookieFilePathContainsInvalidCharacters{(my $authority=shift (@_));if (
(($authority=~ /{/ )or ($authority=~ /}/ ))){return ((0x0991+ 2873-0x14c9));}
else{return ((0x0ea8+ 6183-0x26cf));}}sub 
__createLinkToAuthorityFileAndReturnPath{(my $authority=shift (@_));(my $newAuthority
=((Common::NXPaths::getSystemTMPPath ().$GLOBAL::DIRECTORY_SLASH).
"\x74\x6d\x70\x41\x75\x74\x68\x6f\x72\x69\x74\x79\x43\x6f\x6f\x6b\x69\x65\x4c\x69\x6e\x6b"
));if ((Common::NXFile::fileExists ($newAuthority)or-l ($newAuthority))){if ((
not (Common::NXFile::removeFile ($newAuthority)))){return ((""));}}if (symlink (
$authority,$newAuthority)){return ($newAuthority);}else{Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x73\x79\x6d\x62\x6f\x6c\x69\x63\x20\x6c\x69\x6e\x6b\x20\x27"
.$newAuthority)."\x27\x20\x66\x6f\x72\x20\x27").$authority).
"\x27\x20\x66\x69\x6c\x65\x3a\x20").$!));}return ((""));}sub 
showWarningPopupForAdmin{(my $error=shift (@_));if ((
Common::NXCore::isCurrentUserSystemAdmin ()==(0x13f4+ 4699-0x264e))){
Logger::debug (
"\x53\x68\x6f\x77\x20\x70\x6f\x70\x75\x70\x20\x77\x69\x6e\x64\x6f\x77\x20\x74\x6f\x20\x61\x64\x6d\x69\x6e\x20\x75\x73\x65\x72\x2e"
);(my (@commandNXClient)=());(my $display=Agent::getPhysicalXserverDisplay ());(my $message
=(
"\x54\x68\x65\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x77\x69\x74\x68\x20\x74\x68\x65\x20\x66\x6f\x6c\x6c\x6f\x77\x69\x6e\x67\x20\x65\x72\x72\x6f\x72\x3a\x0a\x0a"
.$error));push (@commandNXClient,main::shell_quote ($GLOBAL::CommandClient,
"\x2d\x64\x69\x61\x6c\x6f\x67","\x6f\x6b","\x2d\x63\x61\x70\x74\x69\x6f\x6e",
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x53\x65\x72\x76\x65\x72\x20\x4e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e"
,"\x2d\x6d\x65\x73\x73\x61\x67\x65",$message,"\x2d\x63\x6c\x61\x73\x73",
"\x61\x6c\x65\x72\x74","\x2d\x64\x69\x73\x70\x6c\x61\x79",("\x3a".$display)));(my (
@command)=());push (@command,$GLOBAL::CommandBash,"\x2d\x63",main::shell_quote (
"\x65\x78\x65\x63","\x2d\x61","\x2d",Common::NXCore::getEffectiveShell (),
"\x2d\x63",join ($",@commandNXClient)));(my (@parameters)=());push (@parameters,
"\x74\x69\x6d\x65\x6f\x75\x74","\x69\x6e\x66");push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59\x3d".
Common::NXPaths::getUserXauthorityFile ()));main::run_command ((\@command),(
\@parameters));}}"\x3f\x3f\x3f";
