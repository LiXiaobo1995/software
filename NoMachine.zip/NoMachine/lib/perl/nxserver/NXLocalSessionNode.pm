############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXLocalSessionNode::new{package NXLocalSessionNode;no warnings;(my (%hash)=
());(my $self=(\%hash));bless ($self);$self->__init;return ($self);}sub 
NXLocalSessionNode::createForeign{package NXLocalSessionNode;no warnings;(my $foreignNodeHost
=shift (@_));(my $foreignNodePort=shift (@_));(my $foreignNodeUuid=shift (@_));(my $node
=new ());$node->setHost ($foreignNodeHost);$node->setPort ($foreignNodePort);
$node->setUuid ($foreignNodeUuid);$node->setLocalDesktopType (
NXLocalSession::getLocalSessionTypeForeign ());$node->setForeignNode;(my $sessionId
=main::get_unique_id ());$node->setSessionId ($sessionId);return ($node);}sub 
NXLocalSessionNode::__init{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));($$self{"\x6e\x6f\x64\x65\x50\x69\x64"}=(-(0x183d+ 364-0x19a8)));(
$$self{"\x73\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65"}=
"\x65\x6d\x70\x74\x79");($$self{"\x6e\x6f\x64\x65\x50\x6f\x72\x74"}=(-
(0x056d+ 4207-0x15db)));($$self{"\x6e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74"}=(-
(0x0ad3+ 6694-0x24f8)));(%self->{"\x61\x74\x74\x61\x63\x68\x65\x64"}={});($$self
{"\x73\x74\x64\x69\x6e"}=(-(0x0260+ 6281-0x1ae8)));($$self{
"\x73\x74\x64\x6f\x75\x74"}=(-(0x03b7+ 1074-0x07e8)));($$self{
"\x44\x42\x75\x73\x4f\x62\x6a\x65\x63\x74"}=(""));($$self{
"\x53\x65\x61\x74\x4f\x62\x6a\x65\x63\x74"}=(""));($$self{
"\x73\x65\x74\x54\x6f\x52\x65\x6d\x6f\x76\x65"}=(0x0d1d+ 4341-0x1e12));($$self{
"\x66\x6f\x72\x65\x69\x67\x6e\x4e\x6f\x64\x65"}=(0x1465+ 2219-0x1d10));($$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x46\x69\x6c\x65\x48\x61\x6e\x64\x6c\x65\x64"}=
(0x1ad0+ 2492-0x248c));($$self{
"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x54\x69\x6d\x65"}=
(0x04f7+ 1362-0x0a49));($$self{
"\x6e\x6f\x64\x65\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x54\x69\x6d\x65"}=
(0x0053+ 6724-0x1a97));($$self{"\x53\x65\x73\x73\x69\x6f\x6e\x50\x69\x64"}=
(0x0089+ 5554-0x163b));($$self{
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x53\x65\x6e\x74"}=(0x0936+ 6890-0x2420));(
$$self{"\x53\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65\x46\x69\x6c\x65"}=
"\x65\x6d\x70\x74\x79");($$self{
"\x6c\x6f\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x54\x79\x70\x65"}=(""));(
$$self{
"\x6e\x6f\x64\x65\x53\x74\x61\x72\x74\x65\x64\x42\x79\x44\x61\x65\x6d\x6f\x6e"}=
(0x2148+ 163-0x21eb));($$self{
"\x69\x64\x4f\x66\x53\x65\x73\x73\x69\x6f\x6e\x42\x65\x66\x6f\x72\x65\x53\x77\x69\x74\x63\x68"
}=(""));($$self{"\x73\x68\x65\x6c\x6c\x4d\x6f\x64\x65"}=(0x02fc+ 779-0x0607));(
$$self{"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x64"}=(0x0116+ 3099-0x0d31));(
$$self{
"\x63\x6c\x65\x61\x6e\x69\x6e\x67\x4e\x6f\x74\x52\x65\x71\x75\x69\x72\x65\x64"}=
(0x02f3+ 1857-0x0a34));($$self{
"\x61\x67\x65\x6e\x74\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"}=
(0x0c3a+ 743-0x0f21));($$self{
"\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x42\x65\x66\x6f\x72\x65\x53\x77\x69\x74\x63\x68"
}=(0x000a+ 8195-0x200d));($$self{"\x65\x72\x72\x6f\x72\x53\x65\x6e\x74"}=
(0x06c5+ 3803-0x15a0));}sub NXLocalSessionNode::terminate{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));if ($self->
checkIsItTimeToKill){$self->killNodeProcess;}else{$self->
logoutOrLockScreenIfNeeded;$self->sendTerminateMessage;}}sub 
NXLocalSessionNode::getTerminateMessage{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));my ($message);if ($self->isShellMode){($message=
"\x71\x75\x69\x74\x0a\x0a");}else{($message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NODE_TERMINATE_ON_REQUEST)."\x20").$GLOBAL::MESSAGES_FORMAT{
$GLOBAL::MSG_NODE_TERMINATE_ON_REQUEST})."\x0a"));}return ($message);}sub 
NXLocalSessionNode::sendTerminateMessage{package NXLocalSessionNode;no warnings;
(my $self=shift (@_));if ((not ($self->terminateWasSent))){(my $message=$self->
getTerminateMessage);if (($self->sendMessage ($message)!=(-(0x041c+ 6155-0x1c26)
))){$self->setTerminateSent;}else{$self->killNodeProcess;}}}sub 
NXLocalSessionNode::terminateNodeProcess{package NXLocalSessionNode;no warnings;
(my $self=shift (@_));(my $pid=$$self{"\x6e\x6f\x64\x65\x50\x69\x64"});(my $signal
=Common::NXProcess::getSignalTerm ());if (Common::NXProcess::isProcessRunning (
$pid)){Logger::warning (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));NXNodeExec::nodeProcessKill ($pid,$signal);}}sub 
NXLocalSessionNode::killNodeProcess{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $pid=$$self{"\x6e\x6f\x64\x65\x50\x69\x64"});if (
Common::NXProcess::isProcessRunning ($pid)){Logger::warning (((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));NXNodeExec::nodeProcessKill ($pid);}}sub 
NXLocalSessionNode::sendMessage{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $message=shift (@_));if (($$self{
"\x6e\x6f\x64\x65\x53\x74\x61\x72\x74\x65\x64\x42\x79\x44\x61\x65\x6d\x6f\x6e"}
==(0x0b8a+ 2274-0x146b))){($nodeSocket=$$self{"\x73\x74\x64\x69\x6e"});}else{(
$nodeSocket=$$self{"\x6e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74"});}Logger::debug (
((((
"\x57\x72\x69\x74\x65\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x27"
.$message)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$nodeSocket)."\x2e"));return (
main::nxwrite ($nodeSocket,$message));}sub NXLocalSessionNode::turnMonitorOn{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));Logger::debug3 (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self)."\x27\x20\x74\x75\x72\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x4f\x6e\x2e"));if 
($self->isMonitorOn){return;}if ($self->isDesktopSession){(my $sessionType=
Common::NXSessionType::getPhysicalDesktop ());Server::sendMonitorOnMessage (
$self->getSocket,$self->getSessionOwner,$self->getUuid,$self->
getLocalDesktopType,$sessionType);}$self->setMonitorStarted;}sub 
NXLocalSessionNode::isDesktopSession{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));if (NXLocalSession::isLocalSessionTypeDesktop ($self->
getLocalDesktopType)){return ((0x0406+ 4643-0x1628));}return (
(0x16a9+ 4011-0x2654));}sub NXLocalSessionNode::turnMonitorOff{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));if ($self->isMonitorOn){
$self->__sendMonitorOffMessage;$self->setMonitorStopped;}else{Logger::debug2 (
"\x4d\x6f\x6e\x69\x74\x6f\x72\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
);}return ((0x10ec+ 895-0x146a));}sub 
NXLocalSessionNode::__sendMonitorOffMessage{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));Logger::debug2 (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x73\x74\x6f\x70\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);(my $message=(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_CLOSE_MONITOR)."\x20\x20").
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_CLOSE_MONITOR})."\x0a"));(my $bytesSent=
$self->sendMessage ($message));if (($bytesSent==(-(0x0b5b+ 5819-0x2215)))){
Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"));}else{Logger::debug2 (((
"\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$message).
"\x27\x20\x77\x61\x73\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"))
;}}sub NXLocalSessionNode::setPort{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $port=shift (@_));($$self{"\x6e\x6f\x64\x65\x50\x6f\x72\x74"}=
$port);}sub NXLocalSessionNode::setCookie{package NXLocalSessionNode;no warnings
;(my $self=shift (@_));(my $cookie=shift (@_));($$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65"}=$cookie);}sub 
NXLocalSessionNode::setPid{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $pid=shift (@_));($$self{"\x6e\x6f\x64\x65\x50\x69\x64"}=$pid);}
sub NXLocalSessionNode::setSocket{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $sock=shift (@_));($$self{
"\x6e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74"}=$sock);}sub 
NXLocalSessionNode::setDisplay{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $display=shift (@_));($$self{"\x64\x69\x73\x70\x6c\x61\x79"}=
$display);}sub NXLocalSessionNode::cleanAttachedList{package NXLocalSessionNode;
no warnings;(my $self=shift (@_));($$self{"\x61\x74\x74\x61\x63\x68\x65\x64"}=()
);Logger::debug3 (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x63\x6c\x65\x61\x6e\x41\x74\x74\x61\x63\x68\x65\x64\x4c\x69\x73\x74\x2e"
));}sub NXLocalSessionNode::setAttachedList{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));(my $attached=shift (@_));(my (%hash)=%$attached)
;Logger::debug3 (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x73\x65\x74\x41\x74\x74\x61\x63\x68\x65\x64\x4c\x69\x73\x74\x2e"));
$self->cleanAttachedList;foreach my $ses (keys (%hash)){(my (%key)=%{$hash{$ses}
;});foreach my $value (keys (%key)){($$self{"\x61\x74\x74\x61\x63\x68\x65\x64"}{
$ses}{$value}=$hash{$ses}{$value});}}}sub NXLocalSessionNode::removeAttached{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $attached_id=
shift (@_));Logger::debug3 (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x72\x65\x6d\x6f\x76\x65\x41\x74\x74\x61\x63\x68\x65\x64\x20\x27").
$attached_id)."\x27\x2e"));($$self{"\x61\x74\x74\x61\x63\x68\x65\x64"}{
$attached_id}=undef);delete ($$self{"\x61\x74\x74\x61\x63\x68\x65\x64"}{
$attached_id});}sub NXLocalSessionNode::setLocalDesktopType{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x6c\x6f\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x54\x79\x70\x65"}=shift (@_));
}sub NXLocalSessionNode::getLocalDesktopType{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));return ($$self{
"\x6c\x6f\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x54\x79\x70\x65"});}sub 
NXLocalSessionNode::setHost{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $host=shift (@_));($$self{"\x6e\x6f\x64\x65\x48\x6f\x73\x74"}=
$host);}sub NXLocalSessionNode::setParameters{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));(my $parameters=shift (@_));($$self{
"\x6e\x6f\x64\x65\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"}=$parameters);}sub 
NXLocalSessionNode::setRestartCounter{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $restartCounter=shift (@_));($$self{
"\x6e\x6f\x64\x65\x52\x65\x73\x74\x61\x72\x74\x43\x6f\x75\x6e\x74\x65\x72"}=
$restartCounter);}sub NXLocalSessionNode::setMonitorStarted{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x6d\x6f\x6e\x69\x74\x6f\x72\x53\x74\x61\x72\x74\x65\x64"}=
(0x0b71+ 1067-0x0f9b));}sub NXLocalSessionNode::setMonitorStopped{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x6d\x6f\x6e\x69\x74\x6f\x72\x53\x74\x61\x72\x74\x65\x64"}=
(0x0b16+ 5293-0x1fc3));}sub NXLocalSessionNode::isMonitorOn{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $isMonitorStarted=
$$self{"\x6d\x6f\x6e\x69\x74\x6f\x72\x53\x74\x61\x72\x74\x65\x64"});return (
$isMonitorStarted);}sub NXLocalSessionNode::isForeignNode{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));if (($$self{
"\x66\x6f\x72\x65\x69\x67\x6e\x4e\x6f\x64\x65"}==(0x0a2b+ 1194-0x0ed4))){return 
((0x05a8+ 3970-0x1529));}return (NXNodes::isForeignNode ($self->getUuid));}sub 
NXLocalSessionNode::getAttachedList{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $list=$$self{"\x61\x74\x74\x61\x63\x68\x65\x64"});
Logger::debug3 (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x67\x65\x74\x41\x74\x74\x61\x63\x68\x65\x64\x4c\x69\x73\x74\x20\x27").
$list)."\x27\x2e"));(my (%attached)=%{$list;});return (%attached);}sub 
NXLocalSessionNode::getAttachedCount{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my (%attached)=$self->getAttachedList);(my $count=scalar (keys (
%attached)));Logger::debug3 (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x67\x65\x74\x41\x74\x74\x61\x63\x68\x65\x64\x43\x6f\x75\x6e\x74\x20\x27"
).$count)."\x27\x2e"));return ($count);}sub 
NXLocalSessionNode::changeAttachedListAfterCrash{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));(my (%hash)=%{$$self{
"\x61\x74\x74\x61\x63\x68\x65\x64"};});Logger::debug3 (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x63\x68\x61\x6e\x67\x65\x41\x74\x74\x61\x63\x68\x65\x64\x4c\x69\x73\x74\x41\x66\x74\x65\x72\x43\x72\x61\x73\x68\x2e"
));foreach my $ses (keys (%hash)){($hash{$ses}{"\x63\x72\x61\x73\x68"}=
(0x0870+ 6221-0x20bc));}}sub NXLocalSessionNode::updateOwnerInAttachedList{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $owner=shift (
@_));(my (%hash)=%{$$self{"\x61\x74\x74\x61\x63\x68\x65\x64"};});Logger::debug3 
(((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self).
"\x27\x20\x75\x70\x64\x61\x74\x65\x4f\x77\x6e\x65\x72\x49\x6e\x41\x74\x74\x61\x63\x68\x65\x64\x4c\x69\x73\x74\x20\x27"
).$owner)."\x27\x2e"));foreach my $session (keys (%hash)){(my (%key)=%{$hash{
$ses};});($$self{"\x61\x74\x74\x61\x63\x68\x65\x64"}{$session}{
"\x6f\x77\x6e\x65\x72"}=$owner);}}sub NXLocalSessionNode::getDisplay{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $display=$$self{
"\x64\x69\x73\x70\x6c\x61\x79"});return ($display);}sub 
NXLocalSessionNode::getPort{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $port=$$self{"\x6e\x6f\x64\x65\x50\x6f\x72\x74"});return ($port)
;}sub NXLocalSessionNode::getCookie{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $cookie=$$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65"});return ($cookie);}sub 
NXLocalSessionNode::getPid{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $pid=$$self{"\x6e\x6f\x64\x65\x50\x69\x64"});return ($pid);}sub 
NXLocalSessionNode::getNXExecPid{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $pid=$$self{"\x6e\x78\x65\x78\x65\x63\x50\x69\x64"});return (
$pid);}sub NXLocalSessionNode::getSocket{package NXLocalSessionNode;no warnings;
(my $self=shift (@_));if (($$self{
"\x6e\x6f\x64\x65\x53\x74\x61\x72\x74\x65\x64\x42\x79\x44\x61\x65\x6d\x6f\x6e"}
==(0x0c5a+ 6774-0x26cf))){Logger::debug3 (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self)."\x27\x20\x67\x65\x74\x53\x6f\x63\x6b\x65\x74\x20\x27").$$self{
"\x73\x74\x64\x69\x6e"})."\x27\x2e"));return ($$self{"\x73\x74\x64\x69\x6e"});}
Logger::debug3 (((((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x20\x27"
.$self)."\x27\x20\x67\x65\x74\x53\x6f\x63\x6b\x65\x74\x20\x27").$$self{
"\x6e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74"})."\x27\x2e"));return ($$self{
"\x6e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74"});}sub NXLocalSessionNode::getHost{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $host=$$self{
"\x6e\x6f\x64\x65\x48\x6f\x73\x74"});return ($host);}sub 
NXLocalSessionNode::getName{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $host=$$self{"\x6e\x6f\x64\x65\x48\x6f\x73\x74"});(my $port=
$$self{"\x6e\x6f\x64\x65\x50\x6f\x72\x74"});return ((($host."\x3a").$port));}sub
 NXLocalSessionNode::getParameters{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $parameters=$$self{
"\x6e\x6f\x64\x65\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});return ($parameters
);}sub NXLocalSessionNode::getRestartCounter{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));(my $restartCounter=$$self{
"\x6e\x6f\x64\x65\x52\x65\x73\x74\x61\x72\x74\x43\x6f\x75\x6e\x74\x65\x72"});
return ($restartCounter);}sub NXLocalSessionNode::getNXWmRunning{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $savedNXWmRunning=
$$self{"\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67"});return (
$savedNXWmRunning);}sub NXLocalSessionNode::getSessionId{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x53\x65\x73\x73\x69\x6f\x6e\x49\x64"});}sub NXLocalSessionNode::setSessionId{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x53\x65\x73\x73\x69\x6f\x6e\x49\x64"}=shift (@_));}sub 
NXLocalSessionNode::setSessionOwner{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x53\x65\x73\x73\x69\x6f\x6e\x4f\x77\x6e\x65\x72"}=shift (
@_));}sub NXLocalSessionNode::getSessionOwner{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));return ($$self{
"\x53\x65\x73\x73\x69\x6f\x6e\x4f\x77\x6e\x65\x72"});}sub 
NXLocalSessionNode::setNXWmRunning{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67"}=shift (@_))
;}sub NXLocalSessionNode::isRunning{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $active=$$self{
"\x6e\x6f\x64\x65\x49\x73\x52\x75\x6e\x6e\x69\x6e\x67"});return ($active);}sub 
NXLocalSessionNode::setRunning{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));($$self{"\x6e\x6f\x64\x65\x49\x73\x52\x75\x6e\x6e\x69\x6e\x67"}=
(0x131b+ 427-0x14c5));}sub NXLocalSessionNode::setNotRunning{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x6e\x6f\x64\x65\x49\x73\x52\x75\x6e\x6e\x69\x6e\x67"}=(0x2472+ 446-0x2630));}
sub NXLocalSessionNode::isActive{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $active=$$self{
"\x6e\x6f\x64\x65\x49\x73\x41\x63\x74\x69\x76\x65"});return ($active);}sub 
NXLocalSessionNode::setActive{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));($$self{"\x6e\x6f\x64\x65\x49\x73\x41\x63\x74\x69\x76\x65"}=
(0x1914+ 2850-0x2435));}sub NXLocalSessionNode::setInactive{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x6e\x6f\x64\x65\x49\x73\x41\x63\x74\x69\x76\x65"}=(0x16b1+ 3473-0x2442));}sub 
NXLocalSessionNode::setToRemove{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x73\x65\x74\x54\x6f\x52\x65\x6d\x6f\x76\x65"}=
(0x0a94+ 2043-0x128e));if (($self->isForeignNode==(0x1550+ 3003-0x210b))){$self
->setRemoveTime ($GLOBAL::timeoutForWaitingForUserSwitch);}else{$self->
setRemoveTime ($GLOBAL::timeoutForRestartingForeignNode);}}sub 
NXLocalSessionNode::isSetToRemove{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $remove=$$self{"\x73\x65\x74\x54\x6f\x52\x65\x6d\x6f\x76\x65"})
;return ($remove);}sub NXLocalSessionNode::setStdin{package NXLocalSessionNode;
no warnings;(my $self=shift (@_));($$self{"\x73\x74\x64\x69\x6e"}=shift (@_));}
sub NXLocalSessionNode::getStdin{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x73\x74\x64\x69\x6e"});}sub 
NXLocalSessionNode::setStdout{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));($$self{"\x73\x74\x64\x6f\x75\x74"}=shift (@_));}sub 
NXLocalSessionNode::getStdout{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));return ($$self{"\x73\x74\x64\x6f\x75\x74"});}sub 
NXLocalSessionNode::setDBusObject{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x44\x42\x75\x73\x4f\x62\x6a\x65\x63\x74"}=shift (@_));}
sub NXLocalSessionNode::getDBusObject{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x44\x42\x75\x73\x4f\x62\x6a\x65\x63\x74"});}sub 
NXLocalSessionNode::setSeatObject{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x53\x65\x61\x74\x4f\x62\x6a\x65\x63\x74"}=shift (@_));}
sub NXLocalSessionNode::getSeatObject{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x53\x65\x61\x74\x4f\x62\x6a\x65\x63\x74"});}sub 
NXLocalSessionNode::setForeignNode{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x66\x6f\x72\x65\x69\x67\x6e\x4e\x6f\x64\x65"}=
(0x046f+ 6208-0x1cae));}sub NXLocalSessionNode::setSessionFileHandled{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x46\x69\x6c\x65\x48\x61\x6e\x64\x6c\x65\x64"}=
(0x0876+ 2419-0x11e8));}sub NXLocalSessionNode::isSessionFileHandled{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x46\x69\x6c\x65\x48\x61\x6e\x64\x6c\x65\x64"});}
sub NXLocalSessionNode::setRemoveTime{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $time=shift (@_));if (($$self{
"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x54\x69\x6d\x65"}!=
(0x08ea+ 5320-0x1db2))){return ((0x03ac+ 7406-0x209a));}($$self{
"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x54\x69\x6d\x65"}=($time+
Common::NXTime::getSecondsSinceEpoch ()));}sub 
NXLocalSessionNode::setRemoveTimeNow{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x54\x69\x6d\x65"}
=Common::NXTime::getSecondsSinceEpoch ());}sub 
NXLocalSessionNode::checkIsItTimeToRemove{package NXLocalSessionNode;no warnings
;(my $self=shift (@_));(my $time=Common::NXTime::getSecondsSinceEpoch ());if (((
$time>=$$self{"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x54\x69\x6d\x65"})and (
$$self{"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x54\x69\x6d\x65"}>
(0x09e5+ 6893-0x24d2)))){return ((0x17cf+ 3230-0x246c));}else{return (
(0x153c+ 1362-0x1a8e));}}sub NXLocalSessionNode::setTimeoutForTerminate{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $timeout=shift (@_));if
 (($$self{"\x6e\x6f\x64\x65\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x54\x69\x6d\x65"
}!=(0x0397+ 3424-0x10f7))){return ((0x14e4+ 1933-0x1c71));}Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x64\x65\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x27"
.$timeout)."\x27\x2e"));(my $time=Common::NXTime::getSecondsSinceEpoch ());(
$$self{"\x6e\x6f\x64\x65\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x54\x69\x6d\x65"}=(
$time+$timeout));}sub NXLocalSessionNode::checkIsItTimeToKill{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $time=
Common::NXTime::getSecondsSinceEpoch ());if ((($time>=$$self{
"\x6e\x6f\x64\x65\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x54\x69\x6d\x65"})and (
$$self{"\x6e\x6f\x64\x65\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x54\x69\x6d\x65"}>
(0x173a+ 2474-0x20e4)))){return ((0x012c+ 6893-0x1c18));}else{return (
(0x0e79+ 3635-0x1cac));}}sub NXLocalSessionNode::getTerminateTime{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x6e\x6f\x64\x65\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x54\x69\x6d\x65"});}sub 
NXLocalSessionNode::setSessionPid{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x53\x65\x73\x73\x69\x6f\x6e\x50\x69\x64"}=shift (@_));}
sub NXLocalSessionNode::getSessionPid{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x53\x65\x73\x73\x69\x6f\x6e\x50\x69\x64"});}sub 
NXLocalSessionNode::setSessionCookieFile{package NXLocalSessionNode;no warnings;
(my $self=shift (@_));($$self{
"\x53\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65\x46\x69\x6c\x65"}=shift (
@_));}sub NXLocalSessionNode::getSessionCookieFile{package NXLocalSessionNode;no
 warnings;(my $self=shift (@_));return ($$self{
"\x53\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65\x46\x69\x6c\x65"});}sub 
NXLocalSessionNode::setTerminateSent{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $timeout=$GLOBAL::timeoutForLocalSessionTerminate);if (
NXSystemDaemons::isShutdownFlag ()){($timeout=
$GLOBAL::TimeoutForShutdownTerminate);}$self->setTimeoutForTerminate ($timeout);
($$self{"\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x53\x65\x6e\x74"}=
(0x025f+ 3185-0x0ecf));}sub NXLocalSessionNode::terminateWasSent{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x53\x65\x6e\x74"});}sub 
NXLocalSessionNode::setNodeDisplay{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $nodeDisplay=shift (@_));($$self{
"\x6e\x6f\x64\x65\x44\x69\x73\x70\x6c\x61\x79"}=$nodeDisplay);}sub 
NXLocalSessionNode::getNodeDisplay{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x6e\x6f\x64\x65\x44\x69\x73\x70\x6c\x61\x79"});}
sub NXLocalSessionNode::setNodeStartedByDaemon{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));($$self{
"\x6e\x6f\x64\x65\x53\x74\x61\x72\x74\x65\x64\x42\x79\x44\x61\x65\x6d\x6f\x6e"}=
(0x07a0+ 4731-0x1a1a));}sub NXLocalSessionNode::isNodeStartedByDaemon{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));if (($$self{
"\x6e\x6f\x64\x65\x53\x74\x61\x72\x74\x65\x64\x42\x79\x44\x61\x65\x6d\x6f\x6e"}
==(0x0343+ 7944-0x224a))){return ((0x0b9f+ 3657-0x19e7));}return (
(0x121b+ 804-0x153f));}sub NXLocalSessionNode::setIdOfSessionBeforeSwitch{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $sessionId=
shift (@_));($$self{
"\x69\x64\x4f\x66\x53\x65\x73\x73\x69\x6f\x6e\x42\x65\x66\x6f\x72\x65\x53\x77\x69\x74\x63\x68"
}=$sessionId);}sub NXLocalSessionNode::getIdOfSessionBeforeSwitch{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x69\x64\x4f\x66\x53\x65\x73\x73\x69\x6f\x6e\x42\x65\x66\x6f\x72\x65\x53\x77\x69\x74\x63\x68"
});}sub NXLocalSessionNode::isShellMode{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x73\x68\x65\x6c\x6c\x4d\x6f\x64\x65"});}sub 
NXLocalSessionNode::setShellMode{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x73\x68\x65\x6c\x6c\x4d\x6f\x64\x65"}=
(0x013d+ 7760-0x1f8c));}sub NXLocalSessionNode::setShellModeFinished{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x73\x68\x65\x6c\x6c\x4d\x6f\x64\x65"}=(0x0624+ 623-0x0893));}sub 
NXLocalSessionNode::setNodeRemoved{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x64"}=
(0x0839+ 5579-0x1e03));}sub NXLocalSessionNode::isNodeRemoved{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x6e\x6f\x64\x65\x52\x65\x6d\x6f\x76\x65\x64"});}sub 
NXLocalSessionNode::getForeignParametersString{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));(my $foreignNodeHost=$self->getHost);(my $foreignNodePort
=$self->getPort);(my $uuid=$self->getUuid);(my $parameters=(
"\x61\x67\x65\x6e\x74\x5f\x73\x65\x72\x76\x65\x72\x3d".$foreignNodeHost));(
$parameters.=("\x26\x61\x67\x65\x6e\x74\x5f\x70\x6f\x72\x74\x3d".
$foreignNodePort));($parameters.=(
"\x26\x61\x67\x65\x6e\x74\x5f\x75\x73\x65\x72\x3d".NXNodes::getForeignUserName (
$uuid)));($parameters.=(
"\x26\x61\x67\x65\x6e\x74\x5f\x70\x61\x73\x73\x77\x6f\x72\x64\x3d".
NXNodes::getForeignPassword ($uuid)));($parameters.=(
"\x26\x73\x65\x73\x73\x69\x6f\x6e\x49\x64\x3d".$self->getSessionId));(
$parameters.="\x26\x67\x65\x74\x4f\x75\x74\x70\x75\x74\x3d\x31");($parameters.=(
"\x26\x74\x79\x70\x65\x3d".Common::NXSessionType::getForeignDesktop ()));return 
($parameters);}sub NXLocalSessionNode::setCleaningNotRequired{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x63\x6c\x65\x61\x6e\x69\x6e\x67\x4e\x6f\x74\x52\x65\x71\x75\x69\x72\x65\x64"}=
(0x08f0+ 5793-0x1f90));}sub NXLocalSessionNode::doesNeedCleaning{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));if ($$self{
"\x63\x6c\x65\x61\x6e\x69\x6e\x67\x4e\x6f\x74\x52\x65\x71\x75\x69\x72\x65\x64"})
{return ((0x0c5c+ 3485-0x19f9));}return ((0x06cb+ 585-0x0913));}sub 
NXLocalSessionNode::isAgentInitialized{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{
"\x61\x67\x65\x6e\x74\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"});}sub 
NXLocalSessionNode::setAgentInitialized{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));($$self{
"\x61\x67\x65\x6e\x74\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"}=
(0x04e7+ 3417-0x123f));}sub NXLocalSessionNode::doesntExistInNodesDB{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));(my $host=$self->getHost);(my $port
=$self->getPort);if (NXNodes::nodeDoesntExist (NXNodes::getUuid ($host,$port))){
return ((0x09da+ 5309-0x1e96));}return ((0x0008+ 3402-0x0d52));}sub 
NXLocalSessionNode::setSessionParemeters{package NXLocalSessionNode;no warnings;
(my $self=shift (@_));($$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"}=shift (
@_));}sub NXLocalSessionNode::startSession{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));(my $message=
"\x73\x74\x61\x72\x74\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x0a");(
$message.=($$self{
"\x73\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"}."\x0a"))
;$self->sendMessage ($message);$self->setShellModeFinished;}sub 
NXLocalSessionNode::isErrorSent{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));if (($$self{"\x65\x72\x72\x6f\x72\x53\x65\x6e\x74"}==
(0x2318+ 818-0x2649))){return ((0x192b+ 570-0x1b64));}return (
(0x1365+  10-0x136f));}sub NXLocalSessionNode::setErrorSent{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x65\x72\x72\x6f\x72\x53\x65\x6e\x74"}=(0x143d+ 2776-0x1f14));}sub 
NXLocalSessionNode::sendErrorToAdmin{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));(my $error=shift (@_));(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_SEND_TO_ADMIN)."\x20").$error)."\x0a"));$self->sendMessage (
$message);}sub NXLocalSessionNode::setMainSessionId{package NXLocalSessionNode;
no warnings;(my $self=shift (@_));($$self{
"\x6d\x61\x69\x6e\x53\x65\x73\x73\x69\x6f\x6e\x49\x64"}=shift (@_));}sub 
NXLocalSessionNode::setMainSessionDisplay{package NXLocalSessionNode;no warnings
;(my $self=shift (@_));($$self{
"\x6d\x61\x69\x6e\x53\x65\x73\x73\x69\x6f\x6e\x44\x69\x73\x70\x6c\x61\x79"}=
shift (@_));}sub NXLocalSessionNode::setMainSessionCookie{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x6d\x61\x69\x6e\x53\x65\x73\x73\x69\x6f\x6e\x43\x6f\x6f\x6b\x69\x65"}=shift (
@_));}sub NXLocalSessionNode::setTerminateBeforeSwitch{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));($$self{
"\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x42\x65\x66\x6f\x72\x65\x53\x77\x69\x74\x63\x68"
}=(0x0875+ 6639-0x2263));}sub NXLocalSessionNode::isTerminateBeforeSwitch{
package NXLocalSessionNode;no warnings;(my $self=shift (@_));return ($$self{
"\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x42\x65\x66\x6f\x72\x65\x53\x77\x69\x74\x63\x68"
});}sub NXLocalSessionNode::isNotTerminateBeforeSwitch{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));return ((!$self->
isTerminateBeforeSwitch));}sub 
NXLocalSessionNode::isLogoutOrLockScreenBeforeTerminateNeeded{package 
NXLocalSessionNode;no warnings;(my $self=shift (@_));if (($self->isActive and (
NXNodeExec::getAttachedToSessionCount ()>(0x156c+ 1987-0x1d2f)))){return (
(0x1347+ 3815-0x222d));}return ((0x0068+ 743-0x034f));}sub 
NXLocalSessionNode::logoutOrLockScreenIfNeeded{package NXLocalSessionNode;no 
warnings;(my $self=shift (@_));if (NXLocalSession::isLocalSessionTypeDesktop (
$self->getLocalDesktopType)){(my $value="\x30");if ($self->
isLogoutOrLockScreenBeforeTerminateNeeded){($value="\x31");}if (
NXLocalSession::isLogoutOnDisconnectEnabled ()){
NXNodeExec::notifyAboutLogoutBeforeTerminate ($self->getSocket,$value);}elsif (
NXLocalSession::isLockScreenEnabled ()){
NXNodeExec::notifyAboutLockBeforeTerminate ($self->getSocket,$value);}}}sub 
NXLocalSessionNode::setUuid{package NXLocalSessionNode;no warnings;(my $self=
shift (@_));(my $uuid=shift (@_));($$self{"\x6e\x6f\x64\x65\x55\x75\x69\x64"}=
$uuid);}sub NXLocalSessionNode::getUuid{package NXLocalSessionNode;no warnings;(my $self
=shift (@_));return ($$self{"\x6e\x6f\x64\x65\x55\x75\x69\x64"});}package 
NXLocalSessionNode;no warnings;return ((0x19f9+  90-0x1a52));
