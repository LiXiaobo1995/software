############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXPaths::getUserNXHomeDir{package NXPaths;no warnings;return (
Common::NXPaths::getUserRealHomeDirectoryByUsername ("\x6e\x78"));}sub 
NXPaths::getTmpDir{package NXPaths;no warnings;(my $DirPath=(($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x74\x6d\x70"));if ((not (-e ($DirPath)))){
Logger::debug (((
"\x54\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$DirPath)."\x2e"));if ((not (mkdir ($DirPath)))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6b\x64\x69\x72\x20".$DirPath)."\x20\x3a\x20")
.$!));return ((""));}else{if ((Common::NXFile::setPermissionsFullForAll (
$DirPath)!=(-(0x08b4+ 1370-0x0e0d)))){Logger::debug (((
"\x43\x68\x61\x6e\x67\x65\x64\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20\x27".
$DirPath)."\x27\x2e"));}else{Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20\x27"
.$DirPath)."\x27\x3a\x20\x65\x72\x72\x6f\x72").libnxh::NXGetError ())."\x3a\x20"
).libnxh::NXGetErrorString ()));}}}return ($DirPath);}sub 
NXPaths::getServerLogDir{package NXPaths;no warnings;(my $LogDir=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));return ($LogDir);
}sub NXPaths::getNXErrorFile{package NXPaths;no warnings;(my $file=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67"));
return ($file);}sub NXPaths::getNxdLog{package NXPaths;no warnings;(my $file=(((
($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64\x2e\x6c\x6f\x67"));return ($file);}sub 
NXPaths::getNxwebclientLog{package NXPaths;no warnings;(my $file=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e\x6c\x6f\x67"));return ($file);
}sub NXPaths::getDefaultNxhtdErrorLog{package NXPaths;no warnings;(my $file=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67"));return ($file
);}sub NXPaths::getNxserviceLog{package NXPaths;no warnings;(my $file=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e\x6c\x6f\x67"
));return ($file);}sub NXPaths::getServerRSAPrivateKey{package NXPaths;no 
warnings;(my $identityFile=((((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH).
"\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").
$GLOBAL::DIRECTORY_SLASH).$GLOBAL::IdentityRSAUsersFile));return ($identityFile)
;}sub NXPaths::getServerDSAPrivateKey{package NXPaths;no warnings;(my $identityFile
=((((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
$GLOBAL::IdentityDSAUsersFile));return ($identityFile);}sub 
NXPaths::getServerRSAPublicKey{package NXPaths;no warnings;return ((
getServerRSAPrivateKey ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getServerDSAPublicKey{package NXPaths;no warnings;return ((
getServerDSAPrivateKey ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getClusterRSAPrivateKey{package NXPaths;no warnings;(my $identityFile=(
(((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
$GLOBAL::IdentityRSAClusterFile));return ($identityFile);}sub 
NXPaths::getClusterDSAPrivateKey{package NXPaths;no warnings;(my $identityFile=(
(((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
$GLOBAL::IdentityDSAClusterFile));return ($identityFile);}sub 
NXPaths::getClusterDSAPublicKey{package NXPaths;no warnings;return ((
getClusterDSAPrivateKey ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getClusterRSAPublicKey{package NXPaths;no warnings;return ((
getClusterRSAPrivateKey ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getClientRSAPrivateKey{package NXPaths;no warnings;(my $identityFile=((
((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x73\x68\x61\x72\x65").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72\x2e\x69\x64\x5f\x72\x73\x61\x2e\x6b\x65\x79"));return 
($identityFile);}sub NXPaths::getClientRSARestorePrivateKey{package NXPaths;no 
warnings;(my $identityFile=((((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH).
"\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").
$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72\x2e\x69\x64\x5f\x72\x73\x61\x2e\x6b\x65\x79\x2e\x72\x65\x73\x74\x6f\x72\x65"
));return ($identityFile);}sub NXPaths::getClientDSADefaultPrivateKey{package 
NXPaths;no warnings;(my $identityFile=((((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH).
"\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x64\x65\x66\x61\x75\x6c\x74\x2e\x69\x64\x5f\x64\x73\x61\x2e\x6b\x65\x79"));
return ($identityFile);}sub NXPaths::getClientRSADefaultPrivateKey{package 
NXPaths;no warnings;(my $identityFile=((((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH).
"\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x64\x65\x66\x61\x75\x6c\x74\x2e\x69\x64\x5f\x72\x73\x61\x2e\x6b\x65\x79"));
return ($identityFile);}sub NXPaths::__getNXAuthorizedRelativePath{package 
NXPaths;no warnings;return ((((("\x2e\x6e\x78".$GLOBAL::DIRECTORY_SLASH).
"\x63\x6f\x6e\x66\x69\x67").$GLOBAL::DIRECTORY_SLASH).
getNXAuthorizedKeysFileName ()));}sub NXPaths::getProgramDataFromEnvironment{
package NXPaths;no warnings;(my $programDataPath=libnxh::NXTransGetEnvironment (
"\x50\x52\x4f\x47\x52\x41\x4d\x44\x41\x54\x41"));if ((defined ($programDataPath)
and ($programDataPath ne ("")))){return ($programDataPath);}else{return ((
getSystemDriveFromEnvironment ().
"\x2f\x50\x72\x6f\x67\x72\x61\x6d\x44\x61\x74\x61\x2f"));}}sub 
NXPaths::getSystemDriveFromEnvironment{package NXPaths;no warnings;(my $systemDrive
=libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"))
;if ((defined ($systemDrive)and ($systemDrive ne ("")))){return ($systemDrive);}
else{return ("\x43\x3a");}}sub NXPaths::getNXAuthorizedKeysFileName{package 
NXPaths;no warnings;return (
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x2e\x63\x72\x74");}sub 
NXPaths::getNodePublicKeys{package NXPaths;no warnings;return (((((
getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x73\x73\x68").
$GLOBAL::DIRECTORY_SLASH).$GLOBAL::SSHAuthorizedKeys));}sub 
NXPaths::getHostCertDir{package NXPaths;no warnings;(my $hostCertDir=((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63"));($hostCertDir.=(
$GLOBAL::DIRECTORY_SLASH."\x6b\x65\x79\x73"));($hostCertDir.=(
$GLOBAL::DIRECTORY_SLASH."\x68\x6f\x73\x74"));return ($hostCertDir);}sub 
NXPaths::getHostPrivateCert{package NXPaths;no warnings;(my $hostPrivateCert=((
getHostCertDir ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x5f\x68\x6f\x73\x74\x5f\x72\x73\x61\x5f\x6b\x65\x79"));return (
$hostPrivateCert);}sub NXPaths::getHostPublicCert{package NXPaths;no warnings;(my $hostPrivateCert
=((getHostCertDir ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x5f\x68\x6f\x73\x74\x5f\x72\x73\x61\x5f\x6b\x65\x79\x2e\x63\x72\x74"))
;return ($hostPrivateCert);}sub NXPaths::getHttpHostPrivateCert{package NXPaths;
no warnings;(my $hostPrivateCert=((getHostCertDir ().$GLOBAL::DIRECTORY_SLASH).
"\x68\x74\x5f\x68\x6f\x73\x74\x5f\x72\x73\x61\x5f\x6b\x65\x79"));return (
$hostPrivateCert);}sub NXPaths::getHttpHostPublicCert{package NXPaths;no 
warnings;(my $hostPrivateCert=((getHostCertDir ().$GLOBAL::DIRECTORY_SLASH).
"\x68\x74\x5f\x68\x6f\x73\x74\x5f\x72\x73\x61\x5f\x6b\x65\x79\x2e\x63\x72\x74"))
;return ($hostPrivateCert);}sub NXPaths::getClusterHostPrivateCert{package 
NXPaths;no warnings;(my $hostClusterPrivateCert=((getHostCertDir ().
$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x72\x73\x61\x5f\x6b\x65\x79"));
return ($hostClusterPrivateCert);}sub NXPaths::getClusterHostPublicCert{package 
NXPaths;no warnings;(my $hostClusterPrivateCert=((getHostCertDir ().
$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x72\x73\x61\x5f\x6b\x65\x79\x2e\x63\x72\x74"
));return ($hostClusterPrivateCert);}sub NXPaths::getClustetHttpHostPrivateCert{
package NXPaths;no warnings;(my $hostClusterPrivateCert=((getHostCertDir ().
$GLOBAL::DIRECTORY_SLASH).
"\x68\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x72\x73\x61\x5f\x6b\x65\x79"));
return ($hostClusterPrivateCert);}sub NXPaths::getClusterHttpHostPublicCert{
package NXPaths;no warnings;(my $hostClusterPrivateCert=((getHostCertDir ().
$GLOBAL::DIRECTORY_SLASH).
"\x68\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x72\x73\x61\x5f\x6b\x65\x79\x2e\x63\x72\x74"
));return ($hostClusterPrivateCert);}sub NXPaths::getConfigDir{package NXPaths;
no warnings;return (((((getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH).
"\x2e\x6e\x78").$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6e\x66\x69\x67"));}sub 
NXPaths::getRestoreRSAPublicKey{package NXPaths;no warnings;return (((((
getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x73\x73\x68").
$GLOBAL::DIRECTORY_SLASH).
"\x72\x65\x73\x74\x6f\x72\x65\x2e\x69\x64\x5f\x72\x73\x61\x2e\x70\x75\x62"));}
sub NXPaths::getUserDefaultRSAPublicKeyPath{package NXPaths;no warnings;return (
((((getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x73\x73\x68").
$GLOBAL::DIRECTORY_SLASH).
"\x64\x65\x66\x61\x75\x6c\x74\x2e\x69\x64\x5f\x72\x73\x61\x2e\x70\x75\x62"));}
sub NXPaths::getUserKnownHostsSSH{package NXPaths;no warnings;return (((((
getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x73\x73\x68").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x6e\x6f\x77\x6e\x5f\x68\x6f\x73\x74\x73"));}sub 
NXPaths::getUserNewRSAPrivateKey{package NXPaths;no warnings;return (((((
getUserNXHomeDir ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x73\x73\x68").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x65\x77\x2e\x69\x64\x5f\x72\x73\x61"));}sub 
NXPaths::getUserNewRSAPublicKey{package NXPaths;no warnings;return ((
getUserNewRSAPrivateKey ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getUserNXKnownCerts{package NXPaths;no warnings;return (((getConfigDir 
().$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x69\x65\x6e\x74\x2e\x63\x72\x74"));}sub 
NXPaths::getCurrentUserConfigDir{package NXPaths;no warnings;return (((((
libnxh::NXTransGetEnvironment ("\x48\x4f\x4d\x45").$GLOBAL::DIRECTORY_SLASH).
"\x2e\x6e\x78").$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6e\x66\x69\x67"));}sub 
NXPaths::getCurrentUserKnownCerts{package NXPaths;no warnings;return (((
getCurrentUserConfigDir ().$GLOBAL::DIRECTORY_SLASH).
"\x63\x6c\x69\x65\x6e\x74\x2e\x63\x72\x74"));}sub NXPaths::getUserKnownCerts{
package NXPaths;no warnings;(my $user=shift (@_));(my $home=
Common::NXPaths::getUserHomeDirectory ($user));return ((((((($home.
$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78").$GLOBAL::DIRECTORY_SLASH).
"\x63\x6f\x6e\x66\x69\x67").$GLOBAL::DIRECTORY_SLASH).
"\x63\x6c\x69\x65\x6e\x74\x2e\x63\x72\x74"));}sub 
NXPaths::getSSHHostKeyDSAPrivate{package NXPaths;no warnings;return (((((((((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x68\x6f\x73\x74").$GLOBAL::DIRECTORY_SLASH).
"\x73\x73\x68\x5f\x68\x6f\x73\x74\x5f\x64\x73\x61\x5f\x6b\x65\x79"));}sub 
NXPaths::getSSHHostKeyDSAPublic{package NXPaths;no warnings;return ((
getSSHHostKeyDSAPrivate ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getSSHHostKeyECDSAPrivate{package NXPaths;no warnings;return (((((((((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x68\x6f\x73\x74").$GLOBAL::DIRECTORY_SLASH).
"\x73\x73\x68\x5f\x68\x6f\x73\x74\x5f\x65\x63\x64\x73\x61\x5f\x6b\x65\x79"));}
sub NXPaths::getSSHHostKeyECDSAPublic{package NXPaths;no warnings;return ((
getSSHHostKeyECDSAPrivate ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getSSHHostKeyED25519Private{package NXPaths;no warnings;return ((((((((
(getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x68\x6f\x73\x74").$GLOBAL::DIRECTORY_SLASH).
"\x73\x73\x68\x5f\x68\x6f\x73\x74\x5f\x65\x64\x32\x35\x35\x31\x39\x5f\x6b\x65\x79"
));}sub NXPaths::getSSHHostKeyED25519Public{package NXPaths;no warnings;return (
(getSSHHostKeyED25519Private ()."\x2e\x70\x75\x62"));}sub 
NXPaths::getSSHHostKeyRSAPrivate{package NXPaths;no warnings;return (((((((((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").$GLOBAL::DIRECTORY_SLASH).
"\x68\x6f\x73\x74").$GLOBAL::DIRECTORY_SLASH).
"\x73\x73\x68\x5f\x68\x6f\x73\x74\x5f\x72\x73\x61\x5f\x6b\x65\x79"));}sub 
NXPaths::getSSHHostKeyRSAPublic{package NXPaths;no warnings;return ((
getSSHHostKeyRSAPrivate ()."\x2e\x70\x75\x62"));}sub NXPaths::getNodeRoot{
package NXPaths;no warnings;return ($GLOBAL::NODE_ROOT);}sub 
NXPaths::get_user_home_dir{package NXPaths;no warnings;if ((
$GLOBAL::CACHE_USER_DIR eq (""))){(my $dir=
Common::NXPaths::getEffectiveUserHomeDirectory ());($GLOBAL::CACHE_USER_DIR=$dir
);}if ((not (-d ($GLOBAL::CACHE_USER_DIR)))){($GLOBAL::CACHE_USER_DIR=getTmpDir 
());}return ($GLOBAL::CACHE_USER_DIR);}sub NXPaths::get_user_nx_dir{package 
NXPaths;no warnings;return (((get_user_home_dir ().$GLOBAL::DIRECTORY_SLASH).
"\x2e\x6e\x78"));}sub NXPaths::getProfilesDB{package NXPaths;no warnings;return 
(((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x64\x62"));}sub 
NXPaths::getUsersDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x75\x73\x65\x72\x73\x2e\x64\x62"));}sub NXPaths::getGroupsDB{package NXPaths;
no warnings;return (((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63")
.$GLOBAL::DIRECTORY_SLASH)."\x67\x72\x6f\x75\x70\x73\x2e\x64\x62"));}sub 
NXPaths::getPasswordsDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x70\x61\x73\x73\x77\x6f\x72\x64\x73\x2e\x64\x62"));}sub 
NXPaths::getAdministratorsDB{package NXPaths;no warnings;return (((((getNodeRoot
 ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x2e\x64\x62"));}sub 
NXPaths::getGuestsDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x67\x75\x65\x73\x74\x73\x2e\x64\x62"));}sub NXPaths::getHostsDB{package 
NXPaths;no warnings;return (((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH).
"\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH)."\x68\x6f\x73\x74\x73\x2e\x64\x62"));}
sub NXPaths::getNodesDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x6f\x64\x65\x73\x2e\x64\x62"));}sub NXPaths::getClusterDB{package NXPaths;
no warnings;return (((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63")
.$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x75\x73\x74\x65\x72\x2e\x64\x62"));}sub 
NXPaths::getNodeGroupsDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x6f\x64\x65\x2d\x67\x72\x6f\x75\x70\x73\x2e\x64\x62"));}sub 
NXPaths::getServerGroupsDB{package NXPaths;no warnings;return (((((getNodeRoot 
().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72\x2d\x67\x72\x6f\x75\x70\x73\x2e\x64\x62"));}sub 
NXPaths::getNetworkDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x65\x74\x77\x6f\x72\x6b\x2e\x64\x62"));}sub NXPaths::getNetworkFile{
package NXPaths;no warnings;return (((((getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)
."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH)."\x6e\x65\x74\x77\x6f\x72\x6b"));}sub
 NXPaths::getLogrotateDB{package NXPaths;no warnings;return (((((getNodeRoot ().
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x6c\x6f\x67\x72\x6f\x74\x61\x74\x65\x2e\x64\x62"));}sub 
NXPaths::getTwoFactorPublicKeys{package NXPaths;no warnings;return (((((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x74\x77\x6f\x46\x61\x63\x74\x6f\x72\x2e\x64\x62"));}
sub NXPaths::getUsbDBPath{package NXPaths;no warnings;return (((((getNodeRoot ()
.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x75\x73\x62\x2e\x64\x62"));}sub NXPaths::getServerLaunchPath{package NXPaths;
no warnings;(my $path=($GLOBAL::ETC_DIR.$GLOBAL::DIRECTORY_SLASH));($path.=(
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65".$GLOBAL::DIRECTORY_SLASH));($path.=(
"\x6e\x78\x73\x65\x72\x76\x65\x72".$GLOBAL::DIRECTORY_SLASH));($path.=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65");return ($path);}sub 
NXPaths::getAncillarySocketPath{package NXPaths;no warnings;(my $sessionID=shift
 (@_));(my $socketPath=((((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x74\x6d\x70").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x73\x73\x69\x6f\x6e\x2d").
$sessionID));return ($socketPath);}sub NXPaths::getSystemdSessionPath{package 
NXPaths;no warnings;(my $path=((((($GLOBAL::DIRECTORY_SLASH."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x73\x79\x73\x74\x65\x6d\x64").
$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x73\x73\x69\x6f\x6e\x73"));return ($path);}
sub NXPaths::getCollectLogScriptsPath{package NXPaths;no warnings;(my $path=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x73\x63\x72\x69\x70\x74\x73").
$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67"));return ($path);}sub 
NXPaths::getLogArchivesPath{package NXPaths;no warnings;(my $path=((
Common::NXPaths::getSpecialUsersLogFolderPath ().$GLOBAL::DIRECTORY_SLASH).
"\x61\x72\x63\x68\x69\x76\x65\x73"));return ($path);}sub 
NXPaths::getLogrotatePath{package NXPaths;no warnings;(my $path=((
Common::NXPaths::getSpecialUsersLogFolderPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6c\x6f\x67\x72\x6f\x74\x61\x74\x65"));return ($path);}sub 
NXPaths::getAssumedHomeDirectory{package NXPaths;no warnings;(my $username=shift
 (@_));(my $path=(""));if ((Common::NXInfo::getOsInfo ()eq 
"\x57\x69\x6e\x64\x6f\x77\x73\x20\x58\x50")){($path=(
"\x43\x3a\x5c\x44\x6f\x63\x75\x6d\x65\x6e\x74\x73\x20\x61\x6e\x64\x20\x53\x65\x74\x74\x69\x6e\x67\x73\x5c"
.$username));}else{($path=("\x43\x3a\x5c\x55\x73\x65\x72\x73\x5c".$username));}
return ($path);}sub NXPaths::getVirtDB{package NXPaths;no warnings;(my $db=((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63"));($db.=(
$GLOBAL::DIRECTORY_SLASH."\x76\x69\x72\x74\x2e\x64\x62"));return ($db);}sub 
NXPaths::getLogFile{package NXPaths;no warnings;(my $logFile=
$GLOBAL::SystemLogFile);if ((($GLOBAL::SystemLogFile eq 
"\x2f\x6c\x6f\x67\x2f\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67")or (
$GLOBAL::SystemLogFile eq ("")))){($logFile=(((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67"));}return ($logFile);}sub 
NXPaths::getSystemLoadFile{package NXPaths;no warnings;return (((getTmpDir ().
$GLOBAL::DIRECTORY_SLASH)."\x73\x79\x73\x74\x65\x6d\x6c\x6f\x61\x64"));}sub 
NXPaths::getNXAuthorizedKeysBasePath{package NXPaths;no warnings;(my $user=shift
 (@_));(my $base=$GLOBAL::NXAuthorizedBasePath);if (($base eq (""))){return (
Common::NXPaths::getUserHomeDirectory ($user));}return ((($base.
$GLOBAL::DIRECTORY_SLASH).$user));}sub NXPaths::getNXAuthorizedKeysRelativePath{
package NXPaths;no warnings;(my $user=shift (@_));(my $relative=
$GLOBAL::NXAuthorizedRelativePath);if (($relative eq (""))){return (
__getNXAuthorizedRelativePath ());}return ($relative);}sub 
NXPaths::getNXAuthorizedKeysPath{package NXPaths;no warnings;(my $user=shift (@_
));(my $base=getNXAuthorizedKeysBasePath ($user));(my $relative=
getNXAuthorizedKeysRelativePath ());return ((($base.$GLOBAL::DIRECTORY_SLASH).
$relative));}sub NXPaths::isNXAuthorizedKeysPathDefault{package NXPaths;no 
warnings;if (($GLOBAL::NXAuthorizedBasePath eq (""))){if (((
$GLOBAL::NXAuthorizedRelativePath eq __getNXAuthorizedRelativePath ())or (
$GLOBAL::NXAuthorizedRelativePath eq ("")))){return ((0x1a0a+ 2854-0x252f));}}
return ((0x17a6+ 2824-0x22ae));}sub NXPaths::getNXReportLoadScriptName{package 
NXPaths;no warnings;return (
"\x6e\x78\x72\x65\x70\x6f\x72\x74\x73\x79\x73\x74\x65\x6d\x6c\x6f\x61\x64\x2e\x73\x68"
);}sub NXPaths::getNXReportLoadScript{package NXPaths;no warnings;return (((((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x73\x63\x72\x69\x70\x74\x73").
$GLOBAL::DIRECTORY_SLASH)."\x6c\x62").$GLOBAL::DIRECTORY_SLASH).
getNXReportLoadScriptName ()));}sub NXPaths::getMemInfoFile{package NXPaths;no 
warnings;return ("\x2f\x70\x72\x6f\x63\x2f\x6d\x65\x6d\x69\x6e\x66\x6f");}sub 
NXPaths::getRedisDatabaseDirectory{package NXPaths;no warnings;return (((
getNodeRoot ().$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63"));}sub 
NXPaths::getRedisDatabaseFile{package NXPaths;no warnings;return (((
getRedisDatabaseDirectory ().$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64\x62"));}sub
 NXPaths::getDMScriptShellDesktop{package NXPaths;no warnings;return (
$GLOBAL::DMScriptShellDesktop);}sub NXPaths::getDMScriptWaylandService{package 
NXPaths;no warnings;return ($GLOBAL::DMScriptWaylandService);}sub 
NXPaths::getDMScriptWaylandServiceAlternative{package NXPaths;no warnings;return
 ($GLOBAL::DMScriptWaylandServiceAlternative);}sub 
NXPaths::getDMScriptPlasmaCompositor{package NXPaths;no warnings;return (
$GLOBAL::DMScriptPlasmaCompositor);}sub NXPaths::getDMScriptPlasmaSourceEnv{
package NXPaths;no warnings;return ($GLOBAL::DMScriptPlasmaSourceEnv);}sub 
NXPaths::getDMScriptSusePlasmaSourceEnv{package NXPaths;no warnings;return (
$GLOBAL::DMScriptSusePlasmaSourceEnv);}sub NXPaths::getDMScriptKdeNeon{package 
NXPaths;no warnings;return ($GLOBAL::DMScriptKdeNeon);}sub 
NXPaths::getDMScriptGaruda{package NXPaths;no warnings;return (
$GLOBAL::DMScriptGaruda);}sub NXPaths::getDMScriptGarudaSourceEnv{package 
NXPaths;no warnings;return ($GLOBAL::DMScriptGarudaSourceEnv);}sub 
NXPaths::getDMScriptRocky{package NXPaths;no warnings;return (
$GLOBAL::DMScriptRocky);}sub NXPaths::getDMScriptKdeNeonSourceEnv{package 
NXPaths;no warnings;return ($GLOBAL::DMScriptKdeNeonSourceEnv);}sub 
NXPaths::getDMScriptSuseWayland{package NXPaths;no warnings;return (
$GLOBAL::DMScriptSuseWayland);}sub NXPaths::getEGLPreloadScript{package NXPaths;
no warnings;return ((((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x65\x6e\x76").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x70\x72\x65\x6c\x6f\x61\x64\x2e\x73\x68"));}
sub NXPaths::getEGLPrealoadLib{package NXPaths;no warnings;return (((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62").
$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62\x6e\x78\x65\x67\x6c\x2e\x73\x6f"));}sub 
NXPaths::getKwinWaylandPath{package NXPaths;no warnings;return (
$GLOBAL::KwinWaylandPath);}sub NXPaths::getNXSourceEnvScriptPath{package NXPaths
;no warnings;return ($GLOBAL::NXSourceEnvScriptPath);}sub 
NXPaths::getNXSourceEnvScript{package NXPaths;no warnings;return (((
getNXSourceEnvScriptPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x2d\x73\x6f\x75\x72\x63\x65\x65\x6e\x76\x2e\x73\x68"));}sub 
NXPaths::getKwinWaylandBackupPath{package NXPaths;no warnings;return ((
getKwinWaylandPath ()."\x2e\x63\x61\x70\x73\x2e\x4e\x58"));}sub 
NXPaths::getGnomeShellPath{package NXPaths;no warnings;return (
$GLOBAL::GnomeShellPath);}sub NXPaths::getGnomeShellCapabilitiesBackupPath{
package NXPaths;no warnings;return ((getGnomeShellPath ().
"\x2e\x63\x61\x70\x73\x2e\x4e\x58"));}sub NXPaths::getClusterInterfaceFile{
package NXPaths;no warnings;return ((((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x63\x6c\x75\x73\x74\x65\x72\x2e\x69\x6e\x74\x65\x72\x66\x61\x63\x65"))
;}package NXPaths;no warnings;return ((0x1a39+ 2637-0x2485));
