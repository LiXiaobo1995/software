############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXLocate;no warnings;($lastIp=(""));($lastHost=(""));($command=(""));(
$WRITE_LOCATE=(""));($READ_LOCATE=(""));($lastLocateUpdate=
Common::NXTime::getSecondsSinceEpoch ());($commandClear=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x72\x65\x6d\x6f\x76\x65\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x6c\x6f\x63\x61\x6c"
);($inited=(0x14a3+ 418-0x1645));($started=(0x0674+ 7761-0x24c5));(@array=());(
$serverStartup=(0x1371+ 4395-0x249c));($host_Index=(0x0f9f+ 613-0x1204));(
$ip_Index=(0x0491+ 3194-0x110a));($type_Index=(0x0675+ 7097-0x222c));($os_Index=
(0x0c0b+ 1341-0x1145));($hw_Index=(0x0595+ 7350-0x2247));($nx_Index=
(0x2143+ 267-0x2249));($ssh_Index=(0x0d1b+ 2518-0x16eb));($https_Index=
(0x1de5+ 1960-0x2586));($mac_Index=(0x0279+ 7261-0x1ece));($uuid_Index=
(0x08d2+ 648-0x0b51));sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub getLastLocateUpdate{return (
$lastLocateUpdate);}sub setLastLocateUpdate{($lastLocateUpdate=
Common::NXTime::getSecondsSinceEpoch ());}sub checkUpdate{(my $now=
Common::NXTime::getSecondsSinceEpoch ());if (((getLastLocateUpdate ()+
updateLocateStep ())<=$now)){setLastLocateUpdate ();if ((checkIpChanged ()or 
checkHostChanged ())){update ();}}}sub checkIpChanged{(my $newIp=(""));if ((
defined ($GLOBAL::NXdListenAddress)and ($GLOBAL::NXdListenAddress ne ("")))){(
$newIp=$GLOBAL::NXdListenAddress);}else{($newIp=NXNodeInfo::getServerIp ());}if 
(($newIp eq $lastIp)){return ((0x00b9+ 8016-0x2009));}return (
(0x19d4+ 385-0x1b54));}sub checkHostChanged{(my $newHost=
Common::NXInfo::getHostInfo ());if (($newHost eq $lastHost)){return (
(0x05c0+ 812-0x08ec));}return ((0x0ae9+ 5958-0x222e));}sub writeCommand{(my $cmd
=shift (@_));if (($READ_LOCATE eq (""))){Logger::warning (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x20\x46\x44\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$cmd)."\x2e"));return ((0x131d+ 2380-0x1c69));}Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x6e\x20\x46\x44\x23"
.$READ_LOCATE)."\x3a\x20").$cmd)."\x2e"));(my $bytes_write=main::nxwrite (
$READ_LOCATE,($cmd."\x0a")));Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x77\x72\x6f\x74\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$READ_LOCATE)."\x3a\x20").$bytes_write)."\x20\x62\x79\x74\x65\x73\x2e"));return
 ($bytes_write);}sub prepareParameters{(my $length=@array);for ((my $i=
(0x137b+ 4557-0x2548));($i<$length);(++$i)){if ((defined ($array[$i])and ($array
[$i]ne ("")))){($array[$i]=~ s/,/ /g );}if ((defined ($array[$i])and ($array[$i]
ne ("")))){($array[$i]=~ s/\s+/ /g );}if ((defined ($array[$i])and ($array[$i]ne
 ("")))){($array[$i]=~ s/\s*$//g );}}}sub buildNewCommand{Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x61\x72\x72\x61\x79\x3a\x20"
.join ($",@array))."\x2e"));(my $commandTMP=(""));if (((__getIp ()ne (""))and (
__getServices ()ne ("")))){prepareParameters ();($commandTMP=((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x6c\x6f\x63\x61\x6c\x2c\x6e\x61\x6d\x65\x73\x3d"
.__getHost ())."\x2c\x69\x70\x3d"));foreach my $f (split ("\x20",__getIp (),
(0x03e3+ 624-0x0653))){if (($f ne (""))){($commandTMP.=($f."\x3b"));}}(
$commandTMP=~ s/;$// );if (($commandTMP=~ /,ip=$/ )){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x74\x20\x69\x70\x20\x61\x64\x72\x65\x73\x73\x2e"
);($command=(""));return;}($commandTMP.=(((((("\x2c\x74\x79\x70\x65\x3d".
__getType ())."\x2c\x6f\x73\x3d").__getOs ())."\x2c\x68\x77\x3d").__getHw ()).
"\x2c\x73\x65\x72\x76\x69\x63\x65\x3d"));($commandTMP.=__getServices ());(
$commandTMP.="\x2c\x6d\x61\x63\x3d");($commandTMP.=__getMac ());($commandTMP.=
"\x2c\x75\x75\x69\x64\x3d");($commandTMP.=__getUuid ());($commandTMP.="\x0a");}
else{Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x6e\x6f\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6f\x72\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x69\x70\x20\x61\x64\x72\x65\x73\x73\x2e"
);($command=(""));return;}chomp ($commandTMP);($command=$commandTMP);
Logger::debug ((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x6e\x65\x77\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x69\x73\x3a\x20"
.$commandTMP));}sub update{Logger::debug (
"\x57\x69\x6c\x6c\x20\x75\x70\x64\x61\x74\x65\x20\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x6e\x6f\x77\x2e"
);if ((not (wasStarted ()))){return (run ());}writeCommand ($commandClear);
setNewIp ();setNewHost ();buildNewCommand ();if (($command eq (""))){return (
(0x0ce6+ 5481-0x224f));}writeCommand ($command);return ((0x01db+ 6877-0x1cb7));}
sub setNewIp{__setIp ();($lastIp=__getIp ());}sub setNewHost{__setHost (
Common::NXInfo::getHostInfo ());($lastHost=__getHost ());}sub removeService{(my $service
=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$service)."\x2e"));if (($service eq "\x6e\x78\x64")){__setNx ((""));}elsif (((
$service eq "\x73\x73\x68\x64")or ($service eq "\x6e\x78\x73\x73\x68\x64"))){
__setSsh ((""));}elsif (($service eq "\x6e\x78\x68\x74\x64")){__setHttps ((""));
}update ();}sub addService{(my $service=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x61\x64\x64\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$service)."\x2e"));if (($service eq "\x6e\x78\x64")){__setNx (
NXNodeInfo::getNxdPortIfEnabled ());}elsif ((($service eq "\x73\x73\x68\x64")or 
($service eq "\x6e\x78\x73\x73\x68\x64"))){__setSsh (NXNodeInfo::getSshdPort ())
;}elsif (($service eq "\x6e\x78\x68\x74\x64")){__setHttps (
NXNodeInfo::getHttpsPort ());}update ();}sub setInitCommand{__setHost (
Common::NXInfo::getHostInfo ());__setIp ();__setType (NXNodeInfo::getServerType 
());__setOs (Common::NXInfo::getDistroInfo ());__setHw (
Common::NXInfo::getHwInfo ());__setNx (NXNodeInfo::getNxdPortIfEnabled ());
__setSsh (NXNodeInfo::getSshdPort ());__setHttps (NXNodeInfo::getHttpsPort ());
__setMac (__getMacAddress ());__setUuid ($GLOBAL::UUID);buildNewCommand ();}sub 
initInfo{Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x69\x6e\x67"
);setInitCommand ();setServerStartup ();($inited=(0x17a4+ 1160-0x1c2b));}sub run
{if (wasStarted ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x77\x61\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);return ((0x0c14+ 3770-0x1acd));}if (($inited!=(0x00a9+ 2562-0x0aaa))){initInfo
 ();}Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x4e\x58\x4c\x6f\x63\x61\x74\x65");if (
main::nxPipeCreateBi ((\$READ_LOCATE),(\$WRITE_LOCATE))){Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x5b"
.$READ_LOCATE)."\x2f").$WRITE_LOCATE)."\x5d"));}else{Logger::error (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x70\x61\x69\x72\x2e"
);return ((0x1512+ 751-0x1801));}(my $setInheritableReturn=
libnxh::NXDescriptorInheritable ($READ_LOCATE,(0x07e2+ 1242-0x0cbb)));(my $homeDir
=NXPaths::getUserNXHomeDir ());libnxh::NXTransSetEnvironment ("\x48\x4f\x4d\x45"
,$homeDir);(my $writeLocateOutput=Common::NXCore::nxFileDuplicate ($WRITE_LOCATE
));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x6c\x69\x65\x6e\x74\x43\x72\x65\x61\x74\x65\x28"
.$WRITE_LOCATE)."\x2c\x20").$writeLocateOutput).
"\x29\x20\x73\x74\x61\x72\x74\x2e\x20"));(my $ret=libnxhs::NXLocateClientCreate 
($WRITE_LOCATE,$writeLocateOutput));Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x6c\x69\x65\x6e\x74\x43\x72\x65\x61\x74\x65\x28"
.$WRITE_LOCATE)."\x2c\x20").$writeLocateOutput).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20").$ret)."\x2e"));
Common::NXCore::doNotCloseSocketAtFinish ($WRITE_LOCATE);if (($ret!=
(0x16e2+ 1923-0x1e64))){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65"
);main::nxclose ($READ_LOCATE);main::nxclose ($WRITE_LOCATE);return ($ret);}(
$started=(0x14cb+ 1504-0x1aaa));(my $msg=$command);return (writeCommand ($msg));
}sub wasStarted{return ($started);}sub NXLocateLogFile{return (((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e\x6c\x6f\x67"));}
sub isNXLocateEnabled{if ((Server::isDirectAccessDisabled ()or (not (
NXLicense::isDirectConnectionFeature ())))){return ((0x00b4+ 2571-0x0abf));}
return ($GLOBAL::EnableNetworkBroadcast);}sub close{if (isNXLocateEnabled ()){
Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x69\x73\x20\x63\x6c\x6f\x73\x69\x6e\x67\x2e"
);(my $ret=libnxhs::NXLocateClientDestroy ());if (($ret!=(0x1087+ 3500-0x1e32)))
{Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x6f\x70\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e"
);return ($ret);}($started=(0x0db0+ 2773-0x1885));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x6c\x69\x65\x6e\x74\x44\x65\x73\x74\x72\x6f\x79\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20"
.$ret)."\x2e"));}else{return ((0x0a97+ 1741-0x1164));}}sub requestToRemove{(my $service
=shift (@_));if (((((($service ne "\x6e\x78\x68\x74\x64")and ($service ne 
"\x6e\x78\x64"))and ($service ne "\x73\x73\x68\x64"))and ($service ne 
"\x6e\x78\x73\x73\x68\x64"))or checkIfServerStartup ())){return;}if (
Server::isServerShutdown ()){return;}unless (NXSystemDaemons::isRunning (
"\x6e\x78\x73\x65\x72\x76\x65\x72")){return ((0x0487+ 4166-0x14cd));}
Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x3a\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x2e"));unless (
openConnectionToStartup ()){return ((0x060f+ 2364-0x0f4b));}(my $res=
NXClientSystemDaemons::sendMessage ((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_STOP)."\x20").$service)."\x0a")));
closeConnectionWithStartup ();return ((0x2517+  48-0x2546));}sub requestToAdd{(my $service
=shift (@_));if (((((($service ne "\x6e\x78\x68\x74\x64")and ($service ne 
"\x6e\x78\x64"))and ($service ne "\x73\x73\x68\x64"))and ($service ne 
"\x6e\x78\x73\x73\x68\x64"))or checkIfServerStartup ())){return;}Logger::debug (
((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x61\x64\x64\x3a\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x2e"));unless (
openConnectionToStartup ()){return ((0x19ef+ 2504-0x23b7));}(my $res=
NXClientSystemDaemons::sendMessage ((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_START)."\x20").$service)."\x0a")));
closeConnectionWithStartup ();return ((0x088c+ 2771-0x135e));}sub 
checkIfServerStartup{if (($serverStartup==(0x0f0d+ 1278-0x140a))){Logger::debug2
 ("\x53\x65\x72\x76\x65\x72\x20\x53\x74\x61\x72\x74\x75\x70");return (
(0x164f+ 3320-0x2346));}Logger::debug2 (
"\x4e\x6f\x74\x20\x53\x65\x72\x76\x65\x72\x20\x53\x74\x61\x72\x74\x75\x70");
return ((0x212b+  28-0x2147));}sub setServerStartup{Logger::debug (
"\x53\x65\x74\x74\x69\x6e\x67\x20\x53\x65\x72\x76\x65\x72\x20\x53\x74\x61\x72\x74\x75\x70\x20\x74\x6f\x20\x31\x2e"
);($serverStartup=(0x003f+ 8113-0x1fef));}sub restart{stop ();start ();}sub 
start{if (isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x2e");
unless (openConnectionToStartup ()){return ((0x03b1+ 5676-0x19dd));}(my $res=
NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_START)."\x20\x73\x74\x61\x72\x74\x0a")));
closeConnectionWithStartup ();return ((0x1e3c+ 1250-0x231d));}else{return (
(0x002a+ 834-0x036c));}}sub stop{if (isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x74\x6f\x70\x70\x69\x6e\x67\x2e");
unless (openConnectionToStartup ()){return ((0x20f5+ 1532-0x26f1));}(my $res=
NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_STOP)."\x20\x73\x74\x6f\x70\x0a")));
closeConnectionWithStartup ();return ((0x0d8a+ 5700-0x23cd));}else{return (
(0x05cc+ 7086-0x217a));}}sub openConnectionToStartup{unless (
NXClientSystemDaemons::openConnection ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);return ((0x1ae5+ 289-0x1c06));}return ((0x0356+ 4808-0x161d));}sub 
closeConnectionWithStartup{NXClientSystemDaemons::closeConnection ();}sub 
__getMacAddress{(my (%macs)=__getMacs ());(my $mac=(""));(my $ipAdresses=__getIp
 ());if (($ipAdresses ne (""))){foreach my $ip (split ( /,/ ,$ipAdresses,
(0x1148+ 3648-0x1f88))){while ((($name,$value)=each (%macs))){if (($name eq $ip)
){($mac.=($value."\x3b"));}}}if (($mac ne (""))){($mac=~ s/;$//g );}if (($mac ne
 (""))){if ((length ($mac)==(0x1c97+ 2335-0x25b6))){($mac=
"\x55\x6e\x64\x65\x66\x69\x6e\x65\x64");}}else{($mac=
"\x55\x6e\x64\x65\x66\x69\x6e\x65\x64");Logger::debug2 (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x75\x61\x62\x6c\x65\x20\x74\x6f\x20\x67\x65\x74\x20\x4d\x41\x43\x20\x61\x64\x64\x72\x65\x73\x73\x2e"
);}}else{($mac="\x55\x6e\x64\x65\x66\x69\x6e\x65\x64");Logger::debug2 (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x67\x65\x74\x20\x49\x50\x20\x61\x64\x64\x72\x65\x73\x73\x2e"
);}Logger::debug2 (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x4d\x41\x43\x20\x61\x64\x64\x72\x65\x73\x73\x3a\x20"
.$mac)."\x2e"));__setMac ($mac);return ($mac);}sub __getMacs{(my (%macs)=());
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $networkInterfaces=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20"
.$networkInterfaces)."\x2e"));if (($networkInterfaces ne (""))){(my (@lines)=
split ( /\n/ ,$networkInterfaces,(0x0f88+ 4882-0x229a)));foreach my $line (
@lines){Logger::debug ((("\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20".$line).
"\x2e"));if (($line=~ /(^.*)\s+AF_INET\s+([0-9A-Fa-f:]*)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){(my $ip=$3);(my $mc=$2);if (($mc=~ /([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})/ )
){($macs{$ip}=$mc);}}}}else{Logger::debug2 (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x66\x65\x74\x63\x68\x20\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x28\x29\x2e"
);}return (%macs);}sub updateLocateStep{return ($GLOBAL::LocateUpdateStep);}sub 
__setHost{(my $host=shift (@_));if (($host ne (""))){($host=
Common::NXCore::convertStringFromWindowsCodePageToUtf8 ($host));}($array[
$host_Index]=$host);($lastHost=__getHost ());}sub __getHost{if (($array[
$host_Index]eq (""))){return ("\x55\x6e\x6b\x6e\x6f\x77\x6e");}return ($array[
$host_Index]);}sub __setIp{if ((defined ($GLOBAL::NXdListenAddress)and (
$GLOBAL::NXdListenAddress ne ("")))){($array[$ip_Index]=
$GLOBAL::NXdListenAddress);($lastIp=__getIp ());}else{($array[$ip_Index]=
NXNodeInfo::getServerIp ());($lastIp=__getIp ());}}sub __getIp{return ($array[
$ip_Index]);}sub __setType{($array[$type_Index]=shift (@_));}sub __getType{if ((
$array[$type_Index]eq (""))){return ("\x55\x6e\x6b\x6e\x6f\x77\x6e");}return (
$array[$type_Index]);}sub __setOs{($array[$os_Index]=shift (@_));}sub __getOs{if
 (($array[$os_Index]eq (""))){return ("\x55\x6e\x6b\x6e\x6f\x77\x6e");}return (
$array[$os_Index]);}sub __setHw{($array[$hw_Index]=shift (@_));}sub __getHw{if (
($array[$hw_Index]eq (""))){return ("\x55\x6e\x6b\x6e\x6f\x77\x6e");}return (
$array[$hw_Index]);}sub __setNx{($array[$nx_Index]=shift (@_));}sub __getNx{
return ($array[$nx_Index]);}sub __setSsh{($array[$ssh_Index]=shift (@_));}sub 
__getSsh{return ($array[$ssh_Index]);}sub __setHttps{($array[$https_Index]=shift
 (@_));}sub __getHttps{return ($array[$https_Index]);}sub __getServices{(
$commandTMP=(""));if ((__getNx ()ne (""))){($commandTMP.=(("\x6e\x78\x3a".
__getNx ())."\x3b"));}if ((__getSsh ()ne (""))){($commandTMP.=((
"\x73\x73\x68\x3a".__getSsh ())."\x3b"));}if ((__getHttps ()ne (""))){(
$commandTMP.=(("\x68\x74\x74\x70\x73\x3a".__getHttps ())."\x3b"));}if ((
$commandTMP ne (""))){($commandTMP=~ s/;$//g );}else{Logger::debug2 (
"\x4e\x58\x4c\x63\x61\x74\x65\x3a\x3a\x5f\x5f\x67\x65\x74\x53\x65\x72\x76\x69\x63\x65\x73\x28\x29\x3a\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"
);}return ($commandTMP);}sub __setMac{($array[$mac_Index]=shift (@_));}sub 
__getMac{return ($array[$mac_Index]);}sub __setUuid{($array[$uuid_Index]=shift (
@_));}sub __getUuid{return ($array[$uuid_Index]);}return ((0x00b1+ 4635-0x12cb))
;
