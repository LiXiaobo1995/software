############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXLogin::BEGIN{package NXLogin;no warnings;require NXUser;do{
"\x4e\x58\x55\x73\x65\x72"->import};}sub NXLogin::BEGIN{package NXLogin;no 
warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}
sub NXLogin::BEGIN{package NXLogin;no warnings;require Exception::Configuration;
do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->import};}sub NXLogin::BEGIN{package NXLogin;no warnings;require 
Exception::Internal;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
import};}sub NXLogin::BEGIN{package NXLogin;no warnings;require Exception::Log;
do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->import};}sub 
NXLogin::BEGIN{package NXLogin;no warnings;require Exception::InfoLog;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
import};}sub NXLogin::BEGIN{package NXLogin;no warnings;require 
Exception::NXUser::NotSystemUser;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72"
->import};}package NXLogin;no warnings;require NXMsg;my ($__nxuser);my (
$__foreign_addres);my ($__local_addres);my ($__password_type);my ($__sessionType
);(my $__flagUseNXUsers=(0x02fc+ 7154-0x1eed));(my $__flagUseNXPasswords=
(0x1baf+ 2713-0x2647));(my $__flagGuestIsLogged=(0x073b+ 319-0x087a));(my $__flagWebLoginUnrestricted
=(0x14a4+ 1839-0x1bd3));(my $serverBrowseGuest=(0x0c02+ 2175-0x1481));(my $trueGuestLogin
=(0x0c41+ 3104-0x1861));(my $desktopGuestLogin=(0x0f19+ 5118-0x2317));(my $virtualDesktopGuestLogin
=(0x1ba8+ 226-0x1c8a));(my $physicalDesktopGuestLogin=(0x067b+ 2916-0x11df));(
$loggedUserAdministratorProperty="\x6e\x6f");$absoluteName;$loginFromPlayer;(
$updateLogin=(0x0935+ 7336-0x25dd));($AuthenticationMethod=(""));(
$AuthenticationMethodSSHSystem=
"\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x67\x69\x6e\x20\x61\x6e\x64\x20\x70\x61\x73\x73\x77\x6f\x72\x64"
);($AuthenticationMethodAnywhere=
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x4e\x65\x74\x77\x6f\x72\x6b");(
$AuthenticationMethodSSHSystemForwardKerberosKey=
"\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x67\x69\x6e\x20\x61\x6e\x64\x20\x4b\x65\x72\x62\x65\x72\x6f\x73"
);($AuthenticationMethodSSHSystemForwardAgentKey=
"\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x67\x69\x6e\x20\x61\x6e\x64\x20\x70\x72\x69\x76\x61\x74\x65\x20\x6b\x65\x79\x20"
);($AuthenticationMethodNXGSS="\x4e\x58\x2d\x6b\x65\x72\x62\x65\x72\x6f\x73");(
$AuthenticationMethodNXPublicKey=
"\x4e\x58\x2d\x70\x72\x69\x76\x61\x74\x65\x2d\x6b\x65\x79");(
$AuthenticationMethodNXQuick=
"\x4e\x58\x20\x51\x75\x69\x63\x6b\x20\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodSSHQuick=
"\x53\x53\x48\x20\x51\x75\x69\x63\x6b\x20\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodmd5="\x4d\x44\x35");($AuthenticationMethodPassword=
"\x50\x61\x73\x73\x77\x6f\x72\x64");($AuthenticationMethodPasswordDB=
"\x50\x61\x73\x73\x77\x6f\x72\x64\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65"
);($AuthenticationMethodNXpassword=
"\x4e\x58\x2d\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodSSHpassword=
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x6c\x6f\x67\x69\x6e");(
$AuthenticationMethodNXpasswordDB=
"\x4e\x58\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65"
);($AuthenticationMethodSSHpasswordDB=
"\x53\x53\x48\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65"
);($AuthenticationMethodOneTimePassword=
"\x4f\x6e\x65\x2d\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodNotRequired=
"\x4e\x6f\x74\x20\x52\x65\x71\x75\x69\x72\x65\x64");(
$forwardingUserToRemoteServer=(0x11e0+ 1867-0x192b));($quasiAdminAuthRequired=
(0x0bef+ 1096-0x1037));($visitor=(""));($visitorHost=(""));($visitorLongName=
(""));($desktopGuest=(0x138f+ 4813-0x265c));(my $__connectionMethodSSH=
(0x0100+ 5045-0x14b5));(my $__userLoggedInThroughNXClient=(0x0c3c+ 6564-0x25e0))
;($loginServerTypeName="\x6c\x6f\x67\x69\x6e");($userFullName=(""));(
$tokenAuthorizedUser=(""));sub init{(my $param=shift (@_));if ((not (defined (
$param)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (
"\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x73\x65\x72\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((($param ne (0x1f12+ 2013-0x26ef))and ($param ne (0x107c+ 2426-0x19f5))))
{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (((
"\x76\x61\x6c\x75\x65\x20\x6f\x66\x20\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x73\x65\x72\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$param)."\x27"));}($__flagUseNXUsers=$param);($param=shift (@_));if ((not (
defined ($param)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (
"\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x50\x61\x73\x73\x77\x6f\x72\x64\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((($param ne (0x1908+ 513-0x1b09))and ($param ne (0x0f67+ 2479-0x1915)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (((
"\x76\x61\x6c\x75\x65\x20\x6f\x66\x20\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x50\x61\x73\x73\x77\x6f\x72\x64\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$param)."\x27"));}($__flagUseNXPasswords=$param);if ((not (
$__flagUseNXPasswords))){main::nxrequire (
"\x4e\x58\x4e\x73\x73\x55\x73\x65\x72\x4d\x61\x6e\x61\x67\x65\x72");
NXNssUserManager::init ($GLOBAL::AuthorizationTimeout);}}sub setForwardedUser{(my $login
=shift (@_));(my $address=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x75\x73\x65\x72\x20\x6c\x6f\x67\x69\x6e\x20\x27"
.$login)."\x27\x2e"));if ((not (defined ($login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x73\x65\x74\x46\x6f\x72\x77\x61\x72\x64\x65\x64\x55\x73\x65\x72\x3a\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x6c\x6f\x67\x69\x6e\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}my ($result);my ($password);my ($sessionFileData);(my $remoteIp=
NXClientConnection::getRemoteIp ());if ((NXGuestsManager::isGuestByUsername (
$login)or NXGuestsManager::isRequestForNewGuestAccount ($login))){
setGuestIsLogged ();(($result,$login,$password,$sessionFileData)=
NXGuestsManager::getGuestLoginPasswordAndSessionFileData ($login,$remoteIp,
$password));}else{unsetGuestIsLogged ();}($__nxuser=NXUser::new ($login,
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e"))
;setAdministratorPropertyForLoggedUser ();(my $authMethod=getAuthMethod ());
Logger::info ((((((("\x55\x73\x65\x72\x20\x27".$login).
"\x27\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres).
"\x27\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
).$authMethod)."\x2e"));($__foreign_addres=$address);
checkPerUserNodeConfigurationFile ($login);__setAbsoluteNameForLoggedUser (
$login);}sub set{(my ($nxuser,$foreign_addres,$password_type,$local_addres,
$sessionType)=@_);Logger::debug (((((((((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x6e\x78\x75\x73\x65\x72\x20\x27"
.$nxuser)."\x27\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x27").$foreign_addres).
"\x27\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x27").$password_type).
"\x27\x20\x6c\x6f\x63\x61\x6c\x20\x27").$local_addres)."\x27\x2e"));if ((not (
defined ($nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x4e\x58\x55\x73\x65\x72\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($local_addres)))){($local_addres=());}if ((not (defined (
$password_type)))){($password_type="\x75\x6e\x6b\x6e\x6f\x77\x6e");}if ((not (
length ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$foreign_addres)."\x27"));}(my $login=$nxuser->getLogin);if ((not (length (
$login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x27\x4e\x58\x55\x73\x65\x72\x2e\x4c\x6f\x67\x69\x6e\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$login)."\x27"));}if ((((isNotGuestLogged ()||(!isUseNXPasswords ()))and ((not 
(isServerBrowseGuest ()))and (not (
NXGuestsManager::isServerBrowseGuestAccountName ($login)))))and ((not (
isDesktopGuestLogin ()))and (not (NXGuestsManager::isDesktopGuestAccountName (
$login)))))){if ((not (Common::NXCore::isSystemUserExist ($login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72"
->throw ($login);}}Logger::debug (((((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6e\x78\x75\x73\x65\x72\x20\x27"
.$login).
"\x27\x20\x77\x69\x74\x68\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
).$foreign_addres)."\x27\x2e"));($__nxuser=$nxuser);($__foreign_addres=
$foreign_addres);($__local_addres=$local_addres);($__password_type=
$password_type);($__sessionType=$sessionType);
setAdministratorPropertyForLoggedUser ();(my $authMethod=getAuthMethod ());if ((
$authMethod eq (""))){Logger::error (
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"
);NXShell::handle_command ("\x65\x78\x69\x74");}if (($sessionType ne 
"\x76\x69\x72\x74\x75\x61\x6c")){(my $invited=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x49\x4e\x56\x49\x54\x45\x44"));(my $loginToLog=$login);if (
isAuthenticationMethodAnywhere ()){($loginToLog=NXAnywhereAuth::getUsername ());
}(my $text=(""));if (NXAnywhereAuth::isDefaultUser ()){($text=((((((
"\x55\x73\x65\x72\x20\x27".$loginToLog).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres)."\x27").((
"\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
.$authMethod).
"\x2e\x20\x55\x73\x65\x72\x20\x77\x69\x6c\x6c\x20\x63\x6f\x6e\x74\x69\x6e\x75\x65\x20"
)).(("\x77\x6f\x72\x6b\x69\x6e\x67\x20\x61\x73\x20\x27".$login).
"\x27\x20\x73\x79\x73\x74\x65\x6d\x20\x75\x73\x65\x72\x2e")));}elsif ((($invited
 ne (""))and ($invited ne "\x30"))){($text=(((((("\x55\x73\x65\x72\x20\x27".
$loginToLog).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres)."\x27").((
"\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
.$authMethod)."\x2e\x20")).
"\x55\x73\x65\x72\x20\x77\x61\x73\x20\x69\x6e\x76\x69\x74\x65\x64\x20\x62\x79\x20\x74\x68\x65\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x2e"
));}else{($text=((((("\x55\x73\x65\x72\x20\x27".$loginToLog).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres)."\x27").((
"\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
.$authMethod)."\x2e")));}Logger::info ($text);Logger::statusPush ($text);}else{
();}checkPerUserNodeConfigurationFile ($login);__setAbsoluteNameForLoggedUser (
$login);}sub checkPerUserNodeConfigurationFile{(my $username=shift (@_));if (((
$username ne "\x6e\x78")and (not (
NXGuestsManager::isServerBrowseGuestAccountName ($username))))){(my $userNodeConfigFile
=Common::NXPaths::getUserNodeCfgPath ($username));(my $keyToCheckInNodeConfigFile
=
"\x43\x6f\x6d\x6d\x61\x6e\x64\x58\x64\x70\x79\x69\x6e\x66\x6f\x7c\x43\x6f\x6d\x6d\x61\x6e\x64\x58\x61\x75\x74\x68\x7c\x41\x67\x65\x6e\x74\x58\x31\x31\x56\x65\x63\x74\x6f\x72\x47\x72\x61\x70\x68\x69\x63\x73\x7c\x41\x67\x65\x6e\x74\x4c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x4d\x6f\x64\x65\x7c"
);($keyToCheckInNodeConfigFile.=
"\x44\x69\x73\x70\x6c\x61\x79\x44\x65\x66\x61\x75\x6c\x74\x7c\x44\x69\x73\x70\x6c\x61\x79\x53\x65\x72\x76\x65\x72\x50\x72\x69\x6f\x72\x69\x74\x79\x7c\x44\x69\x73\x70\x6c\x61\x79\x41\x67\x65\x6e\x74\x50\x72\x69\x6f\x72\x69\x74\x79\x7c\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x69\x6d\x65\x6f\x75\x74\x7c"
);($keyToCheckInNodeConfigFile.=
"\x41\x75\x64\x69\x6f\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x7c\x45\x6e\x61\x62\x6c\x65\x41\x75\x64\x69\x6f\x7c\x45\x6e\x61\x62\x6c\x65\x4d\x6f\x75\x6e\x74\x53\x68\x61\x72\x65\x53\x4d\x42\x46\x53\x7c\x45\x6e\x61\x62\x6c\x65\x4d\x6f\x75\x6e\x74\x53\x68\x61\x72\x65\x53\x53\x48\x46\x53\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x43\x55\x50\x53\x53\x75\x70\x70\x6f\x72\x74\x7c\x45\x6e\x61\x62\x6c\x65\x53\x6d\x61\x72\x74\x63\x61\x72\x64\x53\x68\x61\x72\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x50\x72\x69\x6e\x74\x65\x72\x53\x68\x61\x72\x69\x6e\x67\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x44\x69\x73\x6b\x53\x68\x61\x72\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x55\x53\x42\x53\x68\x61\x72\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x4e\x65\x74\x77\x6f\x72\x6b\x53\x68\x61\x72\x69\x6e\x67\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x46\x69\x6c\x65\x54\x72\x61\x6e\x73\x66\x65\x72\x7c\x45\x6e\x61\x62\x6c\x65\x4c\x6f\x63\x61\x6c\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x53\x65\x73\x73\x69\x6f\x6e\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x7c"
);($keyToCheckInNodeConfigFile.=
"\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x69\x73\x70\x6c\x61\x79\x73\x7c\x4e\x58\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x7c"
);($keyToCheckInNodeConfigFile.=
"\x47\x50\x55\x4c\x6f\x61\x64\x42\x61\x6c\x61\x6e\x63\x69\x6e\x67\x41\x6c\x67\x6f\x72\x69\x74\x68\x6d\x7c\x47\x50\x55\x44\x65\x64\x69\x63\x61\x74\x65\x64\x44\x65\x76\x69\x63\x65"
);if (main::parse_config_file ($userNodeConfigFile,$keyToCheckInNodeConfigFile))
{Logger::debug (((
"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x75\x73\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x2e\x20\x46\x69\x6c\x65\x20\x27"
.$userNodeConfigFile).
"\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x20\x6f\x72\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6f\x70\x65\x6e\x2e"
));}}}sub check{(my ($nxuser,$foreign_addres,$password_type,$local_addres)=@_);
if ((not (defined ($nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x4e\x58\x55\x73\x65\x72\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($local_addres)))){($local_addres=());}if ((not (defined (
$password_type)))){($password_type="\x75\x6e\x6b\x6e\x6f\x77\x6e");}if ((not (
length ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$foreign_addres)."\x27"));}(my $login=$nxuser->getLogin);if ((not (length (
$login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x27\x4e\x58\x55\x73\x65\x72\x2e\x4c\x6f\x67\x69\x6e\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$login)."\x27"));}if ((not (Common::NXCore::isSystemUserExist ($login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72"
->throw ($login);}}sub get{unless (defined ($__nxuser)){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__nxuser);}sub getForeignAddres{if ((not (defined ($__nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x46\x6f\x72\x65\x69\x67\x6e\x41\x64\x64\x72\x65\x73\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__foreign_addres);}sub getLocalAddres{if ((not (defined ($__nxuser))
)){"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x4c\x6f\x63\x61\x6c\x41\x64\x64\x72\x65\x73\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__local_addres);}sub getPasswordType{if ((not (defined ($__nxuser)))
){"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x50\x61\x73\x73\x77\x6f\x72\x64\x54\x79\x70\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__password_type);}sub reset{if ((not (defined ($__nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x72\x65\x73\x65\x74\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}(my $tmp_nxuser=$__nxuser->getLogin);(my $tmp_foreign_addres=
$__foreign_addres);if (isAuthenticationMethodAnywhere ()){($tmp_nxuser=
NXAnywhereAuth::getUsername ());}if (NXAnywhereAuth::isDefaultUser ()){
Logger::info ((((("\x55\x73\x65\x72\x20\x27".$tmp_nxuser).
"\x27\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x61\x73\x20\x27").$__nxuser->getLogin)
.((
"\x27\x20\x20\x73\x79\x73\x74\x65\x6d\x20\x75\x73\x65\x72\x20\x66\x72\x6f\x6d\x20\x27"
.$tmp_foreign_addres)."\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x6f\x75\x74\x2e")));
}else{Logger::info ((((("\x55\x73\x65\x72\x20\x27".$tmp_nxuser).
"\x27\x20\x66\x72\x6f\x6d\x20\x27").$tmp_foreign_addres).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x6f\x75\x74\x2e"));}main::nxrequire (
"\x4e\x58\x55\x74\x6d\x70");NXUtmp::remove ();($__nxuser=());($__foreign_addres=
());resetAdministratorPropertyForLoggedUser ();resetQuasiAdminAuthRequired ();
considerAfterLogout ($tmp_nxuser);}sub isAuthenticated{if (
isWebLoginUnrestricted ()){return ((0x0a65+ 171-0x0b0f));}if (defined ($__nxuser
)){(my $login=$__nxuser->getLogin);Logger::debug (((((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x75\x73\x65\x72\x20\x69\x73\x20\x27".$login).
"\x27\x20\x66\x72\x6f\x6d\x20\x27").$__foreign_addres)."\x27"));return (
(0x1b17+ 2260-0x23ea));}Logger::debug (
"\x6e\x6f\x20\x75\x73\x65\x72\x20\x63\x75\x72\x72\x65\x6e\x74\x6c\x79\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e"
);return ((0x01d4+ 7792-0x2044));}sub userIsNxAdministrator{(my $user=shift (@_)
);if ((defined ($user)and ($user ne ("")))){return (
NXAdministratorsManager::userExistInDb ($user));}return ((0x0d75+ 5316-0x2239));
}sub isAdministrator{if (isAuthenticatedWithAdministratorProperty ()){return (
(0x0932+ 4838-0x1c17));}if (NXPublicKeyAuth::isTrustedServerConnection ()){
return ((0x067c+ 3653-0x14c0));}if (exceptionForWindowsCaseUserNX ()){return (
(0x0fe9+ 2109-0x1826));}return (main::effectiveUserIsAdministrator ());}sub 
isAuthenticatedWithAdministratorProperty{if (isAuthenticated ()){if ((
$loggedUserAdministratorProperty eq "\x79\x65\x73")){Logger::debug (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x4c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e"
);return ((0x1722+ 1816-0x1e39));}}return ((0x0d72+ 4721-0x1fe3));}sub 
exceptionForWindowsCaseUserNX{(my $login=Common::NXCore::getEffectiveUsername ()
);Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x45\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x73\x65\x72\x20\x6e\x61\x6d\x65\x20\x27"
.$login)."\x27\x2e"));if (($login eq "\x6e\x78")){return ((0x171d+ 1715-0x1dcf))
;}}sub setAdministratorPropertyForLoggedUser{if (
NXAdministratorsManager::userIsAdministrator ($__nxuser->getLogin)){
setAdministratorPropertyForQuasiAdmin ();}else{
resetAdministratorPropertyForLoggedUser ();}}sub 
setAdministratorPropertyForQuasiAdmin{Logger::debug (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e"
);($loggedUserAdministratorProperty="\x79\x65\x73");}sub 
resetAdministratorPropertyForLoggedUser{Logger::debug (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x52\x65\x73\x65\x74\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e"
);($loggedUserAdministratorProperty="\x6e\x6f");}sub getCurrentUser{
Logger::debug3 (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x47\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x75\x73\x65\x72\x2e"
);my ($user);if ((isAuthenticated ()and (not (isAdministrator ())))){($user=get 
()->getLogin);Logger::debug3 (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x55\x73\x65\x72\x20\x27".$user).
"\x27\x20\x69\x73\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65\x64\x20\x28\x6e\x6f\x74\x20\x61\x64\x6d\x69\x6e\x29\x2e"
));if ((defined ($user)and length ($user))){return ($user);}}if (defined (
$__nxuser)){($user=$__nxuser->getLogin);Logger::debug3 (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x55\x73\x65\x72\x20\x27".$user).
"\x27\x20\x66\x72\x6f\x6d\x20\x6f\x62\x6a\x65\x63\x74\x2e"));}return ($user);}
sub getCurrentAdministrator{my ($user);if ((isAuthenticated ()and 
isAdministrator ())){($user=get ()->getLogin);}if ((defined ($user)and length (
$user))){return ($user);}return (());}sub isUseNXUsers{return ($__flagUseNXUsers
);}sub isUseNXPasswords{return ($__flagUseNXPasswords);}sub isGuestLogged{return
 ($__flagGuestIsLogged);}sub isNotGuestLogged{return ((!isGuestLogged ()));}sub 
setGuestIsLogged{($__flagGuestIsLogged=(0x0c68+  44-0x0c93));}sub 
unsetGuestIsLogged{($__flagGuestIsLogged=(0x16ad+ 1931-0x1e38));}sub 
isServerBrowseGuest{if (($serverBrowseGuest==(0x0563+ 5391-0x1a71))){return (
(0x1f8c+ 803-0x22ae));}return ((0x0027+ 3311-0x0d16));}sub setServerBrowseGuest{
($serverBrowseGuest=(0x1011+ 5335-0x24e7));}sub clearServerBrowseGuest{(
$serverBrowseGuest=(0x16d3+ 3388-0x240f));}sub setTrueGuestLogin{(
$trueGuestLogin=(0x1b59+ 919-0x1eef));}sub isTrueGuestLogin{if (($trueGuestLogin
==(0x1e23+ 1316-0x2346))){return ((0x188a+ 3017-0x2452));}return (
(0x133d+ 890-0x16b7));}sub isDesktopGuestLogin{if (($desktopGuestLogin==
(0x020a+ 2730-0x0cb3))){return ((0x195c+ 130-0x19dd));}return (
(0x0911+ 5632-0x1f11));}sub setPhysicalDesktopGuestLogin{($desktopGuestLogin=
(0x0801+  40-0x0828));($physicalDesktopGuestLogin=(0x02a0+ 5506-0x1821));}sub 
isPhysicalDesktopGuestLogin{if (($physicalDesktopGuestLogin==
(0x0e97+ 5687-0x24cd))){return ((0x23fd+ 628-0x2670));}return (
(0x04f2+ 852-0x0846));}sub setVirtualDesktopGuestLogin{($desktopGuestLogin=
(0x01c3+ 3565-0x0faf));($virtualDesktopGuestLogin=(0x0cf2+ 4261-0x1d96));}sub 
isVirtualDesktopGuestLogin{if (($virtualDesktopGuestLogin==(0x0c71+ 2149-0x14d5)
)){return ((0x1183+ 3156-0x1dd6));}return ((0x164f+ 2970-0x21e9));}sub 
getLocalAccountName{(my $login=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20\x6c\x6f\x67\x69\x6e\x20\x27"
.$login).
"\x27\x20\x74\x6f\x20\x74\x68\x65\x20\x6c\x6f\x63\x61\x6c\x20\x61\x63\x63\x6f\x75\x6e\x74\x20\x6e\x61\x6d\x65\x2e"
));(my $SID=Common::NXCore::userInfoGetUidByUsername ($login));if (($SID==(-
(0x012f+ 6294-0x19c4)))){Logger::warning (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x53\x49\x44\x20\x66\x6f\x72\x20\x6c\x6f\x67\x69\x6e\x3a\x20"
.$login)."\x2e"));return ($login);}(my $localAccountName=
Common::NXCore::convertWindowsSidToUsername ($SID));if (($localAccountName eq 
(""))){Logger::warning (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x6c\x6f\x63\x61\x6c\x20\x61\x63\x63\x6f\x75\x6e\x74\x20\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x53\x49\x44\x3a\x20"
.$SID)."\x2e"));return ($login);}Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x4c\x6f\x63\x61\x6c\x20\x61\x63\x63\x6f\x75\x6e\x74\x20\x6e\x61\x6d\x65\x3a\x20"
.$localAccountName)."\x2e"));return ($localAccountName);}sub isInternalUsername{
(my $username=shift (@_));if (NXProfiles::isInternalKey ($username)){return (
(0x03f1+ 1626-0x0a4a));}if (NXGuestsManager::isRequestForNewGuestAccount (
$username)){return ((0x0f6c+ 153-0x1004));}if (
NXGuestsManager::isServerBrowseGuestAccountName ($username)){return (
(0x1599+ 2819-0x209b));}if (NXGuestsManager::isDesktopGuestAccountName (
$username)){return ((0x1bbf+ 2270-0x249c));}main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");if (
NXUsersManager::isDMUser ($username)){return ((0x1415+ 2410-0x1d7e));}return (
(0x1d86+ 2189-0x2613));}sub getAbsoluteNameForUsername{(my $username=shift (@_))
;my ($absoluteUsername);if (isInternalUsername ($username)){return ($username);}
($absoluteUsername=getLocalAccountName ($username));if (($absoluteUsername==(-
(0x0b77+ 1330-0x10a8)))){Logger::warning (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x61\x62\x73\x6f\x6c\x75\x74\x65\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x3a\x20"
.$username)."\x2e"));return ($username);}return ($absoluteUsername);}sub 
getAbsoluteNameForUsernameIfNotDisabled{(my $username=shift (@_));if ((
$GLOBAL::DisableUsernameConversion!=(0x04ac+ 2375-0x0df2))){return (
getAbsoluteNameForUsername ($username));}return ($username);}sub 
__setAbsoluteNameForLoggedUser{(my $loggedUser=shift (@_));($absoluteName=
getAbsoluteNameForUsername ($loggedUser));}sub getAbsoluteNameForLoggedUser{
return ($absoluteName);}sub __authMethodIsNotAllowed{if (
Server::isClientNxserver ()){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x69\x73\x20\x61\x6c\x77\x61\x79\x73\x20\x61\x6c\x6c\x6f\x77\x65\x64\x2e"
);return ((0x090b+ 2903-0x1462));}if (isAuthenticationMethodAnywhere ()){if (
Server::isAnywhereDisabled ()){return ((0x0f92+ 4966-0x22f7));}return (
(0x0ac0+ 126-0x0b3e));}(my (@allowed)=split ( /,/ ,lc (
$GLOBAL::AcceptedAuthenticationMethods),(0x001c+ 2850-0x0b3e)));foreach my $method
 (@allowed){if (($method eq "\x61\x6c\x6c")){return ((0x02a3+ 2724-0x0d47));}if 
((($method eq "\x6e\x78\x2d\x70\x61\x73\x73\x77\x6f\x72\x64")and 
isAuthenticationMethodBasedOnNXPassword ())){return ((0x0d34+ 4163-0x1d77));}if 
((($method eq "\x6e\x78\x2d\x70\x72\x69\x76\x61\x74\x65\x2d\x6b\x65\x79")and 
isAuthenticationMethodNXPublicKey ())){return ((0x07e8+ 2768-0x12b8));}if (((
$method eq "\x6e\x78\x2d\x6b\x65\x72\x62\x65\x72\x6f\x73")and 
isAuthenticationMethodNXGSS ())){return ((0x01ff+ 978-0x05d1));}if ((($method eq
 "\x73\x73\x68\x2d\x73\x79\x73\x74\x65\x6d")and 
isAuthenticationMethodBasedOnSSHSystem ())){return ((0x13ec+ 3662-0x223a));}if (
(($method eq "\x73\x73\x68\x2d\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65")and 
isAuthenticationMethodBasedOnSSHPassword ())){return ((0x0e2b+ 3041-0x1a0c));}}
if (isAuthenticationMethodOneTimePassword ()){return ((0x09dc+ 4715-0x1c47));}if
 (isAuthenticationMethodNotRequired ()){return ((0x06b9+ 7127-0x2290));}return (
(0x00e4+ 1145-0x055c));}sub __setAuthMethod{(my $method=shift (@_));(my $force=(
shift (@_)||("")));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x5f\x5f\x73\x65\x74\x41\x75\x74\x68\x4d\x65\x74\x68\x6f\x64\x20\x77\x69\x74\x68\x20\x74\x79\x70\x65\x3a\x20"
.$method)."\x2e"));if ((__isNotSetAuthenticationMethod ()or ($force eq 
"\x66\x6f\x72\x63\x65"))){($AuthenticationMethod=$method);}else{Logger::error ((
(((
"\x54\x72\x79\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20\x66\x72\x6f\x6d\x20"
.$AuthenticationMethod)."\x20\x74\x6f\x20").$method)."\x2e"));
NXShell::handle_command ("\x65\x78\x69\x74");}if (__authMethodIsNotAllowed ()){
NXMsg::error (
"\x65\x4e\x6f\x74\x41\x6c\x6c\x6f\x77\x65\x64\x41\x75\x74\x68\x4d\x65\x74\x68\x6f\x64"
,"\x4e\x58\x4c\x6f\x67\x69\x6e",__getAuthMethodToError ());
NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
setAuthenticationMethodNotRequired{__setAuthMethod (
$AuthenticationMethodNotRequired);}sub isAuthenticationMethodNotRequired{if ((
$AuthenticationMethodNotRequired eq getAuthMethod ())){return (
(0x0049+ 4897-0x1369));}return ((0x09f7+ 4976-0x1d67));}sub 
__isNotSetAuthenticationMethod{if (($AuthenticationMethod eq (""))){return (
(0x0261+ 2192-0x0af0));}return ((0x20f6+ 170-0x21a0));}sub getAuthMethod{return 
($AuthenticationMethod);}sub setAuthenticationMethodSSHSystem{if (
__isNotSetAuthenticationMethod ()){__setAuthMethod (
$AuthenticationMethodSSHSystem);}elsif (isAuthenticationMethodBasedOnSSHSystem 
()){Logger::debug (((((
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20"
.$AuthenticationMethod).
"\x2c\x20\x64\x6f\x6e\x27\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x69\x74\x20\x74\x6f\x20"
).$AuthenticationMethodSSHSystem)."\x2e"));}else{__setAuthMethod (
$AuthenticationMethodSSHSystem);}}sub isAuthenticationMethodBasedOnSSHSystem{if 
(isAuthenticationMethodSSHSystemForwardKerberosKey ()){return (
(0x10d9+ 3839-0x1fd7));}if (isAuthenticationMethodSSHSystemForwardAgentKey ()){
return ((0x1588+ 702-0x1845));}if (($AuthenticationMethodSSHSystem eq 
getAuthMethod ())){return ((0x229b+ 312-0x23d2));}return ((0x1a9f+ 3011-0x2662))
;}sub setAuthenticationMethodAnywhere{__setAuthMethod (
$AuthenticationMethodAnywhere);}sub isAuthenticationMethodAnywhere{if ((
$AuthenticationMethodAnywhere eq getAuthMethod ())){return (
(0x0522+ 5478-0x1a87));}return ((0x041a+ 8631-0x25d1));}sub 
setAuthenticationMethodSSHSystemForwardKerberosKey{__setAuthMethod (
$AuthenticationMethodSSHSystemForwardKerberosKey);}sub 
isAuthenticationMethodSSHSystemForwardKerberosKey{if ((
$AuthenticationMethodSSHSystemForwardKerberosKey eq getAuthMethod ())){return (
(0x0567+ 2706-0x0ff8));}return ((0x07a0+ 6745-0x21f9));}sub 
setAuthenticationMethodSSHSystemForwardAgentKey{__setAuthMethod (
$AuthenticationMethodSSHSystemForwardAgentKey);}sub 
isAuthenticationMethodSSHSystemForwardAgentKey{if ((
$AuthenticationMethodSSHSystemForwardAgentKey eq getAuthMethod ())){return (
(0x057b+ 1820-0x0c96));}return ((0x0269+ 6923-0x1d74));}sub 
setAuthenticationMethodNXGSS{__setAuthMethod ($AuthenticationMethodNXGSS);}sub 
isAuthenticationMethodNXGSS{if (($AuthenticationMethodNXGSS eq getAuthMethod ())
){return ((0x0235+ 2067-0x0a47));}return ((0x01d5+ 6992-0x1d25));}sub 
setAuthenticationMethodNXPublicKey{__setAuthMethod (
$AuthenticationMethodNXPublicKey);}sub isAuthenticationMethodNXPublicKey{if ((
$AuthenticationMethodNXPublicKey eq getAuthMethod ())){return (
(0x0818+ 3099-0x1432));}return ((0x047b+ 7884-0x2347));}sub 
setAuthenticationMethodQuick{if (Server::isConnectionTypeNXD ()){__setAuthMethod
 ($AuthenticationMethodNXQuick);}else{__setAuthMethod (
$AuthenticationMethodSSHQuick);}}sub isAuthenticationMethodNXQuick{if ((
$AuthenticationMethodNXQuick eq getAuthMethod ())){return ((0x0267+ 8553-0x23cf)
);}return ((0x0db1+ 5422-0x22df));}sub isAuthenticationMethodSSHQuick{if ((
$AuthenticationMethodSSHQuick eq getAuthMethod ())){return (
(0x0ed1+ 4358-0x1fd6));}return ((0x0912+ 253-0x0a0f));}sub 
isAuthenticationMethodBasedOnQuick{if (isAuthenticationMethodNXQuick ()){return 
((0x0996+ 1198-0x0e43));}if (isAuthenticationMethodSSHQuick ()){return (
(0x0499+ 1380-0x09fc));}return ((0x0329+ 8787-0x257c));}sub 
changeAuthenticationMethodPassword{setAuthenticationMethodPassword (
"\x66\x6f\x72\x63\x65");}sub setAuthenticationMethodPassword{(my $force=shift (
@_));if (Server::isConnectionTypeNXD ()){if (isUseNXPasswords ()){
__setAuthMethod ($AuthenticationMethodNXpasswordDB,$force);}else{__setAuthMethod
 ($AuthenticationMethodNXpassword,$force);}}elsif (Server::isConnectionTypeSSHD 
()){if (isUseNXPasswords ()){__setAuthMethod ($AuthenticationMethodSSHpasswordDB
,$force);}else{__setAuthMethod ($AuthenticationMethodSSHpassword,$force);}}elsif
 (isConnectionMethodSSH ()){if (isUseNXPasswords ()){__setAuthMethod (
$AuthenticationMethodSSHpasswordDB,$force);}else{__setAuthMethod (
$AuthenticationMethodSSHpassword,$force);}}else{if (isUseNXPasswords ()){
__setAuthMethod ($AuthenticationMethodPasswordDB,$force);}else{__setAuthMethod (
$AuthenticationMethodPassword,$force);}}}sub 
isAuthenticationMethodBasedOnPassword{if (
isAuthenticationMethodBasedOnNXPassword ()){return ((0x1d7a+ 1540-0x237d));}if (
isAuthenticationMethodBasedOnSSHPassword ()){return ((0x0260+ 3874-0x1181));}if 
(($AuthenticationMethodPasswordDB eq getAuthMethod ())){return (
(0x0a5f+ 7112-0x2626));}if (($AuthenticationMethodPassword eq getAuthMethod ()))
{return ((0x0d49+ 5643-0x2353));}return ((0x23a2+ 741-0x2687));}sub 
isAuthenticationMethodBasedOnNXPassword{if (($AuthenticationMethodNXpassword eq 
getAuthMethod ())){return ((0x1ed9+ 2001-0x26a9));}if ((
$AuthenticationMethodNXpasswordDB eq getAuthMethod ())){return (
(0x0cd7+ 4645-0x1efb));}if (isAuthenticationMethodNXQuick ()){return (
(0x11d9+ 1044-0x15ec));}return ((0x1805+ 1568-0x1e25));}sub 
isAuthenticationMethodBasedOnSSHPassword{if (($AuthenticationMethodSSHpassword 
eq getAuthMethod ())){return ((0x1015+ 2391-0x196b));}if ((
$AuthenticationMethodSSHpasswordDB eq getAuthMethod ())){return (
(0x130f+ 2325-0x1c23));}if (isAuthenticationMethodSSHQuick ()){return (
(0x0174+ 9496-0x268b));}return ((0x0b4c+ 2579-0x155f));}sub 
setAuthenticationMethodMD5{__setAuthMethod ($AuthenticationMethodmd5);}sub 
isAuthenticationMethodMD5{if (($AuthenticationMethodmd5 eq getAuthMethod ())){
return ((0x074f+ 3713-0x15cf));}return ((0x1dd3+ 368-0x1f43));}sub 
setAuthenticationMethodOneTimePassword{__setAuthMethod (
$AuthenticationMethodOneTimePassword);}sub isAuthenticationMethodOneTimePassword
{if (($AuthenticationMethodOneTimePassword eq getAuthMethod ())){return (
(0x10c2+ 2812-0x1bbd));}return ((0x186c+ 874-0x1bd6));}sub 
__getAuthMethodToError{if (isAuthenticationMethodBasedOnSSHPassword ()){return (
$AuthenticationMethodSSHpassword);}if (isAuthenticationMethodBasedOnNXPassword 
()){return ($AuthenticationMethodNXpassword);}return ($AuthenticationMethod);}
sub saveLoginFromPlayer{(my $login=shift (@_));($loginFromPlayer=$login);}sub 
getLoginFromPlayer{return ($loginFromPlayer);}sub getUsernameForRemote{(my $login
=getLoginFromPlayer ());if ((defined ($login)and ("\x6c\x6f\x67\x69\x6e" ne ("")
))){return ($login);}if (defined ($__nxuser)){($login=$__nxuser->getLogin);if ((
defined ($login)and ("\x6c\x6f\x67\x69\x6e" ne ("")))){return ($login);}}
Logger::error (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);(my $backtrace=Carp::longmess ($_));($backtrace=~ s/\n[\s]+/\n/ );(my (@lines)
=split ( /\n/ ,$backtrace,(0x09d8+ 1526-0x0fce)));Logger::multilineError (
"\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x3a",@lines);main::nxexit (
(0x0dc1+ 6160-0x25d0));}sub setLoginConversionToAbsoluteNameAvailable{(
$updateLogin=(0x0272+ 5256-0x16f9));}sub 
__isLoginConversionToAbsoluteNameAvailable{return ($updateLogin);}sub 
__isLoginRequireConversionToAbsoluteName{(my $actualLogin=shift (@_));(my $newLogin
=getAbsoluteNameForUsername ($actualLogin));if (($newLogin ne $actualLogin)){
return ((0x1f9f+ 1341-0x24db));}return ((0x0d69+ 6391-0x2660));}sub 
convertToAbsoluteNameNXUserIfNeeded{(my $username=shift (@_));(my $password=
shift (@_));(my $ref_nxUser=shift (@_));if (
__isLoginConversionToAbsoluteNameAvailable ()){if (
__isLoginRequireConversionToAbsoluteName ($username)){($$ref_nxUser=NXUser::new 
(getAbsoluteNameForUsername ($username),$password));}}}sub 
setConnectionMethodSSH{($__connectionMethodSSH=(0x06f0+ 1360-0x0c3f));}sub 
isConnectionMethodSSH{if (($__connectionMethodSSH==(0x078a+ 5118-0x1b87))){
return ((0x1cc9+ 1886-0x2426));}return ((0x05e4+ 7114-0x21ae));}sub isNotNXUser{
(my $username=shift (@_));if (((NXUsersManager::userExistInDb ($username)==
(0x10e0+ 2356-0x1a14))and (NXAdministratorsManager::userExistInDb ($username)==
(0x0bfc+ 336-0x0d4c)))){return ((0x0afc+ 5085-0x1ed8));}return (
(0x0849+ 1960-0x0ff1));}sub __isAuthMethodReportedInFail2banFormat{if ((((
isAuthenticationMethodNXPublicKey ()or isAuthenticationMethodNXGSS ())or 
isAuthenticationMethodBasedOnNXPassword ())or isAuthenticationMethodAnywhere ())
){return ((0x01e5+ 5678-0x1812));}return ((0x0f98+ 3174-0x1bfe));}sub 
reportAuthError{(my $text=shift (@_));(my $remoteIp=
NXClientConnection::getRemoteIp ());(my $method=getAuthMethod ());if (
__isAuthMethodReportedInFail2banFormat ()){Logger::error (((((((
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x77\x69\x74\x68\x20\x27"
.$method)."\x27\x20\x66\x72\x6f\x6d\x20\x68\x6f\x73\x74\x20\x27").$remoteIp).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27"
).$text)."\x27\x2e"));}else{Logger::error (((((((
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x77\x69\x74\x68\x20\x27"
.$method).
"\x27\x20\x66\x72\x6f\x6d\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x73\x65\x72\x76\x65\x72\x20\x68\x6f\x73\x74\x20\x77\x69\x74\x68\x20\x49\x50\x20\x27"
).$remoteIp).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27"
).$text)."\x27\x2e"));}}sub __setUserLoggedInThroughNXClient{(
$__userLoggedInThroughNXClient=(0x09e6+ 4593-0x1bd6));}sub 
__setUserLoggedOutThroughNXClient{($__userLoggedInThroughNXClient=
(0x1d3f+ 2473-0x26e8));}sub isUserStillLoggedInThroughNXClient{return (
$__userLoggedInThroughNXClient);}sub considerBeforeLogin{if ((
Server::isClientNxclient ()or Server::isClientNxwebclient ())){
NXEvent::beforeLogin ();}}sub considerAfterLogin{(my $user=shift (@_));if ((
Server::isClientNxclient ()or Server::isClientNxwebclient ())){
NXEvent::afterLogin ($user);__setUserLoggedInThroughNXClient ();}}sub 
considerAfterLogout{(my $user=shift (@_));if ((
isUserStillLoggedInThroughNXClient ()or Server::isConnectionForwarded ())){if ((
$user eq (""))){($user=getCurrentUser ());}__setUserLoggedOutThroughNXClient ();
NXEvent::afterLogout ($user);}}sub addUserLoginToDB{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x69\x6e\x63\x72\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x6c\x6f\x67\x69\x6e\x73\x0a"
);NXRedis::setServerType ($loginServerTypeName);}sub deleteUserLoginFromDB{
NXRedis::unsetServerType ($loginServerTypeName);}sub getUserLoginsCount{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x6c\x6f\x67\x69\x6e\x73\x0a"
);(my $count=NXRedis::get ());return ($count);}sub 
getCurrentlyLoggedInUsersCount{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x66\x69\x65\x6c\x64\x3d\x6c\x69\x73\x74\x0a"
);(my $listString=NXRedis::get ());(my (@listArray)=split ( /\n/ ,$listString,
(0x0b78+ 5276-0x2014)));(my $count=(0x0a4b+ 595-0x0c9e));foreach my $client (
@listArray){(my (@fields)=split ( / / ,$client,(0x0d84+ 4994-0x2106)));(my $serverTypes
=$fields[(0x011c+ 5938-0x184b)]);if (($serverTypes=~ /\b$loginServerTypeName\b/ )
){(++$count);}}return ($count);}sub isWebAccessLogin{(my $shell=
Server::getShellData ());if (($shell eq "\x77\x65\x62\x6c\x6f\x67\x69\x6e")){
return ((0x1084+ 170-0x112d));}return ((0x0101+ 1391-0x0670));}sub 
isWebAccessUnrestricted{if (($GLOBAL::WebAccessType eq 
"\x75\x6e\x72\x65\x73\x74\x72\x69\x63\x74\x65\x64")){return (
(0x1cef+ 2449-0x267f));}return ((0x16d2+ 1496-0x1caa));}sub 
isWebAccessSystemLogin{if (($GLOBAL::WebAccessType eq 
"\x73\x79\x73\x74\x65\x6d\x6c\x6f\x67\x69\x6e")){return ((0x148a+ 2858-0x1fb3));
}return ((0x0ce9+ 5942-0x241f));}sub isWebAccessNetworkLogin{if ((
$GLOBAL::WebAccessType eq "\x6e\x65\x74\x77\x6f\x72\x6b\x6c\x6f\x67\x69\x6e")){
return ((0x0e17+ 2962-0x19a8));}return ((0x086b+ 4630-0x1a81));}sub 
setWebLoginUnresticted{($__flagWebLoginUnrestricted=(0x0ba6+ 6732-0x25f1));}sub 
isWebLoginUnrestricted{return ($__flagWebLoginUnrestricted);}sub 
isForwardingUserToRemoteServer{return ($forwardingUserToRemoteServer);}sub 
setForwardingUserToRemoteServer{($forwardingUserToRemoteServer=
(0x0e31+ 3206-0x1ab6));}sub setQuasiAdminAuthRequired{Logger::debug (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x53\x65\x74\x20\x71\x75\x61\x73\x69\x2d\x61\x64\x6d\x69\x6e\x20\x61\x75\x74\x68\x20\x72\x65\x71\x75\x69\x72\x65\x64\x2e"
);($quasiAdminAuthRequired=(0x0d15+ 1750-0x13ea));}sub 
resetQuasiAdminAuthRequired{Logger::debug (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x52\x65\x73\x65\x74\x20\x71\x75\x61\x73\x69\x2d\x61\x64\x6d\x69\x6e\x20\x61\x75\x74\x68\x20\x72\x65\x71\x75\x69\x72\x65\x64\x2e"
);($quasiAdminAuthRequired=(0x0a04+ 6026-0x218e));}sub isQuasiAdminAuthRequired{
if (($quasiAdminAuthRequired==(0x0108+ 4157-0x1144))){Logger::debug (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x51\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x20\x61\x75\x74\x68\x20\x72\x65\x71\x75\x69\x72\x65\x64\x2e"
);return ((0x1ad0+ 2896-0x261f));}return ((0x01cc+ 4512-0x136c));}sub 
checkIfClientIsQuasiAdmin{();}sub setVisitor{($visitor=shift (@_));Logger::debug
 (((
"\x47\x75\x65\x73\x74\x41\x63\x63\x65\x73\x73\x3a\x20\x53\x65\x74\x20\x76\x69\x73\x69\x74\x6f\x72\x20\x27"
.$visitor)."\x27\x2e"));}sub getVisitor{return ($visitor);}sub isVisitor{if ((
$visitor ne (""))){return ((0x03d3+ 1276-0x08ce));}return ((0x234b+ 334-0x2499))
;}sub setVisitorHost{($visitorHost=shift (@_));Logger::debug (((
"\x47\x75\x65\x73\x74\x41\x63\x63\x65\x73\x73\x3a\x20\x53\x65\x74\x20\x76\x69\x73\x69\x74\x6f\x72\x20\x68\x6f\x73\x74\x20\x27"
.$visitorHost)."\x27\x2e"));}sub getVisitorHost{return ($visitorHost);}sub 
setVisitorLongName{($visitorLongName=shift (@_));Logger::debug (((
"\x56\x69\x73\x69\x74\x6f\x72\x41\x63\x63\x65\x73\x73\x3a\x20\x53\x65\x74\x20\x76\x69\x73\x69\x74\x6f\x72\x20\x6c\x6f\x6e\x67\x20\x6e\x61\x6d\x65\x20\x27"
.$visitorLongName)."\x27\x2e"));setUserFullName ($visitorLongName);}sub 
getVisitorLongName{return ($visitorLongName);}sub setUserFullName{(my $fullName=
shift (@_));($fullName=main::urldecode ($fullName));Logger::debug (((
"\x53\x65\x74\x20\x75\x73\x65\x72\x20\x66\x75\x6c\x6c\x20\x6e\x61\x6d\x65\x3a\x20"
.$fullName)."\x2e"));($userFullName=$fullName);}sub getUserFullName{(my $fullName
=$userFullName);if (($fullName ne (""))){Logger::debug (((
"\x47\x65\x74\x20\x75\x73\x65\x72\x20\x66\x75\x6c\x6c\x20\x6e\x61\x6d\x65\x3a\x20"
.$fullName)."\x2e"));return ($fullName);}else{return (undef);}}sub 
setTokenAuthorizedUser{($tokenAuthorizedUser=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x74\x6f\x6b\x65\x6e\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x75\x73\x65\x72\x20\x27"
.$tokenAuthorizedUser)."\x27\x2e"));}sub isTokenAuthorizedUser{(my $user=shift (
@_));if (($user eq $tokenAuthorizedUser)){return ((0x1abb+ 1396-0x202e));}return
 ((0x1733+ 1361-0x1c84));}NXMsg::register_error ("\x4e\x58\x4c\x6f\x67\x69\x6e",
"\x65\x4e\x6f\x74\x41\x6c\x6c\x6f\x77\x65\x64\x41\x75\x74\x68\x4d\x65\x74\x68\x6f\x64"
,(0x06b7+ 920-0x085b));return ((0x0d56+ 3682-0x1bb7));
