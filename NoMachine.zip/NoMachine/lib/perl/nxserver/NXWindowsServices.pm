############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXWindowsServices::BEGIN{package NXWindowsServices;no warnings;require NXMsg
;do{"\x4e\x58\x4d\x73\x67"->import};}package NXWindowsServices;no warnings;(
$serviceRunning="\x72\x75\x6e\x6e\x69\x6e\x67");($serviceNotExists=
"\x6e\x6f\x74\x45\x78\x69\x73\x74");($serviceNotRunning=
"\x6e\x6f\x74\x52\x75\x6e\x6e\x69\x6e\x67");($serviceCannotGetStatus=
"\x63\x61\x6e\x6e\x6f\x74\x47\x65\x74\x53\x74\x61\x74\x75\x73");(
$nodeStatusAlready=undef);sub getServiceStatusNotExists{return (
$serviceNotExists);}sub getServiceStatusNotRunning{return ($serviceNotRunning);}
sub getServiceStatusRunning{return ($serviceRunning);}sub 
getServiceCannotGetStatus{return ($serviceCannotGetStatus);}sub serviceStatus{(my $serviceName
=shift (@_));if ((not (NXSystemDaemons::isFeatureEnabled ($serviceName)))){
return (getServiceStatusNotExists ());}(my (@command)=$GLOBAL::CommandNXService)
;push (@command,"\x2d\x2d\x6e\x6f\x64\x61\x65\x6d\x6f\x6e");push (@command,
"\x2d\x2d\x73\x74\x61\x74\x75\x73");push (@command,$serviceName);(my (@options)=
());(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(
\@options)));chomp ($cmd_out);Logger::debug ((((
"\x53\x74\x61\x74\x75\x73\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x20".
$serviceName)."\x20\x69\x73\x20").$cmd_out));if (($cmd_out=~ /Running/ )){return
 (getServiceStatusRunning ());}if (($cmd_out=~ /Starting/ )){return (
getServiceStatusNotRunning ());}if (($cmd_out=~ /Stopped/ )){return (
getServiceStatusNotRunning ());}if (($cmd_out=~ /Stopping/ )){return (
getServiceStatusNotRunning ());}if (($cmd_out=~ /Not installed/ )){return (
getServiceStatusNotExists ());}Logger::warning (((((
"\x55\x6e\x68\x61\x6e\x64\x6c\x65\x64\x20\x62\x65\x68\x61\x76\x69\x6f\x75\x72\x20\x6f\x66\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x27"
.join ($",@command))."\x27\x20\x5b").$cmd_out)."\x5d"));return (
getServiceCannotGetStatus ());}sub getStatusOfServicesAndRemember{(my $servicesToCheck
=__getNXDevicesServicesList ());Logger::debug ((
"\x43\x68\x65\x63\x6b\x20\x73\x74\x61\x74\x75\x73\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20"
.$servicesToCheck));(my (@command)=$GLOBAL::CommandNXService);(@allServices=());
push (@command,"\x2d\x2d\x6e\x6f\x64\x61\x65\x6d\x6f\x6e");push (@command,
"\x2d\x2d\x73\x74\x61\x74\x75\x73");push (@command,$servicesToCheck);(my (
@options)=());(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command
),(\@options)));if (($exit_value ne (0x03d8+ 3602-0x11ea))){Logger::warning ((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x61\x69\x6c\x65\x64\x20".join ($",@command
)));return ((0x1137+ 3464-0x1ebf));}__saveStatusOfServices ($cmd_out);return (
(0x1991+ 973-0x1d5d));}sub __saveStatusOfServices{(my $statusOfServices=shift (
@_));($statusOfServices=~ s/\r\n/\n/g );chomp ($statusOfServices);Logger::debug 
((
"\x53\x61\x76\x65\x20\x73\x74\x61\x74\x75\x73\x20\x6f\x66\x20\x61\x6c\x6c\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20"
.$statusOfServices));(my (@lines)=split ( /\n/ ,$statusOfServices,
(0x0f2a+ 2160-0x179a)));foreach my $line (@lines){if (($line=~ /^(\w+)\s([\w\s]*)$/ )
){(my $service=$1);(my $status=$2);Logger::debug (((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service).
"\x27\x20\x68\x61\x73\x20\x73\x74\x61\x74\x75\x73\x20\x27").$status)."\x27\x2e")
);($statusOfService{$service}=$status);push (@allServices,$service);}else{
Logger::warning ((
"\x53\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x6c\x69\x6e\x65\x20\x6e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20"
.$line));}}return ((0x0754+ 1229-0x0c20));}sub setNodeStatusAlready{(
$nodeStatusAlready=(0x1ce1+ 2175-0x255f));}sub getNodeStatusAlready{return (
$nodeStatusAlready);}sub resetNodeStatusAlready{($nodeStatusAlready=undef);}sub 
stopService{(my $serviceName=shift (@_));(my $silence=shift (@_));(my (@command)
=$GLOBAL::CommandNXService);push (@command,
"\x2d\x2d\x64\x69\x73\x61\x62\x6c\x65");push (@command,$serviceName);(my (
@options)=());(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command
),(\@options)));if (($exit_value eq (0x0678+ 2607-0x10a7))){if (($cmd_out=~ /Already stopped/ )
){if ((not ($silence))){NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}
return ((0x0d17+ 4637-0x1f34));}if ((($serviceName eq "\x6e\x78\x73\x73\x68\x64"
)or ($serviceName eq "\x6e\x78\x68\x74\x64"))){main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ($serviceName);}if
 ((not ($silence))){NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
else{if ((not ($silence))){NXMsg::send_response (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
return ((0x16f4+ 3023-0x22c3));}sub getServiceStatusFromMemory{(my $serviceName=
shift (@_));if ((not (defined ($statusOfService{$serviceName})))){
Logger::warning (((
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20".$serviceName)
."\x20\x73\x74\x61\x74\x75\x73"));return ((0x0960+ 6109-0x213d));}if (defined (
$statusOfService{$serviceName})){Logger::debug ((((
"\x52\x65\x61\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x20"
.$serviceName)."\x20").$statusOfService{$serviceName}));if (($statusOfService{
$serviceName}eq "\x52\x75\x6e\x6e\x69\x6e\x67")){return (getServiceStatusRunning
 ());}if (($statusOfService{$serviceName}eq "\x53\x74\x6f\x70\x70\x69\x6e\x67"))
{return (getServiceStatusRunning ());}if (($statusOfService{$serviceName}eq 
"\x53\x74\x6f\x70\x70\x65\x64")){return (getServiceStatusNotRunning ());}if ((
$statusOfService{$serviceName}eq "\x53\x74\x61\x72\x74\x69\x6e\x67")){return (
getServiceStatusNotRunning ());}if (($statusOfService{$serviceName}eq 
"\x4e\x6f\x74\x20\x69\x6e\x73\x74\x61\x6c\x6c\x65\x64")){return (
getServiceStatusNotExists ());}if (($statusOfService{$serviceName}eq 
"\x4d\x61\x72\x6b\x65\x64\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65")){return (
getServiceStatusNotRunning ());}Logger::warning ((((
"\x55\x6e\x68\x61\x6e\x64\x6c\x65\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x20"
.$serviceName)."\x20").$statusOfService{$serviceName}));}else{Logger::warning ((
("\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20".$serviceName
)."\x20\x73\x74\x61\x74\x75\x73"));}return ((0x04f8+ 641-0x0779));}sub 
__getNXDevicesServicesList{return (
"\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2c\x6e\x78\x70\x72\x69\x6e\x74\x65\x72\x2c\x6e\x78\x73\x73\x68\x64\x2c\x6e\x78\x68\x74\x64"
);}sub stopAllWindowsServices{(my $servicesToStop=__getNXDevicesServicesList ())
;__setServicesSilence ();Logger::debug ((
"\x53\x74\x6f\x70\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20"
.$servicesToStop));(my (@command)=$GLOBAL::CommandNXService);push (@command,
"\x2d\x2d\x6e\x6f\x64\x61\x65\x6d\x6f\x6e");push (@command,
"\x2d\x2d\x64\x69\x73\x61\x62\x6c\x65");push (@command,$servicesToStop);(my (
@options)=());(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command
),(\@options)));(my (@lines)=split ( /\n/ ,$cmd_out,(0x0ac3+ 3822-0x19b1)));
foreach my $line (@lines){if (($line=~ /^(\w*)\s/ )){(my $serviceName=$1);if ((
$servicesToStop=~ /$serviceName/ )){if (($line=~ /Stopped/ )){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x64\x69\x73\x61\x62\x6c\x65\x64"));sendResponseDisabledIfnotSilenced (
$serviceName);}elsif (($line=~ /Already stopped/ )){Logger::debug ((
"\x53\x65\x72\x76\x69\x63\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20"
.$serviceName));if (($serviceName eq "\x6e\x78\x73\x65\x72\x76\x69\x63\x65")){
Logger::debug (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x68\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x66\x6c\x61\x67\x20\x66\x6f\x72\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x6e\x6f\x64\x65\x2c\x20\x73\x65\x72\x76\x69\x63\x65\x20"
.$serviceName)."\x2e"));setNodeStatusAlready ();}
sendResponseAlreadyDisabledIfNotSilenced ($serviceName);}else{if ((not (
killService ($serviceName)))){Logger::warning (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x66\x61\x69\x6c\x65\x64\x2e"
));sendResponseCannotStopIfnotSilenced ($serviceName);}else{Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20".$serviceName)."\x20\x6b\x69\x6c\x6c\x65\x64")
);sendResponseDisabledIfnotSilenced ($serviceName);}}}else{Logger::warning ((
"\x52\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x74\x61\x69\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20"
.$line));}}else{Logger::warning ((
"\x52\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20"
.$line));}}}sub killService{(my $processName=shift (@_));(my $recursive=(shift (
@_)||(0x16dc+ 3050-0x22c5)));(my $timeout=(shift (@_)||(0x15b0+ 4136-0x25d3)));(my (
@command)=$GLOBAL::CommandNXService);push (@command,
"\x2d\x2d\x70\x72\x6f\x63\x65\x73\x73\x6b\x69\x6c\x6c");(my (@parameters)=());
push (@parameters,"\x74\x69\x6d\x65\x6f\x75\x74",$timeout);if ((serviceStatus (
$processName)eq getServiceStatusRunning ())){push (@command,
"\x2d\x2d\x70\x72\x6f\x63\x65\x73\x73\x6e\x61\x6d\x65");push (@command,(
$processName."\x2e\x65\x78\x65"));if ($recursive){push (@command,
"\x2d\x2d\x72\x65\x63\x75\x72\x73\x69\x76\x65");}(my ($cmd_err,$cmd_out,
$exit_value)=main::nxRunCommand ((\@command),(\@parameters)));Logger::debug ((((
"\x45\x78\x65\x63\x75\x74\x65\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20".join ($",
@command))."\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20").$exit_value))
;if ((serviceStatus ($process)eq getServiceStatusRunning ())){Logger::error ((((
(
"\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$process).
"\x27\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6f\x66\x20\x65\x72\x72\x6f\x72\x3a\x20"
).$cmd_err)."\x2e"));return ((0x1167+ 3573-0x1f5c));}}return (
(0x1206+ 4747-0x2490));}sub __getNXDevicesServicesListStartup{(my $sevicesToStart
="\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2c\x6e\x78\x70\x72\x69\x6e\x74\x65\x72")
;return ($sevicesToStart);}sub startWindowsServices{(my $sevicesToStart=
"\x6e\x78\x70\x72\x69\x6e\x74\x65\x72");if ((NXSystemDaemons::isSSHEnabled ()and
 NXSystemDaemons::isSSHStartupKeyEnabled ())){($sevicesToStart.=
"\x2c\x6e\x78\x73\x73\x68\x64");}if ((
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()and 
NXSystemDaemons::isHttpdStartupKeyEnabled ())){($sevicesToStart.=
"\x2c\x6e\x78\x68\x74\x64");}__startWindowServices ($sevicesToStart);}sub 
startNXService{__startWindowServices ("\x6e\x78\x73\x65\x72\x76\x69\x63\x65");}
sub stopNXService{stopService ("\x6e\x78\x73\x65\x72\x76\x69\x63\x65",
(0x0f19+ 2021-0x16fd));}sub __startWindowServices{(my $servicesToStart=shift (@_
));__setServicesSilence ();Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x73\x65\x72\x76\x69\x63\x65\x73\x3a\x20"
.$servicesToStart)."\x2e"));(my (@command)=$GLOBAL::CommandNXService);push (
@command,"\x2d\x2d\x6e\x6f\x64\x61\x65\x6d\x6f\x6e");push (@command,
"\x2d\x2d\x65\x6e\x61\x62\x6c\x65");push (@command,$servicesToStart);push (
@command,"\x2d\x2d\x6e\x6f\x67\x75\x69");(my (@options)=());(my ($cmd_err,
$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options)));(my (@lines)
=split ( /\n/ ,$cmd_out,(0x0b5c+ 5622-0x2152)));(my (@services)=split ( /,/ ,
$servicesToStart,(0x01c8+ 8283-0x2223)));foreach my $line (@lines){if ((scalar (
@services)==(0x0a07+ 4015-0x19b5))){if (($line=~ /Running/ )){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20".$services[(0x071a+ 311-0x0851)]).
"\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"));}elsif (($line=~ /Already running/ )){
Logger::debug ((("\x53\x65\x72\x76\x69\x63\x65\x20".$services[
(0x057b+ 7334-0x2221)]).
"\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));}else{
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$services[(0x1ca2+ 841-0x1feb)])."\x2e"));sendResponseCannotStartIfnotSilenced 
($services[(0x13bb+ 2566-0x1dc1)]);}return ((0x1ca7+ 2535-0x268e));}if (($line=~ /^(\w*)\s/ )
){(my $serviceName=$1);if (($servicesToStart=~ /$serviceName/ )){if (($line=~ /Running/ )
){Logger::debug ((("\x53\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"));}elsif (($line=~ /Already running/ )){
Logger::debug ((("\x53\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));}else{
Logger::warning ((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x53\x74\x61\x72\x74\x20\x66\x61\x69\x6c\x65\x64"));
sendResponseCannotStartIfnotSilenced ($serviceName);}}else{Logger::warning ((
"\x52\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x74\x61\x69\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20"
.$line));}}else{Logger::warning ((
"\x52\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20"
.$line));}}}sub startService{(my $serviceName=shift (@_));(my $silence=shift (@_
));(my (@command)=$GLOBAL::CommandNXService);my ($servicePid);my (
$serviceNameToPrint);push (@command,"\x2d\x2d\x6e\x6f\x64\x61\x65\x6d\x6f\x6e");
push (@command,"\x2d\x2d\x65\x6e\x61\x62\x6c\x65");push (@command,$serviceName);
push (@command,"\x2d\x2d\x6e\x6f\x67\x75\x69");(my (@options)=());(my ($cmd_err,
$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options)));
Logger::debug (((("\x53\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$cmd_out));if (($exit_value eq 
(0x1874+ 3419-0x25cf))){if (($cmd_out=~ /Already running/ )){if ((not ($silence)
)){NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}
return ((0x2216+ 287-0x2335));}if ((($serviceName eq "\x6e\x78\x73\x73\x68\x64")
or ($serviceName eq "\x6e\x78\x68\x74\x64"))){main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToAdd ($serviceName);}if ((
not ($silence))){NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
else{if ((not ($silence))){NXMsg::send_response (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
return ((0x11a3+ 2642-0x1bf5));}sub restartService{(my $serviceName=shift (@_));
(my $silence=shift (@_));stopService ($serviceName,$silence);startService (
$serviceName,$silence);}sub printServiceStatus{(my $serviceName=shift (@_));(my $silence
=shift (@_));(my $serviceStatus=getServiceStatusFromMemory ($serviceName));if ((
(not (defined ($serviceStatus)))or ($serviceStatus==(0x06e9+ 3898-0x1623)))){(
$serviceStatus=serviceStatus ($serviceName));}Logger::debug (((((
"\x54\x68\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x73\x74\x61\x74\x75\x73\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$serviceName)."\x20\x69\x73\x20").$serviceStatus)."\x2e"));if (($serviceStatus 
eq getServiceStatusNotRunning ())){sendResponseDisabledIfnotSilenced (
$serviceName);}elsif (($serviceStatus eq getServiceStatusRunning ())){
sendResponseEnabledIfnotSilenced ($serviceName);}else{Logger::debug (((((
"\x54\x68\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x73\x74\x61\x74\x75\x73\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20\x27"
.$serviceName)."\x27\x20\x69\x73\x20\x27").$serviceStatus)."\x27\x2e"));}return 
($serviceStatus);}sub disableServices{changeServiceStartOption (
"\x6e\x78\x73\x65\x72\x76\x69\x63\x65","\x64\x65\x6d\x61\x6e\x64");}sub 
enableServices{changeServiceStartOption ("\x6e\x78\x73\x65\x72\x76\x69\x63\x65",
"\x61\x75\x74\x6f");}sub setServicesOnDemandToHandleManualStart{if (
NXLicense::isSshFeature ()){changeServiceStartOption ("\x6e\x78\x73\x73\x68\x64"
,"\x64\x65\x6d\x61\x6e\x64");}if (NXLicense::isHttpdSupportFeature ()){
changeServiceStartOption ("\x6e\x78\x68\x74\x64","\x64\x65\x6d\x61\x6e\x64");}}
sub changeServiceStartOption{(my $serviceName=shift (@_));(my $option=shift (@_)
);Logger::debug (((((
"\x43\x68\x61\x6e\x67\x69\x6e\x67\x20\x73\x74\x61\x72\x74\x20\x6f\x70\x74\x69\x6f\x6e\x20\x74\x6f\x20\x5b"
.$option)."\x5d\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x20\x5b").
$serviceName)."\x5d"));(my (@command)=((NXTools::getWindowsSystemPath ().
$GLOBAL::DIRECTORY_SLASH)."\x73\x63\x2e\x65\x78\x65"));push (@command,
"\x63\x6f\x6e\x66\x69\x67");push (@command,$serviceName);push (@command,
"\x73\x74\x61\x72\x74\x3d");push (@command,$option);(my (@options)=());(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options)));}
sub checkWindowsNxServiceStartStatus{(my $serviceName=shift (@_));(my (@command)
=$GLOBAL::CommandNXService);push (@command,
"\x2d\x2d\x73\x65\x72\x76\x69\x63\x65\x73\x74\x61\x72\x74\x74\x79\x70\x65\x67\x65\x74"
);push (@command,$serviceName);(my (@options)=());(my ($cmd_err,$cmd_out,
$exit_value)=main::nxRunCommand ((\@command),(\@options)));chomp ($cmd_out);(
$cmd_out=~ s/\s.*// );($cmd_out=~ s/\n// );if (($cmd_out eq "\x32")){return (
$cmd_out);}elsif (($cmd_out eq "\x33")){return ($cmd_out);}else{return (
(0x082a+ 6261-0x209f));}}sub __setServicesSilence{(my (@listServicesToSilence)=(
"\x6e\x78\x70\x72\x69\x6e\x74\x65\x72","\x6e\x78\x73\x73\x68\x64"));foreach my $serviceName
 (@listServicesToSilence){($silencedServices{$serviceName}=(0x0e06+ 130-0x0e87))
;}if ((not (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()))){(
$silencedServices{"\x6e\x78\x68\x74\x64"}=(0x1ad5+ 216-0x1bac));}}sub 
manageServiceInSilence{(my $serviceName=shift (@_));($silencedServices{
$serviceName}=(0x189f+ 3133-0x24db));}sub __isServiceSilenced{(my $service=shift
 (@_));if (defined ($silencedServices{$service})){return ((0x1782+ 2849-0x22a2))
;}return ((0x01f8+ 1036-0x0604));}sub getServiceNameToResponse{(my $serviceName=
shift (@_));if (($serviceName eq "\x6e\x78\x73\x65\x72\x76\x69\x63\x65")){(
$serviceName="\x6e\x78\x73\x65\x72\x76\x65\x72");}return ($serviceName);}sub 
sendResponseCannotStopIfnotSilenced{(my $serviceName=shift (@_));if (
__isServiceSilenced ($serviceName)){return ((0x17cd+ 1847-0x1f03));}(
$serviceName=getServiceNameToResponse ($serviceName));NXMsg::send_response (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);
return ((0x0181+ 5025-0x1521));}sub sendResponseCannotStartIfnotSilenced{(my $serviceName
=shift (@_));if (__isServiceSilenced ($serviceName)){return (
(0x005c+ 8955-0x2356));}($serviceName=getServiceNameToResponse ($serviceName));
NXMsg::send_response (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);
return ((0x0e9c+ 3761-0x1d4c));}sub sendResponseEnabledIfnotSilenced{(my $serviceName
=shift (@_));if (__isServiceSilenced ($serviceName)){return (
(0x10f3+ 1086-0x1530));}($serviceName=getServiceNameToResponse ($serviceName));
NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);
return ((0x00e1+ 5789-0x177d));}sub sendResponseDisabledIfnotSilenced{(my $serviceName
=shift (@_));if (__isServiceSilenced ($serviceName)){return (
(0x01ec+ 1627-0x0846));}($serviceName=getServiceNameToResponse ($serviceName));
NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);
return ((0x14bf+ 4416-0x25fe));}sub sendResponseAlreadyDisabledIfNotSilenced{(my $serviceName
=shift (@_));if (__isServiceSilenced ($serviceName)){return (
(0x1ab5+ 646-0x1d3a));}($serviceName=getServiceNameToResponse ($serviceName));
NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);
return ((0x0c75+ 5466-0x21ce));}sub sendTerminateToNodeMirror{(my $masterIDPath=
((NXNodeInfo::getNodeInfoDirPath ().$GLOBAL::DIRECTORY_SLASH)."\x69\x64"));if ((
not (Common::NXFile::isExists ($masterIDPath)))){Logger::debug (
"\x4e\x58\x4e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x20\x69\x64\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
);return ((0x123b+ 168-0x12e3));}(my $FH=main::nxopen ($masterIDPath,
$NXBits::O_RDONLY,(0x0af3+ 1480-0x10bb)));unless (defined ($FH)){Logger::error (
(("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".
$masterIDPath)."\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));return (
(0x08e2+ 3764-0x1796));}my ($masterPath);(my $bytes_read=main::nxread ($FH,(
\$masterPath),(0x1ec8+ 5689-0x2501)));main::nxclose ($FH);chomp ($masterPath);(my $sessionCookieFile
=(($masterPath.$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));(my $sessionPortFile
=(($masterPath.$GLOBAL::DIRECTORY_SLASH)."\x70\x6f\x72\x74"));(my $FH=
main::nxopen ($sessionCookieFile,$NXBits::O_RDONLY,(0x0b5b+ 1212-0x1017)));
unless (defined ($FH)){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".
$sessionCookieFile)."\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));
Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring));return ((0x0111+ 9501-0x262e));}(my $bytes_read=
main::nxread ($FH,(\$cookie),(0x1f31+ 4196-0x1f95)));main::nxclose ($FH);($FH=
main::nxopen ($sessionPortFile,$NXBits::O_RDONLY,(0x08dd+ 1956-0x1081)));unless 
(defined ($FH)){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".
$sessionPortFile)."\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));return ((0x1235+ 3997-0x21d2));}($bytes_read=
main::nxread ($FH,(\$port),(0x10e4+ 2893-0x0c31)));main::nxclose ($FH);chomp (
$cookie);chomp ($port);(my $message=
"\x4e\x58\x3e\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x62\x65\x66\x6f\x72\x65\x20\x73\x68\x75\x74\x64\x6f\x77\x6e"
);Logger::debug2 (((
"\x57\x72\x69\x74\x65\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x3a\x20\x5b"
.$message)."\x5d"));(my $auth_string=(
"\x4e\x58\x3e\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6f\x6f\x6b\x69\x65\x3d"
.$cookie));(my $sock=main::nxConnectLocal ($port));if (($sock==(-
(0x0217+ 242-0x0308)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x20\x2d\x2d\x6d\x69\x72\x72\x6f\x72\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x5b"
.$port)."\x5d"));return ((0x040c+ 2228-0x0cc0));}(my $writtenbytes=main::nxwrite
 ($sock,((($auth_string."\x0a").$message)."\x0a")));main::nxclose ($sock);}sub 
checkForNotCleanedSessionAndClean{(my $dirName=
Common::NXPaths::getNodeRootDirectoryPath ());Logger::debug ((
"\x4c\x6f\x6f\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x69\x65\x73\x20\x66\x72\x6f\x6d\x20\x63\x72\x61\x73\x68\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x2e\x20"
.$dirName));if ((not (opendir (DIRHANDLE,$dirName)))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.$dirName)."\x3a\x20").$!));return ((0x0472+  53-0x04a6));}(my (@folders)=
readdir (DIRHANDLE));(my $needCleaning=(0x099c+ 525-0x0ba9));foreach my $dir (
@folders){if (($dir=~ /^C-.*-(\d+)-/ )){main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");NXNodeCleaner::start (
"\x61\x75\x74\x6f","\x30",Common::NXSessionType::getPhysicalDesktop (),
"\x6e\x78");return;}}}return ((0x0092+ 8832-0x2311));
