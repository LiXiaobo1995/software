############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXNodeConfiguration::BEGIN{package NXNodeConfiguration;no warnings;require 
Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
NXNodeConfiguration::BEGIN{package NXNodeConfiguration;no warnings;require 
Exception::NXConfigurator;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x6f\x72"
->import};}sub NXNodeConfiguration::BEGIN{package NXNodeConfiguration;no 
warnings;require Exception::Configuration;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->import};}sub NXNodeConfiguration::BEGIN{package NXNodeConfiguration;no 
warnings;require Exception::Internal;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
import};}sub NXNodeConfiguration::BEGIN{package NXNodeConfiguration;no warnings;
require NXPaths;do{"\x4e\x58\x50\x61\x74\x68\x73"->import};}package 
NXNodeConfiguration;no warnings;($__dbFileName=(NXPaths::getNodeRoot ().
"\x2f\x65\x74\x63\x2f\x6e\x6f\x64\x65\x2e\x63\x66\x67"));($__platform=
"\x52\x45\x44\x48\x41\x54");my (%node_only_keys_names_hash);(
$node_only_keys_names_hash{
"\x43\x6f\x6e\x66\x69\x67\x46\x69\x6c\x65\x56\x65\x72\x73\x69\x6f\x6e"}={
"\x53\x55\x53\x45","\x31\x2e\x30",("\x53\x4c\x41\x43\x4b\x57\x41\x52\x45">
"\x31\x2e\x30"),"\x52\x45\x44\x48\x41\x54","\x31\x2e\x30",
"\x44\x45\x42\x49\x41\x4e","\x31\x2e\x30","\x4d\x41\x4e\x44\x52\x49\x56\x41",
"\x31\x2e\x30","\x53\x4f\x4c\x41\x52\x49\x53","\x31\x2e\x30",
"\x4d\x41\x43\x4f\x53\x58","\x31\x2e\x30","\x43\x4f\x4e\x46\x49\x47",
"\x31\x2e\x30","\x53\x45\x52\x56\x45\x52",(""),
"\x44\x45\x53\x43\x52\x49\x50\x54\x49\x4f\x4e",
"\x47\x65\x6e\x65\x72\x61\x6c\x3a\x20\x43\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x6d\x61\x74\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
});($node_only_keys_names_hash{
"\x53\x65\x73\x73\x69\x6f\x6e\x4c\x6f\x67\x4c\x65\x76\x65\x6c"}={
"\x53\x55\x53\x45","\x36","\x53\x4c\x41\x43\x4b\x57\x41\x52\x45","\x36",
"\x52\x45\x44\x48\x41\x54","\x36","\x44\x45\x42\x49\x41\x4e","\x36",
"\x4d\x41\x4e\x44\x52\x49\x56\x41","\x36","\x53\x4f\x4c\x41\x52\x49\x53","\x36",
"\x4d\x41\x43\x4f\x53\x58","\x36","\x43\x4f\x4e\x46\x49\x47","\x36",
"\x53\x45\x52\x56\x45\x52","\x36","\x44\x45\x53\x43\x52\x49\x50\x54\x49\x4f\x4e"
,
"\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x53\x65\x74\x20\x74\x68\x65\x20\x6c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x6f\x66\x20\x4e\x58\x20\x53\x65\x72\x76\x65\x72\x20\x61\x6e\x64\x20\x4e\x58\x20\x4e\x6f\x64\x65\x2e"
});($node_only_keys_names_hash{
"\x45\x6e\x61\x62\x6c\x65\x55\x6e\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x53\x65\x73\x73\x69\x6f\x6e"
}={"\x53\x55\x53\x45","\x31","\x53\x4c\x41\x43\x4b\x57\x41\x52\x45","\x31",
"\x52\x45\x44\x48\x41\x54","\x31","\x44\x45\x42\x49\x41\x4e","\x31",
"\x4d\x41\x4e\x44\x52\x49\x56\x41","\x31","\x53\x4f\x4c\x41\x52\x49\x53","\x31",
"\x4d\x41\x43\x4f\x53\x58","\x31","\x43\x4f\x4e\x46\x49\x47","\x31",
"\x53\x45\x52\x56\x45\x52","\x31","\x44\x45\x53\x43\x52\x49\x50\x54\x49\x4f\x4e"
,
"\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x41\x6c\x6c\x6f\x77\x20\x74\x68\x65\x20\x75\x73\x65\x20\x6f\x66\x20\x75\x6e\x65\x6e\x63\x72\x79\x70\x74\x69\x6f\x6e\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x2e"
});($node_only_keys_names_hash{
"\x50\x72\x6f\x78\x79\x54\x43\x50\x4e\x6f\x64\x65\x6c\x61\x79"}={
"\x53\x55\x53\x45","\x30","\x53\x4c\x41\x43\x4b\x57\x41\x52\x45","\x30",
"\x52\x45\x44\x48\x41\x54","\x30","\x44\x45\x42\x49\x41\x4e","\x30",
"\x4d\x41\x4e\x44\x52\x49\x56\x41","\x30","\x53\x4f\x4c\x41\x52\x49\x53","\x30",
"\x4d\x41\x43\x4f\x53\x58","\x30","\x43\x4f\x4e\x46\x49\x47","\x30",
"\x53\x45\x52\x56\x45\x52","\x30","\x44\x45\x53\x43\x52\x49\x50\x54\x49\x4f\x4e"
,
"\x41\x67\x65\x6e\x74\x3a\x20\x45\x6e\x61\x62\x6c\x65\x20\x6f\x72\x20\x64\x69\x73\x61\x62\x6c\x65\x20\x54\x43\x50\x5f\x4e\x4f\x44\x45\x4c\x41\x59\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x69\x6e\x20\x4e\x58\x20\x70\x72\x6f\x78\x79\x2e"
});($node_only_keys_names_hash{
"\x53\x53\x48\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x4b\x65\x79\x73"}={
"\x53\x55\x53\x45",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x53\x4c\x41\x43\x4b\x57\x41\x52\x45",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x52\x45\x44\x48\x41\x54",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x44\x45\x42\x49\x41\x4e",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x4d\x41\x4e\x44\x52\x49\x56\x41",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x53\x4f\x4c\x41\x52\x49\x53",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73",
"\x4d\x41\x43\x4f\x53\x58",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x43\x4f\x4e\x46\x49\x47",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x53\x45\x52\x56\x45\x52",
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x5f\x6b\x65\x79\x73\x32",
"\x44\x45\x53\x43\x52\x49\x50\x54\x49\x4f\x4e",
"\x47\x65\x6e\x65\x72\x61\x6c\x3a\x20\x53\x70\x65\x63\x69\x66\x79\x20\x74\x68\x65\x20\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x20\x61\x6e\x64\x20\x66\x69\x6c\x65\x20\x6e\x61\x6d\x65\x20\x6f\x66\x20\x74\x68\x65\x20\x53\x53\x48\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6b\x65\x79\x73\x2e"
});(my $node_only_keys_names_string=
"\x43\x6f\x6e\x66\x69\x67\x46\x69\x6c\x65\x56\x65\x72\x73\x69\x6f\x6e\x2c\x53\x65\x73\x73\x69\x6f\x6e\x4c\x6f\x67\x4c\x65\x76\x65\x6c\x2c\x53\x53\x48\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x4b\x65\x79\x73\x2c\x45\x6e\x61\x62\x6c\x65\x55\x6e\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x53\x65\x73\x73\x69\x6f\x6e\x2c\x50\x72\x6f\x78\x79\x54\x43\x50\x4e\x6f\x64\x65\x6c\x61\x79"
);(my (@node_only_keys_names_array)=split ( /,/ ,$node_only_keys_names_string,
(0x06a8+ 866-0x0a0a)));sub NXNodeConfiguration::listKeyDescriptions (){package 
NXNodeConfiguration;no warnings;(my $list="\x0a");(my $maxName=
(0x0e63+  81-0x0eb4));(my $maxValue=(0x0b14+ 5764-0x2198));my ($key_name);my (
$keyValue);foreach $key_name (@node_only_keys_names_array){($maxName=((length (
$key_name)>$maxName)?length ($key_name):$maxName));($keyValue=
getNodeKeyDescription ("\x6b\x65\x79",$key_name));($maxValue=((length ($keyValue
)>$maxValue)?length ($keyValue):$maxValue));}($list.=(sprintf ((("\x25\x2d".
$maxName)."\x73"),"\x4b\x65\x79")."\x20"));($list.=(sprintf ((("\x25\x2d".
$maxValue)."\x73"),"\x56\x61\x6c\x75\x65")."\x20"));($list.="\x0a");($list.=(
"\x2d" x $maxName));($list.="\x20");($list.=("\x2d" x $maxValue));($list.="\x0a"
);foreach $key_name (@node_only_keys_names_array){($list.=sprintf ((("\x25\x2d".
$maxName)."\x73"),$key_name));($list.="\x20");($keyValue=getNodeKeyDescription (
"\x6b\x65\x79",$key_name));($list.=sprintf ((("\x25\x2d".$maxValue)."\x73"),
$keyValue));($list.="\x0a");}return ($list);}sub 
NXNodeConfiguration::listKeyValues (){package NXNodeConfiguration;no warnings;(my $list
="\x0a");(my $maxName=(0x03e7+ 4146-0x1419));(my $maxValue=(0x1147+ 3645-0x1f84)
);my ($key_name);my ($keyValue);foreach $key_name (@node_only_keys_names_array){
($maxName=((length ($key_name)>$maxName)?length ($key_name):$maxName));(
$keyValue=getCurrentNodeKeyValue ("\x6b\x65\x79",$key_name,
"\x70\x6c\x61\x74\x66\x6f\x72\x6d","\x53\x45\x52\x56\x45\x52"));($maxValue=((
length ($keyValue)>$maxValue)?length ($keyValue):$maxValue));}($list.=(sprintf (
(("\x25\x2d".$maxName)."\x73"),"\x4b\x65\x79")."\x20"));($list.=(sprintf (((
"\x25\x2d".$maxValue)."\x73"),"\x56\x61\x6c\x75\x65")."\x20"));($list.="\x0a");(
$list.=("\x2d" x $maxName));($list.="\x20");($list.=("\x2d" x $maxValue));($list
.="\x0a");foreach $key_name (@node_only_keys_names_array){($list.=sprintf (((
"\x25\x2d".$maxName)."\x73"),$key_name));($list.="\x20");($keyValue=
getCurrentNodeKeyValue ("\x6b\x65\x79",$key_name,
"\x70\x6c\x61\x74\x66\x6f\x72\x6d","\x53\x45\x52\x56\x45\x52"));($list.=sprintf 
((("\x25\x2d".$maxValue)."\x73"),$keyValue));($list.="\x0a");}return ($list);}
sub NXNodeConfiguration::getCurrentNodeKeyValue{package NXNodeConfiguration;no 
warnings;(my (%param)=@_);(my $keyName=$param{"\x6b\x65\x79"});(my $platform=
$param{"\x70\x6c\x61\x74\x66\x6f\x72\x6d"});(my $keyValue=
"\x6e\x6f\x74\x2d\x66\x6f\x75\x6e\x64");($GLOBAL::NODE_CONFIG_FILE=(
$GLOBAL::NODE_ROOT."\x2f\x65\x74\x63\x2f\x6e\x6f\x64\x65\x2e\x63\x66\x67"));
local $DB_FILE_HANDLE;(my $dbFileName=$GLOBAL::NODE_CONFIG_FILE);(
$DB_FILE_HANDLE=main::nxopen ($dbFileName,$NXBits::O_RDONLY,
(0x0555+ 2008-0x0d2d)));if ((not (defined ($DB_FILE_HANDLE)))){(my $errorstring=
libnxh::NXGetErrorString ());
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->throw (((((
"\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".
$dbFileName)."\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x3a\x20").$errorstring).
"\x2e"));}while (main::nxreadLine ($DB_FILE_HANDLE,(\$_))){(my $line=$_);if ((
$line=~ /^ *$keyName/ )){($keyValue=$line);}}if (($keyValue eq 
"\x6e\x6f\x74\x2d\x66\x6f\x75\x6e\x64")){($keyValue=getDefaultNodeKeyValue (
"\x70\x6c\x61\x74\x66\x6f\x72\x6d",$platform,"\x6b\x65\x79",$keyName));}else{((
$keyName,$keyValue)=split ( /=/ ,$keyValue,(0x050f+ 2107-0x0d47)));($keyValue=~ s/\n//gm )
;($keyValue=~ s/"//g );($keyValue=~ s/ //g );}main::nxclose ($DB_FILE_HANDLE);
return ($keyValue);}sub NXNodeConfiguration::getDefaultNodeKeyValue{package 
NXNodeConfiguration;no warnings;(my (%param)=@_);(my $keyName=$param{
"\x6b\x65\x79"});(my $platform=$param{"\x70\x6c\x61\x74\x66\x6f\x72\x6d"});if ((
($platform eq "\x53\x45\x52\x56\x45\x52")and $GLOBAL::NX_SYSTEM_DISTRIBUTION)){(
$platform=uc ($GLOBAL::NX_SYSTEM_DISTRIBUTION));}(my $node_key_default_value=
$node_only_keys_names_hash{$keyName}{$platform});return ($node_key_default_value
);}sub NXNodeConfiguration::getNodeKeyDescription{package NXNodeConfiguration;no
 warnings;(my (%param)=@_);(my $keyName=$param{"\x6b\x65\x79"});(my $node_key_short_description
=$node_only_keys_names_hash{$keyName}{
"\x44\x45\x53\x43\x52\x49\x50\x54\x49\x4f\x4e"});return (
$node_key_short_description);}sub NXNodeConfiguration::getEnableLocalRecording{
package NXNodeConfiguration;no warnings;if ((not (defined (
$GLOBAL::EnableLocalRecording)))){($GLOBAL::EnableLocalRecording=
(0x0588+ 2153-0x0df0));}return ($GLOBAL::EnableLocalRecording);}sub 
NXNodeConfiguration::getDisplayServerPriority{package NXNodeConfiguration;no 
warnings;if ((not (defined ($GLOBAL::DisplayServerPriority)))){(
$GLOBAL::DisplayServerPriority="\x72\x65\x61\x6c\x74\x69\x6d\x65");}return (
$GLOBAL::DisplayServerPriority);}sub 
NXNodeConfiguration::getDisplayAgentPriority{package NXNodeConfiguration;no 
warnings;if ((not (defined ($GLOBAL::DisplayAgentPriority)))){(
$GLOBAL::DisplayAgentPriority="\x72\x65\x61\x6c\x74\x69\x6d\x65");}return (
$GLOBAL::DisplayAgentPriority);}sub NXNodeConfiguration::isNotDisplayDefault{
package NXNodeConfiguration;no warnings;(my $display=shift (@_));if ((not (
defined ($GLOBAL::DisplayDefault)))){return ((0x160a+ 221-0x16e7));}my (
$displayFromConfig);Logger::debug (((
"\x44\x65\x66\x61\x75\x6c\x74\x20\x64\x69\x73\x70\x6c\x61\x79\x20\x66\x72\x6f\x6d\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x65\x20\x66\x69\x6c\x65\x20\x5b"
.$GLOBAL::DisplayDefault)."\x5d\x2e"));if (($GLOBAL::DisplayDefault=~ /:(\d+)/ )
){($displayFromConfig=$1);}if (($display==$displayFromConfig)){return (
(0x09e6+ 6957-0x2513));}return ((0x06da+ 724-0x09ad));}sub 
NXNodeConfiguration::isAgentX11VectorGraphics{package NXNodeConfiguration;no 
warnings;if ((not (defined ($GLOBAL::AgentX11VectorGraphics)))){if (defined (
$GLOBAL::AgentLightweightMode)){($GLOBAL::AgentX11VectorGraphics=
$GLOBAL::AgentLightweightMode);}else{($GLOBAL::AgentX11VectorGraphics=
(0x0114+ 1776-0x0803));}}return ($GLOBAL::AgentX11VectorGraphics);}sub 
NXNodeConfiguration::unsetAgentX11VectorGraphics{package NXNodeConfiguration;no 
warnings;($GLOBAL::AgentX11VectorGraphics=(0x04bc+ 2002-0x0c8e));}sub 
NXNodeConfiguration::setAgentX11VectorGraphics{package NXNodeConfiguration;no 
warnings;($GLOBAL::AgentX11VectorGraphics=(0x11bf+ 3184-0x1e2e));}sub 
NXNodeConfiguration::getNodeConnectionTimeout{package NXNodeConfiguration;no 
warnings;if ((not (defined ($GLOBAL::NodeConnectionTimeout)))){(
$GLOBAL::NodeConnectionTimeout=(0x1032+ 2381-0x1907));}if ((not ((
$GLOBAL::NodeConnectionTimeout=~ /\d+/ )))){Logger::warning (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x74\x68\x65\x20\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x69\x6d\x65\x6f\x75\x74\x20\x6b\x65\x79\x2e\x20\x55\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x2e"
);($GLOBAL::NodeConnectionTimeout=(0x179d+ 1535-0x1d24));}return (
$GLOBAL::NodeConnectionTimeout);}sub 
NXNodeConfiguration::getNXRecordingDirectory{package NXNodeConfiguration;no 
warnings;if (((not (defined ($GLOBAL::NXRecordingDirectory)))or (
$GLOBAL::NXRecordingDirectory eq ("")))){($GLOBAL::NXRecordingDirectory=((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"));}else{if ((
$GLOBAL::NXRecordingDirectory=~ /%PROGRAMDATA%/ )){(my $programDataPath=
NXPaths::getProgramDataFromEnvironment ());($GLOBAL::NXRecordingDirectory=~ s/%PROGRAMDATA%/$programDataPath/ )
;}}return ($GLOBAL::NXRecordingDirectory);}
