############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Server::BEGIN{package Server;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package Server;no warnings
;(my $__sessionID=(""));(my $__mainSessionID=(""));(my $__clientSupportLightweightMode
=(0x00cc+ 3675-0x0f26));(my $__clientSupportRootlessReconnect=
(0x09b5+ 3102-0x15d2));(my $__overrideShadowProfileRule=(0x0024+ 4681-0x126d));(my $__clientExtendedHelloHWinfo
=(0x1cf1+  59-0x1d2c));(my $__clientExtendedHelloCpuRamInfo=
(0x0463+ 1110-0x08b9));(my $__passErrorsToClient=(0x13d4+ 2395-0x1d2e));(my $__sslContext
=(""));(my $__connectionType="\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44");(my $__connectionIN
=(-(0x00e1+ 1953-0x0881)));(my $__connectionOUT=(-(0x02bb+ 4570-0x1494)));(my $__subsystemConnectionIN
=(-(0x0276+ 5572-0x1839)));(my $__subsystemConnectionOUT=(-(0x061c+ 4768-0x18bb)
));(my $__subsystemEncryptorIN=(-(0x0136+ 5189-0x157a)));(my $__communicationNXD
=(-(0x11a7+ 978-0x1578)));(my $__masterGoingToShutdown=(0x06ec+ 5416-0x1c14));(my $__foreignAddress
=(""));(my $__decodeUsernameFromClient=(0x06c4+ 3706-0x153e));(my $__encodeUsernameForClient
=(0x112d+ 5378-0x262f));(my $__myUuid=(""));(my $__isExistSessionFile=
(0x02e2+ 3656-0x112a));(my $__pureSession=(0x1664+ 3008-0x2224));(my $__pureVirtualSession
=(0x01b9+ 7768-0x2011));(my $__clientName="\x6e\x6f\x74\x73\x65\x74");(my $__mainServerClientName
="\x6e\x6f\x74\x73\x65\x74");(my $__clientMajorVersion=
"\x6e\x6f\x74\x73\x65\x74");(my $__clientMinorVersion="\x6e\x6f\x74\x73\x65\x74"
);(my $__clientPatchVersion="\x6e\x6f\x74\x73\x65\x74");(my $__clientBrowser=
(""));(my $__clientPlatform="\x6e\x6f\x74\x73\x65\x74");(my $__clientSupportsSSLEncryption
=(0x0b03+ 4579-0x1ce5));(my $__clientSupportsRedirecting=(0x04b8+ 5045-0x186d));
(my $__clientSupportsGuests=(0x0b82+ 2014-0x1360));(my $__clientSupportsNxpasswordService
=(0x133b+ 252-0x1437));(my $__clientSupportsPropertyRequest=
(0x11a4+ 5121-0x25a5));(my $__clientSupportsOsInfo=(0x1337+ 4622-0x2545));(my $__clientSupportsListHistory
=(0x0004+ 5827-0x16c7));(my $__clientSupportsFakeAuthentication=
(0x1a01+ 980-0x1dd5));(my $__clientSupportsExtendedServices=(0x0666+  68-0x06aa)
);(my $__clientVersion3OrOlder=(0x1789+ 1379-0x1cec));(my $__clientVersion7OrOlder
=(0x1087+ 5337-0x2560));(my $__clientSupportsPlatformParameters=
(0x034d+ 7989-0x2282));(my $__clientSupportsKbtypeParameter=
(0x0dcd+ 4030-0x1d8b));(my $__clientSupportsDynamicColumnWidth=
(0x0462+ 8014-0x23af));(my $__clientSupportsNodeAndLabelParameter=
(0x0f19+ 1929-0x16a2));(my $__clientSupportsNodeAndStatusParameter=
(0x1030+ 2300-0x192c));(my $__clientSupportsDialogInConnectionPolicy=
(0x08e9+ 4224-0x1969));(my $__clientSupportsNxFrameBufferFeature=
(0x09c1+ 3415-0x1718));(my $__clientSupportsDesktopViewMode=
(0x00b4+ 4096-0x10b4));(my $__clientSupportsSha256=(0x1c27+ 578-0x1e68));(my $__clientSupportsHelloWithAdmin
=(0x1dc7+ 215-0x1e9e));(my $__clientSupportingEncodedUserInHello=
(0x1d53+ 399-0x1ee2));(my $__clientSupportsProxyPacketPriority=
(0x09da+ 5726-0x2038));(my $__clientSupportsManualNodeSelection=
(0x029a+ 8386-0x235c));(my $__clientSupportsDynamicFieldSizesInSessionList=
(0x1580+ 3946-0x24e9));(my $__clientSupportsExpiredPasswordChange=
(0x060b+ 3748-0x14af));(my $__clientSupportsIgnoreSessionTypeForListSession=
(0x0995+ 3679-0x17f4));(my $__clientSupportingClientMenuConfiguration=
(0x1283+ 3722-0x210d));(my $__clientSupportingSeparateUsersOnSessionList=
(0x08b4+ 6028-0x2040));(my $__clientSupportingDisableCredentialsStoring=
(0x0502+ 5228-0x196e));(my $__clientSupportsPackedMessages=(0x01e9+ 7666-0x1fdb)
);(my $__clientSupportsTranslatedMessages=(0x1a4b+ 2239-0x230a));(my $__clientSupportsErrorDuringPasswordChange
=(0x0849+ 7635-0x261c));(my $__clientSupportsMultiserver=(0x1304+ 3569-0x20f4));
(my $__clientSupportsPasswordRequest=(0x0d08+ 384-0x0e88));(my $__clientSupportsAutoreconnectSetting
=(0x0c04+ 3519-0x19c3));(my $__clientSupportsAgentMode=(0x06e5+ 4180-0x1739));(my $__clientSupportDuoAuth
=(0x0490+ 2566-0x0e96));(my $__clientSupportsAutomaticRecording=
(0x16b4+ 272-0x17c4));(my $__clientSupportNoMachineNetworkTwoFactor=
(0x0d4d+ 6409-0x2655));(my $__clientSupportsSeparateAuthInMultiServer=
(0x1517+ 2083-0x1d39));(my $__clientSupportsAuthRequiredNamedAsFurtherAuth=
(0x0b83+ 5725-0x21df));(my $__clientSupportsAnywhereAuthMethods=
(0x0fc2+ 4328-0x20aa));(my $__clientSupportsCredentialsEncryption=
(0x06d0+ 815-0x09ff));(my $__clientSupportsServerListConnections=
(0x1987+ 2378-0x22d0));(my $__clientSupportSelectForwardMethod=
(0x059d+ 7943-0x24a4));(my $__clientSupportsErrorPublicKeyNotRecognized=
(0x1cb8+  47-0x1ce7));(my $__clientSupportsPooledServers=(0x1939+   7-0x1940));(my $__clientSupportsLocalSessionTypeAndOwner
=(0x1140+ 1101-0x158d));(my $__clientSupportsDesktopSharing=
(0x02f4+ 4130-0x1316));(my $__clientSupportsTerminateReason=
(0x03d2+ 8979-0x26e5));(my $__clientSupportsSubserversNamedAsNodes=
(0x22b2+ 983-0x2688));(my $__clientSupportsGuestTypes=(0x1482+ 4310-0x2557));(my $__clientSupportsAttachRequestMessage
=(0x0182+ 9253-0x25a7));(my $__clientSupportsExpireDateStatus=
(0x0a72+ 5539-0x2014));(my $__clientSupportsExpireInformation=
(0x063a+ 3099-0x1254));(my $__clientSupportsUpdateInNodeEdit=
(0x03c0+ 3643-0x11fa));(my $__clientSupportsUuidChangeMessage=
(0x0f60+ 3432-0x1cc8));(my $__clientSupportsClientConnection=
(0x0451+ 6689-0x1e71));(my $__clientSupportsInverseParameter=
(0x04ea+ 7793-0x235a));(my $__clientSupportsBrowseWithoutAuth=
(0x0579+  50-0x05aa));(my $__clientSupportsCommandsAfterStop=
(0x0162+ 6939-0x1c7c));(my $__clientSupportsParentCloudLimits=
(0x0046+ 5828-0x170a));(my $__clientSupportsIgnoringWarnings=
(0x02f2+ 2696-0x0d7a));(my $__clientSupportsExtendedHelloProcessorInfo=
(0x02dc+ 8012-0x2228));(my $__clientSupportNewLabels=(0x0b3d+ 2036-0x1330));(my $__clientSupportServerlistWithNames
=(0x15f9+ 4046-0x25c6));(my $__clientSupportsSeparateConnections=
(0x0b3b+ 5692-0x2176));(my $__clientSupportsDynamicParentConnections=
(0x0ea6+ 5171-0x22d9));(my $__clientSupportsMdnsMonitor=(0x1655+ 3648-0x2494));(my $__clientSupportsUdpServer
=(0x0c1f+ 4968-0x1f87));(my $__clientSupportsMissingLicenseFileOrWrongAcronym=
(0x2035+ 976-0x2404));(my $__clientSupportsReportingAllConnections=
(0x03ec+ 1332-0x091f));(my $__clientSupportsFileTransferInfomation=
(0x1c3c+ 529-0x1e4c));(my $__clientSupportsPhysicalDekstopAndClusterInfo=
(0x22b8+ 1057-0x26d8));(my $__clientSupportsCurrentNodeAddress=
(0x0027+ 4088-0x101e));(my $__clientSupportsAllowGuest=(0x08a4+ 7601-0x2654));(my $__clientSupportsCustomUdpPort
=(0x069a+ 1390-0x0c07));(my $__clientSupportWrongPlatformLicenseInfo=
(0x133b+ 4977-0x26ab));(my $__clientSupportNodeFlags=(0x0af2+ 4746-0x1d7b));(my $__clientSupportsCode555
=(0x1bc7+ 2437-0x254b));(my $__publicKeyMessageVersion=(0x1871+ 619-0x1adb));(my $__downwardCompatibilitySudoVerification
=(0x1032+ 5214-0x248f));(my $__downwardCompatibilityEmptyCommand=
(0x08e3+ 5577-0x1eab));(my $__mainServerSupportsHandleFirstAttach=
(0x0ee3+ 159-0x0f82));(my $__connectedToConsole=(0x06a4+ 7639-0x247a));(my $__serverStartedBySystemd
=(0x0cc7+ 2210-0x1569));(my $__serverStartedByService=(0x1144+ 2446-0x1ad2));(my $__startupNeedPerformAdministrativeTasks
=(0x2273+  18-0x2284));(my $__showAllResourceAvailableFlag=(0x078b+ 2995-0x133e)
);(my $__udpConnection=(0x1b66+ 1961-0x230f));(my $__checkLocalBySystemdSessions
=(0x0140+ 8009-0x2089));(my $__futureMainSession=(""));(my $__serverIsShutdownServer
=(0x12fb+  90-0x1355));(my $__serverIsRestartServer=(0x1632+ 1297-0x1b43));(my $__serverIsDaemon
=(0x0202+ 5947-0x193d));(my $__connectionTunnelled=(0x1bff+ 328-0x1d47));(my $__helloData
=(""));(my $__shellData=(""));my ($__timestamps);(my $__sessionRealConnecter=
(""));(my $__connectionForwarded=(0x19c6+ 1051-0x1de1));(my $__isMainSessionHeavyweight
=(0x05c5+ 5943-0x1cfc));(my $__anywhereName=
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x4e\x65\x74\x77\x6f\x72\x6b");(my $__accessOnlyToLocalPhysical
=(0x0aed+ 4972-0x1e59));(my $__accessOnlyToAttach=(0x0c32+ 6429-0x254f));(my $__remoteServer
=(0x04ec+ 907-0x0877));(my $__serverReverselogin=(0x00d3+ 8320-0x2153));(my $__serverReverseProtocol
=(""));(my $__serverReverseHost=(""));(my $__fdIN=(-(0x05b6+ 2292-0x0ea9)));(my $__fdOUT
=(-(0x0959+ 1594-0x0f92)));(my $__directAccessFlag=(-(0x07a1+ 5688-0x1dd8)));(my $__skipClosingPassedSocket
=(0x16e1+ 599-0x1938));(my $__disableUdpForwarder=(0x1973+ 1702-0x2019));(my $__udpStatus
=(0x126d+ 2606-0x1c9b));(my $__clientSupportsQuasiAdmin=(0x02d1+ 5626-0x18ca));(my $__clientSupportsForwardWithTimeout
=(0x0aa7+ 4891-0x1dc1));(my $__clientSupportHelloForVisitor=(0x18da+  68-0x191d)
);(my $__clientSupportParentName=(0x1d97+ 1690-0x2430));(my $__clientSupportCsNodePool
=(0x129c+ 4516-0x243f));sub setMySessionID{(my $id=shift (@_));(my $isLocal=(
shift (@_)||(0x000d+ 3673-0x0e66)));if (($__sessionID eq (""))){($__sessionID=
$id);Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x27"
.$__sessionID)."\x27\x2e"));}else{if ($isLocal){Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x68\x61\x6e\x67\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x66\x72\x6f\x6d\x20\x27"
.$__sessionID)."\x27\x20\x74\x6f\x20\x27").$id)."\x27\x2e"));($__sessionID=$id);
return ((0x02ca+ 5103-0x16b8));}if (($id ne $__sessionID)){Logger::error (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x27"
.$__sessionID)."\x27\x2e"));main::nxexit ();}else{Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74\x20\x27"
.$__sessionID)."\x27\x2e"));}}}sub saveSslContext{if (defined (
$GLOBAL::IS_SESSION_H)){if (($GLOBAL::IS_SESSION_H==(0x0817+ 2885-0x135b))){
setSslContext (libnxh::NXEncryptorGetContext ());}}}sub setSslContext{(my $sslContext
=shift (@_));Logger::debug ((
"\x53\x61\x76\x65\x20\x73\x73\x6c\x20\x63\x6f\x6e\x74\x65\x78\x74\x20".length (
$sslContext)));($__sslContext=$sslContext);}sub getSslContext{Logger::debug ((
"\x52\x65\x73\x74\x6f\x72\x65\x20\x73\x73\x6c\x20\x63\x6f\x6e\x74\x65\x78\x74\x20"
.length ($__sslContext)));return ($__sslContext);}sub isMySessionIdCreated{if ((
$__sessionID ne (""))){return ((0x1892+ 373-0x1a06));}return (
(0x08e7+ 441-0x0aa0));}sub getMySessionID{if (($__sessionID eq (""))){
Logger::debug (
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);}else{Logger::debug (((
"\x47\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x27".$__sessionID)
."\x27\x2e"));}return ($__sessionID);}sub setMainSessionHeavyweightMode{(
$__isMainSessionHeavyweight=shift (@_));}sub setMainSessionID{(my $id=shift (@_)
);if (($__mainSessionID eq (""))){($__mainSessionID=$id);if ((
$__isMainSessionHeavyweight eq (""))){($__isMainSessionHeavyweight=
NXSession2::isHeavyweightModeSessionBySessionId ($__mainSessionID));}
Logger::debug (((
"\x53\x65\x74\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x27"
.$__mainSessionID)."\x27\x2e"));}else{if (($id ne $__mainSessionID)){
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x27"
.$id).
"\x27\x2c\x20\x69\x74\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x65\x78\x69\x73\x74\x73\x20\x27"
).$__mainSessionID)."\x27\x2e"));main::nxexit ();}else{Logger::debug (((
"\x4d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x69\x73\x20\x69\x64\x65\x6e\x74\x69\x63\x61\x6c\x20\x74\x6f\x20\x74\x68\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74\x20\x27"
.$__mainSessionID)."\x27\x2e"));}}}sub isMainSessionHeavyweightMode{return (
$__isMainSessionHeavyweight);}sub switchMainSessionID{(my $id=shift (@_));
Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x77\x69\x74\x63\x68\x65\x64\x20\x66\x72\x6f\x6d\x20\x27"
.$__mainSessionID)."\x27\x20\x74\x6f\x20\x27").$id)."\x27\x2e"));(
$__mainSessionID=$id);}sub getMainSessionID{if (($__mainSessionID eq (""))){
Logger::debug (
"\x4d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);}else{Logger::debug (((
"\x47\x65\x74\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x3a\x20"
.$__mainSessionID)."\x2e"));}return ($__mainSessionID);}(my $__direclyConnected=
(0x07fd+ 7530-0x2567));sub isDireclyConnected{if (($__direclyConnected==
(0x0517+ 1795-0x0c19))){return ((0x0fe0+ 3527-0x1da6));}return (
(0x128f+ 757-0x1584));}sub isNotDireclyConnected{return ((!isDireclyConnected ()
));}sub setDirectlyConnected{($__direclyConnected=(0x140b+ 4628-0x261e));}(
$__removeNodeFromClient35=(0x0b38+ 2238-0x13f6));sub setRemoteNodeFromClient35{(
$__removeNodeFromClient35=(0x03ab+ 8047-0x2319));}sub isRemoveNodeFromClient35{
return ($__removeNodeFromClient35);}($desktopPolicy=
"\x6e\x6f\x72\x6d\x61\x6c\x50\x6f\x6c\x69\x63\x79");($desktopPolicyKeyNotSet=
"\x66\x61\x6c\x73\x65");sub isReverseDefaultDesktopPolicy{if (($desktopPolicy eq
 "\x72\x65\x76\x65\x72\x73\x65\x50\x6f\x6c\x69\x63\x79")){return (
(0x03f4+ 2770-0x0ec5));}return ((0x104d+ 1849-0x1786));}sub 
isNotReverseDefaultDesktopPolicy{return ((!isReverseDefaultDesktopPolicy ()));}
sub setReverseDefaultDesktopPolicy{($desktopPolicy=
"\x72\x65\x76\x65\x72\x73\x65\x50\x6f\x6c\x69\x63\x79");}sub 
setDefaultDesktopPolicyNotSet{($desktopPolicyKeyNotSet="\x74\x72\x75\x65");}sub 
isDefaultDesktopPolicyNotSet{if (($desktopPolicyKeyNotSet eq "\x74\x72\x75\x65")
){return ((0x0e1f+ 169-0x0ec7));}return ((0x0292+ 6641-0x1c83));}sub 
doesClientSupportLightMode{if (($__clientSupportLightweightMode==
(0x16c3+ 1093-0x1b07))){Logger::debug (
"\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x6c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x2e"
);return ((0x0640+ 2816-0x113f));}Logger::debug (
"\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x6c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x2e"
);return ((0x03e6+ 6733-0x1e33));}sub setClientNotSupportLightMode{(
$__clientSupportLightweightMode=(0x03f9+ 7087-0x1fa8));}sub 
passErrorsToUserEnabled{return ($__passErrorsToClient);}sub 
setPassErrorsToUserEnabled{($__passErrorsToClient=(0x026b+ 496-0x045a));}sub 
setPassErrorsToUserDisabled{($__passErrorsToClient=(0x096b+ 2082-0x118d));}sub 
resetMySessionID{($__sessionID=(""));}sub setClientNotSupportRootlessReconnect{(
$__clientSupportRootlessReconnect=(0x0918+ 3229-0x15b5));}sub 
isClientNotSupportRootlessReconnect{if (($__clientSupportRootlessReconnect==
(0x0e93+ 2711-0x192a))){return ((0x1678+ 3417-0x23d0));}return (
(0x125d+ 3105-0x1e7e));}sub getMyUUID{if (($__myUuid eq (""))){(my $uuidFilePath
=(($GLOBAL::PathEtc.$GLOBAL::DIRECTORY_SLASH)."\x75\x75\x69\x64"));(my $FH=
main::nxopen ($uuidFilePath,$NXBits::O_RDONLY,(0x155f+ 513-0x1760)));if ((not (
defined ($FH)))){(my $error=libnxh::NXGetError ());(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$uuidFilePath)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorName)."\x2c\x20").$errorString)."\x2e"));return ((""));}my (
$uuid);main::nxreadLine ($FH,(\$uuid));main::nxclose ($FH);chomp ($uuid);
Logger::debug ((("\x47\x6f\x74\x20\x75\x75\x69\x64\x20\x27".$uuid).
"\x27\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x2e"));($__myUuid=
$uuid);}return ($__myUuid);}sub reloadMyUUID{($__myUuid=(""));getMyUUID ();}sub 
encryptorAlreadyStarted{Logger::debug2 (
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x53\x74\x61\x72\x74\x65\x64\x28\x29\x2e"
);(my $return=libnxhs::NXSubsystemStarted ());Logger::debug2 (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x53\x74\x61\x72\x74\x65\x64\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));return ($return);}sub setCachedMessagesFromClient{
Logger::debug2 (
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x4d\x65\x73\x73\x61\x67\x65\x73\x28\x29\x2e"
);(my $messages=libnxhs::NXSubsystemGetMessages ());Logger::debug2 (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x4d\x65\x73\x73\x61\x67\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$messages)."\x27"));main::nxrequire (
"\x47\x65\x74\x43\x6f\x6d\x6d\x61\x6e\x64\x53\x74\x61\x74\x65\x4d\x61\x63\x68\x69\x6e\x65"
);GetCommandStateMachine::setCachedClientMessagesBuffer ($messages);}sub 
setIODescriptors{Logger::debug (
"\x47\x6f\x69\x6e\x74\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x64\x28\x29\x2e"
);(my $fd=libnxhs::NXSubsystemGetEncryptorFd ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x64\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x46\x44\x23"
.$fd)."\x2e"));if (($fd==(-(0x0d5f+ 2158-0x15cc)))){main::nxwrite (
main::nxgetSTDOUT (),
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x49\x4f\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e\x0a"
);main::nxexit ((0x1327+ 848-0x1677));}($GLOBAL::SOCKET_PASSED=$fd);
Common::NXCore::nxsetSTDIN ($fd);Common::NXCore::nxsetSTDOUT ($fd);}sub 
setClientOverrideShadowProfileRule{($__overrideShadowProfileRule=
(0x048c+ 2741-0x0f40));}sub clientOverrideShadowProfileRule{return (
$__overrideShadowProfileRule);}sub setClientExtendedHelloHWinfo{(
$__clientExtendedHelloHWinfo=(0x0313+ 8290-0x2374));}sub isClientSupportHWInfo{
return ($__clientExtendedHelloHWinfo);}sub setClientExtendedHelloCpuRamInfo{(
$__clientExtendedHelloCpuRamInfo=(0x25a5+ 292-0x26c8));}sub 
setClientSupportsExtendedHelloProcessorInfo{(
$__clientSupportsExtendedHelloProcessorInfo=(0x0cf1+ 1564-0x130c));}sub 
isClientSupportCpuRamInfo{return ($__clientExtendedHelloCpuRamInfo);}sub 
isClientSupportsExtendedHelloProcessorInfo{return (
$__clientSupportsExtendedHelloProcessorInfo);}sub getForeignAddress{if ((
$__foreignAddress ne (""))){return ($__foreignAddress);}return (
NXLogin::getForeignAddres ());}sub setForeignAddress{($__foreignAddress=shift (
@_));}sub sudoShouldAskForUsername{return ((0x0a6f+ 3908-0x19b2));}sub 
initConnectionSTD{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x62\x79\x20\x53\x54\x44\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x2e"
);setConnectionTypeSTD ();setConnectionDescriptors (main::nxgetSTDIN (),
main::nxgetSTDOUT ());setInheritConnectionDescriptor ("\x6e\x6f");}sub 
initServerConnectionSSHD{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x53\x53\x48\x44\x2e"
);setConnectionTypeSSHD ();setConnectionDescriptors (main::nxgetSTDIN (),
main::nxgetSTDOUT ());setInheritConnectionDescriptor ("\x6e\x6f");
setSubsystemConnectionIN (main::nxgetSTDIN ());setSubsystemConnectionOUT (
main::nxgetSTDOUT ());NXPublicKeyAuth::init ("\x73\x65\x72\x76\x65\x72");
NXPublicKeyAuth::setRemoteLogin ();}sub initClientConnectionReverse{(my $descriptor
=shift (@_));($__fdIN=shift (@_));($__fdOUT=shift (@_));(my $protocol=shift (@_)
);Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x76\x69\x61\x20\x72\x65\x76\x65\x72\x73\x65\x20\x6c\x6f\x67\x69\x6e\x2e"
);setConnectionType ("\x52\x65\x76\x65\x72\x73\x65");setReverseProtocol (
$protocol);setConnectionIN ($descriptor);setConnectionOUT ($descriptor);
setInheritConnectionDescriptor ("\x6e\x6f");}sub getReverseConnection{return (
$__connectionIN);}sub setReverseProtocol{($__serverReverseProtocol=shift (@_));}
sub getReverseProtocol{return ($__serverReverseProtocol);}sub 
initClientConnectionSSHD{Logger::debug (
"\x43\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x53\x53\x48\x44\x2e"
);setConnectionType ("\x53\x53\x48\x44");setConnectionDescriptors (
main::nxgetSTDIN (),main::nxgetSTDOUT ());setInheritConnectionDescriptor (
"\x6e\x6f");setSubsystemConnectionIN (main::nxgetSTDIN ());
setSubsystemConnectionOUT (main::nxgetSTDOUT ());}sub getNXEncryptorContext{(my $encryptorPipe
=shift (@_));(my $context=libnxh::NXEncryptorGetContext ());(my $maxTimeout=
(0x0631+ 3176-0x1221));(my $timeout=$maxTimeout);(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($encryptorPipe);while ((($context eq (""))and (
(0x070f+ 5556-0x1cc3)<$timeout))){(my $startTime=
Common::NXTime::getSecondsSinceEpoch ());(my (@ready)=$selector->can_read ((
$timeout *(0x10e0+ 2138-0x1552))));(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());($timeout=($timeout-($currentTime-
$startTime)));if ((scalar (@ready)==(0x0189+ 2003-0x095c))){Logger::warning (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20"
.$maxTimeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x72\x65\x61\x63\x68\x65\x64\x2e"));return 
((0x07e0+ 6387-0x20d3));}foreach my $f (@ready){if (($f==$encryptorPipe)){
Logger::debug (((
"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x20\x46\x44\x23"
.$f)."\x2e"));my ($read_buf);(my $bytes_read=main::nxread ($f,(\$read_buf),4096)
);if (((not (defined ($bytes_read)))or ($bytes_read==(0x079c+ 1682-0x0e2e)))){
Logger::debug ((("\x43\x6c\x6f\x73\x65\x64\x20\x46\x44\x23".$f)."\x2e"));
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6c\x6f\x73\x74\x2e"
);main::nxclose ($f);$selector->remove ($f);$selector->remove ($signalFd);return
 ((0x04e5+ 1089-0x0926));}else{Logger::debug (((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x3a\x20"
.$read_buf)."\x2e"));if (($read_buf=~ /1\n/ )){($context=
libnxh::NXEncryptorGetContext ());main::nxclose ($f);}elsif (($read_buf=~ /2\n/ )
){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);main::nxclose ($f);$selector->remove ($encryptorPipe);$selector->remove (
$signalFd);return ((0x1529+ 1723-0x1be4));}else{Logger::warning (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6f\x70\x74\x69\x6f\x6e\x20\x61\x70\x70\x65\x61\x72\x73\x2e"
);}}}}}($GLOBAL::NXD_SSL_CONTEXT=$context);(my $operationTime=($maxTimeout-
$timeout));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x27"
.$context)."\x27\x20\x61\x66\x74\x65\x72\x20").$operationTime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));return ((0x0626+ 2016-0x0e05));}sub 
initClientConnectionNXD{(my $inheritedDescriptor=shift (@_));Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x4e\x58\x44\x2e"
);($GLOBAL::IS_SESSION_H=(0x0ffa+ 2691-0x1a7c));if (encryptorAlreadyStarted ()){
setIODescriptors ();NXMsg::setSilentMode ();setCachedMessagesFromClient ();
setConnectionTypeNXD ();setConnectionDescriptors ($inheritedDescriptor);
setInheritConnectionDescriptor ("\x6e\x6f");return;}Logger::debug2 ((
"\x49\x6e\x68\x65\x72\x69\x74\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20"
.$inheritedDescriptor));(my $descriptor=libnxh::NXDescriptorCreate (
$inheritedDescriptor));if (($descriptor<(0x0bb7+ 1052-0x0fd3))){Logger::error ((
(
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$inheritedDescriptor)."\x2e"));shutdownClientConnection ();main::nxexit ();}
setNxdCommunication ($descriptor);($inheritedDescriptor=getTcpDescriptor ());(my $result
=main::nxPipeCreateBi ((\$GLOBAL::LOCAL_NX_DESCRIPTOR_IN),(
\$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)));Logger::debug (((((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x6c\x6f\x63\x61\x6c\x5f\x69\x6e\x20\x46\x44\x23"
.$GLOBAL::LOCAL_NX_DESCRIPTOR_IN).
"\x20\x6c\x6f\x63\x61\x6c\x20\x6f\x75\x74\x20\x46\x44\x23").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x20\x72\x65\x73\x75\x6c\x74\x20\x27").
$result)."\x27"));if (((($a<(0x17bb+ 2426-0x2135))or (
$GLOBAL::LOCAL_NX_DESCRIPTOR_IN<(0x0aa8+ 2075-0x12c3)))or (
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT<(0x18fb+ 627-0x1b6e)))){Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x4e\x58\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x70\x69\x70\x65\x2e"
);shutdownClientConnection ();main::nxexit ();}main::doNotCloseSocketAtFinish (
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT);my ($encryptorCreateIn);my (
$encryptorCreateOut);($result=main::nxPipeCreateBi ((\$encryptorCreateIn),(
\$encryptorCreateOut)));Logger::debug (((((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x49\x6e\x20\x46\x44\x23"
.$encryptorCreateIn).
"\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x4f\x75\x74\x20\x46\x44\x23"
).$encryptorCreateOut)."\x20\x72\x65\x73\x75\x6c\x74\x20\x27").$result).
"\x27\x2e"));if (((($result<(0x030b+ 321-0x044c))or ($encryptorCreateIn<
(0x137a+ 3597-0x2187)))or ($encryptorCreateOut<(0x011b+ 3718-0x0fa1)))){
Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x2e"
);shutdownClientConnection ();main::nxexit ();}main::doNotCloseSocketAtFinish (
$encryptorCreateOut);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x53\x65\x74\x50\x69\x70\x65\x28"
.$encryptorCreateOut)."\x29\x3b"));($result=libnxh::NXEncryptorSetPipe (
$encryptorCreateOut));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x53\x65\x74\x50\x69\x70\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");
if (((NXCluster::isEnabled ()and ($GLOBAL::ClusterHost ne ("")))and (not (
NXCluster::isSingleCert ())))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x2e"
);Logger::debug (((((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x6c\x75\x73\x74\x65\x72\x43\x72\x65\x61\x74\x65\x28"
.$inheritedDescriptor)."\x2c\x20").$inheritedDescriptor)."\x2c\x20").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x2c\x20").$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x2c\x20").$GLOBAL::ClusterHost)."\x29"));($result=
libnxh::NXEncryptorClusterCreate ($inheritedDescriptor,$inheritedDescriptor,
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,
$GLOBAL::ClusterHost));}else{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x2e"
);(my $nxRTEnv=libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x52\x54"));if ((
$nxRTEnv ne (""))){if (($nxRTEnv=~ /(.*):(.*):(.*):(.*)/ )){(my $host=$1);(my $port
=$2);(my $iv=$3);(my $key=$4);Logger::debug (((((((((((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x52\x54\x28"
.$inheritedDescriptor)."\x2c\x20").$inheritedDescriptor)."\x2c\x20").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x2c\x20").$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x2c\x20").$host)."\x2c\x20").$port)."\x2c\x20").$iv)."\x2c\x20").$key)."\x29")
);($result=libnxh::NXEncryptorCreateRT ($inheritedDescriptor,
$inheritedDescriptor,$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,$host,$port,$iv,$key));}}else{Logger::debug (((
((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x28"
.$inheritedDescriptor)."\x2c\x20").$inheritedDescriptor)."\x2c\x20").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x2c\x20").$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x29"));($result=libnxh::NXEncryptorCreate ($inheritedDescriptor,
$inheritedDescriptor,$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT));}}Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x72\x65\x73\x75\x6c\x74\x20\x27"
.$result)."\x27\x2e"));if (($result<(0x011d+ 9381-0x25c2))){
Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x66\x6f\x72\x20\x69\x6e\x68\x65\x72\x69\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$inheritedDescriptor)."\x2e"));shutdownClientConnection ();main::nxexit ();}(
$GLOBAL::SOCKET_PASSED=$GLOBAL::LOCAL_NX_DESCRIPTOR_IN);(
$GLOBAL::DefaultSTDINDescriptor=$GLOBAL::SOCKET_PASSED);(
$GLOBAL::DefaultSTDOUTDescriptor=$GLOBAL::SOCKET_PASSED);
setSubsystemConnectionIN ($GLOBAL::LOCAL_NX_DESCRIPTOR_IN);
setSubsystemConnectionOUT ($GLOBAL::LOCAL_NX_DESCRIPTOR_IN);
setSubsystemEncryptorIN ($GLOBAL::LOCAL_NX_DESCRIPTOR_OUT);Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4d\x6f\x64\x65\x20\x2d\x48\x20\x46\x44\x23".
$GLOBAL::SOCKET_PASSED)."\x2e"));setConnectionTypeNXD ();
setConnectionDescriptors ($inheritedDescriptor);setInheritConnectionDescriptor (
"\x6e\x6f");if ((getNXEncryptorContext ($encryptorCreateIn)==
(0x18c8+ 807-0x1bef))){Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x6f\x6e\x74\x65\x78\x74\x20\x6e\x6f\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);shutdownClientConnection ();main::nxexit ();}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x6f\x6e\x74\x65\x78\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);}sub shutdownClientConnection{if (isClientConnectionOpenOrNull ()){
Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
);if (isConnectionTypeNXD ()){shutdownClientConnectionNXD ();}elsif (
isConnectionTypeSSHD ()){shutdownClientConnectionSSHD ();}elsif ((
isConnectionTypeSTD ()or isConnectionTypeSTDNULL ())){
shutdownClientConnectionSTD ();}elsif (isReverselogin ()){
shutdownClientConnectionReverse ();}setClientConnectionClosed ();}}sub 
shutdownClientConnectionNXD{Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x4e\x58\x44\x2e"
);if (libnxh::NXEncryptorRunning ()){Logger::debug (
"\x46\x72\x65\x65\x20\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x6f\x6e\x74\x65\x78\x74"
);(my $return=libnxh::NXEncryptorFreeContext ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x72\x65\x65\x43\x6f\x6e\x74\x65\x78\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));($return=libnxh::NXEncryptorDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x44\x65\x73\x74\x72\x6f\x79\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));if ((shouldSkipClosingPassedSocket ()==(0x11e2+ 2745-0x1c9b))
){main::nxclose ($GLOBAL::SOCKET_PASSED);}NXShell::setConnectionClosed ();}else{
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);}main::nxclose (getConnectionIN ());}sub shutdownClientConnectionReverse{
Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x52\x65\x76\x65\x72\x73\x65\x2e"
);if (($__fdIN!=(-(0x0e88+ 1601-0x14c8)))){main::nxclose ($__fdIN);}if (((
$__fdOUT!=$__fdIN)and ($__fdOUT!=(-(0x0426+ 2031-0x0c14))))){main::nxclose (
$__fdOUT);}($__fdIN=(-(0x0188+ 4100-0x118b)));($__fdOUT=(-(0x01a3+ 4104-0x11aa))
);}sub shutdownClientConnectionSSHD{Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x53\x53\x48\x44\x2e"
);main::nxclose (getConnectionIN ());main::nxclose (getConnectionOUT ());}sub 
shutdownClientConnectionSTD{Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x53\x54\x44\x49\x4e\x20\x61\x6e\x64\x20\x53\x54\x44\x4f\x55\x54\x2e"
);main::nxclose (main::nxgetSTDIN ());Common::NXCore::nxsetSTDIN ((-
(0x05e7+ 4446-0x1744)));main::nxclose (main::nxgetSTDOUT ());
Common::NXCore::nxsetSTDOUT ((-(0x0360+ 1413-0x08e4)));}sub 
redirectClientConnectionToNull{Logger::warning (
"\x72\x65\x64\x69\x72\x65\x63\x74\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x6f\x4e\x75\x6c\x6c\x28\x29\x20\x69\x73\x20\x6e\x6f\x74\x20\x69\x6e\x74\x65\x6e\x64\x65\x64\x20\x74\x6f\x20\x62\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x2e"
);return;if (isConnectionTypeSTD ()){(my $ret=redirectClientConnectionSTDToNull 
());Logger::debug (($ret.
"\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28\x73\x29\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
));setConnectionTypeSTDNULL ();return ($ret);}else{Logger::error (
"\x72\x65\x64\x69\x72\x65\x63\x74\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x6f\x4e\x75\x6c\x6c\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x20\x66\x6f\x72\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x79\x70\x65"
);return ((-(0x1b68+ 894-0x1ee5)));}}sub redirectClientConnectionSTDToNull{
Logger::warning (
"\x72\x65\x64\x69\x72\x65\x63\x74\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x53\x54\x44\x54\x6f\x4e\x75\x6c\x6c\x28\x29\x20\x69\x73\x20\x6e\x6f\x74\x20\x69\x6e\x74\x65\x6e\x64\x65\x64\x20\x74\x6f\x20\x62\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x2e"
);return;Logger::debug (
"\x52\x65\x64\x69\x72\x65\x63\x74\x69\x6e\x67\x20\x53\x54\x44\x49\x4e\x20\x61\x6e\x64\x20\x53\x54\x44\x4f\x55\x54\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
);(my $in=main::nxgetSTDIN ());(my $out=main::nxgetSTDOUT ());(my $nullin=
main::nxopen ("\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c",$NXBits::O_RDONLY,
(0x1f18+ 375-0x208f)));if ((not (defined ($nullin)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));return ((0x16c0+ 2744-0x2178))
;}(my $nullout=main::nxopen ("\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c",
$NXBits::O_WRONLY,(0x0245+ 3127-0x0e7c)));if ((not (defined ($nullout)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));main::nxclose ($nullin);return
 ((0x03d3+ 8594-0x2565));}(my $result=(0x0d87+ 1491-0x1358));(my $ret=
Common::NXCore::nxFileClone ($nullin,$in));if ((not (defined ($ret)))){
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x69\x6e\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
);(--$result);}($ret=Common::NXCore::nxFileClone ($nullout,$out));if ((not (
defined ($ret)))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
);(--$result);}main::nxclose ($nullin);main::nxclose ($nullout);return ($result)
;}sub isClientConnectionOpen{if ((($__connectionType eq 
"\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44")or ($__connectionType eq 
"\x53\x54\x44\x4e\x55\x4c\x4c"))){Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);return ((0x16d9+ 810-0x1a03));}else{Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x73\x74\x69\x6c\x6c\x20\x6f\x70\x65\x6e\x2e"
);return ((0x0806+ 4669-0x1a42));}}sub isClientConnectionOpenOrNull{if ((
$__connectionType eq "\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44")){
Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6c\x6f\x73\x65\x64\x20\x28\x73\x74\x72\x69\x63\x74\x6c\x79\x2c\x20\x6e\x6f\x74\x20\x6e\x75\x6c\x6c\x65\x64\x29\x2e"
);return ((0x0fdf+ 5374-0x24dd));}else{Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x70\x65\x6e\x20\x6f\x72\x20\x6e\x75\x6c\x6c\x65\x64\x2e"
);return ((0x0baf+ 1680-0x123e));}}sub isClientConnectionClosed{return ((!
isClientConnectionOpen ()));}sub setClientConnectionClosed{Logger::debug (
"\x53\x65\x74\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);if ((not (NXShell::byeMeansSwitch ()))){
NXClientConnection::informAboutDisconnect ();}setConnectionType (
"\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44");}sub setConnectionType{(my $type
=shift (@_));($__connectionType=$type);}sub getConnectionType{(my $type=
$__connectionType);return ($type);}sub setConnectionIN{(my $fd=shift (@_));(
$__connectionIN=$fd);}sub setConnectionOUT{(my $fd=shift (@_));($__connectionOUT
=$fd);}sub getConnectionIN{return ($__connectionIN);}sub getConnectionOUT{return
 ($__connectionOUT);}sub setConnectionDescriptors{if (isConnectionTypeNXD ()){(my $conectionInOut
=shift (@_));setConnectionIN ($conectionInOut);setConnectionOUT ($conectionInOut
);}elsif ((isConnectionTypeSSHD ()or isConnectionTypeSTD ())){(my $conectionIn=
shift (@_));(my $conectionOut=shift (@_));setConnectionIN ($conectionIn);
setConnectionOUT ($conectionOut);}}sub setConnectionDescriptorsInheritable{(my $value
=shift (@_));if (isClientConnectionOpenOrNull ()){if (isConnectionTypeNXD ()){
libnxh::NXDescriptorInheritable (getConnectionIN (),$value);}elsif (((
isConnectionTypeSSHD ()or isConnectionTypeSTD ())or isConnectionTypeSTDNULL ()))
{libnxh::NXDescriptorInheritable (getConnectionIN (),$value);
libnxh::NXDescriptorInheritable (getConnectionOUT (),$value);}}}sub 
setInheritConnectionDescriptor{(my $value=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x74\x6f\x20\x27"
.$value)."\x27\x2e"));if (($value eq "\x6e\x6f")){
setConnectionDescriptorsInheritable ((0x1156+ 1302-0x166c));}if (($value eq 
"\x79\x65\x73")){setConnectionDescriptorsInheritable ((0x08ed+ 5307-0x1da7));}(
$GLOBAL::inheritConnectionDescriptor=$value);}sub getInheritConnectionDescriptor
{return ($GLOBAL::inheritConnectionDescriptor);}sub 
isInheritConnectionDescriptor{if (($GLOBAL::inheritConnectionDescriptor eq 
"\x79\x65\x73")){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x49\x6e\x68\x65\x72\x69\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);return ((0x0b85+ 5203-0x1fd7));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4e\x6f\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);return ((0x187f+  58-0x18b9));}sub setConnectionTypeNXD{setConnectionType (
"\x4e\x58\x44");}sub setConnectionTypeSSHD{setConnectionType ("\x53\x53\x48\x44"
);}sub setConnectionTypeSTD{setConnectionType ("\x53\x54\x44");}sub 
setConnectionTypeSTDNULL{setConnectionType ("\x53\x54\x44\x4e\x55\x4c\x4c");}sub
 isConnectionTypeNXD{if (($__connectionType eq "\x4e\x58\x44")){return (
(0x03f5+ 2618-0x0e2e));}else{return ((0x21b3+ 1334-0x26e9));}}sub 
isConnectionTypeReverseNXD{if ((($__connectionType eq 
"\x52\x65\x76\x65\x72\x73\x65")and ($__serverReverseProtocol eq "\x4e\x58\x44"))
){return ((0x1341+ 2418-0x1cb2));}return ((0x22c0+ 734-0x259e));}sub 
addCONNECTIONvariableToEnvArrayPassed{(my $ref_array=shift (@_));(my $nxConnectionEnv
=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (($nxConnectionEnv 
ne (""))){push (@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$nxConnectionEnv));
return ((0x16b2+ 3846-0x25b7));}(my $sshConnectionEnv=
libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if ((
$sshConnectionEnv ne (""))){push (@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$sshConnectionEnv
));}(my $sshClientEnv=libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"));if (($sshClientEnv ne (""))){push (
@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54\x3d".$sshClientEnv));}}sub 
isConnectionTypeSSHD{if (($__connectionType eq "\x53\x53\x48\x44")){return (
(0x09d1+ 2253-0x129d));}else{return ((0x1f9d+ 1724-0x2659));}}sub 
isConnectionTypeSTD{if (($__connectionType eq "\x53\x54\x44")){return (
(0x0896+ 7369-0x255e));}else{return ((0x0f8c+ 5512-0x2514));}}sub 
isConnectionTypeSTDNULL{if (($__connectionType eq "\x53\x54\x44\x4e\x55\x4c\x4c"
)){return ((0x1a60+ 1675-0x20ea));}else{return ((0x055f+ 2156-0x0dcb));}}sub 
setSubsystemConnectionIN{(my $fd=shift (@_));($__subsystemConnectionIN=$fd);}sub
 setSubsystemConnectionOUT{(my $fd=shift (@_));($__subsystemConnectionOUT=$fd);}
sub getSubsystemConnectionIN{return ($__subsystemConnectionIN);}sub 
getSubsystemConnectionOUT{return ($__subsystemConnectionOUT);}sub 
setSubsystemEncryptorIN{($__subsystemEncryptorIN=shift (@_));}sub 
getSubsystemEncryptorIN{return ($__subsystemEncryptorIN);}sub 
setMasterGoingToShutdown{($__masterGoingToShutdown=(0x0aa3+ 3270-0x1768));}sub 
isMasterGoingToShutdown{return ($__masterGoingToShutdown);}sub setPureSession{
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x70\x75\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);($__pureSession=(0x0d48+ 3663-0x1b96));}sub isPureSession{if (($__pureSession
==(0x032d+ 2345-0x0c55))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x75\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x0d95+ 3449-0x1b0d));}return ((0x0824+ 2362-0x115e));}sub 
terminateCommandReceived{return ($GLOBAL::REQUEST_TERMINATE);}sub 
setNotConnectedToConsole{($__connectedToConsole=(0x149f+ 3840-0x239f));}sub 
setConnectedToConsole{($__connectedToConsole=(0x0266+ 6449-0x1b96));}sub 
isConnectedToConsole{return ($__connectedToConsole);}sub setStartedBySystemd{(
$__serverStartedBySystemd=(0x1578+ 737-0x1858));}sub 
isCurrentServerDeamonStartedBySystemd{return ($__serverStartedBySystemd);}sub 
setStartedByService{($__serverStartedByService=(0x100a+ 2803-0x1afc));}sub 
isCurrentServerDeamonStartedByService{return ($__serverStartedByService);}sub 
setStartupNotNeedPerformAdministrativeTasks{(
$__startupNeedPerformAdministrativeTasks=(0x1828+ 3727-0x26b7));}sub 
resetStartupNotNeedPerformAdministrativeTasks{(
$__startupNeedPerformAdministrativeTasks=(0x07e4+ 2954-0x136d));}sub 
startupNeedPerformAdministrativeTasks{return (
$__startupNeedPerformAdministrativeTasks);}sub handleClientTypeAndVersion{(my $clientName
=shift (@_));(my $clientMajorVersion=shift (@_));(my $clientMinorVersion=shift (
@_));(my $clientPatchVersion=shift (@_));Logger::debug ((((((((
"\x43\x6c\x69\x65\x6e\x74\x20\x73\x65\x74\x20\x74\x6f\x20".$clientName).
"\x20\x2d\x20").$clientMajorVersion)."\x2e").$clientMinorVersion)."\x2e").
$clientPatchVersion));setClientName ($clientName);setClientMajorVersion (
$clientMajorVersion);setClientMinorVersion ($clientMinorVersion);
setClientPatchVersion ($clientPatchVersion);setIfClientSupportsLightweight ();
setIfClientSupportsSSLEncryption ();setShowAllResourceAvailableFlag ();
setIfClientSupportsRedirecting ();setIfClientSupportsGuests ();
setIfClientSupportsNxpasswordService ();setIfClientSupportsPropertyRequest ();
setIfClientSupportsOsInfo ();setIfClientSupportsListHistory ();
setIfClientSupportsExtendedServices ();setIfClientIsVersion3OrOlder ();
setIfClientIsVersion7OrOlder ();setIfClientSupportsPlatformParameters ();
setIfClientSupportsKbtypeParameter ();setIfClientSupportsFakeAuthentication ();
setIfClientSupportsDynamicColumnWidth ();
setIfClientSupportsNodeAndLabelParameter ();
setIfClientSupportsNodeAndStatusParameter ();
setIfClientSupportsDialogInConnectionPolicy ();
setIfClientSupportsNxFrameBufferFeature ();setIfClientSupportsDesktopViewMode ()
;setIfClientSupportsSha256 ();setIfClientSupportsHelloWithAdmin ();
setIfClientSupportingEncodedUserInHello ();
setIfClientSupportsProxyPacketPriority ();setIfClientSupportsManualNodeSelection
 ();setIfClientIsSupportingDynamicFieldSizesInSessionList ();
setIfClientSupportsExpiredPasswordChange ();
setIfClientSupportsIgnoreSessionTypeForListSession ();
setIfClientSupportingClientMenuConfiguration ();
setIfClientSupportingDisableCredentialsStoring ();
setIfClientSupportsPackedMessages ();setIfClientSupportsTranslatedMessages ();
setIfClientSupportsErrorDuringPasswordChange ();
setIfClientSupportsPasswordRequest ();setIfClientSupportsDuoAuth ();
setIfClientSupportsLBTypeSystemLoad ();
setIfClientSupportsSystemDesktopsInConnectionPolicy ();
setIfClientSupportsErrorPublicKeyNotRecognized ();
setIfClientSupportsPooledServers ();setIfClientSupportsLocalSessionTypeAndOwner 
();setIfClientSupportsUdpInConnectionPolicy ();setIfClientSupportNewLabels ();
setIfClientSupportServerlistWithNames ();setIfClientSupportsCode555 ();
setDownwardCompatibilitySudoVerification ();setDownwardCompatibilityEmptyCommand
 ();setIfClientSupportsMultiserver ();setIfClientSupportAutoreconnectSetting ();
setIfClientSupportAgentMode ();setIfClientSupportsAutomaticRecording ();
setClientSupportsSeparateAuthInMultiServer ();
setClientSupportsAuthRequiredNamedAsFurtherAuth ();
setClientSupportsAnywhereAuthMethods ();setClientSupportsNoMachineTwoFactor ();
setClientSupportsCredentialsEncryption ();
setIfMainServerSupportsHandleFirstAttach ();
setClientSupportstServerListConnections ();
setIfClientSupportsSelectForwardMethod ();setIfClientSupportsDesktopSharing ();
setIfClientSupportsTerminateReason ();setIfClientSupportsSubserversNamedAsNodes 
();setClientSupportsGuestTypes ();setClientSupportsExpireDateStatus ();
setClientSupportsExpireInformation ();
setClientSupportsMissingLicenseFileOrWrongAcronym ();
setClientSupportWrongPlatformLicenseInfo ();setClientSupportNodeFlags ();
setClientSupportsAttachRequestMessage ();setClientSupportsInverseParameter ();
setClientSupportsUpdateInNodeEdit ();setClientSupportsClientConnection ();
setClientSupportsUuidChangeMessage ();setClientSupportsBrowseWithoutAuth ();
setPublicKeyMessageVersion ();setClientSupportsCommandsAfterStop ();
setClientSupportsParentCloudLimits ();setClientSupportsSeparateConnections ();
setClientSupportsDynamicParentConnections ();setClientSupportsIgnoringWarnings 
();setClientSupportsMdnsMonitor ();setClientSupportsForwardUdp ();
setClientSupportsDirectUdp ();setClientSupportsFileTransferInfomation ();
setClientSupportsPhysicalDestkopAndClusterInformation ();
setClientSupportsQuasiAdmin ();setClientSupportsForwardWithTimeout ();
setClientSupportsCurrentNodeAddress ();setClientSupportsAllowGuest ();
setClientSupportsCustomUdpPort ();setClientSupportHelloForVisitor ();
setClientSupportParentName ();setClientSupportCsNodePool ();if (
isClientVersionGreaterOrEqual ((0x10b2+ 1436-0x164a))){if (isClientNxclient ()){
($GLOBAL::CLIENT_WITHOUT_UNENCRYPTION_MODE=(0x0a80+ 4076-0x1a6b));}if ((((
isClientNxwebclient ()or isClientNxclient ())or isClientNxserver ())or 
isClientNxmanager ())){($GLOBAL::ConnectionMaxKeepAlive=(-(0x106b+ 2862-0x1b98))
);}}if ((isClientVersion ((0x1ab6+ 397-0x1c3f),(0x1313+ 4333-0x2400))or 
isClientVersion ((0x0513+ 6588-0x1ecb),(0x0ea8+ 847-0x11f6)))){
setReverseDefaultDesktopPolicy ();}if (isClientNxclient ()){
NXShell::setCommandByeMeansExitSilent ();if (isClientVersionLesserOrEqual (
(0x083f+ 1071-0x0c6d),(0x1f4a+  33-0x1f67))){(
$GLOBAL::conversionUnixApplicationToUnixDesktopNeededBecauseOldClient=
(0x0dca+ 4411-0x1f04));}if (isClientVersionGreaterOrEqual ((0x1017+ 2112-0x1853)
,(0x180b+ 240-0x18f8),(0x0735+ 5950-0x1e63))){setClientExtendedHelloHWinfo ();}
if (isClientVersionGreaterOrEqual ((0x06a2+ 6581-0x2050),(0x1a47+ 1850-0x2181),
(0x0169+ 8120-0x2058))){setClientExtendedHelloCpuRamInfo ();}if (
isClientVersionGreaterOrEqual ((0x1d31+ 396-0x1eb5),(0x0283+ 1410-0x0805),
(0x1181+ 5355-0x266c))){setClientSupportsExtendedHelloProcessorInfo ();}}if (
isClientNxwebclient ()){setEncodeUsernameForClient ();setNotConnectedToConsole 
();if (isClientVersionLesserOrEqual ((0x0427+ 5754-0x1a9d),(0x0987+ 6029-0x2111)
,(0x0200+ 1536-0x07dd))){setDecodeUsernameFromClient ();}if (
isClientVersionGreaterOrEqual ((0x02d1+ 8572-0x2446),(0x08a4+ 801-0x0bc5),
(0x0239+ 8161-0x2155))){setClientExtendedHelloHWinfo ();}if (
isClientVersionGreaterOrEqual ((0x1272+ 5039-0x261a),(0x06d4+ 4795-0x198f),
(0x12a1+ 3402-0x1f23))){setClientExtendedHelloCpuRamInfo ();}if (
isClientVersionGreaterOrEqual ((0x1815+ 2765-0x22da),(0x00ec+ 5937-0x181d),
(0x1708+ 2461-0x202b))){setClientSupportsExtendedHelloProcessorInfo ();}}}sub 
setIfClientSupportsLightweight{if (isClientNxwebclient ()){Logger::debug (
"\x4c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e"
);setClientNotSupportLightMode ();setClientNotSupportRootlessReconnect ();
setClientOverrideShadowProfileRule ();}elsif (isClientVersion (
(0x1c40+ 2367-0x257b),(0x01e5+ 3824-0x10d5))){Logger::debug (
"\x4c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x6e\x78\x70\x6c\x61\x79\x65\x72\x20\x34\x2e\x30"
);setClientNotSupportLightMode ();}}sub setIfClientSupportsSSLEncryption{if (
isClientVersionLesserOrEqual ((0x02ef+ 6222-0x1b3c),(0x1417+ 1447-0x19bb))){(
$__clientSupportsSSLEncryption=(0x0dec+ 643-0x106f));}else{(
$__clientSupportsSSLEncryption=(0x13c3+ 2537-0x1dab));}}sub 
setShowAllResourceAvailableFlag{if (isClientVersionGreaterOrEqual (
(0x1982+ 2894-0x24cc),(0x10ed+ 5454-0x2637),(0x112d+ 4219-0x21a3))){(
$__showAllResourceAvailableFlag=(0x0242+ 8452-0x2345));}else{(
$__showAllResourceAvailableFlag=(0x0163+  14-0x0171));}}sub 
notShowAllResourceAvailable{if ($__showAllResourceAvailableFlag){return (
(0x209a+ 1104-0x24ea));}return ((0x0c23+ 4594-0x1e14));}sub 
isClientSupportingSSLEncryption{return ($__clientSupportsSSLEncryption);}sub 
setIfClientSupportsRedirecting{if (isClientVersionGreaterOrEqual (
(0x1548+ 4400-0x2674))){($__clientSupportsRedirecting=(0x1d88+ 1617-0x23d8));}
else{($__clientSupportsRedirecting=(0x0fb3+ 2322-0x18c5));}}sub 
isClientSupportingRedirecting{return ($__clientSupportsRedirecting);}sub 
setIfClientSupportsGuests{if (isClientVersionGreaterOrEqual (
(0x1398+ 1455-0x1943),(0x1680+ 3933-0x25dc))){($__clientSupportsGuests=
(0x0f8a+ 5107-0x237c));}else{($__clientSupportsGuests=(0x0544+ 6779-0x1fbf));}}
sub isClientSupportingGuests{return ($__clientSupportsGuests);}sub 
setIfClientSupportsMultiserver{if ((isClientNxclient ()or isClientNxwebclient ()
)){if (isClientVersionGreaterOrEqual ((0x03fa+ 6985-0x1f3d),
(0x1ae2+ 2318-0x23f0))){($__clientSupportsMultiserver=(0x0679+ 2142-0x0ed6));}
else{($__clientSupportsMultiserver=(0x0ca0+ 3364-0x19c4));}}}sub 
isClientNotSupportingMultiserver{if (($__clientSupportsMultiserver==
(0x222f+  70-0x2275))){return ((0x039f+ 3245-0x104b));}return (
(0x1833+ 2595-0x2256));}sub setIfClientSupportAutoreconnectSetting{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x266a+  36-0x2688),(0x099b+ 4073-0x1982),(0x06f6+ 1398-0x0c60))){(
$__clientSupportsAutoreconnectSetting=(0x0df3+ 4430-0x1f40));}else{(
$__clientSupportsAutoreconnectSetting=(0x0b7b+ 5683-0x21ae));}}}sub 
isClientSupportAutoreconnectSetting{return (
$__clientSupportsAutoreconnectSetting);}sub setIfClientSupportAgentMode{if (
isClientNxclient ()){if (isClientVersionGreaterOrEqual ((0x0a74+ 4090-0x1a68),
(0x162b+ 1613-0x1c76),(0x0c21+ 3565-0x1a02))){($__clientSupportsAgentMode=
(0x0e09+ 3737-0x1ca1));}else{($__clientSupportsAgentMode=(0x05c5+ 3271-0x128c));
}}if (isClientNxwebclient ()){if (isClientVersionGreaterOrEqual (
(0x11e9+ 2023-0x19c9),(0x0c72+ 6584-0x262a),(0x0807+ 4409-0x1889))){(
$__clientSupportsAgentMode=(0x1308+ 4121-0x2320));}else{(
$__clientSupportsAgentMode=(0x152b+ 492-0x1717));}}}sub isClientSupportAgentMode
{return ($__clientSupportsAgentMode);}sub setIfClientSupportsNxpasswordService{
if (isClientVersionGreaterOrEqual ((0x18ba+ 415-0x1a54),(0x02ea+ 1296-0x07f9),
(0x1e5d+ 105-0x1eba))){($__clientSupportsNxpasswordService=(0x09b7+ 6133-0x21ab)
);}else{($__clientSupportsNxpasswordService=(0x0351+ 4614-0x1557));}}sub 
isClientSupportingNxpasswordService{return ($__clientSupportsNxpasswordService);
}sub setIfClientSupportsPropertyRequest{if (isClientVersionGreaterOrEqual (
(0x0c2f+ 1346-0x116d))){($__clientSupportsPropertyRequest=(0x0b31+ 3305-0x1819))
;}else{($__clientSupportsPropertyRequest=(0x0a9a+ 2433-0x141b));}}sub 
isClientSupportingPropertyRequest{return ($__clientSupportsPropertyRequest);}sub
 setIfClientSupportsOsInfo{if (isClientVersionGreaterOrEqual (
(0x16a7+ 1416-0x1c2b))){($__clientSupportsOsInfo=(0x05ad+ 6360-0x1e84));}else{(
$__clientSupportsOsInfo=(0x1656+ 1736-0x1d1e));}}sub isClientSupportingOsInfo{
return ($__clientSupportsOsInfo);}sub setIfClientSupportsListHistory{if (
isClientVersionGreaterOrEqual ((0x0bc6+ 3021-0x178f))){(
$__clientSupportsListHistory=(0x0e17+ 2755-0x18d9));}else{(
$__clientSupportsListHistory=(0x080b+ 3238-0x14b1));}}sub 
isClientSupportingListHistory{return ($__clientSupportsListHistory);}sub 
setIfClientSupportsExtendedServices{if (isClientVersionGreaterOrEqual (
(0x0b6f+ 5088-0x1f4b),(0x0b4b+ 978-0x0f1c))){($__clientSupportsExtendedServices=
(0x049a+ 8688-0x2689));}else{($__clientSupportsExtendedServices=
(0x02d3+ 8619-0x247e));}}sub isClientSupportingExtendedServices{return (
$__clientSupportsExtendedServices);}sub setIfClientIsVersion3OrOlder{if (
isClientVersionLesserOrEqual ((0x0b0a+ 2943-0x1686))){($__clientVersion3OrOlder=
(0x013f+ 7875-0x2001));}else{($__clientVersion3OrOlder=(0x0e2a+ 6318-0x26d8));}}
sub isClientVersion3OrOlder{return ($__clientVersion3OrOlder);}sub 
setIfClientIsVersion7OrOlder{if (isClientVersionLesserOrEqual (
(0x15bf+ 929-0x1959))){($__clientVersion7OrOlder=(0x05fa+ 2328-0x0f11));}else{(
$__clientVersion7OrOlder=(0x1a48+ 215-0x1b1f));}}sub isClientVersion7OrOlder{
return ($__clientVersion7OrOlder);}sub setIfClientSupportsPlatformParameters{if 
(isClientVersionGreaterOrEqual ((0x1bd0+ 2514-0x259e),(0x0cb1+ 3141-0x18f6),
(0x1059+ 2681-0x1a17))){($__clientSupportsPlatformParameters=
(0x0864+ 3176-0x14cb));}else{($__clientSupportsPlatformParameters=
(0x06ba+ 4033-0x167b));}}sub isClientSupportingPlatformParameters{return (
$__clientSupportsPlatformParameters);}sub setIfClientSupportsKbtypeParameter{if 
(isClientVersion ((0x1730+ 1714-0x1de1))){($__clientSupportsKbtypeParameter=
(0x0d81+ 1602-0x13c2));}else{($__clientSupportsKbtypeParameter=
(0x0a0c+ 7330-0x26ae));}}sub isClientSupportingKbtypeParameter{return (
$__clientSupportsKbtypeParameter);}sub setIfClientSupportsFakeAuthentication{if 
((isClientVersionLesserOrEqual ((0x0a77+ 3917-0x19c3))and 
isClientVersionGreaterOrEqual ((0x015f+ 9064-0x24c6),(0x05c0+ 4650-0x17e5)))){(
$__clientSupportsFakeAuthentication=(0x18cb+ 2744-0x2382));}else{(
$__clientSupportsFakeAuthentication=(0x00d0+ 4064-0x10b0));}}sub 
isClientSupportingFakeAuthentication{return ($__clientSupportsFakeAuthentication
);}sub setIfClientSupportsDynamicColumnWidth{if (isClientVersionLesserOrEqual (
(0x09eb+ 6643-0x23db))){($__clientSupportsDynamicColumnWidth=
(0x05e9+ 1477-0x0bae));}}sub isClientSupportingDynamicColumnWidth{return (
$__clientSupportsDynamicColumnWidth);}sub setIfClientSupportsSha256{if (
isClientVersionLesserOrEqual ((0x01cb+ 1868-0x0912),(0x01ab+ 3734-0x1041),
(0x1a5b+ 1726-0x210c))){($__clientSupportsSha256=(0x1010+ 3508-0x1dc4));}else{(
$__clientSupportsSha256=(0x14e1+ 1414-0x1a66));}}sub isClientSupporingSha256{
return ($__clientSupportsSha256);}sub setIfClientSupportsHelloWithAdmin{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x18da+ 2621-0x2312),(0x04bf+ 6734-0x1f0d),(0x04b6+ 3682-0x1303))){(
$__clientSupportsHelloWithAdmin=(0x06cc+ 5796-0x1d6f));}}else{(
$__clientSupportsHelloWithAdmin=(0x15e4+ 1833-0x1d0d));}}sub 
isClientSupportingHelloWithAdmin{if (($__clientSupportsHelloWithAdmin==
(0x0c15+ 6655-0x2613))){return ((0x15db+ 314-0x1714));}return (
(0x00e7+  58-0x0121));}sub setIfClientSupportingEncodedUserInHello{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x0adc+ 6798-0x2562),(0x1a8f+ 1703-0x2136),(0x0be7+ 102-0x0bad))){(
$__clientSupportingEncodedUserInHello=(0x0696+ 7423-0x2394));}}else{(
$__clientSupportingEncodedUserInHello=(0x09cf+ 6405-0x22d4));}}sub 
isClientSupportingEncodedUserInHello{if (($__clientSupportingEncodedUserInHello
==(0x0f88+ 4645-0x21ac))){return ((0x0814+ 5503-0x1d92));}return (
(0x1889+ 2210-0x212b));}sub setDownwardCompatibilitySudoVerification{if (
isClientNxserver ()){if (isClientVersionGreaterOrEqual ((0x1221+ 3077-0x1e21),
(0x10fa+ 4003-0x209d),(0x18e8+ 1856-0x2007))){(
$__downwardCompatibilitySudoVerification=(0x1dda+ 595-0x202d));}}}sub 
isDownwardCompatibilitySudoVerification{return (
$__downwardCompatibilitySudoVerification);}sub 
setDownwardCompatibilityEmptyCommand{if (isClientNxserver ()){if (
isClientVersionGreaterOrEqual ((0x0099+ 2524-0x0a70),(0x0e5d+ 4448-0x1fbd),
(0x0419+ 457-0x05c1))){($__downwardCompatibilityEmptyCommand=
(0x1f79+ 1684-0x260d));}}}sub isDownwardCompatibilityEmptyCommand{return (
$__downwardCompatibilityEmptyCommand);}sub isClientVersion{(my $major=shift (@_)
);(my $minor=shift (@_));(my $patch=shift (@_));if ((not (isClientVersionSet ())
)){return ((0x1b12+ 1017-0x1f0b));}if ((not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x0223+ 5761-0x18a3));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($major==$__clientMajorVersion)){if (($minor eq 
"\x61\x6e\x79")){return ((0x0507+ 560-0x0736));}if (($minor==
$__clientMinorVersion)){if ((($patch eq "\x61\x6e\x79")or ($patch==
$__clientPatchVersion))){return ((0x0949+ 3847-0x184f));}}}return (
(0x0ee6+ 2628-0x192a));}sub isClientVersionGreaterOrEqual{(my $major=shift (@_))
;(my $minor=shift (@_));(my $patch=shift (@_));if ((not (isClientVersionSet ()))
){return ((0x0266+ 2207-0x0b05));}if ((not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x08ec+ 7350-0x25a1));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($__clientMajorVersion>$major)){return (
(0x0bd4+ 942-0x0f81));}if (($__clientMajorVersion==$major)){if ((($minor eq 
"\x61\x6e\x79")or ($__clientMinorVersion>$minor))){return ((0x0191+   7-0x0197))
;}if (($__clientMinorVersion==$minor)){if ((($patch eq "\x61\x6e\x79")or (
$__clientPatchVersion>=$patch))){return ((0x1563+ 712-0x182a));}}}return (
(0x01d5+ 380-0x0351));}sub isClientVersionLesserOrEqual{(my $major=shift (@_));(my $minor
=shift (@_));(my $patch=shift (@_));if ((not (isClientVersionSet ()))){return (
(0x0158+ 5955-0x189b));}if ((not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x082d+ 6960-0x235c));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($__clientMajorVersion<$major)){return (
(0x0282+ 3957-0x11f6));}if (($__clientMajorVersion==$major)){if ((($minor eq 
"\x61\x6e\x79")or ($__clientMinorVersion<$minor))){return ((0x0600+ 6145-0x1e00)
);}if (($__clientMinorVersion==$minor)){if ((($patch eq "\x61\x6e\x79")or (
$__clientPatchVersion<=$patch))){return ((0x0054+ 3317-0x0d48));}}}return (
(0x1e43+ 1440-0x23e3));}sub isClientNxclient{if (($__clientName eq 
"\x6e\x78\x63\x6c\x69\x65\x6e\x74")){return ((0x1412+ 4785-0x26c2));}else{return
 ((0x03d0+ 6552-0x1d68));}}sub isClientNxserver{if (($__clientName eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){return ((0x1414+ 1957-0x1bb8));}else{return
 ((0x080f+ 1954-0x0fb1));}}sub isClientNxwebclient{if (($__clientName eq 
"\x6e\x78\x77\x65\x62\x63\x6c\x69\x65\x6e\x74")){return ((0x1185+ 3940-0x20e8));
}else{return ((0x0460+ 1468-0x0a1c));}}sub isClientNxmanager{if (($__clientName 
eq "\x6e\x78\x6d\x61\x6e\x61\x67\x65\x72")){return ((0x020d+ 7601-0x1fbd));}else
{return ((0x01ac+ 5111-0x15a3));}}sub isClientNameSet{if ((($__clientName eq 
"\x6e\x6f\x74\x73\x65\x74")or ($__clientName eq ("")))){return (
(0x1be0+ 468-0x1db4));}return ((0x1c67+ 2235-0x2521));}sub isClientVersionSet{if
 ((((((($__clientMajorVersion eq "\x6e\x6f\x74\x73\x65\x74")or (
$__clientMajorVersion eq ("")))or ($__clientMinorVersion eq 
"\x6e\x6f\x74\x73\x65\x74"))or ($__clientMinorVersion eq ("")))or (
$__clientPatchVersion eq "\x6e\x6f\x74\x73\x65\x74"))or ($__clientPatchVersion 
eq ("")))){return ((0x02f8+ 2392-0x0c50));}return ((0x0970+ 3195-0x15ea));}sub 
setClientName{($__clientName=shift (@_));($GLOBAL::CLIENT_NAME=$__clientName);}
sub setMainServerClientName{($__mainServerClientName=shift (@_));}sub 
setClientMajorVersion{($__clientMajorVersion=shift (@_));(
$GLOBAL::CLIENT_MAJOR_VERSION=$__clientMajorVersion);}sub setClientMinorVersion{
($__clientMinorVersion=shift (@_));($GLOBAL::CLIENT_MINOR_VERSION=
$__clientMinorVersion);}sub setClientPatchVersion{($__clientPatchVersion=shift (
@_));($GLOBAL::CLIENT_PATCH_VERSION=$__clientPatchVersion);}sub setClientBrowser
{($__clientBrowser=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x3a\x73\x65\x74\x43\x6c\x69\x65\x6e\x74\x42\x72\x6f\x77\x73\x65\x72\x3a\x20"
.$__clientBrowser)."\x2e"));}sub getClientBrowser{return ($__clientBrowser);}sub
 setClientPlatform{($__clientPlatform=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x3a\x73\x65\x74\x43\x6c\x69\x65\x6e\x74\x50\x6c\x61\x74\x66\x6f\x72\x6d\x3a\x20"
.$__clientPlatform)."\x2e"));}sub getClientPlatform{return ($__clientPlatform);}
sub getClientName{return ($__clientName);}sub getMainServerClientName{
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4d\x61\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x63\x6c\x69\x65\x6e\x74\x20\x6e\x61\x6d\x65\x20\x27"
.$__mainServerClientName)."\x27\x2e"));return ($__mainServerClientName);}sub 
getClientMajorVersion{return ($__clientMajorVersion);}sub getClientMinorVersion{
return ($__clientMinorVersion);}sub getClientPatchVersion{return (
$__clientPatchVersion);}sub getClientVersion{(my $client=((((
getClientMajorVersion ()."\x2e").getClientMinorVersion ())."\x2e").
getClientPatchVersion ()));return ($client);}sub setEncodeUsernameForClient{(
$__encodeUsernameForClient=(0x07a5+ 5187-0x1be7));}sub encodeUsernameForClient{
if (($__encodeUsernameForClient==(0x0d80+ 2523-0x175a))){return (
(0x0a54+ 1829-0x1178));}return ((0x0be3+ 391-0x0d6a));}sub 
setDecodeUsernameFromClient{($__decodeUsernameFromClient=(0x03b4+ 3177-0x101c));
}sub decodeUsernameFromClient{if (($__decodeUsernameFromClient==
(0x14dd+ 2618-0x1f16))){return ((0x1330+ 1639-0x1996));}return (
(0x07d7+ 3420-0x1533));}sub setSessionRealConnected{($__sessionRealConnecter=
shift (@_));}sub removeSessionRealConnected{($__sessionRealConnecter=(""));}sub 
isSessionRealConnected{(my $sessionID=shift (@_));if (($__sessionRealConnecter 
eq $sessionID)){return ((0x05bb+ 839-0x0901));}return ((0x1760+ 1289-0x1c69));}
sub saveTimestamp{(my $id=shift (@_));(my $caption=shift (@_));(my ($sec,
$microsec)=Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=
sprintf ("\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,
(0x0521+ 1851-0x0c5c),(0x0d3a+ 4247-0x1dce)));Logger::debug2 (((((((
"\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27".$caption).
"\x27\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x61\x74\x20\x27").$sec).
"\x2c").$milisec)."\x27"));($$__timestamps{$id}={});($$__timestamps{$id}{
"\x63\x61\x70\x74\x69\x6f\x6e"}=$caption);($$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"}=$sec);($$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"}=$milisec);}
sub getTimePassedFromSavedTimestamp{(my $id=shift (@_));if ((not (defined (
$$__timestamps{$id})))){return ((0x0511+ 4733-0x178e));}(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,(0x0834+ 4109-0x1841),
(0x0166+ 5052-0x151f)));(my $startSeconds=$$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"});(my $startMiliseconds=
$$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"});(my $liveTimeSeconds
=($sec-$startSeconds));(my $liveTimeMiliseconds=($milisec-$startMiliseconds));if
 (($liveTimeMiliseconds<(0x0805+ 6833-0x22b6))){($liveTimeMiliseconds=(
$liveTimeMiliseconds+(0x1d64+ 2317-0x2289)));($liveTimeSeconds=($liveTimeSeconds
-(0x08da+ 5401-0x1df2)));}($liveTimeMiliseconds=sprintf ("\x25\x30\x33\x64",
$liveTimeMiliseconds));if (($liveTimeMiliseconds eq "\x30\x30\x30")){(
$liveTimeMiliseconds=(0x0c46+ 5931-0x2371));}(my $liveTime=(($liveTimeSeconds.
"\x2e").$liveTimeMiliseconds));Logger::debug (((
"\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27".$$__timestamps{$id}{
"\x63\x61\x70\x74\x69\x6f\x6e"}).((
"\x27\x20\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x65\x64\x20\x27".$liveTime).
"\x27\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20")));delete ($$__timestamps{$id});
return ($liveTime);}sub setIfClientSupportsNodeAndLabelParameter{if (
isClientVersionGreaterOrEqual ((0x0f8d+ 3705-0x1e02),(0x2393+ 789-0x26a4),
(0x05f1+ 4916-0x191c))){($__clientSupportsNodeAndLabelParameter=
(0x0d93+ 3827-0x1c85));}else{($__clientSupportsNodeAndLabelParameter=
(0x1312+ 3183-0x1f81));}}sub isClientSupportingNodeAndLabelParameter{if ((
$__clientSupportsNodeAndLabelParameter==(0x1715+ 475-0x18ef))){return (
(0x122d+ 4544-0x23ec));}return ((0x0031+ 8551-0x2198));}sub 
setIfClientSupportsNodeAndStatusParameter{if (isClientVersionGreaterOrEqual (
(0x03a4+ 167-0x0445),(0x0180+ 510-0x037e),(0x0370+  42-0x0374))){(
$__clientSupportsNodeAndStatusParameter=(0x1028+ 2778-0x1b01));}else{(
$__clientSupportsNodeAndStatusParameter=(0x00b9+ 2767-0x0b88));}}sub 
isClientSupportingNodeAndStatusParameter{if ((
$__clientSupportsNodeAndStatusParameter==(0x127a+ 955-0x1634))){return (
(0x1bef+ 2254-0x24bc));}return ((0x15ca+ 3565-0x23b7));}sub 
setIfClientSupportsDialogInConnectionPolicy{if (isClientVersionGreaterOrEqual (
(0x1f25+ 640-0x21a1),(0x0c7d+ 3710-0x1af7),(0x0632+ 6064-0x1dd8))){(
$__clientSupportsDialogInConnectionPolicy=(0x04f4+ 1428-0x0a87));}else{(
$__clientSupportsDialogInConnectionPolicy=(0x0e2c+ 3300-0x1b10));}}sub 
isClientSupportingDialogInConnectionPolicy{if ((
$__clientSupportsDialogInConnectionPolicy==(0x1553+ 3327-0x2251))){return (
(0x0dd5+ 2966-0x196a));}return ((0x0914+ 4271-0x19c3));}sub 
setIfClientSupportsSystemDesktopsInConnectionPolicy{if (
isClientVersionGreaterOrEqual ((0x0913+ 7251-0x255f),(0x12d8+ 3849-0x21e1),
(0x0578+ 5557-0x1ac4))){($__clientSupportsSystemDesktopsInConnectionPolicy=
(0x1bd0+ 1772-0x22bb));}else{($__clientSupportsSystemDesktopsInConnectionPolicy=
(0x02a0+ 3912-0x11e8));}}sub isClientSupportsSystemDesktopsInConnectionPolicy{if
 (($__clientSupportsSystemDesktopsInConnectionPolicy==(0x1300+ 3598-0x210d))){
return ((0x0781+ 3948-0x16ec));}return ((0x07ad+ 3003-0x1368));}sub 
setIfClientSupportsNxFrameBufferFeature{if (isClientVersionGreaterOrEqual (
(0x004d+ 1671-0x06cf),(0x17cd+ 3011-0x2390),(0x1a07+ 2908-0x254f))){(
$__clientSupportsNxFrameBufferFeature=(0x116c+ 1107-0x15be));}else{(
$__clientSupportsNxFrameBufferFeature=(0x1f92+ 1417-0x251b));}}sub 
isClientSupportingNxFrameBufferFeature{if ((
$__clientSupportsNxFrameBufferFeature==(0x0bcb+ 891-0x0f45))){return (
(0x1c7d+ 1442-0x221e));}return ((0x1374+ 398-0x1502));}sub 
getDisconnectedSessionExpiryLimitValue{if ((($GLOBAL::DisconnectedSessionExpiry 
eq "\x6e\x6f\x74\x53\x65\x74")or ($GLOBAL::DisconnectedSessionExpiry eq ("")))){
if ((main::imRemoteServer ()and 
NXSessionParameters::isMainServerDisconnectedSessionExpiryKeySet ())){return (
NXSessionParameters::getMainServerDisconnectedSessionExpiryLimitValue ());}else{
return ((0x1fdb+ 1706-0x2685));}}else{return ($GLOBAL::DisconnectedSessionExpiry
);}}sub isDisconnectedSessionExpiryKeySet{if (
getDisconnectedSessionExpiryLimitValue ()){return ((0x0979+ 1361-0x0ec9));}else{
return ((0x1833+ 1485-0x1e00));}}sub setIfClientSupportsDesktopViewMode{if (
isClientVersionGreaterOrEqual ((0x0f64+ 5437-0x249d),(0x00bf+ 5477-0x161f),
(0x1de3+ 2057-0x25eb))){($__clientSupportsDesktopViewMode=(0x07ac+ 4624-0x19bb))
;}else{($__clientSupportsDesktopViewMode=(0x04a6+ 4127-0x14c5));}}sub 
isClientSupportDesktopViewMode{if (($__clientSupportsDesktopViewMode==
(0x0ed8+ 2140-0x1733))){return ((0x139c+ 1342-0x18d9));}return (
(0x208d+ 256-0x218d));}sub setIfClientSupportsProxyPacketPriority{if (
isClientVersionGreaterOrEqual ((0x0ae1+ 6468-0x2420),(0x10a3+ 3953-0x2014),
(0x03c0+ 1880-0x0af7))){($__clientSupportsProxyPacketPriority=
(0x0b22+ 5958-0x2267));}}sub isClientSupportingProxyPacketPriority{return (
$__clientSupportsProxyPacketPriority);}sub 
setIfClientSupportsManualNodeSelection{if (isClientVersionGreaterOrEqual (
(0x0c54+ 6298-0x24ea))){($__clientSupportsManualNodeSelection=
(0x14e6+ 2131-0x1d38));}}sub isClientSupportsManualNodeSelection{return (
$__clientSupportsManualNodeSelection);}sub waitForNetlogonServiceIfNeeded{if ((
$GLOBAL::NetLogonDependency==(0x0725+ 918-0x0abb))){Logger::debug (
"\x43\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x65\x20\x74\x75\x72\x6e\x65\x64\x20\x6f\x66\x66\x2e"
);return ((0x0b47+ 547-0x0d69));}(my $notifyAboutWaitingForNetLogonRunningSent=
(0x11c9+ 5201-0x2619));while ((0x039c+ 7452-0x20b7)){(my $state=
libnxhs::NXIsWinDomainLogon ());Logger::debug (((
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x53\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x65\x20\x69\x73\x20\x27"
.$state)."\x27\x2e"));if (($state==(-(0x1281+ 4523-0x242b)))){
Common::NXCore::reportErrorFromNXPL (
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x49\x73\x57\x69\x6e\x44\x6f\x6d\x61\x69\x6e\x4c\x6f\x67\x6f\x6e\x20\x66\x61\x69\x6c\x65\x64\x2e"
);return ((0x0255+ 9113-0x25ee));}elsif (($state==(0x1161+ 164-0x1205))){
Logger::debug (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x69\x6e\x73\x74\x61\x6c\x6c\x65\x64\x2e"
);return ((0x0492+ 2953-0x101a));}elsif (($state==(0x0626+ 4382-0x1743))){
Logger::debug (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
);return ((0x0149+ 6382-0x1a37));}elsif (((($state==(0x0851+ 5730-0x1eb1))or (
$state==(0x1188+ 948-0x1537)))or ($state==(0x0da9+  38-0x0dc8)))){if ((
$notifyAboutWaitingForNetLogonRunningSent==(0x00dc+ 1256-0x05c3))){
Logger::warning (
"\x57\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x74\x61\x72\x74\x20\x6f\x66\x20\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x2e"
);if (($state==(0x11b4+ 1924-0x1936))){NXMsg::send_response (
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x53\x65\x72\x76\x69\x63\x65\x73"
,"\x53\x65\x72\x76\x65\x72","\x73\x74\x61\x72\x74\x65\x64");}elsif (($state==
(0x1049+ 644-0x12c8))){NXMsg::send_response (
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x65\x74\x4c\x6f\x67\x6f\x6e\x54\x6f\x53\x74\x61\x72\x74"
,"\x53\x65\x72\x76\x65\x72","\x72\x65\x73\x75\x6d\x65\x64");}else{
NXMsg::send_response (
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x65\x74\x4c\x6f\x67\x6f\x6e\x54\x6f\x53\x74\x61\x72\x74"
,"\x53\x65\x72\x76\x65\x72","\x70\x61\x75\x73\x65\x64");}(
$notifyAboutWaitingForNetLogonRunningSent=(0x0214+ 5366-0x170a));}main::nxsleep 
((0x02af+ 2512-0x0c7c));}elsif (($state==(0x05c3+ 3473-0x1351))){Logger::error (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x6f\x70\x70\x69\x6e\x67\x2c\x20\x6e\x65\x65\x64\x20\x6d\x61\x6e\x75\x61\x6c\x20\x73\x74\x61\x72\x74\x75\x70\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x2e"
);return ((0x0bca+ 4387-0x1ced));}elsif (($state==(0x16d5+ 1454-0x1c7f))){
Logger::debug (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ((0x17d7+ 804-0x1afa));}elsif (($state==(0x07ef+ 6830-0x2297))){
Logger::error (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x70\x61\x75\x73\x65\x64\x2c\x20\x6e\x65\x65\x64\x20\x6d\x61\x6e\x75\x61\x6c\x20\x63\x6f\x6e\x74\x69\x6e\x75\x65\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x2e"
);return ((0x16e4+ 568-0x191c));}else{Logger::error (((
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x73\x74\x61\x74\x75\x73\x20"
.$state)."\x2e"));return ((0x194c+ 709-0x1c11));}}}sub setIsUdpConnection{(
$__udpConnection=(0x00c2+ 9228-0x24cd));}sub isUdpConnection{return (
$__udpConnection);}sub setFutureMainSession{($__futureMainSession=shift (@_));}
sub getFutureMainSession{return ($__futureMainSession);}sub setServerIsRestart{(
$__serverIsRestartServer=(0x0188+ 9446-0x266d));}sub isServerRestart{return (
$__serverIsRestartServer);}sub setServerIsShutdown{($__serverIsShutdownServer=
(0x0e47+ 235-0x0f31));}sub isServerShutdown{return ($__serverIsShutdownServer);}
sub serverIsNotSessionServer{if (isServerShutdown ()){return (
(0x0577+ 7253-0x21cb));}return ((0x02df+ 6030-0x1a6d));}sub isRedirectSupported{
if (isClientSupportingRedirecting ()){return ((0x03a3+ 1146-0x081c));}return (
(0x0b75+ 1383-0x10dc));}sub getHostnameForPropertyRequest{(my $hostInfo=
Common::NXInfo::getHostInfo ());return (Common::NXCore::urlencode ($hostInfo));}
sub setIfClientIsSupportingDynamicFieldSizesInSessionList{if (((not (
isClientNxclient ()))or isClientVersionGreaterOrEqual ((0x1a74+ 2168-0x22e7),
(0x1998+ 3418-0x26f2),(0x219c+ 1235-0x263f)))){(
$__clientSupportsDynamicFieldSizesInSessionList=(0x0531+ 8252-0x256c));}else{(
$__clientSupportsDynamicFieldSizesInSessionList=(0x0731+ 1112-0x0b89));}}sub 
isClientSupportingDynamicFieldSizesInSessionList{return (
$__clientSupportsDynamicFieldSizesInSessionList);}sub 
isClientSupportingClientMenuConfiguration{return (
$__clientSupportingClientMenuConfiguration);}sub 
setIfClientSupportingClientMenuConfiguration{if (isClientNxserver ()){return (
(0x05cc+ 4296-0x1694));}if (isClientVersionGreaterOrEqual ((0x1d45+ 1324-0x226c)
,(0x000d+ 2519-0x09e3),(0x1c94+ 1282-0x2185))){(
$__clientSupportingClientMenuConfiguration=(0x0cd3+ 1311-0x11f1));}}sub 
isClientSupportingSeparateUsersOnSessionList{return (
$__clientSupportingSeparateUsersOnSessionList);}sub 
setIfClientSupportingDisableCredentialsStoring{if ((
isClientVersionGreaterOrEqual ((0x0ef1+ 2457-0x1885),(0x0042+ 9679-0x2610),
(0x151b+ 4478-0x2670))and (not (isClientNxserver ())))){(
$__clientSupportingDisableCredentialsStoring=(0x017d+ 3743-0x101b));}else{(
$__clientSupportingDisableCredentialsStoring=(0x0f75+ 1311-0x1494));}}sub 
isClientSupportingDisableCredentialsStoring{return (
$__clientSupportingDisableCredentialsStoring);}sub 
setIfClientSupportingSeparateUsersOnSessionList{if (
isClientVersionGreaterOrEqual ((0x139d+ 3744-0x2238),(0x182d+ 3231-0x24cb),
(0x09cd+ 6733-0x23fa))){($__clientSupportingSeparateUsersOnSessionList=
(0x0421+ 6798-0x1eae));}else{($__clientSupportingSeparateUsersOnSessionList=
(0x002c+ 1925-0x07b1));}}sub setDaemonProcess{($__serverIsDaemon=
(0x16a7+ 1181-0x1b43));}sub isDaemonProcess{return ($__serverIsDaemon);}sub 
isAdministrator{if (NXLogin::isAuthenticated ()){return (
NXLogin::isAdministrator ());}else{return (main::effectiveUserIsAdministrator ()
);}}sub setIfClientSupportsExpiredPasswordChange{if (
isClientVersionGreaterOrEqual ((0x019f+ 3762-0x104c),(0x0eb8+ 1282-0x13b9),
(0x144f+ 1445-0x19e9))){($__clientSupportsExpiredPasswordChange=
(0x01a8+ 9529-0x26e0));}else{($__clientSupportsExpiredPasswordChange=
(0x0352+ 6033-0x1ae3));}}sub isClientSupportsExpiredPasswordChange{return (
$__clientSupportsExpiredPasswordChange);}sub setIfClientSupportsDuoAuth{if (
isClientVersionGreaterOrEqual ((0x0ac7+ 2958-0x164f),(0x00d1+ 5820-0x1788),
(0x0a08+ 6568-0x23af))){($__clientSupportDuoAuth=(0x0a68+ 339-0x0bba));}else{(
$__clientSupportDuoAuth=(0x08ad+ 2031-0x109c));}}sub isClientSupportsDuoAuth{
return ($__clientSupportDuoAuth);}sub setClientSupportsNoMachineTwoFactor{(
$__clientSupportNoMachineNetworkTwoFactor=(0x0e38+ 1758-0x1516));if ((
isClientNxclient ()and isClientVersionGreaterOrEqual ((0x09ad+ 3801-0x187f),
(0x0282+ 522-0x048c),(0x0d05+ 257-0x0d74)))){(
$__clientSupportNoMachineNetworkTwoFactor=(0x011b+ 4564-0x12ee));}}sub 
isClientSupportsNoMachineTwoFactor{return (
$__clientSupportNoMachineNetworkTwoFactor);}sub 
setIfClientSupportsIgnoreSessionTypeForListSession{if (
isClientVersionLesserOrEqual ((0x1f5c+ 469-0x212e),(0x2040+ 486-0x2221),
(0x0429+ 3583-0x1228))){($__clientSupportsIgnoreSessionTypeForListSession=
(0x11d8+ 3035-0x1db2));}else{($__clientSupportsIgnoreSessionTypeForListSession=
(0x02b3+ 1478-0x0879));}}sub isClientSupportsIgnoreSessionTypeForListSession{
return ($__clientSupportsIgnoreSessionTypeForListSession);}sub 
setIfClientSupportsPackedMessages{if ((isClientNxserver ()and 
isClientVersionGreaterOrEqual ((0x1d33+ 2338-0x264f),(0x0400+ 6246-0x1c66),
(0x0301+ 1589-0x0919)))){($__clientSupportsPackedMessages=(0x1739+ 3402-0x2482))
;}else{($__clientSupportsPackedMessages=(0x1cb5+ 1843-0x23e8));}}sub 
setClientSupportsPackedMessages{($__clientSupportsPackedMessages=
(0x0c15+ 5369-0x210d));}sub isClientSupportsPackedMessages{return (
$__clientSupportsPackedMessages);}sub setIfClientSupportsTranslatedMessages{if (
(not (isClientNxserver ()))){($__clientSupportsTranslatedMessages=
(0x0916+ 7526-0x267b));}else{($__clientSupportsTranslatedMessages=
(0x0428+ 1505-0x0a09));}}sub isClientSupportsTranslatedMessages{return (
$__clientSupportsTranslatedMessages);}sub 
setIfClientSupportsErrorDuringPasswordChange{if (isClientVersionGreaterOrEqual (
(0x082f+ 7224-0x2461),(0x047b+ 3586-0x127d),(0x0b79+ 5134-0x1f66))){(
$__clientSupportsErrorDuringPasswordChange=(0x1f00+ 1815-0x2616));}else{(
$__clientSupportsErrorDuringPasswordChange=(0x0dba+ 5586-0x238c));}}sub 
isClientSupportsErrorDuringPasswordChange{return (
$__clientSupportsErrorDuringPasswordChange);}sub 
setIfClientSupportsPasswordRequest{if (((isClientNxclient ()and 
isClientVersionGreaterOrEqual ((0x151a+ 929-0x18b5),(0x0c71+ 515-0x0e72),
(0x0d26+ 386-0x0ea8)))or isClientNxwebclient ())){(
$__clientSupportsPasswordRequest=(0x0184+ 6895-0x1c72));}else{(
$__clientSupportsPasswordRequest=(0x0444+ 4962-0x17a6));}}sub 
isClientSupportsPasswordRequest{return ($__clientSupportsPasswordRequest);}sub 
setClientSupportsSeparateAuthInMultiServer{(
$__clientSupportsSeparateAuthInMultiServer=(0x0ea1+ 3618-0x1cc3));if (
isClientVersionGreaterOrEqual ((0x07b8+ 3333-0x14b6),(0x0c17+ 2851-0x173a),
(0x0648+ 4954-0x18eb))){($__clientSupportsSeparateAuthInMultiServer=
(0x2145+ 783-0x2453));}}sub doesClientSupportSeparateAuthInMultiServer{return (
$__clientSupportsSeparateAuthInMultiServer);}sub 
setClientSupportsAuthRequiredNamedAsFurtherAuth{if ((not (
isClientVersionGreaterOrEqual ((0x06c9+ 4604-0x18bd),(0x10d5+ 2183-0x195c),
(0x0740+ 408-0x087b))))){($__clientSupportsAuthRequiredNamedAsFurtherAuth=
(0x0cf0+ 4843-0x1fdb));}}sub doesClientSupportsAuthRequiredNamedAsFurtherAuth{
return ($__clientSupportsAuthRequiredNamedAsFurtherAuth);}sub 
setClientSupportstServerListConnections{($__clientSupportsServerListConnections=
(0x0141+  86-0x0197));if (isClientVersionGreaterOrEqual ((0x181c+ 1621-0x1e6b),
(0x0186+ 2390-0x0ad2),(0x09c4+ 2960-0x154d))){(
$__clientSupportsServerListConnections=(0x1a66+ 806-0x1d8b));}}sub 
doesClientSupportServerListConnections{return (
$__clientSupportsServerListConnections);}sub 
setIfClientSupportsAutomaticRecording{if (isClientVersionGreaterOrEqual (
(0x00c3+ 4414-0x11fa),(0x1c47+ 1203-0x20fa),(0x0958+ 7202-0x24db))){(
$__clientSupportsAutomaticRecording=(0x12a7+ 134-0x132c));}else{(
$__clientSupportsAutomaticRecording=(0x00b2+ 6753-0x1b13));}}sub 
isClientSupportingAutomaticRecording{if (($__clientSupportsAutomaticRecording==
(0x0547+ 7493-0x228b))){return ((0x0f03+ 3254-0x1bb8));}return (
(0x0339+ 2149-0x0b9e));}sub setClientSupportsAnywhereAuthMethods{if (((
isClientNxclient ()and isClientVersionGreaterOrEqual ((0x0852+ 4349-0x1948),
(0x0719+ 2697-0x11a2),(0x0438+ 2593-0x0dce)))or isClientNxwebclient ())){(
$__clientSupportsAnywhereAuthMethods=(0x0950+ 6477-0x229c));}}sub 
isClientSupportsAnywhereAuthMethods{return ($__clientSupportsAnywhereAuthMethods
);}sub setClientSupportsCredentialsEncryption{if ((isClientNxwebclient ()and 
isClientVersionGreaterOrEqual ((0x073d+ 929-0x0ad7),(0x2262+ 147-0x22f5),
(0x031a+ 4124-0x12a6)))){($__clientSupportsCredentialsEncryption=
(0x0609+ 1049-0x0a21));}}sub isClientSupportsCredentialsEncryption{return (
$__clientSupportsCredentialsEncryption);}sub 
setIfClientSupportsSelectForwardMethod{if (isClientVersionGreaterOrEqual (
(0x0b1d+ 2542-0x1504),(0x1b47+ 132-0x1bcb),(0x1578+ 997-0x18b5))){(
$__clientSupportSelectForwardMethod=(0x0289+ 1819-0x09a3));}}sub 
isClientSupportsSelectForwardMethod{return ($__clientSupportSelectForwardMethod)
;}sub isClientSupportingDesktopSharing{return ($__clientSupportsDesktopSharing);
}sub setIfClientSupportsDesktopSharing{if (isClientVersionGreaterOrEqual (
(0x112f+ 4926-0x2465),(0x0a85+ 6206-0x22c3),(0x0742+ 1568-0x0d4e))){
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x2e"
);($__clientSupportsDesktopSharing=(0x1354+ 1867-0x1a9e));return;}Logger::debug 
(
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x2e"
);($__clientSupportsDesktopSharing=(0x041f+ 4823-0x16f6));}sub 
isClientSupportsTerminateReason{return ($__clientSupportsTerminateReason);}sub 
setIfClientSupportsTerminateReason{if (isClientVersionGreaterOrEqual (
(0x0a0b+  13-0x0a11),(0x1324+ 1681-0x19b4),(0x0213+ 6414-0x1b1c))){(
$__clientSupportsTerminateReason=(0x0ddb+ 5893-0x24df));}}sub 
isClientSupportsSubserversNamedAsNodes{return (
$__clientSupportsSubserversNamedAsNodes);}sub 
setIfClientSupportsSubserversNamedAsNodes{if (isClientVersionLesserOrEqual (
(0x0bf1+ 1856-0x1329),(0x19cc+ 2118-0x2212),(0x04b5+ 7545-0x21d8))){(
$__clientSupportsSubserversNamedAsNodes=(0x0bd9+ 5385-0x20e2));}else{(
$__clientSupportsSubserversNamedAsNodes=(0x0c41+ 2376-0x1588));}}sub 
isUseNodeAsSubserver{if ((isClientSupportsSubserversNamedAsNodes ()and 
NXLicense::isMultiServerFeature ())){return ((0x06d9+ 1921-0x0e59));}return (
(0x1d5f+ 1252-0x2243));}sub setClientSupportsExpireDateStatus{if (
isClientVersionLesserOrEqual ((0x1098+ 661-0x1326),(0x1887+ 3302-0x256a),
(0x1614+ 4258-0x26b6))){($__clientSupportsExpireDateStatus=(0x034f+ 4261-0x13f4)
);}else{($__clientSupportsExpireDateStatus=(0x0f0c+ 2626-0x194d));}}sub 
setClientSupportsExpireInformation{if (isClientVersionLesserOrEqual (
(0x01dc+ 9399-0x268b),(0x0478+ 1384-0x09e0),(0x0c13+ 4028-0x1b5d))){(
$__clientSupportsExpireInformation=(0x0351+ 2770-0x0e23));}else{(
$__clientSupportsExpireInformation=(0x045d+ 2351-0x0d8b));}}sub 
setClientSupportsMissingLicenseFileOrWrongAcronym{if (
isClientVersionLesserOrEqual ((0x055a+ 5578-0x1b1c),(0x0649+ 6965-0x217e),
(0x1269+ 2313-0x1ae1))){($__clientSupportsMissingLicenseFileOrWrongAcronym=
(0x02c3+ 8526-0x2411));}else{($__clientSupportsMissingLicenseFileOrWrongAcronym=
(0x17e8+ 375-0x195e));}}sub setClientSupportWrongPlatformLicenseInfo{if (
isClientVersionLesserOrEqual ((0x18fb+ 2056-0x20fb),(0x1b8a+ 224-0x1c6a),
(0x1668+  44-0x15f6))){($__clientSupportWrongPlatformLicenseInfo=
(0x010f+ 5313-0x15d0));}else{($__clientSupportWrongPlatformLicenseInfo=
(0x1007+ 3814-0x1eec));}}sub setClientSupportNodeFlags{if (
isClientVersionLesserOrEqual ((0x03a8+ 7683-0x21a3),(0x0d05+ 2058-0x150f),
(0x11c0+ 3594-0x1f26))){($__clientSupportNodeFlags=(0x0933+ 5814-0x1fe9));}else{
($__clientSupportNodeFlags=(0x158a+ 3642-0x23c3));}}sub 
setClientSupportsReportingAllConnections{if (isClientVersionLesserOrEqual (
(0x079b+ 4165-0x17d8),(0x2118+ 1050-0x2532),(0x04e9+ 5942-0x1b8d))){(
$__clientSupportsReportingAllConnections=(0x189a+ 1059-0x1cbd));}else{(
$__clientSupportsReportingAllConnections=(0x086d+ 2660-0x12d0));}}sub 
setClientSupportsFileTransferInfomation{if (isClientVersionLesserOrEqual (
(0x18ac+ 1593-0x1edd),(0x04b2+ 5249-0x1933),(0x260f+ 348-0x26d8))){(
$__clientSupportsFileTransferInfomation=(0x0d02+ 3560-0x1aea));}else{(
$__clientSupportsFileTransferInfomation=(0x0d73+ 2572-0x177e));}}sub 
setClientSupportsPhysicalDestkopAndClusterInformation{if (
isClientVersionLesserOrEqual ((0x03c4+ 8055-0x2333),(0x17a7+ 2585-0x21c0),
(0x12cf+ 2164-0x1aad))){($__clientSupportsPhysicalDekstopAndClusterInfo=
(0x009f+ 7888-0x1f6f));}else{($__clientSupportsPhysicalDekstopAndClusterInfo=
(0x078d+ 1337-0x0cc5));}}sub setClientSupportsGuestTypes{(
$__clientSupportsGuestTypes=(0x023d+ 7419-0x1f38));}sub 
doesClientSupportGuestTypes{return ($__clientSupportsGuestTypes);}sub 
doesClientSupportsExpireDateStatus{return ($__clientSupportsExpireDateStatus);}
sub doesClientSupportsExpireInformation{return (
$__clientSupportsExpireInformation);}sub 
doesClientSupportWrongLicenseOrMissingFile{return (
$__clientSupportsMissingLicenseFileOrWrongAcronym);}sub 
doesClientSupportWrongPlatformLicenseInfo{return (
$__clientSupportWrongPlatformLicenseInfo);}sub doesClientSupportNodeFlags{return
 ($__clientSupportNodeFlags);}sub doesClientSupportsReportingAllConnections{
return ($__clientSupportsReportingAllConnections);}sub 
doesClientSupportsFileTransferInfomation{return (
$__clientSupportsFileTransferInfomation);}sub 
doesClientSupportsPhysicalDesktopRunningInformationAndClusterStats{return (
$__clientSupportsPhysicalDekstopAndClusterInfo);}sub 
setClientSupportsInverseParameter{($__clientSupportsInverseParameter=
(0x12d4+ 3475-0x2067));if (isClientVersionGreaterOrEqual ((0x1e04+ 2079-0x261b),
(0x07d6+ 6914-0x22d8),(0x1657+ 1638-0x1c60))){($__clientSupportsInverseParameter
=(0x1946+ 183-0x19fc));}}sub doesClientSupportInverseParameter{return (
$__clientSupportsInverseParameter);}sub setClientSupportsBrowseWithoutAuth{(
$__clientSupportsBrowseWithoutAuth=(0x0cf9+ 3939-0x1c5c));if (
isClientVersionGreaterOrEqual ((0x0966+ 3258-0x1618),(0x0725+ 797-0x0a42),
(0x0858+ 5809-0x1ea6))){($__clientSupportsBrowseWithoutAuth=
(0x02ba+ 7681-0x20ba));}}sub doesClientSupportBrowseWithoutAuth{return (
$__clientSupportsBrowseWithoutAuth);}sub setClientSupportsMdnsMonitor{(
$__clientSupportsMdnsMonitor=(0x01d0+ 3262-0x0e8e));if (
isClientVersionGreaterOrEqual ((0x08cd+ 818-0x0bf7),(0x114b+ 5353-0x2634),
(0x067b+ 8226-0x261a))){($__clientSupportsMdnsMonitor=(0x1a48+ 1041-0x1e58));}}
sub doesClientSupportMdnsMonitor{return ($__clientSupportsMdnsMonitor);}sub 
setClientSupportsCurrentNodeAddress{($__clientSupportsCurrentNodeAddress=
(0x140a+ 247-0x1501));if (isClientVersionGreaterOrEqual ((0x050f+ 6380-0x1df3),
(0x0a17+ 4884-0x1d2b),(0x0e64+ 6291-0x265c))){(
$__clientSupportsCurrentNodeAddress=(0x0635+ 2958-0x11c2));}}sub 
doesClientSupportCurrentNodeAddress{return ($__clientSupportsCurrentNodeAddress)
;}sub setClientSupportsAllowGuest{($__clientSupportsAllowGuest=
(0x1662+   7-0x1669));if (isClientVersionGreaterOrEqual ((0x1398+ 3690-0x21fa),
(0x0c16+ 1917-0x1393),(0x1081+ 3391-0x1d25))){($__clientSupportsAllowGuest=
(0x0e67+ 2883-0x19a9));}}sub doesClientSupportAllowGuest{return (
$__clientSupportsAllowGuest);}sub setClientSupportsCustomUdpPort{(
$__clientSupportsCustomUdpPort=(0x1cef+ 1987-0x24b2));if (
isClientVersionGreaterOrEqual ((0x1376+ 1062-0x1794),(0x1997+ 164-0x1a3b),
(0x1947+ 1591-0x1ee1))){($__clientSupportsCustomUdpPort=(0x1006+ 888-0x137d));}
return ((0x0650+ 1261-0x0b3c));}sub doesClientSupportCustomUdpPort{return (
$__clientSupportsCustomUdpPort);}sub sendMonitorOnMessage{(my $socket=shift (@_)
);(my $login=shift (@_));(my $name=shift (@_));(my $type=shift (@_));(my $sessionType
=shift (@_));Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x49\x6e\x69\x74\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);($login=NXLogin::getAbsoluteNameForUsernameIfNotDisabled ($login));
sendLocalRecordingValue ($socket,$login,$name);sendServerVersion ($socket);
sendPhysicaldesktopSharing ($socket,$login,$type,$sessionType);
sendFileTransferValue ($socket,$login,$name);my ($message);if ($type){($message=
(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ATTACHED_USER_MONITOR).
"\x20\x4d\x4f\x4e\x49\x54\x4f\x52\x20\x4f\x4e\x20\x74\x79\x70\x65\x3d").$type).
"\x20\x0a"));}else{($message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ATTACHED_USER_MONITOR).
"\x20\x4d\x4f\x4e\x49\x54\x4f\x52\x20\x4f\x4e\x20\x74\x79\x70\x65\x3d\x6e\x6f\x44\x65\x73\x6b\x74\x6f\x70\x20\x0a"
));}(my $ret=NXNodeExec::sendToNode ($message,$socket));if ((($ret==(-
(0x13a1+ 1437-0x193d)))or ($ret==(0x0211+ 7542-0x1f87)))){Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"));}else{Logger::debug (((
"\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$message).
"\x27\x20\x77\x61\x73\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"))
;}}sub sendLocalRecordingValue{(my $socket=shift (@_));(my $login=shift (@_));(my $name
=shift (@_));(my $localRec=undef);if (main::imRemoteServer ()){($localRec=
NXSessionParameters::getLocalRecording ());}if ((not (defined ($localRec)))){(
$localRec=NXProfilesManager::isLocalRecordingAvailableForUserAndNode ($login,
$name));}(my $ret=NXNodeExec::sendToNode (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_LOCAL_RECORDING).
"\x20\x6c\x6f\x63\x61\x6c\x2d\x72\x65\x63\x6f\x72\x64\x69\x6e\x67\x20").
$localRec),$socket));if ((($ret==(-(0x0618+ 5018-0x19b1)))or ($ret==
(0x1d99+ 833-0x20da)))){Logger::warning (((
"\x4c\x6f\x63\x61\x6c\x20\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x20"
.$localRec).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
));}else{Logger::debug (((
"\x4c\x6f\x63\x61\x6c\x20\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x20"
.$localRec)."\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"));}}sub 
sendServerVersion{(my $socket=shift (@_));(my $ret=NXNodeExec::sendToNode ((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_SERVER_VERSION).
"\x20\x73\x65\x72\x76\x65\x72\x2d\x76\x65\x72\x73\x69\x6f\x6e\x20").
main::urlencode ((($GLOBAL::PRODUCT_NAME."\x2c").$GLOBAL::SOFTWARE_RELEASE))),
$socket));if ((($ret==(-(0x0245+ 5495-0x17bb)))or ($ret==(0x0be5+ 2816-0x16e5)))
){Logger::warning (((((
"\x53\x65\x72\x76\x65\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x3a\x20".
$GLOBAL::PRODUCT_NAME)."\x2c").$GLOBAL::SOFTWARE_RELEASE).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
));}else{Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x3a\x20".
$GLOBAL::PRODUCT_NAME)."\x2c").$GLOBAL::SOFTWARE_RELEASE).
"\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"));}}sub 
sendPhysicaldesktopSharing{(my $socket=shift (@_));(my $login=shift (@_));(my $type
=shift (@_));(my $sessionType=shift (@_));(my $session=getMySessionID ());
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$sessionType)."\x27\x2e"));if (defined ($type)){if (
Common::NXSessionType::isPhysical ($sessionType)){(my $physicalSharing=
(0x078c+ 7020-0x22f7));if (NXLocalSession::isPhysicalDesktopAccessDisabledInCfg 
()){($physicalSharing=(0x0276+ 2824-0x0d7e));}Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27"
.$session).
"\x27\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x27").
$physicalSharing)."\x27\x2e"));if (($physicalSharing!=(0x0c61+ 4554-0x1e2b))){(
$physicalSharing=NXUsersManager::isPhysicalDesktopSharingEnabled ($login));
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x73\x65\x72\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x27"
.$physicalSharing)."\x27\x2e"));}NXSession2::setDesktopShareValue ($session,
$physicalSharing);(my $ret=NXNodeExec::sendToNode (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_DESKTOP_SHARING).
"\x20\x44\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3d"
).$physicalSharing),$socket));if ((($ret==(-(0x00a4+ 7468-0x1dcf)))or ($ret==
(0x12ff+ 3859-0x2212)))){Logger::warning (((
"\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$login).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x2e"
));}}else{(my $virtualSharing=(0x0996+ 1286-0x0e9b));if (
NXSessionParameters::isVirtualDesktopAccessDisabledInCfg ()){($virtualSharing=
(0x055d+ 8001-0x249e));}Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x56\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27"
.$session).
"\x27\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x27").
$virtualSharing)."\x27\x2e"));(my $ret=NXNodeExec::sendToNode ((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_DESKTOP_SHARING).
"\x20\x44\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3d"
).$virtualSharing),$socket));if ((($ret==(-(0x1865+ 315-0x199f)))or ($ret==
(0x0c9a+ 4977-0x200b)))){Logger::warning (((
"\x56\x69\x72\x74\x75\x61\x6c\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$login).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x2e"
));}NXSession2::setDesktopShareValue ($session,$virtualSharing);}}}sub 
sendFileTransferValue{(my $socket=shift (@_));(my $login=shift (@_));(my $name=
shift (@_));(my $fileTransfer=undef);if (main::imRemoteServer ()){($fileTransfer
=NXSessionParameters::getFileTransfer ());}if ((not (defined ($fileTransfer)))){
($fileTransfer=NXProfilesManager::isFileTransferAvailablePerUserAndNode ($login,
$name));}(my $ret=NXNodeExec::sendToNode (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_FILE_TRANSFER).
"\x20\x66\x69\x6c\x65\x74\x72\x61\x6e\x73\x66\x65\x72\x20").$fileTransfer),
$socket));if ((($ret==(-(0x1403+ 4791-0x26b9)))or ($ret==(0x0a75+ 206-0x0b43))))
{Logger::warning (((
"\x46\x69\x6c\x65\x20\x74\x72\x61\x6e\x73\x66\x65\x72\x20\x76\x61\x6c\x75\x65\x20"
.$fileTransfer).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
));}else{Logger::debug (((
"\x46\x69\x6c\x65\x20\x74\x72\x61\x6e\x73\x66\x65\x72\x20\x76\x61\x6c\x75\x65\x20"
.$fileTransfer)."\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"));}}sub 
isSessionFile{return ($__isExistSessionFile);}sub setSessionFileCreated{(
$__isExistSessionFile=(0x00b7+ 1222-0x057c));}sub setSessionFileRemoved{(
$__isExistSessionFile=(0x0231+ 4503-0x13c8));}sub isDirectAccessEnabled{if (
isClientNxserver ()){($__directAccessFlag=(0x0147+ 1978-0x0900));return (
(0x17c1+ 1159-0x1c47));}if (($__directAccessFlag!=(-(0x12cb+ 5022-0x2668)))){
return ($__directAccessFlag);}if (NXLicense::isIgnoreRolesConfigKeys ()){(
$__directAccessFlag=(0x0e70+ 639-0x10ee));return ((0x09a7+ 6827-0x2451));}if ((
$GLOBAL::EnableDirectConnections==(0x18ea+ 1271-0x1de0))){($__directAccessFlag=
(0x1ca8+ 887-0x201e));return ((0x0e78+ 5842-0x2549));}($__directAccessFlag=
(0x001b+ 4956-0x1377));return ((0x1221+ 1263-0x1710));}sub 
isDirectAccessDisabled{return ((!isDirectAccessEnabled ()));}sub 
setConnectionForwarded{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x2e"
);($__connectionForwarded=(0x0edb+ 1131-0x1345));}sub isConnectionForwarded{if (
($__connectionForwarded==(0x0453+ 6040-0x1bea))){return ((0x0028+ 1084-0x0463));
}return ((0x0a5a+ 1676-0x10e6));}sub setIfMainServerSupportsHandleFirstAttach{if
 (isClientNxserver ()){if (isClientVersionGreaterOrEqual ((0x186c+ 2136-0x20be),
(0x0908+ 4853-0x1bfd),(0x11c2+ 195-0x1277))){(
$__mainServerSupportsHandleFirstAttach=(0x17a6+ 2391-0x20fc));}}}sub 
isMainServerSupportsHandleFirstAttach{return (
$__mainServerSupportsHandleFirstAttach);}sub saveHelloData{($__helloData=shift (
@_));}sub getHelloData{return ($__helloData);}sub saveShellData{($__shellData=
shift (@_));}sub getShellData{return ($__shellData);}sub getVisibleUUID{my (
$uuid);main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (
NXCluster::hasClusterGUID ()){Logger::debug (
"\x50\x61\x72\x74\x20\x6f\x66\x20\x61\x20\x63\x6c\x75\x73\x74\x65\x72\x2e\x20\x49\x6e\x74\x72\x6f\x64\x75\x63\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x47\x55\x49\x44\x2e"
);($uuid=NXCluster::getClusterGUID ());}else{($uuid=getMyUUID ());}return ($uuid
);}sub getAnywhereName{return ($__anywhereName);}sub 
setIfClientSupportsLBTypeSystemLoad{if ((isClientNxserver ()and 
isClientVersionGreaterOrEqual ((0x17f5+ 226-0x18d1),(0x0080+ 7192-0x1c94),
(0x00b0+ 4404-0x11dd)))){($__clientSupportsLBTypeSystemLoad=(0x000c+ 531-0x021e)
);}else{($__clientSupportsLBTypeSystemLoad=(0x00cd+ 8440-0x21c5));}}sub 
isClientSupportsLBTypeSystemLoad{return ($__clientSupportsLBTypeSystemLoad);}sub
 setAccessOnlyToLocalPhysical{($__accessOnlyToLocalPhysical=(0x0943+ 275-0x0a55)
);}sub isAccessOnlyToLocalPhysical{return ($__accessOnlyToLocalPhysical);}sub 
setAccessOnlyToAttach{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x61\x63\x63\x65\x73\x73\x20\x6f\x6e\x6c\x79\x20\x74\x6f\x20\x61\x74\x74\x61\x63\x68\x2e"
);($__accessOnlyToAttach=(0x1204+ 1424-0x1793));}sub isAccessOnlyToAttach{return
 ($__accessOnlyToAttach);}sub isAnywhereDisabled{if (($GLOBAL::EnableNMN eq 
"\x31")){return ((0x180f+ 1545-0x1e18));}return ((0x0610+ 3111-0x1236));}sub 
isClientSupportsErrorPublicKeyNotRecognized{return (
$__clientSupportsErrorPublicKeyNotRecognized);}sub 
setIfClientSupportsErrorPublicKeyNotRecognized{if (((isClientNxclient ()or 
isClientNxwebclient ())or isClientNxserver ())){if (
isClientVersionGreaterOrEqual ((0x1367+ 2845-0x1e7d),(0x1a19+ 1447-0x1fc0),
(0x0273+ 8505-0x2303))){($__clientSupportsErrorPublicKeyNotRecognized=
(0x0cf1+ 6497-0x2651));}else{($__clientSupportsErrorPublicKeyNotRecognized=
(0x04ad+ 2965-0x1042));}}}sub isClientSupportsPooledServers{return (
$__clientSupportsPooledServers);}sub setIfClientSupportsPooledServers{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x0529+ 5330-0x19f4),(0x098a+ 3661-0x17d7),(0x0708+ 6075-0x1e0b))){(
$__clientSupportsPooledServers=(0x0139+ 8537-0x2291));}else{(
$__clientSupportsPooledServers=(0x11e6+ 3973-0x216b));}}}sub 
setIfClientSupportsLocalSessionTypeAndOwner{if ((isClientNxserver ()and 
isClientVersionGreaterOrEqual ((0x110a+ 4696-0x235b),(0x107d+ 974-0x144b),
(0x06e1+ 5970-0x1d7a)))){($__clientSupportsLocalSessionTypeAndOwner=
(0x0cb0+ 6020-0x2433));}else{($__clientSupportsLocalSessionTypeAndOwner=
(0x08e8+ 2473-0x1291));}}sub isNotClientSupportsLocalSessionTypeAndOwner{return 
((!$__clientSupportsLocalSessionTypeAndOwner));}sub 
isClientSupportsCorrectlyFormattedUnicodeInListCommands{if (isConnectedToConsole
 ()){return ((0x00d2+ 1217-0x0592));}else{return ((0x12e0+ 1165-0x176d));}}sub 
setIfClientSupportsUdpInConnectionPolicy{if (isClientVersionGreaterOrEqual (
(0x1aec+ 1680-0x2175),(0x1178+ 1041-0x1589),(0x1973+ 161-0x1950))){(
$__clientSupportsUdpInConnectionPolicy=(0x0093+ 5891-0x1795));}else{(
$__clientSupportsUdpInConnectionPolicy=(0x0e46+ 1051-0x1261));}}sub 
isClientSupportsUdpInConnectionPolicy{if ((
$__clientSupportsUdpInConnectionPolicy==(0x084c+ 2892-0x1397))){return (
(0x12aa+ 2438-0x1c2f));}return ((0x1a18+ 2318-0x2326));}sub setImRemoteServer{(
$__remoteServer=(0x06dc+ 2049-0x0edc));}sub isRemoteServerSet{if ((
$__remoteServer==(0x0a4d+ 720-0x0d1c))){return ((0x037b+ 2264-0x0c52));}return (
(0x1107+ 158-0x11a5));}sub setClientSupportsUuidChangeMessage{if (
isClientVersionGreaterOrEqual ((0x0db0+ 925-0x1145),(0x0abc+ 2413-0x1429),
(0x1054+ 5392-0x2506))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x75\x75\x69\x64\x20\x63\x68\x61\x6e\x67\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);($__clientSupportsUuidChangeMessage=(0x0412+ 6294-0x1ca7));return;}
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x75\x75\x69\x64\x20\x63\x68\x61\x6e\x67\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);}sub isClientSupportsUuidChangeMessage{return (
$__clientSupportsUuidChangeMessage);}sub setClientSupportsAttachRequestMessage{
if (isClientVersionGreaterOrEqual ((0x0dc0+ 1669-0x143d),(0x097f+ 5990-0x20e5),
(0x0357+ 8033-0x225c))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x61\x74\x74\x61\x63\x68\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);($__clientSupportsAttachRequestMessage=(0x0d27+ 4577-0x1f07));return;}
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x61\x74\x74\x61\x63\x68\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);($__clientSupportsAttachRequestMessage=(0x0a18+ 1744-0x10e8));}sub 
isClientSupportsAttachRequestMessage{return (
$__clientSupportsAttachRequestMessage);}sub setServerReverselogin{(
$__serverReverselogin=(0x0501+ 7056-0x2090));}sub isReverselogin{if ((
$__serverReverselogin==(0x0bf8+ 1405-0x1174))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x76\x65\x72\x73\x65\x20\x6c\x6f\x67\x69\x6e\x2e"
);return ((0x0c5d+ 1993-0x1425));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4e\x6f\x74\x20\x72\x65\x76\x65\x72\x73\x65\x20\x6c\x6f\x67\x69\x6e\x2e"
);return ((0x02c3+ 6801-0x1d54));}sub setReverseHost{($__serverReverseHost=shift
 (@_));}sub getReverseHost{return ($__serverReverseHost);}sub 
setClientSupportsUpdateInNodeEdit{if (isClientVersionGreaterOrEqual (
(0x007f+ 3330-0x0d79),(0x113a+ 281-0x1253),(0x06d6+ 6738-0x20cb))){(
$__clientSupportsUpdateInNodeEdit=(0x1729+ 1362-0x1c7a));}else{(
$__clientSupportsUpdateInNodeEdit=(0x0bcd+ 5825-0x228e));}}sub 
isClientSupportsUpdateInNodeEdit{return ($__clientSupportsUpdateInNodeEdit);}sub
 setClientSupportsClientConnection{($__clientSupportsClientConnection=
(0x097c+ 4246-0x1a12));if ((((isClientVersionGreaterOrEqual (
(0x1020+ 2886-0x1b5e),(0x1800+ 1094-0x1c46),(0x0291+ 5129-0x162c))and (not (
isClientNxwebclient ())))or (isClientVersionGreaterOrEqual (
(0x10fc+ 1522-0x16e6),(0x1a99+ 739-0x1d7c),(0x1ce6+ 479-0x1e3e))and 
isClientNxwebclient ()))or ($GLOBAL::ClientSupportsClientConnection==
(0x0a94+ 701-0x0d50)))){($__clientSupportsClientConnection=(0x06c5+ 3390-0x1402)
);}}sub doesClientSupportClientConnection{return (
$__clientSupportsClientConnection);}sub updateMyCurrentUUID{(my $uuid=shift (@_)
);main::redefine ("\x55\x55\x49\x44",$uuid);($__myUuid=$uuid);}sub 
isServerStopped{if (Common::NXFile::isExists ($GLOBAL::ServerStopStatusFlagLink)
){return ((0x0801+ 7396-0x24e4));}return ((0x0369+ 3922-0x12bb));}sub 
isClientSupportsCommandsAfterStop{return ($__clientSupportsCommandsAfterStop);}
sub setClientSupportsCommandsAfterStop{($__clientSupportsCommandsAfterStop=
(0x0ee3+ 2424-0x185b));if (isClientNxserver ()){(
$__clientSupportsCommandsAfterStop=(0x0c2f+ 1869-0x137b));}}sub 
setClientSupportsParentCloudLimits{($__clientSupportsParentCloudLimits=
(0x0c23+ 4782-0x1ed1));if ((isClientNxserver ()and isClientVersionGreaterOrEqual
 ((0x041f+ 1728-0x0ad7),(0x09bd+ 7202-0x25df),(0x12b0+ 799-0x155a)))){(
$__clientSupportsParentCloudLimits=(0x002d+ 986-0x0406));}}sub 
isClientSupportsParentCloudLimit{return ($__clientSupportsParentCloudLimits);}
sub setClientSupportsDynamicParentConnections{(
$__clientSupportsDynamicParentConnections=(0x0210+ 3185-0x0e81));if ((
isClientNxserver ()and isClientVersionGreaterOrEqual ((0x06da+ 966-0x0a98),
(0x0857+ 1213-0x0d14),(0x0a0d+ 4538-0x1b21)))){(
$__clientSupportsDynamicParentConnections=(0x1404+ 3244-0x20af));}}sub 
isClientSupportsDynamicParentConnections{return (
$__clientSupportsDynamicParentConnections);}sub 
setClientSupportsSeparateConnections{if (isClientVersionGreaterOrEqual (
(0x01ac+ 498-0x0396),(0x0412+ 6409-0x1d1b),(0x03d6+ 564-0x058b))){(
$__clientSupportsSeparateConnections=(0x02e7+ 4148-0x131a));}else{(
$__clientSupportsSeparateConnections=(0x0343+ 2536-0x0d2b));}}sub 
isClientSupportsSeparateConnections{return ($__clientSupportsSeparateConnections
);}sub setClientSupportsIgnoringWarnings{($__clientSupportsIgnoringWarnings=
(0x0875+ 858-0x0bcf));if ((isClientNxclient ()and isClientVersionGreaterOrEqual 
((0x0239+ 5250-0x16b3),(0x0be1+ 4497-0x1d72),(0x0998+ 1324-0x0e4e)))){(
$__clientSupportsIgnoringWarnings=(0x1296+ 3376-0x1fc5));}}sub 
doesClientSupportIgnoringWarnings{return ($__clientSupportsIgnoringWarnings);}
sub isPublicKeyMessageVersion{return ($__publicKeyMessageVersion);}sub 
setPublicKeyMessageVersion{if (isClientVersionLesserOrEqual (
(0x1cfc+ 765-0x1ff2))){($__publicKeyMessageVersion=(0x030b+ 3798-0x11e1));}}sub 
setIfClientSupportNewLabels{if (isClientVersionLesserOrEqual (
(0x1995+ 2924-0x24f9),(0x12a6+ 333-0x13f3),(0x064c+ 1282-0x0acf))){(
$__clientSupportNewLabels=(0x13b2+ 2586-0x1dcc));}}sub 
doesClientSupportNewLabels{return ($__clientSupportNewLabels);}sub 
setIfClientSupportServerlistWithNames{if (isClientVersionLesserOrEqual (
(0x1649+ 430-0x17ef),(0x13e4+ 2771-0x1eb7),(0x01b3+ 5571-0x16ef))){(
$__clientSupportServerlistWithNames=(0x1138+ 2246-0x19fe));}else{(
$__clientSupportServerlistWithNames=(0x0322+ 3287-0x0ff8));}}sub 
doesClientSupportServerlistWithNames{return ($__clientSupportServerlistWithNames
);}sub setIfClientSupportsCode555{if (isClientVersionGreaterOrEqual (
(0x05a0+ 1846-0x0cce),(0x01d2+ 5679-0x17ff),(0x05f1+ 7703-0x2408))){(
$__clientSupportsCode555=(0x0a67+ 6195-0x2299));}else{($__clientSupportsCode555=
(0x1d03+ 457-0x1ecc));}}sub doesClientSupportCode555{return (
$__clientSupportsCode555);}sub updateMyCfg{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6e\x66\x69\x67\x20\x75\x70\x64\x61\x74\x65\x2e"
);($GLOBAL::REFRESH_CFG=(0x0486+ 7967-0x23a4));
NXLicense::clearLicenseDependantConfigKeys ();main::loadDefaultConfigValues ();
main::init_by_config_file ($GLOBAL::CONFIG_FILE);
NXLicense::updateLicenseDependantConfigKeys ();NXLicense::checkLegacyPortKeys ()
;(my $keyToCheckInNodeConfigFile=
"\x43\x6f\x6d\x6d\x61\x6e\x64\x58\x64\x70\x79\x69\x6e\x66\x6f\x7c\x43\x6f\x6d\x6d\x61\x6e\x64\x58\x61\x75\x74\x68\x7c\x41\x67\x65\x6e\x74\x58\x31\x31\x56\x65\x63\x74\x6f\x72\x47\x72\x61\x70\x68\x69\x63\x73\x7c\x41\x67\x65\x6e\x74\x4c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x4d\x6f\x64\x65\x7c"
);($keyToCheckInNodeConfigFile.=
"\x44\x69\x73\x70\x6c\x61\x79\x44\x65\x66\x61\x75\x6c\x74\x7c\x44\x69\x73\x70\x6c\x61\x79\x53\x65\x72\x76\x65\x72\x50\x72\x69\x6f\x72\x69\x74\x79\x7c\x44\x69\x73\x70\x6c\x61\x79\x41\x67\x65\x6e\x74\x50\x72\x69\x6f\x72\x69\x74\x79\x7c\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x69\x6d\x65\x6f\x75\x74\x7c"
);($keyToCheckInNodeConfigFile.=
"\x41\x75\x64\x69\x6f\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x7c\x45\x6e\x61\x62\x6c\x65\x41\x75\x64\x69\x6f\x7c\x45\x6e\x61\x62\x6c\x65\x4d\x6f\x75\x6e\x74\x53\x68\x61\x72\x65\x53\x4d\x42\x46\x53\x7c\x45\x6e\x61\x62\x6c\x65\x4d\x6f\x75\x6e\x74\x53\x68\x61\x72\x65\x53\x53\x48\x46\x53\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x43\x55\x50\x53\x53\x75\x70\x70\x6f\x72\x74\x7c\x45\x6e\x61\x62\x6c\x65\x53\x6d\x61\x72\x74\x63\x61\x72\x64\x53\x68\x61\x72\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x50\x72\x69\x6e\x74\x65\x72\x53\x68\x61\x72\x69\x6e\x67\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x44\x69\x73\x6b\x53\x68\x61\x72\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x55\x53\x42\x53\x68\x61\x72\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x4e\x65\x74\x77\x6f\x72\x6b\x53\x68\x61\x72\x69\x6e\x67\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x46\x69\x6c\x65\x54\x72\x61\x6e\x73\x66\x65\x72\x7c\x45\x6e\x61\x62\x6c\x65\x4c\x6f\x63\x61\x6c\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x53\x65\x73\x73\x69\x6f\x6e\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x7c"
);($keyToCheckInNodeConfigFile.=
"\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x69\x73\x70\x6c\x61\x79\x73\x7c\x4e\x58\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x7c\x55\x73\x65\x72\x4e\x58\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x50\x61\x74\x68\x7c\x43\x6f\x6d\x6d\x6f\x6e\x4c\x6f\x67\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x7c"
);($keyToCheckInNodeConfigFile.=
"\x47\x50\x55\x4c\x6f\x61\x64\x42\x61\x6c\x61\x6e\x63\x69\x6e\x67\x41\x6c\x67\x6f\x72\x69\x74\x68\x6d\x7c\x47\x50\x55\x44\x65\x64\x69\x63\x61\x74\x65\x64\x44\x65\x76\x69\x63\x65\x7c\x55\x73\x65\x72\x73\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x50\x61\x74\x68\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x53\x63\x72\x65\x65\x6e\x42\x6c\x61\x6e\x6b\x69\x6e\x67\x7c\x45\x6e\x61\x62\x6c\x65\x53\x63\x72\x65\x65\x6e\x42\x6c\x61\x6e\x6b\x69\x6e\x67\x45\x66\x66\x65\x63\x74\x7c\x44\x69\x73\x70\x6c\x61\x79\x4d\x6f\x6e\x69\x74\x6f\x72\x49\x63\x6f\x6e\x7c"
);($keyToCheckInNodeConfigFile.=
"\x45\x6e\x61\x62\x6c\x65\x53\x6f\x75\x6e\x64\x41\x6c\x65\x72\x74\x7c\x53\x68\x6f\x77\x44\x65\x73\x6b\x74\x6f\x70\x56\x69\x65\x77\x65\x64"
);($GLOBAL::REFRESH_CFG=(0x06b9+ 8135-0x2680));main::parse_config_file (
$GLOBAL::NODE_CONFIG_FILE,$keyToCheckInNodeConfigFile);Logger::updateLogLevel (
$GLOBAL::SessionLogLevel);main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");
NXLocalSession::checkScreenBlankingOnConfigUpdate ();
NXLocalSession::checkScreenBlankingEffectOnConfigUpdate ();
NXLocalSession::informAboutDisplayMonitorIconStatus ();
NXLocalSession::informAboutSoundAlertStatus ();
NXLocalSession::informAboutDesktopViewedStatus ();main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");
NXConnectionMonitor::handleRefreshCfg ();main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::handleRefreshCfg ();return;}sub 
__setKeyInNodeConfigFile{(my $key=shift (@_));(my $ref_options=shift (@_));(my $value
=$$ref_options{$key});Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6b\x65\x79\x20\x27"
.$key)."\x27\x20\x74\x6f\x20\x76\x61\x6c\x75\x65\x20\x27").$value).
"\x27\x20\x69\x6e\x20\x6e\x6f\x64\x65\x2e\x63\x66\x67\x2e"));&try (sub{
Common::NXCommonNodeConfiguration::setKey ("\x6b\x65\x79",$key,
"\x76\x61\x6c\x75\x65",$value);},
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x6f\x72"
->catch (&with (sub{($e=shift (@_));$e->notify;},
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
catch (&with (sub{($e=shift (@_));$e->notify;})))));}sub 
setSkipClosingPassedSocket{($__skipClosingPassedSocket=(0x0ab8+ 3657-0x1900));}
sub shouldSkipClosingPassedSocket{return ($__skipClosingPassedSocket);}sub 
getTcpDescriptor{(my $message=(("\x4e\x58\x3e\x20".$GLOBAL::TCP_COMMUNICATION).
"\x20\x54\x43\x50\x20\x63\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x0a"
));Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x71\x75\x65\x73\x74\x69\x6e\x67\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x27"
.$message)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$__communicationNXD)."\x2e"));if 
((main::nxwrite ($__communicationNXD,$message)==(-(0x10e1+ 2858-0x1c0a)))){
Logger::error (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x4e\x58\x44\x20\x6f\x6e\x20\x46\x44\x23"
.$__communicationNXD)."\x2e"));shutdownClientConnection ();main::nxexit ();}(my $answer
=getAnswer ($__communicationNXD,$GLOBAL::TcpDescriptorReadTimeout));if (($answer
=~ /^NX> $GLOBAL::TCP_HANDLE TCP handle pid=(.*) socket=(.*) cookie=(.*) fd=(.*) / )
){(my $pid=$1);(my $fd=$4);(my $path=main::urldecode ($2));(my $cookie=$3);(my $descriptor
=Common::NXDescriptor::acquire ($pid,$fd,$path,$cookie));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$descriptor)."\x2e"));if (($descriptor<(0x0a30+ 6383-0x231f))){Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x63\x71\x75\x69\x72\x65\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);shutdownClientConnection ();main::nxexit ();}main::closeSocketAtFinish (
$descriptor);return ($descriptor);}Logger::error (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x57\x72\x6f\x6e\x67\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$answer)."\x27\x2e"));shutdownClientConnection ();main::nxexit ();}sub 
setNxdCommunication{($__communicationNXD=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x4e\x58\x44\x20\x63\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x70\x69\x70\x65\x20\x46\x44\x23"
.$__communicationNXD).
"\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x20\x61\x74\x20\x65\x78\x69\x74\x2e"));
main::closeSocketAtFinish ($__communicationNXD);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.$__communicationNXD)."\x2c\x20\x30\x29"));libnxh::NXDescriptorInheritable (
$__communicationNXD,(0x0ad7+ 1990-0x129d));}sub getNxdConnection{return (
$__communicationNXD);}sub getAnswer{(my $handle=shift (@_));(my $timeout=shift (
@_));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($handle);(my $finish=(0x0cb2+ 4094-0x1cb0));(my $time
=$timeout);(my $answer=(""));while ((($finish==(0x0523+ 417-0x06c4))and ($time>
(0x0636+ 4757-0x18cb)))){(my $startTime=Common::NXTime::getSecondsSinceEpoch ())
;(my (@ready)=$selector->can_read (($time *(0x0d33+ 4860-0x1c47))));(my $currentTime
=Common::NXTime::getSecondsSinceEpoch ());($time=($time-($currentTime-$startTime
)));if ((scalar (@ready)==(0x1c21+ 1241-0x20fa))){Logger::warning (((((
"\x52\x65\x61\x64\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20".$timeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x72\x65\x61\x63\x68\x65\x64\x20\x66\x6f\x72\x20\x46\x44\x23"
).$handle)."\x2e"));($finish=(0x0807+  13-0x0813));}foreach my $fh (@ready){if (
($fh==$handle)){my ($buffer);(my $bytes=main::nxread ($fh,(\$buffer),4096));(
$answer.=$buffer);if (((not (defined ($bytes)))or ($bytes==(0x1fa8+ 1027-0x23ab)
))){Logger::debug (((
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$fh)."\x2e"));$selector->remove ($fh);$selector->remove ($signalFd);($finish=
(0x1a2d+ 570-0x1c66));}else{Logger::debug ((((("\x52\x65\x61\x64\x20".$bytes).
"\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x46\x44").$fh)."\x2e"));if ((
$buffer=~ /\n/ )){$selector->remove ($fh);$selector->remove ($signalFd);chomp (
$buffer);($buffer=~ s/\r//g );($finish=(0x016a+ 4679-0x13b0));}}}}}return (
$answer);}sub passUdpDescriptorToNode{my ($in);my ($out);main::nxPipeCreateBi ((
\$in),(\$out));(my $cookie=main::get_unique_id ());(my $path=((
NXPaths::getTmpDir ().$GLOBAL::DIRECTORY_SLASH).main::get_unique_id ()));(my $params
=("\x75\x64\x70\x50\x69\x64\x3d".$ $));
 ($params.=(
"\x26\x75\x64\x70\x50\x61\x74\x68\x3d".main::urlencode ($path)));($params.=(
"\x26\x75\x64\x70\x43\x6f\x6f\x6b\x69\x65\x3d".$cookie));($params.=(
"\x26\x75\x64\x70\x46\x64\x3d".$out));(my ($stdout,$childPid)=
NXNodeExec::askNode ("\x70\x61\x73\x73\x55\x64\x70\x48\x61\x6e\x64\x6c\x65",
$params,NXSessionParameters::getNodeUUID (),NXSessionParameters::getUsername ())
);Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x53\x74\x61\x72\x74\x53\x74\x61\x74\x65\x4d\x61\x63\x68\x69\x6e\x65\x3a\x20\x50\x61\x73\x73\x20\x55\x44\x50\x20\x68\x61\x6e\x64\x6c\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$stdout)."\x27\x2e"));if (($stdout=~ /ready/ )){if ((
Common::NXDescriptor::yield ($out,$path,$cookie)==(-(0x090a+ 3986-0x189b)))){
Logger::warning (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x70\x61\x73\x73\x20\x55\x44\x50\x20\x68\x61\x6e\x64\x6c\x65\x20\x46\x44\x23"
.$out).
"\x20\x77\x69\x74\x68\x20\x73\x6f\x63\x6b\x65\x74\x20\x70\x61\x74\x68\x20\x27").
$path)."\x27\x2e"));}}}sub setClientSupportsForwardUdp{(
$__clientSupportsUdpServer=(0x230b+  77-0x2358));if (isClientNxwebclient ()){
return;}if (isClientVersionGreaterOrEqual ((0x04fb+ 1524-0x0ae7),
(0x0b47+ 6056-0x22ef),(0x1918+ 690-0x1b3d))){($__clientSupportsUdpServer=
(0x1a25+ 899-0x1da7));}}sub doesClientSupportUdpServer{if ((
$__clientSupportsUdpServer==(0x1172+ 2622-0x1baf))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x55\x44\x50\x2e"
);return ((0x0b53+ 2041-0x134b));}Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x55\x44\x50\x2e"
);return ((0x0f2d+ 2478-0x18db));}sub disableUdpForwarder{Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x44\x69\x73\x61\x62\x6c\x69\x6e\x67\x20\x55\x44\x50\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x2e"
);($__disableUdpForwarder=(0x0963+ 2203-0x11fd));}sub isUdpForwarderEnabled{if (
($__disableUdpForwarder==(0x14b5+ 4527-0x2663))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x55\x44\x50\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0225+ 8977-0x2536));}Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x55\x44\x50\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x20\x69\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);return ((0x0a8b+ 1928-0x1212));}sub setUdpStatus{($__udpStatus=shift (@_));
Logger::debug (((
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6e\x78\x61\x67\x65\x6e\x74\x20\x55\x44\x50\x20\x73\x74\x61\x74\x75\x73\x20\x27"
.$__udpStatus)."\x27\x2e"));}sub isUdpDisabled{if (($__udpStatus==
(0x1140+ 1011-0x1533))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x6e\x78\x61\x67\x65\x6e\x74\x20\x55\x44\x50\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0aa2+ 2216-0x1349));}return ((0x0e17+  97-0x0e78));}sub 
setClientSupportsDirectUdp{($__clientSupportsDirectUdp=(0x06dc+ 1998-0x0eaa));if
 (isClientNxwebclient ()){return;}if (isClientVersionGreaterOrEqual (
(0x030c+ 6455-0x1c3b))){return;}($__clientSupportsDirectUdp=(0x121b+ 621-0x1487)
);}sub doesClientSupportDirectUdp{if (($__clientSupportsDirectUdp==
(0x0186+ 2046-0x0983))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x64\x69\x72\x65\x63\x74\x20\x55\x44\x50\x2e"
);return ((0x0e48+ 148-0x0edb));}Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x64\x69\x72\x65\x63\x74\x20\x55\x44\x50\x2e"
);return ((0x2030+ 1018-0x242a));}sub setClientSupportsQuasiAdmin{(
$__clientSupportsQuasiAdmin=(0x017d+ 740-0x0461));if ((isClientNxclient ()or 
isClientNxwebclient ())){if (isClientVersionGreaterOrEqual (
(0x06ed+ 4758-0x197b))){($__clientSupportsQuasiAdmin=(0x0522+ 6046-0x1cbf));}}}
sub doesClientSupportQuasiAdmin{if (($__clientSupportsQuasiAdmin==
(0x0088+ 7440-0x1d97))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x71\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x2e"
);return ((0x1cff+ 543-0x1f1d));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x71\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x2e"
);return ((0x0510+ 4500-0x16a4));}sub setClientSupportsForwardWithTimeout{(
$__clientSupportsForwardWithTimeout=(0x0021+ 5681-0x1652));if (
isClientVersionGreaterOrEqual ((0x1745+ 922-0x1ad7),(0x12f0+ 3144-0x1f38),
(0x1551+ 2577-0x1ecb))){($__clientSupportsForwardWithTimeout=
(0x1922+ 2482-0x22d3));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x02d6+ 1249-0x07b7));}sub doesClientSupportsForwardWithTimeut{if ((
$__clientSupportsForwardWithTimeout==(0x059c+ 8407-0x2672))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x1282+ 1232-0x1751));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x14c6+  75-0x1511));}sub getMyLocalIP{(my $gatewayIP=("\x20" x 
(0x1644+ 1860-0x19a0)));(my $localIP=("\x20" x (0x15b3+ 373-0x1340)));(my $externalIP
=("\x20" x (0x13d2+ 2904-0x1b42)));libnxhs::NXUpnpGetNetworkInfo ($gatewayIP,
$localIP,$externalIP);($localIP=~ s/\0// );($localIP=main::trimLine ($localIP));
return ($localIP);}sub setClientSupportHelloForVisitor{(
$__clientSupportHelloForVisitor=(0x166c+ 4125-0x2689));if (
isClientVersionGreaterOrEqual ((0x0967+ 7511-0x26b6),(0x0ec5+ 2783-0x19a4),
(0x0879+ 3503-0x158b))){($__clientSupportHelloForVisitor=(0x14bc+ 2302-0x1db9));
}}sub doesClientSupportHelloForVisitor{if (($__clientSupportHelloForVisitor==
(0x0185+ 303-0x02b3))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x68\x65\x6c\x6c\x6f\x20\x66\x6f\x72\x20\x76\x69\x73\x69\x74\x6f\x72\x2e"
);return ((0x0664+ 4164-0x16a7));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x68\x65\x6c\x6c\x6f\x20\x66\x6f\x72\x20\x76\x69\x73\x69\x74\x6f\x72\x2e"
);return ((0x00da+ 7781-0x1f3f));}sub setClientSupportParentName{(
$__clientSupportParentName=(0x16d9+ 2573-0x20e6));if (
isClientVersionGreaterOrEqual ((0x0a57+ 5691-0x208a),(0x0760+ 7910-0x2646),
(0x1e16+ 1978-0x2531))){($__clientSupportParentName=(0x0fb5+ 1999-0x1783));}}sub
 doesClientSupportParentName{if (($__clientSupportParentName==
(0x1fe2+ 282-0x20fb))){return ((0x2357+  79-0x23a5));}return (
(0x1799+ 2526-0x2177));}sub setClientSupportCsNodePool{(
$__clientSupportCsNodePool=(0x171b+ 3259-0x23d6));if (
isClientVersionGreaterOrEqual ((0x1233+ 1001-0x1614),(0x02e6+ 3038-0x0ec4),
(0x0ecc+ 4637-0x2042))){($__clientSupportCsNodePool=(0x16c1+ 3958-0x2636));}}sub
 doesClientSupportCsNodePool{if (($__clientSupportCsNodePool==
(0x0415+ 1106-0x0866))){return ((0x1030+ 5028-0x23d3));}return (
(0x0067+ 4712-0x12cf));}sub isClusterNotSetUp{if (
NXLicense::isClusterCreateFeature ()){main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((not (NXCluster::isClusterConfigured
 ()))){return ((0x0eb0+ 1398-0x1425));}return ((0x0832+ 1215-0x0cf1));}return (
(0x1bac+ 2887-0x26f3));}sub isCluster{if (NXLicense::isClusterFeature ()){if (
NXLicense::isClusterCreateFeature ()){return ((0x0c57+ 2314-0x1560));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (
NXCluster::isClusterConfigured ()){return ((0x01dc+ 5164-0x1607));}}return (
(0x178c+ 3063-0x2383));}sub setPureVirtualSession{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x70\x75\x72\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);($__pureVirtualSession=(0x0504+ 4653-0x1730));}sub isPureVirtualSession{if ((
$__pureVirtualSession==(0x0d24+ 4396-0x1e4f))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x75\x72\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x0a76+ 5878-0x216b));}return ((0x1c4a+ 1915-0x23c5));}
NXMsg::register_response ("\x53\x65\x72\x76\x65\x72",
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x65\x74\x4c\x6f\x67\x6f\x6e\x54\x6f\x53\x74\x61\x72\x74"
,(0x1389+ 5123-0x2598));NXMsg::register_response ("\x53\x65\x72\x76\x65\x72",
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x53\x65\x72\x76\x69\x63\x65\x73"
,(0x0f40+ 835-0x108f));return ((0x0bb4+ 6639-0x25a2));
