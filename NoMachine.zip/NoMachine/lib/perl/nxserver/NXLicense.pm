############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXLicense::BEGIN{package NXLicense;no warnings;require NXProfilesManager;do{
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72"->import};
}sub NXLicense::BEGIN{package NXLicense;no warnings;require Time::Local;do{
"\x54\x69\x6d\x65\x3a\x3a\x4c\x6f\x63\x61\x6c"->import};}package NXLicense;no 
warnings;require NXShell;($virtualSessionsFeature=(0x1028+ 2175-0x18a7));(
$x11SessionsFeature=(0x01c0+ 4042-0x118a));($rdpFeature=(0x08e1+ 6870-0x23b7));(
$guestsFeature=(0x0879+ 2975-0x1418));($profilesFeature=(0x1822+ 3697-0x2693));(
$multinodeFeature=(0x0d1f+ 5901-0x242c));($terminalNodeSelectFeature=
(0x1a33+ 572-0x1c6f));($redirectFeature=(0x03e2+ 5365-0x18d7));(
$httpdSupportFeature=(0x0ae4+ 6530-0x2466));($sshFeature=(0x0897+ 4896-0x1bb7));
($groupsFeature=(0x1362+ 2363-0x1c9d));($clusterFeature=(0x0d22+ 5282-0x21c4));(
$clusterCreateFeature=(0x018c+ 6090-0x1956));($directConnections=
(0x0330+ 7662-0x211d));($serverAvailableAsRemoteNode=(0x03ff+ 1818-0x0b19));(
$serverAvailableAsRemoteServer=(0x0acc+ 970-0x0e96));($nxFrameBufferFeature=
(0x01f0+ 2506-0x0bba));($notSystemUserFeature=(0x0658+ 2264-0x0f30));(
$nodeSynchronization=(0x0a80+ 3027-0x1653));($multiserverFeature=
(0x116d+ 1444-0x1711));($automaticRecordingFeature=(0x06eb+ 5353-0x1bd4));(
$killingLeftoverCMonStarup=(0x0e8d+ 2833-0x199e));($subCloudServersFeature=
(0x01f2+ 4478-0x1370));($foreignServersFeature=(0x213c+  56-0x2174));(
$reverseClientFeature=(0x0a42+ 5078-0x1e18));($visitorAccessFeature=
(0x13ad+ 3653-0x21f2));($guestAccessFeature=(0x12b4+ 1539-0x18b7));(
$virtualGuestDesktopSharingFeature=(0x105b+ 973-0x1428));(
$physicalGuestDesktopSharingFeature=(0x07d0+ 5617-0x1dc1));($defaultUpdateMode=
(0x1346+ 3927-0x229c));($customFreeSubscriptionMessage=(0x03d9+ 658-0x066b));(
$LicenseVirtualDesktopsLimit=(-(0x07b8+ 4782-0x1a65)));($ignoreRolesConfigKeys=
(0x0e29+ 942-0x11d7));($isLicenseExpired=(0x0b95+ 3569-0x1986));($expiryDate=
(""));($expiryTimestamp=(""));($expiryReadableDate=(""));($productIdInLicense=
(""));($platformInLicense=(""));($SubscriptionVersion=(-(0x09ac+ 4768-0x1c4b)));
($usingNodeLicenseFile=(0x0f35+ 1601-0x1576));($licenseProcessorsCount=
(0x1e86+ 1351-0x23cd));($__checkProcessorsCountDelay=(0x191d+ 3204-0x2475));(
$__lastCheckProcessorsCount=(0x03e7+ 5459-0x193a));($__warningBeforeExpiryPeriod
=5184000);($isNoLicenseFile=(0x00c1+ 4403-0x11f4));(
$isNotSuitableLicenseForPackage=(0x232a+ 904-0x26b2));(
$isWrongPlatformLicenseForPackage=(0x1da6+ 721-0x2077));(
$GLOBAL::licenseConnectionsLimit=(0x0f98+ 3740-0x1e34));(my $__evaluationPeriodExpired
=(0x0697+ 6614-0x206d));(my $__evaluation=(0x0351+ 4790-0x1607));(my $__acronymId
=(-(0x222d+ 292-0x2350)));sub enableCustomFreeSubscriptionMessage{(
$customFreeSubscriptionMessage=(0x1fad+ 1558-0x25c2));}sub getProductIdInLicense
{return ($productIdInLicense);}sub getPlatformInLicense{return (
$platformInLicense);}sub isCustomFreeSubscriptionMessage{return (
$customFreeSubscriptionMessage);}sub initializeFilePaths{($codecLicFile=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x64\x65\x63\x2e\x6c\x69\x63"));(
$cloudLicFile=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x6f\x75\x64\x2e\x6c\x69\x63"));(
$serverLicFile=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72\x2e\x6c\x69\x63"));(
$nodeLicFile=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x6f\x64\x65\x2e\x6c\x69\x63"));($clusterLicFile=
(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x75\x73\x74\x65\x72\x2e\x6c\x69\x63"));}sub 
saveExpiryDate{(my $expiry=(shift (@_)||("")));($expiryDate=$expiry);}sub 
saveExpiryTimestamp{(my $expiry=shift (@_));($expiryTimestamp=$expiry);}sub 
getExpiryTimestamp{return ($expiryTimestamp);}sub getExpiryReadableDate{return (
$expiryReadableDate);}sub handleSubscriptionExpiryByDaemon{if (((not (
Server::isDaemonProcess ()))or isEvaluation ())){return;}(my $msg=
Common::NXMsg::getEnglishTextOneLine (
"\x65\x43\x4d\x44\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x56\x65\x72\x73\x69\x6f\x6e\x37\x45\x78\x70\x69\x72\x79"
));Logger::error ($msg);}sub checkIfLicenseExpired{if (($expiryDate eq (""))){
Logger::error (
"\x55\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x70\x45\x78\x70\x69\x72\x79\x27"
,(0x0630+ 6353-0x1f01));NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);($isLicenseExpired=(0x021d+ 7829-0x20b1));NXShell::handle_command (
"\x65\x78\x69\x74");return ((0x0c97+ 1131-0x1101));}elsif (($expiryDate eq 
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64")){($isLicenseExpired=(0x1ab2+  58-0x1aec)
);return ((0x0be0+ 1323-0x110b));}else{(my (@ltime)=Common::NXTime::getLocalTime
 ());(my $now=($ltime[(0x0b38+ 3822-0x1a21)]+1900));($now=($now.sprintf (
"\x25\x30\x32\x64",($ltime[(0x0631+ 5113-0x1a26)]+(0x1711+ 1163-0x1b9b)))));(
$now=($now.sprintf ("\x25\x30\x32\x64",$ltime[(0x0413+ 258-0x0512)])));($now=(
$now.sprintf ("\x25\x30\x32\x64",$ltime[(0x0a20+ 1548-0x102a)])));($now=($now.
sprintf ("\x25\x30\x32\x64",$ltime[(0x12e3+ 2962-0x1e74)])));($now=($now.sprintf
 ("\x25\x30\x32\x64",$ltime[(0x16fc+ 1454-0x1caa)])));if (($now ge $expiryDate))
{($isLicenseExpired=(0x18dc+ 2318-0x21e9));handleSubscriptionExpiryByDaemon ();
return ((0x1150+ 4715-0x23ba));}($isLicenseExpired=(0x171a+ 801-0x1a3b));
NXEvent::subscribe (NXEvent::getLicenseExpiredEventName (),
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x4c\x69\x63\x65\x6e\x73\x65\x43\x68\x61\x6e\x67\x65\x64"
);return ((0x0eba+ 4247-0x1f51));}}sub isLicenseExpired{return (
$isLicenseExpired);}sub isNoLicenseFile{return ($isNoLicenseFile);}sub 
isNotSuitableLicenseForPackage{return ($isNotSuitableLicenseForPackage);}sub 
isWrongPlatformLicenseForPackage{return ($isWrongPlatformLicenseForPackage);}sub
 setNotSuitableLicenseForPackage{($isNotSuitableLicenseForPackage=
(0x10d7+ 1592-0x170e));}sub setWrongPlatformLicenseForPackage{(
$isWrongPlatformLicenseForPackage=(0x07cb+ 7277-0x2437));}sub 
enableDirectConnections{($directConnections=(0x0519+ 5738-0x1b82));}sub 
disableDirectConnections{($directConnections=(0x1901+ 2619-0x233c));}sub 
enableServerAvailableAsRemoteNode{($serverAvailableAsRemoteNode=
(0x19ec+ 210-0x1abd));}sub enableServerAvailableAsRemoteServer{(
$serverAvailableAsRemoteServer=(0x1105+ 5419-0x262f));}sub enableRdpFeature{(
$rdpFeature=(0x0e61+ 3840-0x1d60));}sub enableVirtualSessionsFeature{(
$virtualSessionsFeature=(0x00aa+ 7649-0x1e8a));}sub enableX11SessionsFeature{(
$x11SessionsFeature=(0x02c3+ 770-0x05c4));}sub enableGuestsFeature{(
$guestsFeature=(0x078d+ 4699-0x19e7));}sub enableProfilesFeature{(
$profilesFeature=(0x1654+ 507-0x184e));}sub enableMultiNodeFeature{(
$multinodeFeature=(0x15da+ 3855-0x24e8));}sub enableTerminalServerNodeSelect{(
$terminalNodeSelectFeature=(0x0c35+ 5065-0x1ffd));}sub enableMultiserverFeature{
($multiserverFeature=(0x1e14+ 476-0x1fef));}sub enableKillingLeftoverCMonStarup{
($killingLeftoverCMonStarup=(0x0851+ 3045-0x1435));}sub enableGroupsFeature{(
$groupsFeature=(0x0cdd+ 4473-0x1e55));}sub enableRedirectFeature{(
$redirectFeature=(0x05c2+ 3297-0x12a2));}sub enableHttpdSupportFeature{(
$httpdSupportFeature=(0x0476+ 5886-0x1b73));}sub enableClusterFeature{(
$clusterFeature=(0x1feb+ 713-0x22b3));}sub enableClusterCreateFeature{(
$clusterCreateFeature=(0x0c97+ 3362-0x19b8));}sub 
enableAutomaticRecordingFeature{($automaticRecordingFeature=
(0x052f+ 4910-0x185c));}sub enableSshFeature{($sshFeature=(0x1dea+ 1354-0x2333))
;}sub enableNxFrameBufferFeature{($nxFrameBufferFeature=(0x1aaa+ 513-0x1caa));}
sub enableGuestAccessFeature{($guestAccessFeature=(0x0657+ 4311-0x172d));}sub 
isGuestAccessFeature{return ($guestAccessFeature);}sub 
enableVisitorAccessFeature{($visitorAccessFeature=(0x027f+ 5842-0x1950));}sub 
isVisitorAccessFeature{return ($visitorAccessFeature);}sub 
isGuestAccessFeatureEnabled{if (isGuestAccessFeature ()){(my $key=lc (
$GLOBAL::PhysicalDesktopAccessNodes));if ((($key=~ /guest/ )or ($key=~ /all/ )))
{return ((0x1b7d+ 397-0x1d09));}($key=lc ($GLOBAL::VirtualDesktopAccessNodes));
if ((($key=~ /guest/ )or ($key=~ /all/ ))){return ((0x0f08+ 3799-0x1dde));}if ((
$__guestAccessLogged!=(0x0622+ 2992-0x11d1))){Logger::debug (((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x47\x75\x65\x73\x74\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNodes)."\x27\x20\x27").
$GLOBAL::VirtualDesktopAccessNodes)."\x27\x2e"));($__guestAccessLogged=
(0x107a+ 5262-0x2507));}return ((0x14c7+ 1104-0x1917));}return (
(0x02a6+ 9109-0x263b));}sub isVisitorAccessFeatureEnabled{if (
isVisitorAccessFeature ()){(my $key=lc ($GLOBAL::PhysicalDesktopAccessNodes));if
 ((($key=~ /visitor/ )or ($key=~ /all/ ))){return ((0x1efa+ 1067-0x2324));}($key
=lc ($GLOBAL::VirtualDesktopAccessNodes));if ((($key=~ /visitor/ )or ($key=~ /all/ )
)){return ((0x2190+  14-0x219d));}if (($__visitorAccessLogged==
(0x15f7+ 2418-0x1f68))){Logger::debug (((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x56\x69\x73\x69\x74\x6f\x72\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNodes)."\x27\x20\x27").
$GLOBAL::VirtualDesktopAccessNodes)."\x27\x2e"));($__visitorAccessLogged=
(0x040c+ 412-0x05a7));}return ((0x09ab+ 1191-0x0e52));}return (
(0x00a9+ 4045-0x1076));}sub isGuestAccessFeatureDisabled{return ((!
isGuestAccessFeatureEnabled ()));}sub isNodeAccessAvailbleForGuest{if ((
$GLOBAL::EnableGuestAccessNode eq "\x30")){return ((0x06a9+ 4098-0x16ab));}(my $key
=lc ($GLOBAL::PhysicalDesktopAccessNodes));if (((($key=~ /visitor/ )or ($key=~ /all/ )
)or ($key=~ /guest/ ))){return ((0x0ea1+ 2772-0x1974));}($key=lc (
$GLOBAL::VirtualDesktopAccessNodes));if (((($key=~ /visitor/ )or ($key=~ /all/ )
)or ($key=~ /guest/ ))){return ((0x0880+ 4177-0x18d0));}Logger::debug (((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x67\x75\x65\x73\x74\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNodes)."\x27\x20\x27").
$GLOBAL::VirtualDesktopAccessNodes)."\x27\x2e"));return ((0x17e2+ 1561-0x1dfb));
}sub enablePhysicalGuestDesktopSharingFeature{(
$physicalGuestDesktopSharingFeature=(0x0112+ 1987-0x08d4));}sub 
isPhysicalGuestDesktopSharingFeature{return ($physicalGuestDesktopSharingFeature
);}sub isPhysicalGuestDesktopSharingFeatureEnabled{main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");if ((
isPhysicalGuestDesktopSharingFeature ()and 
NXLocalSession::isPhysicalDesktopAccessAvailbleForGuest ())){return (
(0x1c46+ 2182-0x24cb));}return ((0x017b+ 9407-0x263a));}sub 
isPhysicalGuestDesktopSharingFeatureDisabled{main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");if ((
isPhysicalGuestDesktopSharingFeature ()and (not (
NXLocalSession::isPhysicalDesktopAccessAvailbleForGuest ())))){return (
(0x02bc+ 4610-0x14bd));}return ((0x0796+ 1479-0x0d5d));}sub 
enableVirtualGuestDesktopSharingFeature{Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x45\x6e\x61\x62\x6c\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x67\x75\x65\x73\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x66\x65\x61\x74\x75\x72\x65\x2e"
);($virtualGuestDesktopSharingFeature=(0x0935+ 4592-0x1b24));}sub 
isVirtualGuestDesktopSharingFeature{return ($virtualGuestDesktopSharingFeature);
}sub isVirtualGuestDesktopSharingFeatureEnabled{main::nxrequire (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73");
if ((isVirtualGuestDesktopSharingFeature ()and 
NXSessionParameters::isVirtualDesktopAccessAvailbleForGuest ())){return (
(0x1b04+ 2507-0x24ce));}return ((0x0e63+ 4966-0x21c9));}sub 
isVirtualGuestDesktopSharingFeatureDisabled{main::nxrequire (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73");
if ((isVirtualGuestDesktopSharingFeature ()and (not (
NXSessionParameters::isVirtualDesktopAccessAvailbleForGuest ())))){return (
(0x0f63+ 591-0x11b1));}return ((0x1c89+ 1260-0x2175));}sub 
enableSubCloudServersFeature{($subCloudServersFeature=(0x051c+ 1349-0x0a60));}
sub enableForeignServersFeature{($foreignServersFeature=(0x1d3b+ 1116-0x2196));}
sub enableNotSystemUserFeature{($notSystemUserFeature=(0x1a92+ 729-0x1d6a));}sub
 enableNodeSynchronization{($nodeSynchronization=(0x10fb+ 2504-0x1ac2));}sub 
enableGuestsForNode{($guestForNode=(0x004f+ 5540-0x15f2));}sub 
isGuestsForNodeEnabled{if (($guestForNode==(0x0252+ 3218-0x0ee3))){Logger::debug
 (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x47\x75\x65\x73\x74\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x61\x72\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);return ((0x1037+ 1393-0x15a7));}return ((0x1f5d+ 938-0x2307));}sub 
isGuestsForNodeDisabled{return ((!isGuestsForNodeEnabled ()));}sub isRdpFeature{
return ($rdpFeature);}sub isDirectConnectionFeature{return ($directConnections);
}sub isServerAvailableAsRemoteServer{return ($serverAvailableAsRemoteServer);}
sub isServerAvailableAsRemoteNode{return ($serverAvailableAsRemoteNode);}sub 
isVirtualSessionsFeature{return ($virtualSessionsFeature);}sub 
isX11SessionsFeature{return ($x11SessionsFeature);}sub isGuestFeature{return (
$guestsFeature);}sub isNotGuestFeature{return ((!isGuestFeature ()));}sub 
isGuestFeatureEnabled{if ((isGuestFeature ()and (
$GLOBAL::EnableGuestCreateVirtualDesktop==(0x20cd+  55-0x2103)))){return (
(0x0274+ 2422-0x0be9));}return ((0x070d+ 5660-0x1d29));}sub isProfilesFeature{
return ($profilesFeature);}sub isNotProfilesFeature{return ((!isProfilesFeature 
()));}sub isMultiNodeFeature{return ($multinodeFeature);}sub 
isMultiServerFeature{return ($multiserverFeature);}sub 
isTerminalNodeSelectFeature{return ($terminalNodeSelectFeature);}sub 
isNotMultiServerFeature{return ((!isMultiServerFeature ()));}sub 
isKillingLeftoverCMonStarup{return ($killingLeftoverCMonStarup);}sub 
isNotMultiNodeFeature{return ((!isMultiNodeFeature ()));}sub isGroupsFeature{
return ($groupsFeature);}sub isNotGroupsFeature{return ((!isGroupsFeature ()));}
sub isRedirectFeature{return ($redirectFeature);}sub isNotRedirectFeature{return
 ((!isRedirectFeature ()));}sub isHttpdSupportFeature{return (
$httpdSupportFeature);}sub isClusterFeature{return ($clusterFeature);}sub 
isClusterCreateFeature{return ($clusterCreateFeature);}sub 
isAutomaticRecordingFeature{return ($automaticRecordingFeature);}sub 
isSshFeature{return ($sshFeature);}sub isNxFrameBufferFeature{return (
$nxFrameBufferFeature);}sub isVirtualSharingFeature{return (
$virtualSharingFeature);}sub isSubCloudServerFeature{return (
$subCloudServersFeature);}sub isForeignServersFeature{return (
$foreignServersFeature);}sub isNotForeignServersFeature{return ((!
isForeignServersFeature ()));}sub isNotsshFeature{return ((!isSshFeature ()));}
sub isNotSystemUserFeature{return ($notSystemUserFeature);}sub 
isNodeSynchronization{return ($nodeSynchronization);}sub isEnterpriseServer{
return ($EnterpriseServer);}sub isEnterpriseTerminalServer{return (
$EnterpriseTerminalServer);}sub getConnectionsLimit{return (
$GLOBAL::licenseConnectionsLimit);}sub getVirtualSessionLimit{if (
isNxFrameBufferFeature ()){return ((0x13e7+ 1677-0x1a73));}return (
$LicenseVirtualDesktopsLimit);}sub __setUpdateMode{(my $mode=(shift (@_)||
(0x06a9+ 6170-0x1ec2)));($defaultUpdateMode=$mode);}sub getUpdateMode{return (
$defaultUpdateMode);}sub checkNodeLicence{(my (@command)=($GLOBAL::CommandNXNode
,"\x2d\x2d\x76\x65\x72\x73\x69\x6f\x6e"));(my (@param)=());(my ($std_err,
$std_out,$ret_val)=main::run_command ((\@command),(\@param)));if (($std_out=~ /NXNODE - Version/ )
){return ((0x1c03+ 2604-0x262f));}else{main::nxwrite (main::nxgetSTDOUT (),
$std_out);return ((0x0136+ 2267-0x0a10));}}sub readLicenseFile{(my $licensePath=
shift (@_));my ($license);Logger::debug (((
"\x52\x65\x61\x64\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x77\x69\x74\x68\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x20\x27"
.$>)."\x27\x2e"));if ((defined ($licensePath)and ($licensePath ne ("")))){(
$license=$licensePath);Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x47\x69\x76\x65\x6e\x20\x70\x61\x74\x68\x20\x74\x6f\x20\x74\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$license)."\x2e"));}else{($license=$GLOBAL::PRODUCT_KEY_FILE);Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x50\x61\x74\x68\x20\x74\x6f\x20\x74\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$license)."\x2e"));}if ((not (Common::NXFile::fileExists ($license)))){
Logger::error (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$license)."\x27\x20\x64\x6f\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
return ("\x4d\x69\x73\x73\x65\x64");}(my $content=(""));(my $FILE=main::nxopen (
$license,$NXBits::O_RDONLY,(0x089f+ 4350-0x199d),{"\x45\x41\x43\x43\x45\x53",
"\x73\x69\x6c\x65\x6e\x74"}));if ($FILE){while (main::nxreadLine ($FILE,(\$_))){
($content.=$_);}main::nxclose ($FILE);}else{(my (@command)=
$GLOBAL::CommandNXexec);push (@command,"\x2d\x2d\x73\x65\x72\x76\x65\x72");push 
(@command,"\x2d\x2d\x73\x65\x72\x76\x65\x72\x6c\x69\x63\x65\x6e\x73\x65");(my (
@params)=());push (@params,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (@params,
"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68")));push (@params,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@params)));if (
$exit_value){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x73\x73\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$license).
"\x27\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x6e\x78\x65\x78\x65\x63\x2e"));
NXMsg::error (
"\x65\x52\x65\x61\x64\x69\x6e\x67\x54\x68\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4f\x6e\x54\x68\x65\x53\x65\x72\x76\x65\x72"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");NXShell::handle_command (
"\x65\x78\x69\x74");}else{($content=$cmd_out);}}($content=
Common::NXCore::extractLicenseBodyFromLicenseFile ($content));return ($content);
}sub chk_license{(my $subscription_mode=shift (@_));(my $showWarnings=
(0x01e5+ 5718-0x183a));if (($subscription_mode eq 
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2d\x73\x74\x61\x72\x74")){(
$showWarnings=(0x0db4+ 3037-0x1991));}if (($subscription_mode eq 
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e")){($subscription_mode=
(0x0940+ 4202-0x19a9));}else{($subscription_mode=(0x032c+ 3727-0x11bb));}(my (
%parameters)=());($parameters{"\x75\x73\x65\x72\x73"}=(0x0333+ 3364-0x1056));(
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=(0x1660+ 660-0x18f3)
);(my $content=readLicenseFile ());if (($content ne "\x4d\x69\x73\x73\x65\x64"))
{($isNoLicenseFile=(0x0910+ 1403-0x0e8b));setLicenseParameters ($content,(
\%parameters));if (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x74\x56\x61\x6c\x69\x64")){($isNoLicenseFile=(0x0c4a+ 926-0x0fe7));
goto CONFIG_END;}checkNXProduct ((\%parameters));($GLOBAL::FLAG_SEND_PRODUCT_KEY
=(0x10c3+ 2800-0x1bb2));}else{($isNoLicenseFile=(0x0ba5+ 5868-0x2290));
setMissedLicenseParameters ($content,(\%parameters));}Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x50\x72\x6f\x64\x75\x63\x74\x20\x49\x44\x20\x27"
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"})."\x27\x2e"));if (
libnxh::NXIsNomachineFreeServer ($__acronymId)){enableX11SessionsFeature ();
enablePhysicalGuestDesktopSharingFeature ();__setUpdateMode (
(0x085f+ 3246-0x150b));if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x0a99+ 2507-0x1464))){(
$GLOBAL::licenseConnectionsLimit=(0x12b0+ 915-0x1643));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}else{(
$GLOBAL::licenseConnectionsLimit=(0x0eb9+ 3066-0x1ab2));}
changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if (($users=~ /^-?\d/ )
){($GLOBAL::USERS_LIMIT=$parameters{"\x75\x73\x65\x72\x73"});}else{(
$GLOBAL::USERS_LIMIT=(0x14ad+ 1525-0x1aa2));}($GLOBAL::PRODUCT_MARK=
$GLOBAL::PRODUCT_ID);($GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});
enableCustomFreeSubscriptionMessage ();setIgnoreRolesConfigKeys ();}elsif ((((((
(((libnxh::NXIsEnterpriseServer ($__acronymId)or libnxh::NXIsCloudServer (
$__acronymId))or libnxh::NXIsQuickServer ($__acronymId))or 
libnxh::NXIsNomachineNetworkServer ($__acronymId))or 
libnxh::NXIsEnterpriseTerminalServer ($__acronymId))or 
libnxh::NXIsEnterpriseCloudServer ($__acronymId))or 
libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId))or 
libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))or 
libnxh::NXIsSmallBusinessCloudServer ($__acronymId))){if (
libnxh::NXIsEnterpriseServer ($__acronymId)){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Portal Server/NoMachine Cloud Server/ )
;($GLOBAL::PRODUCT_NAME=~ s/NoMachine Enterprise Server/NoMachine Cloud Server/ )
;enableMultiserverFeature ();enableKillingLeftoverCMonStarup ();($parameters{
"\x70\x72\x6f\x64\x75\x63\x74"}=$GLOBAL::PRODUCT_NAME);}elsif ((((
libnxh::NXIsCloudServer ($__acronymId)or libnxh::NXIsEnterpriseCloudServer (
$__acronymId))or libnxh::NXIsSmallBusinessCloudServer ($__acronymId))or 
libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))){if ((
$SubscriptionVersion==(0x034d+ 840-0x068e))){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Cloud Server/NoMachine Enterprise Cloud Server/ )
;($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}="\x45\x43\x53");(
$GLOBAL::PRODUCT_ID=($parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($__acronymId=
libnxh::NXParseServerProductId ($parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}enableMultiserverFeature ();
enableKillingLeftoverCMonStarup ();enableGuestAccessFeature ();
enableVisitorAccessFeature ();}if ((libnxh::NXIsEnterpriseCloudServer (
$__acronymId)or libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))){
enableRedirectFeature ();enableClusterFeature ();enableSubCloudServersFeature ()
;enableForeignServersFeature ();}if ((libnxh::NXIsEnterpriseTerminalServer (
$__acronymId)or libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId))){
enableMultiNodeFeature ();enableVirtualSessionsFeature ();enableRedirectFeature 
();enableClusterFeature ();enableGuestsFeature ();
enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableTerminalServerNodeSelect ();}if
 ((libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId)or 
libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))){
enableClusterCreateFeature ();}enableServerAvailableAsRemoteServer ();
enableReverseClientFeture ();enableRdpFeature ();enableX11SessionsFeature ();
enableProfilesFeature ();enableGroupsFeature ();enableRedirectFeature ();
enableSshFeature ();enableAutomaticRecordingFeature ();if ((not (
libnxh::NXIsNomachineNetworkServer ($__acronymId)))){enableHttpdSupportFeature 
();}if (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq 
(0x0882+ 3226-0x151c))){($GLOBAL::licenseConnectionsLimit=(0x1ce9+ 467-0x1ebc));
}elsif (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )
){($GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x0b96+ 1029-0x0f97));if ((
$GLOBAL::ConnectionsLimit>(0x089a+ 3214-0x1524))){($GLOBAL::ConnectionsLimit=
(0x192f+ 2837-0x2440));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x0e72+ 1420-0x13fe));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif (
libnxh::NXIsEnterpriseDesktop ($__acronymId)){
enableServerAvailableAsRemoteServer ();enableReverseClientFeture ();
enableX11SessionsFeature ();enableSshFeature ();enableHttpdSupportFeature ();
enableAutomaticRecordingFeature ();enablePhysicalGuestDesktopSharingFeature ();
enableRedirectFeature ();enableGroupsFeature ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x08bf+ 5835-0x1f8a))){(
$GLOBAL::licenseConnectionsLimit=(0x0071+ 1484-0x063d));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x0d24+ 3168-0x1980));if ((
$GLOBAL::ConnectionsLimit>(0x02ab+ 5782-0x193d))){($GLOBAL::ConnectionsLimit=
(0x0e27+ 3774-0x1ce1));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x050b+ 2693-0x0f90));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif (
libnxh::NXIsTerminalServer ($__acronymId)){enableVirtualSessionsFeature ();
enableX11SessionsFeature ();enableSshFeature ();enableGuestsFeature ();
enableProfilesFeature ();enableGroupsFeature ();enableRdpFeature ();
enableHttpdSupportFeature ();enableServerAvailableAsRemoteServer ();
enableReverseClientFeture ();enableAutomaticRecordingFeature ();
enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableRedirectFeature ();if ((
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq 
(0x139c+ 4478-0x251a))){($GLOBAL::licenseConnectionsLimit=(0x09a8+ 6243-0x220b))
;}elsif (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )
){($GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x12d4+ 2712-0x1d68));if ((
$GLOBAL::ConnectionsLimit>(0x0d59+ 5516-0x22e1))){($GLOBAL::ConnectionsLimit=
(0x005f+ 2089-0x0884));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x1b9b+ 106-0x1c05));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif ((
libnxh::NXIsSmallBusinessServer ($__acronymId)or 
libnxh::NXIsSmallBusinessTerminalServer ($__acronymId))){if ((
$SubscriptionVersion==(0x1240+ 3533-0x2006))){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Small Business Server/NoMachine Small Business Terminal Server/ )
;($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}="\x53\x42\x54\x53");(
$GLOBAL::PRODUCT_ID=($parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($__acronymId=
libnxh::NXParseServerProductId ($parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}
enableServerAvailableAsRemoteServer ();enableReverseClientFeture ();
enableVirtualSessionsFeature ();enableX11SessionsFeature ();enableSshFeature ();
enableHttpdSupportFeature ();enableAutomaticRecordingFeature ();
enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableRedirectFeature ();
enableGroupsFeature ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x0622+ 2213-0x0ec7))){(
$GLOBAL::licenseConnectionsLimit=(0x1641+ 1437-0x1bde));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x1d5c+ 1357-0x22a5));if ((
$GLOBAL::ConnectionsLimit>(0x0a60+ 4109-0x1a69))){($GLOBAL::ConnectionsLimit=
(0x1281+ 1271-0x1774));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x0f91+ 5132-0x239d));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif ((
libnxh::NXIsTerminalServerNode ($__acronymId)or 
libnxh::NXIsEnterpriseTerminalServerNode ($__acronymId))){if (
libnxh::NXIsTerminalServerNode ($__acronymId)){if (($SubscriptionVersion<=
(0x1536+ 1660-0x1bab))){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Terminal Server Node/NoMachine Enterprise Terminal Server Node/ )
;($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}="\x45\x54\x53\x4e");(
$GLOBAL::PRODUCT_ID=($parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($__acronymId=
libnxh::NXParseServerProductId ($parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}}enableRdpFeature ();
enableVirtualSessionsFeature ();enableX11SessionsFeature ();enableSshFeature ();
disableDirectConnections ();enableServerAvailableAsRemoteNode ();
enableAutomaticRecordingFeature ();enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableGuestsFeature ();
enableGuestsForNode ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x0123+ 2370-0x0a65))){(
$GLOBAL::licenseConnectionsLimit=(0x165b+ 4002-0x25fd));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}
changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x07c4+ 5935-0x1ef3));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif (
libnxh::NXIsWorkstation ($__acronymId)){enableVirtualSessionsFeature ();
enableX11SessionsFeature ();enableSshFeature ();enableHttpdSupportFeature ();
enableServerAvailableAsRemoteServer ();enableReverseClientFeture ();
enableAutomaticRecordingFeature ();enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableRedirectFeature ();
enableGroupsFeature ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x20f9+ 924-0x2495))){(
$GLOBAL::licenseConnectionsLimit=(0x06fd+ 4254-0x179b));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}
changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x0959+ 7547-0x26d4));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}else{
Logger::error (
"\x4e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x6c\x69\x63\x65\x6e\x73\x65\x2e"
);NXMsg::error (
"\x65\x47\x55\x49\x49\x6e\x76\x61\x6c\x69\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"
);main::nxexit ((0x02ad+ 3071-0x0eac));}updateLicenseDependantConfigKeys ();
checkLegacyPortKeys ();CONFIG_END:Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}).
"\x27\x2e"));if (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4d\x69\x73\x73\x65\x64")){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
);}elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x74\x56\x61\x6c\x69\x64")){NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif ((($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x6e\x65")and isCustomFreeSubscriptionMessage ())){if (
$subscription_mode){Common::NXMsg::send_response (
"\x77\x43\x6d\x64\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x46\x72\x65\x65"
);}}elsif (((($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x6e\x65")or ($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x50\x61\x72\x74\x6e\x65\x72"))or ($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x44\x65\x76\x65\x6c\x6f\x70\x65\x72"))){if ($subscription_mode){NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x55\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x64"
);}}elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e")){setEvaluation ();if (
$subscription_mode){Common::NXMsg::send_response (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e"
,$parameters{"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"});}}
elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64")){if (
$showWarnings){NXMsg::error (
"\x65\x47\x55\x49\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");}setEvaluationPeriodExpired ();}elsif (
($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64")){if ($subscription_mode){
main::subscriptionInfo ($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"},
$parameters{"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"},
$parameters{"\x70\x65\x72\x69\x6f\x64"},$parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"},
$parameters{"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"});}}
elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64\x45\x78\x70\x69\x72\x65\x64")){if (
$showWarnings){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");}}if (((
$GLOBAL::EnableGuestCreateVirtualDesktop==(0x1c46+ 647-0x1ecc))and 
isNotGuestFeature ())){Logger::warning (
"\x47\x75\x65\x73\x74\x20\x75\x73\x65\x72\x73\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);Logger::warning (
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x74\x65\x72\x6d\x73\x20\x61\x6e\x64\x20\x63\x6f\x6e\x64\x69\x74\x69\x6f\x6e\x73\x20\x6f\x66\x20\x79\x6f\x75\x72\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2e"
);}if ((($GLOBAL::EnableUserProfile eq "\x31")and isNotProfilesFeature ())){
Logger::warning (
"\x50\x72\x6f\x66\x69\x6c\x65\x73\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);Logger::warning (
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x74\x65\x72\x6d\x73\x20\x61\x6e\x64\x20\x63\x6f\x6e\x64\x69\x74\x69\x6f\x6e\x73\x20\x6f\x66\x20\x79\x6f\x75\x72\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2e"
);}return ($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"});}sub 
changeVirtualDesktopsLimitToLicense{(my $virtualDesktops=shift (@_));(my $limit=
__getFromLicenseVirtualSessionLimit ($virtualDesktops));(
$LicenseVirtualDesktopsLimit=$limit);}sub checkNodeProductID{(my $node_id=shift 
(@_));(my $server_id=shift (@_));if (($node_id=~ /^$server_id(EN|N|SN|PSN)$/ )){
return ((0x0096+ 3165-0x0cf2));}(my $serverAcronymId=
libnxh::NXParseServerProductId ($server_id));(my $nodeAcronymId=
libnxh::NXParseNodeProductId ($node_id));if ((libnxh::NXIsEnterpriseServer (
$serverAcronymId)and libnxh::NXIsEnterpriseDesktopNode ($nodeAcronymId))){return
 ((0x04cb+ 7202-0x20ec));}return ((0x1988+ 2992-0x2538));}sub 
load_system_settings{Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4c\x6f\x61\x64\x20\x73\x79\x73\x74\x65\x6d\x20\x73\x65\x74\x74\x69\x6e\x67\x73\x2e"
);if (isProfilesFeature ()){if (__ifUserNXOrAdmin ()){if (
NXProfilesManager::isProfilesEnabled ()){($GLOBAL::EnableUserProfile=
(0x024a+ 3706-0x10c3));}else{($GLOBAL::EnableUserProfile=(0x0159+ 7838-0x1ff7));
}}else{($GLOBAL::EnableUserProfile=(0x23e4+ 795-0x26ff));}}if (
isGuestsForNodeEnabled ()){($GLOBAL::EnableGuestCreateVirtualDesktop=
(0x0f76+ 5081-0x234e));}loadWelcomeString ();}sub __ifUserNXOrAdmin{return (((
Common::NXCore::getEffectiveUsername ()eq "\x6e\x78")||
main::effectiveUserIsAdministrator ()));}sub loadWelcomeString{if ((defined (
$GLOBAL::LICENSE)and length ($GLOBAL::LICENSE))){if (($GLOBAL::LICENSE eq 
"\x4e\x6f\x6e\x65")){($GLOBAL::WELCOME_STR=((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_MARK));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}elsif 
((($GLOBAL::LICENSE eq "\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e")or (
$GLOBAL::LICENSE eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"))){(
$GLOBAL::WELCOME_STR=(((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_MARK).
"\x20\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e"));($GLOBAL::MESSAGES_FORMAT{
$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}elsif (($GLOBAL::LICENSE eq 
"\x4d\x69\x73\x73\x65\x64")){($GLOBAL::WELCOME_STR=((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION));($GLOBAL::CLIENT_WELCOME_STR=(((
$GLOBAL::SOFTWARE_NAME."\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").
$GLOBAL::SOFTWARE_MAJ_VERSION).$GLOBAL::SOFTWARE_MIN_VERSION));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}elsif 
(($GLOBAL::LICENSE eq "\x53\x74\x61\x6e\x64\x61\x72\x64")){($GLOBAL::WELCOME_STR
=((((($GLOBAL::SOFTWARE_NAME."\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").
$GLOBAL::SOFTWARE_MAJ_VERSION).$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").
$GLOBAL::PRODUCT_MARK));($GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=
$GLOBAL::WELCOME_STR);}elsif (($GLOBAL::LICENSE eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64\x45\x78\x70\x69\x72\x65\x64")){(
$GLOBAL::WELCOME_STR=((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_MARK));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}(
$GLOBAL::LONG_WELCOME_STR=((($GLOBAL::PRODUCT_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION));($GLOBAL::MESSAGES_FORMAT{
$GLOBAL::LONG_WELCOME_STR}=$GLOBAL::LONG_WELCOME_STR);(
$GLOBAL::CLIENT_WELCOME_STR=((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_NAME));}else{
NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
__getFromLicenseVirtualSessionLimit{(my $valueFromLicense=shift (@_));if ((
$valueFromLicense eq (0x0d6a+ 1309-0x1287))){return ((0x1d60+ 772-0x2064));}
elsif (($valueFromLicense=~ /^-?\d/ )){return ($valueFromLicense);}else{return (
(-(0x0cc7+ 364-0x0e32)));}}sub Activate{(my $activateFile=shift (@_));(my $destination
=__findDestination ($activateFile));if ((not (defined ($destination)))){return (
(0x025f+ 6719-0x1c9d));}if (__backupLicenseFile ($destination)){return (
(0x03ba+ 5473-0x191a));}if (__copyLicToDestination ($activateFile,$destination))
{return ((0x20e9+ 1050-0x2502));}my ($errorName);my ($errorCode);if ((
$destination ne $cloudLicFile)){if ((Common::NXFile::setOwnershipForUserNX (
$destination,(\$errorName),(\$errorCode))==(-(0x0243+ 3869-0x115f)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x0e89+ 1118-0x12e6));}if ((Common::NXFile::setPermissionReadOnlyForNX (
$destination,(\$errorName),(\$errorCode))==(-(0x0eb2+ 4263-0x1f58)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x0480+ 2581-0x0e94));}}else{(my (@htdUsers)=NXTools::getNXHtdUser ());(my $user
=$htdUsers[(0x00a9+ 9427-0x257c)]);if ((Common::NXFile::setOwnershipForUser (
$destination,$user,(\$errorName),(\$errorCode))==(-(0x16af+ 133-0x1733)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x1849+ 3653-0x268d));}if ((Common::NXFile::setPermissionsReadOnlyForUser (
$destination,$user,(\$errorName),(\$errorCode))==(-(0x1198+ 3570-0x1f89)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x1c19+ 1432-0x21b0));}}main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);NXClientSystemDaemons::sendToServerDaemonNewLicenseActivated ();if ((not (
NXMsg::isMessageRegistered (
"\x69\x4c\x69\x63\x65\x6e\x73\x65\x41\x63\x74\x69\x76\x61\x74\x65\x64")))){
NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x69\x4c\x69\x63\x65\x6e\x73\x65\x41\x63\x74\x69\x76\x61\x74\x65\x64",
$GLOBAL::MSG_LICENSE_ACTIVATED);}NXMsg::send_response (
"\x69\x4c\x69\x63\x65\x6e\x73\x65\x41\x63\x74\x69\x76\x61\x74\x65\x64",
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$destination);return (
(0x0a66+ 5474-0x1fc8));}sub __backupLicenseFile{(my $orginal=shift (@_));if ((
not (Common::NXFile::fileExists ($orginal)))){return;}(my $backup=($orginal.
"\x2e\x62\x61\x63\x6b\x75\x70"));if (Common::NXFile::fileExists ($backup)){(
$backup.=("\x2d".NXTools::getTimeMs ()));}(my ($retValue,$outMsg)=
Common::NXCore::copyFile ($orginal,$backup));if (($outMsg ne (""))){
NXMsg::send_response (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$orginal,$backup,$outMsg);return (
(0x05a0+ 6996-0x20f3));}my ($errorName);my ($errorCode);if ((
Common::NXFile::setPermissionReadOnlyForNX ($backup,(\$errorName),(\$errorCode))
==(-(0x051a+ 3291-0x11f4)))){NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",(($backup."\x2e\x20").$errorName));return (
(0x047f+ 2460-0x0e1a));}}sub __getMd5FromFile{(my $filename=shift (@_));(my $content
=(""));(my $KEY_FD=main::nxopen ($filename,$NXBits::O_RDONLY,
(0x0003+ 6045-0x17a0),{"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));
while (main::nxreadLine ($KEY_FD,(\$_))){($content.=$_);}main::nxclose ($KEY_FD)
;if (($content ne (""))){return (Common::NXCore::digestMd5Hex ($content));}
return ((""));}sub __copyLicToDestination{(my $source=shift (@_));(my $destination
=shift (@_));($destination=~ s/\\\\/\\/g );if (($source eq $destination)){
NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x69\x43\x4d\x44\x4c\x69\x63\x65\x6e\x73\x65\x41\x6c\x72\x65\x61\x64\x79\x41\x63\x74\x69\x76\x65"
,(0x1468+ 116-0x1200));NXMsg::send_response (
"\x69\x43\x4d\x44\x4c\x69\x63\x65\x6e\x73\x65\x41\x6c\x72\x65\x61\x64\x79\x41\x63\x74\x69\x76\x65"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$source);return ((0x09cd+ 2161-0x123d));
}if (Common::NXFile::fileExists ($destination)){(my $source_md5=__getMd5FromFile
 ($source));(my $destination_md5=__getMd5FromFile ($destination));if ((((
$source_md5 ne (""))and ($destination_md5 ne ("")))and ($source_md5 eq 
$destination_md5))){return;}}my ($error);if ((
Common::NXFile::setPermissionsReadWriteForNX ($destination,(\$error))==(-
(0x1aff+  31-0x1b1d)))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$source,$destination,$error);return (
(0x0b00+ 799-0x0e1f));}(my ($retValue,$outMsg)=Common::NXCore::copyFile ($source
,$destination));if (($outMsg ne (""))){NXMsg::send_response (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$source,$destination,$outMsg);return (
(0x05ec+ 464-0x07bb));}Common::NXFile::setPermissionReadOnlyForNX ($destination)
;return ((0x0cdf+ 5676-0x230b));}sub getLicense{(my $path=shift (@_));(my $license
=(""));(my $FD=main::nxopen ($path,$NXBits::O_RDONLY,(0x164b+ 1628-0x1ca7)));if 
((not (defined ($FD)))){return (undef);}while (main::nxreadLine ($FD,(\$_))){(
$license.=$_);}main::nxclose ($FD);return ($license);}sub getServerLicense{
return (getLicense ($GLOBAL::PRODUCT_KEY_FILE));}sub reportServerLicense{(my $KEY_FD
=main::nxopen ($GLOBAL::PRODUCT_KEY_FILE,$NXBits::O_RDONLY,(0x10f9+ 1924-0x187d)
));if ((not (defined ($KEY_FD)))){main::nxexit ((0x154f+ 1790-0x1c4c));}else{
while (main::nxreadLine ($KEY_FD,(\$_))){main::nxwrite (main::nxgetSTDOUT (),$_)
;}main::nxclose ($KEY_FD);}}sub __findDestination{(my $file=shift (@_));(my $KEY_FD
=main::nxopen ($file,$NXBits::O_RDONLY,(0x1a8f+ 1342-0x1fcd)));if ((not (defined
 ($KEY_FD)))){(my $err=$file);(my $errorstring=libnxh::NXGetErrorString ());if (
($errorstring ne (""))){($err.=("\x20".$errorstring));}NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x46\x69\x6c\x65",$err);return (
undef);}(my $platform=(""));(my $productId=(""));(my $platformInNewLicense=(""))
;while (main::nxreadLine ($KEY_FD,(\$_))){if ( /^Platform: +(.*)\n$/ ){(
$platformInNewLicense=$1);}if ( /^Product Id: +(.)(.*)\n$/ ){($platform=$1);(
$productId=$2);}}main::nxclose ($KEY_FD);if ((($platform eq (""))or ($productId 
eq ("")))){NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x54\x79\x70\x65\x4e\x6f\x74\x52\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64"
,(0x0742+ 8621-0x26fb));NXMsg::send_response (
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x54\x79\x70\x65\x4e\x6f\x74\x52\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");return (undef);}if (($platform ne 
$GLOBAL::BUILD_PLATFORM)){unless (((($platform eq "\x41")||($platform eq "\x4c")
)and ($GLOBAL::BUILD_PLATFORM eq "\x52"))){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x6c\x61\x74\x66\x6f\x72\x6d"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$platformInNewLicense,
Common::NXInfo::getOsInfo ());return (undef);}}if ((($productId eq "\x41\x50")or
 ($productId eq "\x41\x50\x53"))){return ($codecLicFile);}(my $acronymId=(""));
if (__isUsingNodeLicenseFile ()){($acronymId=libnxh::NXParseNodeProductId (
$productId));}else{($acronymId=libnxh::NXParseServerProductId ($productId));}if 
(libnxh::NXIsValidAcronymId ($acronymId)){return ($serverLicFile);}
NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64",
(0x02a8+ 5012-0x1448));NXMsg::send_response (
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64",
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$productId);return (undef);}sub 
checkRemoteNodeLicense{(my $license=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b".
$license).
"\x5d\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));(my $acronymId=libnxh::NXParseNodeProductId ($license));if ((
libnxh::NXIsEnterpriseTerminalServerNode ($acronymId)or 
libnxh::NXIsTerminalServerNode ($acronymId))){Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x54\x65\x72\x6d\x69\x6e\x61\x6c\x20\x53\x65\x72\x76\x65\x72\x20\x4e\x6f\x64\x65\x2e"
);return ((0x02ff+ 8913-0x25cf));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b"
.$license)."\x5d\x2e"));return ((0x14fa+ 4136-0x2522));}sub 
checkRemoteServerLicense{(my $license=shift (@_));(my $acronymId=
libnxh::NXParseServerProductId ($license));if (((((((
libnxh::NXIsEnterpriseDesktop ($acronymId)or 
libnxh::NXIsSmallBusinessTerminalServer ($acronymId))or 
libnxh::NXIsEnterpriseTerminalServer ($acronymId))or libnxh::NXIsTerminalServer 
($acronymId))or libnxh::NXIsWorkstation ($acronymId))or 
libnxh::NXIsSmallBusinessServer ($acronymId))or 
libnxh::NXIsEnterpriseTerminalServerCluster ($acronymId))){Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x0329+ 1465-0x08e1));}if (
isSubCloudServerFeature ()){if ((((libnxh::NXIsEnterpriseCloudServer ($acronymId
)or libnxh::NXIsCloudServer ($acronymId))or libnxh::NXIsSmallBusinessCloudServer
 ($acronymId))or libnxh::NXIsEnterpriseCloudServerCluster ($acronymId))){
Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x20\x77\x69\x74\x68\x20\x73\x75\x62\x63\x6c\x6f\x75\x64\x2e"));
return ((0x0480+ 3139-0x10c2));}}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x1973+ 3430-0x26d9));}sub 
checkInverseServerLicense{(my $license=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b".
$license).
"\x5d\x20\x66\x6f\x72\x20\x69\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x63\x63\x65\x73\x73\x2e"
));(my $acronymId=libnxh::NXParseServerProductId ($license));if ((((
libnxh::NXIsCloudServer ($acronymId)or libnxh::NXIsEnterpriseCloudServer (
$acronymId))or libnxh::NXIsSmallBusinessCloudServer ($acronymId))or 
libnxh::NXIsEnterpriseCloudServerCluster ($acronymId))){Logger::debug (
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x43\x6c\x6f\x75\x64\x20\x53\x65\x72\x76\x65\x72\x2e"
);return ((0x0563+ 8299-0x25cd));}Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b"
.$license)."\x5d\x2e"));return ((0x2081+ 1237-0x2556));}sub 
remoteVersionAvailableAsNode{(my $version=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20".$version)
.
"\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));if (($version le "\x36")){Logger::warning (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x36\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"
);return ((0x0029+ 9754-0x2643));}return ((0x0244+ 1565-0x0860));}sub 
remoteLicenseAndVersionAvailableAsNode{(my $license=shift (@_));(my $version=
shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x65\x6d\x6f\x74\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x20\x76\x65\x72\x73\x69\x6f\x6e\x20").$version).
"\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));if (($version le "\x35")){Logger::warning (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x35\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"
);return ((0x0a4c+ 5896-0x2154));}if (($license=~ /terminal server node/ )){
Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x54\x65\x72\x6d\x69\x6e\x61\x6c\x20\x53\x65\x72\x76\x65\x72\x20\x4e\x6f\x64\x65\x2e"
);return ((0x174d+ 1761-0x1e2d));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20"
.$license)."\x2e"));return ((0x1832+ 1342-0x1d70));}sub 
isRemoteServerAvailableAsCluster{(my $license=shift (@_));if (
isLicenseCloudServerCluster ($license)){return ((0x0f10+ 407-0x10a6));}elsif (
isLicenseEnterpriseTerminalServerCluster ($license)){return (
(0x0662+ 3047-0x1248));}return ((0x0add+ 4677-0x1d22));}sub 
wasRemoteServerAvailableAsClusterAsV7{(my $license=shift (@_));if (
isLicenseCloudServer ($license)){return ((0x0653+  33-0x0673));}elsif (
isLicenseEnterpriseTerminalServer ($license)){return ((0x1cff+ 458-0x1ec8));}
return ((0x0b5b+ 679-0x0e02));}sub remoteLicenseAndVersionAvailableAsInverse{(my $license
=shift (@_));(my $version=shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x65\x6d\x6f\x74\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x20\x61\x6e\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x27").
$version).
"\x27\x20\x66\x6f\x72\x20\x69\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x63\x63\x65\x73\x73\x2e"
));if ((not (isReverseClientFeture ()))){Logger::warning (
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x1134+ 3580-0x1f30));}if (($version le "\x37")){Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20"
.$version)."\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"));return (
(0x014a+ 5146-0x1564));}if (($license=~ /terminal server node/ )){
Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x104c+ 4468-0x21c0));}if (($license=~ /enterprise cloud server/ )
){Logger::debug (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x72\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x25cc+ 247-0x26c2));}if (($license=~ /cloud server/ )
){if (isMultiServerFeature ()){Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x73\x75\x62\x2d\x63\x6c\x6f\x75\x64\x20\x27"
.$license)."\x27\x2e"));return ((0x1003+ 2796-0x1aef));}Logger::debug (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x05e2+ 1654-0x0c57));}Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x1f3f+ 1892-0x26a3));}sub 
remoteLicenseAndVersionAvailableAsServer{(my $license=shift (@_));(my $version=
shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x65\x6d\x6f\x74\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x20\x61\x6e\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x27").
$version).
"\x27\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x63\x63\x65\x73\x73\x2e"
));if (($version le "\x35")){Logger::warning (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x35\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"
);return ((0x0df8+ 4113-0x1e09));}if (($license=~ /terminal server node/ )){
Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x0bed+ 3135-0x182c));}if (($license=~ /cloud server/ )
){if (isSubCloudServerFeature ()){Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x20\x77\x69\x74\x68\x20\x73\x75\x62\x63\x6c\x6f\x75\x64\x2e"));
return ((0x06c1+ 4014-0x166e));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x1329+ 2181-0x1bae));}if ((((($license=~ /enterprise desktop/ )
or ($license=~ /workstation/ ))or ($license=~ /terminal server/ ))or ($license=~ /small business server/ )
)){Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x0de6+ 1511-0x13cc));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x00f3+ 7516-0x1e4f));}sub checkClusterLicense{
(my $license=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b".
$license).
"\x5d\x20\x66\x6f\x72\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));(my $acronymId=libnxh::NXParseServerProductId ($license));if ((((
libnxh::NXIsEnterpriseServer ($acronymId)or libnxh::NXIsCloudServer ($acronymId)
)or libnxh::NXIsNomachineNetworkServer ($acronymId))or 
libnxh::NXIsEnterpriseTerminalServer ($acronymId))){Logger::debug (
"\x43\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x45\x6e\x74\x65\x72\x70\x72\x69\x73\x65\x2f\x43\x6c\x6f\x75\x64\x20\x53\x65\x72\x76\x65\x72\x2e"
);return ((0x00e8+ 4591-0x12d6));}Logger::warning (((
"\x43\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b"
.$license)."\x5d\x2e"));return ((0x024f+ 1179-0x06ea));}sub 
errorEvaluationLicenseDuringUpgradeFromV3toV4{NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x55\x70\x67\x72\x61\x64\x65\x46\x72\x6f\x6d\x33\x54\x6f\x34\x4e\x6f\x74\x50\x6f\x73\x73\x69\x62\x6c\x65"
);NXShell::handle_command ("\x65\x78\x69\x74");}sub isEvaluationPeriodExpired{
return ($__evaluationPeriodExpired);}sub setEvaluationPeriodExpired{(
$__evaluationPeriodExpired=(0x1224+ 2777-0x1cfc));}sub setIgnoreRolesConfigKeys{
($ignoreRolesConfigKeys=(0x219a+ 1246-0x2677));}sub isIgnoreRolesConfigKeys{
return ($ignoreRolesConfigKeys);}sub isLicenseTerminalServerNode{(my $licenseString
=lc (shift (@_)));if (($licenseString=~ /terminal server node/ )){return (
(0x10ba+ 1979-0x1874));}return ((0x0ea9+ 779-0x11b4));}sub amITerminalServerNode
{return (isLicenseTerminalServerNode ($GLOBAL::PRODUCT_NAME));}sub 
isLicenseCloudServer{(my $license=lc (shift (@_)));if (($license=~ /cloud server/ )
){return ((0x05f8+ 6945-0x2118));}return ((0x0a40+ 746-0x0d2a));}sub 
isLicenseCloudServerCluster{(my $license=lc (shift (@_)));if (($license=~ /cloud server cluster/ )
){return ((0x082d+ 177-0x08dd));}return ((0x00bf+ 3286-0x0d95));}sub 
amICloudServer{return (isLicenseCloudServer ($GLOBAL::PRODUCT_NAME));}sub 
isLicenseEnterpriseTerminalServer{(my $license=lc (shift (@_)));if (($license=~ /enterprise terminal server/ )
){return ((0x00d9+ 1746-0x07aa));}return ((0x0247+ 8333-0x22d4));}sub 
isLicenseEnterpriseTerminalServerCluster{(my $license=lc (shift (@_)));if ((
$license=~ /enterprise terminal server cluster/ )){return ((0x156a+ 3518-0x2327)
);}return ((0x1311+ 3151-0x1f60));}sub amIEnterpriseTerminalServer{return (
isLicenseEnterpriseTerminalServer ($GLOBAL::PRODUCT_NAME));}sub setEvaluation{(
$__evaluation=(0x05db+ 4364-0x16e6));}sub isEvaluation{return ($__evaluation);}
sub __setUsingNodeLicenseFile{($usingNodeLicenseFile=(0x01e0+ 8827-0x245a));}sub
 __isUsingNodeLicenseFile{return ($usingNodeLicenseFile);}sub 
isNomachineFreeServer{if (libnxh::NXIsNomachineFreeServer ($__acronymId)){return
 ((0x056b+ 542-0x0788));}return ((0x01e3+ 8652-0x23af));}sub 
isTimeForCheckProcessorsCount{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=$__checkProcessorsCountDelay
);if ((($__lastCheckProcessorsCount+$delay)<$currentTime)){return (
(0x14a1+ 446-0x165e));}return ((0x0485+ 6022-0x1c0b));}sub checkProcessorsCount{
($__lastCheckProcessorsCount=Common::NXTime::getSecondsSinceEpoch ());(my $procCount
=libnxh::NXGetPhysicalCores ());if ((($licenseProcessorsCount!=
(0x184f+ 2846-0x236d))and ($procCount>$licenseProcessorsCount))){Logger::warning
 (((("\x59\x6f\x75\x72\x20\x73\x79\x73\x74\x65\x6d\x20\x72\x75\x6e\x73\x20".
$procCount).
"\x20\x63\x6f\x72\x65\x73\x20\x77\x68\x69\x6c\x65\x20\x79\x6f\x75\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20"
).(("\x6f\x6e\x6c\x79\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20".
$licenseProcessorsCount)."\x2e")));}}sub removeLicenseEvents{
NXEvent::removeEvent (NXEvent::getLicenseExpiredEventName ());}sub 
handleLicenseChanged{removeLicenseEvents ();($__evaluationPeriodExpired=
(0x16b6+ 1895-0x1e1d));($__evaluation=(0x0de1+ 2289-0x16d2));chk_license ();
main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");
NXConnectionMonitor::propagateNewLicense ();
NXConnectionMonitor::propagateNewLicenseToNodes ();(my $message=(
$GLOBAL::MSG_LICENSE_CHANGE.
"\x20\x4c\x69\x63\x65\x6e\x73\x65\x20\x63\x68\x61\x6e\x67\x65\x64\x20"));if (
isNoLicenseFile ()){($message.=
"\x74\x79\x70\x65\x3d\x6d\x69\x73\x73\x69\x6e\x67\x20");if (Server::isCluster ()
){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.Server::getMyUUID ()).
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x74\x61\x74\x75\x73\x2c\x76\x61\x6c\x75\x65\x3d\x66\x61\x69\x6c\x65\x64\x0a"
));}if (Server::isDaemonProcess ()){NXRedisSubscription::publishToSubscribers (
$message);}}elsif ((isEvaluationPeriodExpired ()or isLicenseExpired ())){(
$message.="\x74\x79\x70\x65\x3d\x65\x78\x70\x69\x72\x65\x64\x20");if (
Server::isCluster ()){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.Server::getMyUUID ()).
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x74\x61\x74\x75\x73\x2c\x76\x61\x6c\x75\x65\x3d\x66\x61\x69\x6c\x65\x64\x0a"
));}if (Server::isDaemonProcess ()){NXRedisSubscription::publishToSubscribers (
$message);}}else{NXConnectionMonitor::propagateMap ();}}sub 
enableReverseClientFeture{Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x45\x6e\x61\x62\x6c\x65\x20\x72\x65\x76\x65\x72\x73\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x66\x65\x61\x74\x75\x72\x65\x2e"
);($reverseClientFeature=(0x0506+ 6425-0x1e1e));}sub isReverseClientFeture{
return ($reverseClientFeature);}sub clearLicenseDependantConfigKeys{(
$GLOBAL::PhysicalDesktopAccess=undef);(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=undef);($GLOBAL::VirtualDesktopAccess
=undef);($GLOBAL::VirtualDesktopAccessNoAcceptance=undef);}sub 
updateLicenseDependantConfigKeys{Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x44\x65\x70\x65\x6e\x64\x61\x6e\x74\x43\x6f\x6e\x66\x69\x67\x4b\x65\x79\x73\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$__acronymId)."\x27\x2e"));if (libnxh::NXIsNomachineFreeServer ($__acronymId)){
if ((not (defined ($GLOBAL::PhysicalDesktopAccess)))){(
$GLOBAL::PhysicalDesktopAccess=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72\x2c\x73\x79\x73\x74\x65\x6d\x2c\x67\x75\x65\x73\x74"
);if (($GLOBAL::PhysicalDesktopSharing eq "\x30")){(
$GLOBAL::PhysicalDesktopAccess="\x6f\x77\x6e\x65\x72");}elsif ((
$GLOBAL::PhysicalDesktopSharing eq "\x32")){($GLOBAL::PhysicalDesktopAccess=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72"
);}}if ((not (defined ($GLOBAL::PhysicalDesktopAccessNoAcceptance)))){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72"
);if (($GLOBAL::PhysicalDesktopAuthorization eq "\x30")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x73\x79\x73\x74\x65\x6d");}elsif ((
$GLOBAL::PhysicalDesktopAuthorization eq "\x31")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=
"\x74\x72\x75\x73\x74\x65\x64\x2c\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72"
);}elsif (($GLOBAL::PhysicalDesktopAuthorization eq "\x32")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x74\x72\x75\x73\x74\x65\x64");}}}
else{if ((not (defined ($GLOBAL::PhysicalDesktopAccess)))){(
$GLOBAL::PhysicalDesktopAccess=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72\x2c\x73\x79\x73\x74\x65\x6d"
);if (($GLOBAL::PhysicalDesktopSharing eq "\x30")){(
$GLOBAL::PhysicalDesktopAccess="\x6f\x77\x6e\x65\x72");}elsif ((
$GLOBAL::PhysicalDesktopSharing eq "\x31")){($GLOBAL::PhysicalDesktopAccess=
"\x73\x79\x73\x74\x65\x6d");}}if ((not (defined (
$GLOBAL::PhysicalDesktopAccessNoAcceptance)))){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72"
);if (($GLOBAL::PhysicalDesktopAuthorization eq "\x30")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x73\x79\x73\x74\x65\x6d");}elsif ((
$GLOBAL::PhysicalDesktopAuthorization eq "\x32")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x74\x72\x75\x73\x74\x65\x64");}}}(
$GLOBAL::PhysicalDesktopAccess=lc ($GLOBAL::PhysicalDesktopAccess));(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=lc (
$GLOBAL::PhysicalDesktopAccessNoAcceptance));if ((lc (
$GLOBAL::PhysicalDesktopAccessNoAcceptance)=~ /guest/ )){Logger::warning (
"\x47\x75\x65\x73\x74\x20\x76\x61\x6c\x75\x65\x20\x6d\x75\x73\x74\x20\x6e\x6f\x74\x20\x62\x65\x20\x69\x6e\x63\x6c\x75\x64\x65\x64\x20\x69\x6e\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x41\x63\x63\x65\x73\x73\x4e\x6f\x41\x63\x63\x65\x70\x74\x61\x6e\x63\x65\x20\x6b\x65\x79\x2e"
);($GLOBAL::PhysicalDesktopAccessNoAcceptance=~ s/guest//g );}Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x44\x65\x70\x65\x6e\x64\x61\x6e\x74\x43\x6f\x6e\x66\x69\x67\x4b\x65\x79\x73\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x41\x63\x63\x65\x73\x73\x20\x27"
.$GLOBAL::PhysicalDesktopAccess)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x44\x65\x70\x65\x6e\x64\x61\x6e\x74\x43\x6f\x6e\x66\x69\x67\x4b\x65\x79\x73\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x41\x63\x63\x65\x73\x73\x4e\x6f\x41\x63\x63\x65\x70\x74\x61\x6e\x63\x65\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNoAcceptance)."\x27\x2e"));}sub saveTempLicense{(my $content
=shift (@_));(my $tempPath=(($serverLicFile."\x2e\x74\x6d\x70\x2e").$ $));
 (my $OUTFILE
=main::nxopen ($tempPath,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND
),$NXBits::UserReadWrite));if ((not (defined ($OUTFILE)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$tempPath)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));return (undef);}main::nxwrite ($OUTFILE,
$content);main::nxclose ($OUTFILE);return ($tempPath);}sub checkLegacyPortKeys{
if (($GLOBAL::SSHDPort ne (""))){Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x53\x53\x48\x44\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::SSHPort=$GLOBAL::SSHDPort);}if (($GLOBAL::SSHDUPnPPort ne (""))){
Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x53\x53\x48\x44\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::SSHUPnPPort=$GLOBAL::SSHDUPnPPort);}if (($GLOBAL::NXPort ne (""))){
Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x4e\x58\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::NXTCPPort=$GLOBAL::NXPort);}if (($GLOBAL::NXUPnPPort ne (""))){
Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x4e\x58\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::NXTCPUPnPPort=$GLOBAL::NXUPnPPort);}}sub setLicenseParameters{(my $content
=shift (@_));(my $ref_parameters=shift (@_));if (($content=~ /^Date: +(.*)$/m ))
{($$ref_parameters{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=$1);}
if (($content=~ /^Product: +(.*)$/m )){($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74"}=$1);($GLOBAL::PRODUCT_NAME=$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74"});}if (($content=~ /^Customer: +(.*)$/m )){(
$$ref_parameters{"\x63\x75\x73\x74\x6f\x6d\x65\x72"}=$1);}if (($content=~ /^Product Id: +(.)(.*)$/m )
){($$ref_parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=$1);(
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=$2);(
$productIdInLicense=$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}
);($GLOBAL::PRODUCT_ID=($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}.$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}($__acronymId=
libnxh::NXParseServerProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));if (($content=~ /^Subscription Id: +(.*)$/m )
){($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"}=$1);}if ((
$content=~ /^Subscription Type: +(.*)$/m )){($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=$1);}if 
(($content=~ /^(Expiration|Expiry): +(.*)$/m )){($$ref_parameters{
"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=$2);}if ((
$content=~ /^Platform: +(.*)$/m )){($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d"}=$1);($platformInLicense=$$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d"});}if (($content=~ /^Users: +(.*)$/m )){(
$$ref_parameters{"\x75\x73\x65\x72\x73"}=$1);if (($$ref_parameters{
"\x75\x73\x65\x72\x73"}=~ /nlimited$/ )){($$ref_parameters{
"\x75\x73\x65\x72\x73"}=(0x1374+ 1139-0x17e7));}}if (($content=~ /^Connections: +(.*)$/m )
){($$ref_parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=$1);if ((
$$ref_parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /nlimited$/ )
){($$ref_parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=
(0x1704+ 3814-0x25ea));}}if (($content=~ /^Virtual Desktops: +(.*)$/m )){(
$$ref_parameters{"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}
=$1);if (($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=~ /None$/ )){(
$$ref_parameters{"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}
=(-(0x195c+ 1873-0x20ac)));}elsif (($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=~ /nlimited$/ ))
{($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=
(0x01e1+ 4114-0x11f3));}}if ((($content=~ /^Processors: +(\d+)$/m )or ($content
=~ /^Processors: +\d+-(\d+)$/m ))){($licenseProcessorsCount=$1);}if (($content=~ /^Product Key: +(.*)$/m )
){($$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"}=$1);(
$GLOBAL::PRODUCT_KEY=$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"});}if (($content=~ /^Subscription Key: +(.*)$/m )
){($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"}=$1);}if ((
$content=~ /^Subscription Version: +(.*)$/m )){($SubscriptionVersion=$1);}elsif 
(($SubscriptionVersion==(-(0x10ba+ 3083-0x1cc4)))){($SubscriptionVersion=
$GLOBAL::defaultLegacyLicenseVersion);}($content=~ s/^(Subscription Key: +).*$/$1/m )
;($content=~ s/----- Begin subscription data -----\n//m );($content=~ s/----- End subscription data -----\n*//m )
;my ($c_subscription_key);(my $add_chr=substr (Common::NXCore::digestMd5Hex (
$$ref_parameters{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}),
(0x033f+ 2243-0x0c02),(0x21bb+ 1250-0x2695)));($content=~ s/^(Subscription Key: +).*$/$1/m )
;($c_subscription_key=(Common::NXCore::digestMd5Hex (($content.
$GLOBAL::PRODUCT_KEY_SALT)).$add_chr));if (($c_subscription_key ne 
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"})){(
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=
"\x4e\x6f\x74\x56\x61\x6c\x69\x64");return;}if (($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}ne $GLOBAL::BUILD_PLATFORM)){
unless ((("\x52" eq $GLOBAL::BUILD_PLATFORM)and (($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}eq "\x4c")||($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}eq "\x41")))){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x6c\x61\x74\x66\x6f\x72\x6d"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$platformInNewLicense,
Common::NXInfo::getOsInfo ());setWrongPlatformLicenseForPackage ();}}my ($sec,
$min,$hour,$mday,$mon,$year);my ($now);if (($$ref_parameters{
"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}ne 
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64")){if (($$ref_parameters{
"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*) (\d\d\d\d)/ )
){(($sec,$min,$hour,$mday,$mon,$year)=($6,$5,$4,$3,$2,$8));($mon=~ s/Jan/00/i );
($mon=~ s/Feb/01/i );($mon=~ s/Mar/02/i );($mon=~ s/Apr/03/i );($mon=~ s/May/04/i )
;($mon=~ s/Jun/05/i );($mon=~ s/Jul/06/i );($mon=~ s/Aug/07/i );($mon=~ s/Sep/08/i )
;($mon=~ s/Oct/09/i );($mon=~ s/Nov/10/i );($mon=~ s/Dec/11/i );(++$mon);}else{
NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}($$ref_parameters{
"\x65\x78\x70\x69\x72\x79"}=((((($year.sprintf ("\x25\x30\x32\x64",$mon)).
sprintf ("\x25\x30\x32\x64",$mday)).sprintf ("\x25\x30\x32\x64",$hour)).sprintf 
("\x25\x30\x32\x64",$min)).sprintf ("\x25\x30\x32\x64",$sec)));saveExpiryDate (
$$ref_parameters{"\x65\x78\x70\x69\x72\x79"});(my $expiry_timestamp=
Time::Local::timelocal ($sec,$min,$hour,$mday,($mon-(0x0130+ 3363-0x0e52)),$year
));saveExpiryTimestamp ($expiry_timestamp);if (checkIfLicenseExpired ()){(
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=(
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}.
"\x45\x78\x70\x69\x72\x65\x64"));}else{NXEvent::createEventOnTime (
NXEvent::getLicenseExpiredEventName (),$expiry_timestamp);}if (($$ref_parameters
{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*) (\d\d\d\d)/ )
){(($sec,$min,$hour,$mday,$mon,$year)=($6,$5,$4,$3,$2,$8));($mon=~ s/Jan/00/i );
($mon=~ s/Feb/01/i );($mon=~ s/Mar/02/i );($mon=~ s/Apr/03/i );($mon=~ s/May/04/i )
;($mon=~ s/Jun/05/i );($mon=~ s/Jul/06/i );($mon=~ s/Aug/07/i );($mon=~ s/Sep/08/i )
;($mon=~ s/Oct/09/i );($mon=~ s/Nov/10/i );($mon=~ s/Dec/11/i );(++$mon);}elsif 
(($$ref_parameters{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=~ /^.*(\d\d\d\d)-(\d\d)-(\d\d)/ )
){($year=$1);($mon=$2);($mday=$3);}else{NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x44\x61\x74\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}(my $date=(($year.sprintf (
"\x25\x30\x32\x64",$mon)).sprintf ("\x25\x30\x32\x64",$mday)));(my $date_timestamp
=Time::Local::timelocal ($sec,$min,$hour,$mday,($mon-(0x0025+ 9489-0x2535)),
$year));($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}=($expiry_timestamp-
$date_timestamp));($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}=(
$$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}/86400));if ((($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}eq (0x1281+ 1737-0x17dd))or ($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}eq (0x07f5+ 5916-0x1da3)))){($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}="\x31\x20\x79\x65\x61\x72");}else{($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}=(int ($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}).
"\x20\x64\x61\x79\x73"));}}else{($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}=
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64");saveExpiryDate (
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64");}(Common::NXCore::decodeDate (
$GLOBAL::BUILD_DAY)=~ /(\d{4})(\d{2})(\d{2})/ );(my $buildday_timestamp=
Time::Local::timelocal ((0x0c1b+ 1979-0x13d6),(0x0431+ 2383-0x0d80),
(0x1ecd+ 1929-0x264a),$3,($2-(0x0868+ 6020-0x1feb)),$1));my ($wday,$yday,$isdst)
;(($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=
Common::NXTime::getLocalTimeFromTimestamp ($buildday_timestamp));($year+=
(0x1439+ 1450-0x1277));($sec=sprintf ("\x25\x30\x32\x64",$sec));($min=sprintf (
"\x25\x30\x32\x64",$min));($hour=sprintf ("\x25\x30\x32\x64",$hour));(my (
@mon_list)=("\x4a\x61\x6e","\x46\x65\x62","\x4d\x61\x72","\x41\x70\x72",
"\x4d\x61\x79","\x4a\x75\x6e","\x4a\x75\x6c","\x41\x75\x67","\x53\x65\x70",
"\x4f\x63\x74","\x4e\x6f\x76","\x44\x65\x63"));(my (@day_list)=("\x53\x75\x6e",
"\x4d\x6f\x6e","\x54\x75\x65","\x57\x65\x64","\x54\x68\x75","\x46\x72\x69",
"\x53\x61\x74"));($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=((((((((
(((($day_list[$wday]."\x20").$mon_list[$mon])."\x20").$mday)."\x20").$hour).
"\x3a").$min)."\x3a").$sec)."\x20\x43\x45\x54\x20").$year));($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79"}=$year);($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79"}=($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf ("\x25\x30\x32\x64",($mon+
(0x1c84+ 1536-0x2283)))));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}=
($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf (
"\x25\x30\x32\x64",$mday)));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"
}=($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf (
"\x25\x30\x32\x64",$hour)));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"
}=($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf (
"\x25\x30\x32\x64",$min)));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}
=($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf (
"\x25\x30\x32\x64",$sec)));}sub setMissedLicenseParameters{(my $content=shift (
@_));(my $ref_parameters=shift (@_));($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=$content
);($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"}=
"\x4e\x6f\x6e\x65");($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=
"\x4e\x6f\x6e\x65");($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=uc (substr (
Common::NXInfo::getOsInfo (),(0x0b76+ 3104-0x1796),(0x0930+ 6028-0x20bb))));(
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=
libnxh::NXTransGetEnvironment ("\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"));if ((
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}eq (""))){(
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=$ENV{
"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"});}($__acronymId=
libnxh::NXParseServerProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($GLOBAL::PRODUCT_NAME=
libnxh::NXParseProductName ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($GLOBAL::PRODUCT_ID=(
$$ref_parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}.
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));(my ($sec,$min,
$hour,$mday,$mon,$year)=((0x0cec+ 149-0x0d81),(0x0f64+  97-0x0fc5),
(0x008c+ 6169-0x18a4),(0x0bb5+ 4311-0x1c8c),(0x00b7+ 2891-0x0c02),
(0x1246+ 5327-0x1f63)));($$ref_parameters{"\x65\x78\x70\x69\x72\x79"}=((((($year
.sprintf ("\x25\x30\x32\x64",$mon)).sprintf ("\x25\x30\x32\x64",$mday)).sprintf 
("\x25\x30\x32\x64",$hour)).sprintf ("\x25\x30\x32\x64",$min)).sprintf (
"\x25\x30\x32\x64",$sec)));saveExpiryDate ($$ref_parameters{
"\x65\x78\x70\x69\x72\x79"});(my $expiry_timestamp=(0x12a9+ 827-0x15e4));
saveExpiryTimestamp ($expiry_timestamp);}sub checkNXProduct{(my $ref_parameters=
shift (@_));if (isWrongNXProductInLicense ()){($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=getHardcodedNXProduct ());(
$$ref_parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=uc (substr (
Common::NXInfo::getOsInfo (),(0x0816+ 1927-0x0f9d),(0x143b+ 3991-0x23d1))));(
$GLOBAL::PRODUCT_ID=($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}.$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($GLOBAL::PRODUCT_NAME=
libnxh::NXParseProductName ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));if (__isUsingNodeLicenseFile ()){(
$__acronymId=libnxh::NXParseNodeProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}else{($__acronymId=
libnxh::NXParseServerProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}}else{(
$isNotSuitableLicenseForPackage=(0x065d+ 5472-0x1bbd));}}sub 
isWrongNXProductInLicense{(my $nxproduct=getHardcodedNXProduct ());if ((
$SubscriptionVersion<=(0x0671+ 2311-0x0f71))){if ((libnxh::NXIsCloudServer (
$__acronymId)and ($nxproduct eq "\x45\x43\x53"))){return ((0x0994+ 7344-0x2644))
;}elsif ((libnxh::NXIsTerminalServerNode ($__acronymId)and ($nxproduct eq 
"\x45\x54\x53\x4e"))){return ((0x2397+ 124-0x2413));}elsif ((
libnxh::NXIsSmallBusinessServer ($__acronymId)and ($nxproduct eq 
"\x53\x42\x54\x53"))){return ((0x080f+ 6918-0x2315));}}if ((
libnxh::NXIsNomachineFreeServer ($__acronymId)and ($nxproduct eq "\x53"))){
return ((0x1507+ 922-0x18a1));}elsif ((libnxh::NXIsEnterpriseCloudServer (
$__acronymId)and ($nxproduct eq "\x45\x43\x53"))){return ((0x0d25+ 3707-0x1ba0))
;}elsif ((libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId)and ($nxproduct
 eq "\x45\x43\x53\x43"))){return ((0x09ac+ 709-0x0c71));}elsif ((
libnxh::NXIsCloudServer ($__acronymId)and ($nxproduct eq "\x43\x53"))){return (
(0x0655+ 7097-0x220e));}elsif ((libnxh::NXIsSmallBusinessCloudServer (
$__acronymId)and ($nxproduct eq "\x53\x42\x43\x53"))){return (
(0x043c+ 2921-0x0fa5));}elsif ((libnxh::NXIsEnterpriseTerminalServer (
$__acronymId)and ($nxproduct eq "\x45\x54\x53"))){return ((0x1666+ 3134-0x22a4))
;}elsif ((libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId)and (
$nxproduct eq "\x45\x54\x53\x43"))){return ((0x222d+ 1160-0x26b5));}elsif ((
libnxh::NXIsTerminalServerNode ($__acronymId)and ($nxproduct eq "\x54\x53\x4e"))
){return ((0x009a+ 7508-0x1dee));}elsif ((
libnxh::NXIsEnterpriseTerminalServerNode ($__acronymId)and ($nxproduct eq 
"\x45\x54\x53\x4e"))){return ((0x082c+ 986-0x0c06));}elsif ((
libnxh::NXIsTerminalServer ($__acronymId)and ($nxproduct eq "\x54\x53"))){return
 ((0x1ab5+ 2775-0x258c));}elsif ((libnxh::NXIsSmallBusinessTerminalServer (
$__acronymId)and ($nxproduct eq "\x53\x42\x54\x53"))){return (
(0x0ea5+ 1279-0x13a4));}elsif ((libnxh::NXIsEnterpriseDesktop ($__acronymId)and 
($nxproduct eq "\x45\x44"))){return ((0x1111+ 2472-0x1ab9));}elsif ((
libnxh::NXIsWorkstation ($__acronymId)and ($nxproduct eq "\x57"))){return (
(0x1b79+ 1103-0x1fc8));}Logger::error (((((
"\x54\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27".$GLOBAL::PRODUCT_ID).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x69\x74\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x64\x75\x63\x74\x20\x27"
).$nxproduct)."\x27\x2e"));NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x72\x6f\x64\x75\x63\x74"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$nxproduct,$productIdInLicense);
setNotSuitableLicenseForPackage ();return ((0x01e3+ 6503-0x1b49));}sub 
getHardcodedNXProduct{(my $nxproduct=libnxh::NXTransGetEnvironment (
"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"));if (($nxproduct eq (""))){($nxproduct=
$ENV{"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"});}return ($nxproduct);}sub 
getNodeLicenseStatus{(my $uuid=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x6e\x6f\x64\x65\x73\x2e"
.$uuid).
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x53\x74\x61\x74\x75\x73\x0a"
));(my $subscriptionStatus=main::urldecode (NXRedis::get ()));return (
$subscriptionStatus);}sub isLicenseSuspendsFurtherWork{if (((((
isEvaluationPeriodExpired ()or isLicenseExpired ())or isNoLicenseFile ())or 
isNotSuitableLicenseForPackage ())or isWrongPlatformLicenseForPackage ())){
return ((0x13f2+ 281-0x150a));}return ((0x07f2+ 6593-0x21b3));}sub 
doesProductSupportGuestCreateVirtual{(my $productId=shift (@_));(my $acronym=
libnxh::NXParseServerProductId ($productId));if (((libnxh::NXIsTerminalServer (
$acronym)or libnxh::NXIsEnterpriseTerminalServer ($acronym))or 
libnxh::NXIsEnterpriseTerminalServerCluster ($acronym))){return (
(0x04f9+ 2383-0x0e47));}return ((0x16a7+ 1933-0x1e34));}sub 
doesProductSupportGuestAccess{(my $productId=shift (@_));(my $acronym=
libnxh::NXParseServerProductId ($productId));if ((((libnxh::NXIsCloudServer (
$acronym)or libnxh::NXIsEnterpriseCloudServer ($acronym))or 
libnxh::NXIsSmallBusinessCloudServer ($acronym))or 
libnxh::NXIsEnterpriseCloudServerCluster ($acronym))){return (
(0x0c1b+ 6609-0x25eb));}return ((0x0f57+ 4210-0x1fc9));}NXMsg::register_response
 ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,(0x0353+ 409-0x02f8));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x52\x65\x61\x64\x69\x6e\x67\x54\x68\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4f\x6e\x54\x68\x65\x53\x65\x72\x76\x65\x72"
,(0x2226+ 539-0x224d));Common::NXMsg::register_response (
"\x69\x43\x6c\x75\x73\x74\x65\x72\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
,(0x077b+ 5519-0x1ae1));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
,(0x0d6d+ 2325-0x140c));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64"
,(0x18f2+ 3446-0x23f2));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
,(0x1f37+ 1713-0x2372));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x6c\x61\x74\x66\x6f\x72\x6d"
,(0x0743+ 6858-0x1f97));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x72\x6f\x64\x75\x63\x74"
,(0x0c85+ 628-0x0c83));return ((0x1da3+ 2342-0x26c8));
