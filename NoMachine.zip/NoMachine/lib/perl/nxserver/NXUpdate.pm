############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUpdate::BEGIN{package NXUpdate;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXUpdate::BEGIN{package 
NXUpdate;no warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import (
"\x3a\x74\x72\x79")};}sub NXUpdate::BEGIN{package NXUpdate;no warnings;require 
NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->import};}package NXUpdate;no warnings
;($readSize=(0x0384+ 9165-0x26d1));($inited=(0x1cb2+ 303-0x1de1));($step=
(0x23bc+ 750-0x2696));($updatePid=(0x09e0+ 4471-0x1b57));($clientPid=
(0x00d9+ 3534-0x0ea7));($pidFile=(""));($nodeSessionID=(""));($lastAskForUpdate=
(-(0x0695+ 7664-0x2484)));($lastRepeatForUpdate=(-(0x0c49+ 5957-0x238d)));(
$pendingVersion="\x2d\x31");($ignoreVersion="\x2d\x31");($ignoreUpgradeVersion=
"\x2d\x31");($lastUpdate=(-(0x1924+ 1992-0x20eb)));($updateMode=(-
(0x0d92+ 4101-0x1d96)));($automaticInstall=(-(0x0546+ 6033-0x1cd6)));($hostName=
"\x2d\x31");($timestampIndex=(0x1a75+ 2163-0x22e8));($updateModeIndex=
(0x142d+ 4127-0x244b));($pendingVersionIndex=(0x0cd7+ 4418-0x1e17));(
$ignoreVersionIndex=(0x03b1+ 6826-0x1e58));($ignoreUpgradeVersionIndex=
(0x0ad9+ 1113-0x0f2e));($automtaicInstallIndex=(0x2075+  13-0x207d));(
$hostNameIndex=(0x00e8+ 3544-0x0eba));($pendingVersionInstallOnStartup=(-
(0x1782+ 3875-0x26a4)));($repeatCheckOnStartupCount=(-(0x025a+ 7369-0x1f22)));(
$DefaultUpdateFrequency=172800);($DefaultAskUpdateFrequency=432000);(
$DefaultDownloadUpdateFrequency=(0x1a3a+ 1532-0x1226));(
$DefaultCheckOnStartupFrequency=(0x0b1d+ 5001-0x1ea1));(
$DefaultCheckOnStartupCounter=(0x1454+ 2527-0x1e2f));($SilentUpdateMode=
(0x0512+ 912-0x08a1));($BackgroundUpdateMode=(0x112a+ 4353-0x2229));(
$UpdateFrequency=(-(0x03eb+ 8209-0x23fb)));($UpdateFilePermissions=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));sub 
setUpdateFrequency{(my $time=(shift (@_)||(0x0212+ 1319-0x0739)));(
$UpdateFrequency=$time);}sub getUpdateFrequency{if (($UpdateFrequency!=(-
(0x11b2+ 3422-0x1f0f)))){return ($UpdateFrequency);}if ((
$GLOBAL::UpdateFrequency=~ /^\d+$/ )){($UpdateFrequency=$GLOBAL::UpdateFrequency
);return ($UpdateFrequency);}($UpdateFrequency=$DefaultUpdateFrequency);return (
$UpdateFrequency);}sub getAskUpdateFrequency{if (($GLOBAL::AskUpdateFrequency=~ /^\d+$/ )
){return ($GLOBAL::AskUpdateFrequency);}return ($DefaultAskUpdateFrequency);}sub
 getDownloadUpdateFrequency{if (($GLOBAL::DownloadUpdateFrequency=~ /^\d+$/ )){
return ($GLOBAL::DownloadUpdateFrequency);}return (
$DefaultDownloadUpdateFrequency);}sub getUpdateFilePath{if ((
$GLOBAL::UpdateFilePath eq (""))){($GLOBAL::UpdateFilePath=(((($GLOBAL::VAR_ROOT
.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").$GLOBAL::DIRECTORY_SLASH).
"\x75\x70\x64\x61\x74\x65"));}return ($GLOBAL::UpdateFilePath);}sub 
checkIfTimeForCheckUpdate{if (((getLastCheck ()>=(0x1e74+ 2001-0x2645))and ((
getLastCheck ()+getUpdateFrequency ())<=Common::NXTime::getSecondsSinceEpoch ())
)){return ((0x03a5+ 7619-0x2167));}return ((0x0dc1+ 4631-0x1fd8));}sub 
checkIfTimeForAskUpdate{if (((isUpdateEnabled ()==(0x03dd+ 7883-0x22a8))or (
isBackgroundMode ()==(0x18b1+ 3451-0x262c)))){return ((0x030b+ 8954-0x2605));}if
 (((getLastAskForUpdate ()>(0x0351+ 3401-0x109a))and ((getLastAskForUpdate ()+
getAskUpdateFrequency ())<=Common::NXTime::getSecondsSinceEpoch ()))){return (
(0x11aa+  55-0x11e0));}return ((0x05d4+ 265-0x06dd));}sub checkIfRepeatUpdate{if
 ((isBackgroundMode ()==(0x0db7+ 118-0x0e2c))){return ((0x00f6+ 7781-0x1f5b));}
if ((getLastRepeatForUpdate ()>(0x0468+ 8309-0x24dd))){return (
(0x1462+ 613-0x16c6));}return ((0x16e7+ 2890-0x2231));}sub 
checkLastRepeatedUpdate{if (((getLastRepeatForUpdate ()+
getDownloadUpdateFrequency ())<=Common::NXTime::getSecondsSinceEpoch ())){return
 ((0x1a02+ 1303-0x1f18));}return ((0x12b6+ 351-0x1415));}sub 
checkIfRepeatOnStartup{if ((isBackgroundMode ()==(0x05e7+ 1077-0x0a1b))){return 
((0x0413+ 4655-0x1642));}if ((($repeatCheckOnStartupCount==(-
(0x0f6c+ 1461-0x1520)))or ($repeatCheckOnStartupCount>=
$DefaultCheckOnStartupCounter))){return ((0x11bf+ 4929-0x2500));}return (
(0x0fb8+ 4303-0x2086));}sub checkLastCheckOnStartup{if (((
getLastRepeatCheckOnStartup ()+$DefaultCheckOnStartupFrequency)<=
Common::NXTime::getSecondsSinceEpoch ())){return ((0x0718+ 6816-0x21b7));}return
 ((0x0e9c+ 3501-0x1c49));}sub checkIfAskForInstallUpdate{(my $sessionID=shift (
@_));if (($sessionID eq (""))){return;}if ((isUpdateEnabled ()==
(0x054c+ 1431-0x0ae3))){return;}if ((isBackgroundMode ()==(0x1366+ 1413-0x18eb))
){return;}if (($pendingVersionInstallOnStartup<(0x1f8d+ 1761-0x266e))){return;}
NXSession2::checkConsistence ();if ((
NXSession2::isLocalSessionDesktopBySessionId ($sessionID)==(0x0b49+ 4480-0x1cc9)
)){return;}__handleAskForUpdate ($sessionID);if ((
$pendingVersionInstallOnStartup>(0x0860+ 2723-0x1303))){(
$pendingVersionInstallOnStartup=(-(0x02d9+ 8482-0x23fa)));}return;}sub 
handleCheckUpdateOnSession{(my $sessionID=shift (@_));if (isUpdateRunning ()){
return ((0x0574+ 3404-0x12c0));}saveTime ();if ((not ($inited))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x20\x6e\x6f\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x2c\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x69\x74\x20\x66\x69\x72\x73\x74\x20\x61\x73\x20\x72\x6f\x6f\x74\x2e"
);return ((0x0245+ 5536-0x17e4));}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x75\x6e\x64\x2c\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
);__sendUpdateMessage ($sessionID,"\x75\x70\x64\x61\x74\x65");return (
(0x0c55+ 6730-0x269f));}sub isUpdateRunning{(my $pidToCheck=$updatePid);if ((
$pidToCheck<=(0x1af6+ 1733-0x21bb))){($pidToCheck=$clientPid);}if (($pidToCheck>
(0x1623+ 2971-0x21be))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x72\x6f\x63\x65\x73\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pidToCheck)."\x27\x2e"));return ((0x0208+ 1496-0x07df));}return (
(0x0ae0+ 6683-0x24fb));}sub checkUpdate{if ((NXLicense::isLicenseExpired ()==
(0x0c5d+ 510-0x0e5a))){setUpdateFrequency ((0x0ee1+ 220-0x0fbd));return;}elsif (
($UpdateFrequency!=$GLOBAL::UpdateFrequency)){setUpdateFrequency (
$GLOBAL::UpdateFrequency);}if ((isUpdateEnabled ()==(0x11f2+ 5041-0x25a3))){
return;}if ((checkIfRepeatOnStartup ()==(0x1ddb+ 2307-0x26dd))){if ((
checkLastCheckOnStartup ()==(0x17b5+ 1918-0x1f32))){(++
$repeatCheckOnStartupCount);(my $sinceLastUpdate=(
Common::NXTime::getSecondsSinceEpoch ()-getLastRepeatCheckOnStartup ()));
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x63\x68\x65\x63\x6b\x20\x6f\x6e\x20\x73\x74\x61\x72\x74\x75\x70\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastRepeatCheckOnStartup ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20")
.$sinceLastUpdate)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2e"));
handleUpdate ();setLastRepeatCheckOnStartup ();}return;}elsif ((
checkIfRepeatUpdate ()==(0x07f1+ 7014-0x2356))){if ((checkLastRepeatedUpdate ()
==(0x060b+ 8348-0x26a6))){(my $sinceLastUpdate=(
Common::NXTime::getSecondsSinceEpoch ()-getLastRepeatForUpdate ()));
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x63\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastRepeatForUpdate ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20").
$sinceLastUpdate)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2e"));
handleUpdate ();setLastRepeatForUpdate ();}return;}if ((
checkIfTimeForCheckUpdate ()==(0x08e4+ 1280-0x0de3))){(my $sinceLastUpdate=(
Common::NXTime::getSecondsSinceEpoch ()-getLastCheck ()));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastCheck ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20").
$sinceLastUpdate).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2c\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
));handleUpdate ();}elsif ((checkIfTimeForAskUpdate ()==(0x1b86+ 2520-0x255d))){
(my $sinceLastUpdate=(Common::NXTime::getSecondsSinceEpoch ()-
getLastAskForUpdate ()));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastAskForUpdate ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20").
$sinceLastUpdate)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2e"));
__handleAskForUpdate ();}return;}sub getLastCheck{if (($lastUpdate<
(0x13fb+ 3280-0x20cb))){($lastUpdate=lastUpdateTime ());}return ($lastUpdate);}
sub getLastAskForUpdate{return ($lastAskForUpdate);}sub setLastAskForUpdate{(
$lastAskForUpdate=Common::NXTime::getSecondsSinceEpoch ());}sub 
getLastRepeatForUpdate{return ($lastRepeatForUpdate);}sub setLastRepeatForUpdate
{($lastRepeatForUpdate=Common::NXTime::getSecondsSinceEpoch ());}sub 
resetRepeatForUpdate{($lastRepeatForUpdate=(-(0x074a+ 2166-0x0fbf)));}sub 
getLastRepeatCheckOnStartup{return ($lastRepeatCheckOnStartup);}sub 
setLastRepeatCheckOnStartup{($lastRepeatCheckOnStartup=
Common::NXTime::getSecondsSinceEpoch ());}sub setLastCheck{($lastUpdate=
Common::NXTime::getSecondsSinceEpoch ());}sub __getPhysicalSession{Logger::debug
 (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x6f\x6f\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x61\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x68\x61\x74\x20\x63\x61\x6e\x20\x72\x75\x6e\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65"
);(my (@allLocalPhysicalSessions)=NXSession2::getLocalPhysicalSessionsList ());
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x67\x6f\x74\x20\x6c\x69\x73\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20"
.join ($",@allLocalPhysicalSessions))."\x2e"));foreach my $session (
@allLocalPhysicalSessions){Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20"
.$session)."\x2e"));if (NXSession2::isStatusRunning (
NXSession2::getStatusBySessionId ($session))){Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".
$session)."\x27\x20\x72\x65\x61\x64\x79\x2e"));return ($session);}else{
Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".
$session)."\x27\x20\x6e\x6f\x74\x20\x72\x65\x61\x64\x79\x2e"));}}return ((""));}
sub __sendUpdateMessage{(my $session=shift (@_));(my $mode=shift (@_));
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x5b"
.$session)."\x5d\x2e"));(my $message=((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_MAKE_UPDATE)."\x20").$mode)."\x20\x73\x65\x73\x73\x69\x6f\x6e\x3d")
.$session));if ((($mode eq "\x75\x70\x64\x61\x74\x65")and (
isCorrectedVersionFormat ($ignoreVersion)==(0x0b99+ 2676-0x160c)))){
checkIgnoreVersion ();($message.=("\x20\x69\x67\x6e\x6f\x72\x65\x3d".
$ignoreVersion));}return (NXNodeExec::sendToNodeBySessionId ($message,$session))
;}sub __handleAskForUpdate{(my $sessionID=(shift (@_)||("")));if (((
isUpdateEnabled ()==(0x0f58+ 4570-0x2132))or (isBackgroundMode ()==
(0x01c7+ 2542-0x0bb5)))){return ((0x1adb+ 991-0x1eba));}if (isUpdateRunning ()){
return ((0x0750+ 7353-0x2409));}setLastAskForUpdate ();if (($sessionID eq ("")))
{($sessionID=__getPhysicalSession ());if (($sessionID eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x66\x69\x6e\x64\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x1b1a+ 2657-0x257a));}}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x75\x6e\x64\x2c\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x61\x73\x6b\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
);(my $byte=__sendUpdateMessage ($sessionID,"\x61\x73\x6b"));if ((($byte==
(0x0dd0+ 2356-0x1704))or ($byte==(-(0x03ed+ 8701-0x25e9))))){return ((-
(0x0564+   3-0x0566)));}return ((0x048f+ 6728-0x1ed7));}sub handleUpdate{if ((
isBackgroundMode ()==(0x1638+ 2374-0x1f7d))){handleBackgroundUpdate (
"\x63\x68\x65\x63\x6b");return ((0x1721+ 2537-0x210a));}if ((not ($inited))){
Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x20\x6e\x6f\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x2c\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x69\x74\x20\x66\x69\x72\x73\x74\x20\x61\x73\x20\x72\x6f\x6f\x74\x2e"
);return ((0x20d9+ 620-0x2344));}if (isUpdateRunning ()){return (
(0x0fe9+ 1188-0x148d));}saveTime ();(my $session=__getPhysicalSession ());if ((
$session eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x66\x69\x6e\x64\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);if (($repeatCheckOnStartupCount==(-(0x0a86+ 1552-0x1095)))){(
$repeatCheckOnStartupCount=(0x0937+ 4670-0x1b75));}return ((0x05e9+ 2703-0x1077)
);}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x75\x6e\x64\x2c\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
);__sendUpdateMessage ($session,"\x75\x70\x64\x61\x74\x65");(
$repeatCheckOnStartupCount=$DefaultCheckOnStartupCounter);return (
(0x1aa7+  77-0x1af4));}sub __getUpdateFileContentStringBaseOnCurrentGlobals{(my $defaultContent
=($lastUpdate."\x3a"));($defaultContent.=($updateMode."\x3a"));($defaultContent
.=($pendingVersion."\x3a"));($defaultContent.=($ignoreVersion."\x3a"));(
$defaultContent.=($ignoreUpgradeVersion."\x3a"));($defaultContent.=(
$automaticInstall."\x3a"));($defaultContent.=$hostName);return ($defaultContent)
;}sub __getDefaultUpdateFileContent{(my $initalizeFromMemory=(shift (@_)||
(0x031c+ 4440-0x1474)));if (($initalizeFromMemory==(0x0bba+  38-0x0be0))){(
$lastUpdate=Common::NXTime::getSecondsSinceEpoch ());($updateMode=
NXLicense::getUpdateMode ());($pendingVersion="\x30");($ignoreVersion="\x30");(
$ignoreUpgradeVersion="\x30");($automaticInstall=(0x19d6+ 1517-0x1fc3));(
$hostName="\x30");}return (__getUpdateFileContentStringBaseOnCurrentGlobals ());
}sub __tryToGetUpdateFileContentFromMemory{(my $defaultContent=
__getDefaultUpdateFileContent ((0x0966+ 4323-0x1a48)));if (((not (defined (
$defaultContent)))or ($defaultContent eq ("")))){return (
__getDefaultUpdateFileContent ((0x03f6+ 6190-0x1c24)));}return (
validateUpdateFileContent ($defaultContent));}sub isCorrectedVersionFormat{(my $version
=shift (@_));if ((not (defined ($version)))){return ((0x0fcb+ 593-0x121c));}if (
(($version ne (""))and ((($version eq "\x30")||($version=~ /(\d+\.\d+\.\d+_\d+)/ )
)||($version=~ /(\d+\.\d+\.\d+)/ )))){return ((0x09d1+ 3459-0x1753));}return (
(0x04a4+ 2015-0x0c83));}sub setTimestampField{(my $value=(shift (@_)||("")));if 
((($value=~ /^\d+$/ )and ($value>(0x080a+ 3754-0x16b4)))){($lastUpdate=$value);
return ((0x1772+ 434-0x1923));}else{($lastUpdate=
Common::NXTime::getSecondsSinceEpoch ());}return ((0x0970+ 2983-0x1517));}sub 
checkTimestampFromMemory{(my $oldTimestamp=(shift (@_)||(0x016f+ 8264-0x21b7)));
if (((not (($oldTimestamp=~ /^\d+$/ )))or ($oldTimestamp<=(0x11e9+ 4140-0x2215))
)){($oldTimestamp=Common::NXTime::getSecondsSinceEpoch ());}if (((($lastUpdate=~ /^\d+$/ )
and ($lastUpdate>(0x029b+ 1873-0x09ec)))and ($lastUpdate>=$oldTimestamp))){
return;}else{setTimestampField ($oldTimestamp);}}sub setHostNameField{(my $value
=shift (@_));if (((defined ($value)and ($value ne ("")))and ($value ne 
"\x2d\x31"))){($hostName=$value);return ((0x0538+ 2374-0x0e7d));}else{($hostName
="\x30");}return ((0x0257+ 761-0x0550));}sub setAutomaticInstallField{(my $value
=shift (@_));if ((defined ($value)and ($value=~ /^[0,1]$/ ))){($automaticInstall
=$value);return ((0x1646+ 3670-0x249b));}else{($automaticInstall=
(0x0fa8+ 2879-0x1ae7));}return ((0x0380+ 1089-0x07c1));}sub 
validateUpdateFileContent{(my $content=(shift (@_)||("")));(my $initialize=(
shift (@_)||(0x09b5+ 5591-0x1f8c)));Logger::debug2 (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x3a\x20\x27"
.$initialize)."\x27\x2c\x20\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x20").$content).
"\x2e"));if ((defined ($content)and ($content eq ("")))){if (($initialize==
(0x0d05+ 4451-0x1e67))){(my $defaultContent=__getDefaultUpdateFileContent (
(0x032a+ 4705-0x158b)));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x27\x75\x70\x64\x61\x74\x65\x27\x20\x66\x69\x6c\x65\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x73\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);return (
$defaultContent);}else{return (__tryToGetUpdateFileContentFromMemory ());}}(my (
@updateFileContentArray)=split ( /:/ ,$content,(0x1646+ 571-0x1881)));(my $changeUpdateFile
=(0x11fc+ 3727-0x208b));if ((setTimestampField ($updateFileContentArray[
$timestampIndex])==(0x108c+ 808-0x13b3))){if (($initialize==(0x1bf1+ 895-0x1f6f)
)){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x77\x69\x74\x68\x3a\x20"
.$lastUpdate)."\x2e"));}}else{Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x77\x69\x74\x68\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$lastUpdate)."\x2e"));($changeUpdateFile=(0x00cd+ 7831-0x1f63));}if (
isCorrectUpdateMode ($updateFileContentArray[$updateModeIndex])){($updateMode=
$updateFileContentArray[$updateModeIndex]);if (($initialize==
(0x073b+ 1971-0x0eed))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$updateMode)."\x27\x2e"));}}else{($updateMode=NXLicense::getUpdateMode ());(
$changeUpdateFile=(0x1b43+ 1115-0x1f9d));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$updateMode)."\x27\x2e"));}if ((isCorrectedVersionFormat (
$updateFileContentArray[$pendingVersionIndex])==(0x0d6c+ 1642-0x13d5))){(
$pendingVersion=$updateFileContentArray[$pendingVersionIndex]);if (($initialize
==(0x043a+ 2316-0x0d45))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x70\x65\x6e\x64\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$pendingVersion)."\x27\x2e"));}}else{($pendingVersion="\x30");(
$changeUpdateFile=(0x0450+ 1002-0x0839));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x70\x65\x6e\x64\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$pendingVersion)."\x2e"));}if ((isCorrectedVersionFormat (
$updateFileContentArray[$ignoreVersionIndex])==(0x1d4c+ 1340-0x2287))){(
$ignoreVersion=$updateFileContentArray[$ignoreVersionIndex]);if (($initialize==
(0x00eb+ 8827-0x2365))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$ignoreVersion)."\x27\x2e"));}}else{($ignoreVersion="\x30");($changeUpdateFile=
(0x09c8+ 6926-0x24d5));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$ignoreVersion)."\x2e"));}if ((isCorrectedVersionFormat (
$updateFileContentArray[$ignoreUpgradeVersionIndex])==(0x1fd6+ 1029-0x23da))){(
$ignoreUpgradeVersion=$updateFileContentArray[$ignoreUpgradeVersionIndex]);if ((
$initialize==(0x0889+ 3247-0x1537))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x69\x67\x6e\x6f\x72\x65\x20\x75\x70\x67\x72\x61\x64\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$ignoreUpgradeVersion)."\x27\x2e"));}}else{($ignoreUpgradeVersion="\x30");(
$changeUpdateFile=(0x002a+ 6902-0x1b1f));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x69\x67\x6e\x6f\x72\x65\x20\x75\x70\x67\x72\x61\x64\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$ignoreUpgradeVersion)."\x27\x2e"));}if ((setAutomaticInstallField (
$updateFileContentArray[$automtaicInstallIndex])==(0x1419+ 2546-0x1e0a))){if ((
$initialize==(0x197b+ 1165-0x1e07))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x75\x70\x64\x61\x74\x65\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x69\x6e\x73\x74\x61\x6c\x6c\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$automaticInstall)."\x27\x2e"));}}else{Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x69\x6e\x73\x74\x61\x6c\x6c\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x20\x27\x30\x27\x2e"
);($changeUpdateFile=(0x0e9b+ 1880-0x15f2));}if ((setHostNameField (
$updateFileContentArray[$hostNameIndex])==(0x016f+ 8517-0x22b3))){if ((
$initialize==(0x0c06+ 2420-0x1579))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x68\x6f\x73\x74\x6e\x61\x6d\x65\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$hostName)."\x27\x2e"));}}else{Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x68\x6f\x73\x74\x6e\x61\x6d\x65\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x20\x27\x30\x27\x2e"
);($changeUpdateFile=(0x07a6+ 3540-0x1579));}if (($changeUpdateFile==
(0x012f+ 3185-0x0d9f))){(my $defaultContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());if (($initialize==
(0x1962+ 1743-0x2030))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x27\x75\x70\x64\x61\x74\x65\x27\x20\x66\x69\x6c\x65\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x73\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);}return (
$defaultContent);}else{return (__getUpdateFileContentStringBaseOnCurrentGlobals 
());}}sub initializeByUpdateFile{readInfoFromFile ((0x155d+ 3370-0x2286));return
;}sub checkAndCorrectUpdateFilePermission{(my $updateFile=getUpdateFilePath ());
if ((not (Common::NXFile::isExists ($updateFile)))){(my $defaultContent=
__getDefaultUpdateFileContent ((0x121b+ 290-0x133d)));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x63\x68\x65\x63\x6b\x41\x6e\x64\x43\x6f\x72\x72\x65\x63\x74\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2c\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x69\x74\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);}else{Logger::debug 
(((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x3a\x3a\x73\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x52\x65\x61\x64\x57\x72\x69\x74\x65\x46\x6f\x72\x4f\x77\x6e\x65\x72\x52\x65\x61\x64\x4f\x6e\x6c\x79\x46\x6f\x72\x41\x6c\x6c\x46\x6f\x72\x63\x65\x28"
.$updateFile)."\x29\x20\x73\x74\x61\x72\x74\x2e"));
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAllForce ($updateFile);
}}sub init{__setPidFilePath ();if ((not (Common::NXFile::isExists (
getUpdateFilePath ())))){(my $defaultContent=__getDefaultUpdateFileContent (
(0x0331+ 6639-0x1d20)));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x69\x6e\x69\x74\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2c\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x69\x74\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);}else{
initializeByUpdateFile ();}if ((not ($inited))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x69\x6e\x67\x2c\x20\x67\x65\x74\x74\x69\x6e\x67\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x61\x62\x6f\x75\x74\x20\x73\x79\x73\x74\x65\x6d\x2e"
);($inited=(0x1695+ 1742-0x1d62));Logger::debug ((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x55\x70\x64\x61\x74\x65\x46\x72\x65\x71\x75\x65\x6e\x63\x79\x20\x73\x65\x74\x20\x74\x6f\x3a\x20"
.getUpdateFrequency ()));}if ((isUpdateEnabled ()==(0x0b16+ 5391-0x2025))){
return ((0x1038+ 2616-0x1a70));}if ((isUpdateEnabled ()==(0x0ab7+ 686-0x0d64))){
if ((isBackgroundMode ()==(0x0149+ 3085-0x0d55))){checkIfReadyBackgroundUpdate 
();}else{checkIgnoreVersion ();}}}sub __setPidFilePath{($pidFile=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x72\x75\x6e\x6e\x65\x72\x2e\x70\x69\x64"));}
sub __getPidFilePath{if (($pidFile eq (""))){__setPidFilePath ();}return (
$pidFile);}sub lastUpdateTime{(my $updateTime=__getInformationFromUpdateFile (
$timestampIndex));if (($updateTime ne (""))){return ($updateTime);}return (
(0x16ba+ 3734-0x2550));}sub saveTime{setLastCheck ();(my $oldTimestamp=
$lastUpdate);(my $updateFile=getUpdateFilePath ());(my $FH=main::nxopen (
$updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),$UpdateFilePermissions));if (((
not (defined ($FH)))or ($FH<=(0x01cd+ 4262-0x1273)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return;}if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x241f+ 540-0x2638)));if (((not (
defined ($ret)))or ($ret<=(0x1ead+ 629-0x2122)))){Logger::warning (((
"\x73\x61\x76\x65\x54\x69\x6d\x65\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return;}(my ($readBytes,$validatedContent)=readInfoFromFileFD ($FH,
(0x01f0+ 2246-0x0ab6)));(my (@con)=split ( /:/ ,$validatedContent,
(0x07c8+ 5066-0x1b92)));checkTimestampFromMemory ();(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile ($newContent
,$FH,$readBytes);($updateFile=getUpdateFilePath ());Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x64\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x69\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile)."\x27\x3a\x20").$newContent)."\x2e"));}sub saveClientPid{(my $processPid
=shift (@_));(my $nodeSessionID=(shift (@_)||(0x1091+ 1795-0x1794)));($clientPid
=$processPid);if (((!$nodeSessionID)==(0x0bbd+ 5404-0x20d9))){(
$NXUpdate::nodeSessionID=$nodeSessionID);}return;}sub freeClientPidForNodeClose{
(my $nodeSessionID=(shift (@_)||"\x30"));if ((isUpdateEnabled ()==
(0x1457+ 1410-0x19d9))){return;}if (($nodeSessionID eq "\x30")){return;}if ((
$nodeSessionID eq $NXUpdate::nodeSessionID)){handleClientUpdateExit ();}return;}
sub handleClientUpdateExit{(my $isEAGAIN=(shift (@_)||(0x14e8+ 135-0x156f)));(
$clientPid=(0x0d66+ 5969-0x24b7));($nodeSessionID="\x30");if (($isEAGAIN==
(0x0a14+ 745-0x0cfd))){resetRepeatForUpdate ();}else{Logger::debug (
"\x43\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x45\x41\x47\x41\x49\x4e\x20\x65\x72\x72\x6f\x72\x2e"
);setLastRepeatForUpdate ();}return;}sub savePid{(my $processPid=shift (@_));if 
((($processPid eq (""))and ($processPid<=(0x08f3+ 2288-0x11e3)))){return (
(0x0970+ 1477-0x0f34));}($updatePid=$processPid);(my $filename=__getPidFilePath 
());Logger::debug ((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x70\x69\x64\x3a\x20".
$processPid).
"\x2c\x20\x66\x6f\x72\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x27\x20\x69\x6e\x20"
).$filename));(my $FH=main::nxopen ($filename,($NXBits::O_RDWR+$NXBits::O_CREAT)
,$NXBits::UserReadWrite));if ((not (defined ($FH)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$filename).
"\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),
(0x242d+  25-0x2446));return ((0x011a+ 8814-0x2387));}if ((main::nxwrite ($FH,(
$processPid."\x0a"))==(-(0x1f41+ 1086-0x237e)))){(my $error=libnxh::NXGetError 
());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),(0x0bc4+ 1458-0x1176))
;main::nxclose ($FH);return ((0x016d+ 7293-0x1de9));}main::nxclose ($FH);
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x61\x76\x65\x64\x20\x50\x49\x44\x20\x27"
.$processPid)."\x27\x20\x69\x6e\x20\x27").$filename)."\x27\x2e"));return (
(0x2145+ 1184-0x25e5));}sub removePid{return (__removePidFile (
(0x0f3b+ 2045-0x1737)));}sub __removePidFile{(my $silence=(shift (@_)||
(0x07c8+ 5254-0x1c4e)));($updatePid=(0x0f24+ 4728-0x219c));(my $filename=
__getPidFilePath ());if (Common::NXFile::isExists ($filename)){if ((not (unlink 
($filename)))){Logger::warning (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x3a\x20").$!)."\x2e"));return ((0x0843+ 280-0x095a));}}else{if
 ((not ($silence))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x2e"))
;}return ((0x00d5+ 9111-0x246c));}return ((0x04a3+ 3533-0x1270));}sub __readPid{
(my $silence=(shift (@_)||(0x0656+ 7218-0x2288)));if (($updatePid>
(0x1828+ 958-0x1be6))){Logger::debug2 (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x70\x69\x64\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x2e"
,(0x02ea+ 5666-0x190c));return ($updatePid);}(my $filename=__getPidFilePath ());
if ((not (Common::NXFile::isExists ($filename)))){if ((not ($silence))){
Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x46\x69\x6c\x65\x20\x27".$filename).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"),
(0x05ed+ 1611-0x0c38));}return ((0x1a25+ 590-0x1c73));}(my $FH=main::nxopen (
$filename,$NXBits::O_RDONLY,(0x02d7+ 8316-0x2353)));if ((not (defined ($FH)))){(my $error
=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$filename).
"\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),
(0x0115+ 6373-0x19fa));return ((0x1916+ 1662-0x1f94));}my ($processPid);
main::nxreadLine ($FH,(\$processPid));main::nxclose ($FH);if (($processPid=~ /^(\d+)$/ )
){chomp ($processPid);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x52\x65\x61\x64\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x3a\x20").$processPid)."\x2e"));($updatePid=$processPid);
return ($processPid);}Logger::warning (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x66\x6f\x72\x6d\x61\x74\x20\x6f\x66\x20\x50\x49\x44\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x3a\x20").$processPid)."\x2e"));return ((0x0543+ 865-0x08a4));
}sub __getPendingVersion{($pendingVersion=__getInformationFromUpdateFile (
$pendingVersionIndex));return ($pendingVersion);}sub __getIgnoreVersion{if (((
$ignoreVersion ne (""))and ($ignoreVersion ne "\x2d\x31"))){return (
$ignoreVersion);}return (__getInformationFromUpdateFile ($ignoreVersionIndex));}
sub __getInformationFromUpdateFile{(my $position=shift (@_));(my $validatedContent
=readInfoFromFile ());(my (@con)=split ( /:/ ,$validatedContent,
(0x19bc+ 1220-0x1e80)));if (((length ($con[$position])!=(0x03e1+ 479-0x05c0))and
 ($con[$position]ne "\x20"))){Logger::debug2 (((((
"\x5f\x5f\x67\x65\x74\x49\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x46\x72\x6f\x6d\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x20\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x27"
.$position)."\x27\x20\x76\x61\x6c\x75\x65\x3a\x20\x27").$con[$position]).
"\x27\x2e"));return ($con[$position]);}else{return ((""));}}sub 
__deletePendingVersion{(my $updateFile=getUpdateFilePath ());(my $FH=
main::nxopen ($updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),
$UpdateFilePermissions));if (((not (defined ($FH)))or ($FH<=
(0x0560+ 2633-0x0fa9)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return;}if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x1929+ 1461-0x1edb)));if (((not (
defined ($ret)))or ($ret<=(0x2102+ 1309-0x261f)))){Logger::warning (((
"\x5f\x5f\x64\x65\x6c\x65\x74\x65\x50\x65\x6e\x64\x69\x6e\x67\x56\x65\x72\x73\x69\x6f\x6e\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return;}(my ($readBytes,$validatedContent)=readInfoFromFileFD ($FH,
(0x1fac+ 189-0x2069)));(my (@con)=split ( /:/ ,$validatedContent,
(0x033c+ 1706-0x09e6)));($pendingVersion="\x30");(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile ($newContent
,$FH,$readBytes);}sub __deleteIgnoreVersion{(my $updateFile=getUpdateFilePath ()
);(my $FH=main::nxopen ($updateFile,($NXBits::O_RDWR+$$NXBits::O_CREAT),
$UpdateFilePermissions));if (((not (defined ($FH)))or ($FH<=
(0x0d41+ 5358-0x222f)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((-
(0x0341+ 1858-0x0a82)));}if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x078d+ 4283-0x1845)));if (((not (
defined ($ret)))or ($ret<=(0x0156+ 9633-0x26f7)))){Logger::warning (((
"\x5f\x5f\x64\x65\x6c\x65\x74\x65\x49\x67\x6e\x6f\x72\x65\x56\x65\x72\x73\x69\x6f\x6e\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));($ignoreVersion=
"\x30");main::nxclose ($FH);return;}(my ($readBytes,$validatedContent)=
readInfoFromFileFD ($FH,(0x0c7d+ 3597-0x1a8a)));(my (@con)=split ( /:/ ,
$validatedContent,(0x1742+ 400-0x18d2)));($ignoreVersion="\x30");(my $newContent
=__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile (
$newContent,$FH,$readBytes);}sub handleBackgroundUpdate{(my $mode=shift (@_));
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x75\x70\x64\x61\x74\x65\x20\x69\x6e\x20\x6d\x6f\x64\x65\x20\x27"
.$mode)."\x27\x2e"));my (@command,@parameters);main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);if ((((isUpdateEnabled ()==(0x0a3b+ 3823-0x192a))||(isBackgroundMode ()==
(0x056b+ 8266-0x25b5)))and (NXSoftwareUpdateDaemon::isWorking ()==
(0x1002+ 3869-0x1f1f)))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x42\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x75\x70\x64\x61\x74\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0f61+ 4199-0x1fc7));}if (isUpdateRunning ()){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x42\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x75\x70\x64\x61\x74\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ((0x1d7f+ 165-0x1e23));}if (($mode eq "\x63\x68\x65\x63\x6b")){saveTime
 ();}(my $pid=(""));push (@command,$GLOBAL::CommandClientBin);push (@command,
"\x2d\x2d\x75\x70\x64\x61\x74\x65",$mode,
"\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64");push (@parameters,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");foreach my $key (keys (%ENV)){if (((((((
($key ne "\x4e\x58\x5f\x52\x4f\x4f\x54")and ($key ne 
"\x55\x53\x45\x52\x4e\x41\x4d\x45"))and ($key ne "\x48\x4f\x4d\x45"))and ($key 
ne "\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d"))and ($key ne 
"\x4e\x58\x5f\x55\x53\x45\x52"))and ($key ne "\x4e\x58\x5f\x47\x52\x4f\x55\x50")
)and ($key ne "\x4e\x58\x5f\x43\x4f\x4e\x46\x49\x47"))){push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(($key."\x3d").libnxh::NXTransGetEnvironment (
$key)));}}(my $userDir=NXPaths::getUserNXHomeDir ());(my $userName=
Common::NXCore::getEffectiveUsername ());(my $userGroup=
$GLOBAL::CACHE_EFFECTIVE_USERGROUP);push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x52\x4f\x4f\x54\x3d".$userDir).
$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x43\x4f\x4e\x46\x49\x47\x3d".
$userDir).$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$userDir));push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x55\x53\x45\x52\x4e\x41\x4d\x45\x3d".$userName));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x55\x53\x45\x52\x3d".$userName));
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x47\x52\x4f\x55\x50\x3d".$userGroup));push (@parameters,
"\x67\x65\x74\x20\x70\x69\x64",(\$pid));my ($updateOut);
Common::NXCore::nxPipeCreateBi ((\$stdout),(\$updateOut));push (@parameters,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$updateOut);push (
@parameters,"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",$updateOut);
if (($mode eq "\x63\x68\x65\x63\x6b")){push (@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x65\x74\x50\x69\x64\x46\x6f\x72\x43\x68\x65\x63\x6b\x55\x70\x64\x61\x74\x65"
);}elsif (($mode eq "\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){push (@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x65\x74\x50\x69\x64\x46\x6f\x72\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x55\x70\x64\x61\x74\x65"
);}elsif (($mode eq "\x69\x6e\x73\x74\x61\x6c\x6c")){push (@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x65\x74\x50\x69\x64\x46\x6f\x72\x49\x6e\x73\x74\x61\x6c\x6c\x55\x70\x64\x61\x74\x65"
);}main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20"
.$mode)."\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x2e"));(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@parameters)));
if (($mode eq "\x63\x68\x65\x63\x6b")){($checkStdOutBuffer=undef);(
$checkExitStatus=undef);(my $description=(
"\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20".$mode
));(my $handler=
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x74\x64\x4f\x75\x74\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x63\x68\x65\x63\x6b\x20\x46\x44\x23"
.$stdout)."\x2e"));Common::NXSelector::addToGlobalSelector ($stdout,$description
,$handler);}elsif (($mode eq "\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){(my $description
=("\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20".
$mode));(my $handler=
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e\x3a\x3a\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x46\x44\x23"
.$stdout)."\x2e"));Common::NXSelector::addToGlobalSelector ($stdout,$description
,$handler);}if ((($pid ne (""))and ($pid>(0x09a7+ 2892-0x14f3)))){if (($mode ne 
"\x69\x6e\x73\x74\x61\x6c\x6c")){savePid ($pid);}else{
NXSoftwareUpdateDaemon::saveInstallPid ($pid);saveClientPid ($pid);}
Logger::debug (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20"
.$mode).
"\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
).$pid)."\x27\x2e"));if (($mode eq "\x63\x68\x65\x63\x6b")){
NXSoftwareUpdateDaemon::reportUpdateStartCheck ();
NXSoftwareUpdateDaemon::reportCheckInProgress ();}elsif (($mode eq 
"\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){
NXSoftwareUpdateDaemon::reportUpdateStartDownload ();}elsif (($mode eq 
"\x69\x6e\x73\x74\x61\x6c\x6c")){
NXSoftwareUpdateDaemon::reportUpdateStartInstall ();
NXSoftwareUpdateDaemon::reportInstallInProgress ();}}else{Logger::warning (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20"
.$mode).
"\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x27"
).$exit_value)."\x27\x2e"));if (($mode eq "\x63\x68\x65\x63\x6b")){
NXSoftwareUpdateDaemon::reportUpdateCheckFailed ($exit_value);}elsif (($mode eq 
"\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){
NXSoftwareUpdateDaemon::reportUpdateDownloadFailed ($exit_value);}elsif (($mode 
eq "\x69\x6e\x73\x74\x61\x6c\x6c")){
NXSoftwareUpdateDaemon::reportUpdateInstallFailed ($exit_value);}}return (
(0x1b73+ 1149-0x1ff0));}sub setPidForCheckUpdate{(my $pid=shift (@_));
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&handleCheckUpdateExit));return;}
sub setPidForDownloadUpdate{(my $pid=shift (@_));
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&handleDownloadUpdateExit));return
;}sub setPidForInstallUpdate{(my $pid=shift (@_));
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&handleInstallUpdateExit));return;
}sub __processCheckUpdateExit{if (($checkExitStatus eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x2e"
);return ((0x050c+ 6613-0x1ee1));}if (($checkStdOutBuffer eq (""))){
Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x73\x74\x64\x6f\x75\x74\x20\x62\x75\x66\x66\x65\x72\x2e"
);return ((0x0832+ 3627-0x165d));}__removePidFile ((0x1316+ 2860-0x1e41));
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x72\x6f\x63\x65\x73\x73\x20\x63\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x20\x62\x75\x66\x66\x65\x72\x20\x27"
.$checkStdOutBuffer)."\x27\x2e"));if (($checkStdOutBuffer=~ /Installation is up to date/ )
){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4e\x6f\x20\x75\x70\x64\x61\x74\x65\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"
);NXSoftwareUpdateDaemon::reportUpdateNotAvailable ();}elsif ((
$checkStdOutBuffer=~ /Update version (.*) available/ )){(my $version=$1);
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x27"
.$version)."\x27\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));if (
NXSoftwareUpdateDaemon::isForceCheck ()){
NXSoftwareUpdateDaemon::reportUpdateAvailable ($version);}else{
handleBackgroundUpdate ("\x64\x6f\x77\x6e\x6c\x6f\x61\x64");}}elsif ((
$checkStdOutBuffer=~ /Software update check failed, error is: (.*)./ )){(my $error
=$1);NXSoftwareUpdateDaemon::reportUpdateCheckFailed ($error);}elsif ((
$checkExitStatus!=(0x06da+ 4373-0x17ef))){
NXSoftwareUpdateDaemon::reportUpdateCheckFailed ($checkExitStatus);}else{
Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x63\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$checkStdOutBuffer)."\x27\x2e"));}($checkStdOutBuffer=undef);($checkExitStatus=
undef);return;}sub handleCheckUpdateExit{(my $pid=shift (@_));(my $code=shift (
@_));($checkExitStatus=$code);if ((($checkExitStatus==(0x0dc2+ 2770-0x1894))or (
$checkExitStatus==(0x04a4+ 8624-0x2555)))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
);}else{Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x27"
.$code)."\x27\x2e"));}__processCheckUpdateExit ();
NXSoftwareUpdateDaemon::resetUpdateMode ();}sub handleDownloadUpdateExit{(my $clientPid
=shift (@_));(my $exit_status=shift (@_));__removePidFile ((0x0667+ 3321-0x135f)
);NXSoftwareUpdateDaemon::resetUpdateMode ();if (($exit_status==
(0x03f8+ 4666-0x1632))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
);NXSoftwareUpdateDaemon::reportUpdateDownloadSuccessfully ();if ((
getLastAskForUpdate ()<=(0x0a65+ 2834-0x1577))){__handleAskForUpdate ();if ((
$pendingVersionInstallOnStartup>(0x08b0+ 505-0x0aa9))){(
$pendingVersionInstallOnStartup=(-(0x05d9+ 4254-0x1676)));}}}else{
Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x27"
.$exit_status)."\x27\x2e"));NXSoftwareUpdateDaemon::reportUpdateDownloadFailed (
$exit_status);}return;}sub handleInstallUpdateExit{(my $clientPid=shift (@_));(my $exit_status
=shift (@_));if (($exit_status==(0x0846+ 6122-0x2030))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x49\x6e\x73\x74\x61\x6c\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
);NXSoftwareUpdateDaemon::reportUpdateInstallFinished ($exit_status);}else{
Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x49\x6e\x73\x74\x61\x6c\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x27"
.$exit_status)."\x27\x2e"));NXSoftwareUpdateDaemon::reportUpdateInstallFailed (
$exit_status);}($NXUpdate::clientPid=(0x0421+ 301-0x054e));
NXSoftwareUpdateDaemon::resetUpdateMode ();
NXSoftwareUpdateDaemon::resetInstallPid ();__removePidFile (
(0x10bf+ 4985-0x2437));return;}sub checkIfReadyBackgroundUpdate{(my $serverMinorVersion
=(""));(my $serverPatchVersion=(""));if (($GLOBAL::SOFTWARE_MIN_VERSION=~ /(\d+)\.(\d+)/ )
){($serverMinorVersion=$1);($serverPatchVersion=$2);}(my $pendingVersion=
__getPendingVersion ());if ((($pendingVersion ne (""))and ($pendingVersion=~ /(\d+)\.(\d+)\.(\d+)/ )
)){(my $pendingMajorVersion=$1);(my $pendingMinorVersion=$2);(my $pendingPatchVersion
=$3);if (((($pendingMajorVersion>$GLOBAL::SOFTWARE_MAJ_VERSION)or ((
$pendingMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)and ($pendingMinorVersion>
$serverMinorVersion)))or ((($pendingMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)
and ($pendingMinorVersion>=$serverMinorVersion))and ($pendingPatchVersion>
$serverPatchVersion)))){Logger::debug (
"\x55\x70\x64\x61\x74\x65\x73\x20\x61\x72\x65\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x74\x6f\x20\x62\x65\x20\x69\x6e\x73\x74\x61\x6c\x6c\x65\x64\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x2e"
);if ((isAutomaticInstallEnabled ()==(0x01df+ 2086-0x0a05))){(my $sessionID=
__getPhysicalSession ());($pendingVersionInstallOnStartup=(0x1363+ 1235-0x1835))
;setLastCheck ();checkIfAskForInstallUpdate ($sessionID);undef ($sessionID);}
else{handleBackgroundUpdate ("\x69\x6e\x73\x74\x61\x6c\x6c");}}else{
Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x73\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x2c\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x2e"
);__deletePendingVersion ();}}return;}sub checkIgnoreVersion{(my $serverMinorVersion
=(""));(my $serverPatchVersion=(""));if (($GLOBAL::SOFTWARE_MIN_VERSION=~ /(\d+)\.(\d+)/ )
){($serverMinorVersion=$1);($serverPatchVersion=$2);}(my $ignoreVersion=
__getIgnoreVersion ());if ((($ignoreVersion ne (""))and ($ignoreVersion=~ /(\d+)\.(\d+)\.(\d+)/ )
)){(my $ignoreMajorVersion=$1);(my $ignoreMinorVersion=$2);(my $ignorePatchVersion
=$3);if (((($ignoreMajorVersion>$GLOBAL::SOFTWARE_MAJ_VERSION)or ((
$ignoreMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)and ($ignoreMinorVersion>
$serverMinorVersion)))or ((($ignoreMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)
and ($ignoreMinorVersion>=$serverMinorVersion))and ($ignorePatchVersion>
$serverPatchVersion)))){Logger::debug2 (((
"\x49\x6e\x69\x74\x61\x6c\x69\x7a\x65\x64\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x77\x69\x74\x68\x3a\x20"
.$ignoreVersion)."\x2e"));($NXUpdate::ignoreVersion=$ignoreVersion);}elsif ((
$ignoreVersion ne (""))){Logger::debug2 (
"\x52\x65\x6d\x6f\x76\x65\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x61\x62\x6f\x75\x74\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);__deleteIgnoreVersion ();}}return;}sub isUpdateEnabled{if ((getUpdateFrequency
 ()>(0x058d+ 5268-0x1a21))){if (($updateMode==(-(0x022a+ 8442-0x2323)))){
__getUpdateMode ();}if ((($updateMode==$SilentUpdateMode)or ($updateMode==
$BackgroundUpdateMode))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x6d\x6f\x64\x65\x20\x27"
.$updateMode)."\x27\x2e"));return ((0x0720+ 1878-0x0e75));}}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x147f+ 3481-0x2218));}sub isBackgroundMode{if (($updateMode==(-
(0x0c23+ 2726-0x16c8)))){__getUpdateMode ();}if (($updateMode==
$BackgroundUpdateMode)){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x27\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x2e"
);return ((0x0355+ 3094-0x0f6a));}return ((0x0cfc+ 2239-0x15bb));}sub 
__isSilentMode{if (($updateMode==(-(0x0502+ 177-0x05b2)))){__getUpdateMode ();}
if (($updateMode==$SilentUpdateMode)){return ((0x01e4+ 4171-0x122e));}return (
(0x0574+ 2252-0x0e40));}sub setUpdateMode{(my $mode=shift (@_));if (
isCorrectUpdateMode ($mode)){($updateMode=$mode);Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x76\x61\x6c\x75\x65\x20\x27"
.$updateMode)."\x27\x2e"));}else{($updateMode=NXLicense::getUpdateMode ());
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x27"
.$updateMode)."\x27\x2e"));}if ((not (Common::NXFile::isExists (
getUpdateFilePath ())))){(my $content=__tryToGetUpdateFileContentFromMemory ());
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x73\x65\x74\x55\x70\x64\x61\x74\x65\x4d\x6f\x64\x65\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2c\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x69\x74\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$content)."\x2e"));saveInfoToFile ($content);return ((0x04b1+ 4721-0x1722));}
else{return (__updateFile ());}}sub __getUpdateMode{if ((not (
Common::NXFile::isExists (getUpdateFilePath ())))){($updateMode=
NXLicense::getUpdateMode ());return ((0x11ac+ 5376-0x26ac));}(my $mode=
__getInformationFromUpdateFile ($updateModeIndex));if (isCorrectUpdateMode (
$mode)){($updateMode=$mode);return ($updateMode);}($updateMode=
NXLicense::getUpdateMode ());return ($updateMode);}sub isAutomaticInstallEnabled
{if (($automaticInstall==(-(0x0a16+ 4184-0x1a6d)))){__getAutomaticInstall ();}if
 (($automaticInstall==(0x128b+ 3134-0x1ec8))){return ((0x23da+ 254-0x24d7));}
return ((0x09bd+ 5555-0x1f70));}sub __getAutomaticInstall{if ((not (
Common::NXFile::isExists (getUpdateFilePath ())))){($automaticInstall=
(0x0dd9+ 2872-0x1911));return ((0x1bf5+ 2398-0x2553));}(my $value=
__getInformationFromUpdateFile ($automtaicInstallIndex));if (($value ne (""))){
if (($value=~ /^[0,1]$/ )){($automaticInstall=$value);return ($automaticInstall)
;}}($automaticInstall=(0x0aea+ 2640-0x153a));return ($automaticInstall);}sub 
killUpdateIfPidFileExists{__setPidFilePath ();(my $filename=__getPidFilePath ())
;if ((not (Common::NXFile::isExists ($filename)))){return;}killUpdate ();return;
}sub killUpdate{main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);if (((isUpdateEnabled ()==(0x1f55+  64-0x1f95))and (
NXSoftwareUpdateDaemon::isWorking ()==(0x07d6+ 7988-0x270a)))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x6b\x69\x70\x20\x6b\x69\x6c\x6c\x20\x66\x6f\x72\x20\x6e\x6f\x74\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x2e"
);return ((0x0ee0+ 3427-0x1c43));}__readPid ();(my $updatePid=$updatePid);if (
NXSoftwareUpdateDaemon::isForceInstall ()){($updatePid=
NXSoftwareUpdateDaemon::getInstallPid ());}if (($updatePid==(0x211c+  16-0x212c)
)){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x6b\x69\x70\x20\x6b\x69\x6c\x6c\x20\x66\x6f\x72\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x50\x49\x44\x2e"
);NXSoftwareUpdateDaemon::reportUpdateCancelledFailed ();return (
(0x18a4+ 3521-0x2665));}Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$updatePid)."\x27\x2e"));NXSoftwareUpdateDaemon::reportUpdateCancelled ();if (
Common::NXProcess::isProcessRunning ($updatePid)){if ((
Common::NXProcess::sigkill ($updatePid)==(0x1945+ 2518-0x231b))){Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x2e"
);}}NXSoftwareUpdateDaemon::resetInstallPid ();__removePidFile (
(0x080a+ 5043-0x1bbc));}sub runNXPostUpdate{(my $nxexecCommand=
NXTools::getNXExecCommand ());if ((not (-x ($nxexecCommand)))){Logger::debug (((
"\x6e\x6f\x20".$nxexecCommand)."\x20\x66\x69\x6c\x65"));return;}if ((not (
Common::NXFile::isExists ($GLOBAL::SCRIPT_NXPOSTUPDATE)))){Logger::debug (((
"\x6e\x6f\x20\x5b".$GLOBAL::SCRIPT_NXPOSTUPDATE)."\x5d\x20\x66\x69\x6c\x65"));
return;}my (@command,@parameters);push (@parameters,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");if (Common::NXInfo::isArchitecture64Bit 
()){push (@command,
"\x43\x3a\x5c\x57\x69\x6e\x64\x6f\x77\x73\x5c\x53\x79\x73\x6e\x61\x74\x69\x76\x65\x5c\x63\x6d\x64\x2e\x65\x78\x65"
);}else{push (@command,"\x63\x6d\x64\x2e\x65\x78\x65");}push (@command,
"\x2f\x43");push (@command,(("\x22".$GLOBAL::SCRIPT_NXPOSTUPDATE)."\x22"));(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));}
sub shutdown{if ((isUpdateEnabled ()==(0x0c90+ 2613-0x16c5))){return (
(0x2613+ 139-0x269e));}if ((($updatePid>(0x125f+ 1755-0x193a))and 
Common::NXProcess::isProcessRunning ($updatePid))){killClient ($updatePid);
__removePidFile ((0x1f79+ 1022-0x2376));}}sub killClient{(my $clientPid=shift (
@_));if (Common::NXProcess::sigkill ($clientPid)){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x6b\x69\x6c\x6c\x65\x64\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$clientPid)."\x2e"));}else{Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$clientPid)."\x2e"));}}sub readInfoFromFileFD{(my $FH=shift (@_));(my $initialize
=(shift (@_)||(0x06bd+ 3047-0x12a4)));(my $info=(""));(my $readBytes=
(0x0cec+ 4442-0x1e46));if (((not (defined ($FH)))or ($FH<=(0x001b+ 4089-0x1014))
)){(my $error=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::debug (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x46\x44\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$infoType)."\x20\x66\x69\x6c\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").
$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));(my $content=
__tryToGetUpdateFileContentFromMemory ());Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x46\x44\x3a\x20\x55\x73\x65\x20\x76\x61\x6c\x75\x65\x73\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x3a\x20"
.$content)."\x2e"));return ((-(0x038d+ 2007-0x0b63)),$content);}else{($readBytes
=main::nxread ($FH,(\$info),$readSize));chomp ($info);}Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x46\x44\x3a\x20\x52\x65\x61\x64\x20"
.$readBytes)."\x20\x62\x79\x74\x65\x73\x3a\x20").$info)."\x2e"));(my $validatedContent
=validateUpdateFileContent ($info,$initialize));return ($readBytes,
$validatedContent);}sub readInfoFromFile{(my $initialize=(shift (@_)||
(0x1484+ 800-0x17a4)));(my $updateFile=getUpdateFilePath ());(my $FH=
main::nxopen ($updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),
$UpdateFilePermissions));if (((not (defined ($FH)))or ($FH<=
(0x1813+ 2159-0x2082)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((-
(0x0780+ 4737-0x1a00)));}if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x01c1+ 4106-0x11c8)));if (((not (
defined ($ret)))or ($ret<=(0x13d9+ 4132-0x23fd)))){(my $error=libnxh::NXGetError
 ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH).
"\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));(my $content
=__tryToGetUpdateFileContentFromMemory ());Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x3a\x20\x55\x73\x65\x20\x76\x61\x6c\x75\x65\x73\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x3a\x20"
.$content)."\x2e"));main::nxclose ($FH);return ($content);}else{my ($lineRead);
main::nxread ($FH,(\$lineRead),$readSize);(my $info=$lineRead);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=libnxh::NXFileUnlock 
($FH));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));main::nxclose ($FH);if ((not (defined ($info)))){($info=
(""));}else{chomp ($info);}(my $validatedContent=validateUpdateFileContent (
$info,$initialize));return ($validatedContent);}}sub saveInfoToFile{(my $info=
shift (@_));(my $FH=(shift (@_)||(0x0586+ 2863-0x10b5)));(my $readBytes=(shift (
@_)||(0x0950+ 1718-0x1006)));(my $unlock=(0x0103+ 5244-0x157f));(my $updateFile=
getUpdateFilePath ());if (((not (defined ($FH)))or ($FH<=(0x0e3c+ 3438-0x1baa)))
){($FH=main::nxopen ($updateFile,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+
$NXBits::O_TRUNC),$UpdateFilePermissions));if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}}else{($unlock=
(0x143b+ 175-0x14e9));}if ((not (defined ($FH)))){(my $error=libnxh::NXGetError 
());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile).
"\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),
(0x0a7f+ 5747-0x20f2));return ((0x1838+ 651-0x1ac2));}if (($unlock==
(0x0d77+ 2904-0x18ce))){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x42\x65\x67\x69\x6e\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $ret=libnxh::NXFileBegin ($FH));
Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x42\x65\x67\x69\x6e\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$ret)."\x2e"));}(my $data=$info);if (((($unlock==(0x01f8+ 3412-0x0f4b))and (
$readBytes>(0x17e1+ 2533-0x21c6)))and ($readBytes>length ($info)))){(my $fill=(
"\x00" x ($readSize-length ($info))));($data.=$fill);}if ((main::nxwrite ($FH,
$data)==(-(0x0162+ 8985-0x247a)))){(my $error=libnxh::NXGetError ());(my $errorname
=libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),(0x22d7+ 230-0x23bd));
if (($unlock==(0x044f+ 4048-0x141e))){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=libnxh::NXFileUnlock 
($FH));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));}main::nxclose ($FH);return ((0x03eb+ 4116-0x13fe));}if ((
$unlock==(0x1663+  43-0x168d))){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=libnxh::NXFileUnlock 
($FH));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));}main::nxclose ($FH);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x53\x61\x76\x65\x64\x20\x27"
.$info)."\x27\x20\x69\x6e\x20\x27").$updateFile)."\x27\x2e"));return (
(0x0693+ 613-0x08f8));}sub sendMessageToServerStartup{(my $ignore=shift (@_));(my $serverMonitorPid
=NXClientSystemDaemons::getServerDaemonPid ());if (($serverMonitorPid==(-
(0x02bd+ 5391-0x17cb)))){return (undef);}if (($serverMonitorPid==$ $)) {
 return
 ((-(0x06d6+ 2100-0x0f09)));}(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPDATE_IGNORE_TO_SERVER_STARTUP_MONITOR)."\x20").$ignore)."\x0a"));my (
$response);if (NXClientSystemDaemons::openConnection ()){if (
NXClientSystemDaemons::sendMessage ($message)){($response=
NXClientSystemDaemons::parseMessageFromServer ((0x1c0c+  45-0x1c34)));}else{
return (undef);}NXClientSystemDaemons::closeConnection ();}else{return (undef);}
Logger::debug2 (((
"\x48\x61\x6e\x64\x6c\x65\x72\x20\x75\x70\x64\x61\x74\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3a\x20\x27"
.$response)."\x27\x2e"));return ($response);}sub __saveIgnoreVersion{(my $ignore
=shift (@_));(my $updateFile=getUpdateFilePath ());(my $FH=main::nxopen (
$updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),$UpdateFilePermissions));if (((
not (defined ($FH)))or ($FH<=(0x14b7+ 1210-0x1971)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x6c\x6f\x63\x6b\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((-
(0x0499+ 2150-0x0cfe)));}if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x01ab+ 7153-0x1d99)));if (((not (
defined ($ret)))or ($ret<=(0x01ed+ 7998-0x212b)))){Logger::warning (((
"\x5f\x5f\x73\x61\x76\x65\x49\x67\x6e\x6f\x72\x65\x56\x65\x72\x73\x69\x6f\x6e\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return;}(my ($readBytes,$validatedContent)=readInfoFromFileFD ($FH,
(0x0df5+ 6068-0x25a9)));(my (@con)=split ( /:/ ,$validatedContent,
(0x0869+ 4620-0x1a75)));($ignoreVersion=$ignore);(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile ($newContent
,$FH,$readBytes);}sub setUpdateIgnoreMessage{(my $ignore=shift (@_));
Logger::debug2 (((
"\x53\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x74\x6f\x3a\x20"
.$ignore)."\x2e"));($ignoreVersion=$ignore);return;}sub handeUpdateIgnoreMessage
{(my $ignore=shift (@_));__saveIgnoreVersion ($ignore);
sendMessageToServerStartup ($ignore);return;}sub isCorrectUpdateMode{(my $mode=
shift (@_));if (((not (defined ($mode)))or ($mode eq ("")))){return (
(0x0183+ 2010-0x095d));}if (($mode=~ /^[0,1,2]$/ )){return (
(0x16b5+ 1075-0x1ae7));}return ((0x1aeb+ 2350-0x2419));}sub 
handleMessageUpdateRemovePid{(my $line=shift (@_));(my $pid=(""));(my $isEAGAIN=
(0x0807+ 7422-0x2505));if (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_REMOVE_PID pid=(.*) eagain=(.*)$//g )
){($pid=main::urldecode ($1));($isEAGAIN=main::urldecode ($2));}elsif (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_REMOVE_PID pid=(.*)$//g )
){($pid=main::urldecode ($1));}else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2e"
);return ((0x10d3+ 3167-0x1d31));}if ((($pid ne (""))and ($pid>
(0x0792+ 5515-0x1d1d)))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x65\x72\x76\x65\x72\x20\x67\x6f\x74\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));handleClientUpdateExit ($isEAGAIN);return ((0x08cd+ 6833-0x237e)
);}else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2c\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x69\x64\x2e"
);return ((0x0ff8+ 5910-0x270d));}}sub handleMessageUpdatePid{(my $line=shift (
@_));(my $socket=shift (@_));my ($pid);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x6c\x69\x6e\x65\x20\x3d\x20\x5b".$line
)."\x5d\x20\x73\x6f\x63\x6b\x65\x74\x20\x5b").$socket)."\x5d\x2e"));if (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_PID (.*)$//g )
){($pid=main::urldecode ($1));}else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2e"
);return ((0x0874+ 113-0x08e4));}(my $sessionID=
NXLocalSession::getSessionIdByNodeSocket ($socket));if (((not (defined (
$sessionID)))or ($sessionID eq ("")))){Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x2e"
);return ((0x1baa+ 2285-0x2496));}if ((($pid ne (""))and ($pid>
(0x0926+ 1713-0x0fd7)))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x65\x72\x76\x65\x72\x20\x67\x6f\x74\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));saveClientPid ($pid,$sessionID);return ((0x001d+ 4437-0x1172));}
else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2c\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x69\x64\x2e"
);return ((0x0f28+ 2800-0x1a17));}}sub handleUpdateCommand{Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x45\x78\x65\x63\x75\x74\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x73\x63\x72\x69\x70\x74\x2e"
);(my $CommandSetup=(((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x74\x75\x70"
).$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));(my (@command)=
());(@command=($GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",
main::shell_quote ($CommandSetup,"\x2d\x2d\x75\x70\x64\x61\x74\x65")));(my (
@options)=());(my $error=main::nxExecCommand ((\@command),(\@options)));if ((
$error ne (""))){Logger::warning ((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x75\x70\x64\x61\x74\x65\x20\x73\x63\x72\x69\x70\x74\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$error));Common::NXMsg::send_response (
"\x65\x47\x55\x49\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x4f\x66\x43\x6f\x6d\x6d\x61\x6e\x64\x46\x61\x69\x6c\x65\x64"
,$CommandSetup,$error);}}sub __updateFile{(my $file=getUpdateFilePath ());(my $FH
=main::nxopen ($file,($NXBits::O_RDWR+$NXBits::O_CREAT),$UpdateFilePermissions))
;if (((not (defined ($FH)))or ($FH<=(0x0903+ 4782-0x1bb1)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".$file
)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error)."\x2c\x20").
$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((0x05ea+ 4123-0x1604));}
if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x136c+ 242-0x145b)));if (((not (
defined ($ret)))or ($ret<=(0x1252+ 1142-0x16c8)))){Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x75\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return ((0x1717+ 2193-0x1fa7));}(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());return (saveInfoToFile (
$newContent,$FH,$readBytes));}sub stdOutCallback{(my $fd=shift (@_));(my $bytes=
main::nxread ($fd,(\$checkStdOutBuffer),65536));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$checkStdOutBuffer)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e"));(
$checkStdOutBuffer.="\x0a");Common::NXSelector::removeFromGlobalSelector ($fd);
main::nxclose ($fd);__processCheckUpdateExit ();}return ((0x0dd5+ 1855-0x1513));
