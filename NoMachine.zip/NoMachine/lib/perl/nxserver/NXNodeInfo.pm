############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->import}
;}package NXNodeInfo;no warnings;(my (%info)=());sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub getNodeInfoDirPath{(my $nodeInfoDirPath
=(((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x6f\x64\x65"));return ($nodeInfoDirPath);}sub 
getInfoFile{(my $fileName=shift (@_));(my $infoFile=((getNodeInfoDirPath ().
$GLOBAL::DIRECTORY_SLASH).$fileName));return ($infoFile);}sub saveInfoToFile{(my $infoType
=shift (@_));(my $info=shift (@_));(my $truncate=(shift (@_)||
(0x04cd+ 7597-0x227a)));(my $infoFile=getInfoFile ($infoType));(my $FH=(""));if 
(($truncate==(0x11d5+ 3925-0x212a))){($FH=main::nxopen ($infoFile,(
$NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead)
+$NXBits::OthersRead)));}else{($FH=main::nxopen ($infoFile,(($NXBits::O_WRONLY+
$NXBits::O_CREAT)+$NXBits::O_TRUNC),(($NXBits::UserReadWrite+$NXBits::GroupRead)
+$NXBits::OthersRead)));}if ((not (defined ($FH)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$infoFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring));return ((0x0e29+ 467-0x0ffb));}if ((main::nxwrite (
$FH,($info."\x0a"))==(-(0x00ac+ 1436-0x0647)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
main::nxclose ($FH);Logger::error (((
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$infoFile)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));return ((0x1428+ 3339-0x2132));}main::nxclose ($FH);
Logger::debug (((((
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x53\x61\x76\x65\x64\x20\x27"
.$info)."\x27\x20\x69\x6e\x20\x27").$infoFile)."\x27\x2e"));return (
(0x1918+ 1103-0x1d67));}sub clearInfoFromMemory{(my $infoType=shift (@_));undef 
($NXNodeInfo::info{$infoType});}sub readInfoFromFile{(my $infoType=shift (@_));
if (defined ($NXNodeInfo::info{$infoType})){return ($NXNodeInfo::info{$infoType}
);}(my $infoFile=getInfoFile ($infoType));(my $info=(0x1d00+ 2007-0x24d7));(my $FH
=main::nxopen ($infoFile,$NXBits::O_RDONLY,(0x1598+ 3616-0x23b8)));if ((not (
defined ($FH)))){($NXNodeInfo::info{$infoType}=(""));(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::debug2 (((
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$infoType)."\x20\x66\x69\x6c\x65\x2e"));Logger::debug2 ((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring));}else{my ($lineRead);main::nxreadLine ($FH,(\$lineRead));if ((
$infoType eq "\x63\x70\x75\x69\x6e\x66\x6f")){($info+=$lineRead);}else{($info=
$lineRead);}main::nxclose ($FH);chomp ($info);}($NXNodeInfo::info{$infoType}=
$info);return ($info);}sub getServerIp{Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x20\x73\x74\x61\x72\x74\x2e\x20"
);(my $networkInterfaces=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20"
.$networkInterfaces)."\x2e"));if (($networkInterfaces ne (""))){(my $Ipv4=
__getServerIpv4 ($networkInterfaces));(my $Ipv6=__getServerIpv6 (
$networkInterfaces));(my $ip.=(($Ipv4."\x2c").$Ipv6));Logger::debug (((
"\x52\x65\x74\x72\x69\x65\x76\x65\x64\x20\x73\x65\x72\x76\x65\x72\x20\x69\x70\x3a\x20"
.$ip)."\x2e"));return ($ip);}else{Logger::debug (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x73\x65\x72\x76\x65\x72\x20\x69\x70\x2e"
);}return ((""));}sub __getServerIpv4{(my $networkInterfaces=shift (@_));(my $ip
=(""));(my (@lines)=split ( /\n/ ,$networkInterfaces,(0x19e2+ 526-0x1bf0)));
foreach my $line (@lines){if (($line=~ /INET\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(\d+\.\d+\.\d+\.\d+)/ )
){if ((not (($3=~ /^127/ )))){($ip.=($3."\x2c"));}}}if (($ip=~ /,$/ )){chop ($ip
);}Logger::debug (((
"\x52\x65\x74\x72\x69\x65\x76\x65\x64\x20\x73\x65\x72\x76\x65\x72\x20\x69\x70\x76\x34\x3a\x20"
.$ip)."\x2e"));return ($ip);}sub __getServerIpv6{(my $networkInterfaces=shift (
@_));(my $ip=(""));(my (@lines)=split ( /\n/ ,$networkInterfaces,
(0x08a1+ 3203-0x1524)));foreach my $line (@lines){if (($line=~ /INET6\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(.*)\s+/ )
){(my (@wart)=split ("\x20",$line,(0x1e62+ 1043-0x2275)));(my (@war)=split ( /%/ ,
$wart[(0x0083+ 3488-0x0e20)],(0x0798+ 2419-0x110b)));if ((($war[
(0x1653+ 2834-0x2165)]ne "\x3a\x3a\x31")and ($war[(0x1968+ 1906-0x20da)]ne 
"\x66\x65\x38\x30\x3a\x3a\x31"))){($ip.=($war[(0x0549+ 5535-0x1ae8)]."\x2c"));}}
}if (($ip=~ /,$/ )){chop ($ip);}Logger::debug (((
"\x52\x65\x74\x72\x69\x65\x76\x65\x64\x20\x73\x65\x72\x76\x65\x72\x20\x69\x70\x76\x36\x3a\x20"
.$ip)."\x2e"));return ($ip);}sub getServerType{return ($GLOBAL::PRODUCT_NAME);}
sub getNxdPortIfEnabled{if (NXSystemDaemons::isNxdEnabled ()){return (getNxdPort
 ());}return ((""));}sub getNxdPort{main::nxrequire (
"\x4e\x58\x54\x6f\x6f\x6c\x73");if (NXTools::isCorrectPort ($GLOBAL::NXPort)){
return ($GLOBAL::NXPort);}return ($GLOBAL::NXTCPPort);}sub getNxdUDPPort{return 
($GLOBAL::NXUDPPort);}sub getSshdPort{if (NXSystemDaemons::isSSHEnabled ()){
return ($GLOBAL::SSHPort);}return ((""));}sub getHttpsPort{if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){(my $port=
NXTools::getNXHtdPort ());Logger::debug (((
"\x52\x65\x74\x72\x69\x65\x76\x65\x64\x20\x6e\x78\x68\x74\x64\x20\x70\x6f\x72\x74\x3a\x20\x27"
.$port)."\x27\x2e"));return ($port);}return ((""));}sub getPlatform{if ((defined
 ($platform)and ($platform ne ("")))){return ($platform);}__setPlatform ();
return ($platform);}sub __setPlatform{(my $platform=__getPlatform ());if ((
$platform ne (""))){($NXNodeInfo::platform=$platform);}else{(
$NXNodeInfo::platform="\x75\x6e\x6b\x6e\x6f\x77\x6e");}}sub __getPlatform{return
 ("\x77\x69\x6e\x64\x6f\x77\x73");(my $platform=lc (
Common::NXInfo::getDistroInfo ()));if (($platform eq (""))){($platform=
"\x6c\x69\x6e\x75\x78");}return ($platform);}return ((0x0d08+ 5231-0x2176));
