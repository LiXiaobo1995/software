############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXAnywhereRedis;no warnings;(my $__accessKeyName=
"\x61\x63\x63\x65\x73\x73\x4b\x65\x79");(my $__machineidName=
"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64");(my $__accessCookieName=
"\x61\x63\x63\x65\x73\x73\x43\x6f\x6f\x6b\x69\x65");(my $__allowedName=
"\x61\x6c\x6c\x6f\x77\x65\x64");sub getAllowed{(my $value=__getKey (
$__allowedName));return (main::urldecode ($value));}sub getAccessCookie{return (
__getKey ($__accessCookieName));}sub getAccessKey{return (__getKey (
$__accessKeyName));}sub getMachineId{return (__getKey ($__machineidName));}sub 
setAllowed{(my $value=(shift (@_)||"\x20"));return (__addKey ($__allowedName,
main::urlencode ($value)));}sub setAccessCookie{(my $value=(shift (@_)||"\x20"))
;return (__addKey ($__accessCookieName,$value));}sub setAccessKey{(my $value=(
shift (@_)||"\x20"));return (__addKey ($__accessKeyName,$value));}sub 
setMachineId{(my $value=(shift (@_)||"\x20"));return (__addKey ($__machineidName
,$value));}sub delAllowed{return (__delKey ($__allowedName));}sub 
delAccessCookie{return (__delKey ($__accessCookieName));}sub delAccessKey{return
 (__delKey ($__accessKeyName));}sub delMachineId{return (__delKey (
$__machineidName));}sub __getKey{(my $key=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x4e\x4d\x4e\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x0a"));return (NXRedis::get ());}sub __addKey{(my $key=shift (@_));(my $value
=shift (@_));return (NXRedis::sendToDb (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x4e\x4d\x4e\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x2c\x76\x61\x6c\x75\x65\x3d").$value)."\x0a")));}sub __delKey{(my $key=
shift (@_));return (NXRedis::sendToDb (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x4e\x4d\x4e\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x2c\x66\x69\x65\x6c\x64\x3d").$key)."\x0a")));}"\x3f\x3f\x3f";
