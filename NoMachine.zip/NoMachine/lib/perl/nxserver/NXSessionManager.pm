############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSessionManager::BEGIN{package NXSessionManager;no warnings;require 
NXSession2;do{"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32"->import};}package 
NXSessionManager;no warnings;($sessionCloseStarted=(0x0852+ 984-0x0c2a));sub 
listConnectedSessions{(my (@param)=@_);($sessionId=$param[(0x0df8+ 4388-0x1f1b)]
);($sessionId=~ s/^.*=// );if (($sessionId=~ /(\w{32})$/ )){if ((not (
NXSession2::existSession ($sessionId)))){NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);return ((0x00c8+ 2712-0x0b60));}(my (
@connectedSessions)=NXSession2::listConnectedSessions ($sessionId));
main::nxwrite (main::nxgetSTDOUT (),
"\x0a\x53\x65\x73\x73\x69\x6f\x6e\x73\x49\x64\x0a");main::nxwrite (
main::nxgetSTDOUT (),(("\x2d" x (0x17ac+ 3669-0x25e1))."\x0a"));my ($sessionId);
foreach my $sessionId (@connectedSessions){($sessionId=sprintf (
"\x25\x2d\x33\x32\x73",$sessionId));main::nxwrite (main::nxgetSTDOUT (),(
$sessionId."\x0a"));}Logger::debug (
"\x52\x65\x70\x6f\x72\x74\x65\x64\x20\x64\x61\x74\x61\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);main::nxwrite (main::nxgetSTDOUT (),"\x0a");return ((0x160b+ 1881-0x1d63));}
else{if (($sessionId eq (""))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x6c\x65\x63\x74\x53\x65\x73\x73\x69\x6f\x6e\x4d\x69\x73\x73\x69\x6e\x67\x41\x72\x67"
,"\x6d\x61\x69\x6e");}else{NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);}}return ((0x1c1b+ 515-0x1e1e));}sub 
listConnectedSessionUsers{(my (@param)=@_);(my $message=(""));if ((
Server::isClientNxwebclient ()or Server::isClientNxclient ())){($sessionId=
$param[(0x0c3a+ 3799-0x1b11)]);}else{($sessionId=$param[(0x02f2+ 8756-0x2525)]);
}($sessionId=~ s/^.*=// );if (($sessionId=~ /(\w{32})$/ )){if ((not (
NXSession2::existSession ($sessionId)))){NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);return ((0x1320+ 1902-0x1a8e));}(my (
@connectedSessions)=NXSession2::listConnectedSessions ($sessionId));
main::nxwrite (main::nxgetSTDOUT (),
"\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a"
);main::nxwrite (main::nxgetSTDOUT (),(((("\x2d" x (0x22cf+ 379-0x2429))."\x20")
.("\x2d" x (0x0a05+ 6994-0x2537)))."\x0a"));foreach my $session (
@connectedSessions){($session=sprintf ("\x25\x2d\x33\x32\x73",$session));(my $username
=NXSession2::getUsernameBySessionId ($session));($username=sprintf (
"\x25\x2d\x33\x33\x73",$username));($message=((($username."\x20").$session).
"\x0a"));main::nxwrite (main::nxgetSTDOUT (),$message);}if ((
Server::isClientNxwebclient ()or Server::isClientNxclient ())){Logger::debug (((
"\x52\x65\x70\x6f\x72\x74\x65\x64\x20\x64\x61\x74\x61\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x5b"
.$message)."\x5d\x2e"));}}else{if (($sessionId eq (""))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x6c\x65\x63\x74\x53\x65\x73\x73\x69\x6f\x6e\x4d\x69\x73\x73\x69\x6e\x67\x41\x72\x67"
,"\x6d\x61\x69\x6e");}else{NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);}}return ((0x0c6f+ 468-0x0e43));}sub 
considerSessionReconnect{if (((Common::NXSessionType::isVirtualAttach (
NXSessionParameters::getSessionType ())and NXSessionParameters::isReconnectable 
())and NXSessionParameters::isRestoreSession ())){return ((0x0726+ 3902-0x1663))
;}else{return ((0x0c53+ 2258-0x1525));}}sub considerBeforeSessionDisconnect{if (
(Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ())and (
not (Server::isMasterGoingToShutdown ())))){NXEvent::beforeSessionDisconnect ();
}}sub considerAfterSessionDisconnect{if ((Common::NXSessionType::isVirtual (
NXSessionParameters::getSessionType ())and (not (Server::isMasterGoingToShutdown
 ())))){NXEvent::afterSessionDisconnect ();}}sub considerBeforeSessionStart{if (
(NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::beforeSessionStart ();}}sub 
considerBeforeSessionClose{if ((((isNotSessionCloseStarted ()and 
NXSessionParameters::getSessionType ())and Common::NXSessionType::isVirtual (
NXSessionParameters::getSessionType ()))or Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::beforeSessionClose ();}}}sub
 considerAfterSessionClose{if (((NXSessionParameters::getSessionType ()and 
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()))or 
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::afterSessionClose ();}}}sub 
considerBeforeSessionFailure{if (((NXSessionParameters::getSessionType ()and 
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()))or 
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::beforeSessionFailure ();}}}
sub considerAfterSessionFailure{if (((NXSessionParameters::getSessionType ()and 
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()))or 
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::afterSessionFailure ();}}}
sub setSessionCloseStarted{($NXSession::sessionCloseStarted=(0x25b3+  87-0x2609)
);}sub isSessionCloseStarted{return ($NXSession::sessionCloseStarted);}sub 
isNotSessionCloseStarted{return ((!isSessionCloseStarted ()));}return (
(0x1c83+ 1274-0x217c));
