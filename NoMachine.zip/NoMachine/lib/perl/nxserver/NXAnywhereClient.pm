############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXAnywhereClient;no warnings;%connections;($commandBuffer=(""));sub 
sendAddMachinesCommand{(my $connectionId=shift (@_));if ((not (defined (
$connectionId)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x65\x77\x20".
Server::getAnywhereName ())."\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"))
;}else{(my $command=__getAddMachinesCommand ());if (__sendCommandOnId (
$connectionId,$command)){closeAnywhereConnection ($connectionId);return (undef);
}return ($connectionId);}return (undef);}sub sendRegisterMachinesCommand{(my $connectionId
=shift (@_));if ((not (defined ($connectionId)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x65\x77\x20".
Server::getAnywhereName ())."\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"))
;}else{(my $command=__getRegisterCommand ());if (__sendCommandOnId (
$connectionId,$command)){closeAnywhereConnection ($connectionId);return (undef);
}return ($connectionId);}return (undef);}sub createAnonymousConnection{(my $connectionId
=__createAnywhereConnection ());if ((not (defined ($connectionId)))){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x65\x77\x20".
Server::getAnywhereName ()).((((
"\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27".$connectionId).
"\x27\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27").$username)."\x27\x2e")));}
else{(my $loginCommand=__getAnonymousLoginCommand ());if (__sendCommandOnId (
$connectionId,$loginCommand)){closeAnywhereConnection ($connectionId);return (
undef);}return ($connectionId);}return (undef);}sub 
createConnectionAndRegularLogin{main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $allowed=
NXAnywhereRedis::getAllowed ());if ((not (defined ($allowed)))){Logger::warning 
((("\x41\x6c\x6c\x6f\x77\x65\x64\x20\x66\x6f\x72\x20".Server::getAnywhereName ()
).
"\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x69\x73\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e"
));return (undef);}(my $connectionId=__createAnywhereConnection ());if ((not (
defined ($connectionId)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x65\x77\x20".
Server::getAnywhereName ())."\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"))
;}else{(my $loginCommand=__getLoginCommandLine ($allowed));if (($loginCommand eq
 (""))){return (undef);}if (__sendCommandOnId ($connectionId,$loginCommand)){
closeAnywhereConnection ($connectionId);return (undef);}return ($connectionId);}
return (undef);}sub readToBuffer{(my $fd=shift (@_));my ($message);(my $read=
main::nxread ($fd,(\$message),4096));if (((not (defined ($read)))or ($read==
(0x04e8+ 270-0x05f6)))){__handleConnectionClose ($fd);return (
(0x11c5+ 3037-0x1da2));}(my $logMessage=$message);($logMessage=~ s/[\x1a\x1b]/./g )
;Logger::debug ((Server::getAnywhereName ().((((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x52\x65\x61\x64\x20\x27".$logMessage).
"\x27\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").$fd)."\x2e")));($commandBuffer.=
$message);return ((0x03c6+ 2294-0x0cbb));}sub getCommandResponse{(my $commandLine_ref
=shift (@_));Logger::debug3 ((Server::getAnywhereName ().((
"\x20\x42\x75\x66\x66\x65\x72\x20\x27".$commandBuffer)."\x27\x2e")));if ((
$commandBuffer=~ /^(.*?)\n(.*)$/s )){((%$commandLine_ref)=parseLine ($1));if ((
$$commandLine_ref{"\x73\x69\x7a\x65"}>length ($2))){Logger::debug ((
Server::getAnywhereName ().
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x4e\x6f\x74\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2c\x20\x77\x61\x69\x74\x2e"
));return ((0x0b59+ 539-0x0d74));}($commandBuffer=$2);($$commandLine_ref{
"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"}=substr ($commandBuffer,
(0x19d3+ 1157-0x1e58),$$commandLine_ref{"\x73\x69\x7a\x65"}));chomp (
$$commandLine_ref{"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"});(
$commandBuffer=substr ($commandBuffer,$$commandLine_ref{"\x73\x69\x7a\x65"}));
Logger::debug3 ((Server::getAnywhereName ().((((((
"\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x27".$$commandLine_ref{
"\x63\x6f\x6d\x6d\x61\x6e\x64"})."\x27\x20\x73\x69\x7a\x65\x20\x27").
$$commandLine_ref{"\x73\x69\x7a\x65"}).
"\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61\x20\x27").
$$commandLine_ref{"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"})."\x27")));
Logger::debug3 ((Server::getAnywhereName ().((
"\x20\x49\x6e\x20\x62\x75\x66\x66\x65\x72\x20\x6c\x65\x66\x74\x20\x27".
$commandBuffer)."\x27\x2e")));}else{return ((0x09b7+ 2754-0x1479));}return (
(0x020a+ 4059-0x11e4));}sub parseLine{(my $line=shift (@_));(my (@elements)=
split ( /[,\n]/ ,$line,(0x0835+ 2018-0x1017)));(my (%parameters)=());
Logger::debug3 ((Server::getAnywhereName ().((
"\x20\x50\x61\x72\x73\x69\x6e\x67\x20\x65\x76\x65\x6e\x74\x20\x6c\x69\x6e\x65\x20\x27"
.$line)."\x27\x2e")));foreach my $element (@elements){(my ($name,$value)=split ( /=/ ,
$element,(0x0df9+ 3805-0x1cd3)));if (($parameters{$name}eq (""))){($parameters{
$name}=$value);}else{($parameters{$name}.=("\x2c".$value));}(my $logValue=$value
);($logValue=~ s/[\x1a\x1b]/./g );Logger::debug ((Server::getAnywhereName ().(((
(
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27"
.$name)."\x27\x20\x74\x6f\x20\x27").$logValue)."\x27\x2e")));}return (
%parameters);}sub sendUserOnConnection{(my $connectionId=shift (@_));(my $owner=
shift (@_));Logger::debug ((Server::getAnywhereName ().((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x73\x65\x6e\x64\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x3a\x20"
.$owner)."\x2e")));(my $command=__getUserCommand ($owner));return (
__sendCommandOnId ($connectionId,$command));}sub sendConnectedOnConnection{(my $connectionId
=shift (@_));(my $connections=shift (@_));Logger::debug ((
Server::getAnywhereName ().((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x73\x65\x6e\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x3a\x20"
.$connections)."\x2e")));(my $command=__getConnectionsCommand ($connections));
return (__sendCommandOnId ($connectionId,$command));}sub getFdById{(my $connectionId
=shift (@_));return ($connections{$connectionId}{"\x66\x64"});}sub getIdByFd{(my $Fd
=shift (@_));foreach my $connectionId (keys (%connections)){if (($connections{
$connectionId}{"\x66\x64"}==$Fd)){return ($connectionId);}}return (undef);}sub 
sendAllowedCommandOnConnection{(my $connectionId=shift (@_));(my $allowed=shift 
(@_));(my $command=__getAllowedCommand ($allowed));return (__sendCommandOnId (
$connectionId,$command));}sub sendLogoutOnConnection{(my $connectionId=shift (@_
));(my $command=__getLogoutCommand ());return (__sendCommandOnId ($connectionId,
$command));}sub sendCancelTwoFactor{(my $connectionId=shift (@_));(my $authId=
shift (@_));Logger::debug ((Server::getAnywhereName ().((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x43\x61\x6e\x63\x65\x6c\x20\x74\x77\x6f\x2d\x66\x61\x63\x74\x6f\x72\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$authId)."\x27\x2e")));(my $cmd=__getCancelTwoFactorCommand ($authId));return (
__sendCommandOnId ($connectionId,$cmd));}sub sendTwoFactorRequest{(my $connectionId
=shift (@_));(my $username=shift (@_));(my $client=shift (@_));(my $ip=shift (@_
));(my $authId=shift (@_));(my $local=shift (@_));(my $hostname=shift (@_));(my $platform
=shift (@_));(my $method=shift (@_));Logger::debug ((Server::getAnywhereName ().
((((
"\x20\x54\x77\x6f\x20\x66\x61\x63\x74\x6f\x72\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$username)."\x27\x20\x6d\x65\x74\x68\x6f\x64\x20\x27").$method)."\x27\x2e")));(my $cmd
=__getTwoFactorCommand ($username,$client,$ip,$authId,$local,$hostname,$platform
,$method));return (__sendCommandOnId ($connectionId,$cmd));}sub sigtermReceived{
Logger::debug ((((Server::getAnywhereName ().
"\x20\x43\x6c\x69\x65\x6e\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x2e\x20"
).Server::getAnywhereName ())."\x20\x63\x6c\x6f\x73\x69\x6e\x67\x2e"));(
$sigtermReceived=(0x12bb+ 4249-0x2353));}sub __isAfterSigterm{return (
$sigtermReceived);}sub __getLogoutCommand{return (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6c\x6f\x67\x6f\x75\x74\x0a");}sub 
__getAllowedCommand{(my $allowed=shift (@_));(my $command=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x61\x6c\x6c\x6f\x77\x65\x64\x2c");($command.=(
("\x74\x79\x70\x65\x3d".$allowed)."\x0a"));return ($command);}sub 
__getUserCommand{(my $user=shift (@_));return (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x73\x6b\x74\x6f\x70\x2c\x75\x73\x65\x72\x3d"
.purge ($user))."\x0a"));}sub __getConnectionsCommand{(my $connections=shift (@_
));return (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x2c\x76\x61\x6c\x75\x65\x3d"
.$connections)."\x0a"));}sub __getAddMachinesCommand{(my $connections=shift (@_)
);return (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6d\x61\x63\x68\x69\x6e\x65\x73\x2c\x74\x79\x70\x65\x3d\x67\x65\x74\x0a"
);}sub __getRegisterCommand{(my $connections=shift (@_));return (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6d\x61\x63\x68\x69\x6e\x65\x73\x2c\x74\x79\x70\x65\x3d\x72\x65\x67\x69\x73\x74\x65\x72\x0a"
);}sub __createAnywhereConnection{my ($pipeIn,$pipeOut);if ((not (
main::nxPipeCreateBi ((\$pipeOut),(\$pipeIn))))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20"
.Server::getAnywhereName ())."\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e")
);return (undef);}Logger::debug ((Server::getAnywhereName ().((((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x43\x72\x65\x61\x74\x65\x28\x46\x44\x23"
.$pipeIn)."\x2c\x20\x46\x44\x23").$pipeIn)."\x29\x20\x73\x74\x61\x72\x74\x2e")))
;(my $anywhereId=libnxhs::NXAnywhereCreate ($pipeIn,$pipeIn));Logger::debug ((
Server::getAnywhereName ().((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x43\x72\x65\x61\x74\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27\x46\x44\x23"
.$anywhereId)."\x27\x2e")));($connections{$anywhereId}{"\x66\x64"}=$pipeOut);
return ($anywhereId);}sub __sendCommandOnId{(my $connectionId=shift (@_));(my $cmd
=shift (@_));(my $fd=getFdById ($connectionId));(my $logCmd=
__hidePasswordFromLoginCommandLine ($cmd));($logCmd=~ s/[\x1a\x1b]/./g );
Logger::debug ((Server::getAnywhereName ().((((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.$logCmd)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e")));if ((defined ($fd)
and ($fd!=(-(0x0f01+ 1770-0x15ea))))){if ((main::nxwrite ($fd,$cmd)==(-
(0x0aaf+ 5432-0x1fe6)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning ((Server::getAnywhereName ().((((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.$logCmd)."\x27\x20\x74\x6f\x20\x46\x44\x23").$fd)."\x2e")));Logger::warning ((
Server::getAnywhereName ().(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20").$errorstring)."\x2e")));return ((0x078b+ 4319-0x1869))
;}return ((0x0188+ 3687-0x0fef));}Logger::warning ((Server::getAnywhereName ().(
(((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.$logCmd)."\x27\x2e\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20").
$connectionId)."\x20\x69\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e")));return (
(0x022f+ 1655-0x08a5));}sub __getHostkey{(my $file=NXPaths::getHostPublicCert ()
);(my $fileHandle=main::nxopen ($file,$NXBits::O_RDONLY));(my $hostkey=undef);
unless (defined ($fileHandle)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20".Server::getAnywhereName ()).(
("\x20\x68\x6f\x73\x74\x6b\x65\x79\x20\x66\x69\x6c\x65\x20\x27".$file).
"\x27\x2e")));return ($hostkey);}my ($buffer);while (main::nxreadLine (
$fileHandle,(\$buffer))){($hostkey.=$buffer);}main::nxclose ($fileHandle);if ((
$hostkey eq (""))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20".Server::getAnywhereName ()).(
("\x20\x68\x6f\x73\x74\x6b\x65\x79\x20\x66\x72\x6f\x6d\x20\x27".$file).
"\x27\x2e")));}($hostkey=~ s/\r//gm );($hostkey=~ s/\n//gm );return ($hostkey);}
sub __getLoginCommandLine{(my $allowed=shift (@_));(my $machine=
Common::NXInfo::getHostInfo ());if ((defined ($GLOBAL::NMNHostName)and (
$GLOBAL::NMNHostName ne ("")))){($machine=$GLOBAL::NMNHostName);}main::nxrequire
 ("\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $cookie=
NXAnywhereRedis::getAccessCookie ());if (($cookie eq (""))){Logger::warning ((
Server::getAnywhereName ().
"\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x66\x65\x74\x63\x68\x20\x6d\x61\x63\x68\x69\x6e\x65\x20\x63\x6f\x6f\x6b\x69\x65\x2e"
));return ((""));}(my $loginCommand=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6c\x6f\x67\x69\x6e\x2c");($loginCommand.=
"\x61\x6e\x6f\x6e\x79\x6d\x6f\x75\x73\x3d\x31\x2c");($loginCommand.=((
"\x6d\x61\x63\x68\x69\x6e\x65\x63\x6f\x6f\x6b\x69\x65\x3d".purge ($cookie)).
"\x2c"));($loginCommand.=(("\x6d\x61\x63\x68\x69\x6e\x65\x3d".purge ($machine)).
"\x2c"));($loginCommand.=(("\x68\x77\x3d".purge (Common::NXInfo::getHwInfo ())).
"\x2c"));($loginCommand.=(("\x70\x6c\x61\x74\x66\x6f\x72\x6d\x3d".purge (
Common::NXInfo::getDistroInfo ()))."\x2c"));($loginCommand.=((
"\x70\x61\x63\x6b\x61\x67\x65\x3d".purge ($GLOBAL::PRODUCT_NAME))."\x2c"));(
$loginCommand.=(("\x68\x6f\x73\x74\x6b\x65\x79\x3d".purge (__getHostkey ())).
"\x2c"));($loginCommand.=(("\x75\x75\x69\x64\x3d".purge (Server::getMyUUID ())).
"\x2c"));($loginCommand.=(("\x76\x65\x72\x73\x69\x6f\x6e\x3d".purge (
Common::NXInfo::getNxVersion ()))."\x2c"));($loginCommand.=
"\x74\x79\x70\x65\x3d\x73\x65\x72\x76\x65\x72\x2c");($loginCommand.=((
"\x61\x6c\x6c\x6f\x77\x65\x64\x3d".$allowed)."\x0a"));return ($loginCommand);}
sub __getAnonymousLoginCommand{(my $cookie=(shift (@_)||("")));(my $machine=
Common::NXInfo::getHostInfo ());if ((defined ($GLOBAL::NMNHostName)and (
$GLOBAL::NMNHostName ne ("")))){($machine=$GLOBAL::NMNHostName);}(my $loginCommand
="\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6c\x6f\x67\x69\x6e\x2c");($loginCommand.=
"\x61\x6e\x6f\x6e\x79\x6d\x6f\x75\x73\x3d\x31\x2c");if (($cookie ne (""))){(
$loginCommand.=(("\x6d\x61\x63\x68\x69\x6e\x65\x63\x6f\x6f\x6b\x69\x65\x3d".
purge ($cookie))."\x2c"));}($loginCommand.=(("\x6d\x61\x63\x68\x69\x6e\x65\x3d".
purge ($machine))."\x2c"));($loginCommand.=(("\x68\x77\x3d".purge (
Common::NXInfo::getHwInfo ()))."\x2c"));($loginCommand.=((
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x3d".purge (Common::NXInfo::getDistroInfo ()))
."\x2c"));($loginCommand.=(("\x70\x61\x63\x6b\x61\x67\x65\x3d".purge (
$GLOBAL::PRODUCT_NAME))."\x2c"));($loginCommand.=((
"\x68\x6f\x73\x74\x6b\x65\x79\x3d".purge (__getHostkey ()))."\x2c"));(
$loginCommand.=(("\x75\x75\x69\x64\x3d".purge (Server::getMyUUID ()))."\x2c"));(
$loginCommand.=(("\x76\x65\x72\x73\x69\x6f\x6e\x3d".purge (
Common::NXInfo::getNxVersion ()))."\x2c"));($loginCommand.=
"\x74\x79\x70\x65\x3d\x73\x65\x72\x76\x65\x72\x0a");return ($loginCommand);}sub 
__hidePasswordFromLoginCommandLine{(my $line=shift (@_));($line=~ s/(password=).*,machine/$1******,machine/gm )
;return ($line);}sub closeAnywhereConnection{(my $connectionId=shift (@_));
Logger::debug ((Server::getAnywhereName ().((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x67\x6f\x69\x6e\x67\x20\x74\x6f\x20\x64\x65\x73\x74\x72\x6f\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$connectionId)."\x27\x2e")));Logger::debug ((Server::getAnywhereName ().((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x73\x74\x72\x6f\x79\x28"
.$connectionId)."\x29")));(my $ret=libnxhs::NXAnywhereDestroy ($connectionId));
Logger::debug ((Server::getAnywhereName ().((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x73\x74\x72\x6f\x79\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$ret)."\x27\x2e")));Logger::debug ((Server::getAnywhereName ().((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x52\x65\x6d\x6f\x76\x65\x20\x66\x72\x6f\x6d\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20\x46\x44\x23"
.$connections{$connectionId}{"\x66\x64"})."\x2e")));
Common::NXSelector::removeFromGlobalSelector ($connections{$connectionId}{
"\x66\x64"});main::nxclose ($connections{$connectionId}{"\x66\x64"});(
$connections{$connectionId}=undef);delete ($connections{$connectionId});
Logger::debug ((Server::getAnywhereName ().((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x64\x65\x73\x74\x72\x6f\x79\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$connectionId)."\x27\x2e")));if (($ret==(-(0x19fb+ 737-0x1cdb)))){
Common::NXCore::reportErrorFromNXPL ((Server::getAnywhereName ().
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x73\x74\x72\x6f\x79\x20\x66\x61\x69\x6c\x65\x64\x2e"
));}}sub __handleConnectionClose{(my $connectionFd=shift (@_));(my $connectionId
=getIdByFd ($connectionFd));if (__isAfterSigterm ()){Logger::debug ((
Server::getAnywhereName ().((((
"\x20\x43\x6c\x69\x65\x6e\x74\x3a\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$connectionId)."\x27\x20\x46\x44\x23").$connectionFd).
"\x20\x63\x6c\x6f\x73\x65\x64\x2e")));}else{Logger::warning (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20".
Server::getAnywhereName ()).(((("\x20\x27".$connectionId)."\x27\x20\x46\x44\x23"
).$connectionFd)."\x20\x63\x6c\x6f\x73\x65\x64\x2e")));Logger::debug ((
Server::getAnywhereName ().((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x73\x75\x6c\x74\x28"
.$connectionId)."\x29\x20\x73\x74\x61\x72\x74\x2e")));(my $errorNumber=
libnxhs::NXAnywhereResult ($connectionId));Logger::debug ((
Server::getAnywhereName ().((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x73\x75\x6c\x74\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$errorNumber)."\x27\x2e")));}closeAnywhereConnection ($connectionId);}sub 
__getTwoFactorCommand{(my $username=shift (@_));(my $client=shift (@_));(my $ip=
shift (@_));(my $authId=shift (@_));(my $local=shift (@_));(my $hostname=shift (
@_));(my $platform=shift (@_));(my $method=shift (@_));(my $cmd=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x74\x77\x6f\x66\x61\x63\x74\x6f\x72");($cmd.=
"\x2c\x61\x63\x74\x69\x6f\x6e\x3d\x72\x65\x71\x75\x65\x73\x74");($cmd.=(
"\x2c\x69\x64\x3d".purge ($authId)));($cmd.=("\x2c\x69\x70\x3d".purge ($ip)));(
$cmd.=("\x2c\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d".purge ($username)));($cmd.=(
"\x2c\x6c\x6f\x63\x61\x6c\x3d".$local));($cmd.=(
"\x2c\x70\x6c\x61\x74\x66\x6f\x72\x6d\x3d".purge ($platform)));($cmd.=(
"\x2c\x68\x6f\x73\x74\x6e\x61\x6d\x65\x3d".purge ($hostname)));if (($method ne 
(""))){($cmd.=("\x2c\x6d\x65\x74\x68\x6f\x64\x3d".$method));}($cmd.="\x0a");
return ($cmd);}sub __getCancelTwoFactorCommand{(my $authId=shift (@_));(my $cmd=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x74\x77\x6f\x66\x61\x63\x74\x6f\x72\x2c");(
$cmd.="\x61\x63\x74\x69\x6f\x6e\x3d\x63\x61\x6e\x63\x65\x6c\x2c");($cmd.=(
"\x69\x64\x3d".$authId));($cmd.="\x0a");return ($cmd);}sub purge{(my $msg=shift 
(@_));Logger::debug3 ((Server::getAnywhereName ().((
"\x20\x4e\x58\x43\x6f\x72\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x50\x75\x72\x67\x65\x28"
.$msg)."\x29\x2e")));libnxhs::NXAnywherePurge ($msg);Logger::debug3 ((
Server::getAnywhereName ().((
"\x20\x4e\x58\x43\x6f\x72\x65\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x50\x75\x72\x67\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$msg)."\x27\x2e")));return ($msg);}sub unpurge{(my $msg=shift (@_));
Logger::debug3 ((Server::getAnywhereName ().((
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x55\x6e\x70\x75\x72\x67\x65\x28"
.$msg)."\x29\x2e")));libnxhs::NXAnywhereUnpurge ($msg);Logger::debug3 ((
Server::getAnywhereName ().((
"\x20\x4e\x58\x43\x6f\x72\x65\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x55\x6e\x70\x75\x72\x67\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$msg)."\x27\x2e")));return ($msg);}"\x3f\x3f\x3f";
