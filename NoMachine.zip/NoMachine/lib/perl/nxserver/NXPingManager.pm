############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXPingManager;no warnings;(my $__pingRequestTime=(0x093a+ 6669-0x2347));
(my $__pingTime=(0x0897+ 372-0x0a0b));(my $__interval=(0x0080+ 4763-0x131b));(my $__timeout
=(0x14e9+ 3897-0x2422));(my $__errorTimeout=(0x1a29+ 1643-0x2094));sub 
initialize{__setTimeBetweenPingsFromNode ();__setTimeoutForPingAfterRequest ();
__setPingRequestTime ();}sub __setTimeBetweenPingsFromNode{($__interval=
(0x091d+ 4321-0x19b3));Logger::debug (((
"\x4e\x58\x50\x69\x6e\x67\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x54\x69\x6d\x65\x20\x62\x65\x74\x77\x65\x65\x6e\x20\x70\x69\x6e\x67\x73\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x6e\x6f\x64\x65\x3a\x20"
.$__interval)."\x2e"));}sub __setTimeoutForPingAfterRequest{($__timeout=
NXNodeConfiguration::getNodeConnectionTimeout ());Logger::debug (((
"\x4e\x58\x50\x69\x6e\x67\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x54\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x70\x69\x6e\x67\x20\x61\x66\x74\x65\x72\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20"
.$__timeout)."\x2e"));}sub checkTimesAndRequestPingIfNecessary{if ((
__isPingEnabled ()==(0x0533+ 1222-0x09f9))){return;}if ((__isTimeout ()==
(0x1d47+ 2417-0x26b7))){if ((__isErrorTimeout ()==(0x16e2+ 3290-0x23bb))){(my $msg
=((
"\x4e\x6f\x64\x65\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x70\x69\x6e\x67\x20\x73\x69\x6e\x63\x65\x20"
.$__timeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));Logger::error ($msg);Logger::statusPushError ($msg);die ($msg);}
__setErrorTimeout ();Logger::warning (((
"\x4e\x6f\x64\x65\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x70\x69\x6e\x67\x20\x73\x69\x6e\x63\x65\x20"
.$__timeout)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));__sendPingRequest ();
return;}if ((__isPingRequestTime ()==(0x1d79+ 2350-0x26a6))){__sendPingRequest 
();return;}}sub handlePing{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x70\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);__resetPingRequestTime ();__clearErrorTimeout ();Logger::debug (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x6f\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);NXNodeExec::sendToNode ((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_NODE_PONG)."\x20")
.$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_NODE_PONG})."\x0a"));__setPingTime ();}
sub __isPingRequestTime{if (($__pingTime==(0x200d+  29-0x202a))){return (
(0x0bcf+ 2092-0x13fb));}(my $time=Common::NXTime::getSecondsSinceEpoch ());if ((
$time>=($__pingTime+$__interval))){return ((0x012d+ 197-0x01f1));}return (
(0x0b63+ 137-0x0bec));}sub __resetPingRequestTime{($__pingRequestTime=
(0x0d71+ 5269-0x2206));}sub __setPingRequestTime{($__pingRequestTime=
Common::NXTime::getSecondsSinceEpoch ());}sub __sendPingRequest{Logger::debug (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x70\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);NXNodeExec::sendToNode ((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_REQUEST_FOR_PING).
"\x20").$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_REQUEST_FOR_PING})."\x0a"));
__setPingRequestTime ();__resetPingTime ();}sub disable{($__timeout=
(0x01a7+ 8957-0x24a4));Logger::debug (
"\x4e\x58\x50\x69\x6e\x67\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x20\x70\x69\x6e\x67\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);}sub __isPingEnabled{if (($__timeout==(0x1a11+ 1279-0x1f10))){return (
(0x06d2+ 565-0x0907));}return ((0x1403+ 4686-0x2650));}sub __isTimeout{if ((
$__pingRequestTime==(0x11ff+ 3741-0x209c))){return ((0x0076+ 1955-0x0819));}(my $time
=Common::NXTime::getSecondsSinceEpoch ());if (($__pingRequestTime>$time)){(
$__pingRequestTime=Common::NXTime::getSecondsSinceEpoch ());}if (($time>=(
$__pingRequestTime+$__timeout))){return ((0x12f8+   8-0x12ff));}return (
(0x16c0+ 1370-0x1c1a));}sub __setPingTime{($__pingTime=
Common::NXTime::getSecondsSinceEpoch ());}sub __resetPingTime{($__pingTime=
(0x060b+ 8440-0x2703));}sub __setErrorTimeout{($__errorTimeout=
(0x1bad+ 672-0x1e4c));}sub __isErrorTimeout{return ($__errorTimeout);}sub 
__clearErrorTimeout{($__errorTimeout=(0x13f6+ 1151-0x1875));}return (
(0x1067+ 3928-0x1fbe));
