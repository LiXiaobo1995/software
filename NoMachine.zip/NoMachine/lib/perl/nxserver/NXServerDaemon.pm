############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXServerDaemon::BEGIN{package NXServerDaemon;no warnings;require warnings;do
{"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXServerDaemon::BEGIN{package 
NXServerDaemon;no warnings;require NXPaths;do{"\x4e\x58\x50\x61\x74\x68\x73"->
import};}package NXServerDaemon;no warnings;require SlaveServer;sub BEGIN{
require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}((
%listenSocket)=());(@checkLocalSessionLoopDelay=((0x12d1+ 4889-0x25cc),
(0x0d2c+ 4889-0x2027),(0x0270+ 6567-0x1bdb),(0x18ea+ 2030-0x1fac),
(0x04c4+ 8700-0x2468),(0x1439+ 5769-0x23ba),3600));($servicesMonitoringDelay=
(0x074c+ 6255-0x1f9d));($currentCheckLocalSessionLoopDelay=(0x12dc+ 1501-0x18b9)
);($lastCheckLocalSessionTime=(0x0ad4+ 3218-0x1766));($terminateMode=
(0x0066+ 5458-0x15b8));(@servicesToMonitoring=());($terminateReceivedTime=
(0x0ef8+ 5194-0x2342));($checkLocalSessionScheduled=(0x07b9+ 984-0x0b91));(
$checkLocalSessionDelayed=(0x24ea+ 112-0x255a));($selector=undef);(
$ServerDaemonLockFileHandle=(-(0x06e6+ 6933-0x21fa)));($ServerDaemonDBusName=
"\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x64\x61\x65\x6d\x6f\x6e"
);($clientDescriptorsWaitingForStatusReport={});((%serversInAdminMode)=());(
$adminModeFlag=((((((NXPaths::getNodeRoot ().$GLOBAL::DIRECTORY_SLASH).
"\x76\x61\x72").$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x61\x64\x6d\x69\x6e\x4d\x6f\x64\x65"));(
$connectedToRemoteNodes=(0x174c+ 2865-0x227d));($connectedToLocalhost=
(0x11ad+ 1472-0x176d));($initializing=(-(0x02e1+ 8496-0x2410)));($errorToAdmin=
(""));sub __startupInfo{(my $nodes=NXNodes::remoteNodesSize ());(my $message=
"\x53\x79\x73\x74\x65\x6d\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x3a\x20"
);($message.=Common::NXInfo::getDistroInfo ());main::nxrequire (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72");if (
KeysManager::isNotExistNodePublicKey ()){($message.=
"\x2c\x20\x73\x74\x61\x6e\x64\x61\x6c\x6f\x6e\x65");}if (($nodes>
(0x12f8+ 242-0x13ea))){($message.=("\x2c\x20\x4e".$nodes));}($message.="\x2e");
Logger::info ((((("\x53\x74\x61\x72\x74\x69\x6e\x67\x20".$GLOBAL::PRODUCT_ID).
"\x20").$GLOBAL::SOFTWARE_RELEASE).
"\x20\x61\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x73\x2e"));Logger::info (
$message);}sub runDaemon{__startupInfo ();__setDaemonInitializing ();
Server::setPassErrorsToUserDisabled ();if ((not (
NXRedis::isDbRunningInCurrentProcess ()))){NXRedis::initRedisServer ();}
main::nxrequire ("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
NXUdpControl::cleanLocalUdpChannels ();NXNodes::findLocalNode ();
saveServerDaemonLangEnvInDb ();NXLocalSession::startSessionServers ();
NXLocate::setServerStartup ();__startServices ();if (NXLocate::isNXLocateEnabled
 ()){NXLocate::run ();}NXSystemDaemons::initUPnPServices ();
NXSystemDaemons::initNXNetworkChangeService ();if (
NXLicense::isAutomaticRecordingFeature ()){if (($GLOBAL::AutomaticRecordingClean
>(0x1136+ 1678-0x17c4))){NXEvent::createPeriodicEventAndSubscribe (
NXEvent::getAutomaticRecordingCleanEventName (),(
$GLOBAL::AutomaticRecordingClean/(0x053c+ 1303-0x0a51)),
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x3a\x3a\x72\x65\x6d\x6f\x76\x65\x4f\x6c\x64\x52\x65\x63\x6f\x72\x64\x73"
);}}__setDaemonInitialized ();NXEvent::afterDaemonStart ();runMonitor ();
NXSystemDaemons::stopNXNetworkChangeService ();NXSystemDaemons::stopUPnPServices
 ();NXSystemDaemons::stop ("\x6e\x78\x64");if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){NXSystemDaemons::stop (
"\x6e\x78\x68\x74\x64");}stopServerDaemonListen ();removeServerDaemonPidFile ();
NXRedis::closeDb ();NXClusterDaemon::destroy ();NXEvent::afterDaemonStop ();}sub
 initializeDaemon{Server::initConnectionSTD ();if ((checkAndSetServerDaemonFlock
 ()==(0x0f1c+ 201-0x0fe5))){Logger::error (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x69\x6e\x73\x74\x61\x6e\x63\x65\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);main::nxexit ();}NXEvent::beforeDaemonStart ();if (NXSystemDaemons::savePid (
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x70\x69\x64\x2e"
);main::nxexit ();}__initializeDaemonSelector ();if ((not (
__startServerDaemonListen ()))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x20\x6c\x69\x73\x74\x65\x6e\x69\x6e\x67\x20\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);main::nxexit ();}return ((0x0471+ 5808-0x1b20));}sub __startServices{
Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);Server::setClientConnectionClosed ();NXSystemDaemons::start ("\x6e\x78\x64");
NXWindowsServices::startWindowsServices ();}sub __initializeDaemonSelector{(
$selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;($$NXBegin::parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x54\x45\x52\x4d"}=sub{(
$GLOBAL::REQUEST_TERMINATE=(0x031b+ 1837-0x0a47));
NXSystemDaemons::setShutdownFlag ();Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x54\x45\x52\x4d\x27\x20\x69\x6e\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x2e"
);});}sub checkAndSetServerDaemonFlock{unless (($ServerDaemonLockFileHandle==(-
(0x048f+ 5978-0x1be8)))){return ((0x1ae5+ 1636-0x2148));}if ((not (
checkDaemonFlock ()))){return ((0x1b2f+ 2491-0x24ea));}else{main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44\x61\x65\x6d\x6f\x6e"
);(my $fh=NXServices::NXDaemon::lockFile ());if (($fh==(-(0x0764+ 320-0x08a3))))
{return ((0x0e34+ 851-0x1187));}setServerDaemonLockFileHandle ($fh);return (
(0x1269+ 1511-0x184f));}}sub checkDaemonFlock{(my $file=
$GLOBAL::ServerDaemonLockFilePath);Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x66\x69\x6c\x65\x20\x6c\x6f\x63\x6b\x3a\x20"
.$file)."\x2e"));if (((defined ($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"})and (
length ($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"})>(0x15f5+ 2941-0x2172)))and (
$ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31"))){(my $dir=((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e"));if ((not (-d ($dir)
))){my ($errorMessage);Common::NXPaths::makePath ((\$errorMessage),$dir);}}if ((
not (Common::NXFile::fileExists ($file)))){Logger::debug (((
"\x46\x69\x6c\x65\x20".$file).
"\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));return (
(0x0c2a+ 3846-0x1b2f));}(my $SERVER_FH=main::nxopen ($file,$NXBits::O_RDONLY,
(0x118d+ 1048-0x15a5)));if ((not (defined ($SERVER_FH)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".$file
)."\x2e"));return ((0x09e7+ 1295-0x0ef6));}if ((not (Common::NXCore::nxTryLock (
$SERVER_FH,$NXBits::LOCK_EX)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x63\x6b\x20\x66\x69\x6c\x65\x3a\x20".$file
)."\x2e"));main::nxclose ($SERVER_FH);return ((0x0864+ 4954-0x1bbe));}
main::nxclose ($SERVER_FH);return ((0x0d36+ 4360-0x1e3d));}sub runMonitor{
Logger::debug (
"\x53\x74\x61\x72\x74\x20\x6d\x61\x69\x6e\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x6c\x6f\x6f\x70\x2e"
);main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");
NXNodeExec::setSessionType (Common::NXSessionType::getPhysicalDesktop ());(my $signalFd
=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});addFdToSelector ($signalFd);(my $connectionToNXservice
=main::nxgetSTDIN ());addFdToSelector ($connectionToNXservice);main::nxrequire (
"\x4e\x58\x55\x70\x64\x61\x74\x65");NXUpdate::init ();if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){main::nxrequire (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c"
);NXWebInfoFilesControl::enableService ();}(my $terminateFinished=
(0x06a8+ 2288-0x0f98));my ($exception);while ((($GLOBAL::REQUEST_TERMINATE!=
(0x0309+ 6373-0x1bed))or ($terminateFinished!=(0x0664+ 7613-0x2420)))){my (
@ready);if ((not (isTerminateMode ()))){if ((isSendErrorToAdminMode ()==
(0x0547+ 1176-0x09de))){NXLocalSession::sendErrorToAdmin (getErrorToAdmin ());}
handleServicesMonitoring ();NXClusterDaemon::create ();(my $delay=
getNewTimeoutForRead ());(@ready=$selector->can_read ($delay));}else{if (
NXLocalSession::localSessionsRunning ()){(my $timeout=getNewTimeoutForRead ());
Common::NXCore::exitFromSelectOnFirstSignal ();&try (sub{(@ready=$selector->
can_read ($timeout));},&otherwise (sub{($exception=shift (@_));}));if (
$exception){last;}}else{($terminateFinished=(0x0b48+ 4425-0x1c90));}}foreach my $f
 (@ready){if (NXSystemDaemons::isDefinedUPnPFD ($f)){main::nxrequire (
"\x4e\x58\x55\x70\x6e\x70");NXUpnp::handleMessageOnDescriptor ($f);}elsif (($f==
$NXSystemDaemons::NetworkChangeFD_Read)){main::nxrequire (
"\x4e\x58\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65");
NXNetworkChange::handleMessageOnDescriptor ($f);}elsif (($f==
$connectionToNXservice)){Logger::debug (((
"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$f)."\x2e"));my ($read_buf);(my $bytes_read=main::nxread ($f,(\$read_buf),
(0x1ab1+ 5176-0x1ee9)));if (((not (defined ($bytes_read)))or ($bytes_read==
(0x0177+ 6629-0x1b5c)))){Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);removeFdFromSelector ($f);main::nxclose ($f);($GLOBAL::REQUEST_TERMINATE=
(0x0e1a+ 2511-0x17e8));NXSystemDaemons::setShutdownFlag ();}else{Logger::debug (
((
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x20\x73\x65\x6e\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$read_buf)."\x27\x2e"));if (($read_buf=~ /SERVICE_CONTROL_STOP/ )){
Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x20\x69\x73\x20\x63\x6c\x6f\x73\x69\x6e\x67\x2c\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);($GLOBAL::REQUEST_TERMINATE=(0x0201+ 5568-0x17c0));
NXSystemDaemons::setShutdownFlag ();}elsif ((($read_buf eq 
"\x41\x6c\x69\x76\x65")and NXLocalSession::isStopStatus ())){Logger::debug (
"\x53\x65\x6e\x64\x20\x61\x73\x6b\x20\x74\x6f\x20\x73\x74\x6f\x70\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x2e"
);NXLocalSession::resetStopStatus ();(my $fd=main::nxgetSTDOUT ());(my $msg=
"\x44\x65\x6c\x65\x74\x65");if ((main::nxwrite ($fd,$msg)==(-
(0x1a44+ 2740-0x24f7)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e"
);}else{Logger::debug ((((("\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$msg).
"\x27\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6f\x6e\x20\x46\x44\x23"
).$fd)."\x2e"));}}elsif ((($read_buf eq "\x44\x65\x61\x64")and 
NXLocalSession::isStartStatus ())){Logger::debug (
"\x53\x65\x6e\x64\x20\x61\x73\x6b\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x2e"
);NXLocalSession::resetStartStatus ();(my $fd=main::nxgetSTDOUT ());(my $msg=
"\x41\x64\x64");if ((main::nxwrite ($fd,$msg)==(-(0x0976+ 6674-0x2387)))){
Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e"
);}else{Logger::debug ((((("\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$msg).
"\x27\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x20\x6f\x6e\x20\x46\x44\x23"
).$fd)."\x2e"));}}}}}if ((not (NXSystemDaemons::isShutdownFlag ()))){if (
NXForeignSession::isTimeForCheckForeignNodes ()){
NXForeignSession::checkForeignNodes ();}NXServers::checkInverseNodesConnection 
();NXConnectionMonitor::checkCMConnection ();main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65");if (((not (
__isWaitingForLocalNodeRun ()))and NXLogrotate::isTimeForCheckLogrotate ())){
NXLogrotate::checkLogrotateAndHandleIfNeeded ();}if (
NXLicense::isTimeForCheckProcessorsCount ()){NXLicense::checkProcessorsCount ();
}main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");if (
NXScripts::shouldRerunNXReportSystemLoadScript ()){
NXScripts::rerunNXReportSystemLoadScript ();}}if (
NXLicense::isAutomaticRecordingFeature ()){main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);NXAutomaticRecordingNode::checkAndHandleIfNeeded ();}if ((
Server::terminateCommandReceived ()and (not (isTerminateMode ())))){
setTerminateMode ();Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x73\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e");
NXRedisSubscription::publishToSubscribers (($GLOBAL::MSG_SHUTDOWN_TERMINATE.
"\x20\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x72\x65\x61\x73\x6f\x6e\x3d\x64\x61\x65\x6d\x6f\x6e\x20"
));NXLocalSession::terminateAllLocalSessions ();}
NXLocalSession::checkNodesToRemove ();
NXLocalSession::checkNodesToKillAfterTerminateSent ();
checkWaitingToLocalNodeRunWithSendStatus ();}Logger::debug (
"\x41\x66\x74\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x6d\x61\x69\x6e\x20\x6c\x6f\x6f\x70\x2e"
);NXEvent::beforeDaemonStop ();NXUpdate::shutdown ();if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){main::nxrequire (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c"
);NXWebInfoFilesControl::deleteAllInfoFiles ();}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");NXNodeCleaner::collect 
();NXTerminate::waitForRunningSession ();NXTerminate::terminateLeftoverServers 
();if ($exception){$exception->notify;}}sub handleServicesMonitoring{
NXUpdate::checkUpdate ();main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");if ((
NXUpnp::isUPnPMapEnabled ()and NXUpnp::isUPnPEnabled ())){
NXUpnp::checkIfAddPortMapping ();}if ((NXLocate::isNXLocateEnabled ()and 
NXLocate::wasStarted ())){NXLocate::checkUpdate ();}if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){main::nxrequire (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c"
);NXWebInfoFilesControl::checkService ();}foreach my $service (
@servicesToMonitoring){checkServiceAndRestartIfNecessary ($service);}}sub 
checkServiceAndRestartIfNecessary{(my $service=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x20\x73\x65\x72\x76\x69\x63\x65\x20\x61\x6e\x64\x20\x72\x65\x73\x74\x61\x72\x74\x20\x69\x66\x20\x6e\x65\x63\x65\x73\x73\x61\x72\x79\x3a\x20"
.$service)."\x2e"));if (NXSystemDaemons::isDisabled ($service)){return (
(0x00c8+ 5003-0x1453));}if (NXSystemDaemons::isRunning ($service)){return (
(0x1427+ 479-0x1606));}return (NXSystemDaemons::start ($service));}sub 
parseLocalNodeSocket{(my $socket=shift (@_));(my $read_buf=shift (@_));if (
isAcceptFDParsing ($socket)){addToAcceptFDBuffer ($socket,$read_buf);
Logger::debug (((
"\x70\x61\x72\x73\x65\x4c\x6f\x63\x61\x6c\x4e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74\x3a\x20\x53\x6b\x69\x70\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket).
"\x20\x61\x6e\x6f\x74\x68\x65\x72\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73\x2e"
));return;}else{setAcceptFDParsing ($socket);}Logger::debug (((((
"\x50\x61\x72\x73\x65\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$read_buf)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$socket)."\x2e"));(my (@lines)=
split ( /\n/ ,$read_buf,(0x0971+ 2252-0x123d)));foreach my $line (@lines){if ((
$line eq (""))){next;}if (($line=~ /NX> (\d+).*/ )){(my $messageNum=$1);if (
NXNodeExec::isMessageWithCodeHandledByNode ($messageNum)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x62\x79\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x2e"
);(my $currentNodeStdin=NXNodeExec::getstdin ());if (defined ($currentNodeStdin)
){Logger::debug (((
"\x53\x61\x76\x69\x6e\x67\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x46\x44\x23"
.$currentNodeStdin)."\x2e"));}else{Logger::debug (
"\x53\x61\x76\x69\x6e\x67\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x2e"
);}(my $stdin=NXLocalSession::getStdinForLocalNodeBasedOnSocket ($socket));if ((
$stdin==(-(0x0d60+ 2378-0x16a9)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x6f\x62\x6a\x65\x63\x74\x20\x77\x61\x73\x20\x63\x6c\x65\x61\x6e\x65\x64\x20\x62\x65\x66\x6f\x72\x65\x20\x68\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$line)."\x27\x2e"));next;}NXNodeExec::setstdin ($stdin);(my $function=
NXNodeExec::getHandlerFunctionForMessageCodeFromNode ($messageNum));
Logger::debug (((("\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x3a\x20"
.$messageNum)."\x20\x77\x69\x74\x68\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x3a\x20"
).$function));&$function ($socket,$line);Logger::debug (
"\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x68\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x62\x79\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x2e"
);if (defined ($currentNodeStdin)){Logger::debug (((
"\x52\x65\x73\x74\x6f\x72\x69\x6e\x67\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x46\x44\x23"
.$currentNodeStdin)."\x2e"));}else{Logger::debug (
"\x52\x65\x73\x74\x6f\x72\x69\x6e\x67\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x2e"
);}NXNodeExec::setstdin ($currentNodeStdin);}else{if (
Common::NXMsg::isPackedMessageNumber ($messageNum)){(my ($indexString,
$rawMessage,@parameters)=Common::NXMsg::unpackResponse ($line));($messageNum=
Common::NXMsg::getNumber ($indexString));if (((not ($messageNum))and (
$rawMessage=~ /NX> (\d+).*/ ))){($messageNum=$1);}}if (
Common::NXMsg::isErrorMessageNumber ($messageNum)){NXNodeExec::setLastErrorLine 
($line);}}}}Logger::debug (((
"\x70\x61\x72\x73\x65\x4c\x6f\x63\x61\x6c\x4e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));clearAcceptFDParsing ($socket);(my $FDBuffer=
getAcceptFDBuffer ($socket));if (($FDBuffer ne (""))){clearAcceptFDBuffer (
$socket);Logger::debug (((
"\x70\x61\x72\x73\x65\x4c\x6f\x63\x61\x6c\x4e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74\x3a\x20\x52\x65\x73\x75\x6d\x65\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));parseLocalNodeSocket ($socket,$FDBuffer);}}sub 
parseServerMonitor{(my $socket_fn=shift (@_));my ($line);(my $code=(-
(0x08c1+ 6498-0x2222)));(my $body=(""));(my $clientSocket=(""));if ((
getAcceptFDBuffer ($socket_fn)=~ /^(.*?)\n(.*)$/s )){($line=$1);
setAcceptFDBuffer ($socket_fn,$2);}(my $logstr=main::hideOutput ($line));(my $logsbuff
=main::hideOutput (getAcceptFDBuffer ($socket_fn)));Logger::debug (((((
"\x50\x61\x72\x73\x65\x20\x64\x61\x65\x6d\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$logstr).
"\x27\x20\x69\x6e\x20\x62\x75\x66\x66\x65\x72\x20\x6c\x65\x66\x74\x20\x27").
$logsbuff)."\x27\x2e"));if (($line=~ /NX> (\d+) (.*)$/ )){($code=$1);($body=$2);
(my $logBody=($body||("")));(my $logCode=($code||("")));Logger::debug ((((((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x5b".
$logCode)."\x5d\x5b").$logBody)."\x5d\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").
$socket_fn));if ((defined ($code)and ($code==(0x1eb0+ 329-0x1c12)))){return (
(0x04f8+ 6058-0x1ca2));}elsif (($code==$GLOBAL::MSG_UPNP_DELETE)){
main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");return (
NXUpnp::handleCodeDeleteUPnPMap ($socket_fn,$body));}elsif (($code==
$GLOBAL::MSG_UPNP_START)){main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");return (
NXUpnp::handleCodeStartUPnPMap ($socket_fn,$body));}elsif (($code==
$GLOBAL::MSG_UPNP_STOP)){main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");return (
NXUpnp::handleCodeStopUPnPMap ($socket_fn));}elsif (($code==
$GLOBAL::MSG_UPNP_STATUS_REQUEST)){main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
return (NXUpnp::handleCodeStatusUPnPMap ($socket_fn));}elsif (($code==
$GLOBAL::MSG_UPNP_MAPPING_SERVICE)){main::nxrequire ("\x4e\x58\x55\x70\x6e\x70")
;return (NXUpnp::handleUPnPSingleServiceMessage ($socket_fn,$body));}elsif ((
$code==$GLOBAL::MSG_MCM_START)){NXNodes::reloadNodesDB ();if (($body=~ /uuid=(\S+) / )
){(my $uuid=$1);NXLocalSession::startLocalSession ($uuid);}}elsif (($code==
$GLOBAL::MSG_MCM_STOP)){if (($body=~ /uuid=(\S+) / )){(my $uuid=$1);
NXLocalSession::stopMonitoring ($uuid);NXTerminate::terminateConnectionMonitor (
$uuid);}}elsif (($code==$GLOBAL::MSG_MCM_STANDBY)){
NXTerminate::terminateConnectionMonitors ();}elsif (($code==
$GLOBAL::MSG_MCM_FAILOVER)){NXNodes::reloadNodesDB ();
NXLocalSession::startConnectionMonitors ();}elsif (($code==
$GLOBAL::MSG_MCM_SESSION)){Logger::debug (((((
"\x52\x65\x63\x65\x69\x76\x65\x64\x3a\x20".$body).
"\x2e\x20\x43\x75\x72\x72\x65\x6e\x74\x6c\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20"
).$connected)."\x2e"));if (($body=~ /disconnected (\d*)/ )){(
$connectedToRemoteNodes=($connectedToRemoteNodes-$1));}elsif (($body=~ /connected (\d*)/ )
){($connectedToRemoteNodes=($connectedToRemoteNodes+$1));}}elsif (($code==
$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x2e\x20\x42\x6f\x64\x79\x20\x69\x73\x20\x27"
.$body)."\x27"));(my $answer=prepareAnswerWithServicesStatus ($body));if (
clientIsWaitingForReply ($socket_fn)){Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x69\x73\x20\x27"
.$answer)."\x27"));main::nxwrite ($socket_fn,$answer);}return (
(0x1d42+ 773-0x2047));}elsif (($code==
$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS_AND_RUN_IF_NEEDED)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x61\x6e\x64\x20\x72\x75\x6e\x20\x69\x66\x20\x6e\x65\x65\x64\x65\x64\x3a\x20"
.$body)."\x2e"));NXSystemDaemons::setEnabled ("\x6e\x78\x68\x74\x64");
NXSystemDaemons::setHandlingManualStart ("\x6e\x78\x68\x74\x64");
NXSystemDaemons::setEnabled ("\x6e\x78\x64");
NXSystemDaemons::setHandlingManualStart ("\x6e\x78\x64");if (
shouldNotWaitLocalSessionForStatusResponse ()){__runServicesIfNeeded ($body);}
else{Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x62\x65\x66\x6f\x72\x65\x20\x61\x6e\x79\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x73\x20\x73\x74\x61\x72\x74\x65\x64\x2e\x20\x57\x61\x69\x74\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2e"
);waitWithStatusResponseToNodeRun ($socket_fn,(0x1bad+ 1323-0x20c4),$body);
return ((0x0be0+ 6699-0x260a));}(my $answer=
__prepareAnswerWithServicesStatusForStartupDontWaitForLocalNode ($body));if (
clientIsWaitingForReply ($socket_fn)){Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x61\x6e\x64\x20\x72\x75\x6e\x20\x69\x66\x20\x6e\x65\x65\x64\x65\x64\x3a\x20"
.$answer)."\x2e"));main::nxwrite ($socket_fn,$answer);}return (
(0x074d+ 4250-0x17e7));}elsif (($code==$GLOBAL::MSG_ASK_FOR_DESKTOP_OWNER)){
Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x71\x75\x65\x72\x79\x20\x27"
.$body)."\x27\x2e"));if (clientIsWaitingForReply ($socket_fn)){(my $desktopOwner
=NXLocalSession::getActiveSessionOwner ());Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x69\x73\x20\x27"
.$desktopOwner)."\x27\x2e"));(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ASK_FOR_DESKTOP_OWNER).
"\x20\x44\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x69\x73\x20").
main::urlencode ($desktopOwner))."\x20"));(my $bytes=main::nxwrite ($socket_fn,
$message));if (($bytes==(-(0x0f9b+ 1370-0x14f4)))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x61\x6e\x73\x77\x65\x72\x2e"
);}}else{Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);}return ((0x0b26+ 4080-0x1b16));}elsif (($code==$GLOBAL::MSG_NXLOCATE_STOP)){
if (NXLocate::isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x77\x69\x6c\x6c\x20\x63\x6c\x6f\x73\x65\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e"
);if (($body eq "\x73\x74\x6f\x70")){NXLocate::close ();}else{
NXLocate::removeService ($body);}}}elsif (($code==$GLOBAL::MSG_NXLOCATE_START)){
if (NXLocate::isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x77\x69\x6c\x6c\x20\x72\x75\x6e\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e"
);if (($body eq "\x73\x74\x61\x72\x74")){NXLocate::run ();}else{
NXLocate::addService ($body);}}}elsif (($code==
$GLOBAL::MSG_NXD_COMMAND_TO_SERVER_STARTUP_MONITOR)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x4e\x58\x44\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));return (handleNXDCommand ($body,$socket_fn));}elsif (($code==
$GLOBAL::MSG_ADMIN_MODE)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x41\x64\x6d\x69\x6e\x20\x4d\x6f\x64\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));return (handleAdminModeCommand ($body,$socket_fn));}elsif ((
$code==$GLOBAL::MSG_UPDATE_IGNORE_TO_SERVER_STARTUP_MONITOR)){if (($body ne ("")
)){NXUpdate::setUpdateIgnoreMessage ($body);notifyClientIfStillAvailable (
$socket_fn,$GLOBAL::NXUPDATE_IGNORE_COMMAND_SUCCESS);return (
(0x0895+ 1700-0x0f39));}else{Logger::debug (
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x4e\x58\x75\x70\x64\x61\x74\x65\x20\x69\x67\x6e\x6f\x72\x65\x2e"
);return ((0x05eb+ 8262-0x2631));}}elsif (($code==
$GLOBAL::MSG_NXHTD_COMMAND_TO_SERVER_STARTUP_MONITOR)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x4e\x58\x48\x54\x44\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);return (handleNXHTDCommand ($body,$socket_fn));}elsif (($code==
$GLOBAL::MSG_REGISTER_LOCAL_NODE_IN_SERVER_STARTUP_MONITOR)){(my $logBody=($body
||("")));Logger::debug (((
"\x4e\x65\x77\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x77\x69\x74\x68\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$logBody)."\x2e"));NXLocalSession::handleRegisterLocalSession ($socket_fn,
NXNodes::findLocalNode (),$body,getServerSocketPort (),getServerSocketCookie ())
;}elsif (($code==
$GLOBAL::MSG_REGISTER_LOCAL_NODE_IN_SERVER_STARTUP_MONITOR_AFTER_SERVER_CRASH)){
(my $logBody=($body||("")));Logger::debug (((
"\x4c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x61\x66\x74\x65\x72\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x63\x72\x61\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$logBody)."\x2e"));
NXLocalSession::handleRegisterLocalSessionAfterServerDaemonCrash ($socket_fn,
$body);}elsif (($code==$GLOBAL::MSG_FOREIGN_NODE_COOKIE_DISPLAY)){Logger::debug 
(
"\x4e\x65\x77\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x63\x6f\x6f\x6b\x69\x65\x20\x61\x6e\x64\x20\x64\x69\x73\x70\x6c\x61\x79\x2e"
);NXForeignSession::handleCookieAndDisplayRetrieved ($socket_fn,$body);}elsif ((
$code==$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE)){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
);return (NXVirtualSession::createSessionNode ($socket_fn,$body));}elsif (($code
==$GLOBAL::MSG_ASK_ATTACH_ANSWER)){Logger::debug (
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2e"
);NXAsk4Attach::parseAuthorizationResponse ($body);}elsif (($code==
$GLOBAL::MSG_START_FRAME_BUFFER)){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x66\x72\x61\x6d\x65\x20\x62\x75\x66\x66\x65\x72\x2e"
);main::nxrequire ("\x4e\x58\x46\x72\x61\x6d\x65\x42\x75\x66\x66\x65\x72");
NXFrameBuffer::handleRequestToStartNxFrameBuffer ($socket_fn,$body);}elsif ((
$code==$GLOBAL::MSG_DESKTOP_SHARING)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));return (
NXUsersManager::sendSharingPhysicalToPhysicalSessionIfNeeded ($body,$socket_fn))
;}elsif (($code==$GLOBAL::MSG_ANYWHERE)){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
Logger::debug ((("\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20".Server::getAnywhereName 
()).((
"\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e")));NXAnywhereDefault::handleClientMessage ($body,
(0x0e2b+ 5198-0x2278));return ((0x1f68+ 1365-0x24bd));}elsif (($code==
$GLOBAL::MSG_USER_CONNECTION_TO_MACHINE)){if (($body eq 
"\x55\x73\x65\x72\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
handleDisconnectedFromMachine ();}elsif (($body eq 
"\x55\x73\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
handleConnectedToMachine ();}else{Logger::warning (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x77\x72\x6f\x6e\x67\x20\x75\x73\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27"
.$body)."\x27"));}return ((0x0cd2+ 4087-0x1cc8));}elsif (($code==
$GLOBAL::MSG_EMULATE_SYSTEM_EVENTS)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x65\x6d\x75\x6c\x61\x74\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x65\x76\x65\x6e\x74\x73\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);NXLocalSession::sendToActiveLocalNode ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_EMULATE_SYSTEM_EVENTS).
"\x20\x45\x6d\x75\x6c\x61\x74\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x65\x76\x65\x6e\x74\x73\x20"
));return ((0x0ded+ 530-0x0fff));}elsif (($code==
$GLOBAL::MSG_START_AUTOMATIC_RECORDING)){main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x72\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));NXAutomaticRecordingNode::startRecordSessionById ($body);return
 ((0x054b+ 7577-0x22e4));}elsif (($code==$GLOBAL::MSG_STOP_AUTOMATIC_RECORDING))
{main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x72\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));NXAutomaticRecordingNode::stopRecordSessionById ($body);return 
((0x0aac+ 6983-0x25f3));}elsif (
NXNodeExec::isMessageWithCodeHandledByServerSocket ($code)){Logger::debug (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);(my $function=NXNodeExec::getHandlerFunctionForMessageCodeFromServerSocket (
$code));Logger::debug ((((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x3a\x20".$code).
"\x20\x77\x69\x74\x68\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x3a\x20").$function));
&$function ($socket_fn,$line);Logger::debug (((
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x68\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x3a\x20"
.$code).
"\x20\x6f\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"))
;if ((((NXAsk4Attach::isAttachCandidate ($socket_fn)or 
NXAsk4Disconnect::isDisconnectCandidate ($socket_fn))or 
NXNodeConnectionMonitor::isNodeConnectionMonitorSocket ($socket_fn))or 
NXReconnect::isDisconnectSocket ($socket_fn))){return ((0x12ed+ 3400-0x2034));}
return ((0x1050+ 2770-0x1b22));}elsif (($code==$GLOBAL::MSG_CLUSTER_YIELD)){
Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x79\x69\x65\x6c\x64\x2e"
);main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");return (
NXClusterDaemon::acquire ($body,$socket_fn));}elsif (($code==
$GLOBAL::MSG_REDIS_YIELD)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x72\x65\x64\x69\x73\x20\x79\x69\x65\x6c\x64\x2e"
);return (NXRedis::daemonAcquire ($body,$socket_fn));}elsif ((($code==
$GLOBAL::MSG_OTP_CREATE)or ($code==$GLOBAL::MSG_OTP_AUTH))){if (
NXLicense::isServerAvailableAsRemoteServer ()){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6f\x6e\x65\x2d\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64");return (
NXOneTimePassword::parseMessage ($socket_fn,$body));}else{Logger::error (
"\x53\x65\x72\x76\x65\x72\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x74\x6f\x6b\x65\x6e\x20\x72\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x2e"
);return ((0x081a+ 2988-0x13c6));}}elsif (($code==
$GLOBAL::MSG_PROPAGATION_RULES_AND_SESSION_ID)){if (
NXLicense::isServerAvailableAsRemoteServer ()){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x20\x72\x75\x6c\x65\x73\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64");return (
NXOneTimePassword::parsePropagationRulesAndSessionIDRequest ($socket_fn,$body));
}}elsif (($code==$GLOBAL::MSG_NCM_NAME)){if (
NXLicense::isServerAvailableAsRemoteServer ()){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x6f\x72\x20\x74\x6f\x6b\x65\x6e\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64");return (
NXOneTimePassword::parseNCMNameRequest ($socket_fn,$body));}}elsif (($code==
$GLOBAL::MSG_2FA_REQUEST)){main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");return (
NXTwoFactorDaemon::parseMessage ($socket_fn,$body));}elsif (($code==
$GLOBAL::MSG_SUBSCRIBE_TO_DAEMON)){main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);return (NXDaemonSubscriptionManager::addSubscription ($socket_fn,$body));}
elsif (($code==$GLOBAL::MSG_CM_REVERSE_RUNNING)){main::nxrequire (
"\x4e\x58\x52\x65\x76\x65\x72\x73\x65\x43\x6c\x69\x65\x6e\x74\x44\x61\x65\x6d\x6f\x6e"
);return (NXReverseClientDaemon::handleConnection ($socket_fn,$body));}elsif ((
$code==$GLOBAL::MSG_DEBUG_LOG_LEVEL)){main::nxrequire (
"\x4e\x58\x44\x65\x62\x75\x67\x4d\x61\x6e\x61\x67\x65\x72");return (
NXDebugManager::handleDebugLogLevelMessage ($body));}elsif (($code==
$GLOBAL::MSG_MCM_START_SYSTEM_LOAD_SCRIPT)){saveReportSystemLoadReceivedFd (
$socket_fn);main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::runNXReportSystemLoadScript ();return ((0x002f+ 4823-0x1305));}elsif 
(($code==$GLOBAL::MSG_LICENSE_CHANGE)){NXLicense::handleLicenseChanged ();return
 ((0x0777+ 6149-0x1f7c));}elsif (($code==$GLOBAL::MSG_UPDATE_UUID)){if (($body=~ /newuuid=(\S+) olduuid=(\S+)/ )
){(my $uuid=$1);(my $oldUuid=$2);if ((($uuid ne (""))and ($oldUuid ne ("")))){
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setNewUuid (
$uuid,$oldUuid);NXConnectionMonitor::propagateMap ();}}return (
(0x09f3+ 4807-0x1cba));}elsif (($code==$GLOBAL::MSG_UPDATE_PARENT_UUID)){if ((
$body=~ /parent uuid change newuuid=(\S+) olduuid=(\S+)/ )){(my $uuid=$1);(my $oldUuid
=$2);if ((($uuid ne (""))and ($oldUuid ne ("")))){
NXLocalSession::updateConnectionMonitorUUIDs ($oldUuid,$uuid);
NXNodes::reloadNodesDB ();}return ((0x0ef9+ 2278-0x17df));}return (
(0x161f+ 2787-0x2102));}elsif (($code==$GLOBAL::MSG_ASK_FOR_NODEDEL_ON_PARENT)){
if (($body=~ /Delete node nodeuuid=(\S+) / )){(my $uuid=$1);if (($uuid ne ("")))
{NXNodes::runNodeDelForNodeRequest ($uuid);NXNodes::reloadNodesDB ();}}return (
(0x184b+ 2741-0x2300));}elsif (($code==$GLOBAL::MSG_TERMINATE_SESSION)){if ((
$body=~ /sessionID=(\S+) / )){(my $sessionID=$1);if (($sessionID ne (""))){
NXLocalSession::terminateLocalSession ($sessionID);}else{Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x65\x6d\x70\x74\x79\x20\x69\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$body)."\x27\x2e"));}}return ((0x18c4+ 519-0x1acb));}elsif (($code==
$GLOBAL::MSG_SOFTWARE_UPDATE)){main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);if (NXSoftwareUpdateDaemon::handleRequest ($socket_fn,$body)){return (
(0x0ac3+ 4010-0x1a6d));}removeFdFromSelector ($socket_fn);return (
(0x09e0+ 3956-0x1953));}elsif (($code==$GLOBAL::MSG_DAEMON_RESTART)){
NXSystemDaemons::handleRestartRequest ($socket_fn,$body);removeFdFromSelector (
$socket_fn);return ((0x0950+  93-0x09ac));}elsif (($code==
$GLOBAL::MSG_CHECK_GUESTS_EXPIRY_DATE)){checkGuestsExpiryDate ();}elsif (($code
==$GLOBAL::MSG_DAEMON_RUN_COMMAND_REQUEST)){return (runCommandAsDaemon (
$socket_fn,$body));}elsif (($code==$GLOBAL::MSG_CLUSTER_STATUS)){main::nxrequire
 ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");
NXClusterDaemon::handleStatusRequest ($socket_fn);return ((0x1906+ 2689-0x2387))
;}elsif (($code==$GLOBAL::UDP_COMMUNICATION)){main::nxrequire (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");if (
NXUdpControl::handleDaemonCommunicationRequest ($socket_fn,$body)){return (
(0x1a0f+ 2966-0x25a5));}removeFdFromSelector ($socket_fn);return (
(0x0064+ 9624-0x25fb));}elsif (($code==$GLOBAL::UDP_FORWARDER)){main::nxrequire 
("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
NXUdpControl::handleDaemonForwarderRequest ($socket_fn,$body);return (
(0x2373+ 220-0x244f));}elsif (($code==$GLOBAL::UDP_COMMUNICATION_CLOSE)){
main::nxrequire ("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
NXUdpControl::handleDaemonCommunicationCloseRequest ($socket_fn,$body);return (
(0x0d38+ 4229-0x1dbd));}else{(my $logBody=($body||("")));($logBody=
main::hideOutput ($logBody));Logger::debug (((((
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27".
$logBody)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$socket_fn)."\x2e"));return (
(0x0753+ 2253-0x1020));}}else{Logger::warning (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$logstr)."\x27\x2e"));}return ((0x0696+ 2114-0x0ed7));}sub handleNXDCommand{(my $body
=shift (@_));(my $socket_fn=shift (@_));if (($body eq $GLOBAL::NXD_COMMAND_START
)){if (NXSystemDaemons::isRunning ("\x6e\x78\x64")){notifyClientIfStillAvailable
 ($socket_fn,$GLOBAL::NXD_COMMAND_ALREADY_DONE);return ((0x0eb7+ 2211-0x175a));}
Server::updateMyCfg ();NXSystemDaemons::setEnabled ("\x6e\x78\x64");
NXSystemDaemons::setHandlingManualStart ("\x6e\x78\x64");NXSystemDaemons::start 
("\x6e\x78\x64");if (NXSystemDaemons::isRunning ("\x6e\x78\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_SUCCESS);if (
NXLocate::isNXLocateEnabled ()){NXLocate::addService ("\x6e\x78\x64");}return (
(0x0791+ 5456-0x1ce1));}else{notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXD_COMMAND_FAILURE);return ((0x06ba+ 978-0x0a8c));}}elsif (($body eq 
$GLOBAL::NXD_COMMAND_STOP)){if ((not (NXSystemDaemons::isRunning ("\x6e\x78\x64"
)))){notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_ALREADY_DONE)
;return ((0x110d+ 545-0x132e));}NXSystemDaemons::stop ("\x6e\x78\x64");if (
NXSystemDaemons::isRunning ("\x6e\x78\x64")){notifyClientIfStillAvailable (
$socket_fn,$GLOBAL::NXD_COMMAND_FAILURE);return ((0x11f5+ 1537-0x17f6));}else{
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_SUCCESS);if (
NXLocate::isNXLocateEnabled ()){NXLocate::removeService ("\x6e\x78\x64");}return
 ((0x167f+ 618-0x18e9));}}else{Logger::debug (
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x4e\x58\x44\x2e"
);return ((0x0157+ 4092-0x1153));}}sub handleAdminModeCommand{(my $body=shift (
@_));(my $socket=shift (@_));Logger::debug (((((
"\x68\x61\x6e\x64\x6c\x65\x20\x41\x64\x6d\x69\x6e\x20\x4d\x6f\x64\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$body)."\x20\x6f\x6e\x20\x46\x44\x23").$socket)."\x2e"));if (($body=~ /^enable (.*)/ )
){__handleEnableAdminMode ($1,$socket);}elsif (($body=~ /^disable (.*)/ )){
__handleDisableAdminMode ($1,$socket);}elsif (($body=~ /^connected (.*)/ )){
__handleConnectedSessionInAdminMode ($1,$socket);}elsif (($body=~ /^disconnected (.*)/ )
){handleDisconnectedSessionInAdminMode ($1,$socket);}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x77\x72\x6f\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$body)."\x2e"));}return ((0x1ddf+ 275-0x1ef2));}sub __handleEnableAdminMode{(my $sessionId
=shift (@_));(my $socket=shift (@_));NXSession2::setAdminModeBySessionId (
$sessionId,(0x03bc+ 7995-0x22f6));if (($sessionId eq Server::getMySessionID ()))
{($serversInAdminMode{$sessionId}=(-(0x0075+ 9342-0x24f2)));main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXConnectedUsersManager::sendAllAddedUserToClient ();}else{(my $fh=
main::send_command_to_server ($sessionId,($GLOBAL::MSG_ENABLE_ADMIN."\x20"),
"\x6e\x6f\x74\x63\x6c\x6f\x73\x65"));if (($fh==(-(0x0887+ 846-0x0bd4)))){
main::nxwrite ($socket,"\x66\x61\x69\x6c\x65\x64");return;}else{(
$serversInAdminMode{$sessionId}=$fh);}}(my $fd=main::nxopen ($adminModeFlag,(
$NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead)
+$NXBits::OthersRead)));if ((not (defined ($fd)))){main::nxwrite ($socket,
"\x66\x61\x69\x6c\x65\x64");}else{main::nxclose ($fd);main::nxwrite ($socket,
"\x64\x6f\x6e\x65");}}sub __handleDisableAdminMode{(my $sessionId=shift (@_));(my $socket
=shift (@_));if ((not (defined ($serversInAdminMode{$sessionId})))){
main::nxwrite ($socket,"\x6e\x6f\x74\x20\x65\x78\x69\x73\x74");}else{
NXSession2::setAdminModeBySessionId ($sessionId,(0x07a9+ 4182-0x17ff));if ((
$serversInAdminMode{$sessionId}!=(-(0x01f7+ 4107-0x1201)))){main::nxclose (
$serversInAdminMode{$sessionId});}($serversInAdminMode{$sessionId}=undef);delete
 ($serversInAdminMode{$sessionId});if ((not (%$serversInAdminMode))){unlink (
$adminModeFlag);}main::nxwrite ($socket,"\x64\x6f\x6e\x65");}}sub 
__handleConnectedSessionInAdminMode{(my $sessionId=shift (@_));(my $socket=shift
 (@_));foreach my $fh (values (%serversInAdminMode)){Logger::debug ((
"\x73\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x41\x64\x6d\x69\x6e\x20\x4d\x6f\x64\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$fh));if (($fh==(-(0x136d+ 244-0x1460)))){(my ($username,$ip,$createTime,
$display,$cookie,$client,$shadowMode,$nodeName,$type,$shadowModeCfg)=
NXSession2::getClientMonitorParameters ($sessionId));(my (%session)=(
"\x75\x73\x65\x72\x6e\x61\x6d\x65",$username,"\x49\x50",$ip,
"\x63\x72\x65\x61\x74\x69\x6f\x6e\x54\x69\x6d\x65",$createTime,
"\x64\x69\x73\x70\x6c\x61\x79",$display,"\x63\x6f\x6f\x6b\x69\x65",$cookie,
"\x63\x6c\x69\x65\x6e\x74",$client,"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65",
$shadowMode,"\x6e\x6f\x64\x65",$nodeName,
"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65\x43\x66\x67",$shadowModeCfg));
main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXConnectedUsersManager::sendAddUserToClient ((\%session));}else{if ((
main::nxwrite ($fh,(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ADMIN_MODE).
"\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20").$sessionId)."\x0a"))==(-
(0x0554+ 7171-0x2156)))){main::nxwrite ($socket,"\x66\x61\x69\x6c\x65\x64");}}}
main::nxwrite ($socket,"\x64\x6f\x6e\x65");}sub 
handleDisconnectedSessionInAdminMode{(my $message=shift (@_));(my $socket=shift 
(@_));foreach my $fh (values (%serversInAdminMode)){if (($fh==(-
(0x0bc0+ 6735-0x260e)))){main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXConnectedUsersManager::sendDelUserToClient ($message);}else{if ((
main::nxwrite ($fh,(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ADMIN_MODE).
"\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20").$message)."\x0a"))==
(-(0x1a91+ 700-0x1d4c)))){if (defined ($socket)){main::nxwrite ($socket,
"\x66\x61\x69\x6c\x65\x64");}}}}if (defined ($socket)){main::nxwrite ($socket,
"\x64\x6f\x6e\x65");}}sub handleNXHTDCommand{(my $body=shift (@_));(my $socket_fn
=shift (@_));if (($body eq $GLOBAL::NXHTD_COMMAND_START)){if (
NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_ALREADY_DONE);
return ((0x0091+ 389-0x0216));}NXSystemDaemons::setEnabled (
"\x6e\x78\x68\x74\x64");NXSystemDaemons::setHandlingManualStart (
"\x6e\x78\x68\x74\x64");NXSystemDaemons::start ("\x6e\x78\x68\x74\x64");if (
NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_SUCCESS);if (
NXLocate::isNXLocateEnabled ()){NXLocate::addService ("\x6e\x78\x68\x74\x64");}}
else{notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_FAILURE);}
return ((0x0274+ 3330-0x0f76));}elsif (($body eq $GLOBAL::NXHTD_COMMAND_STOP)){
if ((not (NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")))){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_ALREADY_DONE);
return ((0x1541+ 919-0x18d8));}NXSystemDaemons::stop ("\x6e\x78\x68\x74\x64");if
 (NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_FAILURE);}else{
if (NXLocate::isNXLocateEnabled ()){NXLocate::removeService (
"\x6e\x78\x68\x74\x64");}notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXHTD_COMMAND_SUCCESS);}return ((0x1711+ 1870-0x1e5f));}elsif (($body 
eq $GLOBAL::NXHTD_COMMAND_STATUS)){if (NXSystemDaemons::isRunning (
"\x6e\x78\x68\x74\x64")){notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXHTD_COMMAND_SUCCESS);}else{notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXHTD_COMMAND_FAILURE);}return ((0x21f1+ 1294-0x26ff));}else{
Logger::debug (
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x4e\x58\x48\x54\x44\x2e"
);return ((0x08ca+ 3474-0x165c));}}sub checkLocalSessionIsEnabled{if ((
NXNodes::isLocalNodeInDatabase ()and 
NXLocalSession::isPhysicalDesktopAvailableInConfig ())){return (
(0x0386+ 2625-0x0dc6));}return ((0x1f29+  63-0x1f68));}sub 
__prepareAnswerWithServicesStatusForStartupDontWaitForLocalNode{(my $list=shift 
(@_));return (__prepareAnswerWithServicesStatusForStartup ($list,
(0x117d+ 680-0x1424)));}sub 
__prepareAnswerWithServicesStatusForStartupOrWaitForLocalNode{(my $list=shift (
@_));return (__prepareAnswerWithServicesStatusForStartup ($list,
(0x0277+ 7950-0x2185)));}sub __prepareAnswerWithServicesStatusForStartup{(my $list
=shift (@_));(my $dontWait=shift (@_));if ((not (defined ($dontWait)))){(
$dontWait=(0x08bf+ 4088-0x18b7));}(my (@services)=split ( / / ,$list,
(0x0975+ 2495-0x1334)));(my $answer=("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS_AND_RUN_IF_NEEDED));foreach my $service (
@services){($answer.=(("\x20".$service)."\x20"));if (($service eq 
"\x6e\x78\x6e\x6f\x64\x65")){(my $nodeShouldBeRunning=checkLocalSessionIsEnabled
 ());if ($nodeShouldBeRunning){if (NXLocalSession::localSessionsRunning ()){(
$answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{if ($dontWait){($answer.=
"\x4e\x6f\x74\x52\x75\x6e\x6e\x69\x6e\x67");}else{return (undef);}}}else{(
$answer.="\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{if (
NXSystemDaemons::isServiceEnabled ($service)){if (NXSystemDaemons::isRunning (
$service,(0x1f2d+  54-0x1f62))){($answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{
($answer.="\x4e\x6f\x74\x52\x75\x6e\x6e\x69\x6e\x67");}}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}($answer.="\x2c");}($answer=~ s/,$// );(
$answer.="\x0a");return ($answer);}sub __runServicesIfNeededExceptNode{(my $list
=shift (@_));($list=~ s/ nxnode// );($list=~ s/nxnode // );($list=~ s/nxnode// )
;return (__runServicesIfNeeded ($list));}sub __runServicesIfNeeded{(my $list=
shift (@_));(my (@services)=split ( / / ,$list,(0x1c2c+ 2602-0x2656)));foreach my $service
 (@services){if (($service eq "\x6e\x78\x6e\x6f\x64\x65")){();}else{if (
NXSystemDaemons::isServiceEnabled ($service)){NXSystemDaemons::setSilentMode (
$service);checkServiceAndRestartIfNecessary ($service);}}}return (
(0x0d1a+ 2741-0x17ce));}sub prepareAnswerWithServicesStatus{(my $list=shift (@_)
);(my $answer=("\x4e\x58\x3e\x20".$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS));(my (
@services)=split ( / / ,$list,(0x05a8+ 2043-0x0da3)));foreach my $service (
@services){($answer.=(("\x20".$service)."\x20"));if (($service eq 
"\x6e\x78\x6e\x6f\x64\x65")){(my $nodeShouldBeRunning=checkLocalSessionIsEnabled
 ());if ($nodeShouldBeRunning){if (NXLocalSession::localSessionsRunning ()){(
$answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{if (NXSystemDaemons::isServiceEnabled
 ($service)){if (NXSystemDaemons::isRunning ($service,(0x1402+ 3391-0x2140))){(
$answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}($answer.="\x2c");}($answer=~ s/,$// );(
$answer.="\x0a");return ($answer);}sub getPort{return (getServerSocketPort ());}
sub getCookie{return (getServerSocketCookie ());}sub delaySessionList{
Logger::debug (
"\x53\x63\x68\x65\x64\x75\x6c\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6c\x69\x73\x74\x20\x61\x73\x20\x73\x6f\x6f\x6e\x20\x61\x73\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x2e"
);($checkLocalSessionDelayed=(0x2303+ 197-0x23c7));}sub 
checkIsTimeForNewSessionList{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=
getCheckLocalSessionLoopDelay ());if ($checkLocalSessionScheduled){(
$lastCheckLocalSessionTime=$currentTime);($checkLocalSessionScheduled=
(0x01c3+ 8238-0x21f1));return ((0x1b30+ 1556-0x2143));}if (((
$lastCheckLocalSessionTime+$delay)<$currentTime)){if ($checkLocalSessionDelayed)
{($checkLocalSessionDelayed=(0x0ff5+ 2143-0x1854));}($lastCheckLocalSessionTime=
$currentTime);return ((0x1963+ 1613-0x1faf));}else{return ((0x1433+ 1788-0x1b2f)
);}}sub initializeCheckLocalSessionTime{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());($lastCheckLocalSessionTime=
$currentTime);}sub getCheckLocalSessionLoopDelay{(my $delay=
$checkLocalSessionLoopDelay[$currentCheckLocalSessionLoopDelay]);if (
$checkLocalSessionDelayed){($delay=$GLOBAL::checkLocalSessionDelay);}return (
$delay);}sub increaseCheckLocalSessionLoopDelay{if (((
$currentCheckLocalSessionLoopDelay+(0x0ce3+ 1936-0x1472))<scalar (
@checkLocalSessionLoopDelay))){($currentCheckLocalSessionLoopDelay+=
(0x04f7+ 2765-0x0fc3));}}sub restartCheckLocalSessionDelayCounter{(
$currentCheckLocalSessionLoopDelay=(0x08ff+ 4379-0x1a1a));}sub 
isAnyLocalSessionFound{if (($currentCheckLocalSessionLoopDelay==
(0x05cf+ 458-0x0799))){return ((0x0177+ 1503-0x0755));}else{return (
(0x1387+ 3528-0x214f));}}sub isTerminateMode{return ($terminateMode);}sub 
setTerminateMode{($terminateMode=(0x0d94+ 1996-0x155f));($terminateReceivedTime=
Common::NXTime::getSecondsSinceEpoch ());Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x6d\x6f\x64\x65\x2e"
);}sub getNewTimeoutForRead{(my $time=Common::NXTime::getSecondsSinceEpoch ());my (
$newTimeout);if (isTerminateMode ()){($newTimeout=((($terminateReceivedTime+
$GLOBAL::timeoutForLocalSessionTerminate)-$time)*(0x100d+ 590-0x0e73)));}else{(
$newTimeout=($servicesMonitoringDelay *(0x08da+ 1462-0x0aa8)));Logger::debug (((
"\x4e\x65\x78\x74\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x63\x68\x65\x63\x6b\x20\x69\x6e\x20"
.$newTimeout)."\x20\x6d\x73\x2e"));if (NXClusterDaemon::isStartupInProgress ()){
(my $clusterDelay=NXClusterDaemon::getTimeoutForStartup ());if (($newTimeout>
$clusterDelay)){($newTimeout=$clusterDelay);}}if (
NXUpnp::isRepeatMappingInProgress ()){(my $upnpDelay=
NXUpnp::getTimeoutForRepeatMapping ());if (($newTimeout>$upnpDelay)){(
$newTimeout=$upnpDelay);}}}if (($newTimeout<(0x0108+ 7470-0x1e35))){($newTimeout
=(0x0a83+ 6134-0x2215));}Logger::debug (((
"\x4e\x65\x77\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20".$newTimeout).
"\x20\x6d\x73\x2e"));return ($newTimeout);}sub serverSocket_parser{(my $socket=
getServerSocket ());if (defined ($socket)){(my $new_sock=main::nxAcceptSocket (
$socket));addAcceptedFdToSystemSelector ($new_sock);}}sub 
serverSocketAccepted_parser{(my $f=shift (@_));(my $auth=
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64");if ((isAuthorizedConnectionOnFD ($f)
==(0x05e0+ 4151-0x1617))){($auth=
"\x75\x6e\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64");}Logger::debug (((((((
"\x53\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x70\x61\x72\x73\x65\x72\x20\x66\x6f\x72\x20"
.$auth)."\x20\x46\x44\x23").$f)."\x20\x27").$listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$f}{
"\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"})."\x27\x2e"));if (
isDefinedClientHandlerOnSocket ($f)){(my $readBuffer=(""));(my $bufferSize=
(0x147b+ 3193-0x10f4));(my $readSize=$bufferSize);while (($readSize==$bufferSize
)){(my $read=(""));($readSize=main::nxread ($f,(\$read),$bufferSize));(
$readBuffer.=$read);}if (((not (defined ($readSize)))or ($readSize==
(0x091d+ 6477-0x226a)))){main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
main::nxrequire ("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");
main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);Logger::debug (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23".$f).
"\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));removeClientFDFromSelector 
($f);if (NXLocalSession::isLocalNodeSocket ($f)){
NXLocalSession::handleLocalNodeClosedSocket ($f);}elsif (
isSocketWaitingForLocalNodeStatus ($f)){
handleSocketWaitingForLocalNodeStatusClosed ($f);}elsif (
NXNodeConnectionMonitor::isNodeConnectionMonitorSocket ($f)){
NXNodeConnectionMonitor::handleConnectionToNCMLost ($f);}elsif (
NXTwoFactorDaemon::isRequestSocket ($f)){NXTwoFactorDaemon::handleSocketClosed (
$f);}elsif (NXDaemonSubscriptionManager::isSubscriptionSocket ($f)){
NXDaemonSubscriptionManager::handleCloseSubscription ($f);}elsif (
NXUpnp::isUPnPSocket ($f)){NXUpnp::handleUPnPSocketOnClose ($f);}elsif (
isReportSystemLoadFD ($f)){removeReportSystemLoadFD ($f);}elsif (
NXUdpControl::isRequestSocket ($f)){NXUdpControl::handleRequestSocketOnClose ($f
);}main::nxclose ($f);}else{(my $logLine=main::hideOutput ($readBuffer));
Logger::debug ((((((("\x52\x65\x61\x64\x20\x27".$logLine)."\x27\x2c\x20").
$readSize)."\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").$f).
"\x2e"));if ((isAuthorizedConnectionOnFD ($f)==(0x0d90+ 2344-0x16b8))){
Logger::debug ((("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x46\x44\x23".$f).
"\x20\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x2c\x20\x79\x65\x74\x2e"
));if ((handleSlaveMessage ($readBuffer,$f)==(0x1900+ 2575-0x230e))){return;}if 
((handleUnauthorizedConnection ((\$readBuffer),$f)==(0x02ff+ 7662-0x20ed))){
return;}}if (NXLocalSession::isLocalNodeSocket ($f)){addToAcceptFDBuffer ($f,
$readBuffer);(my $FDBuffer=getAcceptFDBuffer ($f));clearAcceptFDBuffer ($f);
parseLocalNodeSocket ($f,$FDBuffer);return;}else{addToAcceptFDBuffer ($f,
$readBuffer);}while (isCommandToParseInFDBuffer ($f)){if ((parseServerMonitor (
$f)==(0x1e4d+ 1344-0x238d))){removeClientFDFromSelector ($f);clearAcceptFDBuffer
 ($f);main::nxclose ($f);next;}if (NXLocalSession::isLocalNodeSocket ($f)){(my $FDBuffer
=getAcceptFDBuffer ($f));clearAcceptFDBuffer ($f);parseLocalNodeSocket ($f,
$FDBuffer);}}}return;}else{Logger::warning (((
"\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x41\x63\x63\x65\x70\x74\x65\x64\x5f\x70\x61\x72\x73\x65\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x61\x6e\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x61\x63\x63\x65\x70\x74\x65\x64\x20\x68\x61\x6e\x64\x6c\x65\x3a\x20\x27"
.$f)."\x27\x2e"));}}sub handleUnauthorizedConnection{(my $bufferRef=shift (@_));
(my $f=shift (@_));Logger::debug (((
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$f)."\x2e"));(my $cookie=substr ($$bufferRef,(0x0998+ 4244-0x1a2c),length ((
"\x4e\x58\x3e\x20".getServerSocketCookie ()))));($$bufferRef=substr ($$bufferRef
,length (("\x4e\x58\x3e\x20".getServerSocketCookie ()))));($cookie=~ s/NX> // );
if (isServerSocketCookie ($cookie)){Logger::debug (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6f\x6e\x20\x46\x44\x23"
.getClientHandler ($f))."\x2e"));authorizeConnectionOnFD ($f);($$bufferRef=~ s/NX> $cookie// )
;if (((not (defined ($$bufferRef)))or ($$bufferRef eq ("")))){return (
(0x01d8+ 5985-0x1939));}($$bufferRef=~ s/^\n// );if ((not (($$bufferRef=~ /^NX>/ )
))){($$bufferRef=("\x4e\x58\x3e".$$bufferRef));}return ((0x169a+ 3023-0x2268));}
else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$f)."\x2e"));removeClientFDFromSelector ($f);main::nxclose ($f);return (
(0x0c28+ 2766-0x16f6));}}sub handleSlaveMessage{(my $buffer=shift (@_));(my $f=
shift (@_));if (($buffer=~ /^NXCLIENT-(.*) cookie=(.*),command=get,target=local,option=(.*)/ )
){Logger::debug (
"\x53\x6c\x61\x76\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x2e"
);SlaveServer::handleGetCommand ($f,$buffer);return ((0x06c3+ 6431-0x1fe1));}}
sub stopServerDaemonListen{if (defined ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){
Common::NXSelector::removeFromGlobalSelector ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"});main::nxclose ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"});}if ((defined ($listenSocket{
"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"})and ($listenSocket{
"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}ne ("")))){(my $fileName=((
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}.
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));unlink ($fileName);
Logger::debug ((("\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20".$fileName).
"\x20\x66\x69\x6c\x65"));($fileName=(($listenSocket{
"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}.$GLOBAL::DIRECTORY_SLASH).
"\x70\x6f\x72\x74"));unlink ($fileName);Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20".$fileName)."\x20\x66\x69\x6c\x65"));(
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}=(""));}(my $path=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").$GLOBAL::DIRECTORY_SLASH
)."\x73\x65\x72\x76\x65\x72"));(my $redisPortFile=main::get_redis_port ($path));
unlink ($redisPortFile);libnxhs::NXRedisServerListenerDestroy ();}sub 
removeServerDaemonPidFile{if (($ServerDaemonLockFileHandle!=(-
(0x18a9+ 1971-0x205b)))){main::nxclose ($ServerDaemonLockFileHandle);(
$ServerDaemonLockFileHandle=(-(0x21f6+ 398-0x2383)));}(my $filename=
$GLOBAL::ServerDaemonLockFilePath);if ((Common::NXFile::isExists ($filename)and 
(not (unlink ($filename))))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$filename)."\x3a\x20").$!));}else{Logger::debug (((
"\x55\x6e\x6c\x69\x6e\x6b\x65\x64\x20\x66\x69\x6c\x65\x20".$filename)."\x2e"));}
}sub setServerDaemonLockFileHandle{($ServerDaemonLockFileHandle=shift (@_));}sub
 __startServerDaemonListen{if (((not (defined ($listenSocket{"\x70\x6f\x72\x74"}
)))or ($listenSocket{"\x70\x6f\x72\x74"}eq ("")))){($listenSocket{
"\x70\x6f\x72\x74"}=NXTools::getUniquePort ());if (($listenSocket{
"\x70\x6f\x72\x74"}<(0x04ad+ 5793-0x1b4e))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x6c\x69\x73\x74\x65\x6e\x69\x6e\x67\x2e"
);return ((0x08d5+ 4295-0x199c));}}if (((not (defined ($listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"})))or ($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}eq 
("")))){($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}=main::get_unique_id ());}if (
((not (defined ($listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"})))or (
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}eq ("")))){(
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}=
__saveServerDaemonOptionsFile ());}($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"}=main::nxListenOnSocket ($listenSocket{
"\x70\x6f\x72\x74"}));if (($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"}<
(0x0977+ 1738-0x1041))){($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"}=undef
);return ((0x06da+ 2638-0x1128));}addServerSocketToSelector ();Logger::debug (((
"\x53\x74\x61\x72\x74\x65\x64\x20\x6c\x69\x73\x74\x65\x6e\x69\x6e\x67\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20"
.$listenSocket{"\x70\x6f\x72\x74"})."\x2e"));
libnxhs::NXRedisServerListenerCreate (Logger::setLogFile (),
$GLOBAL::SessionLogLevel,NXTools::getUniquePort (),$listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"});return ((0x027c+ 5654-0x1891));}sub 
__saveServerDaemonOptionsFile{(my $path=(((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x64\x62").$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72"));(my $serverDaemonCookieFile=(($path.
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));(my $serverDaemonPortFile
=(($path.$GLOBAL::DIRECTORY_SLASH)."\x70\x6f\x72\x74"));(my $OPF=main::nxopen (
$serverDaemonCookieFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),
$NXBits::UserReadWrite));if ((not (defined ($OPF)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".
$serverDaemonCookieFile)."\x2e"));Logger::debug (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));return;}main::nxwrite ($OPF,$listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"});main::nxclose ($OPF);($OPF=main::nxopen (
$serverDaemonPortFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),
$NXBits::UserReadWrite));if ((not (defined ($OPF)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".
$serverDaemonPortFile)."\x2e"));Logger::debug (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));return;}main::nxwrite ($OPF,$listenSocket{
"\x70\x6f\x72\x74"});main::nxclose ($OPF);return ($path);}sub getServerSocket{
return ($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"});}sub 
removeSocketFromMonitoring{(my $socket=shift (@_));Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x46\x44\x23".$socket).
"\x20\x66\x72\x6f\x6d\x20\x64\x61\x65\x6d\x6f\x6e\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
));$selector->remove ($socket);Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x46\x44\x23".$socket).
"\x20\x66\x72\x6f\x6d\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
));Common::NXSelector::removeFromGlobalSelector ($socket);delete ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$socket});}sub 
removeSocketFromMonitoringIfExist{(my $socket=shift (@_));if (defined ($selector
)){if ($selector->exists ($socket)){removeSocketFromMonitoring ($socket);return 
((0x0272+ 4749-0x14fe));}}return ((0x1343+ 2962-0x1ed5));}sub addFdToSelector{(my $new_sock
=shift (@_));if ((defined ($new_sock)and ($new_sock ne ("")))){if (defined (
$listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){$selector->add ($new_sock);}
}}sub isClientFDInSelector{(my $socket=shift (@_));if ((defined ($selector)and (
$socket ne ("")))){if ($selector->exists ($socket)){return (
(0x0155+ 8282-0x21ae));}}return ((0x0bcb+ 5767-0x2252));}sub 
removeClientFDFromSelector{(my $socket=shift (@_));if ((defined ($socket)and (
$socket ne ("")))){if (defined ($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"
})){$selector->remove ($socket);Common::NXSelector::removeFromGlobalSelector (
$socket);delete ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$socket});}}}sub 
removeFdFromSelector{(my $socket=shift (@_));if ((defined ($socket)and ($socket 
ne ("")))){if (defined ($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){
$selector->remove ($socket);}}}sub addServerSocketToSelector{if (defined (
$listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){$selector->add (
$listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"});
Common::NXSelector::addToGlobalSelector ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"},
"\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x27\x73\x20\x73\x6f\x63\x6b\x65\x74"
,
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x3a\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x5f\x70\x61\x72\x73\x65\x72"
);}}sub addAcceptedFdToSystemSelector{(my $new_sock=shift (@_));(my $description
=(shift (@_)||"\x72\x65\x67\x75\x6c\x61\x72\x20\x68\x61\x6e\x64\x6c\x65"));if ((
defined ($new_sock)and ($new_sock ne ("")))){Logger::debug (((
"\x41\x63\x63\x65\x70\x74\x65\x64\x20\x6e\x65\x77\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$new_sock)."\x2e"));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x66\x6f\x72\x20\x46\x44\x23"
.$new_sock).
"\x20\x74\x6f\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x69\x6e\x67\x20\x68\x61\x73\x68\x2e"
));($listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$new_sock}={"\x66\x68",$new_sock,"\x61\x63\x63\x65\x70\x74\x65\x64",
(0x0d3f+ 6143-0x253e),"\x62\x75\x66\x66\x65\x72",(""),
"\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e",$description,
"\x70\x61\x72\x73\x69\x6e\x67",(0x1e56+ 1275-0x2351)});$selector->add ($new_sock
);Common::NXSelector::addToGlobalSelector ($new_sock,
"\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x27\x73\x20\x73\x6f\x63\x6b\x65\x74\x20\x61\x63\x63\x65\x70\x74\x65\x64\x20\x68\x61\x6e\x64\x6c\x65"
,
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x3a\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x41\x63\x63\x65\x70\x74\x65\x64\x5f\x70\x61\x72\x73\x65\x72"
);}}sub authorizeConnectionOnFD{(my $socketToAuthorize=shift (@_));(
$listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$socketToAuthorize}{"\x61\x63\x63\x65\x70\x74\x65\x64"}=(0x0127+ 1185-0x05c7));}
sub isAuthorizedConnectionOnFD{(my $socketToAuthorize=shift (@_));return (
$listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$socketToAuthorize}{"\x61\x63\x63\x65\x70\x74\x65\x64"});}sub 
isDefinedClientHandlerOnSocket{(my $socket=shift (@_));if (defined (
$listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$socket})){return ((0x0717+ 5771-0x1da1));}return ((0x0750+ 5439-0x1c8f));}sub 
clientIsWaitingForReply{(my $clientSocket=shift (@_));(my $socket=$listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$clientSocket});if (
(defined ($socket)and ($socket ne ("")))){return ((0x057c+ 6216-0x1dc3));}return
 ((0x1c04+ 2594-0x2626));}sub notifyClientIfStillAvailable{(my $socket=shift (@_
));(my $msg=shift (@_));if (clientIsWaitingForReply ($socket)){main::nxwrite (
$socket,$msg);}}sub addDBusIfEnabled{if (NXDbusMonitor::isRunning ()){
addFdToSelector (NXDbusMonitor::getStdout ());Logger::debug (
"\x41\x64\x64\x65\x64\x20\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x68\x61\x6e\x64\x6c\x65\x20\x74\x6f\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
);}else{Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);}}sub getServerSocketPort{return ($listenSocket{"\x70\x6f\x72\x74"});}sub 
getServerSocketCookie{if (((not (defined ($listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"})))or ($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}eq 
("")))){($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}=main::get_unique_id ());}
return ($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"});}sub isServerSocketCookie{(my $cookie
=shift (@_));if (($cookie eq $listenSocket{"\x63\x6f\x6f\x6b\x69\x65"})){return 
((0x0da1+ 5712-0x23f0));}return ((0x25c0+ 127-0x263f));}sub isAcceptFDParsing{(my $fd
=shift (@_));if (defined ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"})){return ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"});}else{return ((0x0b5c+ 1504-0x113c));}}sub 
setAcceptFDParsing{(my $fd=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"}=(0x034a+ 2432-0x0cc9));}sub clearAcceptFDParsing
{(my $fd=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"}=(0x0251+ 7881-0x211a));}sub clearAcceptFDBuffer{
(my $fd=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}=(""));}sub getAcceptFDBuffer{(my $fd=shift (@_));
return ($listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"
}{$fd}{"\x62\x75\x66\x66\x65\x72"});}sub isCommandToParseInFDBuffer{(my $fd=
shift (@_));if (((defined ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"})and ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}ne ("")))and ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}=~ /\n/ ))){return ((0x17cd+ 2208-0x206c));}return (
(0x1e37+ 1970-0x25e9));}sub addToAcceptFDBuffer{(my $fd=shift (@_));(my $buffer=
shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}.=$buffer);}sub setAcceptFDBuffer{(my $fd=shift (@_))
;(my $buffer=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}=$buffer);}sub getClientHandler{(my $f=shift (@_));
return ($listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"
}{$f}{"\x66\x68"});}sub waitWithStatusResponseToNodeRun{(my $socket_fn=shift (@_
));(my $timeout=shift (@_));(my $serviceName=shift (@_));Logger::debug (((
"\x77\x61\x69\x74\x57\x69\x74\x68\x53\x74\x61\x74\x75\x73\x52\x65\x73\x70\x6f\x6e\x73\x65\x54\x6f\x4e\x6f\x64\x65\x52\x75\x6e\x3a\x20\x57\x61\x69\x74\x20\x74\x6f\x20\x72\x65\x67\x69\x73\x74\x65\x72\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20"
.$timeout)."\x2e"));__addClientDescriptorWaitingForLocalNodeStatus ($socket_fn,
$timeout,$serviceName);}sub checkWaitingToLocalNodeRunWithSendStatus{(my $currectTime
=Common::NXTime::getSecondsSinceEpoch ());foreach my $socket (keys (
%$clientDescriptorsWaitingForStatusReport)){(my $timestamp=
__getTimestampForSocketWaitingForLocalNodeStatus ($socket));if (($currectTime>
$timestamp)){__raportServicesStatusAndCloseConnection ($socket);}}}sub 
handleSocketWaitingForLocalNodeStatusClosed{(my $socket=shift (@_));if (((
$socket ne (""))and ($socket!=(-(0x0a35+ 904-0x0dbc))))){
__removeSocketWaitingForLocalNodeStatus ($socket);}}sub 
__raportServicesStatusAndCloseConnection{(my $socket=shift (@_));(my $services=
__getServicesWaitingForLocalNodeStatus ($socket));
__removeSocketWaitingForLocalNodeStatus ($socket);
__runServicesIfNeededExceptNode ($services,(0x0f5c+ 4799-0x221a));if (
clientIsWaitingForReply ($socket)){(my $answer=
__prepareAnswerWithServicesStatusForStartupDontWaitForLocalNode ($services));
Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x69\x73\x20\x27"
.$answer)."\x27"));main::nxwrite ($socket,$answer);}clearAcceptFDBuffer ($socket
);removeClientFDFromSelector ($socket);main::nxclose ($socket);}sub 
responseToAllServicesStatusAndCloseConnection{if (
shouldNotWaitLocalSessionForStatusResponse ()){foreach my $socket (keys (
%$clientDescriptorsWaitingForStatusReport)){
__raportServicesStatusAndCloseConnection ($socket);}}}sub 
__addClientDescriptorWaitingForLocalNodeStatus{(my $socket=shift (@_));(my $timeout
=shift (@_));(my $serviceName=shift (@_));(my $timestamp=
Common::NXTime::getSecondsSinceEpoch ());($timestamp=($timestamp+$timeout));(
$$clientDescriptorsWaitingForStatusReport{$socket}={
"\x73\x65\x72\x76\x69\x63\x65\x73",$serviceName,
"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70",$timestamp});}sub 
__getServicesWaitingForLocalNodeStatus{(my $socket=shift (@_));return (
$$clientDescriptorsWaitingForStatusReport{$socket}{
"\x73\x65\x72\x76\x69\x63\x65\x73"});}sub 
__getTimestampForSocketWaitingForLocalNodeStatus{(my $socket=shift (@_));return 
($$clientDescriptorsWaitingForStatusReport{$socket}{
"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"});}sub isSocketWaitingForLocalNodeStatus{
(my $socket=shift (@_));if (defined ($$clientDescriptorsWaitingForStatusReport{
$socket})){return ((0x0ecd+ 3133-0x1b09));}return ((0x16c1+ 517-0x18c6));}sub 
__removeSocketWaitingForLocalNodeStatus{(my $socket=shift (@_));delete (
$$clientDescriptorsWaitingForStatusReport{$socket});}sub 
__isWaitingForLocalNodeRun{if (scalar (keys (
%$clientDescriptorsWaitingForStatusReport))){return ((0x0b92+ 3310-0x187f));}
return ((0x0df7+ 524-0x1003));}sub isAdminModeEnabled{if (
Common::NXFile::isExists ($adminModeFlag)){return ((0x0158+ 6846-0x1c15));}
return ((0x15ad+ 1007-0x199c));}sub getConnectionNumber{return (
$connectedToRemoteNodes);}sub getConnectionToLocalhostNumber{return (
$connectedToLocalhost);}sub setConnectionToLocalhostNumber{(my $connections=
NXSession2::getConnectionsToLocalhostWithSession ());($connectedToLocalhost=
$connections);}sub __setDaemonInitializing{($initializing=(0x0740+ 2531-0x1122))
;}sub __setDaemonInitialized{($initializing=(0x0dd1+ 4051-0x1da4));}sub 
isDaemonInitialized{if (($initializing==(0x02d1+ 342-0x0427))){return (
(0x2193+ 428-0x233e));}return ((0x09f2+ 758-0x0ce8));}sub 
shouldNotWaitLocalSessionForStatusResponse{if (((not (checkLocalSessionIsEnabled
 ()))or NXLocalSession::isAnyLocalSessionStarted ())){return (
(0x0422+ 7715-0x2244));}return ((0x083a+ 5718-0x1e90));}sub 
saveServerDaemonLangEnvInDb{(my $envLang=libnxh::NXTransGetEnvironment (
"\x4c\x41\x4e\x47"));if ((defined ($envLang)and ($envLang ne ("")))){
NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x65\x6e\x76\x2e\x6c\x61\x6e\x67\x2c\x76\x61\x6c\x75\x65\x3d"
.$envLang)."\x0a"));}}sub handleDisconnectedFromMachine{($connectedToLocalhost-=
(0x08b6+ 1946-0x104f));main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
NXAnywhereDefault::sendConnections ($connectedToLocalhost);}sub 
handleConnectedToMachine{($connectedToLocalhost+=(0x0cdc+ 2135-0x1532));
main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
NXAnywhereDefault::sendConnections ($connectedToLocalhost);}((%systemLoadFds)=()
);sub saveReportSystemLoadReceivedFd{(my $FD=shift (@_));Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x61\x76\x65\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x46\x44\x23"
.$FD)."\x2e"));($systemLoadFds{$FD}=$FD);}sub isReportSystemLoadRequestReceived{
if (%systemLoadFds){Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);return ((0x13db+ 1766-0x1ac0));}Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x4e\x6f\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);return ((0x1d9b+   7-0x1da2));}sub isReportSystemLoadFD{(my $FD=shift (@_));if
 ((defined ($systemLoadFds{$FD})and ($systemLoadFds{$FD}>(0x09ea+ 2564-0x13ee)))
){Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x46\x44\x23".
$FD).
"\x20\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
));return ((0x102d+ 3361-0x1d4d));}return ((0x078f+ 2698-0x1219));}sub 
removeReportSystemLoadFD{(my $FD=shift (@_));Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x46\x44\x23"
.$FD)."\x2e"));($systemLoadFds{$FD}=undef);delete ($systemLoadFds{$FD});if ((not
 (NXScripts::isRunNXReportSystemLoadScriptEnabled ()))){
NXScripts::terminateNXReportSystemLoadScriptIfRunning ();}}sub 
setSendErrorToAdmin{($errorToAdmin=shift (@_));}sub getErrorToAdmin{return (
$errorToAdmin);}sub isSendErrorToAdminMode{if (($errorToAdmin eq (""))){return (
(0x0b09+ 5815-0x21c0));}return ((0x0278+ 1339-0x07b2));}sub 
checkGuestsExpiryDate{Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x67\x75\x65\x73\x74\x73\x20\x65\x78\x70\x69\x72\x79\x20\x64\x61\x74\x65\x2e"
);(my (@keys)=());(my (@arguments)=());push (@arguments,
"\x67\x75\x65\x73\x74\x73");main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x63\x72\x69\x70\x74");(my $returnValue=
NXRedisScript::executeScript (
"\x67\x65\x74\x41\x6c\x6c\x44\x61\x74\x61\x46\x72\x6f\x6d\x53\x65\x74",(\@keys),
(\@arguments)));($returnValue=~ s/^"// );($returnValue=~ s/"$// );(my (
@guestsData)=split ( /" "/ ,$returnValue,(0x1d3f+ 318-0x1e7d)));(my $current=
Common::NXTime::getSecondsSinceEpoch ());foreach my $guest (@guestsData){if (((
$guest=~ /^\s*$/ )or ($guest eq ("")))){Logger::warning (
"\x4e\x6f\x64\x65\x20\x67\x6f\x74\x20\x63\x6f\x72\x72\x75\x70\x74\x65\x64\x20\x64\x61\x74\x61\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);next;}(my (%hash)=split ( / / ,$guest,(0x1368+ 2816-0x1e68)));if (($hash{
"\x65\x78\x70\x69\x72\x65"}le $current)){Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x65\x78\x70\x69\x72\x65\x64\x20\x75\x73\x65\x72\x20"
.$hash{"\x6c\x6f\x67\x69\x6e"})."\x2e"));NXShell::handle_command (
"\x67\x75\x65\x73\x74\x64\x65\x6c",$hash{"\x6c\x6f\x67\x69\x6e"});}elsif ((not (
NXEvent::isEventExist (NXEvent::getGuestExpiryDateEventName ($hash{
"\x6c\x6f\x67\x69\x6e"}))))){Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x6e\x65\x77\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20\x67\x75\x65\x73\x74\x20"
.$hash{"\x6c\x6f\x67\x69\x6e"})."\x2e"));NXEvent::createEventOnTimeAndSubscribe 
(NXEvent::getGuestExpiryDateEventName ($hash{"\x6c\x6f\x67\x69\x6e"}),$hash{
"\x65\x78\x70\x69\x72\x65"},
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x3a\x61\x66\x74\x65\x72\x47\x75\x65\x73\x74\x45\x78\x70\x69\x72\x65\x64"
);NXUsersManager::reloadUsersDB ();}}}sub runCommandAsDaemon{(my $socketToReply=
shift (@_));(my $messageBody=shift (@_));my ($commandToRun);my (%parameters);if 
(($messageBody=~ /command=(.*) parameters=(.*)/ )){($commandToRun=$1);(my $urlParams
=$2);((%parameters)=NXShell::urlParameter2Hash ($urlParams));}else{
Logger::warning (((
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20"
.$messageBody)."\x2e"));return ((0x0307+ 5097-0x16ef));}(my $currentSTDOUT=
main::nxgetSTDOUT ());(my $currentLang=Common::NXTranslator::getLanguage ());if 
(($parameters{"\x6c\x61\x6e\x67"}eq "\x43")){($parameters{"\x6c\x61\x6e\x67"}=
"\x65\x6e\x5f\x55\x53");}if ((($parameters{"\x6c\x61\x6e\x67"}ne (""))and (
$parameters{"\x6c\x61\x6e\x67"}ne $currentLang))){Common::NXTranslator::init (
$parameters{"\x6c\x61\x6e\x67"});}($parameters{
"\x6f\x75\x74\x70\x75\x74\x53\x6f\x63\x6b\x65\x74"}=$socketToReply);
__checkParametersForDaemonRequest ((\%parameters));NXShell::handle_command (
$commandToRun,%parameters);if ((main::nxwrite (main::nxgetSTDOUT (),((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_DAEMON_RUN_COMMAND_REQUEST).
"\x20\x46\x69\x6e\x69\x73\x68\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x0a"))==(-
(0x0ceb+ 5462-0x2240)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);
return ((-(0x0f19+ 3287-0x1bef)));}__cleanStdOutAfterRequestDaemonCommand (
$currentSTDOUT);if ((($parameters{"\x6c\x61\x6e\x67"}ne (""))and ($parameters{
"\x6c\x61\x6e\x67"}ne $currentLang))){Common::NXTranslator::init ($currentLang);
}removeFdFromSelector ($socketToReply);return ((0x0be1+ 4455-0x1d48));}sub 
prepareStdOutForRequestDaemonCommand{(my $sock=shift (@_));
Common::NXCore::nxsetSTDOUT ($sock);Server::setConnectionTypeSTD ();
NXShell::setIgnoreExitRequestForDaemonCommands ((0x0044+ 2765-0x0b10));}sub 
__cleanStdOutAfterRequestDaemonCommand{(my $previousSocket=shift (@_));
Server::setConnectionType ("\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44");
Common::NXCore::nxsetSTDOUT ($previousSocket);
NXShell::setIgnoreExitRequestForDaemonCommands ((0x0ddb+ 4202-0x1e45));}sub 
__checkParametersForDaemonRequest{(my $ref_parameters=shift (@_));if (((not (
defined ($$ref_parameters{"\x65\x78\x74\x65\x6e\x64\x65\x64"})))or (
$$ref_parameters{"\x65\x78\x74\x65\x6e\x64\x65\x64"}eq ("")))){($$ref_parameters
{"\x65\x78\x74\x65\x6e\x64\x65\x64"}=(0x03d4+ 3161-0x102d));}if (((not (defined 
($$ref_parameters{"\x61\x6c\x6c"})))or ($$ref_parameters{"\x61\x6c\x6c"}eq (""))
)){($$ref_parameters{"\x61\x6c\x6c"}=(0x0000+ 9688-0x25d8));}if (((not (defined 
($$ref_parameters{"\x74\x72\x65\x65"})))or ($$ref_parameters{"\x74\x72\x65\x65"}
eq ("")))){($$ref_parameters{"\x74\x72\x65\x65"}=(0x0395+ 3019-0x0f60));}if (((
not (defined ($$ref_parameters{"\x72\x61\x77"})))or ($$ref_parameters{
"\x72\x61\x77"}eq ("")))){($$ref_parameters{"\x72\x61\x77"}=
(0x15a4+ 1279-0x1aa3));}}"\x3f\x3f\x3f";
