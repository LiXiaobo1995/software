############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXDbus;no warnings;require Common::NXShellCommands;require 
PhysicSessions;((%buses)=());(my $NotDisplayFound=(-(0x0810+ 7154-0x2401)));my (
%XServer);(my (@allProcessArray)=());my (@XSessions);(my $dbusLibraryInitialized
=(-(0x0ee7+ 5222-0x234c)));sub initialize{(my $dbusName=shift (@_));if ((
$dbusLibraryInitialized!=(-(0x0b62+ 1827-0x1284)))){return;}Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x73\x74\x61\x72\x74\x2e"
);(my $ret=libnxhs::NXDBusInitialize ($dbusName,(0x0a12+ 5058-0x1dd4)));
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$ret)."\x27\x2e"));if (($ret==(0x07e5+ 3550-0x15c3))){Logger::debug (
"\x44\x42\x75\x73\x20\x62\x79\x20\x6c\x69\x62\x6e\x78\x68\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);($dbusLibraryInitialized=(0x0146+ 4412-0x1281));return;}Logger::debug (
"\x44\x42\x75\x73\x20\x62\x79\x20\x6c\x69\x62\x6e\x78\x68\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);($dbusLibraryInitialized=(0x0d15+ 4198-0x1d7b));}sub destroy{if ((
$dbusLibraryInitialized==(0x00fa+ 1244-0x05d5))){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x44\x65\x73\x74\x72\x6f\x79\x20\x73\x74\x61\x72\x74\x2e"
);(my $ret=libnxhs::NXDBusDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x44\x42\x75\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$ret)."\x27\x2e"));Logger::debug (
"\x44\x42\x75\x73\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x75\x6e\x6c\x6f\x61\x64\x65\x64\x2e"
);}}sub dbusByNXPLInitialized{if (($dbusLibraryInitialized==(-
(0x0933+ 7365-0x25f7)))){return ((0x063f+ 5961-0x1d88));}return (
$dbusLibraryInitialized);}sub checkBuses{Logger::debug (
"\x63\x68\x65\x63\x6b\x42\x75\x73\x65\x73\x20\x73\x74\x61\x72\x74\x65\x64\x2e");
(my (@names)=getSystemBusNames ());foreach my $item (@names){(my $pid=
getConnectionProcessId ($item));if (defined ($pid)){($buses{$item}{
"\x70\x69\x64"}=$pid);}}getConnectionProcessNames ();Logger::debug (
"\x42\x55\x53\x20\x6c\x69\x73\x74\x3a");foreach my $bus (keys (%buses)){(my $pid
=$buses{$bus}{"\x70\x69\x64"});(my $command=$buses{$bus}{
"\x63\x6f\x6d\x6d\x61\x6e\x64"});if (defined ($command)){Logger::debug (((((((
"\x42\x55\x53\x20".$bus)."\x20\x72\x75\x6e\x20\x62\x79\x20\x27").$pid).
"\x20\x2d\x20").$command)."\x27\x2e"));}}}sub getConnectionProcessNames{(my (
@command)=($GLOBAL::COMMAND_PS,"\x2d\x41","\x2d\x6f",
"\x70\x69\x64\x2c\x63\x6f\x6d\x6d\x61\x6e\x64"));(my (@options)=());(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@options)));(my (
@processes)=split ( /\n/ ,$cmd_out,(0x1b6c+ 2271-0x244b)));foreach my $item (
@processes){if (($item=~ /^\s+(\d+)\s+(.*)/ )){(my $pid=$1);(my $command=$2);
foreach my $bus (keys (%buses)){if (($buses{$bus}{"\x70\x69\x64"}==$pid)){(
$buses{$bus}{"\x63\x6f\x6d\x6d\x61\x6e\x64"}=$command);}}}}}sub 
getConnectionProcessId{(my $connection=shift (@_));(my $answer=dbusSend (
"\x73\x79\x73\x74\x65\x6d",
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x42\x75\x73"
,
"\x2f\x6f\x72\x67\x2f\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2f\x44\x42\x75\x73"
,
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x42\x75\x73"
,
"\x47\x65\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x55\x6e\x69\x78\x50\x72\x6f\x63\x65\x73\x73\x49\x44"
,("\x73\x74\x72\x69\x6e\x67\x3a".$connection)));Logger::debug (((
"\x67\x65\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x72\x6f\x63\x65\x73\x73\x49\x64\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$answer)."\x27\x2e"));if (($answer=~ /uint32 (\d+)/ )){return ($1);}else{return
 (undef);}}sub getSystemBusNames{(my $answer=dbusSend (
"\x73\x79\x73\x74\x65\x6d",
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x42\x75\x73"
,
"\x2f\x6f\x72\x67\x2f\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2f\x44\x42\x75\x73"
,
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x42\x75\x73"
,"\x4c\x69\x73\x74\x4e\x61\x6d\x65\x73"));Logger::debug3 (((
"\x44\x42\x75\x73\x20\x67\x65\x74\x53\x79\x73\x74\x65\x6d\x42\x75\x73\x4e\x61\x6d\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$answer)."\x27\x2e"));(my (@lines)=split ( /\n/ ,$answer,(0x128a+  45-0x12b7)))
;(my (@names)=());foreach my $item (@lines){if (($item=~ /string "(.*)"/ )){(my $name
=$1);push (@names,$name);}}Logger::debug3 (((
"\x44\x42\x75\x73\x20\x67\x65\x74\x53\x79\x73\x74\x65\x6d\x42\x75\x73\x4e\x61\x6d\x65\x73\x20\x67\x6f\x74\x20\x27"
.join ($",@names))."\x27\x2e"));return (@names);}sub dbusSend{(my $type=shift (
@_));(my $destination=shift (@_));(my $objectPath=shift (@_));(my $interface=
shift (@_));(my $member=shift (@_));(my (@options)=@_);if (dbusByNXPLInitialized
 ()){(my $bufferSize=(0x14e8+ 875-0x0853));my ($buffer);my ($data);if (scalar (
@options)){($data=join ($",@options));}else{($data=(""));}Logger::debug ((((((((
(((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x4d\x65\x74\x68\x6f\x64\x28"
.$bufferSize)."\x2c\x20").$destination)."\x2c\x20").$objectPath)."\x2c\x20").
$interface)."\x2c\x20").$member)."\x2c\x20").$data).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $written=libnxhs::NXDBusMethod ($buffer
,$bufferSize,$destination,$objectPath,$interface,$member,$data));Logger::debug (
((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x4d\x65\x74\x68\x6f\x64\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$written)."\x20\x27").$buffer)."\x27\x2e"));if (($written>$bufferSize)){(
$bufferSize=($written+(0x0ee9+ 927-0x1287)));($buffer=(""));Logger::debug ((((((
(((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x4d\x65\x74\x68\x6f\x64\x28"
.$bufferSize)."\x2c\x20").$destination)."\x2c\x20").$objectPath)."\x2c\x20").
$interface)."\x2c\x20").$member)."\x2c\x20").$data).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));($written=libnxhs::NXDBusMethod ($buffer,
$bufferSize,$destination,$objectPath,$interface,$member,$data));Logger::debug ((
(((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x4d\x65\x74\x68\x6f\x64\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$written)."\x20\x27").$buffer)."\x27\x2e"));}if (($written==(-
(0x19df+ 620-0x1c4a)))){Common::NXCore::reportErrorFromNXPL (((((((((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x42\x75\x73\x4d\x65\x74\x68\x6f\x64\x28"
.$bufferSize)."\x2c\x20").$destination)."\x2c\x20").$objectPath)."\x2c\x20").
$interface)."\x2c\x20").$member)."\x2c\x20").$data).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));}return ($buffer);}my (@command);if (
scalar (@options)){(@command=(Common::NXShellCommands::getCommand (
"\x64\x62\x75\x73\x2d\x73\x65\x6e\x64"),("\x2d\x2d".$type),(
"\x2d\x2d\x64\x65\x73\x74\x3d".$destination),
"\x2d\x2d\x74\x79\x70\x65\x3d\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c",
"\x2d\x2d\x70\x72\x69\x6e\x74\x2d\x72\x65\x70\x6c\x79",$objectPath,(($interface.
"\x2e").$member),@options));}else{(@command=(Common::NXShellCommands::getCommand
 ("\x64\x62\x75\x73\x2d\x73\x65\x6e\x64"),("\x2d\x2d".$type),(
"\x2d\x2d\x64\x65\x73\x74\x3d".$destination),
"\x2d\x2d\x74\x79\x70\x65\x3d\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c",
"\x2d\x2d\x70\x72\x69\x6e\x74\x2d\x72\x65\x70\x6c\x79",$objectPath,(($interface.
"\x2e").$member)));}(my (@param)="\x45\x52\x52\x69\x6e\x4f\x55\x54");(my (
$std_err,$std_out,$ret_val)=main::run_command ((\@command),(\@param)));return (
$std_out);}sub dbusMonitorAll{(my $stdin=shift (@_));(my $stdout=shift (@_));(my $type
=shift (@_));(my (@command)=());(my (@param)=());(my $processPid=());(@command=(
Common::NXShellCommands::getCommand (
"\x64\x62\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72"),("\x2d\x2d".$type)));push (
@param,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$stdin);push (@param,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$stdout);push (@param,
"\x67\x65\x74\x20\x70\x69\x64",(\$processPid));push (@param,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");(my ($std_err,$std_out,$ret_val)=
main::run_command ((\@command),(\@param)));return ($processPid);}sub dbusMonitor
{(my $stdin=shift (@_));(my $stdout=shift (@_));(my $type=shift (@_));(my $property
=shift (@_));(my $sender=shift (@_));(my $interface=shift (@_));(my $member=
shift (@_));(my (@command)=());(my (@param)=());(my $processPid=());(my $parameterLine
=setMonitorParameterline ($property,$sender,$interface,$member));push (@command,
$GLOBAL::CommandNXexec,
"\x6e\x78\x64\x62\x75\x73\x6d\x6f\x6e\x69\x74\x6f\x72\x2e\x73\x68",$type,
$property,$sender,$interface,$member);push (@param,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$stdin);push (@param,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$stdout);push (@param,
"\x67\x65\x74\x20\x70\x69\x64",(\$processPid));push (@param,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");push (@param
,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");(my ($std_err,$std_out,$ret_val)=
main::run_command ((\@command),(\@param)));return ($processPid);}sub 
setMonitorParameterline{(my $property=shift (@_));(my $sender=shift (@_));(my $interface
=shift (@_));(my $member=shift (@_));(my $line=(""));if (($property ne (""))){(
$line=(("\x74\x79\x70\x65\x3d\x27".$property)."\x27"));}if (($sender ne (""))){
if (($line ne (""))){($line.=(("\x2c\x20\x73\x65\x6e\x64\x65\x72\x3d\x27".
$sender)."\x27"));}else{($line=(("\x73\x65\x6e\x64\x65\x72\x3d\x27".$sender).
"\x27"));}}if (($interface ne (""))){if (($line ne (""))){($line.=((
"\x2c\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3d\x27".$interface)."\x27"));}
else{($line=(("\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3d\x27".$interface)."\x27")
);}}if (($member ne (""))){if (($line ne (""))){($line.=((
"\x2c\x20\x6d\x65\x6d\x62\x65\x72\x3d\x27".$member)."\x27"));}else{($line=((
"\x6d\x65\x6d\x62\x65\x72\x3d\x27".$member)."\x27"));}}Logger::debug3 (((
"\x44\x42\x75\x73\x20\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6c\x69\x6e\x65\x20\x66\x6f\x72\x20\x64\x62\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$line)."\x27\x2e"));return ($line);}"\x3f\x3f\x3f";
