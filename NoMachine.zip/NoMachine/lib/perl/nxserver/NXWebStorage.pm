############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXWebStorage::addWebData{package NXWebStorage;no warnings;(my $ref_parameters
=shift (@_));Logger::debug (((((
"\x4e\x58\x57\x65\x62\x53\x74\x6f\x72\x61\x67\x65\x3a\x20\x41\x64\x64\x20\x64\x61\x74\x61\x20\x66\x6f\x72\x20\x53\x49\x44\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27\x3a\x20\x27").$$ref_parameters{
"\x64\x61\x74\x61"})."\x27\x2e"));(my $ret=__addKey ($$ref_parameters{
"\x73\x69\x64"},main::urlencode ($$ref_parameters{"\x64\x61\x74\x61"})));
Logger::debug (((
"\x4e\x58\x57\x65\x62\x53\x74\x6f\x72\x61\x67\x65\x3a\x20\x5f\x5f\x61\x64\x64\x4b\x65\x79\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x3a\x20"
.$ret)."\x2e"));if (($ret!=(0x08e4+ 3797-0x17b9))){(my $message=((
"\x53\x61\x76\x65\x64\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x69\x6e\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));if
 ((main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_WEBSTORAGE_ADD)."\x20").$message)."\x0a"))==(-(0x10a0+ 4988-0x241b)
))){return ((0x02f3+ 6251-0x1b5e));}return ((0x013c+ 227-0x021e));}(my $message=
((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x69\x6e\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));
main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ERROR).
"\x20").$message)."\x0a"));return ((0x08d2+ 1914-0x104c));}sub 
NXWebStorage::getWebData{package NXWebStorage;no warnings;(my $ref_parameters=
shift (@_));Logger::debug (
"\x53\x74\x61\x72\x74\x20\x67\x65\x74\x20\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x2e"
);(my $data=__getKey ($$ref_parameters{"\x73\x69\x64"}));if (((not (defined (
$data)))or ($data eq ("")))){(my $message=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x66\x72\x6f\x6d\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));
main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ERROR).
"\x20").$message)."\x0a"));return ((0x0151+ 5939-0x1884));}(my $message=((
"\x47\x65\x74\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x66\x72\x6f\x6d\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));(my $buffer
=(((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_WEBSTORAGE_GET)."\x20\x73\x69\x64\x3d").
$$ref_parameters{"\x73\x69\x64"})."\x20\x64\x61\x74\x61\x3d").$data)."\x0a"));if
 ((main::nxwrite (main::nxgetSTDOUT (),$buffer)==(-(0x056b+ 532-0x077e)))){
return ((0x066b+ 6414-0x1f79));}return ((0x1316+ 4686-0x2563));}sub 
NXWebStorage::__getKey{package NXWebStorage;no warnings;(my $key=shift (@_));(my $ret
=NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x57\x45\x42\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x0a")));if (($ret==(0x04a8+ 698-0x0762))){return ((""));}return (
main::urldecode (NXRedis::get ()));}sub NXWebStorage::__addKey{package 
NXWebStorage;no warnings;(my $key=shift (@_));(my $value=shift (@_));return (
NXRedis::sendToDb (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x57\x45\x42\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x2c\x76\x61\x6c\x75\x65\x3d").$value)."\x0a")));}sub 
NXWebStorage::__delKey{package NXWebStorage;no warnings;(my $key=shift (@_));
return (NXRedis::sendToDb (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x57\x45\x42\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x2c\x66\x69\x65\x6c\x64\x3d").$key)."\x0a")));}package NXWebStorage;no 
warnings;"\x3f\x3f\x3f";
