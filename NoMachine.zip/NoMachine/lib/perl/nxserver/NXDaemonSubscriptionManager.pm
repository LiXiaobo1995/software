############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXDaemonSubscriptionManager;no warnings;((%anywhereSubscriptions)=());
sub addSubscription{(my $fh=shift (@_));(my $line=shift (@_));if (($line=~ /sessionID=(.*) type=(.*) / )
){if (($2 eq "\x61\x6e\x79\x77\x68\x65\x72\x65")){addAnywhereSubscription ($1,
$fh);return ((0x1650+ 3060-0x2243));}else{Logger::warning (
"\x4e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x74\x79\x70\x65\x20\x6f\x66\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2e"
);}}else{Logger::warning (((
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27"
.$line)."\x27\x2e"));}return ((0x1574+ 4452-0x26d8));}sub 
addAnywhereSubscription{(my $sessionID=shift (@_));(my $fh=shift (@_));
Logger::debug ((((("\x41\x64\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27".
$sessionID)."\x27\x20\x74\x6f\x20\x73\x75\x62\x73\x63\x72\x69\x62\x65\x20").
Server::getAnywhereName ())."\x20\x6d\x65\x73\x73\x61\x67\x65\x73\x2e"));(
$anywhereSubscriptions{$fh}=$sessionID);main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");(my $ret
=main::nxwrite ($fh,NXAnywhereDefault::getStatusMessage ()));Logger::debug (((
"\x53\x65\x6e\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x72\x65\x67\x69\x73\x74\x72\x65\x64\x20\x73\x65\x72\x76\x65\x72\x20\x72\x65\x74\x75\x72\x6e\x3a\x20"
.$ret)."\x2e"));}sub sendMessageToAnywhereSubscribers{(my $message=shift (@_));
foreach my $fh (keys (%anywhereSubscriptions)){(my $ret=main::nxwrite ($fh,
$message));Logger::debug ((((((("\x53\x65\x6e\x64\x20\x27".$message).
"\x27\x20\x74\x6f\x20\x46\x44\x23").$fh)."\x20\x72\x65\x74\x75\x72\x6e\x3a\x20")
.$ret)."\x2e"));}}sub isSubscriptionSocket{(my $fh=shift (@_));if (defined (
$anywhereSubscriptions{$fh})){return ((0x0874+ 1610-0x0ebd));}return (
(0x1f61+ 259-0x2064));}sub handleCloseSubscription{(my $fh=shift (@_));delete (
$anywhereSubscriptions{$fh});main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
NXServerDaemon::setConnectionToLocalhostNumber ();
NXAnywhereDefault::sendConnections (
NXServerDaemon::getConnectionToLocalhostNumber ());}"\x3f\x3f\x3f";
