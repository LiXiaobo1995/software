############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXClusterList::print{package NXClusterList;no warnings;(my $ref_params=shift
 (@_));main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");NXCluster::init 
();Common::NXMsg::send_response (
"\x72\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74");__setWidth ((
\%table),"\x68\x6f\x73\x74","\x48\x6f\x73\x74");__setWidth ((\%table),
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65","\x49\x6e\x74\x65\x72\x66\x61\x63\x65");
__setWidth ((\%table),"\x6e\x65\x74\x6d\x61\x73\x6b",
"\x4e\x65\x74\x6d\x61\x73\x6b");foreach my $node (values (
%NXCluster::myClusterDB)){__setWidth ((\%table),"\x68\x6f\x73\x74",$$node{
"\x68\x6f\x73\x74"});__setWidth ((\%table),
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",$$node{
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65"});__setWidth ((\%table),
"\x6e\x65\x74\x6d\x61\x73\x6b",$$node{"\x6e\x65\x74\x6d\x61\x73\x6b"});}
__printWidth ((\%table),"\x68\x6f\x73\x74","\x48\x6f\x73\x74");__printWidth ((
\%table),"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",
"\x49\x6e\x74\x65\x72\x66\x61\x63\x65");__printWidth ((\%table),
"\x6e\x65\x74\x6d\x61\x73\x6b","\x4e\x65\x74\x6d\x61\x73\x6b");main::nxwrite (
main::nxgetSTDOUT (),"\x0a");__printMark ((\%table),"\x68\x6f\x73\x74");
__printMark ((\%table),"\x69\x6e\x74\x65\x72\x66\x61\x63\x65");__printMark ((
\%table),"\x6e\x65\x74\x6d\x61\x73\x6b");main::nxwrite (main::nxgetSTDOUT (),
"\x0a");foreach my $node (values (%NXCluster::myClusterDB)){__printWidth ((
\%table),"\x68\x6f\x73\x74",main::urldecode ($$node{"\x68\x6f\x73\x74"}));
__printWidth ((\%table),"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",main::urldecode (
$$node{"\x69\x6e\x74\x65\x72\x66\x61\x63\x65"}));__printWidth ((\%table),
"\x6e\x65\x74\x6d\x61\x73\x6b",main::urldecode ($$node{
"\x6e\x65\x74\x6d\x61\x73\x6b"}));main::nxwrite (main::nxgetSTDOUT (),"\x0a");}
main::nxwrite (main::nxgetSTDOUT (),"\x0a");if ($$ref_params{
"\x63\x6f\x6e\x66\x69\x67\x75\x72\x65"}){main::nxwrite (main::nxgetSTDOUT (),((
"\x53\x68\x61\x72\x65\x64\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x20".
$GLOBAL::ClusterHost)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x4d\x61\x73\x74\x65\x72\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x20".
$GLOBAL::ClusterMaster)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x50\x72\x6f\x74\x6f\x63\x6f\x6c\x73\x3a\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterProto)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x47\x72\x61\x63\x65\x20\x70\x65\x72\x69\x6f\x64\x3a\x20\x20\x20".
$GLOBAL::ClusterGracePeriod)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x52\x65\x74\x72\x79\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x3a\x20".
$GLOBAL::ClusterRetryInterval)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x50\x72\x6f\x62\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20\x20".
$GLOBAL::ClusterProbeTimeout)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x49\x6e\x74\x65\x72\x76\x61\x6c\x3a\x20\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterInterval)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x54\x69\x6d\x65\x6f\x75\x74\x3a\x20\x20\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterTimeout)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x4c\x6f\x61\x64\x2d\x62\x61\x6c\x61\x6e\x63\x69\x6e\x67\x3a\x20".
$GLOBAL::ClusterLoadBalancing)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x47\x55\x49\x44\x3a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterGUID)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x53\x69\x6e\x67\x6c\x65\x20\x63\x65\x72\x74\x3a\x20\x20\x20\x20".
$GLOBAL::ClusterSingleCert)."\x0a"));}}sub NXClusterList::__setWidth{package 
NXClusterList;no warnings;(my $refTable=shift (@_));(my $name=shift (@_));(my $value
=shift (@_));if (($$refTable{$name}<libnxh::NXStringLength ($value))){(
$$refTable{$name}=libnxh::NXStringLength ($value));}}sub 
NXClusterList::__printWidth{package NXClusterList;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable{
$name}+(0x0b85+ 4533-0x1d39)));(my $message=
Common::NXCore::leftJustifyOrTrimString ($value,$width));main::nxwrite (
main::nxgetSTDOUT (),$message);}sub NXClusterList::__printMark{package 
NXClusterList;no warnings;(my $refTable=shift (@_));(my $name=shift (@_));(my $value
=shift (@_));(my $width=($$refTable{$name}+(0x02fc+ 3726-0x1189)));(my $message=
Common::NXCore::leftJustifyOrTrimString (("\x2d" x $$refTable{$name}),$width));
main::nxwrite (main::nxgetSTDOUT (),$message);}sub NXClusterList::status{package
 NXClusterList;no warnings;(my $username=Common::NXCore::getEffectiveUsername ()
);if (($username ne "\x6e\x78")){(my $content=(""));(my (@command)=(
$GLOBAL::CommandNXexec,"\x2d\x2d\x73\x65\x72\x76\x65\x72",
"\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x73\x74\x61\x74\x75\x73"));(my (
@parameters)=());push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68")));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if ((not ($exit_value))){($content=$cmd_out);}if ((defined ($content)and (
$content ne ("")))){main::nxwrite (main::nxgetSTDOUT (),$content);}if (
NXShell::isCommandForwarded ()){NXShell::setExitRequestCommandFinished ();}
return;}main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);(my $reply=NXClientSystemDaemons::requestClusterStatus ());if (($reply=~ ('NX> ' . $GLOBAL::MSG_CLUSTER_RUNNING) )
){if ((not (NXMsg::isMessageRegistered (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x75\x6e\x6e\x69\x6e\x67")))){
NXMsg::register_response ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74"
,"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x75\x6e\x6e\x69\x6e\x67",
$GLOBAL::MSG_CLUSTER_RUNNING);}NXMsg::send_response (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x75\x6e\x6e\x69\x6e\x67",
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74");return (
(0x1005+ 1744-0x16d5));}if ((not (NXMsg::isMessageRegistered (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x44\x69\x73\x61\x62\x6c\x65\x64"))
)){NXMsg::register_response (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74",
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x44\x69\x73\x61\x62\x6c\x65\x64",
$GLOBAL::MSG_CLUSTER_DISABLED);}NXMsg::send_response (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74");}package NXClusterList;
no warnings;Common::NXMsg::register_response (
"\x72\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74",
$GLOBAL::MSG_CLUSTER_LIST);return ((0x205a+ 1592-0x2691));
