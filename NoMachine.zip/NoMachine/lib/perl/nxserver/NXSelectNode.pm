############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSelectNode::BEGIN{package NXSelectNode;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub NXSelectNode::BEGIN{
package NXSelectNode;no warnings;require NXNodes;do{
"\x4e\x58\x4e\x6f\x64\x65\x73"->import};}sub NXSelectNode::BEGIN{package 
NXSelectNode;no warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import (
"\x3a\x74\x72\x79")};}sub NXSelectNode::BEGIN{package NXSelectNode;no warnings;
require NXNodes;do{"\x4e\x58\x4e\x6f\x64\x65\x73"->import};}package NXSelectNode
;no warnings;(my $__multipleNodesAreAvailable=(0x0197+ 4213-0x120c));(my $__memoryThreshold
=300000);sub prepareNodeList{(my $sessionType=(shift (@_)||
NXSessionParameters::getSessionType ()));if (($sessionType eq (""))){
Logger::error (
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x2e"
);NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x4d\x69\x73\x73\x69\x6e\x67\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65");
return (());}Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x6c\x65\x63\x74\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$sessionType)."\x27\x2e"));if ((__prepareNodeList ($sessionType)==
(0x0d11+ 4848-0x2001))){return (());}(my $sortNodes=(0x0694+ 4560-0x1864));(my (
@nodes)=());while (__nodesAreAvailable ()){(my $node=getNextNode ());(my $host=
$$node{"\x68\x6f\x73\x74"});(my $port=$$node{"\x70\x6f\x72\x74"});if ((not (
NXNodes::isSessionTypeAvailableForNode ($sessionType,(\$node))))){
Logger::warning (((((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27".$sessionType).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x27"
).$host)."\x3a").$port)."\x27\x2e"));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
);next;}if ((__checkProfilesForSelectedNode ($node,$sessionType)==
(0x0d07+ 1728-0x13c6))){next;}push (@nodes,$node);}(my $nodeList=(""));foreach my $node
 (@nodes){($nodeList.=((($$node{"\x68\x6f\x73\x74"}."\x3a").$$node{
"\x70\x6f\x72\x74"})."\x2c"));}($nodeList=~ s/,$// );Logger::debug (((
"\x50\x72\x65\x70\x61\x72\x65\x64\x20\x6e\x6f\x64\x65\x20\x6c\x69\x73\x74\x20\x27"
.$nodeList)."\x27\x2e"));if (isCustomLoadBalancing ()){
__updateNodesArrayByCustomLBScript ((\@nodes));}if (scalar (@nodes)){return (
@nodes);}return (());}sub __prepareNodeList{(my $sessionType=shift (@_));my (
$runningHostsList);(my $isMultiNodeEnabledInProfiles=(0x0875+ 512-0x0a75));if (
NXProfilesManager::isMultinodeEnabled ()){(my $nodeUUID=
NXSessionParameters::getNodeUUID ());if ((NXNodes::isManualSelectionFlag ()and (
$nodeUUID ne ("")))){($runningHostsList=$nodeUUID);}else{($runningHostsList=
NXNodes::getNodesList ());}($isMultiNodeEnabledInProfiles=(0x1819+ 540-0x1a34));
}else{(my ($uuid,$host,$port)=NXNodes::findLocalNode ());($runningHostsList=
$uuid);}(my (@runningHostArray)=split ( /,/ ,$runningHostsList,
(0x0862+ 424-0x0a0a)));(my $runningNodes=scalar (@runningHostArray));if ((
$runningNodes==(0x09e0+ 5592-0x1fb8))){Logger::error (
"\x4e\x6f\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x6e\x6f\x64\x65\x73\x20\x66\x6f\x75\x6e\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);NXMsg::error (
"\x65\x52\x75\x6e\x6e\x69\x6e\x67\x4e\x6f\x64\x65\x73\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
,"\x4e\x58\x53\x65\x6c\x65\x63\x74\x4e\x6f\x64\x65");return (
(0x0dc6+ 4462-0x1f34));}($AvailableHostList=$runningHostsList);if (((not (
NXNodes::isManualSelectionFlag ()))and $isMultiNodeEnabledInProfiles)){(
$AvailableHostList=(""));foreach my $node (@runningHostArray){if ((not (
NXProfilesManager::isNodeAvailableForLoggedUser ($node)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x27".$node).
"\x27\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x2e"
));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x4e\x6f\x64\x65\x73\x41\x72\x65\x44\x69\x73\x61\x62\x6c\x65\x64");}elsif (
(not (NXNodes::isMultinodeEnabledForNode ($node)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x27".$node).
"\x27\x20\x69\x73\x20\x65\x78\x63\x6c\x75\x64\x65\x64\x20\x66\x72\x6f\x6d\x20\x6c\x6f\x61\x64\x20\x62\x61\x6c\x61\x6e\x63\x69\x6e\x67\x2e"
));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x4e\x6f\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x4e\x6f\x64\x65\x73");}else{
Logger::debug (((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x4e\x6f\x64\x65\x3a\x20\x4e\x6f\x64\x65\x20\x27"
.$node).
"\x27\x20\x69\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x6c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x2e"
));($AvailableHostList.=($node."\x2c"));}}($AvailableHostList=~ s/,$// );}(my (
@nodeList)=split ( /,/ ,$AvailableHostList,(0x0679+ 610-0x08db)));($nodeCount=
scalar (@nodeList));if (($nodeCount==(0x19dd+ 779-0x1ce8))){Logger::error (
"\x4e\x6f\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6e\x6f\x64\x65\x73\x20\x66\x6f\x75\x6e\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);NXMsg::error (
"\x65\x4e\x6f\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x4e\x6f\x64\x65\x73",
"\x4e\x58\x4e\x6f\x64\x65\x45\x72\x72\x6f\x72");return ((0x0f5d+ 3890-0x1e8f));}
if (($nodeCount>(0x05da+ 558-0x0807))){__setMultipleNodesAvailable ();}(
$tryCounter=(0x05fd+ 1303-0x0b13));($nodeIndex=(0x0867+ 3551-0x1646));if ((
$GLOBAL::LoadBalancingAlgorithm eq 
"\x6c\x6f\x61\x64\x2d\x61\x76\x65\x72\x61\x67\x65")){($AvailableHostList=
__getLoadAvgList ($AvailableHostList));}elsif (($GLOBAL::LoadBalancingAlgorithm 
eq "\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64")){($AvailableHostList=
__getSystemLoadList ($AvailableHostList));}else{if (
NXNodes::isNodesWeightAvailable ()){($AvailableHostList=
__getWeightRoundRobinList ($AvailableHostList));}else{($AvailableHostList=
__getSimpleRoundRobinList ($AvailableHostList));}}return ($nodeCount);}sub 
__getLoadAvgList{(my (%hashNodes)=());(my (@multinode_hosts)=split ( /,/ ,
$AvailableHostList,(0x181b+ 1021-0x1c18)));foreach my $node (@multinode_hosts){(my $load
=NXNodes::getLoadAvg ($node));Logger::debug (((((
"\x4c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x20\x66\x6f\x72\x20".$node).
"\x3a\x20").$load)."\x2e"));($hashNodes{$node}=$load);}(my $nodeString=(""));
foreach my $key (sort ({($hashNodes{$a}<=>$hashNodes{$b});}keys (%hashNodes))){(
$nodeString.=($key."\x2c"));}chop ($nodeString);Logger::debug (((
"\x4e\x6f\x64\x65\x20\x6c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x20\x6c\x69\x73\x74\x3a\x20"
.$nodeString)."\x2e"));return ($nodeString);}sub __getSystemLoadList{(my (
%hashNodesCorrect)=());(my $incompatibleNodesString=(""));(my (@multinode_hosts)
=split ( /,/ ,$AvailableHostList,(0x0f18+ 387-0x109b)));foreach my $node (
@multinode_hosts){(my ($systemLoad,$availableMemory)=
NXNodes::getSystemLoadAndAvailableMemory ($node));Logger::debug (((((((
"\x53\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x66\x6f\x72\x20".$node).
"\x3a\x20").$systemLoad).
"\x2c\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6d\x65\x6d\x6f\x72\x79\x20").
$availableMemory)."\x2e"));if ((($systemLoad<(0x06e0+ 6223-0x1f2f))or (
$availableMemory<__getMemoryThreshold ()))){($incompatibleNodesString.=($node.
"\x2c"));}else{($hashNodesCorrect{$node}=$systemLoad);}}chop (
$incompatibleNodesString);(my $nodeString=(""));foreach my $key (sort ({(
$hashNodesCorrect{$a}<=>$hashNodesCorrect{$b});}keys (%hashNodesCorrect))){(
$nodeString.=($key."\x2c"));}if (($incompatibleNodesString ne (""))){if (scalar 
(keys (%hashNodesCorrect))){Logger::debug (
"\x41\x64\x64\x69\x6e\x67\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x69\x6e\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x6e\x6f\x64\x65\x73\x20\x74\x6f\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x6c\x69\x73\x74\x2e"
);($nodeString.=__getSimpleRoundRobinList ($incompatibleNodesString));}else{
Logger::warning (
"\x41\x6c\x6c\x20\x6e\x6f\x64\x65\x73\x20\x68\x61\x76\x65\x20\x69\x6e\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x6f\x72\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6d\x65\x6d\x6f\x72\x79\x2e"
);Logger::warning (
"\x46\x61\x6c\x6c\x69\x6e\x67\x20\x62\x61\x63\x6b\x20\x74\x6f\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6c\x69\x73\x74\x2e"
);($nodeString.=__getSimpleRoundRobinList ($AvailableHostList));}}else{chop (
$nodeString);}Logger::debug (((
"\x4e\x6f\x64\x65\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x6c\x69\x73\x74\x3a\x20"
.$nodeString)."\x2e"));return ($nodeString);}sub __getSimpleRoundRobinList{(my $availableHostList
=shift (@_));(my (@hostsAvaliable)=split ( /,/ ,$availableHostList,
(0x0695+ 2557-0x1092)));(my $nodeCount=scalar (@hostsAvaliable));(my $index=
__takeNodeIndex ($nodeCount));if (($index>=$nodeCount)){($index=
(0x0a71+ 6183-0x2298));}(my $i=(0x023d+ 5925-0x1962));(my $nodeString=(""));
while (($i<$nodeCount)){($nodeString.=($hostsAvaliable[$index]."\x2c"));($index=
__getNextNodeIndex ($index,$nodeCount));(++$i);}($nodeString=~ s/,$// );
Logger::debug (((
"\x53\x69\x6d\x70\x6c\x65\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6e\x6f\x64\x65\x20\x6c\x69\x73\x74\x20\x27"
.$nodeString)."\x27\x2e"));return ($nodeString);}sub __getWeightRoundRobinList{(my $availableHostList
=shift (@_));(my (@hosts)=split ( /,/ ,$availableHostList,(0x1316+ 3168-0x1f76))
);(my (%hashNodes)=());foreach my $node (@hosts){(my $nodeSessions=
NXLimits::getSessionsNode ($node));(my $nodeWeight=NXNodes::getWeight ($node));(my $weight
=($nodeWeight-$nodeSessions));Logger::debug ((((("\x4e\x6f\x64\x65\x20\x27".
$node).
"\x27\x20\x77\x65\x69\x67\x68\x74\x20\x74\x6f\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x27"
).$weight)."\x27\x2e"));($hashNodes{$weight}.=($node."\x2c"));}(my $nodeString=
(""));foreach my $key (sort ({$b<=>$a}keys (%hashNodes))){($nodeString.=
$hashNodes{$key});}($nodeString=~ s/,$// );Logger::debug (((
"\x57\x65\x69\x67\x68\x74\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6e\x6f\x64\x65\x20\x6c\x69\x73\x74\x20\x27"
.$nodeString)."\x27\x2e"));return ($nodeString);}sub __takeNodeIndex{(my $nodeCount
=shift (@_));NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x72\x6f\x75\x6e\x64\x72\x6f\x62\x69\x6e\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x64\x65\x78\x0a"
);(my $index=NXRedis::get ());if (($index ne (""))){($index=__getNextNodeIndex (
$index,$nodeCount));}else{($index=(0x03c8+ 7097-0x1f81));}NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x72\x6f\x75\x6e\x64\x72\x6f\x62\x69\x6e\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x64\x65\x78\x2c\x76\x61\x6c\x75\x65\x3d"
.$index)."\x0a"));return ($index);}sub __getNextNodeIndex{(my $num=shift (@_));(my $nodeCount
=shift (@_));if ((($num>=(0x0b83+ 1063-0x0faa))and ($num<($nodeCount-
(0x0833+ 4901-0x1b57))))){(++$num);}else{($num=(0x0209+ 2123-0x0a54));}return (
$num);}sub __checkProfilesForSelectedNode{(my $node=shift (@_));(my $sessionType
=shift (@_));(my $nodeToCheck=$$node{"\x75\x75\x69\x64"});Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
.$nodeToCheck).
"\x27\x20\x61\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
).$sessionType)."\x27\x2e"));if ((
NXProfilesManager::isSessionTypeAvailableForUserGroupSystemAndNode ($sessionType
,undef,$nodeToCheck)==(0x0d7c+ 2990-0x192a))){Logger::debug (((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27".$sessionType).
"\x27\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
).$nodeToCheck)."\x27\x2e"));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
);return ((0x150a+ 1962-0x1cb3));}Logger::debug ((("\x4e\x6f\x64\x65\x20\x27".
$nodeToCheck).
"\x27\x20\x65\x6e\x61\x62\x6c\x65\x20\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
));return ((0x09b4+ 4328-0x1a9c));}sub getNextNode{my ($loadMultinodeHost);if (
NXProfilesManager::isMultinodeEnabled ()){($loadMultinodeHost=__getNodeByIndex (
__getNodeIndex ()));}else{Logger::debug (
"\x4d\x75\x6c\x74\x69\x6e\x6f\x64\x65\x20\x66\x65\x61\x74\x75\x72\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);($loadMultinodeHost=__getNodeByIndex ((0x04a4+  59-0x04df)));}
__increaseNodeIndex ($loadMultinodeHost);return (NXNodes::get (
$loadMultinodeHost));}sub __getNodeListByLBScript{(my $ref_nodes=shift (@_));(my $cmd_err
=(""));(my $cmd_out=(""));(my $exit_value=(0x02c8+  96-0x0328));if ((not (-x (
$GLOBAL::NodeSelectionScript)))){Logger::warning (((
"\x54\x68\x65\x20\x6e\x6f\x64\x65\x20\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::NodeSelectionScript).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"))
;return ((""));}if ((not (Common::NXShellCommands::isApplicationInKnownPath (
"\x70\x65\x72\x6c")))){Logger::warning (
"\x50\x65\x72\x6c\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x69\x6e\x20\x74\x68\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return ((""));}(my (@command)=Common::NXShellCommands::getCommand (
"\x70\x65\x72\x6c"));push (@command,$GLOBAL::NodeSelectionScript);push (@command
,__getParamsForLBScript ($ref_nodes));Logger::debug (((
"\x47\x65\x74\x20\x6e\x6f\x64\x65\x73\x20\x6c\x69\x73\x74\x20\x62\x79\x20\x4c\x42\x20\x73\x63\x72\x69\x70\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.join ($",@command))."\x27\x2e"));(my (@parameters)=());push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x55\x53\x45\x52\x4e\x41\x4d\x45\x3d".NXLogin::getCurrentUser ()));
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x49\x50\x3d".
NXClientConnection::getRemoteIp ()));(($cmd_err,$cmd_out,$exit_value)=
main::run_command ((\@command),(\@parameters)));($cmd_out=~ s/\n$// );if ((
$exit_value!=(0x1943+ 3371-0x266e))){return ((""));}return ($cmd_out);}sub 
__getParamsForLBScript{(my $ref_nodes=shift (@_));(my $paramsForLBScript=undef);
foreach my $node (@$ref_nodes){(my $countSession=
NXNodes::getSessionsCountForLBScript ($$node{"\x75\x75\x69\x64"}));(my $limit=
$$node{"\x6c\x69\x6d\x69\x74"});if (($limit eq (""))){($limit=
NXLimits::getMaxConnectionsLimit ());}(my $weight=$$node{
"\x77\x65\x69\x67\x68\x74"});if (($weight eq (""))){($weight=
(0x0b6a+ 3719-0x19f1));}($paramsForLBScript.=((((((($$node{"\x75\x75\x69\x64"}.
"\x2c").$weight)."\x2c").$countSession)."\x2c").$limit)."\x23"));}return (
$paramsForLBScript);}sub __nodesAreAvailable{if (($tryCounter<=$nodeCount)){
return ((0x14f8+ 2338-0x1e19));}return ((0x0a81+ 3089-0x1692));}sub 
__getNodeByIndex{(my $index=shift (@_));(my (@nodeList)=split ( /,/ ,
$AvailableHostList,(0x20eb+  46-0x2119)));return ($nodeList[$index]);}sub 
__getNodeIndex{return ($nodeIndex);}sub __increaseNodeIndex{(++$nodeIndex);(
$tryCounter++);}sub __setMultipleNodesAvailable{($__multipleNodesAreAvailable=
(0x0dc3+ 4600-0x1fba));}sub multipleNodesAreAvailable{return (
$__multipleNodesAreAvailable);}sub isCustomLoadBalancing{if ((
$GLOBAL::LoadBalancingAlgorithm eq "\x63\x75\x73\x74\x6f\x6d")){if ((
$GLOBAL::NodeSelectionScript ne (""))){return ((0x13c4+ 3106-0x1fe5));}else{
Logger::warning (
"\x4c\x6f\x61\x64\x20\x62\x61\x6c\x61\x6e\x63\x69\x6e\x67\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x27\x63\x75\x73\x74\x6f\x6d\x27\x20\x62\x75\x74\x20\x6e\x6f\x64\x65\x20\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e\x20\x73\x63\x72\x69\x70\x74\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x44\x65\x66\x61\x75\x6c\x74\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x75\x73\x65\x64\x2e"
);}}return ((0x10a3+ 2589-0x1ac0));}sub __updateNodesArrayByCustomLBScript{(my $ref_nodes
=shift (@_));(my $nodesList=__getNodeListByLBScript ($ref_nodes));if ((
$nodesList eq (""))){Logger::warning ((((
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x74\x72\x69\x65\x76\x69\x6e\x67\x20\x6e\x6f\x64\x65\x73\x20\x62\x79\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::NodeSelectionScript)."\x27\x2e\x20").
"\x44\x65\x66\x61\x75\x6c\x74\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x75\x73\x65\x64\x2e"
));return;}(my (@nodesAddressArray)=split ( /#/ ,$nodesList,
(0x1fb3+ 1881-0x270c)));(@$ref_nodes=());foreach my $address (@nodesAddressArray
){push (@$ref_nodes,NXNodes::get ($address));}}sub 
__getCommaSeparatedNodeListByCustomLBScript{(my $ref_nodes=shift (@_));(my $nodesList
=__getNodeListByLBScript ($ref_nodes));if (($nodesList eq (""))){Logger::warning
 ((((
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x74\x72\x69\x65\x76\x69\x6e\x67\x20\x6e\x6f\x64\x65\x73\x20\x62\x79\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::NodeSelectionScript)."\x27\x2e\x20").
"\x44\x65\x66\x61\x75\x6c\x74\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x75\x73\x65\x64\x2e"
));return ((""));}($nodesList=~ s/#/,/g );return ($nodesList);}sub 
__getMemoryThreshold{return ($__memoryThreshold);}NXMsg::register_error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x4e\x6f\x64\x65",
"\x65\x52\x75\x6e\x6e\x69\x6e\x67\x4e\x6f\x64\x65\x73\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
,(0x1109+ 5309-0x23d2));return ((0x04ef+ 8488-0x2616));
