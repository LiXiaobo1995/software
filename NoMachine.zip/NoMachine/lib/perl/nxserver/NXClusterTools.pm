############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXClusterTools::generateClusterGUID{package NXClusterTools;no warnings;(my (
@command)=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);push (@command,
"\x2d\x75");(my (@options)=());push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".NXPaths::getUserNXHomeDir ()));(my ($cmdErr,$cmdOut,
$exitValue)=main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x00cf+ 2773-0x0ba4))){Logger::warning (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x47\x55\x49\x44\x2e"
);return ((""));}chomp ($cmdOut);return ($cmdOut);}sub 
NXClusterTools::generateClusterKeys{package NXClusterTools;no warnings;(my (
@command)=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);(my $priv=
NXPaths::getClusterRSAPrivateKey ());(my $pub=NXPaths::getClusterRSAPublicKey ()
);push (@command,"\x2d\x6b",$priv);push (@command,"\x2d\x70",$pub);push (
@command,"\x2d\x74","\x72\x73\x61");(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".NXPaths::getUserNXHomeDir
 ()));(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(
\@options)));changeFileOwnershipToNxIfRoot ($priv);changeFileOwnershipToNxIfRoot
 ($pub);if ((Common::NXFile::setPermissionsReadWriteForNX ($priv)==(-
(0x0185+ 8032-0x20e4)))){Logger::warning (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x27"
.$priv)."\x27\x2e"));}if ((
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($pub)==(-
(0x0f5c+ 2313-0x1864)))){Logger::warning (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20"
.$pub)."\x2e"));}}sub NXClusterTools::generateClusterHostCerts{package 
NXClusterTools;no warnings;(my (@command)=());push (@command,
$GLOBAL::COMMAND_NXKEYGEN);(my $priv=NXPaths::getClusterHostPrivateCert ());(my $pub
=NXPaths::getClusterHostPublicCert ());push (@command,"\x2d\x6b",$priv);push (
@command,"\x2d\x63",$pub);(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));(my $homeDir=
NXPaths::getUserNXHomeDir ());push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".$homeDir));(my ($cmd_err,$cmd_out,$exit_value)=
main::nxRunCommand ((\@command),(\@options)));changeFileOwnershipToNxIfRoot (
$priv);changeFileOwnershipToNxIfRoot ($pub);if ((
Common::NXFile::setPermissionsReadWriteForNX ($priv)==(-(0x064a+ 7110-0x220f))))
{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20"
.$priv)."\x2e"));}if ((
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($pub)==(-
(0x1310+ 275-0x1422)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20"
.$pub)."\x2e"));}}sub NXClusterTools::cleanInterface{package NXClusterTools;no 
warnings;(my $interface=$GLOBAL::ClusterInterface);(my $clusterHost=
$GLOBAL::ClusterHost);(my $mask=$GLOBAL::ClusterNetmask);if ((
$GLOBAL::ScriptClusterClearSharedIP ne (""))){main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");return (NXScripts::runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x63\x6c\x65\x61\x72\x5f\x73\x68\x61\x72\x65\x64\x5f\x69\x70"
,$interface,$clusterHost,$mask));}if ((($interface eq (""))or ($clusterHost eq 
("")))){(($interface,$clusterHost)=__readInterfaceFromFile ());}if (($interface 
eq (""))){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x3a\x20\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface).
"\x27\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x65\x61\x6e\x20\x75\x70\x2e"))
;return ((0x09e8+ 6853-0x24ad));}Logger::debug (((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x3a\x20\x43\x6c\x65\x61\x6e\x20\x75\x70\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface)."\x27\x20\x68\x6f\x73\x74\x20\x27").$clusterHost)."\x27\x2e"));(my (
@command)=());sub BEGIN{require NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->
import};}push (@command,((NXTools::getWindowsSystemPath ().
$GLOBAL::DIRECTORY_SLASH)."\x6e\x65\x74\x73\x68\x2e\x65\x78\x65"));push (
@command,"\x69\x6e\x74\x65\x72\x66\x61\x63\x65","\x69\x70\x76\x34",
"\x64\x65\x6c\x65\x74\x65","\x61\x64\x64\x72\x65\x73\x73");(push (@command,((
"\x22".$interface)."\x22"),$clusterHost),(my (@options)=()));(my ($cmdOut,
$cmdErr,$exitValue)=main::nxRunCommand ((\@command),(\@options)));Logger::debug 
((((((("\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x75\x74\x70\x75\x74\x20\x27".
$cmdOut)."\x27\x20\x27").$cmdErr).
"\x27\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x27").$exitValue)."\x27\x2e"))
;if (($exitValue!=(0x1d17+ 1486-0x22e5))){Logger::error (((((((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$exitValue)
."\x27\x2e\x20\x27").$cmdOut)."\x27\x20\x27").$cmdErr)."\x27\x2e"));}
removeInterfaceFile ();return ($exitValue);}sub 
NXClusterTools::saveInterfaceToFile{package NXClusterTools;no warnings;(my $interface
=shift (@_));(my $clusterHost=shift (@_));(my $filename=
NXPaths::getClusterInterfaceFile ());(my $fileExisted=(0x0bb0+ 5732-0x2214));if 
(Common::NXFile::fileExists ($filename)){($fileExisted=(0x098f+ 7142-0x2574));}(my $FH
=main::nxopen ($filename,($NXBits::O_RDWR+$NXBits::O_CREAT),((
$NXBits::OthersRead+$NXBits::UserReadWrite)+$NXBits::GroupRead)));if ((not (
defined ($FH)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".$filename
)."\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x2c\x20").$errorstring).
"\x2e"));return ((0x13a6+ 2703-0x1e34));}if ((main::nxwrite ($FH,((($interface.
"\x0a").$clusterHost)."\x0a"))==(-(0x14a7+ 3392-0x21e6)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e"));main::nxclose ($FH);if ((not ($fileExisted))){
changeFileOwnershipToNxIfRoot ($filename);}return ((0x019c+ 1865-0x08e4));}
main::nxclose ($FH);if ((not ($fileExisted))){changeFileOwnershipToNxIfRoot (
$filename);}return ((0x13c2+ 4814-0x2690));}sub 
NXClusterTools::removeInterfaceFile{package NXClusterTools;no warnings;(my $filename
=NXPaths::getClusterInterfaceFile ());if (Common::NXFile::isExists ($filename)){
Common::NXFile::removeFile ($filename);}}sub 
NXClusterTools::doesInterfaceFileExist{package NXClusterTools;no warnings;(my $filename
=NXPaths::getClusterInterfaceFile ());if (Common::NXFile::fileExists ($filename)
){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$filename)."\x27\x20\x65\x78\x69\x73\x74\x73\x2e"));return (
(0x1918+ 584-0x1b5f));}Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$filename).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));return 
((0x0053+ 312-0x018b));}sub NXClusterTools::__readInterfaceFromFile{package 
NXClusterTools;no warnings;if ((not (doesInterfaceFileExist ()))){return ((""),
(""));}(my $filename=NXPaths::getClusterInterfaceFile ());(my $FH=main::nxopen (
$filename,$NXBits::O_RDONLY,(0x1d0f+ 680-0x1fb7)));if ((not (defined ($FH)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$filename)."\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));return ((""),(""));}my ($interface);my (
$clusterHost);main::nxreadLine ($FH,(\$interface));main::nxreadLine ($FH,(
\$clusterHost));main::nxclose ($FH);chomp ($interface);chomp ($clusterHost);
return ($interface,$clusterHost);}sub NXClusterTools::getInterfaces{package 
NXClusterTools;no warnings;(my (%interfaces)=());Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73"
);(my $return=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));(my (@lines)=split ( /\n/ ,$return,(0x0a25+ 5764-0x20a9))
);foreach my $line (@lines){if (($line=~ /(^[\{\}\-\w:\d]+)\s+AF_INET\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){Logger::debug ((((((("\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27".$1).
"\x27\x2c\x20\x49\x50\x20\x27").$4)."\x27\x20\x6d\x61\x73\x6b\x20\x27").$5).
"\x27\x2e"));($interfaces{$1}={"\x69\x70",$4,"\x6d\x61\x73\x6b",$5});}}return (
%interfaces);}sub NXClusterTools::getIPs{package NXClusterTools;no warnings;
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73"
);(my $return=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));(my (%IPs)=());(my (@lines)=split ( /\n/ ,$return,
(0x0374+ 3692-0x11e0)));foreach my $line (@lines){if (($line=~ /(^[\{\}\-\w:\d]+)\s+AF_INET\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){(my $iface=$1);(my $ip=$4);(my $mask=$5);Logger::debug (((((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$iface)."\x27\x20\x49\x50\x20\x27").$ip)."\x27\x20\x6d\x61\x73\x6b\x20\x27").
$mask)."\x27\x2e"));($IPs{$ip}={"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",$iface,
"\x6d\x61\x73\x6b",$mask});}}return (%IPs);}sub NXClusterTools::isIPExists{
package NXClusterTools;no warnings;(my $IP=shift (@_));Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x61\x72\x63\x68\x20\x49\x50\x20\x27"
.$IP).
"\x27\x20\x6f\x6e\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x6c\x69\x73\x74\x2e"
));(my (%interfaces)=getInterfaces ());foreach my $name (keys (%interfaces)){if 
(($interfaces{$name}{"\x69\x70"}eq $ip)){Logger::debug (((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x6f\x75\x6e\x64\x20\x49\x50\x20\x27"
.$IP)."\x27\x20\x6f\x6e\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27").$name)
."\x27\x2e"));return ((0x0524+ 7374-0x21f1));}}Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x49\x50\x20\x27"
.$IP)."\x27\x2e"));return ((0x14f5+ 4177-0x2546));}sub 
NXClusterTools::getClusterPublicKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getClusterRSAPublicKey ());if ((not (Common::NXFile::fileExists ($file
)))){generateClusterKeys ();}(my $content=Common::NXFile::getFileContent ($file)
);if (($content eq (""))){(my $message=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x70\x75\x6c\x69\x63\x20\x6b\x65\x79\x20\x66\x72\x6f\x6d\x20\x70\x61\x74\x68\x20\x27"
.$file)."\x27"));Logger::error ($message);die ($message);}return ($content);}sub
 NXClusterTools::__setDatabaseBackup{package NXClusterTools;no warnings;(my $database
=shift (@_));(my $content=shift (@_));if (__isDatabaseBackupExist ($database)){
Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x44\x61\x74\x61\x62\x61\x73\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x27"
.$database).
"\x27\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x65\x78\x69\x73\x74\x73\x2e"));return 
((0x1bc4+ 483-0x1da7));}if (($content eq (""))){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x44\x61\x74\x61\x62\x61\x73\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x27"
.$database)."\x27\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"));return (
(0x0f2a+ 2469-0x18cf));}($content=main::urlencode ($content));NXRedis::sendToDb 
(((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x6e\x78\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x62\x61\x63\x6b\x75\x70\x2e"
.$database)."\x2c\x76\x61\x6c\x75\x65\x3d").$content)."\x0a"));}sub 
NXClusterTools::getNodesDB{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");return (NXNodes::getDatabaseInString ());}sub 
NXClusterTools::getClusterDB{package NXClusterTools;no warnings;return (
getDatabaseInString ());}sub NXClusterTools::getProfilesDB{package 
NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");return (
NXProfilesDB::getDatabaseInString ());}sub NXClusterTools::getUsersDB{package 
NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");return (
NXUsersManager::getDatabaseInString ());}sub NXClusterTools::getAdministratorsDB
{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);return (NXAdministratorsManager::getDatabaseInString ());}sub 
NXClusterTools::getGroupsDB{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x47\x72\x6f\x75\x70\x73");return (NXGroups::getDatabaseInString ());}
sub NXClusterTools::getNodeGroupsDB{package NXClusterTools;no warnings;
main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73",
"\x69\x6e\x69\x74");return (NXNodeGroups::getDatabaseInString ());}sub 
NXClusterTools::getServerGroupsDB{package NXClusterTools;no warnings;
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73",
"\x69\x6e\x69\x74");return (NXServerGroups::getDatabaseInString ());}sub 
NXClusterTools::getNXCerts{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");return (NXServers::getNXCertsString ());
}sub NXClusterTools::getSSHCerts{package NXClusterTools;no warnings;
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");return (
NXServers::getSSHCertsString ());}sub NXClusterTools::getNetworkDB{package 
NXClusterTools;no warnings;return (Common::NXFile::getFileContent (
NXPaths::getNetworkDB ()));}sub NXClusterTools::getNetworkFile{package 
NXClusterTools;no warnings;return (Common::NXFile::getFileContent (
NXPaths::getNetworkFile ()));}sub NXClusterTools::getServerDSAPublicKey{package 
NXClusterTools;no warnings;(my $file=NXPaths::getServerDSAPublicKey ());if ((not
 (Common::NXFile::fileExists ($file)))){return ((""));}return (
Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getServerDSAPrivateKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getServerDSAPrivateKey ());if ((not (Common::NXFile::fileExists ($file
)))){return ((""));}return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getServerRSAPublicKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getServerRSAPublicKey ());if ((not (Common::NXFile::fileExists ($file)
))){return ((""));}return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getServerRSAPrivateKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getServerRSAPrivateKey ());if ((not (Common::NXFile::fileExists ($file
)))){return ((""));}return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getPlayerCerts{package NXClusterTools;no warnings;(my $file=
NXPaths::getUserNXKnownCerts ());(my $content=Common::NXFile::getFileContent (
$file));return ($content);}sub NXClusterTools::getClusterMasterCertPub{package 
NXClusterTools;no warnings;(my $file=NXPaths::getClusterHostPublicCert ());if ((
not (Common::NXFile::fileExists ($file)))){generateClusterHostCerts ();}(my $content
=Common::NXFile::getFileContent ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getClusterMasterCertPriv{package NXClusterTools;no warnings;(my $file
=NXPaths::getClusterHostPrivateCert ());if ((not (Common::NXFile::fileExists (
$file)))){generateClusterHostCerts ();}(my $content=
Common::NXFile::getFileContent ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getHttpHostPrivateCert{package NXClusterTools;no warnings;(my $file
=NXPaths::getHttpHostPrivateCert ());(my $content=Common::NXFile::getFileContent
 ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getHttpHostPublicCert{package NXClusterTools;no warnings;(my $file
=NXPaths::getHttpHostPublicCert ());(my $content=Common::NXFile::getFileContent 
($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getClusterHttpMasterCertPub{package NXClusterTools;no warnings;(my $file
=NXPaths::getClusterHttpHostPublicCert ());(my $content=
Common::NXFile::getFileContent ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getSSHHostKeyDSAPrivate{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyDSAPrivate ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyDSAPublic{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyDSAPublic ());(my $content=Common::NXFile::getFileContent
 ($file));return ($content);}sub NXClusterTools::getSSHHostKeyRSAPrivate{package
 NXClusterTools;no warnings;(my $file=NXPaths::getSSHHostKeyRSAPrivate ());(my $content
=Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyRSAPublic{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyRSAPublic ());(my $content=Common::NXFile::getFileContent
 ($file));return ($content);}sub NXClusterTools::getSSHHostKeyECDSAPrivate{
package NXClusterTools;no warnings;(my $file=NXPaths::getSSHHostKeyECDSAPrivate 
());(my $content=Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyECDSAPublic{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyECDSAPublic ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyED25519Private{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyED25519Private ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyED25519Public{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyED25519Public ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getUserKnownHostsSSH{package NXClusterTools;no warnings;return (
Common::NXFile::getFileContent (NXPaths::getUserKnownHostsSSH ()));}sub 
NXClusterTools::__unsync{package NXClusterTools;no warnings;(my $file=shift (@_)
);(my $owner=shift (@_));(my $emptyFile=($file."\x2e\x65\x6d\x70\x74\x79"));if (
Common::NXFile::fileExists ($emptyFile)){__remove ($emptyFile);__remove ($file);
return ((0x01d4+ 4107-0x11df));}(my $fileBackup=($file.
"\x2e\x62\x61\x63\x6b\x75\x70"));if (Common::NXFile::fileExists ($fileBackup)){
Logger::debug ((((("\x52\x65\x6e\x61\x6d\x65\x20\x27".$fileBackup).
"\x27\x20\x74\x6f\x20\x27").$file)."\x27\x2e"));unless (rename ($fileBackup,
$file)){Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$fileBackup)."\x27\x20\x74\x6f\x20\x27").$file)."\x27\x2e\x20").$!));return (
(0x0187+ 7879-0x204d));}if (($owner ne "\x72\x6f\x6f\x74")){
changeFileOwnershipToNxIfRoot ($file);}}return ((0x0720+ 5553-0x1cd1));}sub 
NXClusterTools::__unsyncDatabases{package NXClusterTools;no warnings;
Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x64\x65\x73\x79\x6e\x63\x68\x72\x6f\x6e\x69\x7a\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65\x73\x2e"
);if (__isDatabaseBackupExist ("\x6e\x6f\x64\x65\x73")){main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");NXNodes::cleanDb ();NXNodes::setDatabaseByString
 (__getDatabaseBackup ("\x6e\x6f\x64\x65\x73"));}if (__isDatabaseBackupExist (
"\x70\x72\x6f\x66\x69\x6c\x65\x73")){main::nxrequire (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");NXProfilesDB::cleanDb ();
NXProfilesDB::setDatabaseByString (__getDatabaseBackup (
"\x70\x72\x6f\x66\x69\x6c\x65\x73"));}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73");NXNodeGroups::cleanDb ();
NXRemoteMachinesGroups::cleanLoadedGroups ();if (__isDatabaseBackupExist (
"\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x73")){NXNodeGroups::setDatabaseByString (
__getDatabaseBackup ("\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x73"));}
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73");
NXServerGroups::cleanDb ();NXRemoteMachinesGroups::cleanLoadedGroups ();if (
__isDatabaseBackupExist ("\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73")){
NXServerGroups::setDatabaseByString (__getDatabaseBackup (
"\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73"));}if (
__isDatabaseBackupExist ("\x75\x73\x65\x72\x73")){main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");
NXUsersManager::cleanDb ();NXUsersManager::setDatabaseByString (
__getDatabaseBackup ("\x75\x73\x65\x72\x73"));}if (__isDatabaseBackupExist (
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73")){main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXAdministratorsManager::cleanDb ();
NXAdministratorsManager::setDatabaseByString (__getDatabaseBackup (
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73"));}if (
__isDatabaseBackupExist ("\x63\x65\x72\x74\x73\x4e\x58")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setNXCertsByString (undef,
__getDatabaseBackup ("\x63\x65\x72\x74\x73\x4e\x58"));}if (
__isDatabaseBackupExist ("\x63\x65\x72\x74\x73\x53\x53\x48")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setSSHCertsByString (undef,
__getDatabaseBackup ("\x63\x65\x72\x74\x73\x53\x53\x48"));}if (
__isDatabaseBackupExist ("\x67\x72\x6f\x75\x70\x73")){main::nxrequire (
"\x4e\x58\x47\x72\x6f\x75\x70\x73");NXGroups::cleanDb ();
NXGroups::setDatabaseByString (__getDatabaseBackup ("\x67\x72\x6f\x75\x70\x73"))
;}}sub NXClusterTools::__isDatabaseBackupExist{package NXClusterTools;no 
warnings;(my $database=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x65\x78\x69\x73\x74\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x62\x61\x63\x6b\x75\x70\x2e"
.$database)."\x0a"));return (NXRedis::get ());}sub 
NXClusterTools::__getDatabaseBackup{package NXClusterTools;no warnings;(my $database
=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x62\x61\x63\x6b\x75\x70\x2e"
.$database)."\x0a"));return (main::urldecode (NXRedis::get ()));}sub 
NXClusterTools::__remove{package NXClusterTools;no warnings;(my $file=shift (@_)
);if (Common::NXFile::fileExists ($file)){Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x5b".$file)."\x5d"));if ((not (unlink (
$file)))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20".
$file)."\x20").$!));}}}sub NXClusterTools::unsynchronize{package NXClusterTools;
no warnings;(my $host=shift (@_));__unsync (NXPaths::getUserNXKnownCerts ());
__unsync (NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));__unsync (
NXPaths::getNodePublicKeys ());if ((
Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX (
NXPaths::getNodePublicKeys ())==(-(0x1e93+ 1241-0x236b)))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x66\x69\x6c\x65\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x3a\x20"
.NXPaths::getNodePublicKeys ()));}__unsync (NXPaths::getUserKnownHostsSSH ());
__unsyncDatabases ();__remove (NXPaths::getClusterHostPublicCert ());__remove (
NXPaths::getClusterHostPrivateCert ());if (($host ne "\x6c\x6f\x63\x61\x6c")){
cleanDb ();}__unsync (NXPaths::getNetworkFile ());__unsync (
NXPaths::getNetworkDB ());}sub NXClusterTools::cleanSSHKeys{package 
NXClusterTools;no warnings;__unsync (NXPaths::getSSHHostKeyDSAPrivate (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyDSAPublic (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyRSAPrivate (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyRSAPublic (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyECDSAPrivate (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyECDSAPublic (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyED25519Private (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyED25519Public (),
"\x72\x6f\x6f\x74");}sub NXClusterTools::addClusterKey{package NXClusterTools;no
 warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));(my $rights=
$NXBits::UserReadWrite);return (__appendFile ($file,$rights,$fileContent,
(0x04b5+ 3596-0x1141)));}sub NXClusterTools::setNodesDB{package NXClusterTools;
no warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");__setDatabaseBackup ("\x6e\x6f\x64\x65\x73",
NXNodes::getDatabaseInString ());NXNodes::cleanDb ();return (
NXNodes::setDatabaseByString ($fileContent));}sub 
NXClusterTools::setNodeGroupsDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73"
,"\x69\x6e\x69\x74");__setDatabaseBackup (
"\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x73",NXNodeGroups::getDatabaseInString ())
;NXNodeGroups::cleanDb ();return (NXNodeGroups::setDatabaseByString (
$fileContent));}sub NXClusterTools::setServerGroupsDB{package NXClusterTools;no 
warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73","\x69\x6e\x69\x74");
__setDatabaseBackup ("\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73",
NXServerGroups::getDatabaseInString ());NXServerGroups::cleanDb ();
NXServerGroups::cleanLoadedGroups ();return (NXServerGroups::setDatabaseByString
 ($fileContent));}sub NXClusterTools::setClusterDB{package NXClusterTools;no 
warnings;(my $fileContent=shift (@_));cleanDb ();return (setDatabaseByString (
$fileContent));}sub NXClusterTools::setProfilesDB{package NXClusterTools;no 
warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");__setDatabaseBackup (
"\x70\x72\x6f\x66\x69\x6c\x65\x73",NXProfilesDB::getDatabaseInString ());
NXProfilesDB::cleanDb ();return (NXProfilesDB::setDatabaseByString ($fileContent
));}sub NXClusterTools::setUsersDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");__setDatabaseBackup 
("\x75\x73\x65\x72\x73",NXUsersManager::getDatabaseInString ());
NXUsersManager::cleanDb ();return (NXUsersManager::setDatabaseByString (
$fileContent));}sub NXClusterTools::setAdministratorsDB{package NXClusterTools;
no warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);__setDatabaseBackup (
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73",
NXAdministratorsManager::getDatabaseInString ());
NXAdministratorsManager::cleanDb ();return (
NXAdministratorsManager::setDatabaseByString ($fileContent));}sub 
NXClusterTools::setGroupsDB{package NXClusterTools;no warnings;(my $fileContent=
shift (@_));main::nxrequire ("\x4e\x58\x47\x72\x6f\x75\x70\x73");
__setDatabaseBackup ("\x67\x72\x6f\x75\x70\x73",NXGroups::getDatabaseInString ()
);NXGroups::cleanDb ();return (NXGroups::setDatabaseByString ($fileContent));}
sub NXClusterTools::setNXCertsDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x4e\x58\x20\x63\x65\x72\x74\x73\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");(my $ref_certs=
NXServers::getNXCertsHash ());(my $backup=NXShell::hashParameters2Url (
%$ref_certs));__setDatabaseBackup ("\x63\x65\x72\x74\x73\x4e\x58",$backup);
return (NXServers::setNXCertsByString ($ref_certs,$fileContent));}sub 
NXClusterTools::setSSHCertsDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x53\x53\x48\x20\x63\x65\x72\x74\x73\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");(my $ref_certs=
NXServers::getSSHCertsHash ());(my $backup=NXShell::hashParameters2Url (
%$ref_certs));__setDatabaseBackup ("\x63\x65\x72\x74\x73\x53\x53\x48",$backup);
return (NXServers::setSSHCertsByString ($ref_certs,$fileContent));}sub 
NXClusterTools::setNetworkDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getNetworkDB ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x0466+ 5454-0x1834)));}sub NXClusterTools::setNetworkFile{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getNetworkFile ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));return (__setFile ($file,$rights,
$fileContent,(0x0f2a+ 6221-0x25d3)));}sub NXClusterTools::setServerDSAPublicKey{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getServerDSAPublicKey ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));return (__setFile ($file,$rights,
$fileContent,(0x0d3a+ 1669-0x121b)));}sub NXClusterTools::setServerDSAPrivateKey
{package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getServerDSAPrivateKey ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x192d+ 2099-0x1fe0)));}sub 
NXClusterTools::setServerRSAPublicKey{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getServerRSAPublicKey ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));return (
__setFile ($file,$rights,$fileContent,(0x045a+ 7012-0x1e1a)));}sub 
NXClusterTools::setServerRSAPrivateKey{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getServerRSAPrivateKey ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x03a7+ 3959-0x119e)));}sub NXClusterTools::setClientCerts{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getUserNXKnownCerts ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x20cd+ 128-0x1fcd)));}sub 
NXClusterTools::setAuthorizedCerts{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));(my $rights
=$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x196c+ 508-0x19e8)));}sub NXClusterTools::addSSHAuthorizedCerts{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getNodePublicKeys ());if (Common::NXFile::fileExists ($file)){my (
$error);if ((Common::NXFile::setPermissionsReadWriteForNX ($file,(\$error))==(-
(0x05f2+ 8294-0x2657)))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20\x27"
.$file)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$error).
"\x27\x2e"));return ((0x0731+ 2604-0x115c));}}(my $rights=$NXBits::UserReadWrite
);return (__appendFile ($file,$rights,$fileContent,(0x06c9+ 4736-0x17c9)));}sub 
NXClusterTools::setSSHAuthorizedCerts{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getNodePublicKeys ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x090d+ 7680-0x258d)));}sub NXClusterTools::__setHostPrivateCert{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getHostPrivateCert ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x1f68+ 2181-0x266d)));}sub 
NXClusterTools::__setHostPublicCert{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHostPublicCert ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x191f+ 2790-0x2285)));}sub NXClusterTools::setClusterMasterCertPub{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getClusterHostPublicCert ());(my $rights=$NXBits::UserReadWrite);return
 (__setFile ($file,$rights,$fileContent,(0x0de6+ 4318-0x1d44)));}sub 
NXClusterTools::setClusterMasterCertPriv{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getClusterHostPrivateCert ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x05d9+ 5424-0x1989)));}sub NXClusterTools::setKnownHostsSSH{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getUserKnownHostsSSH ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x0d58+ 134-0x0c5e)));}sub 
NXClusterTools::setSSHHostKeyDSAPrivate{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyDSAPrivate ());(my $rights=
$NXBits::UserReadWrite);__setFile ($file,$rights,$fileContent,
(0x11bc+ 1005-0x1429),"\x72\x6f\x6f\x74");return ((0x10ef+ 3020-0x1cbb));}sub 
NXClusterTools::setSSHHostKeyDSAPublic{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyDSAPublic ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));__setFile (
$file,$rights,$fileContent,(0x15a2+ 2345-0x1d27),"\x72\x6f\x6f\x74");return (
(0x1a72+ 541-0x1c8f));}sub NXClusterTools::setSSHHostKeyRSAPrivate{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyRSAPrivate ());(my $rights=$NXBits::UserReadWrite);
__setFile ($file,$rights,$fileContent,(0x0b12+ 3691-0x17fd),"\x72\x6f\x6f\x74");
return ((0x1b47+ 684-0x1df3));}sub NXClusterTools::setSSHHostKeyRSAPublic{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyRSAPublic ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x1cbd+ 3007-0x26d8),"\x72\x6f\x6f\x74");return ((0x0f2d+ 3696-0x1d9d));}sub 
NXClusterTools::setSSHHostKeyECDSAPrivate{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyECDSAPrivate ());(my $rights=
$NXBits::UserReadWrite);__setFile ($file,$rights,$fileContent,
(0x1411+ 804-0x15b5),"\x72\x6f\x6f\x74");return ((0x1632+ 3627-0x245d));}sub 
NXClusterTools::setSSHHostKeyECDSAPublic{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyECDSAPublic ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));__setFile (
$file,$rights,$fileContent,(0x0dbc+ 2204-0x14b4),"\x72\x6f\x6f\x74");return (
(0x1bcc+ 1120-0x202c));}sub NXClusterTools::setSSHHostKeyED25519Private{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyED25519Private ());(my $rights=$NXBits::UserReadWrite);
__setFile ($file,$rights,$fileContent,(0x0cfd+ 444-0x0d39),"\x72\x6f\x6f\x74");
return ((0x02f4+ 2175-0x0b73));}sub NXClusterTools::setSSHHostKeyED25519Public{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyED25519Public ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x1f56+ 2373-0x26f7),"\x72\x6f\x6f\x74");return ((0x1bb8+ 779-0x1ec3));}sub 
NXClusterTools::__backupPrevious{package NXClusterTools;no warnings;(my $path=
shift (@_));(my $rights=shift (@_));(my $owner=shift (@_));(my $body=shift (@_))
;if ((not (Common::NXFile::fileExists ($path)))){(my $emptyFile=($path.
"\x2e\x65\x6d\x70\x74\x79"));(my $FH=main::nxopen ($emptyFile,($NXBits::O_RDWR+
$NXBits::O_CREAT),(($NXBits::OthersRead+$NXBits::UserReadWrite)+
$NXBits::GroupRead)));if ((not (defined ($FH)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x27"
.$emptyFile)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x2c\x20").$errorString).
"\x2e"));return ((0x024b+ 5316-0x170e));}main::nxclose ($FH);if (($owner ne 
"\x72\x6f\x6f\x74")){changeFileOwnershipToNxIfRoot ($emptyFile);}return (
(0x06eb+ 3893-0x1620));}(my $backup=($path."\x2e\x62\x61\x63\x6b\x75\x70"));if (
Common::NXFile::fileExists ($backup)){($backup.=("\x2d".NXTools::getTimeMs ()));
}if (($body ne (""))){(my $FH=main::nxopen ($backup,($NXBits::O_RDWR+
$NXBits::O_CREAT),$NXBits::UserReadWrite));if ((not (defined ($FH)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x27"
.$emptyFile)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x2c\x20").$errorString).
"\x2e"));return ((0x0b72+ 5323-0x203c));}if ((main::nxwrite ($FH,$body)==(-
(0x09f1+ 3399-0x1737)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$backup)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));main::nxclose ($FH);if (($backupOwner ne 
"\x72\x6f\x6f\x74")){changeFileOwnershipToNxIfRoot ($backup);}return (
(0x01ef+ 3850-0x10f8));}main::nxclose ($FH);if (($owner ne "\x72\x6f\x6f\x74")){
changeFileOwnershipToNxIfRoot ($backup);}return ((0x0325+ 1030-0x072b));}else{(my (
$retValue,$outMsg)=Common::NXCore::copyFile ($path,$backup));if (($outMsg ne 
(""))){Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x27".$path).
"\x27\x20\x74\x6f\x20\x27").$backup).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$outMsg)."\x27\x2e"));
return ((0x1af7+ 1961-0x229f));}}my ($error);if ((Common::NXFile::setPermission 
($backup,$rights,(\$error))==(-(0x0b92+ 841-0x0eda)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20"
.$backup)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$error)."\x27\x2e"
));return ((0x159b+ 1114-0x19f4));}unless (Common::NXFile::fileExists ($backup))
{Logger::error (((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x27"
.$backup)."\x27\x20\x66\x6f\x72\x20\x27").$path)."\x27\x2e"));return (
(0x0ef5+ 954-0x12ae));}if ((($owner ne "\x72\x6f\x6f\x74")and ($owner ne 
"\x6e\x78\x68\x74\x64"))){changeFileOwnershipToNxIfRoot ($backup);}return (
(0x01d0+ 6757-0x1c35));}sub NXClusterTools::__setFile{package NXClusterTools;no 
warnings;(my $file=shift (@_));(my $rights=shift (@_));(my $fileBody=shift (@_))
;(my $backupRights=shift (@_));(my $backupOwner=shift (@_));(my $backupBody=
shift (@_));if (__backupPrevious ($file,$backupRights,$backupOwner,$backupBody))
{return ((0x1241+ 3711-0x20bf));}(my $fileBackup=($file."\x2e\x74\x6d\x70"));(my $fileDesc
=main::nxopen ($fileBackup,($NXBits::O_WRONLY+$NXBits::O_CREAT),$rights));unless
 (defined ($fileDesc)){Logger::error (((
"\x45\x72\x72\x6f\x72\x20\x6f\x70\x65\x6e\x69\x6e\x67\x20\x66\x69\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x27"
.$fileBackup)."\x27\x2e"));return ((0x17a2+ 2772-0x2275));}if ((main::nxwrite (
$fileDesc,$fileBody)==(-(0x02ba+ 3275-0x0f84)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$fileBackup)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));main::nxclose ($fileDesc);if ((($backupOwner ne 
"\x72\x6f\x6f\x74")and ($backupOwner ne "\x6e\x78\x68\x74\x64"))){
changeFileOwnershipToNxIfRoot ($fileBackup);}return ((0x17d9+ 835-0x1b1b));}
main::nxclose ($fileDesc);if ((($backupOwner ne "\x72\x6f\x6f\x74")and (
$backupOwner ne "\x6e\x78\x68\x74\x64"))){changeFileOwnershipToNxIfRoot (
$fileBackup);}unless (rename ($fileBackup,$file)){Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$fileBackup)."\x27\x20\x74\x6f\x20\x27").$file).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$!)."\x27\x2e"));return 
((0x0ff4+ 2771-0x1ac6));}return ((0x0ebb+ 4915-0x21ee));}sub 
NXClusterTools::__appendFile{package NXClusterTools;no warnings;(my $file=shift 
(@_));(my $rights=shift (@_));(my $fileBody=shift (@_));(my $rightBackup=shift (
@_));(my $ownerBackup=shift (@_));if (__backupPrevious ($file,$rightBackup,
$ownerBackup)){return ((0x0a8f+ 4574-0x1c6c));}(my $fileExisted=
(0x2220+ 1243-0x26fb));if (Common::NXFile::fileExists ($file)){($fileExisted=
(0x1a9f+ 1609-0x20e7));}(my $fileDesc=main::nxopen ($file,(($NXBits::O_WRONLY+
$NXBits::O_CREAT)+$NXBits::O_APPEND),$rights));unless (defined ($fileDesc)){
Logger::error (((
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x6f\x70\x65\x6e\x69\x6e\x67\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x74\x6f\x20\x61\x70\x70\x65\x6e\x64\x2e"));return (
(0x0714+ 6488-0x206b));}if ((main::nxwrite ($fileDesc,$fileBody)==(-
(0x1f5b+ 522-0x2164)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.$file)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20").$errorstring)."\x2e"));main::nxclose ($fileDesc);if ((
not ($fileExisted))){if (($ownerBackup ne "\x72\x6f\x6f\x74")){
changeFileOwnershipToNxIfRoot ($file);}}return ((0x03fb+ 237-0x04e7));}
main::nxclose ($fileDesc);if ((not ($fileExisted))){
changeFileOwnershipToNxIfRoot ($file);}return ((0x1d0f+ 2183-0x2596));}sub 
NXClusterTools::__addClusterNodeKey{package NXClusterTools;no warnings;(my $message
=shift (@_));($message=main::urldecode ($message));return (addClusterKey (
$message));}sub NXClusterTools::checkUserNXConfigDir{package NXClusterTools;no 
warnings;(my $path=NXPaths::getConfigDir ());unless (
Common::NXFile::directoryExists ($path)){my ($error);unless (
Common::NXPaths::createAccessibleForNXDirectory ((\$error),$path)){return (
(0x063b+ 1305-0x0b54));}}return ((0x03cb+ 2986-0x0f74));}sub 
NXClusterTools::prepareNXKnownCerts{package NXClusterTools;no warnings;(my $refClusterHash
=shift (@_));my ($file);foreach my $key (keys (%$refClusterHash)){(my $value=
$$refClusterHash{$key});chomp ($value);if (
Common::NXShellCreate::isHostInCertFile ($key,NXPaths::getCurrentUserKnownCerts 
())){Common::NXShellCreate::removeCertificate ($key,$value,
NXPaths::getUserNXKnownCerts ());}($file.=(((("\x48\x6f\x73\x74\x3a".$key).
"\x0a").$value)."\x0a"));}(my $myIp=$GLOBAL::ClusterOldLocal);(my $myCert=
getHostPublicCert ());chomp ($myCert);if (
Common::NXShellCreate::isHostInCertFile ($myIp,NXPaths::getCurrentUserKnownCerts
 ())){Common::NXShellCreate::removeCertificate ($myIp,$myCert,
NXPaths::getUserNXKnownCerts ());}($file.=(((("\x48\x6f\x73\x74\x3a".$myIp).
"\x0a").$myCert)."\x0a"));(my $hostCert=getClusterMasterCertPub ());if (
NXCluster::isSingleCert ()){($hostCert=getHostPublicCert ());}chomp ($hostCert);
if (Common::NXShellCreate::isHostInCertFile ($GLOBAL::ClusterHost,
NXPaths::getCurrentUserKnownCerts ())){Common::NXShellCreate::removeCertificate 
($GLOBAL::ClusterHost,$hostCert,NXPaths::getUserNXKnownCerts ());}($file.=((((
"\x48\x6f\x73\x74\x3a".$GLOBAL::ClusterHost)."\x0a").$hostCert)."\x0a"));($file
.=getPlayerCerts ());setClientCerts ($file);(my $path=
NXPaths::getUserNXKnownCerts ());changeFileOwnershipToNxIfRoot ($path);return (
$file);}sub NXClusterTools::__preparePublicKeys{package NXClusterTools;no 
warnings;(my $ref_publicKeys=shift (@_));(my $protocol=shift (@_));Logger::debug
 (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x50\x72\x65\x70\x61\x72\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x73\x2e"
);(my $file=(""));my ($filePath);if (($protocol eq "\x53\x53\x48")){($filePath=
NXPaths::getNodePublicKeys ());}else{($filePath=NXPaths::getNXAuthorizedKeysPath
 ("\x6e\x78"));}(my $fileContent=Common::NXFile::getFileContent ($filePath));(my (
@oldContent)=split ( /\n/ ,$fileContent,(0x0bc1+ 6094-0x238f)));(my $prefix=
"\x6e\x6f\x2d\x70\x6f\x72\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c\x6e\x6f\x2d\x61\x67\x65\x6e\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c"
);($prefix.=(("\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x22".$GLOBAL::ETC_DIR).
$GLOBAL::DIRECTORY_SLASH));($prefix.=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x72\x65\x6d\x6f\x74\x65\x6c\x6f\x67\x69\x6e\x22\x20"
);foreach my $key (keys (%$ref_publicKeys)){(my $potentialKey=$$ref_publicKeys{
$key});(my $add=(0x0f19+ 2236-0x17d4));chomp ($potentialKey);($potentialKey=~ s/\r//g )
;if (($protocol eq "\x53\x53\x48")){($potentialKey=($prefix.$potentialKey));}
else{($potentialKey.=
"\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x43\x6c\x75\x73\x74\x65\x72");}foreach my $line
 (@oldContent){chomp ($line);($line=~ s/\r//g );if (($potentialKey eq $line)){(
$add=(0x0991+ 4418-0x1ad3));last;}}if (($add==(0x0141+ 3202-0x0dc2))){($file.=(
$potentialKey."\x0a"));}}(my $potentialKey=getClusterPublicKey ());chomp (
$potentialKey);($potentialKey=~ s/\r//g );if (($protocol eq "\x53\x53\x48")){(
$potentialKey=($prefix.$potentialKey));}else{($potentialKey.=
"\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x43\x6c\x75\x73\x74\x65\x72");}(my $add
=(0x1c0f+ 2396-0x256a));foreach my $line (@oldContent){chomp ($line);($line=~ s/\r//g )
;if (($potentialKey eq $line)){($add=(0x1707+ 1828-0x1e2b));last;}}if (($add==
(0x0ab0+ 2895-0x15fe))){($file.=($potentialKey."\x0a"));}($file.=$fileContent);
if (($protocol eq "\x53\x53\x48")){setSSHAuthorizedCerts ($file);}else{
setAuthorizedCerts ($file);}return ($file);}sub 
NXClusterTools::prepareNXDPublicKeys{package NXClusterTools;no warnings;(my $ref_publicKeys
=shift (@_));return (__preparePublicKeys ($ref_publicKeys,"\x4e\x58"));}sub 
NXClusterTools::prepareSSHPublicKeys{package NXClusterTools;no warnings;(my $ref_publicKeys
=shift (@_));return (__preparePublicKeys ($ref_publicKeys,"\x53\x53\x48"));}sub 
NXClusterTools::prepareSSHClusterKey{package NXClusterTools;no warnings;(my $prefix
=
"\x6e\x6f\x2d\x70\x6f\x72\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c\x6e\x6f\x2d\x61\x67\x65\x6e\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c"
);($prefix.=((("\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x22".$GLOBAL::ETC_DIR).
$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x72\x65\x6d\x6f\x74\x65\x6c\x6f\x67\x69\x6e\x22\x20"
));(my $key=($prefix.getClusterPublicKey ()));return ($key);}sub 
NXClusterTools::prepareKnownHostsSSH{package NXClusterTools;no warnings;(my $host
=shift (@_));(my $sshCrt=shift (@_));($sshCrt=~ s/\015//gs );my ($file);if ((
$sshCrt ne (""))){($file=(((($GLOBAL::ClusterPool."\x2c").$GLOBAL::ClusterHost).
"\x20").$sshCrt));}Common::NXShellCreate::removeCertificateSSH (
$GLOBAL::ClusterHost,(""),NXPaths::getUserKnownHostsSSH ());(my (@hosts)=split ( /,/ ,
$GLOBAL::ClusterPool,(0x21b4+ 646-0x243a)));foreach my $host (@hosts){
Common::NXShellCreate::removeCertificateSSH ($host,(""),
NXPaths::getUserKnownHostsSSH ());}($file.=getUserKnownHostsSSH ());
setKnownHostsSSH ($file);return ($file);}sub NXClusterTools::checkKeys{package 
NXClusterTools;no warnings;Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x66\x69\x6c\x65\x73\x2e"
);if ((not (Common::NXFile::fileExists (NXPaths::getClusterRSAPrivateKey ())))){
generateClusterKeys ();}if ((not (Common::NXFile::fileExists (
NXPaths::getClusterRSAPublicKey ())))){generateClusterKeys ();}if ((not (
Common::NXFile::fileExists (NXPaths::getClusterHostPublicCert ())))){
generateClusterHostCerts ();}if ((not (Common::NXFile::fileExists (
NXPaths::getClusterHostPrivateCert ())))){generateClusterHostCerts ();}}sub 
NXClusterTools::changeFileOwnershipToNxIfRoot{package NXClusterTools;no warnings
;return ((0x0b2f+ 5932-0x225b));}sub NXClusterTools::__getPathToPublicKey{
package NXClusterTools;no warnings;if (__isRSAKeyAvailable ()){return (
NXPaths::getClusterRSAPrivateKey ());}return (NXPaths::getClusterDSAPrivateKey 
());}sub NXClusterTools::getDatabaseInString{package NXClusterTools;no warnings;
(my $request=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x73\x74\x65\x72\x2c\x66\x69\x65\x6c\x64\x3d\x73\x68\x61\x72\x65\x64\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x74\x6f\x2c\x66\x69\x65\x6c\x64\x3d\x67\x72\x61\x63\x65"
);($request.=
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x74\x72\x79\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x62\x65\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x76\x61\x6c\x2c\x66\x69\x65\x6c\x64\x3d\x74\x69\x6d\x65\x6f\x75\x74\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x69\x6e\x43\x6c\x75\x73\x74\x65\x72\x55\x55\x49\x44\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x75\x73\x74\x65\x72\x47\x55\x49\x44\x0a"
);(my $databaseString=(""));NXRedis::sendToDb ($request);(my $config=
NXRedis::get ());($config=~ s/ /,/g );($databaseString.=($config."\x0a"));
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x0a"
);(my $clusterList=NXRedis::get ());(my (@list)=split ( / / ,$clusterList,
(0x1be0+ 1789-0x22dd)));foreach $host (@list){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.$host).
"\x2c\x66\x69\x65\x6c\x64\x3d\x68\x6f\x73\x74\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x2c\x66\x69\x65\x6c\x64\x3d\x6e\x65\x74\x6d\x61\x73\x6b\x0a"
));(my $line=NXRedis::get ());($line=~ s/ /,/g );($databaseString.=($line."\x0a"
));}return ($databaseString);}sub NXClusterTools::setDatabaseByString{package 
NXClusterTools;no warnings;(my $string=shift (@_));(my (@clusterList)=split ( /\n/ ,
$string,(0x00ec+ 1910-0x0862)));(my $redisString=__setConfigLine ($clusterList[
(0x187f+ 926-0x1c1d)]));NXRedis::sendToDb ($redisString);(my ($host1data,
$host1set)=__setHostLineS ($clusterList[(0x038d+ 5201-0x17dd)]));
NXRedis::sendToDb ($host1data);NXRedis::sendToDb ($host1set);(my ($host2data,
$host2set)=__setHostLineS ($clusterList[(0x18f5+ 2735-0x23a2)]));
NXRedis::sendToDb ($host2data);NXRedis::sendToDb ($host2set);return (
(0x05c2+ 2713-0x105b));}sub NXClusterTools::__setConfigLine{package 
NXClusterTools;no warnings;(my $configLine=shift (@_));(my $record=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67"
);(my (@options)=split ( /,/ ,$configLine,(0x1037+ 3568-0x1e27)));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x73\x74\x65\x72\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x0630+ 1591-0x0c67)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x68\x61\x72\x65\x64\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x0360+ 2312-0x0c67)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x74\x6f\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x0e8a+ 1721-0x1541)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x67\x72\x61\x63\x65\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x00da+ 8422-0x21bd)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x74\x72\x79\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x09b1+ 4142-0x19db)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x62\x65\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x0bad+ 277-0x0cbd)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x76\x61\x6c\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x1541+ 3887-0x246a)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x74\x69\x6d\x65\x6f\x75\x74\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x06d8+ 2024-0x0eb9)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x69\x6e\x43\x6c\x75\x73\x74\x65\x72\x55\x55\x49\x44\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x0ab9+ 2410-0x141b)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x75\x73\x74\x65\x72\x47\x55\x49\x44\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x1b53+ 579-0x1d8d)]));($record.="\x0a");return ($record);}sub 
NXClusterTools::__setHostLineS{package NXClusterTools;no warnings;(my $hostLine=
shift (@_));(my (@host)=split ( /,/ ,$hostLine,(0x1e66+ 1682-0x24f8)));(my $record
=(
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.$host[(0x0677+ 5744-0x1ce7)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x68\x6f\x73\x74\x2c\x76\x61\x6c\x75\x65\x3d".$host
[(0x060b+ 7999-0x254a)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x2c\x76\x61\x6c\x75\x65\x3d"
.$host[(0x155f+ 3722-0x23e8)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x6e\x65\x74\x6d\x61\x73\x6b\x2c\x76\x61\x6c\x75\x65\x3d"
.$host[(0x1292+ 4525-0x243d)]));($record.="\x0a");(my $setRecord=((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2c\x66\x69\x65\x6c\x64\x3d"
.$host[(0x0a4f+ 307-0x0b82)])."\x0a"));return ($record,$setRecord);}sub 
NXClusterTools::cleanDb{package NXClusterTools;no warnings;NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x0a"
);(my (@hosts)=split ( / / ,NXRedis::get (),(0x12a6+ 4376-0x23be)));
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x0a"
);foreach my $host (@hosts){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.$host)."\x0a"));}NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67\x0a"
);return ((0x066d+ 5522-0x1bff));}sub NXClusterTools::getServerCfgFile{package 
NXClusterTools;no warnings;(my $file=$GLOBAL::CONFIG_FILE);return (
Common::NXFile::getFileContent ($file));}sub NXClusterTools::setServerCfgFile{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
$GLOBAL::CONFIG_FILE);(my $rights=(($NXBits::UserReadWrite+$NXBits::GroupRead)+
$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x110d+ 1172-0x13fd));return ((0x05b4+ 4297-0x167d));}sub 
NXClusterTools::getNodeCfgFile{package NXClusterTools;no warnings;(my $file=
$GLOBAL::NODE_CONFIG_FILE);return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::setNodeCfgFile{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=$GLOBAL::NODE_CONFIG_FILE);(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));__setFile (
$file,$rights,$fileContent,(0x0b79+ 5322-0x1e9f));return ((0x14e9+ 3866-0x2403))
;}sub NXClusterTools::sync{package NXClusterTools;no warnings;if ((
$GLOBAL::ClusterSyncDisabled==(0x0e3c+ 4226-0x1ebd))){Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x6c\x75\x73\x74\x65\x72\x20\x73\x79\x6e\x63\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0c4b+ 5644-0x2256));}main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((not (NXCluster::isClusterConfigured
 ()))){Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x6b\x69\x70\x20\x73\x79\x6e\x63\x20\x66\x6f\x72\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x65\x64\x20\x63\x6c\x75\x73\x74\x65\x72\x2e"
);return;}Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x73\x79\x6e\x63\x2e"
);(my (@command)=());push (@command,($GLOBAL::ETC_DIR.
"\x2f\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2f\x6e\x78\x73\x65\x72\x76\x65\x72\x2f\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65"
));push (@command,"\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x65\x64\x69\x74");(my (
@options)=());(my $logfile=Common::NXPaths::getNXServerLogPath ());push (
@options,"\x73\x74\x64\x65\x72\x72",$logfile);push (@options,
"\x73\x74\x64\x6f\x75\x74",$logfile);push (@options,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x3d".libnxh::NXTransGetEnvironment
 ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")));(my $key
=libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45"));if (($key ne 
(""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".$key));}($key
=libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68"));if (($key ne (""))){push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".$key));}($key=
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"));if (
($key ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".$key));}($key=
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"));
if (($key ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65\x3d".$key));}($key=
libnxh::NXTransGetEnvironment ("\x54\x45\x4d\x50"));if (($key ne (""))){push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x54\x45\x4d\x50\x3d".$key));}($key=
libnxh::NXTransGetEnvironment ("\x54\x4d\x50"));if (($key ne (""))){push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x54\x4d\x50\x3d".$key));}($key=
libnxh::NXTransGetEnvironment ("\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45"));
if (($key ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45\x3d".$key));}main::run_command ((
\@command),(\@options));}sub NXClusterTools::getWebCfgFile{package 
NXClusterTools;no warnings;(my $file=$GLOBAL::HTD_CONFIG_FILE);return (
Common::NXFile::getFileContent ($file));}sub NXClusterTools::setWebCfgFile{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
$GLOBAL::HTD_CONFIG_FILE);(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x03ad+ 442-0x03c3),"\x6e\x78\x68\x74\x64");return (changeFileOwnershipToNxhtd 
($file,"\x63\x6f\x6e\x66\x69\x67"));}sub 
NXClusterTools::setHttpHostPublicCertFile{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHttpHostPublicCert ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));(my $ret=
__setFile ($file,$rights,$fileContent,(0x0902+ 1005-0x0b4b),
"\x6e\x78\x68\x74\x64"));return ($ret);return (changeFileOwnershipToNxhtd ($file
,"\x70\x75\x62\x6c\x69\x63\x43\x65\x72\x74"));}sub 
NXClusterTools::setHttpHostPrivateCertFile{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHttpHostPrivateCert ());(my $rights=
$NXBits::UserReadWrite);(my $orginalContent=(""));(my $ret=__setFile ($file,
$rights,$fileContent,(0x0816+ 232-0x077e),"\x6e\x78\x68\x74\x64",$orginalContent
));return ($ret);return (changeFileOwnershipToNxhtd ($file,
"\x70\x72\x69\x76\x61\x74\x65\x43\x65\x72\x74"));}sub 
NXClusterTools::changeFileOwnershipToNxhtd{package NXClusterTools;no warnings;
return ((0x13bb+ 115-0x142e));}sub NXClusterTools::getHttpHostPrivateCertContent
{package NXClusterTools;no warnings;(my $file=shift (@_));return ((""));}sub 
NXClusterTools::getHostPrivateCert{package NXClusterTools;no warnings;(my $file=
NXPaths::getHostPrivateCert ());(my $content=Common::NXFile::getFileContent (
$file));return ($content);}sub NXClusterTools::setHostPrivateCert{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getHostPrivateCert ());(my $rights=$NXBits::UserReadWrite);__setFile (
$file,$rights,$fileContent,(0x066a+ 3276-0x11b6));return ((0x1815+ 3830-0x270b))
;}sub NXClusterTools::getHostPublicCert{package NXClusterTools;no warnings;(my $file
=NXPaths::getHostPublicCert ());(my $content=Common::NXFile::getFileContent (
$file));return ($content);}sub NXClusterTools::setHostPublicCert{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getHostPublicCert ());(my $rights=$NXBits::UserReadWrite);__setFile (
$file,$rights,$fileContent,(0x1b54+ 1719-0x208b));return ((0x07d0+ 4456-0x1938))
;}package NXClusterTools;no warnings;return ((0x0911+ 6442-0x223a));
