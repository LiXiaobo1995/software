############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTerminate::BEGIN{package NXTerminate;no warnings;require Carp;do{
"\x43\x61\x72\x70"->import};}sub NXTerminate::BEGIN{package NXTerminate;no 
warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}
sub NXTerminate::BEGIN{package NXTerminate;no warnings;require Exception::Base;
do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65"->import};}sub 
NXTerminate::BEGIN{package NXTerminate;no warnings;require Exception::Info;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f"->import};}sub 
NXTerminate::BEGIN{package NXTerminate;no warnings;require 
Exception::InfoManager::RecordNotFound;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4d\x61\x6e\x61\x67\x65\x72\x3a\x3a\x52\x65\x63\x6f\x72\x64\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
->import};}sub NXTerminate::BEGIN{package NXTerminate;no warnings;require 
Exception::Internal;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
import};}package NXTerminate;no warnings;($mainSessionTimeout=7000);(
$attachedSessionTimeout=24000);($connectionMonitorTimeout=(0x0c60+ 8516-0x25d4))
;($defaultTimeout=(0x17f4+ 4845-0x1759));($timeWait=5000);(my $__terminateDuringSwitch
=(0x0ab7+ 7185-0x26c8));($savedTerminateReasonID=(""));($shouldTerminateSession=
(0x0063+ 4805-0x1328));($shouldDisconnectSession=(0x0808+ 2301-0x1104));sub 
terminateConnectionOrDisconnectVirtual{(my $eventType=shift (@_));(my $sessionId
=Server::getMySessionID ());(my $sessionType=NXSession2::getTypeBySessionId (
$sessionId));(my $status=NXSession2::getStatusBySessionId ($sessionId));(my $message
=(""));if (Common::NXSessionType::isVirtualFamily ($sessionType)){($message.=(
$GLOBAL::MSG_REQUEST_SUSPEND.
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x72\x65\x61\x73\x6f\x6e\x3d"
));($message.=chooseCloseReasonByTypeOfSubscriptionEvent (
$shouldDisconnectSession,$eventType));($message.="\x20\x2e");
main::send_command_to_server_get_reply ($sessionId,$message);Logger::debug (((((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$sessionId).
"\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20").
$eventType)."\x2e\x0a"));}elsif (NXSession2::isStatusNegotiating ($status)){
main::nxwrite (main::nxgetSTDOUT (),(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_GET_COMMAND)."\x20"));}elsif ((not (
Common::NXSessionType::isPhysical ($sessionType)))){($message.=
chooseCloseReasonByTypeOfSubscriptionEvent ($shouldTerminateSession,$eventType))
;main::closeSelectedAttachedSession ($sessionId,$message);Logger::debug (((((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$sessionId).
"\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20").
$eventType)."\x2e\x0a"));}}sub chooseCloseReasonByTypeOfSubscriptionEvent{(my $shouldDisconnect
=shift (@_));(my $eventType=shift (@_));(my $message=(""));if (($eventType eq 
"\x65\x78\x70\x69\x72\x65\x64")){if (($shouldDisconnect==
$shouldDisconnectSession)){($message.=
"\x69\x47\x55\x49\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x52\x65\x61\x73\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64"
);}else{($message.=
"\x69\x47\x55\x49\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x52\x65\x61\x73\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64"
);}}elsif (($eventType eq "\x6d\x69\x73\x73\x69\x6e\x67")){($message.=
"\x69\x47\x55\x49\x43\x6c\x6f\x73\x65\x53\x65\x73\x73\x69\x6f\x6e\x52\x65\x61\x73\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x4d\x69\x73\x73\x69\x6e\x67"
);}return ($message);}sub terminateAll{(my $silence=shift (@_));(my $terminateCMs
=(shift (@_)||(0x08fd+ 3539-0x16cf)));if ((not (defined ($silence)))){($silence=
(0x1512+ 1582-0x1b40));}Logger::debug (
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x61\x6c\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x2e"
);if (((not (NXLicense::isKillingLeftoverCMonStarup ()))and $terminateCMs)){
terminateConnectionMonitors ($silence);}terminateAttachedSessions ($silence);
main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);NXAutomaticRecordingNode::shutdownTerminate ();terminateMainSessions ($silence
);main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");
NXNodeCleaner::collect ();}sub terminateAllWithoutCMs{(my $silence=shift (@_));
terminateAll ($silence,(0x0f58+ 4651-0x2183));}sub terminateSpecified{(my (
@sessions)=@_);(my $reasonOfTermination=(""));(my $reasonID=(""));
terminateSpecifiedAndSaveReason ($reasonOfTermination,$reasonID,@sessions);}sub 
terminateSpecifiedWithReasonID{(my $reasonID=(shift (@_)||("")));(my (@sessions)
=@_);(my $reasonOfTermination=(""));terminateSpecifiedAndSaveReason (
$reasonOfTermination,$reasonID,@sessions);}sub terminateSpecifiedAndSaveReason{(my $reasonOfTermination
=(shift (@_)||("")));(my $reasonID=(shift (@_)||("")));(my (@sessions)=@_);if ((
@sessions==(0x0fb5+  29-0x0fd2))){return ((0x0e36+ 2625-0x1877));}($timeWait=
$attachedSessionTimeout);Logger::debug (
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x75\x73\x65\x72\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x2e"
);(my (%sessionsToKill)=__getSpecifiedSessions (@sessions));(my $sessionType=
(""));__sendTerminateSaveReasonAndWait ($silence,$sessionType,
$reasonOfTermination,$reasonID,%sessionsToKill);}sub terminateConnectionMonitor{
(my $uuid=shift (@_));($timeWait=$connectionMonitorTimeout);my ($session);my (
$sessionType);if (NXNodes::isReverseClientType ($uuid)){Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x72\x65\x76\x65\x72\x73\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
.$uuid)."\x27\x2e"));($session=NXSession2::getReverseCMSessionByUuid ($uuid));(
$sessionType=
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);}else{Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
.$uuid)."\x27\x2e"));($session=NXSession2::getCMSessionByUuid ($uuid));(
$sessionType=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");}(my $reasonOfTermination
=(""));(my $reasonID=(""));(my (%specified)=__getSpecifiedSessions ($session));
__sendTerminateSaveReasonAndWait ($silence,$sessionType,$reasonOfTermination,
$reasonID,%specified);}sub terminateDireclyConnected{(my $mainSessionId=shift (
@_));(my $reasonID=shift (@_));Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x64\x69\x72\x65\x63\x74\x6c\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x27"
.$mainSessionId)."\x27\x2e"));($timeWait=$attachedSessionTimeout);(my (
%sessionsToKill)=NXSession2::getDireclyConnected ($mainSessionId));(my $sessionType
="\x61\x74\x74\x61\x63\x68");(my $reasonOfTermination=(""));
__sendTerminateSaveReasonAndWait ($silence,$sessionType,$reasonOfTermination,
$reasonID,%sessionsToKill);}sub __getSpecifiedSessions{(my (@sessions)=@_);(
$sessions[(0x06c3+ 3287-0x139a)]=~ s/^(.*=)//g );my (%result);foreach my $sessionId
 (@sessions){if (($sessionId eq Server::getMySessionID ())){next;}if (
NXSession2::existSession ($sessionId)){if (Common::NXSessionType::isNotPhysical 
(NXSession2::getTypeBySessionId ($sessionId))){($result{$sessionId}=
NXSession2::getPidBySessionId ($sessionId));}}else{NXMsg::error (
"\x65\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x74\x45\x78\x69\x73\x74",
"\x6d\x61\x69\x6e",$sessionId);}}return (%result);}sub __getConnectionMonitor{(my $uuid
=shift (@_));(my (%result)=());(my (@allSessions)=());
NXSession2::getAllCMSessions ((\@allSessions));foreach my $sessionId (
@allSessions){(my ($sessionType,$username,$nodeUuid)=
NXSession2::getTypeOwnerAndNodeBySessionId ($sessionId));if (($sessionType ne 
Common::NXSessionType::getConnectionMonitor ())){next;}if (($nodeUuid ne $uuid))
{next;}($result{$sessionId}=NXSession2::getPidBySessionId ($sessionId));last;}
return (%result);}sub __sendTerminateSaveReasonAndWait{(my $silence=shift (@_));
(my $sessionType=shift (@_));(my $reasonOfTermination=(shift (@_)||("")));(my $reasonID
=(shift (@_)||("")));(my (%sessionsToTerminate)=@_);if ((scalar (keys (
%sessionsToTerminate))==(0x01c2+ 2357-0x0af7))){if ($sessionType){Logger::debug 
((("\x4e\x6f\x20".$sessionType).
"\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"
));}else{Logger::debug (
"\x4e\x6f\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"
);}return ((0x05c7+ 6135-0x1dbe));}(my (%pidsToWait)=());(my (
%allTerminatedSessions)=());(my (%sessionsIDs)=());if ($sessionType){
Logger::debug ((scalar (keys (%sessionsToTerminate)).((
"\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x77\x69\x74\x68\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20"
.$sessionType)."\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e")));}
else{Logger::debug ((scalar (keys (%sessionsToTerminate)).
"\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"
));}foreach my $sessionId (keys (%sessionsToTerminate)){unless ($sessionType){
NXMsg::send_response (
"\x69\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x53\x65\x73\x73\x69\x6f\x6e",
"\x4e\x58\x53\x68\x65\x6c\x6c",$sessionId);}if (NXSession2::existSession (
$sessionId)){if (($reasonOfTermination ne (""))){Logger::warning (((((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27"
.$sessionId)."\x27\x20\x77\x69\x74\x68\x20\x72\x65\x61\x73\x6f\x6e\x20\x27").
$reasonOfTermination)."\x27\x2e"));NXSession2::setReasonOfTerminationBySessionId
 ($sessionId,$reasonOfTermination);}if (NXLocalSession::existLocalNodeForSession
 ($sessionId)){(my $pid=NXSession2::getAgentPidBySessionId ($sessionId));
Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));($pidsToWait{$sessionId}=$pid);(my $socket=
NXLocalSession::getNodeSocketBySessionID ($sessionId));
NXNodeExec::sendNodeTerminateRequestAndLockIfNeeded ($socket);(
$allTerminatedSessions{$sessionId}=$socket);($sessionsIDs{$socket}=$sessionId);
next;}(my $pid=NXSession2::getPidBySessionId ($sessionId));($pidsToWait{
$sessionId}=$pid);if ((not (Common::NXProcess::isOnWatchdogProcess ($pid)))){
Common::NXProcess::addWatchdog ($pid,$NXBITS::SIGCHLD);}}else{Logger::warning ((
(
"\x53\x6b\x69\x70\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$sessionId).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x6f\x73\x65\x64\x2e"))
;next;}my ($socket);if (($reasonID ne (""))){if (NXSession2::isRemoteNodeSession
 ($sessionId)){(my ($host,$port,$uuid)=NXSession2::getNodeBySessionId (
$sessionId));if (NXNodes::doesNodeSupportTerminateReasonID ($uuid)){($socket=
main::terminateSessionNotCloseSocketOneAttempt ($sessionId,$reasonID));}else{(
$socket=main::terminateSessionNotCloseSocketOneAttempt ($sessionId));}}else{(
$socket=main::terminateSessionNotCloseSocketOneAttempt ($sessionId,$reasonID));}
}else{($socket=main::terminateSessionNotCloseSocketOneAttempt ($sessionId));}if 
(((not (defined ($socket)))or ($socket==(-(0x0768+ 3480-0x14ff))))){(
$allTerminatedSessions{$sessionId}=());Logger::warning (((((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20").$pidsToWait{$sessionId}
)."\x2e"));}else{Logger::debug (((((
"\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20".$sessionId).
"\x20\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23").$socket)."\x2e"));(
$allTerminatedSessions{$sessionId}=$socket);($sessionsIDs{$socket}=$sessionId);}
}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;foreach my $key (keys (%allTerminatedSessions)){(my $value=
$allTerminatedSessions{$key});Logger::debug (((((
"\x41\x64\x64\x69\x6e\x67\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23".$value).
"\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20").$key)."\x2e"));if (((not
 (defined ($value)))or ($value==(-(0x0177+ 3100-0x0d92))))){Logger::debug (
"\x53\x6b\x69\x70\x20\x65\x6d\x70\x74\x79\x20\x73\x6f\x63\x6b\x65\x74\x2e");next
;}unless ($selector->add ($value)){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23"
.$value)."\x20\x74\x6f\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"));}}(my $timeout
=$timeWait);(my $finish=(0x028d+ 7524-0x1ff1));(my $signalFd=$$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});if (($selector->count>(0x0645+ 3449-0x13be))){
$selector->add ($signalFd);}else{($finish=(0x0cf4+ 4994-0x2075));}while ((
$finish==(0x0892+ 2149-0x10f7))){(my $startTime=
Common::NXTime::getSecondsSinceEpoch ());(my $sessionsCount=scalar (keys (
%allTerminatedSessions)));if (($sessionsCount==(0x010c+ 8758-0x2342))){if (
$sessionType){Logger::debug (((
"\x4e\x6f\x20\x6d\x6f\x72\x65\x20\x74\x79\x70\x65\x20\x27".$sessionType).
"\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x77\x61\x69\x74\x2e"))
;}else{Logger::debug (
"\x4e\x6f\x20\x6d\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x77\x61\x69\x74\x2e"
);}return ((0x0832+ 5114-0x1c2c));}Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x27".$sessionsCount).
"\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x6f\x63\x6b\x65\x74\x73\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x27"
).$timeout)."\x27\x20\x6d\x73\x2e"));(my (@ready)=$selector->can_read ($timeout)
);if ((scalar (@ready)==(0x15ff+ 273-0x1710))){(my $timewait=(
Common::NXTime::getSecondsSinceEpoch ()-$startTime));Logger::debug (((
"\x57\x61\x69\x74\x65\x64\x20".$timewait).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x3a\x20\x6e\x6f\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x2c\x20\x79\x65\x74\x2e"
));($timeout=($timeout-($timewait *(0x0853+ 5181-0x18a8))));if (($timeout>
(0x0519+ 4879-0x1828))){Logger::debug (((
"\x42\x61\x63\x6b\x20\x74\x6f\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20"
.$timeout)."\x20\x6d\x73\x2e"));next;}(my $sessionsCount=scalar (keys (
%allTerminatedSessions)));if (($sessionsCount>(0x0735+ 1920-0x0eb5))){
Logger::debug (((
"\x54\x69\x6d\x65\x6f\x75\x74\x2c\x20\x74\x68\x65\x72\x65\x20\x61\x72\x65\x20\x73\x74\x69\x6c\x6c\x20\x27"
.$sessionsCount).
"\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"
));($finish=(0x0554+ 8092-0x24ef));next;}if ($sessionType){Logger::debug (((
"\x4e\x6f\x20\x6d\x6f\x72\x65\x20\x74\x79\x70\x65\x20\x27".$sessionType).
"\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x6f\x20\x77\x61\x69\x74\x2e"));}
else{Logger::debug (
"\x4e\x6f\x20\x6d\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x77\x61\x69\x74\x2e"
);}return ((0x15b7+ 248-0x16af));}(my $timeWait_max=(0x0ec0+ 3286-0x1b96));
foreach my $fh (@ready){if (defined ($sessionsIDs{$fh})){my ($read_buf);(my $bytes_read
=main::nxread ($fh,(\$read_buf),(0x126d+ 9084-0x25e9)));Logger::debug (((((((
"\x52\x65\x61\x64\x20\x27".$read_buf)."\x27\x2c\x20").$bytes_read).
"\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").$fh)."\x2e"));if
 (($bytes_read==(0x173a+ 2185-0x1fc3))){if (__isSessionCleanedUp ($sessionsIDs{
$fh})){(my $timewait=(Common::NXTime::getSecondsSinceEpoch ()-$startTime));
Logger::debug ((((("\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".$sessionsIDs{$fh}).
"\x27\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x61\x66\x74\x65\x72\x20").
$timewait)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));unless ($sessionType){
NXMsg::send_response (
"\x69\x53\x65\x73\x73\x69\x6f\x6e\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64",
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65",$sessionsIDs{$fh});}if ((
$timewait>$timeWait_max)){($timeWait_max=$timewait);}delete (
$allTerminatedSessions{$sessionsIDs{$fh}});delete ($sessionsIDs{$fh});$selector
->remove ($fh);if (Server::isDaemonProcess ()){
NXServerDaemon::removeSocketFromMonitoringIfExist ($fh);}main::nxclose ($fh);}
else{Logger::debug ((("\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".$sessionsIDs{$fh}).
"\x27\x20\x63\x6c\x6f\x73\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x62\x75\x74\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x69\x6e\x20\x74\x69\x6d\x65\x2e"
));$selector->remove ($fh);if (Server::isDaemonProcess ()){
NXServerDaemon::removeSocketFromMonitoringIfExist ($fh);}main::nxclose ($fh);}}}
else{Logger::debug ((("\x46\x44\x23".$fh).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x20\x61\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));}}($timeout=($timeout-($timeWait_max *(0x20b4+ 458-0x1e96))));if (($timeout<=
(0x11f8+ 1439-0x1797))){($timeout=(0x0b36+ 2554-0x14cc));}($sessionsCount=scalar
 (keys (%sessionsIDs)));if (($sessionsCount==(0x04b8+ 7333-0x215d))){
Logger::debug (
"\x4e\x6f\x20\x6d\x6f\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"
);($finish=(0x1a35+ 1955-0x21d7));}}Logger::debug (((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20".scalar (keys (%allTerminatedSessions))).
"\x20\x6e\x6f\x74\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x2e"
));foreach my $sessionId (keys (%allTerminatedSessions)){unless ($silence){
unless ($sessionType){if (defined ($username)){NXMsg::send_response (
"\x69\x46\x6f\x72\x63\x69\x6e\x67\x53\x68\x75\x74\x64\x6f\x77\x6e\x53\x65\x73\x73\x69\x6f\x6e\x57\x69\x74\x68\x49\x64\x46\x6f\x72\x55\x73\x65\x72"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$sessionId,$username);}else{NXMsg::send_response
 (
"\x69\x46\x6f\x72\x63\x69\x6e\x67\x53\x68\x75\x74\x64\x6f\x77\x6e\x53\x65\x73\x73\x69\x6f\x6e"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$sessionId);}}}(my ($host,$port,$user,$type,
$display,$agentMDisplay,$remoteSession)=NXSession2::getKillSessionParameters (
$sessionId));if (($host==(-(0x0356+ 7151-0x1f44)))){next;}(my $uuid=
NXNodes::getUuid ($host,$port));if (($type eq 
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72")){
Logger::warning (((((((((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20".
$sessionId)."\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20").$pidsToWait{$sessionId})
."\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20").$host)."\x3a").$port).
"\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"))
;}elsif ((($type eq 
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
)or ($type eq 
"\x6e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
))){Logger::warning (((((((((
"\x4e\x6f\x64\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20").$pidsToWait{$sessionId}
)."\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20").$host)."\x3a").$port).
"\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"))
;}elsif (($remoteSession==(0x19a6+ 1459-0x1f58))){my ($exception);
Logger::warning ((((((("\x53\x65\x73\x73\x69\x6f\x6e\x20".$sessionId).
"\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x20").$host)."\x3a").$port).
"\x20\x72\x65\x61\x63\x68\x65\x64\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x2e"
));if (NXNodes::doesNodeSupportTerminate ($uuid)){
Server::setPassErrorsToUserDisabled ();(my $params=(((
"\x73\x65\x73\x73\x69\x6f\x6e\x69\x64\x3d".$sessionId).
"\x26\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d").$user));if (
NXNodes::doesNodeSupportTerminateWithSessionOwner ($uuid)){($params=(((
"\x73\x65\x73\x73\x69\x6f\x6e\x69\x64\x3d".$sessionId).
"\x26\x73\x65\x73\x73\x69\x6f\x6e\x4f\x77\x6e\x65\x72\x3d").$user));}&try (sub{
NXNodeExec::askNodeAndDie ("\x74\x65\x72\x6d\x69\x6e\x61\x74\x65",$params,$uuid,
$user);},&otherwise (sub{($exception=shift (@_));__handleErrorFromRemoteNode (
$sessionId,$exception);},&finally (sub{Server::setPassErrorsToUserEnabled ();}))
);}else{(my $params=("\x73\x65\x73\x73\x69\x6f\x6e\x5f\x69\x64\x3d".
main::urlencode ((($display."\x2d").$sessionId))));NXNodeExec::askNodeAndDie (
"\x6b\x69\x6c\x6c\x73\x65\x73\x73\x69\x6f\x6e",$params,$uuid,$user);}
terminateForwardServerIfExist ($sessionId);unless ($sessionType){if ((not (
defined ($exception)))){NXMsg::send_response (
"\x69\x53\x65\x73\x73\x69\x6f\x6e\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64",
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65",$sessionId);}}next;}else{
Logger::warning ((("\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".$sessionId).
"\x27\x20\x72\x65\x61\x63\x68\x65\x64\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x2e"
));killSessionNodeProcess ($sessionId);if (Common::NXSessionType::isShadowable (
$type)){($display=$agentMDisplay);}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");NXNodeCleaner::start (
$sessionId,$display,$type,$user);}if ((Common::NXCore::checkIfPidProcessNameIs (
$pidsToWait{$sessionId}),"\x6e\x78\x73\x65\x72\x76\x65\x72")){
NXEvent::beforeKillingHangedProcess ($sessionId,$pidsToWait{$sessionId});if (
Common::NXProcess::sigkill ($pidsToWait{$sessionId})){Logger::warning (((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20".$sessionId).
"\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20").
$pidsToWait{$sessionId}).
"\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x6b\x69\x6c\x6c\x65\x64\x2e"));
terminateForwardServerIfExist ($sessionId);}else{Logger::error (((((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20"
.$pidsToWait{$sessionId})."\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
).$sessionId)."\x2e"));}}(my $processName=NXBegin::getProcessName ());(my $message
=
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x72\x65\x61\x63\x68\x65\x64\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x2e\x20"
);($message.=((
"\x53\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20".$pidsToWait{
$sessionId}).
"\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x6b\x69\x6c\x6c\x65\x64\x20"));(
$message.=((((
"\x77\x69\x74\x68\x20\x73\x69\x67\x6e\x61\x6c\x20\x39\x20\x62\x79\x20".
$processName)."\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20").$ $) .  "\x2e"));
NXSession2::cleanUpLeftoverSession ($sessionId,$message);unless ($sessionType){
NXMsg::send_response (
"\x69\x53\x65\x73\x73\x69\x6f\x6e\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64",
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65",$sessionId);}}foreach my $sessionId
 (keys (%allTerminatedSessions)){__isSessionCleanedUp ($sessionId);}
main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");
NXNodeCleaner::collect ();return ((0x104b+ 2316-0x1957));}sub 
killSessionNodeProcess{(my $sessionId=(shift (@_)||Server::getMySessionID ()));(my $nodePid
=NXSession2::getAgentPidBySessionId ($sessionId));if ((not (defined ($nodePid)))
){Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x64\x61\x74\x61\x62\x61\x73\x65\x2e"
);return ((0x1249+ 3366-0x1f6f));}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nodePid,
"\x6e\x78\x6e\x6f\x64\x65\x7c\x6e\x78\x65\x78\x65\x63")){Logger::warning (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20".$sessionId).
"\x20\x6e\x78\x6e\x6f\x64\x65\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20").$nodePid
)."\x2e"));if (Common::NXProcess::sigkill ($nodePid)){Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x6b\x69\x6c\x6c\x65\x64\x20\x6e\x78\x6e\x6f\x64\x65\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$nodePid)."\x2e"));Common::NXProcess::nxwaitpid ($nodePid,
$NXBits::WAIT_UNTRACED,(0x0d80+ 5528-0x2313));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x6e\x78\x6e\x6f\x64\x65\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$nodePid)."\x2e"));}}}sub __isSessionCleanedUp{(my $session=shift (@_));(my (
$sessionExists,$remoteSession,$pid)=NXSession2::getRemoteAndPidBySessionId (
$session));if (($sessionExists==(0x085b+ 929-0x0bfc))){return (
(0x0895+ 602-0x0aee));}if (($remoteSession==(0x08d1+ 547-0x0af3))){return (
(0x04f3+ 8691-0x26e5));}if ((main::waitUntilProcessDie ($pid)==
(0x0d8c+ 219-0x0e67))){return ((0x1c5b+ 2154-0x24c5));}(my $message=((
"\x53\x65\x72\x76\x65\x72\x20\x27".$pid).
"\x27\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x63\x6c\x65\x61\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x69\x6c\x65\x2e"
));NXSession2::cleanUpLeftoverSession ($session,$message);return (
(0x0a65+ 1186-0x0f06));}sub __oldestVirtual{(my $session=shift (@_));(my $sessionType
="\x6d\x61\x69\x6e");(my $reasonOfTermination=(""));(my $reasonID=(""));
__sendTerminateSaveReasonAndWait ("\x73\x69\x6c\x65\x6e\x63\x65",$sessionType,
$reasonOfTermination,$reasonID,$session);}sub oldestVirtual{(my $session=
NXSession2::selectOldestVirtual ());if ((not ($session))){return ((-
(0x0467+ 1225-0x092f)));}return (__oldestVirtual ($session));}sub 
oldestVirtualUser{(my $user=(shift (@_)||"\x4e\x58\x4c\x6f\x67\x69\x6e"->
getCurrentUser));(my $session=NXSession2::selectOldestVirtualByUser ($user));if 
((not ($session))){return ((-(0x1287+ 736-0x1566)));}return (__oldestVirtual (
$session));}sub oldestVirtualNode{(my $node=shift (@_));(my $session=
NXSession2::selectOldestVirtualByNode ($node));if ((not ($session))){return ((-
(0x0794+ 2598-0x11b9)));}return (__oldestVirtual ($session));}sub 
oldestConnectionUser{(my $user=(shift (@_)||"\x4e\x58\x4c\x6f\x67\x69\x6e"->
getCurrentUser));(my ($session,$type)=NXSession2::selectOldestConnectionByUser (
$user));return (__oldestConnection ($session,$type));}sub oldestConnectionOnNode
{(my $node=shift (@_));(my ($session,$type)=
NXSession2::selectOldestConnectionByNode ($node));return (__oldestConnection (
$session,$type));}sub oldestConnection{(my ($session,$type)=
NXSession2::selectOldestConnection ());return (__oldestConnection ($session,
$type));}sub oldestConnectionUserOnNode{(my $node=shift (@_));(my $user=(shift (
@_)||"\x4e\x58\x4c\x6f\x67\x69\x6e"->getCurrentUser));(my ($session,$type)=
NXSession2::selectOldestConnectionByNodeAndUser ($node,$user));return (
__oldestConnection ($session,$type));}sub __oldestConnection{(my $session=shift 
(@_));(my $type=shift (@_));if (($session ne (""))){if (($type eq 
"\x6d\x61\x69\x6e")){sendDisconnectWaitAndCloseConnection ($session,(
$attachedSessionTimeout/(0x0a97+ 5970-0x1e01)));}else{(my $sessionType=
"\x61\x74\x74\x61\x63\x68");(my $reasonOfTermination=(""));(my $reasonID=(""));
__sendTerminateSaveReasonAndWait ("\x73\x69\x6c\x65\x6e\x63\x65",$sessionType,
$reasonOfTermination,$reasonID,$session);}}}sub closeSession{(my $session=shift 
(@_));(my $reason=shift (@_));(my $reasonID=shift (@_));(my $type=
"\x61\x74\x74\x61\x63\x68");__sendTerminateSaveReasonAndWait (
"\x73\x69\x6c\x65\x6e\x63\x65",$type,$reason,$reasonID,$session);}sub 
sendDisconnectWaitAndCloseConnection{(my $session=shift (@_));(my $timeout=shift
 (@_));sendDisconnectAndWait ($session,$timeout);
NXReconnect::handleReconnectFinished ();}sub sendDisconnectAndWait{(my $session=
shift (@_));(my $timeout=shift (@_));if (($timeout eq (""))){($timeout=
$GLOBAL::TimeoutUntilSessionDie);}if ((NXReconnect::requestDisconnect ($session)
==(0x13ec+ 3336-0x20f3))){NXMsg::send_response (
"\x65\x47\x55\x49\x4e\x6f\x74\x53\x75\x73\x70\x65\x6e\x64\x61\x62\x6c\x65",
"\x6d\x61\x69\x6e",$session);main::nxexit ((0x078b+ 3205-0x140f));}(my $fd=
NXReconnect::getMainServerSocket ());Logger::debug (((((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x52\x65\x71\x75\x65\x73\x74\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27"
.$session).
"\x27\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23"
).$fd)."\x2e"));(my (%params)=());(my $parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);$parser
->add ($$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$parser->add ($fd,(
\&NXReconnect::__callbackMainServer),
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x4d\x61\x69\x6e\x53\x65\x72\x76\x65\x72"
,(\%params));$parser->setCallbackForHandle ($fd,"\x43\x6c\x6f\x73\x65",(
\&NXReconnect::__callbackMainServerSocketClose),
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x4d\x61\x69\x6e\x53\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x43\x6c\x6f\x73\x65"
,(\%params),(0x1502+ 1490-0x1ad3),(0x01e0+ 2541-0x0bcc),(0x1274+ 2915-0x1dd7),
(""));$parser->add (main::nxgetSTDIN (),(\&NXReconnect::__callbackPlayer),
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x50\x6c\x61\x79\x65\x72"
,(\%params));$parser->setCallbackForHandle (main::nxgetSTDIN (),
"\x43\x6c\x6f\x73\x65",(\&NXReconnect::__callbackClosePlayer),
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x43\x6c\x6f\x73\x65\x50\x6c\x61\x79\x65\x72"
,(\%params),(0x01f6+ 2124-0x0a41),(0x001a+ 3319-0x0d10),(0x21e7+ 194-0x22a9),
(""));$parser->setTimeout ($timeout);$parser->setCallbackTimeout ((
\&NXReconnect::__callbackMainServerSocketTimeout),(\%params));while (
NXReconnect::isWaitingForMainServerAnswer ()){$parser->run;}if ((
NXReconnect::isDisconnectSessionConfirmed ()==(0x1f84+ 372-0x20f7))){
Logger::debug ((("\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".$session).
"\x27\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
));NXReconnect::setDisconnectSessionNotConfirmed ();}else{NXMsg::send_response (
"\x65\x47\x55\x49\x4e\x6f\x74\x53\x75\x73\x70\x65\x6e\x64\x61\x62\x6c\x65",
"\x6d\x61\x69\x6e",$session);main::nxexit ((0x0b5d+ 3184-0x17cc));}}sub 
terminateForwardServer{(my $serverPid=shift (@_));(my $authType=shift (@_));(my $sshdPid
=shift (@_));Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$serverPid)."\x2e"));terminateForwardServerWindows ($serverPid,$sshdPid);}sub 
terminateSshNomachineUnix{();}sub terminateSshSystemUnix{();}sub 
terminateForwardServerWindows{(my $forwardServerPid=shift (@_));(my $nxsshdPid=
shift (@_));if (checkProcessBeforeKill ($forwardServerPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if (
Common::NXProcess::winKillTreeProcess ($forwardServerPid,(0x06f4+ 7149-0x22e1)))
{Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x4b\x69\x6c\x6c\x65\x64\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$forwardServerPid)."\x2e"));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$forwardServerPid)."\x2e"));}}if (checkProcessBeforeKill ($nxsshdPid,
"\x73\x73\x68\x64",$ $)) {
 if (Common::NXProcess::winKillTreeProcess (
$nxsshdPid,(0x001f+ 8473-0x2138))){Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x4b\x69\x6c\x6c\x65\x64\x20\x6e\x78\x73\x73\x68\x64\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$nxsshdPid)."\x2e"));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x6e\x78\x73\x73\x68\x64\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$nxsshdPid)."\x2e"));}}}sub terminateForwardServerLinux{(my $serverPid=shift (
@_));(my $authType=shift (@_));(my $sshdPid=shift (@_));if (
checkProcessBeforeKill ($serverPid,"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if
 (Common::NXProcess::sigterm ($serverPid)){Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$serverPid)."\x2e"));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20"
.$serverPid)."\x2e"));}(my $result=Common::NXProcess::waitProcess ($serverPid,
(0x1174+ 2818-0x1c75)));if (checkProcessBeforeKill ($serverPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if (Common::NXProcess::sigkill (
$serverPid)){Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x4b\x69\x6c\x6c\x65\x64\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$serverPid)."\x2e\x2e"));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x73\x65\x72\x76\x65\x72\x20"
.$serverPid)."\x2e"));}}}if (($sshdPid>(0x18d3+ 788-0x1be7))){Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x53\x53\x48\x44\x20\x50\x49\x44\x20"
.$sshdPid)."\x2e"));if (($authType eq NXAuth::getTypeSystem ())){
terminateSshSystemUnix ($sshdPid);}elsif (($authType eq NXAuth::getTypeNomachine
 ())){terminateSshNomachineUnix ($sshdPid);}}}sub terminateSynchronizeServer{(my $serverPid
=shift (@_));if (checkProcessBeforeKill ($serverPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if (Common::NXProcess::sigterm (
$serverPid)){Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x73\x79\x63\x68\x72\x6f\x6e\x69\x7a\x65\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$serverPid)."\x2e"));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x73\x79\x6e\x63\x68\x6f\x6e\x69\x7a\x61\x74\x69\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20"
.$serverPid)."\x2e"));}(my $result=Common::NXProcess::waitProcess ($serverPid,
(0x1826+ 1662-0x1ea3)));if (checkProcessBeforeKill ($serverPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if (Common::NXProcess::sigkill (
$serverPid)){Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x4b\x69\x6c\x6c\x65\x64\x20\x73\x79\x6e\x63\x68\x6f\x6e\x69\x7a\x61\x74\x69\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$serverPid)."\x2e\x2e"));}else{Logger::error (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x73\x79\x6e\x63\x68\x6f\x6e\x69\x7a\x61\x74\x69\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20"
.$serverPid)."\x2e"));}}}}sub terminateLeftoverServer{(my $pid=shift (@_));
terminateLeftoverServerWindows ($pid);}sub terminateLeftoverServerWindows{(my $pid
=shift (@_));if (checkProcessBeforeKill ($pid,"\x6e\x78\x73\x65\x72\x76\x65\x72"
,$ $)) {
 if (Common::NXProcess::winKillTreeProcess ($pid,(0x0f0a+ 772-0x120e)))
{Logger::warning (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x6c\x65\x66\x74\x6f\x76\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x6c\x65\x66\x74\x6f\x76\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));}}}sub terminateLeftoverServerLinux{(my $pid=shift (@_));if 
(checkProcessBeforeKill ($pid,"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if (
Common::NXProcess::sigterm ($pid)){Logger::warning (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x6c\x65\x66\x74\x6f\x76\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x6c\x65\x66\x74\x6f\x76\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));return;}(my $result=Common::NXProcess::waitProcess ($pid,
(0x15e9+ 3087-0x21f7)));if (checkProcessBeforeKill ($pid,
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 if (Common::NXProcess::sigkill ($pid
)){Logger::error (((
"\x4b\x69\x6c\x6c\x65\x64\x20\x6c\x65\x66\x74\x6f\x76\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x6c\x65\x66\x74\x6f\x76\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));}}}}sub terminateForwardServerIfExist{(my $sessionId=shift (
@_));(my ($forwardServerPid,$authType,$sshdPid,$sessionType,$connected)=
NXSession2::checkForwardServerPidBySessionId ($sessionId));if ((
$forwardServerPid>(0x1673+ 2694-0x20f9))){terminateForwardServer (
$forwardServerPid,$authType,$sshdPid);main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (NXCluster::isEnabled ()){if (
Common::NXSessionType::isAttach ($sessionType)){
NXConnectionMonitor::sendDisconnectedToDaemon ($sessionId,(0x20c9+ 101-0x212d));
}elsif (Common::NXSessionType::isVirtual ($sessionType)){if (($connected eq 
"\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
NXConnectionMonitor::sendDisconnectedToDaemon ($sessionId,(0x0b61+ 2911-0x16bf))
;}}}}}sub checkProcessBeforeKill{(my $pid=shift (@_));(my $expectedName=shift (
@_));(my $killerPid=(shift (@_)||$ $));
 if ((($pid==(0x1022+ 1201-0x14d2))or (
$pid==(-(0x0325+ 3834-0x121e))))){Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20".$expectedName).
"\x20\x77\x61\x73\x20\x6b\x69\x6c\x6c\x65\x64\x20\x61\x6c\x72\x65\x61\x64\x79\x2e"
));return ((0x0074+ 8870-0x231a));}if (($pid==$killerPid)){Logger::error (
"\x50\x49\x44\x20\x74\x6f\x20\x6b\x69\x6c\x6c\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x61\x73\x20\x6b\x69\x6c\x6c\x65\x72\x2e"
);return ((0x10c2+ 3251-0x1d75));}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($pid,$expectedName)
){return ((0x00b5+ 7411-0x1da7));}return ((0x0204+ 2949-0x0d89));}sub 
terminateAttachedSessions{(my $silence=shift (@_));(my $reasonID=shift (@_));
Logger::debug (
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x61\x6c\x6c\x20\x61\x74\x74\x61\x63\x68\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x2e"
);($timeWait=$attachedSessionTimeout);(my (%sessionsToTerminate)=
NXSession2::getHashOfAttachedIdsAndPidsWithoutRemoteSessions ());(my $sessionType
="\x61\x74\x74\x61\x63\x68");(my $reasonOfTermination=(""));
__sendTerminateSaveReasonAndWait ($silence,$sessionType,$reasonOfTermination,
$reasonID,%sessionsToTerminate);}sub terminateFowardedSessions{(my $uuid=shift (
@_));(my $silence=shift (@_));Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x20\x66\x72\x6f\x6d\x20\x27"
.$uuid)."\x27\x2e"));($timeWait=$attachedSessionTimeout);(my (
%sessionsToTerminate)=NXSession2::getHashOfForwardedSessionIdsAndPids ($uuid));(my $type
=(""));(my $reason=((
"\x4c\x6f\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x77\x69\x74\x68\x20\x63\x6c\x6f\x75\x64\x20\x73\x65\x72\x76\x65\x72\x20\x27"
.$uuid)."\x27"));(my $reasonID=
"\x69\x47\x55\x49\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x52\x65\x61\x73\x6f\x6e\x4c\x6f\x73\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x57\x69\x74\x68\x43\x53"
);__sendTerminateSaveReasonAndWait ($silence,$type,$reason,$reasonID,
%sessionsToTerminate);}sub terminateConnectionMonitors{(my $silence=shift (@_));
Logger::debug (
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x61\x6c\x6c\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x73\x2e"
);($timeWait=$connectionMonitorTimeout);(my (%sessionsToTerminate)=
NXSession2::getHashOfConnectedMonitorsIdsAndPids ());(my $sessionType=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");(my $reasonOfTermination
=(""));(my $reasonID=(""));__sendTerminateSaveReasonAndWait ($silence,
$sessionType,$reasonOfTermination,$reasonID,%sessionsToTerminate);
NXSession2::checkNotCleanedUpRemoteNodeSessions ();}sub terminateMainSessions{(my $silence
=shift (@_));Logger::debug (
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x61\x6c\x6c\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x2e"
);($timeWait=$mainSessionTimeout);(my (%sessionsToTerminate)=
NXSession2::getHashOfMainIdsAndPidsWithoutRemoteSessions ());(my $sessionType=
"\x6d\x61\x69\x6e");(my $reasonOfTermination=(""));(my $reasonID=(""));
__sendTerminateSaveReasonAndWait ($silence,$sessionType,$reasonOfTermination,
$reasonID,%sessionsToTerminate);}sub setTerminateStartedDuringSwitch{(
$__terminateDuringSwitch=(0x0ba3+ 691-0x0e55));}sub 
isTerminateStartedDuringSwitch{if (($__terminateDuringSwitch==
(0x1280+ 1237-0x1754))){return ((0x1609+ 643-0x188b));}else{return (
(0x079f+ 5164-0x1bcb));}}sub emergencyKillHangedReconnect{(my $sessionId=shift (
@_));my ($display);my ($type);my ($user);(my $isCleanupNeeded=
(0x03b4+ 3650-0x11f6));my ($serverPid);my ($nodePid);if (
NXSession2::existSession ($sessionId)){(($serverPid,$nodePid,$user,$type,
$display)=NXSession2::getDataForCleanupBySessionId ($sessionId));if (
Common::NXCore::checkIfPidProcessNameIs ($nodePid,"\x6e\x78\x6e\x6f\x64\x65")){
Common::NXProcess::signalProcessByRestrictedScript ($nodePid,
Common::NXProcess::getSignalKill ());}if (
Common::NXCore::checkIfPidProcessNameIs ($serverPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72")){Common::NXProcess::sigkill ($serverPid);}(
$isCleanupNeeded=(0x0cd4+ 5366-0x21c9));NXSession2::markSessionFailed (
$sessionId,
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x69\x6e\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x74\x69\x6d\x65\x2e"
);NXSession2::moveSessionToFailedTable ($sessionId);}if ($isCleanupNeeded){
main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");
NXNodeCleaner::start ($sessionId,$display,$type,$user);NXNodeCleaner::collect ()
;}}sub terminateLeftoverServers{(my $ref_processes=__getProcesses ());(my (
%leftoverServers)=());foreach my $process (@$ref_processes){__parseProcessLine (
(\%leftoverServers),$process);}main::nxrequire (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");(my $restartPID=
NXSystemDaemons::getRestartProcessPID ());foreach my $pid (keys (
%leftoverServers)){(my $ref_nxserver=$leftoverServers{$pid});if (($$ref_nxserver
{"\x70\x69\x64"}ne $restartPID)){terminateLeftoverServer ($$ref_nxserver{
"\x70\x69\x64"});}else{Logger::debug (((
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x53\x6b\x69\x70\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x20\x6f\x66\x20\x27\x72\x65\x73\x74\x61\x72\x74\x27\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$restartPID)."\x27\x2e"));}}return;}sub __getProcesses{(my $systemPath=(
NXTools::getWindowsSystemPath ().$GLOBAL::DIRECTORY_SLASH));(my $cmdPath=(
$systemPath.$GLOBAL::CommandCmd));(my $tasklistPath=($systemPath.
$GLOBAL::CommandTasklist));(my (@command)=());push (@command,$cmdPath);push (
@command,(("\x63\x6d\x64\x20\x2f\x43\x20\x22".$tasklistPath)."\x22"));push (
@command,"\x2f\x66\x69",
"\x22\x55\x53\x45\x52\x4e\x41\x4d\x45\x20\x65\x71\x20\x6e\x78\x22");(my $SystemRoot
=libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"));(my $HOMEDRIVE
=libnxh::NXTransGetEnvironment ("\x48\x4f\x4d\x45\x44\x52\x49\x56\x45"));(my $HOMEPATH
=libnxh::NXTransGetEnvironment ("\x48\x4f\x4d\x45\x50\x41\x54\x48"));(my (
@parameters)=());push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".$SystemRoot));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x44\x52\x49\x56\x45\x3d".
$HOMEDRIVE));push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x50\x41\x54\x48\x3d".$HOMEPATH));push (@parameters,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));(my (
@processes)=split ( /\r\n/ ,$cmd_out,(0x08ff+ 2732-0x13ab)));return ((
\@processes));}sub __parseProcessLine{(my $ref_nxservers=shift (@_));(my $line=
shift (@_));($line=~ s/^\s+// );($line=~ s/\s+$// );if (($line=~ /^([\w\.]+)\s+(\d+)\s+(.*)$/ )
){(my $command=$1);(my $pid=$2);if (($pid==$ $)) {
 return;}unless (($command=~ /^nxserver.bin/ )
){return;}($$ref_nxservers{$pid}={"\x70\x69\x64",$pid,
"\x63\x6f\x6d\x6d\x61\x6e\x64",$command});}}sub __handleErrorFromRemoteNode{(my $sessionId
=shift (@_));(my $exception=shift (@_));(my $lastError=
NXNodeExec::getLastErrorLine ());if (Common::NXMsg::isPackedMessage ($lastError)
){(my ($indexString,$message,@parameters)=Common::NXMsg::unpackResponse (
$lastError));if (Common::NXEnglishMessages::isSessionNotExist ($indexString)){
Common::NXMsg::error (
"\x65\x47\x55\x49\x53\x65\x73\x73\x69\x6f\x6e\x4e\x6f\x74\x45\x78\x69\x73\x74\x52\x65\x6d\x6f\x74\x65\x4e\x6f\x64\x65"
,$sessionId);NXSession2::moveSessionFile ($sessionId);}else{$exception->notify;}
}else{$exception->notify;}}sub terminateSpecifiedWithDefaultTimeout{(my $reasonID
=(shift (@_)||("")));(my (@sessions)=@_);if ((@sessions==(0x0785+ 570-0x09bf))){
return ((0x0a09+ 2919-0x1570));}Logger::debug (
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x77\x69\x74\x68\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);($timeWait=$defaultTimeout);(my (%specified)=__getSpecifiedSessions (@sessions
));(my $silence=(0x1ab0+ 2080-0x22d0));(my $type=(""));(my $reason=(""));
__sendTerminateSaveReasonAndWait ($silence,$type,$reason,$reasonID,%specified);}
sub setTerminateSocket{(my $fd=shift (@_));push (@terminateSockets,$fd);}sub 
isTerminateSocket{(my $fd=shift (@_));foreach my $socket (@terminateSockets){if 
(($fd==$socket)){Logger::debug ((("\x46\x44\x23".$socket).
"\x20\x69\x73\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x0043+ 2147-0x08a5));}}Logger::debug ((("\x46\x44\x23".$socket).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x024f+ 503-0x0446));}sub isNotTerminateSocket{(my $fd=shift (@_));
return ((!isTerminateSocket ($fd)));}sub terminateSessionsFromArray{(my (@array)
=@_);my (@sessions);foreach my $session (@array){if (($session eq 
Server::getMySessionID ())){Logger::debug (
"\x49\x67\x6e\x6f\x72\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x20\x6f\x77\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);next;}push (@sessions,$session);}Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x66\x72\x6f\x6d\x20\x61\x72\x72\x61\x79\x20"
.join ($",@sessions))."\x2e"));($timeWait=$attachedSessionTimeout);(my (
%sessionsToTerminate)=__getSessions (@sessions));(my $silence=
(0x16fb+ 1515-0x1ce5));(my $sessionType="\x61\x74\x74\x61\x63\x68");(my $reasonOfTermination
=(""));(my $reasonID=(""));__sendTerminateSaveReasonAndWait ($silence,
$sessionType,$reasonOfTermination,$reasonID,%sessionsToTerminate);}sub 
__getSessions{(my (@sessions)=@_);my (%result);foreach $sessionId (@sessions){if
 (NXSession2::existSession ($sessionId)){($result{$sessionId}=
NXSession2::getPidBySessionId ($sessionId));}}return (%result);}sub 
waitForRunningSession{if ((not (NXSession2::areRunningSessions ()))){
Logger::debug (
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x4e\x6f\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x77\x61\x69\x74\x2e"
);return ((0x02e3+ 2013-0x0ac0));}(my $time=Common::NXTime::getSecondsSinceEpoch
 ());(my $timeout=($time+$GLOBAL::TimeoutForShutdownTerminate));while (($time<
$timeout)){main::nxsleep (0.5);if ((not (NXSession2::areRunningSessions ()))){
Logger::debug (
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x4e\x6f\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x77\x61\x69\x74\x2e"
);return ((0x22db+ 495-0x24ca));}($time=Common::NXTime::getSecondsSinceEpoch ())
;}Logger::warning (
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x73\x20\x61\x72\x65\x20\x73\x74\x69\x6c\x6c\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x61\x66\x74\x65\x72\x20\x73\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x0fa1+ 2688-0x1a20));}sub saveTerminateReasonID{(my $reasonID=shift 
(@_));if (($savedTerminateReasonID eq (""))){($savedTerminateReasonID=$reasonID)
;}}sub getSavedTerminateReasonID{return ($savedTerminateReasonID);}sub 
terminateForwardSessions{(my (%remoteSessionsToTerminate)=@_);if ((keys (
%remoteSessionsToTerminate)>(0x0ee1+ 1259-0x13cc))){NXServers::init ();foreach my $sessionId
 (keys (%remoteSessionsToTerminate)){(my (%parameters)=());($parameters{
"\x74\x61\x72\x67\x65\x74"}=$remoteSessionsToTerminate{$sessionId});($parameters
{"\x73\x65\x73\x73\x69\x6f\x6e\x69\x64"}=$sessionId);($parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x0c8f+ 679-0x0f35));
NXServers::forwardCommand ("\x74\x65\x72\x6d\x69\x6e\x61\x74\x65",(\%parameters)
);}NXShell::startGetCommandStateMachine ();}}NXMsg::register_response (
"\x4e\x58\x54\x65\x72\x6d\x69\x6e\x61\x74\x65",
"\x69\x53\x65\x73\x73\x69\x6f\x6e\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x64",
(0x0b73+ 5466-0x1d49));return ((0x0e0a+ 4749-0x2096));
