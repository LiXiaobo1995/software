############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSystemDaemons::BEGIN{package NXSystemDaemons;no warnings;require 
NXWindowsServices;do{
"\x4e\x58\x57\x69\x6e\x64\x6f\x77\x73\x53\x65\x72\x76\x69\x63\x65\x73"->import};
}package NXSystemDaemons;no warnings;require NXLocate;require NXUpdate;require 
NXServerDaemon;require NXClientSystemDaemons;sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub BEGIN{require NXNodeInfo;do{
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f"->import};}sub BEGIN{require 
Common::NXInfo;do{"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x49\x6e\x66\x6f"->
import};}((%daemonsRestartCounter)=());((%nxupnp)=());((%socket)=());(
$NetworkChangeFD_Read=(-(0x0efc+ 813-0x1228)));($NetworkChangeFD_Write=(-
(0x11c1+ 940-0x156c)));($statusUninitialized=
"\x73\x65\x72\x76\x69\x63\x65\x5f\x75\x6e\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"
);($statusStarting=
"\x73\x65\x72\x76\x69\x63\x65\x5f\x73\x74\x61\x72\x74\x69\x6e\x67");(
$statusRunning="\x73\x65\x72\x76\x69\x63\x65\x5f\x72\x75\x6e\x6e\x69\x6e\x67");(
$statusTerminating=
"\x73\x65\x72\x76\x69\x63\x65\x5f\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67");
($statusClosed="\x73\x65\x72\x76\x69\x63\x65\x5f\x63\x6c\x6f\x73\x65\x64");(
$nxhtdPidFile=(""));($restartPID=(""));sub BEGIN{require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub start{(my $serviceName
=shift (@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");
NXServices::NXD::start ();}elsif (($serviceName eq "\x6e\x78\x68\x74\x64")){
main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");
NXServices::NXHtd::start ();}}sub stop{(my $serviceName=shift (@_));if ((
$serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");
NXServices::NXD::stop ();}elsif (($serviceName eq "\x6e\x78\x68\x74\x64")){
main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");
NXServices::NXHtd::stop ();}elsif (($serviceName eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44\x61\x65\x6d\x6f\x6e"
);NXServices::NXDaemon::stop ();}}sub restart{(my $serviceName=shift (@_));if ((
$serviceName eq "\x6e\x78\x64")){stop ("\x6e\x78\x64");start ("\x6e\x78\x64");}
elsif (($serviceName eq "\x6e\x78\x68\x74\x64")){stop ("\x6e\x78\x68\x74\x64");
start ("\x6e\x78\x68\x74\x64");}}sub isEnabled{(my $serviceName=shift (@_));if (
($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::isEnabled ());}elsif (($serviceName eq "\x6e\x78\x68\x74\x64"))
{main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::isEnabled ());}}sub isDisabled{return ((!isEnabled (@_)));}
sub setEnabled{(my $serviceName=shift (@_));if (($serviceName eq "\x6e\x78\x64")
){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::setEnabled ());}elsif (($serviceName eq "\x6e\x78\x68\x74\x64")
){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::setEnabled ());}}sub setHandlingManualStart{(my $serviceName=
shift (@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::setHandlingManualStart ());}elsif (($serviceName eq 
"\x6e\x78\x68\x74\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::setHandlingManualStart ());}}sub isSilenceMode{(my $serviceName
=shift (@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::isSilenceMode ());}elsif (($serviceName eq 
"\x6e\x78\x68\x74\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::isSilenceMode ());}}sub setSilentMode{(my $serviceName=shift 
(@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::setSilentMode ());}elsif (($serviceName eq 
"\x6e\x78\x68\x74\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::setSilentMode ());}}sub __getPidFile{(my $serviceName=shift (
@_));(my $path=($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH));($path.=(
"\x72\x75\x6e".$GLOBAL::DIRECTORY_SLASH));($path.=($serviceName.
"\x2e\x70\x69\x64"));return ($path);}sub __getStopFlagFileName{(my $serviceName=
shift (@_));if (($serviceName eq "\x6e\x78\x73\x65\x72\x76\x65\x72")){return (
$GLOBAL::ServerStopStatusFlagLink);}(my $path=($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH));($path.=("\x72\x75\x6e".$GLOBAL::DIRECTORY_SLASH));(
$path.=($serviceName."\x2e\x73\x74\x6f\x70"));return ($path);}sub 
stopServiceIfRunningWithoutNXServerDaemon{return ((0x0cda+ 2141-0x1537));(my $serviceName
=shift (@_));if ((not (isRunning ($serviceName)))){return ((0x1989+ 2456-0x2321)
);}if ((NXServerDaemon::checkDaemonFlock ()!=(0x197b+ 930-0x1d1d))){(my $servicePid
=readPid ($serviceName));(my $killProcessTree=(0x05cd+ 707-0x0890));if ((
$serviceName eq "\x6e\x78\x68\x74\x64")){($killProcessTree=(0x07c0+ 3830-0x16b5)
);}killServiceIfRunning ($servicePid,$serviceName,$killProcessTree);}return (
(0x0b4a+ 3534-0x1918));}sub killServiceIfRunning{(my $servicePid=shift (@_));(my $serviceName
=shift (@_));(my $processGroup=shift (@_));(my $silence=(shift (@_)||
(0x1415+  62-0x1453)));if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
$serviceName)){if (main::effectiveUserIsAdministrator ()){if (
Common::NXProcess::sigkill ($servicePid,$processGroup)){Logger::debug (((((
"\x4b\x69\x6c\x6c\x65\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20").$servicePid)."\x2e"));}else{
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x73\x65\x72\x76\x69\x63\x65\x20"
.$serviceName)."\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20").$servicePid)."\x2e"))
;}}else{Common::NXProcess::signalProcessByRestrictedScript ($servicePid,
Common::NXProcess::getSignalKill (),$processGroup);Logger::debug (((((
"\x4b\x69\x6c\x6c\x65\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20").$servicePid)."\x2e"));}(my $waitTimeLimit
=(0x0f7d+ 4893-0x2295));(my $waitInterval=0.1);(my $waitTime=
(0x1ae5+ 258-0x1be7));if (Common::NXProcess::isChildProcess ($servicePid)){
Common::NXProcess::nxwaitpid ($servicePid,$NXBits::WAIT_UNTRACED,$waitTimeLimit)
;}else{Logger::debug2 (((((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x27".$serviceName).
"\x27\x20\x74\x6f\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20\x27"
).$servicePid)."\x27\x2e"));while ((Common::NXProcess::isProcessRunning (
$servicePid)and ($waitTime<$waitTimeLimit))){main::nxsleep ($waitInterval);(
$waitTime+=$waitInterval);}}}if ((not (Common::NXProcess::isProcessRunning (
$servicePid)))){($daemonsPids{$serviceName}=(0x0217+ 7644-0x1ff3));removePidFile
 ($serviceName,$silence);}return;}sub savePid{(my $serviceName=shift (@_));(my $processPid
=shift (@_));(my $filename=__getPidFile ($serviceName));Logger::debug (((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x50\x49\x44\x20\x66\x6f\x72\x20"
.$serviceName)."\x20\x69\x6e\x20\x27").$filename)."\x27\x2e"));(my $FH=
main::nxopen ($filename,($NXBits::O_RDWR+$NXBits::O_CREAT),(($NXBits::OthersRead
+$NXBits::UserReadWrite)+$NXBits::GroupRead)));if ((not (defined ($FH)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error ((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
).$filename)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->throw (((((
"\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$filename)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x3a\x20").
$errorstring)."\x2e"));}(my $write=main::nxwrite ($FH,($processPid."\x0a")));(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());if ((
$write==(-(0x0bef+ 6345-0x24b7)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));main::nxclose ($FH);return ((0x08b0+ 4470-0x1a25));}
main::nxclose ($FH);Logger::debug ((((((("\x53\x65\x72\x76\x69\x63\x65\x20".
$serviceName)."\x20\x50\x49\x44\x20").$processPid).
"\x20\x73\x61\x76\x65\x64\x20\x69\x6e\x20\x27").$filename)."\x27\x2e"));return (
(0x2015+ 898-0x2397));}sub readPid{(my $serviceName=shift (@_));(my $pidFile=
__getPidFile ($serviceName));if ((not (Common::NXFile::isExists ($pidFile)))){
Logger::debug ((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x46\x69\x6c\x65\x20\x27").$pidFile).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));return 
((0x01ef+ 5580-0x17bb));}(my $FH=main::nxopen ($pidFile,$NXBits::O_RDONLY,
(0x18e4+ 1312-0x1e04)));if ((not (defined ($FH)))){return ((0x1600+ 4123-0x261b)
);}my ($processPid);main::nxreadLine ($FH,(\$processPid));main::nxclose ($FH);if
 (($processPid=~ /^(\d+)$/ )){chomp ($processPid);Logger::debug (((((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x52\x65\x61\x64\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
).$pidFile)."\x27\x3a\x20").$processPid)."\x2e"));return ($processPid);}
Logger::warning ((((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x57\x72\x6f\x6e\x67\x20\x66\x6f\x72\x6d\x61\x74\x20\x6f\x66\x20\x50\x49\x44\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
).$pidFile)."\x27\x3a\x20").$processPid)."\x2e"));return ((0x04ab+ 613-0x0710));
}sub removePidFile{(my $serviceName=shift (@_));(my $pidFile=__getPidFile (
$serviceName));if ((not (Common::NXFile::isExists ($pidFile)))){Logger::debug ((
((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27").$pidFile).
"\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x2e"));return (
(0x142c+ 1136-0x189c));}if ((not (unlink ($pidFile)))){Logger::warning (((((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
).$pidFile)."\x27\x3a\x20").$!)."\x2e"));return ((0x0613+ 7539-0x2385));}return 
((0x1201+ 4372-0x2315));}sub __removeNxhtdPidFile{(my $pidFile=shift (@_));(my (
@command)=($GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTD,"\x63\x6c\x65\x61\x6e"))
;(my (@options)=());(my ($cmd_err,$cmd_out,$exit_value)=main::run_command ((
\@command),(\@options)));if (($exit_value!=(0x07b9+ 6199-0x1ff0))){
Logger::warning (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27\x6e\x78\x68\x74\x64\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
.$pidFile)."\x27\x2e"));}}sub isRunning{(my $serviceName=shift (@_));(my $servicePid
=readPid ($serviceName));return (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
$serviceName));}sub printStatus{(my $serviceName=shift (@_));(my $operation=
shift (@_));if (($serviceName eq "\x6e\x78\x6e\x6f\x64\x65")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x4e\x6f\x64\x65");
return (NXServices::NXNode::printStatus ($operation));}if (isRunning (
$serviceName)){if ((not (isSilenceMode ($serviceName)))){main::nxrequire (
"\x4e\x58\x53\x74\x61\x72\x74\x75\x70");if (NXStartup::serviceWasRunning (
$serviceName)){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}
else{NXMsg::info ("\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
}else{if ((not (isSilenceMode ($serviceName)))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
return ((0x0059+ 6435-0x197c));}sub isStopFlag{(my $serviceName=shift (@_));(my $silence
=(shift (@_)||(0x00df+ 2152-0x0947)));(my $stopFlagFile=__getStopFlagFileName (
$serviceName));if (Common::NXFile::isExists ($stopFlagFile)){return (
(0x1fdc+ 1257-0x24c4));}return ((0x207d+ 604-0x22d9));}sub setStopFlag{(my $serviceName
=shift (@_));(my $stopFlagFile=__getStopFlagFileName ($serviceName));(my $FH=
main::nxopen ($stopFlagFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead)));if ((not (
defined ($FH)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
).$stopFlagFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));return ((0x1376+ 3074-0x1f77));}else{
main::nxclose ($FH);}my ($errorName);my ($errorCode);if ((
Common::NXFile::setOwnershipForUserNX ($stopFlagFile,(\$errorName),(\$errorCode)
)==(-(0x040b+ 606-0x0668)))){Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20"
.$stopFlagFile)."\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x6e\x78\x2e\x20").
$errorCode)."\x2c\x20").$errorName)."\x2e"));return ((0x0302+ 3046-0x0ee7));}
return ((0x101d+ 904-0x13a5));}sub removeStopFlag{(my $serviceName=shift (@_));
Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x74\x6f\x70\x20\x66\x6c\x61\x67\x20\x66\x6f\x72\x20"
.$serviceName)."\x2e"));(my $stopFlagFile=__getStopFlagFileName ($serviceName));
if (Common::NXFile::isExists ($stopFlagFile)){if ((not (unlink ($stopFlagFile)))
){Logger::error (((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x27").
$stopFlagFile)."\x27\x3a\x20").$!));return ((0x0525+ 2615-0x0f5b));}}return (
(0x0037+ 1193-0x04e0));}sub isShutdownFlag{(my $shutdownFlagFile=
__getShutdownFlagFileName ());if (Common::NXFile::isExists ($shutdownFlagFile)){
return ((0x1dc8+ 1535-0x23c6));}return ((0x172f+ 2274-0x2011));}sub 
setShutdownFlag{if (isShutdownFlag ()){Logger::debug (
"\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x66\x6c\x61\x67\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74\x2e"
);return ((0x03b8+ 4612-0x15bc));}(my $shutdownFlagFile=
__getShutdownFlagFileName ());(my $FH=main::nxopen ($shutdownFlagFile,(
$NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead)
+$NXBits::OthersRead)));if ((not (defined ($FH)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$shutdownFlagFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"))
;Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring));}else{main::nxclose ($FH);}(my $chownReturn=
Common::NXFile::setOwnershipForUserNX ($shutdownFlagFile));if (($chownReturn==(-
(0x1b53+ 1895-0x22b9)))){return ((0x0223+ 8734-0x2440));}Logger::info (
"\x53\x68\x75\x74\x74\x69\x6e\x67\x20\x64\x6f\x77\x6e\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x73\x2e"
);}sub removeShutdownFlag{(my $shutdownFlagFile=__getShutdownFlagFileName ());if
 (Common::NXFile::isExists ($shutdownFlagFile)){if ((not (unlink (
$shutdownFlagFile)))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x27"
.$shutdownFlagFile)."\x27\x3a\x20").$!));return ((0x0e14+ 1599-0x1452));}}return
 ((0x0c3f+ 5983-0x239e));}sub __getShutdownFlagFileName{(my $path=(((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH));($path.=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x73\x68\x75\x74\x64\x6f\x77\x6e");return (
$path);}sub initUPnPServices{main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
NXUpnp::init ();if (NXUpnp::isUPnPEnabled ()){NXUpnp::checkIfAddPortMapping ();}
return;}sub stopUPnPServices{main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
NXUpnp::deleteServiceRules ((0x0bf7+ 1477-0x11bb),(0x25c3+ 116-0x2637));
NXUpnp::destroy ();return;}sub initNXNetworkChangeService{main::nxrequire (
"\x4e\x58\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65");if (
NXNetworkChange::isNetworkChangeEnabled ()){
NXNetworkChange::startNetworkChangeThread ();}return;}sub 
stopNXNetworkChangeService{main::nxrequire (
"\x4e\x58\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65");
NXNetworkChange::destroy ();return;}sub waitOnSigchld{(my $processName=shift (@_
));(my $processPid=shift (@_));(my $timeout=shift (@_));if ((not (
Common::NXProcess::isChildProcess ($processPid)))){Logger::warning (((
"\x4e\x6f\x74\x20\x6d\x79\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x5b".$processPid).
"\x5d\x20\x69\x73\x20\x6e\x6f\x74\x20\x6d\x79\x20\x63\x68\x69\x6c\x64\x2e"));
return ((0x1089+ 5444-0x25cd));}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);(my $finish=(0x15a3+ 1952-0x1d43));(my $startTime=
Common::NXTime::getSecondsSinceEpoch ());while (($finish!=(0x10cc+ 5347-0x25ae))
){Logger::debug ((((("\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x27".
$processName).
"\x27\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x5b"
).$timeout)."\x5d"));(my (@ready)=$selector->can_read (($timeout *
(0x1d65+ 1134-0x1deb))));if ((not (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($processPid,
$processName)))){($finish=(0x1a4f+ 2606-0x247c));Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$processName).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2e"));}else{(my $timewait=(
Common::NXTime::getSecondsSinceEpoch ()-$startTime));($timeout-=$timewait);if ((
$timeout<=(0x06af+ 3534-0x147d))){($finish=(0x196a+ 2232-0x2221));
Logger::warning (((
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x77\x68\x65\x6e\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x27"
.$processName)."\x27\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"));}}}}sub 
handleServiceClosed{(my $serviceName=shift (@_));if ((not (__isSilenceMode (
$serviceName)))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}
removePidFile ($serviceName,(0x1663+ 1564-0x1c7e));($daemonsPids{$serviceName}=
(0x0eba+ 3567-0x1ca9));NXLocate::requestToRemove ($serviceName);Logger::debug (
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x43\x6c\x6f\x73\x65\x64\x3a\x20\x64\x6f\x6e\x65\x2e"
);}sub handleServiceNotClosed{(my $serviceName=shift (@_));if ((not (
__isSilenceMode ($serviceName)))){NXMsg::info (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
sub waitForServiceClosure{(my $servicePid=shift (@_));(my $serviceName=shift (@_
));if (Common::NXProcess::isChildProcess ($servicePid)){waitOnSigchld (
$serviceName,$servicePid,getClosureTimeout ());}else{(my $waitTimeLimit=
getClosureTimeout ());Logger::debug (((((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x27".$serviceName).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20"
).$waitTimeLimit)."\x2e"));(my $waitInterval=0.1);(my $waitTime=
(0x11a4+ 877-0x1511));while ((
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
$serviceName)and ($waitTime<$waitTimeLimit))){main::nxsleep ($waitInterval);(
$waitTime+=$waitInterval);}}}sub getClosureTimeout{return (
$GLOBAL::DefaultServiceClosureTimeout);}sub fixHttpdAfterUpdate{if (
NXLicense::isHttpdSupportFeature ()){(my $cloudConfigFile=($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH));($cloudConfigFile.=("\x65\x74\x63".
$GLOBAL::DIRECTORY_SLASH));($cloudConfigFile.=
"\x63\x6c\x6f\x75\x64\x2e\x63\x66\x67");if (Common::NXFile::isExists (
$cloudConfigFile)){return;}(my $portalConfigFile=($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH));($portalConfigFile.=("\x65\x74\x63".
$GLOBAL::DIRECTORY_SLASH));($portalConfigFile.=
"\x70\x6f\x72\x74\x61\x6c\x2e\x63\x66\x67");if (Common::NXFile::isExists (
$portalConfigFile)){(my ($retVal,$outMsg)=Common::NXCore::copyFile (
$portalConfigFile,$cloudConfigFile));if (($outMsg ne (""))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x63\x6c\x6f\x75\x64\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20"
.$cloudConfigFile)."\x3a\x20").$outMsg)."\x2e"));return ((0x0c63+ 411-0x0dfe));}
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($cloudConfigFile);
}}}sub fixNXpamAfterUpdate{();}sub fixUuidFile{(my $uuidFile=($GLOBAL::NODE_ROOT
.$GLOBAL::DIRECTORY_SLASH));($uuidFile.=("\x65\x74\x63".$GLOBAL::DIRECTORY_SLASH
));($uuidFile.="\x75\x75\x69\x64");if (Common::NXFile::isExists ($uuidFile)){
return;}Logger::debug (
"\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x75\x75\x69\x64\x20\x66\x69\x6c\x65\x2e");
(my $key=generateUuidKey ());if (($key eq (""))){Logger::warning (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x75\x75\x69\x64\x20\x66\x69\x6c\x65\x2e"
);return ((0x030a+ 2865-0x0e3a));}(my $FH=main::nxopen ($uuidFile,(
$NXBits::O_RDWR+$NXBits::O_CREAT),(($NXBits::OthersRead+$NXBits::UserReadWrite)+
$NXBits::GroupRead)));if ((not (defined ($FH)))){return ((0x1884+ 2321-0x2194));
}if ((main::nxwrite ($FH,$key)==(-(0x03f7+ 1247-0x08d5)))){main::nxclose ($FH);
return ((0x030c+ 6726-0x1d51));}main::nxclose ($FH);
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($uuidFile);chomp (
$key);main::redefine ("\x55\x55\x49\x44",$key);main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");(my ($currentUuid,$host,$port)=
NXNodes::getNodeHostAndPort ("\x6c\x6f\x63\x61\x6c\x68\x6f\x73\x74"));
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setNewUuid (
$key,$currentUuid);}sub generateUuidKey{(my (@command)=());push (@command,
$GLOBAL::COMMAND_NXKEYGEN);push (@command,"\x2d\x75");(my (@options)=());push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));(my $homeDir=
NXPaths::getUserNXHomeDir ());push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".$homeDir));(my ($cmdErr,$cmdOut,$exitValue)=
main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x02f9+ 131-0x037c))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x75\x75\x69\x64\x20\x6b\x65\x79\x20"
.$exitValue).
"\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($cmdOut);}sub askServerDaemonForServiceStatus{(my $service=shift (@_
));(my $response=NXClientSystemDaemons::askForServiceStatus ($service));if ((not
 (defined ($response)))){return (undef);}if (($response=~ /NX> $GLOBAL::MSG_ASK_FOR_SERVICES_STATUS (.*)\n/ )
){($response=$1);}return ($response);}sub 
askServerDaemonForServiceStatusAndRunServicesIfNeeded{(my $service=shift (@_));(my $response
=NXClientSystemDaemons::askForServiceStatusAndRunServicesIfNeeded ($service));if
 ((not (defined ($response)))){return (undef);}if (($response=~ /NX> $GLOBAL::MSG_ASK_FOR_SERVICES_STATUS_AND_RUN_IF_NEEDED (.*)\n/ )
){($response=$1);}return ($response);}sub printServiceStatusByReply{(my $response
=shift (@_));(my $operation=shift (@_));(my (@services)=split ( /, / ,$response,
(0x06fb+ 5605-0x1ce0)));foreach my $service (@services){Logger::debug (((
"\x52\x65\x70\x6f\x72\x74\x69\x6e\x67\x3a\x20".$service)."\x2e"));if (($service
=~ /(.*) Enabled/ )){main::nxrequire ("\x4e\x58\x53\x74\x61\x72\x74\x75\x70");if
 (NXStartup::serviceWasRunning ($1)){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}else{
NXMsg::info ("\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}}elsif ((
$service=~ /(.*) Disabled/ )){main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if (NXShutdown::serviceWasDisabled (
$1)){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}else{
NXMsg::info ("\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}}elsif ((
$service=~ /(.*) NotRunning/ )){if ((($1 eq "\x6e\x78\x6e\x6f\x64\x65")and (
$operation eq "\x73\x74\x61\x72\x74\x75\x70"))){sendMessagePhysicalSessionsError
 ();}}}}sub sendMessagePhysicalSessionsError{NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x6e\x6f\x64\x65");}sub addNetworkChangeFD{(my $ReadPipe=shift (@_));(my $WritePipe
=shift (@_));if ((($ReadPipe eq (""))or ($WritePipe eq ("")))){return;}
NXServerDaemon::addFdToSelector ($ReadPipe);($NetworkChangeFD_Read=$ReadPipe);(
$NetworkChangeFD_Write=$WritePipe);return;}sub removeNetworkChangeFD{if ((
$NetworkChangeFD_Read>=(-(0x06bd+ 7857-0x256d)))){
NXServerDaemon::removeFdFromSelector ($NetworkChangeFD_Read);main::nxclose (
$NetworkChangeFD_Read);($NetworkChangeFD_Read=(-(0x150d+ 1534-0x1b0a)));}(
$NetworkChangeFD_Write=(-(0x0eeb+ 2367-0x1829)));return;}sub addUPnPFD{(my $type
=shift (@_));(my $read=shift (@_));(my $write=shift (@_));(my $port=(shift (@_)
||(0x0e76+ 5816-0x252e)));if (((($type eq (""))or ($read eq ("")))or ($write eq 
("")))){Logger::warning (((((((
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x53\x6b\x69\x70\x20\x55\x50\x6e\x50\x20\x46\x44\x20\x61\x64\x64\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x72\x65\x61\x64\x20\x27").$read).
"\x27\x20\x77\x72\x69\x74\x65\x20\x27").$write)."\x27\x2e"));return;}($nxupnp{
$read}{"\x74\x79\x70\x65"}=$type);($nxupnp{$read}{"\x66\x64"}=$read);($nxupnp{
$read}{"\x66\x64\x5f\x77\x72\x69\x74\x65"}=$write);($nxupnp{$read}{
"\x70\x6f\x72\x74"}=$port);Logger::debug (((((
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x41\x64\x64\x20\x4e\x58\x55\x70\x6e\x70\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x66\x6f\x72\x20\x46\x44\x23").$read)."\x2e"));
NXServerDaemon::addFdToSelector ($read);}sub getUpPnPFDType{(my $fd=(shift (@_)
||("")));if (($fd eq (""))){return ((""));}return ($nxupnp{$fd}{
"\x74\x79\x70\x65"});}sub getUpPnPFDPort{(my $fd=(shift (@_)||("")));if (($fd eq
 (""))){return ((""));}return ($nxupnp{$fd}{"\x70\x6f\x72\x74"});}sub 
removeUPnPFD{(my $fd=(shift (@_)||("")));if (($fd eq (""))){return;}
NXServerDaemon::removeFdFromSelector ($fd);main::nxclose ($nxupnp{$fd}{
"\x66\x64\x5f\x77\x72\x69\x74\x65"});main::nxclose ($fd);delete ($nxupnp{$fd});}
sub isDefinedUPnPFD{(my $fd=shift (@_));if (defined ($nxupnp{$fd})){return (
(0x14b7+ 2946-0x2038));}return ((0x0dc9+ 1758-0x14a7));}sub 
resetDaemonsRestartCounter{(my $service=shift (@_));($daemonsRestartCounter{
$service}=(0x092b+ 1422-0x0eb9));}sub isServiceEnabled{(my $serviceName=shift (
@_));if (($serviceName eq "\x6e\x78\x68\x74\x64")){return (
isHttpdEnabledInLicenceAndConfig ());}elsif (($serviceName eq 
"\x6e\x78\x73\x73\x68\x64")){return (isSSHEnabled ());}elsif (($serviceName eq 
"\x6e\x78\x64")){return (isNxdEnabled ());}return ((0x1aa4+ 1068-0x1ecf));}sub 
isServiceDisabled{return ((!isServiceEnabled (@_)));}sub isFeatureEnabled{(my $serviceName
=shift (@_));if (($serviceName eq "\x6e\x78\x73\x73\x68\x64")){return (
NXLicense::isSshFeature ());}return ((0x0731+ 7453-0x244d));}sub 
isHttpdStartupKeyEnabled{if (NXLicense::isHttpdSupportFeature ()){if (
__isServiceSetToStartAutomatically ("\x6e\x78\x68\x74\x64")){return (
(0x01f4+ 7359-0x1eb2));}}return ((0x0737+ 981-0x0b0c));}sub 
isHttpdStartupKeyDisabled{return ((!isHttpdStartupKeyEnabled ()));}sub 
isHttpEnabledInConfig{if (($GLOBAL::ClientConnectionMethods=~ /HTTP/ )){return (
(0x063a+ 1202-0x0aeb));}return ((0x2061+ 1568-0x2681));}sub 
isHttpdEnabledInLicenceAndConfig{if (NXLicense::isHttpdSupportFeature ()){
Logger::debug (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x4e\x58\x48\x74\x64\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6c\x69\x63\x65\x6e\x73\x65\x2e"
);if (isHttpEnabledInConfig ()){Logger::debug (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x4e\x58\x48\x74\x64\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x63\x6f\x6e\x66\x69\x67\x2e"
);return ((0x05ed+ 867-0x094f));}}Logger::debug (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x4e\x58\x48\x74\x64\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0de7+ 2573-0x17f4));}sub isSSHStartupKeyEnabled{if (
NXLicense::isSshFeature ()){if (__isServiceSetToStartAutomatically (
"\x6e\x78\x73\x73\x68\x64")){return ((0x124f+ 4413-0x238b));}}return (
(0x0f5c+ 1400-0x14d4));}sub isSSHEnabledInConfig{if ((
$GLOBAL::ClientConnectionMethods=~ /SSH/ )){Logger::debug (
"\x53\x53\x48\x20\x69\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64\x73\x20\x6b\x65\x79\x2e"
);return ((0x1fa8+ 1779-0x269a));}Logger::debug (
"\x53\x53\x48\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64\x73\x20\x6b\x65\x79\x2e"
);return ((0x04c9+ 5006-0x1857));}sub isSSHEnabled{if (NXLicense::isSshFeature 
()){if (isSSHEnabledInConfig ()){return ((0x072c+ 3276-0x13f7));}}return (
(0x04f5+ 8078-0x2483));}sub isNxdStartupKeyEnabled{if (
__isServiceSetToStartAutomatically ("\x6e\x78\x64")){return (
(0x04a7+ 4932-0x17ea));}return ((0x1962+ 1171-0x1df5));}sub 
isNxdStartupKeyDisabled{return ((!isNxdStartupKeyEnabled ()));}sub 
isNxdEnabledinConfig{if (($GLOBAL::ClientConnectionMethods=~ /NX/ )){return (
(0x0103+ 7822-0x1f90));}return ((0x0a5c+ 144-0x0aec));}sub isNxdEnabled{if (
isNxdEnabledinConfig ()){return ((0x01ad+ 1587-0x07df));}return (
(0x1a05+ 370-0x1b77));}sub __isServiceSetToStartAutomatically{(my $service=shift
 (@_));(my $key=uc ($service));if (($key eq "\x4e\x58\x44")){($key=
$GLOBAL::StartNXDaemon);}elsif (($key eq "\x4e\x58\x48\x54\x44")){($key=
$GLOBAL::StartHTTPDaemon);}elsif (($key eq "\x4e\x58\x53\x53\x48\x44")){($key=
$GLOBAL::StartSSHDaemon);}($key=uc ($key));if ((($key eq 
"\x41\x55\x54\x4f\x4d\x41\x54\x49\x43")or ($key eq "\x31"))){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service).
"\x27\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x61\x6c\x6c\x79\x2e"
));return ((0x018a+ 9309-0x25e6));}return ((0x00a2+ 8732-0x22be));}sub 
isSystemBasedOnSystemd{return ((0x1832+ 121-0x18ab));}sub 
startupRequrieUpStartSwitch{return ((0x0fc4+ 4814-0x2292));}sub 
__nxserverUpstartServiceFileAvailable{(my $upstartFile=(((((
$GLOBAL::DIRECTORY_SLASH."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x69\x6e\x69\x74").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x63\x6f\x6e\x66"));if (
Common::NXFile::isExists ($upstartFile)){return ((0x080a+ 4421-0x194e));}return 
((0x140a+ 1183-0x18a9));}sub doesRunSystemdExist{(my $dir=(((
$GLOBAL::DIRECTORY_SLASH."\x72\x75\x6e").$GLOBAL::DIRECTORY_SLASH).
"\x73\x79\x73\x74\x65\x6d\x64"));if (Common::NXFile::isExists ($dir)){return (
(0x1299+ 2929-0x1e09));}return ((0x0d9a+ 3554-0x1b7c));}sub handleRestartRequest
{(my $fd=shift (@_));(my $request=shift (@_));Logger::debug (((((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x72\x65\x73\x74\x61\x72\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e"));($request=~ /PID=(.*) / )
;(my $pid=$1);setRestartProcessPID ($pid);($GLOBAL::REQUEST_TERMINATE=
(0x1823+ 1904-0x1f92));setShutdownFlag ();}sub setRestartProcessPID{($restartPID
=shift (@_));Logger::debug (((
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x53\x61\x76\x69\x6e\x67\x20\x72\x65\x73\x74\x61\x72\x74\x20\x50\x49\x44\x20\x27"
.$restartPID)."\x27\x2e"));}sub getRestartProcessPID{return ($restartPID);}
NXMsg::register_error (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
(0x024c+ 7032-0x1bd0));NXMsg::register_error (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
(0x1435+ 1577-0x186a));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
(0x0d4d+ 5567-0x226a));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
(0x09b9+ 4210-0x198a));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,(0x2138+ 100-0x20fb));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,(0x0121+ 8411-0x215a));NXMsg::register_error (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65\x46\x6f\x72\x55\x73\x65\x72"
,(0x08a5+ 7985-0x25e2));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64",
(0x012d+ 3461-0x0e10));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x56\x69\x72\x74\x75\x61\x6c\x73\x44\x69\x73\x61\x62\x6c\x65\x64"
,(0x081d+ 3650-0x15bd));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x56\x69\x72\x74\x75\x61\x6c\x73\x45\x6e\x61\x62\x6c\x65\x64"
,(0x0747+ 1552-0x0cb5));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x57\x65\x43\x61\x6e\x52\x75\x6e\x58\x73\x65\x72\x76\x65\x72"
,(0x0616+ 1691-0x0c0f));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73"
,(0x1852+ 761-0x1adc));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x31"
,(0x0bd9+ 328-0x0cb2));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x32"
,(0x08b8+ 6121-0x2032));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x33"
,(0x1919+ 1111-0x1d01));return ((0x062d+ 1798-0x0d32));
