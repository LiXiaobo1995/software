############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUsb::BEGIN{package NXUsb;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package NXUsb;no warnings;
%usbDB;sub list{(my $extended=(shift (@_)||(0x0188+ 7592-0x1f30)));(my $username
=(shift (@_)||("")));(my (%usbList)=());(my $result=getUsbList ((\%usbList),
$username));if (($result!=(0x0044+ 2841-0x0b5d))){printUsbList ((\%usbList),
$extended);}else{Common::NXMsg::error (
"\x65\x43\x4d\x44\x55\x73\x62\x4c\x69\x73\x74\x46\x61\x69\x6c\x65\x64");}}sub 
add{(my $encodedLine=shift (@_));(my $line=main::urldecode ($encodedLine));(my $usb
=__parseUsbCommandLine ($line));(my $sessionId=Server::getMySessionID ());(my $record
=__createRecord ($sessionId,NXLogin::getCurrentUser (),$usb));(my $result=__add 
($record));(my $hubPort=$$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"});if (($result
==(0x0453+ 1831-0x0b7a))){Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}else{Logger::debug (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x41\x64\x64\x65\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}}sub __createRecord{(my $sessionId=shift (@_));(my $username
=shift (@_));(my $ref_usb=shift (@_));(my $record=(""));($record.=($username.
"\x3a"));($record.=($sessionId."\x3a"));($record.=($$ref_usb{
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65"}."\x3a"));($record.=($$ref_usb{
"\x48\x75\x62\x2d\x50\x6f\x72\x74"}."\x3a"));($record.=($$ref_usb{
"\x53\x74\x61\x74\x75\x73"}."\x3a"));($record.=($$ref_usb{"\x4e\x6f\x64\x65\x73"
}."\x3a"));($record.="\x0a");return ($record);}sub delete{(my $encodedLine=shift
 (@_));(my $line=main::urldecode ($encodedLine));(my $usb=__parseUsbCommandLine 
($line));(my $sessionId=Server::getMySessionID ());(my $hubPort=$$usb{
"\x48\x75\x62\x2d\x50\x6f\x72\x74"});(my $result=__del ($sessionId,$hubPort));if
 (($result==(0x082b+ 1679-0x0eba))){Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}else{Logger::debug (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x44\x65\x6c\x65\x74\x65\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}}sub deleteBySessionId{(my $sessionId=shift (@_));(my $result
=__del ($sessionId));if (($result==(0x172d+  40-0x1755))){Logger::warning (((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x2e"));}else{Logger::debug (((
"\x4e\x58\x55\x73\x62\x3a\x20\x44\x65\x6c\x65\x74\x65\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x2e"));}}sub deleteMySession{return (deleteBySessionId (
Server::getMySessionID ()));}sub __parseUsbCommandLine{(my $lineToParse=shift (
@_));($lineToParse=~ s/[\r\n]//g );(my (@line)=split ( /,/ ,$lineToParse,
(0x193d+ 1853-0x207a)));(my (%usb)=());($usb{
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65"}=$line[(0x0fc8+ 837-0x130d)]);(
$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"}=$line[(0x1973+ 2027-0x215d)]);($usb{
"\x53\x74\x61\x74\x75\x73"}=$line[(0x140a+ 3348-0x211c)]);($usb{
"\x4e\x6f\x64\x65\x73"}=$line[(0x13cb+ 2217-0x1c71)]);return ((\%usb));}sub 
getUsbList{(my $ref_usbList=shift (@_));(my $username=shift (@_));(my $dbFilePath
=NXPaths::getUsbDBPath ());(my $handle=main::nxopen ($dbFilePath,
$NXBits::O_RDONLY));if (defined ($handle)){my ($line);while (main::nxreadLine (
$handle,(\$line))){(my $usb=__parseDBLine ($line));if ($username){if (($username
 eq $$usb{"\x55\x73\x65\x72\x6e\x61\x6d\x65"})){($$ref_usbList{$i++}=$usb);}}
else{($$ref_usbList{$i++}=$usb);}}main::nxclose ($handle);}else{return (
(0x0905+ 1538-0x0f07));}return ((0x2111+ 788-0x2424));}sub printUsbList{(my $ref_usbList
=shift (@_));(my $extended=(shift (@_)||(0x06ea+ 1322-0x0c14)));(my (@labels)=(
"\x55\x73\x65\x72\x6e\x61\x6d\x65","\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44",
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65",
"\x48\x75\x62\x2d\x50\x6f\x72\x74","\x53\x74\x61\x74\x75\x73"));if ($extended){
push (@labels,"\x4e\x6f\x64\x65\x73");}Common::NXMsg::info (
"\x69\x43\x4d\x44\x55\x73\x62\x4c\x69\x73\x74");return (NXTools::printTable ((
\@labels),$ref_usbList));}sub __add{(my $record=shift (@_));(my $dbFilePath=
NXPaths::getUsbDBPath ());(my $lockHandle=main::lockFileDirect ($dbFilePath,
$NXBits::LOCK_EX));(my $dbHandle=main::nxopen ($dbFilePath,(($NXBits::O_WRONLY+
$NXBits::O_CREAT)+$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined 
($dbHandle)))){main::unLockFileDirect ($lockHandle);(my $errorString=
libnxh::NXGetErrorString ());Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20"
.$dbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString).
"\x27"));return ((0x0665+ 3370-0x138f));}(my $bytes=main::nxwrite ($dbHandle,
$record));if (($bytes==(-(0x04f8+ 3984-0x1487)))){(my $errorString=
libnxh::NXGetErrorString ());main::nxclose ($dbHandle);main::unLockFileDirect (
$lockHandle);Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x3a\x20"
.$dbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString).
"\x27"));return ((0x0bb1+ 2421-0x1526));}main::nxclose ($dbHandle);
main::unLockFileDirect ($lockHandle);return ((0x05a0+ 4061-0x157c));}sub __del{(my $sessionId
=shift (@_));(my $hubPort=shift (@_));(my $dbFilePath=NXPaths::getUsbDBPath ());
(my $flag_del=(0x0294+ 3977-0x121d));(my $lockHandle=main::lockFileDirect (
$dbFilePath,$NXBits::LOCK_EX));(my $dbHandle=main::nxopen ($dbFilePath,
$NXBits::O_RDONLY,(0x1006+ 431-0x11b5)));if ((not (defined ($dbHandle)))){(my $errorString
=libnxh::NXGetErrorString ());main::unLockFileDirect ($lockHandle);
Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20"
.$dbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString).
"\x27"));return ((0x20d2+ 745-0x23bb));}(my $tempdbFilePath=(($dbFilePath.
"\x2e\x74\x6d\x70\x2e").$ $));
 if (Common::NXFile::isExists ($tempdbFilePath)){
unlink ($tempdbFilePath);}(my $tmpHandle=main::nxopen ($tempdbFilePath,((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND),$NXBits::UserReadWrite));
if ((not (defined ($tmpHandle)))){(my $errorString=libnxh::NXGetErrorString ());
main::nxclose ($dbHandle);main::unLockFileDirect ($lockHandle);Logger::warning (
((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20"
.$tempdbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").
$errorString)."\x27"));return ((0x0b97+ 4420-0x1cdb));}&try (sub{my ($line);
while (main::nxreadLine ($dbHandle,(\$line))){(my $usb=__parseDBLine ($line));(
$usbDB{$$usb{"\x55\x73\x65\x72\x6e\x61\x6d\x65"}}=$usb);if ((($sessionId ne 
$$usb{"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44"})or ($hubPort and ($hubPort ne 
$$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"})))){
Common::NXCore::nxwriteOrThrowException ($tmpHandle,$line);}}},&otherwise (sub{(my $error
=shift (@_));main::nxclose ($tmpHandle);main::nxclose ($dbHandle);
main::unLockFileDirect ($lockHandle);Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x3a\x20"
.$tempdbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$error).
"\x27"));return ((0x0fbf+ 5338-0x2499));}));main::nxclose ($tmpHandle);
main::nxclose ($dbHandle);if ((not (Common::NXFile::renameFile ($tempdbFilePath,
$dbFilePath)))){(my $errorString=libnxh::NXGetErrorString ());
main::unLockFileDirect ($lockHandle);Logger::warning (((((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x3a\x3a\x20"
.$tempdbFilePath)."\x20\x74\x6f\x3a\x20").$dbFilePath).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString)."\x27"));
return ((0x1063+ 4151-0x209a));}main::unLockFileDirect ($lockHandle);return (
(0x04d7+ 808-0x07fe));}sub __parseDBLine{(my $lineToParse=shift (@_));(
$lineToParse=~ s/[\r\n]//g );(my (@line)=split ( /:/ ,$lineToParse,
(0x0965+ 5210-0x1dbf)));(my (%usb)=());($usb{"\x55\x73\x65\x72\x6e\x61\x6d\x65"}
=$line[(0x0bc1+ 3034-0x179b)]);($usb{"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44"}
=$line[(0x1ba4+ 2768-0x2673)]);($usb{
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65"}=$line[(0x0812+ 488-0x09f8)]);(
$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"}=$line[(0x1bf3+ 1308-0x210c)]);($usb{
"\x53\x74\x61\x74\x75\x73"}=$line[(0x04d6+ 4055-0x14a9)]);($usb{
"\x4e\x6f\x64\x65\x73"}=$line[(0x0667+ 7276-0x22ce)]);return ((\%usb));}
"\x3f\x3f\x3f";
