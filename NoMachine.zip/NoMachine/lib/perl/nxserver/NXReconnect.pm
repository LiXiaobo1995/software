############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXReconnect;no warnings;($mainServerSocket=undef);(
$waitingForMainServerAnswer=(0x08a0+ 2672-0x1310));($__reconnectSocket=(-
(0x13e9+ 2289-0x1cd9)));($__reconnectTimestamp=(-(0x0bfd+ 5262-0x208a)));(
$__reconnectSessionId=(-(0x099d+  63-0x09db)));($__ref_monitorSelect=undef);(
@__waitingForReconnectToFinish=());($__isReconnectWaitingForDisconnectAnswer=
(0x0ab4+ 993-0x0e95));($__agentReconnecting=(0x0a71+ 1273-0x0f6a));sub 
requestDisconnect{($mainServerSessionId=shift (@_));(my $mainServerSocket=
sendRequestDisconnect ($mainServerSessionId));if ((defined ($mainServerSocket)
and ($mainServerSocket!=(-(0x13e8+ 1477-0x19ac))))){setMainServerSocket (
$mainServerSocket);startWaitingOnMainServerAnswer ();
setDisconnectSessionNotConfirmed ();return ((0x09a7+ 3215-0x1636));}else{
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);return ((0x0140+ 2168-0x09b7));}}sub sendRequestDisconnect{(my $sessionID=
shift (@_));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x27\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x71\x75\x65\x73\x74\x27\x20\x74\x6f\x20"
.$sessionID)."\x20\x73\x65\x72\x76\x65\x72\x2e"));my ($message);if (
main::imRemoteServer ()){($message=($GLOBAL::MSG_REQUEST_SUSPEND_AND_WAIT.
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x6e\x64\x20\x77\x61\x69\x74\x20\x6f\x6e\x20\x72\x65\x6d\x6f\x74\x65\x2e"
));}else{($message=($GLOBAL::MSG_REQUEST_SUSPEND_AND_WAIT.
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x6e\x64\x20\x77\x61\x69\x74\x2e"
));}return (main::send_command_to_server ($sessionID,$message,
"\x6e\x6f\x74\x63\x6c\x6f\x73\x65"));}sub startWaitingOnMainServerAnswer{(
$waitingForMainServerAnswer=(0x1133+ 3174-0x1d98));}sub 
stopWaitingOnMainServerAnswer{($waitingForMainServerAnswer=(0x08fb+ 6527-0x227a)
);}sub isWaitingForMainServerAnswer{if (($waitingForMainServerAnswer==
(0x074a+ 3915-0x1694))){return ((0x04a2+ 6074-0x1c5b));}return (
(0x144c+ 2980-0x1ff0));}sub isNotWaitingForMainServerAnswer{return ((!
isWaitingForMainServerAnswer ()));}sub __getStopWaitingMessage{return ((
$GLOBAL::MSG_REQUEST_SUSPEND_AND_WAIT.
"\x20\x53\x74\x6f\x70\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
));}sub getMessageConfirmDisconnect{return (
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2c\x20\x72\x65\x61\x64\x79\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);}sub getMessageAnotherReconnectInProgress{return (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73\x2e"
);}sub getMessageAnotherReconnectFinished{return (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2c\x20\x74\x72\x79\x20\x61\x67\x61\x69\x6e\x2e"
);}sub setMainServerSocket{($mainServerSocket=shift (@_));}sub 
getMainServerSocket{return ($mainServerSocket);}sub isAlreadySessionDisconnected
{if (isWaitingForMainServerAnswer ()){return ((0x080a+ 1294-0x0d18));}if (
isDisconnectSessionConfirmed ()){return ((0x05aa+ 2380-0x0ef5));}return (
(0x0eff+ 2031-0x16ee));}sub handleClientExit{(my $mainServerSocket=
getMainServerSocket ());if (defined ($mainServerSocket)){main::nxclose (
$mainServerSocket);setMainServerSocket (undef);}}sub 
setDisconnectSessionConfirmed{($disconnectSessionConfirmed=(0x1f82+ 142-0x200f))
;}sub setDisconnectSessionNotConfirmed{($disconnectSessionConfirmed=
(0x0ceb+ 4499-0x1e7e));}sub isDisconnectSessionConfirmed{if ((
$disconnectSessionConfirmed==(0x02aa+ 5117-0x16a6))){return (
(0x10af+ 1701-0x1753));}return ((0x1bd3+ 2800-0x26c3));}sub 
setDisconnectSessionTryAgain{($disconnectSessionTryAgain=(0x0257+ 6697-0x1c7f));
}sub setDisconnectSessionNotTryAgain{($disconnectSessionTryAgain=
(0x0ef0+ 1596-0x152c));}sub isDisconnectSessionTryAgain{return (
$disconnectSessionTryAgain);}sub setServerError{($serverError=
(0x0b71+ 6006-0x22e6));}sub isServerError{if (($serverError==
(0x0f9a+ 2707-0x1a2c))){return ((0x0301+ 6539-0x1c8b));}return (
(0x0064+ 432-0x0214));}sub handleServerError{if (isServerError ()){return (
(0x14f8+ 2204-0x1d93));}return ((0x088f+ 1693-0x0f2c));}sub __callbackMainServer
{(my $self=shift (@_));(my $handleHash=shift (@_));(my $readBuffer=shift (@_));(my $readBytes
=shift (@_));($buffer.=$readBuffer);Logger::debug ((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x62\x75\x66\x66\x65\x72\x3a\x20"
.$buffer));while (($buffer ne (""))){my ($line);(($buffer,$line)=
__getLineAndBufferLeft ($buffer));if (($line ne (""))){__handleMainServerMessage
 ($line,$handleHash,$self);}}}sub __callbackMainServerSocketClose{(my $self=
shift (@_));(my $handleHash=shift (@_));Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6d\x61\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);$self->removeAndCloseHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});if ((
not (isAlreadySessionDisconnected ()))){handleCannotDisconnectAnotherReconnect 
();}}sub isDisconnectSocket{(my $socket=shift (@_));if (($__reconnectSocket==
$socket)){Logger::debug ((("\x46\x44\x23".$socket).
"\x20\x69\x73\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x1120+ 5009-0x24b0));}Logger::debug ((("\x46\x44\x23".$socket).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x0020+ 681-0x02c9));}sub isNotDisconnectSocket{(my $socket=shift (
@_));return ((!isDisconnectSocket ($socket)));}sub 
saveSocketForSusspendSessionAnswer{(my $socket=shift (@_));(my $ref_select=shift
 (@_));Logger::debug (((
"\x53\x74\x61\x72\x74\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));($__reconnectSocket=$socket);($__ref_monitorSelect=
$ref_select);($__reconnectTimestamp=Common::NXTime::getSecondsSinceEpoch ());}
sub saveSocketWaitingForReconnectToFinish{(my $socket=shift (@_));Logger::debug 
(((
"\x53\x61\x76\x69\x6e\x67\x20\x61\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x46\x44\x23"
.$socket).
"\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x6f\x6e\x65\x20\x74\x6f\x20\x66\x69\x6e\x69\x73\x68\x2e"
));push (@__waitingForReconnectToFinish,$socket);}sub 
informReconnectSessionAboutDisconnect{Logger::debug (
"\x49\x6e\x66\x6f\x72\x6d\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x62\x6f\x75\x74\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);if (($__reconnectSocket!=(-(0x0772+ 421-0x0916)))){if (
__isReconnectWaitingForDisconnectAnswer ()){main::send_reply_to_socket (
$__reconnectSocket,(getMessageConfirmDisconnect ()."\x0a"));
__unsetIsReconnectWaitingForDisconnectAnswer ();}else{setReconnectOver ();}}}sub
 __callbackPlayer{(my $self=shift (@_));(my $handleHash=shift (@_));(my $readBuffer
=shift (@_));(my $readBytes=shift (@_));Logger::warning (((((
"\x55\x6e\x73\x75\x73\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x63\x6c\x69\x65\x6e\x74\x3a\x20"
.$readBytes)."\x20\x27").$readBuffer)."\x27\x2e"));}sub __callbackClosePlayer{
stopWaitingOnMainServerAnswer ();setDisconnectSessionNotConfirmed ();
handleClientExit ();}sub __callbackMainServerSocketTimeout{Logger::warning (
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x72\x6f\x6d\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
);stopWaitingOnMainServerAnswer ();setDisconnectSessionNotConfirmed ();
handleCannotDisconnectAnotherReconnect ();}sub isReconnectInProgress{if ((
$__reconnectSocket!=(-(0x2237+ 1137-0x26a7)))){Logger::debug (((
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x65\x73\x73\x20\x6f\x6e\x20\x46\x44\x23"
.$__reconnectSocket)."\x2e"));return ((0x020d+ 448-0x03cc));}Logger::debug (
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6e\x6f\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x65\x73\x73\x2e"
);return ((0x1144+ 5372-0x2640));}sub setReconnectOver{Logger::debug (((
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6f\x76\x65\x72\x20\x6f\x6e\x20\x46\x44\x23"
.$__reconnectSocket)."\x2e"));if (($__reconnectSocket!=(-(0x0a55+ 6972-0x2590)))
){if (defined ($__ref_monitorSelect)){if ($$__ref_monitorSelect->exists (
$__reconnectSocket)){$$__ref_monitorSelect->remove ($__reconnectSocket);}}
Common::NXSelector::removeFromGlobalSelector ($__reconnectSocket);main::nxclose 
($__reconnectSocket);($__reconnectSocket=(-(0x141a+ 437-0x15ce)));(
$__reconnectSessionId=(-(0x1acc+ 523-0x1cd6)));
__unsetIsReconnectWaitingForDisconnectAnswer ();__unsetAgentReconnecting ();}
__informWaitingSessionsWeAreReadyForReconnect ();}sub handleReconnectTimeout{
Logger::debug (((
"\x48\x61\x6e\x64\x6c\x65\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$__reconnectSocket)."\x2e"));if (($__reconnectSocket!=(-(0x0bd5+ 3125-0x1809)))
){(my $time=Common::NXTime::getSecondsSinceEpoch ());if (($time>(
$__reconnectTimestamp+$GLOBAL::timeoutForSessionReconnect))){if (
__isAgentReconnecting ()){Logger::debug (
"\x41\x67\x65\x6e\x74\x20\x69\x73\x20\x73\x74\x69\x6c\x6c\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67\x20\x69\x67\x6e\x6f\x72\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);}else{Logger::warning ((("\x54\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20".
$GLOBAL::timeoutForSessionReconnect).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
));if (($__reconnectSessionId!=(-(0x032c+ 8549-0x2490)))){Logger::warning (((
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20".$__reconnectSessionId).
"\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x69\x6e\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x74\x69\x6d\x65\x2e"
));NXTerminate::emergencyKillHangedReconnect ($__reconnectSessionId);
NXNodeExec::deleteUser ($__reconnectSessionId,Server::getMySessionID ());(
$__reconnectSessionId=(-(0x0bc8+ 3126-0x17fd)));}setReconnectOver ();}}}}sub 
handleReconnectFinished{Logger::debug (
"\x48\x61\x6e\x64\x6c\x65\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2e"
);setReconnectOver ();(my $reconnectSocket=getMainServerSocket ());if (defined (
$reconnectSocket)){setMainServerSocket (undef);
Common::NXSelector::removeFromGlobalSelector ($reconnectSocket);main::nxclose (
$reconnectSocket);}}sub setReconnectSessionId{($__reconnectSessionId=shift (@_))
;Logger::debug (((
"\x53\x65\x74\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$__reconnectSessionId)."\x2e"));}sub setIsReconnectWaitingForDisconnectAnswer{(
$__isReconnectWaitingForDisconnectAnswer=(0x0bff+ 4990-0x1f7c));}sub 
__unsetIsReconnectWaitingForDisconnectAnswer{(
$__isReconnectWaitingForDisconnectAnswer=(0x0435+ 1636-0x0a99));}sub 
__isReconnectWaitingForDisconnectAnswer{return (
$__isReconnectWaitingForDisconnectAnswer);}sub 
__informWaitingSessionsWeAreReadyForReconnect{while ((scalar (
@__waitingForReconnectToFinish)>(0x1a9f+ 2451-0x2432))){(my $socket=shift (
@__waitingForReconnectToFinish));main::send_reply_to_socket ($socket,(
getMessageAnotherReconnectFinished ()."\x0a"));
NXNodeExec::removeHandleFromMonitor ($socket);}}sub 
isSocketWaitingForReconnectFinish{(my $socket=shift (@_));foreach my $waitingSocket
 (@__waitingForReconnectToFinish){if (($socket==$waitingSocket)){return (
(0x0d14+ 3916-0x1c5f));}}return ((0x05d8+ 1507-0x0bbb));}sub 
isNotSocketWaitingForReconnectFinish{return ((!isSocketWaitingForReconnectFinish
 (@_)));}sub __getLineAndBufferLeft{(my $readBuffer=shift (@_));(my $line=
$readBuffer);if (($readBuffer=~ /^(.*?)\n(.*)$/s )){($line=$1);($readBuffer=$2);
}else{($readBuffer=(""));}return ($readBuffer,$line);}sub 
__handleMainServerMessage{(my $readBuffer=shift (@_));(my $handleHash=shift (@_)
);(my $self=shift (@_));if (($readBuffer eq getMessageConfirmDisconnect ())){
stopWaitingOnMainServerAnswer ();setDisconnectSessionConfirmed ();
SessionStartStateMachine::setNextState (
"\x73\x65\x73\x73\x69\x6f\x6e\x43\x6c\x6f\x73\x65\x64");$self->setExit (
$handleHash,(0x0003+ 160-0x00a3),(0x098b+ 4062-0x1969));}elsif (($readBuffer eq 
getMessageAnotherReconnectFinished ())){setDisconnectSessionTryAgain ();(my $mainServerSocket
=getMainServerSocket ());if (defined ($mainServerSocket)){
NXShell::unregisterDescriptor (
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x4d\x61\x69\x6e\x53\x65\x72\x76\x65\x72"
);NXShell::unregisterDescriptor (
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x4d\x61\x69\x6e\x53\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x43\x6c\x6f\x73\x65"
);$self->removeAndCloseHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->
setExit ($handleHash,(0x038b+ 2474-0x0d35),(0x0693+ 1146-0x0b0d));
setMainServerSocket (undef);}Logger::debug (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x74\x72\x79\x20\x74\x6f\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x61\x67\x61\x69\x6e\x2e"
);SessionStartStateMachine::setNextState (
"\x74\x72\x79\x54\x6f\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x41\x67\x61\x69\x6e"
);}elsif (($readBuffer eq getMessageAnotherReconnectInProgress ())){$self->
setTimeout ($GLOBAL::timeoutForAnotherReconnectDisconnect);$self->
setCallbackTimeout ((\&__callbackMainServerSocketTimeout));
stopWaitingOnMainServerAnswer ();Logger::debug (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x69\x73\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73\x2e"
);SessionStartStateMachine::setNextState (
"\x61\x6e\x6f\x74\x68\x65\x72\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x49\x6e\x50\x72\x6f\x67\x72\x65\x73\x73"
);}}sub handleCannotDisconnectAnotherReconnect{setDisconnectSessionNotConfirmed 
();Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x62\x65\x66\x6f\x72\x65\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);NXMsg::error (
"\x65\x47\x55\x49\x4e\x6f\x74\x53\x75\x73\x70\x65\x6e\x64\x61\x62\x6c\x65",
"\x6d\x61\x69\x6e",$mainServerSessionId);NXShell::setExitRequest (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);SessionStartStateMachine::setNextState ("\x65\x72\x72\x6f\x72");}sub 
setAgentReconnecting{($__agentReconnecting=(0x1472+ 1457-0x1a22));}sub 
__unsetAgentReconnecting{($__agentReconnecting=(0x0de8+ 5046-0x219e));}sub 
__isAgentReconnecting{return ($__agentReconnecting);}return (
(0x0b53+ 5480-0x20ba));
