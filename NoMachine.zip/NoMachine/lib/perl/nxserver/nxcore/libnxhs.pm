############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package libnxhs;no warnings;($VERSION="\x38");require Exporter;require 
DynaLoader;(@ISA=("\x45\x78\x70\x6f\x72\x74\x65\x72",
"\x44\x79\x6e\x61\x4c\x6f\x61\x64\x65\x72"));(@EXPORT=());sub AUTOLOAD{();}
"\x6c\x69\x62\x6e\x78\x68\x73"->bootstrap;"\x3f\x3f\x3f";
