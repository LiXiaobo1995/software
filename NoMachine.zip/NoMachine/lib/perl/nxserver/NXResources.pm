############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXResources::BEGIN{package NXResources;no warnings;require NXProfilesManager
;do{"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72"->
import};}package NXResources;no warnings;$username;($restoreType=(""));(my $__lengthClass
=(0x0e24+ 6242-0x2681));sub BEGIN{require Common::NXSessionType;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"
->import};}sub BEGIN{require NXServices;do{
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73"->import};}sub BEGIN{require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}(my $__lengthType=(0x06f0+ 1465-0x0ca5));(my $__lengthValue
=(0x1147+ 391-0x12c9));($GLOBAL::NXMANAGER_FORMAT_OUTPUT=(0x03b7+ 4312-0x148f));
sub __getResources{(my $profile=shift (@_));(my $class=shift (@_));(my $node=
shift (@_));(my (%resources)=());my ($resourcesList);my ($nodeGroupsList);if ((
$class eq "\x73\x65\x73\x73\x69\x6f\x6e")){($resourcesList=shift (@_));}elsif ((
$class eq "\x73\x65\x72\x76\x69\x63\x65")){($resourcesList=
NXServices::getAllPosibleServicesList ());}elsif (($class eq 
"\x66\x65\x61\x74\x75\x72\x65")){($resourcesList=
$GLOBAL::ALL_POSSIBLE_FEATURES_LIST);if (Server::isConnectedToConsole ()){(
$resourcesList=~ s/,enable-multiserver// );}if (
NXProfiles::isInternalKeyForSystem ($profile)){($resourcesList.=("\x2c".
$GLOBAL::SYSTEM_POSSIBLE_FEATURES_LIST));}Logger::debug (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x46\x65\x61\x74\x75\x72\x65\x20\x6c\x69\x73\x74\x20\x27"
.$resourcesList)."\x27\x2e"));}elsif (($class eq "\x6e\x6f\x64\x65")){if (
NXLicense::isMultiNodeFeature ()){($resourcesList=NXNodes::getAllNodesList ());(
$resourcesList=~ s/:/\//g );main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73","\x69\x6e\x69\x74");(
$nodeGroupsList=NXNodeGroups::getGroupsListStringByNode ());if ($nodeGroupsList)
{if ($resourcesList){($resourcesList.="\x2c");}($resourcesList.=$nodeGroupsList)
;}}else{(my $node=NXNodes::getLocalNodeFromDatabase ());if (defined ($node)){(
$resourcesList=$node);}}}else{return ((0x125b+ 907-0x15e5),%resources);}(
$resourcesList and (my (@arr_resources)=split ( /,/ ,$resourcesList,
(0x0896+ 2776-0x136e))));my ($nodeList);if ((not (defined ($node)))){if (
NXLicense::isMultiNodeFeature ()){($nodeList=NXNodes::getNodesList ());}else{(my $node
=NXNodes::getLocalNodeFromDatabase ());if (defined ($node)){($nodeList=$node);}}
}else{($nodeList=$node);if (NXLicense::isMultiNodeFeature ()){main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73","\x69\x6e\x69\x74");(
$nodeGroupsList=NXNodeGroups::getGroupsListStringByNode ($node));}}Logger::debug
 (((((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x43\x68\x65\x63\x6b\x20\x63\x6c\x61\x73\x73\x20\x27"
.$class).
"\x27\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x73\x20\x27"
).$nodeList)."\x27\x2e"));foreach my $res (@arr_resources){($resources{$res}=
(0x0834+ 5905-0x1f45));}(my (@nodes)=split ( /,/ ,$nodeList,
(0x062c+ 1589-0x0c61)));(my (@nodeGroups)=split ( /,/ ,$nodeGroupsList,
(0x05b9+  71-0x0600)));if ((($class eq "\x66\x65\x61\x74\x75\x72\x65")and (
scalar (@nodes)==(0x0786+ 2680-0x11fe)))){foreach my $res (@arr_resources){if (
NXProfilesManager::isFeatureAvailableForUserGroupAndSystem ($res,$profile)){(
$resources{$res}=(0x0bdc+ 6235-0x2436));}}}if (($class eq "\x6e\x6f\x64\x65")){
foreach my $node (@nodes){if (
NXProfilesManager::isTypeAvaibleOnClassForUserOrNode ($node,$class,$profile)){(
$resources{$node}=(0x1ae7+ 1315-0x2009));}}foreach my $nodeGroup (@nodeGroups){
if (NXProfilesManager::isTypeAvaibleOnClassForUserOrNode ($nodeGroup,$class,
$profile)){($resources{$nodeGroup}=(0x1077+ 3415-0x1dcd));}}}else{foreach my $node
 (@nodes){foreach my $res (@arr_resources){if (
NXProfilesManager::isTypeAvaibleOnClassForUserOrNode ($res,$class,$profile,$node
)){($resources{$res}=(0x1be5+ 2415-0x2553));}}}}my ($error_code);return (
$error_code,%resources);}sub __formatResourceOutput{(my $class=shift (@_));(my $filtered_value
=shift (@_));(my (%resources)=@_);my (@out_resources);my ($printItem);foreach my $key
 (keys (%resources)){(my $value=$resources{$key});($printItem=
(0x1421+ 4512-0x25c1));if (($value==(0x0a65+ 5136-0x1e74))){($value=
"\x79\x65\x73");if ((($filtered_value eq "\x79\x65\x73")or ($filtered_value eq 
("")))){($printItem=(0x0582+ 2949-0x1106));}}elsif (($value==
(0x1418+ 645-0x169d))){($value="\x6e\x6f");if ((($filtered_value eq "\x6e\x6f")
or ($filtered_value eq ("")))){($printItem=(0x080d+ 5236-0x1c80));}}if ((
$printItem==(0x0dac+ 5331-0x227e))){if (($class eq 
"\x73\x65\x73\x73\x69\x6f\x6e")){($key=Common::NXSessionType::convertToExternal 
($key));}push (@out_resources,{"\x63\x6c\x61\x73\x73",$class,"\x74\x79\x70\x65",
$key,"\x76\x61\x6c\x75\x65",$value});}}return (@out_resources);}sub 
__formatRuleValueOutput{(my $class=shift (@_));(my $filtered_value=shift (@_));(my $rule_value
=shift (@_));(my (@out_resources)=());(my (%rule_value_resources)=());(my $value_list_res
=(""));(my (@arr_rule_value)=());if (($class eq "\x73\x65\x73\x73\x69\x6f\x6e"))
{($value_list_res=$GLOBAL::ALL_POSSIBLE_SESSIONS_VALUE_LIST);}elsif (($class eq 
"\x66\x65\x61\x74\x75\x72\x65")){($value_list_res=
$GLOBAL::ALL_POSSIBLE_FEATURES_VALUE_LIST);}elsif (($class eq "\x6e\x6f\x64\x65"
)){($value_list_res=$GLOBAL::ALL_POSSIBLE_NODE_VALUE_LIST);}(@arr_rule_value=())
;($value_list_res and (@arr_rule_value=split ( /,/ ,$value_list_res,
(0x1199+ 3888-0x20c9))));foreach my $rv (@arr_rule_value){($rule_value_resources
{$rv}=(""));}if (($filtered_value eq (""))){(@arr_rule_value=());($rule_value 
and (@arr_rule_value=split ( /,/ ,$rule_value,(0x0916+ 1390-0x0e84))));foreach my $rv
 (@arr_rule_value){(my (@item_rule)=split ( /=/ ,$rv,(0x069c+ 126-0x071a)));(
$rule_value_resources{$item_rule[(0x2087+ 1655-0x26fe)]}=$item_rule[
(0x1e77+ 602-0x20d0)]);}foreach my $key (keys (%rule_value_resources)){if ((
$rule_value_resources{$key}eq (""))){($rule_value_resources{$key}="\x6e\x6f");}
push (@out_resources,{"\x63\x6c\x61\x73\x73",$class,"\x74\x79\x70\x65",$key,
"\x76\x61\x6c\x75\x65",$rule_value_resources{$key}});}}return (@out_resources);}
sub __getSessionResources{(my $user=shift (@_));(my $nodeUuid=shift (@_));(my $filtered_value
=shift (@_));Logger::debug (((((((
"\x47\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x2e\x20\x55\x73\x65\x72\x3a\x20"
.$user)."\x2c\x20\x6e\x6f\x64\x65\x3a\x20").$nodeUuid).
"\x2c\x20\x66\x69\x6c\x74\x65\x72\x65\x64\x20\x76\x61\x6c\x75\x65\x3a\x20").
$filtered_value)."\x2e"));__setUsername ($user);(my $availableSessionTypes=
NXNodes::getAvailableSessionTypes ($nodeUuid));if ((NXNodes::isStatusStopped (
$nodeUuid)and ($restoreType ne ("")))){Logger::debug (
"\x41\x64\x64\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x74\x79\x70\x65\x20\x74\x6f\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x73\x2e"
);($availableSessionTypes=$restoreType);}(my ($error_code,%resources)=
__getResources ($user,"\x73\x65\x73\x73\x69\x6f\x6e",$nodeUuid,
$availableSessionTypes));(my (@allSessionTypes)=split ( /,/ ,
Common::NXSessionType::getAllTypes (),(0x0c01+ 3871-0x1b20)));
__getSystemSessionTypesForLocalNode ($nodeUuid,(\@allSessionTypes));my (
%sessionClassResources);foreach my $type (@allSessionTypes){if (($resources{
$type}==(0x1761+ 2642-0x21b2))){if (Server::isAccessOnlyToLocalPhysical ()){if (
Common::NXSessionType::isPhysical ($type)){($sessionClassResources{$type}=
(0x1682+ 829-0x19be));}else{Logger::debug2 (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$type).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));}}elsif (Server::isAccessOnlyToAttach ()){if ((
Common::NXSessionType::isPhysical ($type)or 
Common::NXSessionType::isVirtualAttach ($type))){($sessionClassResources{$type}=
(0x00a0+ 7880-0x1f67));}else{Logger::debug2 (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$type).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));}}else{Logger::debug (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x69\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));(
$sessionClassResources{$type}=(0x04a3+ 2194-0x0d34));}}else{Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x3a\x20".$type).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));(
$sessionClassResources{$type}=(0x22f8+ 134-0x237e));}}foreach my $type (keys (
%resources)){if (($resources{$type}=~ /xsession-/ )){Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x3a\x20".$type).
"\x20\x69\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));(
$sessionClassResources{$type}=(0x0974+ 1691-0x100e));}}main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79");if (
(NXConnectionPolicy::isDesktopEnabled ()and Server::notShowAllResourceAvailable 
())){($sessionClassResources{Common::NXSessionType::getVirtualDefault ()}=
(0x0134+ 3564-0x0f20));}my (@res);push (@res,__formatResourceOutput (
"\x73\x65\x73\x73\x69\x6f\x6e",$filtered_value,%sessionClassResources));(my $rule_value
=NXProfilesManager::getClassValues ("\x73\x65\x73\x73\x69\x6f\x6e",$user,
$nodeUuid));push (@res,__formatRuleValueOutput ("\x73\x65\x73\x73\x69\x6f\x6e",
$filtered_value,$rule_value));return (@res);}sub 
__getSystemSessionTypesForLocalNode{(my $nodeUuid=shift (@_));(my $ref_Session=
shift (@_));main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79");
unless (NXConnectionPolicy::isSystemDesktopsEnabled ()){return;}if ((($nodeHost 
eq (""))or NXNodes::isLocalNode ($nodeUuid))){(my $sessions=
Common::NXSessionType::getXsessionTypes ());foreach my $name (split ( /,/ ,
$sessions,(0x0ed5+ 2114-0x1717))){push (@$ref_Session,$name);}}}sub 
__getServiceResources{(my $user=shift (@_));(my $node=shift (@_));(my $filtered_value
=shift (@_));Logger::debug (((((((
"\x5f\x5f\x67\x65\x74\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x75\x73\x65\x72\x20\x27"
.$user)."\x27\x2c\x20\x6e\x6f\x64\x65\x20\x27").$node).
"\x27\x2c\x20\x76\x61\x6c\x75\x65\x20\x27").$filtered_value)."\x27\x2e"));(my (
$error_code,%resources)=__getResources ($user,"\x73\x65\x72\x76\x69\x63\x65",
$node));(my $rule_value=NXProfilesManager::getClassValues (
"\x73\x65\x72\x76\x69\x63\x65",$user,$node));(my $services_to_check=(""));
foreach my $service (keys (%resources)){if (($resources{$service}==
(0x0716+ 5854-0x1df3))){Logger::debug2 ((("\x73\x65\x72\x76\x69\x63\x65\x20\x5b"
.$service).
"\x5d\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x73"))
;($services_to_check.=($service."\x2c"));($resources{$service}=
(0x0735+ 3170-0x1397));}}(my (@nodes_array)=());if ((defined ($node)and length (
$node))){(@nodes_array=split ( /,/ ,$node,(0x131a+ 2090-0x1b44)));}else{(
@nodes_array=NXNodes::getNodesArray ());}foreach my $nodeUuid (@nodes_array){
Logger::debug (((
"\x5f\x5f\x67\x65\x74\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x67\x65\x74\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
.$nodeUuid)."\x27\x2e"));(my $deny_services=NXNodes::getNodeDenyServices (
$nodeUuid));Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x73\x20\x64\x65\x6e\x69\x65\x64\x20\x69\x6e\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x61\x6e\x64\x20\x64\x65\x6e\x79\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x3a\x20\x5b"
.$deny_services)."\x5d"));(my (@services_to_check_array)=split ( /,/ ,
$services_to_check,(0x068f+ 3959-0x1606)));foreach my $service (
@services_to_check_array){if ((not (($deny_services=~ /$service/ )))){
Logger::debug2 ((("\x53\x65\x72\x76\x69\x63\x65\x20\x5b".$service).
"\x5d\x20\x66\x6f\x75\x6e\x64\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x2e"));($resources
{$service}=(0x2080+ 243-0x2172));($services_to_check=~ s/$service,// );}}}delete
 ($resources{("")});my (@res);push (@res,__formatResourceOutput (
"\x73\x65\x72\x76\x69\x63\x65",$filtered_value,%resources));push (@res,
__formatRuleValueOutput ("\x73\x65\x72\x76\x69\x63\x65",$filtered_value,
$rule_value));return (@res);}sub __getFeatureResources{(my $user=shift (@_));(my $node
=shift (@_));(my $filtered_value=shift (@_));(my ($error_code,%resources)=
__getResources ($user,"\x66\x65\x61\x74\x75\x72\x65",$node));(my $rule_value=
NXProfilesManager::getClassValues ("\x66\x65\x61\x74\x75\x72\x65",$user,$node));my (
@res);push (@res,__formatResourceOutput ("\x66\x65\x61\x74\x75\x72\x65",
$filtered_value,%resources));push (@res,__formatRuleValueOutput (
"\x66\x65\x61\x74\x75\x72\x65",$filtered_value,$rule_value));return (@res);}sub 
__getNodeResources{(my $user=shift (@_));(my $node=shift (@_));(my $filtered_value
=shift (@_));my (@res);(my ($error_code,%resources)=__getResources ($user,
"\x6e\x6f\x64\x65"));(my $rule_value=NXProfilesManager::getClassValues (
"\x6e\x6f\x64\x65",$user,$node));($rule_value=~ s/\//:/g );foreach my $key (keys
 (%resources)){(my $value=$resources{$key});delete ($resources{$key});($key=~ s/\//:/g )
;($resources{$key}=$value);}push (@res,__formatResourceOutput (
"\x6e\x6f\x64\x65",$filtered_value,%resources));push (@res,
__formatRuleValueOutput ("\x6e\x6f\x64\x65",$filtered_value,$rule_value));return
 (@res);}sub printResources{(my (@param)=@_);my (%parameters);if ((scalar (
@param)eq (0x1996+ 1626-0x1fef))){((%parameters)=NXShell::urlParameter2Hash (
NXShell::getLastParameters (@param)));Logger::debug (((
"\x52\x65\x73\x6f\x75\x72\x63\x65\x20\x6c\x69\x73\x74\x3a\x20\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x70\x61\x72\x61\x6d\x20\x5b"
.join ($",@param))."\x5d\x2e"),(0x0b3f+ 6556-0x24db));(
$GLOBAL::NXMANAGER_FORMAT_OUTPUT=(0x11bd+ 5045-0x2571));if (((not (defined (
$parameters{"\x75\x73\x65\x72"})))or ($parameters{"\x75\x73\x65\x72"}eq ("")))){
if (defined ($parameters{"\x67\x75\x65\x73\x74"})){($parameters{
"\x75\x73\x65\x72"}=NXProfiles::getInternalGuestKey ());}elsif (defined (
$parameters{"\x73\x79\x73\x74\x65\x6d"})){($parameters{"\x75\x73\x65\x72"}=
NXProfiles::getInternalSystemKey ());}else{($parameters{"\x75\x73\x65\x72"}=
NXLogin::get ()->getLogin);}}if ((not (NXLogin::isAdministrator ()))){if (((
$parameters{"\x75\x73\x65\x72"}ne NXLogin::get ()->getLogin)and ($parameters{
"\x6e\x6f\x64\x65"}eq ("")))){NXMsg::error (
"\x65\x44\x69\x66\x66\x65\x72\x65\x6e\x74\x55\x73\x65\x72\x52\x65\x73\x6f\x75\x72\x63\x65"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");return ((0x0a3a+ 1708-0x10e5));
}}}else{Logger::debug (
"\x52\x65\x73\x6f\x75\x72\x63\x65\x20\x6c\x69\x73\x74\x3a\x20\x6d\x6f\x72\x65\x20\x74\x68\x65\x6e\x20\x6f\x6e\x65\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x2e"
,(0x1936+ 2329-0x224f));((%parameters)=@param);if (((not (defined ($parameters{
"\x75\x73\x65\x72"})))or ($parameters{"\x75\x73\x65\x72"}eq ("")))){($parameters
{"\x75\x73\x65\x72"}=NXProfiles::getInternalSystemKey ());}}if (
NXProfiles::isInternalKeyForGuest ($parameters{"\x75\x73\x65\x72"})){if ((((
$GLOBAL::EnableGuestCreateVirtualDesktop eq "\x30")or 
NXLicense::isNotGuestFeature ())or ($GLOBAL::EnableUserProfile eq "\x30"))){if (
NXLicense::isNotGuestFeature ()){NXMsg::error (
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");}else{NXMsg::error (
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");}return ((0x0804+ 1002-0x0bee))
;}}if (($parameters{"\x6e\x6f\x64\x65"}ne (""))){($parameters{"\x6e\x6f\x64\x65"
}=~ s/\.$//s );Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x69\x6e\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20"
.$parameters{"\x6e\x6f\x64\x65"})."\x2e"));(my ($nodeUUID,$host,$port)=
NXNodes::getHostAndPort ($parameters{"\x6e\x6f\x64\x65"}));if ((not (
NXProfilesManager::isNodeAvailableForLoggedUser ($nodeUUID,$parameters{
"\x75\x73\x65\x72"})))){Logger::warning (((
"\x4c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x20\x64\x6f\x6e\x27\x74\x20\x68\x61\x76\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20\x70\x72\x69\x6e\x74\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x20\x66\x72\x6f\x6d\x20\x6e\x6f\x64\x65\x20\x27"
.$nodeUUID)."\x27\x2e"));NXMsg::error (
"\x65\x4e\x6f\x64\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",$parameters{"\x6e\x6f\x64\x65"})
;return ((0x030b+ 7279-0x1f7a));}}Logger::debug (((((((((
"\x52\x65\x73\x6f\x75\x72\x63\x65\x20\x6c\x69\x73\x74\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x5b"
.$parameters{"\x75\x73\x65\x72"})."\x5d\x2c\x20\x63\x6c\x61\x73\x73\x5b").
$parameters{"\x63\x6c\x61\x73\x73"})."\x5d\x2c\x20\x76\x61\x6c\x75\x65\x5b").
$parameters{"\x76\x61\x6c\x75\x65"})."\x5d\x20\x6e\x6f\x64\x65\x5b").$parameters
{"\x6e\x6f\x64\x65"})."\x5d"),(0x076f+ 5282-0x1c11));(my (@resources)=
__calculateResources ((\%parameters)));if ((Common::NXMsg::send_response (
"\x69\x52\x65\x73\x6f\x75\x72\x63\x65\x4c\x69\x73\x74")==(-(0x10d5+ 4479-0x2253)
))){return ((-(0x0a26+ 5934-0x2153)));}if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x1b39+ 2801-0x2629)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x17bd+ 3790-0x268a)));}__setLength (
@resources);if ((main::nxwrite (main::nxgetSTDOUT (),sprintf (((((((((((((
"\x25\x2d".$__lengthClass)."\x2e").$__lengthClass)."\x73\x20\x25\x2d").
$__lengthType)."\x2e").$__lengthType)."\x73\x20\x25\x2d").$__lengthValue)."\x2e"
).$__lengthValue)."\x73\x0a"),"\x43\x6c\x61\x73\x73","\x54\x79\x70\x65",
"\x56\x61\x6c\x75\x65"))==(-(0x1846+ 356-0x19a9)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x12bd+ 2204-0x1b58)));}if ((
main::nxwrite (main::nxgetSTDOUT (),sprintf ((((((((((((("\x25\x2d".
$__lengthClass)."\x2e").$__lengthClass)."\x73\x20\x25\x2d").$__lengthType).
"\x2e").$__lengthType)."\x73\x20\x25\x2d").$__lengthValue)."\x2e").
$__lengthValue)."\x73\x0a"),("\x2d" x $__lengthClass),("\x2d" x $__lengthType),(
"\x2d" x $__lengthValue)))==(-(0x20b7+ 670-0x2354)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x039f+ 3381-0x10d3)));}foreach my $res 
(@resources){if ((main::nxwrite (main::nxgetSTDOUT (),sprintf (((((((((((((
"\x25\x2d".$__lengthClass)."\x2e").$__lengthClass)."\x73\x20\x25\x2d").
$__lengthType)."\x2e").$__lengthType)."\x73\x20\x25\x2d").$__lengthValue)."\x2e"
).$__lengthValue)."\x73\x0a"),$$res{"\x63\x6c\x61\x73\x73"},$$res{
"\x74\x79\x70\x65"},$$res{"\x76\x61\x6c\x75\x65"}))==(-(0x06cc+ 8252-0x2707)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x002c+ 6201-0x1864)));}}return ((0x07eb+ 2924-0x1357));}sub 
__calculateResources{(my $ref_parameters=shift (@_));(my (@resources)=());if ((
$$ref_parameters{"\x6e\x6f\x64\x65"}=~ /^(.*):(\d+)$/ )){($host=$1);($port=$2);(
$$ref_parameters{"\x6e\x6f\x64\x65"}=NXNodes::getUuid ($host,$port));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x73\x65\x73\x73\x69\x6f\x6e")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getSessionResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x73\x65\x72\x76\x69\x63\x65")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getServiceResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x66\x65\x61\x74\x75\x72\x65")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getFeatureResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x6e\x6f\x64\x65")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getNodeResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if ((
NXLogin::isDesktopGuestLogin ()eq (0x1bb2+ 403-0x1d44))){(my (
@notAllowedResources)=split ( /,/ ,$GLOBAL::SERVICES_NOT_ALLOWED_FOR_GDS,
(0x175a+ 2160-0x1fca)));(my $iter=(0x0bac+ 1909-0x1321));foreach my $res (
@resources){foreach my $service (@notAllowedResources){if (($$res{
"\x74\x79\x70\x65"}eq $service)){($resources[$iter]{"\x76\x61\x6c\x75\x65"}=
"\x6e\x6f");}}(++$iter);}}NXProfiles::saveCalculatedResources (@resources);
return (@resources);}sub calculateResourcesBeforeResourcelist{(my $user=shift (
@_));(my $node=shift (@_));my (%parameters);($parameters{"\x75\x73\x65\x72"}=
$user);($parameters{"\x6e\x6f\x64\x65"}=$node);__calculateResources ((
\%parameters));}sub __setLength{(my (@resources)=@_);foreach my $line (
@resources){if ((length ($$line{"\x63\x6c\x61\x73\x73"})>$__lengthClass)){(
$__lengthClass=length ($$line{"\x63\x6c\x61\x73\x73"}));}if ((length ($$line{
"\x74\x79\x70\x65"})>$__lengthType)){($__lengthType=length ($$line{
"\x74\x79\x70\x65"}));}if ((length ($$line{"\x76\x61\x6c\x75\x65"})>
$__lengthValue)){($__lengthValue=length ($$line{"\x76\x61\x6c\x75\x65"}));}}}sub
 getUsername{return ($username);}sub __setUsername{(my $user=shift (@_));(
$username=$user);}sub setRestoreType{(my $type=shift (@_));($restoreType=$type);
}NXMsg::register_error ("\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x44\x69\x66\x66\x65\x72\x65\x6e\x74\x55\x73\x65\x72\x52\x65\x73\x6f\x75\x72\x63\x65"
,(0x091a+ 2297-0x0fe7));NXMsg::register_error (
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,(0x069d+ 2009-0x0c4d));NXMsg::register_error (
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x4e\x6f\x64\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,553);NXMsg::register_error ("\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x44\x69\x73\x61\x62\x6c\x65\x64"
,(0x1016+ 4281-0x1ea6));return ((0x0248+ 8993-0x2568));
