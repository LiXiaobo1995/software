############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTools::BEGIN{package NXTools;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub NXTools::__getTimeMs{
package NXTools;no warnings;(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my (@time)=
Common::NXTime::getLocalTimeFromTimestamp ($sec));(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=(substr ($milisec,(0x0547+ 5777-0x1bd8)
,(0x094c+ 254-0x0a47)).substr ($milisec,(0x1dd3+ 1411-0x2353))));return (
$milisec,@time);}sub NXTools::getTimeMs{package NXTools;no warnings;(my (
$milisec,@time)=__getTimeMs ());(my $TimeMs=((((sprintf ("\x25\x30\x32\x64",
$time[(0x1e19+ 1738-0x24e1)]).sprintf ("\x25\x30\x32\x64",$time[
(0x07cc+ 269-0x08d8)])).sprintf ("\x25\x30\x32\x64",$time[(0x11b6+ 2606-0x1be4)]
))."\x2e").sprintf ($milisec)));return ($TimeMs);}sub NXTools::getTimestamp{
package NXTools;no warnings;(my ($milisec,@time)=__getTimeMs ());($milisec=((
substr ($milisec,(0x051b+ 6073-0x1cd4),(0x052b+ 2799-0x1017))."\x2e").substr (
$milisec,(0x1211+ 951-0x15c5))));(my $Timestamp=(sprintf (
"\x25\x30\x34\x64\x2d\x25\x30\x32\x64\x2d\x25\x30\x32\x64\x20\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x20"
,((0x1a13+ 1103-0x16f6)+$time[(0x0d29+ 2405-0x1689)]),((0x0b93+ 6710-0x25c8)+
$time[(0x0050+ 1045-0x0461)]),$time[(0x1221+ 4248-0x22b6)],$time[
(0x099c+ 3179-0x1605)],$time[(0x0372+ 5546-0x191b)],$time[(0x0ffd+ 4670-0x223b)]
).$milisec));return ($Timestamp);}sub NXTools::getTimestampOnlyMicroseconds{
package NXTools;no warnings;(my ($milisec,@time)=__getTimeMs ());($milisec=((
substr ($milisec,(0x02cc+ 4296-0x1394),(0x0893+ 7373-0x255d))."\x2e").substr (
$milisec,(0x00a2+ 431-0x024e))));(my $Timestamp=sprintf ($milisec));return (
$Timestamp);}sub NXTools::getSharedLibraryExtension{package NXTools;no warnings;my (
$extension);($extension="\x2e\x64\x6c\x6c");return ($extension);}sub 
NXTools::cleanLdLibraryPath{package NXTools;no warnings;(my $libnx=(
"\x6c\x69\x62\x6e\x78".getSharedLibraryExtension ()));(my $ldLibraryPath=
libnxh::NXTransGetEnvironment (
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48"));(my (@elements)
=split ( /:/ ,$ldLibraryPath,(0x009b+ 1241-0x0574)));my (@newLdLibraryPathArray)
;foreach my $element (@elements){(my $testLibry=(($element.
$GLOBAL::DIRECTORY_SLASH).$libnx));if ((Common::NXFile::isExists ($testLibry)or 
(not (-d ($element))))){next;}push (@newLdLibraryPathArray,$element);}(
$ldLibraryPath=join ("\x3a",@newLdLibraryPathArray));
libnxh::NXTransSetEnvironment (
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48",$ldLibraryPath);}
sub NXTools::getWindowsSystemPath{package NXTools;no warnings;(my $systemPath=
(""));(my $envSystemDirectory=libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x44\x69\x72\x65\x63\x74\x6f\x72\x79"));(my $envWinDir=
libnxh::NXTransGetEnvironment ("\x57\x69\x6e\x44\x69\x72"));(my $envSystemRoot=
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"));(my $envSystemDrive
=libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"))
;(my $envHOMEDRIVE=libnxh::NXTransGetEnvironment (
"\x48\x4f\x4d\x45\x44\x52\x49\x56\x45"));if (((undef ne $envSystemDirectory)and 
(length ($envSystemDirectory)>(0x11df+ 5345-0x26c0)))){($systemPath=
$envSystemDirectory);}elsif (((undef ne $envWinDir)and (length ($envWinDir)>
(0x03cb+ 1870-0x0b19)))){($systemPath=(($envWinDir.$GLOBAL::DIRECTORY_SLASH).
"\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif (((undef ne $envSystemRoot)and (
length ($envSystemRoot)>(0x1447+ 3125-0x207c)))){($systemPath=(($envSystemRoot.
$GLOBAL::DIRECTORY_SLASH)."\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif (((undef 
ne $envSystemDrive)and (length ($envSystemDrive)>(0x209f+ 1636-0x2703)))){(
$systemPath=(((($envSystemDrive.$GLOBAL::DIRECTORY_SLASH).
"\x57\x69\x6e\x64\x6f\x77\x73").$GLOBAL::DIRECTORY_SLASH).
"\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif (((undef ne $envHOMEDRIVE)and (
length ($envHOMEDRIVE)>(0x0501+ 1663-0x0b80)))){($systemPath=(((($envHOMEDRIVE.
$GLOBAL::DIRECTORY_SLASH)."\x57\x69\x6e\x64\x6f\x77\x73").
$GLOBAL::DIRECTORY_SLASH)."\x53\x79\x73\x74\x65\x6d\x33\x32"));}else{
Logger::warning (
"\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x79\x73\x74\x65\x6d\x50\x61\x74\x68\x28\x29\x3a\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x65\x74\x20\x70\x61\x74\x68"
);return ((""));}Logger::debug (((
"\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x79\x73\x74\x65\x6d\x50\x61\x74\x68\x28\x29\x3a\x20\x73\x65\x74\x20\x70\x61\x74\x68\x20\x74\x6f\x20\x5b"
.$systemPath)."\x5d"));return ($systemPath);}sub NXTools::getCommandUserAppPid{
package NXTools;no warnings;(my $user=shift (@_));(my (@command)=());return (
@command);(@command=($GLOBAL::COMMAND_PS,"\x2d\x55",$user,"\x2d\x75",$user,
"\x68","\x2d\x6f","\x70\x69\x64\x2c\x61\x72\x67\x73"));return (@command);}sub 
NXTools::__getFromNxhtdCfg{package NXTools;no warnings;(my $ref_keys=shift (@_))
;unless (defined ($GLOBAL::configFileNXHtd)){($GLOBAL::configFileNXHtd=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x77\x65\x62\x2e\x63\x66\x67"));}(my $FH=main::nxopen
 ($GLOBAL::configFileNXHtd,$NXBits::O_RDONLY,(0x0596+ 4574-0x1774)));if ((not (
defined ($FH)))){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$GLOBAL::configFileNXHtd)."\x27\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorNumber)."\x27\x2c\x20\x27").
$errorstring)."\x27\x2e"));}return ((0x02c5+ 5125-0x16ca));}(my $line=(""));
while (main::nxreadLine ($FH,(\$line))){chomp ($line);($line=~ s/^ *// );($line
=~ s/ *$// );foreach my $key (keys (%$ref_keys)){if (((($key eq 
"\x4c\x69\x73\x74\x65\x6e")and ($line=~ /^Listen.+:(\d+)\s+https/i ))or ($line=~ /^Listen\s+(\d+)\s+https/i )
)){(my $nxhtdPort=$1);if (($nxhtdPort ne (""))){if (($nxhtdPort=~ /:/ )){(
$nxhtdPort=(split ( /:/ ,$nxhtdPort,(0x1044+ 4627-0x2257)))[
(0x0da5+ 5356-0x2290)]);}if ((($nxhtdPort>=(0x00d7+ 7603-0x1e89))and ($nxhtdPort
<=65535))){($$ref_keys{$key}=$nxhtdPort);}else{Logger::debug (((
"\x50\x6f\x72\x74\x3a\x20".$nxhtdPort).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x76\x61\x6c\x69\x64\x2e"));}}}elsif (($key eq 
"\x43\x75\x73\x74\x6f\x6d\x4c\x6f\x67")){if (($line=~ /^CustomLog ("|)([^ "]*)("|) common$/ )
){($$ref_keys{$key}=$2);}}elsif (($line=~ /^$key ("|)([^"]*)("|)$/ )){(
$$ref_keys{$key}=$2);}}}main::nxclose ($FH);return ((0x1975+ 2251-0x223f));}sub 
NXTools::getNxhtdErrorLogPath{package NXTools;no warnings;(my $cfgKey=
"\x45\x72\x72\x6f\x72\x4c\x6f\x67");(my $result=__getNxhtdLogFilePath ($cfgKey))
;if (($result eq (""))){return (NXPaths::getDefaultNxhtdErrorLog ());}return (
$result);}sub NXTools::getNxhtdAccessLogPath{package NXTools;no warnings;(my $cfgKey
="\x43\x75\x73\x74\x6f\x6d\x4c\x6f\x67");(my $result=__getNxhtdLogFilePath (
$cfgKey));if (($result eq (""))){return (NXPaths::getDefaultNxhtdErrorLog ());}
return ($result);}sub NXTools::__getNxhtdLogFilePath{package NXTools;no warnings
;(my $key=shift (@_));(my (%keys)=());($keys{$key}=(""));($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}=(""));(my $result=__getFromNxhtdCfg 
((\%keys)));if (($result==(0x1065+ 4255-0x2104))){return ((""));}if (($keys{$key
}=~ /^[A-Za-z]:/ )){return ($keys{$key});}else{if (($keys{$key}ne (""))){return 
((($keys{"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}.$GLOBAL::DIRECTORY_SLASH).
$keys{$key}));}else{return ((""));}}}sub NXTools::getNXHtdUser{package NXTools;
no warnings;(my (%keys)=());($keys{"\x55\x73\x65\x72"}="\x6e\x78\x68\x74\x64");(
$keys{"\x47\x72\x6f\x75\x70"}="\x6e\x78\x68\x74\x64");__getFromNxhtdCfg ((\%keys
));return ($keys{"\x55\x73\x65\x72"},$keys{"\x47\x72\x6f\x75\x70"});}sub 
NXTools::getNXHtdPort{package NXTools;no warnings;(my (%keys)=());($keys{
"\x4c\x69\x73\x74\x65\x6e"}="\x34\x34\x34\x33");__getFromNxhtdCfg ((\%keys));
return ($keys{"\x4c\x69\x73\x74\x65\x6e"});}sub NXTools::getNXExecCommand{
package NXTools;no warnings;return (((((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x65\x78\x65\x63").$GLOBAL::BinExt));}sub NXTools::getNXNodeCommand{
package NXTools;no warnings;(my $node_command=((($GLOBAL::PathBin.
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x6e\x6f\x64\x65").$GLOBAL::BinExt));return (
$node_command);}sub NXTools::getNXSshCommand{package NXTools;no warnings;unless 
(Common::NXFile::isExists ($GLOBAL::SSHClient)){($GLOBAL::SSHClient=(((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x73\x68").$GLOBAL::BinExt));}return (
$GLOBAL::SSHClient);}sub NXTools::findFreePortAndOpen{package NXTools;no 
warnings;(my $from=shift (@_));(my $silent=(shift (@_)||(0x1766+ 1483-0x1d31)));
(my $to=(shift (@_)||($from+$GLOBAL::ServerSlaveLimit)));Logger::debug (((((((
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x69\x6e\x64\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x66\x72\x6f\x6d\x20\x27"
.$from)."\x27\x20\x74\x6f\x20\x27").$to).
"\x27\x20\x73\x69\x6c\x65\x6e\x74\x20\x27").$silent)."\x27\x2e"));(my $i=$from);
(my $port=(0x15f1+ 3248-0x22a1));(my $handler=(0x1258+ 4954-0x25b2));while (((
$port==(0x0504+ 3637-0x1339))and ($i<$to))){($handler=main::nxListenOnSocket ($i
,$silent));if (($handler==(-(0x0b8a+ 5881-0x2282)))){(++$i);}elsif (($handler==(
-(0x1621+ 3463-0x23a6)))){Logger::debug (
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x73\x65\x61\x72\x63\x68\x69\x6e\x67\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x2e"
);last;}else{($port=$i);}}if (($handler<(0x019f+ 8828-0x241b))){Logger::debug (
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x66\x69\x6e\x64\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x72\x61\x6e\x67\x65\x2e"
);return (undef,$port);}Logger::debug (((
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x69\x73\x74\x65\x6e\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));return ($handler,$port);}sub NXTools::openNXServerPort{
package NXTools;no warnings;my ($port);my ($handler);if ((Server::getMySessionID
 ()ne (""))){if (NXSession2::existSession (Server::getMySessionID ())){((
$handler,$port)=findFreePortAndOpen ($GLOBAL::ServerSlaveBase,
"\x73\x69\x6c\x65\x6e\x74"));NXSession2::setPortBySessionId (
Server::getMySessionID (),$port);}Logger::debug (((((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x69\x73\x74\x65\x6e\x20\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x3a\x20"
.$port)."\x20\x2d\x20").Server::getMySessionID ()).("")));}else{Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x73\x6f\x63\x6b\x65\x74\x20\x66\x6f\x72\x20\x4e\x58\x53\x65\x72\x76\x65\x72\x20\x2d\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64"
);}return ($handler);}sub NXTools::getMainSessionID{package NXTools;no warnings;my (
$mainSessionId);if (defined (NXNodeExec::getMainSessionId ())){($mainSessionId=
NXNodeExec::getMainSessionId ());}else{(my (@sessions)=NXSession2::listSessions 
());foreach my $session (@sessions){($mainSessionId=
NXSession2::getMainSessionBySessionId ($session));if ((not (defined (
$mainSessionId)))){(my $localSessiontType=
NXSession2::getLocalSessionTypeBySessionId ($session));if (
NXLocalSession::isLocalSessionTypeDesktop ($localSessionType)){($mainSessionId=
$session);}elsif (NXLocalSession::isLocalSessionTypeLoginwindow (
$localSessionType)){($mainSessionId=$session);}}if (defined ($mainSessionId)){
last;}}NXNodeExec::setMainSessionId ($mainSessionId);}return ($mainSessionId);}
sub NXTools::getParentPid{package NXTools;no warnings;(my $parentPid=
(0x2011+  65-0x2052));($parentPid=Common::NXCore::getParentPidByPid ($ $));
 return
 ($parentPid);}sub NXTools::getNXSshdPidWindows{package NXTools;no warnings;(my $forwardServerParentPid
=(0x025a+ 1850-0x0994));(my $sshdPid=(0x1238+ 1538-0x183a));if (
NXAuth::isNomachine ()){($forwardServerParentPid=getParentPid ());($sshdPid=
Common::NXCore::getParentPidByPid ($forwardServerParentPid));if (
Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid,"\x63\x6d\x64"))
{($sshdPid=Common::NXCore::getParentPidByPid ($sshdPid));if (
Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid,
"\x73\x73\x68\x64")){return ($sshdPid);}}}if (NXAuth::isSystem ()){(
$forwardServerParentPid=getNXSshdPidOnWindowsOnSystemSshSession ());($sshdPid=
Common::NXCore::getParentPidByPid ($forwardServerParentPid));if (
Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72")){($sshdPid=Common::NXCore::getParentPidByPid
 ($sshdPid));if (Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid
,"\x63\x6d\x64")){($sshdPid=Common::NXCore::getParentPidByPid ($sshdPid));if (
Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid,
"\x73\x73\x68\x64")){return ($sshdPid);}}}}return ((0x019b+ 8376-0x2253));}sub 
NXTools::getSshdPidUnix{package NXTools;no warnings;(my $sshdPid=
(0x246d+ 149-0x2502));if (NXAuth::isSystem ()){($sshdPid=
Common::NXCore::getParentPidByPid (getParentPid ()));}if (NXAuth::isNomachine ()
){($sshdPid=getppid);}return ($sshdPid);}sub NXTools::getSshdPid{package NXTools
;no warnings;(my $sshdPid=(0x14ed+ 2837-0x2002));($sshdPid=getNXSshdPidWindows 
());if (Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid,
"\x73\x73\x68\x64")){return ($sshdPid);}Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x53\x53\x48\x44\x20\x50\x49\x44\x3a\x20\x50\x72\x6f\x63\x65\x73\x73\x20"
.$sshdPid).
"\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x68\x61\x76\x65\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x2e"
));}sub NXTools::getNXSshdPidOnWindowsOnSystemSshSession{package NXTools;no 
warnings;(my $parentPid=(0x0150+ 9296-0x25a0));($parentPid=$ARGV[
(0x00c0+ 1891-0x0821)]);return ($parentPid);}sub NXTools::getGIDByGroupOnApple{
package NXTools;no warnings;(my $group=shift (@_));(my $groupId=getgrnam ($group
));if (defined ($groupId)){return ($groupId);}(my ($name,$passwd,$gid,$members)=
getgrgid ($group));if (($name and ($gid eq $group))){return ($gid);}return (("")
);}sub NXTools::getArrayOfListWrappedByLineLength{package NXTools;no warnings;(my $list
=shift (@_));(my (@wrappedArray)=());while ((libnxh::NXStringLength ($list)>
(0x13d3+ 1298-0x18bd))){(my $line=libnxh::NXSubstring ($list,
(0x1a5a+ 2057-0x2263),(0x195b+ 2063-0x2142)));(my $commaPosition=
libnxh::NXStringRightIndex ($line,"\x2c"));(++$commaPosition);($line=
libnxh::NXSubstring ($line,(0x1e84+ 714-0x214e),$commaPosition));push (
@wrappedArray,$line);($list=libnxh::NXSubstring ($list,$commaPosition,
(0x1bbb+ 1044-0x1bcf)));($list=~ s/^ // );}push (@wrappedArray,$list);return (
@wrappedArray);}sub NXTools::setWidth{package NXTools;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));if (($$refTable{$name}<
libnxh::NXStringLength ($value))){($$refTable{$name}=libnxh::NXStringLength (
$value));}}sub NXTools::printWidth{package NXTools;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable{
$name}+(0x00aa+ 9444-0x258d)));(my $message=
Common::NXCore::leftJustifyOrTrimString ($value,$width));if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x121d+ 2454-0x1bb2)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x1129+ 2381-0x1a75)));}}sub NXTools::printMark{package NXTools;no warnings;(my $refTable
=shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable
{$name}+(0x1b21+ 2031-0x230f)));(my $message=
Common::NXCore::leftJustifyOrTrimString (("\x2d" x $$refTable{$name}),$width));
if ((main::nxwrite (main::nxgetSTDOUT (),$message)==(-(0x07e6+ 4766-0x1a83)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x103a+ 3577-0x1e32)));}}sub NXTools::printTable{package NXTools;no warnings;(my $ref_labels
=shift (@_));(my $ref_values=shift (@_));(my (%table)=());for ((my $i=
(0x067b+ 5484-0x1be7));($i<@$ref_labels);(++$i)){setWidth ((\%table),$i,
@$ref_labels[$i]);}foreach my $value (values (%$ref_values)){for ((my $i=
(0x0097+ 3796-0x0f6b));($i<@$ref_labels);(++$i)){(my $name=@$ref_labels[$i]);
setWidth ((\%table),$i,$$value{$name});}}for ((my $i=(0x0b97+ 2514-0x1569));($i<
@$ref_labels);(++$i)){printWidth ((\%table),$i,@$ref_labels[$i]);}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x1277+ 1953-0x1a17)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x0151+ 4627-0x1363)));}for ((my $i=(0x0cfb+ 6649-0x26f4));($i<@$ref_labels);(
++$i)){if (printMark ((\%table),$i)){return ((-(0x2406+ 196-0x24c9)));}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x058c+ 5487-0x1afa)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x0734+ 6635-0x211e)));}foreach my $key (sort (keys (%$ref_values))){(my $value
=$$ref_values{$key});for ((my $i=(0x0264+ 5350-0x174a));($i<@$ref_labels);(++$i)
){(my $name=@$ref_labels[$i]);if (printWidth ((\%table),$i,$$value{$name})){
return ((-(0x0d69+ 1119-0x11c7)));}}if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x066b+ 968-0x0a32)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x0401+ 6433-0x1d21)));}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x06eb+ 5137-0x1afb)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x1eb7+  28-0x1ed2)));}return ((0x1741+ 898-0x1ac3));}sub NXTools::getLoadAvg{
package NXTools;no warnings;(my $daemonResult=("\x20" x (0x00c0+ 6146-0x18c1)));
(my $response=("\x20" x (0x1141+ 2994-0x1cc1)));(my $message=
"\x2d\x2d\x63\x70\x75\x6c\x6f\x61\x64");Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x65\x6e\x64\x28"
.$daemonResult)."\x2c\x20\x2a\x2a\x2a\x2c\x20\x35\x30\x2c\x20").$message)."\x29"
));(my $return=libnxhs::NXDaemonSend ($daemonResult,$response,
(0x21e3+  28-0x21cd),$message));($response=substr ($response,
(0x02d2+ 7685-0x20d7),index ($response,"\x00")));($response=~ s/\r//g );chomp (
$response);Logger::debug (((((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x65\x6e\x64\x28"
.$daemonResult)."\x2c\x20").$response)."\x2c\x20\x35\x30\x2c\x20").$message).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$return)."\x2e"));if (($response=~ /(\d+\.\d+)\s+(\d+\.\d+)\s+(\d+\.\d+)/ )
){Logger::debug ((("\x4c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x3a\x20".$1
)."\x2e"));return ($1);}Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x62\x74\x61\x69\x6e\x20\x6c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x2e"
);return (0.5);}sub NXTools::getSystemLoad{package NXTools;no warnings;return ((
-(0x030f+ 8614-0x24b4)));}sub NXTools::getAvailableMemory{package NXTools;no 
warnings;return ((-(0x0ad4+ 413-0x0c70)));}sub 
NXTools::stringLengthClientDependent{package NXTools;no warnings;(my $string=
shift (@_));if (Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands 
()){return (libnxh::NXStringLength ($string));}else{return (length ($string));}}
sub NXTools::subStringClientDependent{package NXTools;no warnings;(my $string=
shift (@_));(my $offset=shift (@_));(my $length=shift (@_));if (
Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands ()){return (
libnxh::NXSubstring ($string,$offset,$length));}else{($string=~ s/^(.{$offset,$length}).*/$1/ )
;return ($string);}}sub NXTools::leftJustifyStringClientDependent{package 
NXTools;no warnings;(my $string=shift (@_));(my $maxLength=shift (@_));(my $character
=(shift (@_)||"\x20"));if (
Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands ()){return (
Common::NXCore::leftJustifyString ($string,$maxLength,$character));}else{return 
(sprintf ((("\x25\x2d".$maxLength)."\x73"),$string));}}sub 
NXTools::leftJustifyOrTrimStringClientDependent{package NXTools;no warnings;(my $string
=shift (@_));(my $maxLength=shift (@_));(my $character=(shift (@_)||"\x20"));if 
(Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands ()){return (
Common::NXCore::leftJustifyOrTrimString ($string,$maxLength,$character));}else{
return (sprintf ((((("\x25\x2d".$maxLength)."\x2e").$maxLength)."\x73"),$string)
);}}sub NXTools::leftJustifyOrTrimStringRawFormat{package NXTools;no warnings;(my $string
=shift (@_));(my $maxLength=shift (@_));return (sprintf ((((("\x25\x2d".
$maxLength)."\x2e").$maxLength)."\x73"),$string));}sub 
NXTools::getNxhtdPidFileFromCfg{package NXTools;no warnings;(my (%keys)=());(
$keys{"\x50\x69\x64\x46\x69\x6c\x65"}=(""));($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}=(""));__getFromNxhtdCfg ((\%keys));
if (($keys{"\x50\x69\x64\x46\x69\x6c\x65"}=~ /^\// )){return ($keys{
"\x50\x69\x64\x46\x69\x6c\x65"});}if (($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}ne (""))){return ((($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}.$GLOBAL::DIRECTORY_SLASH).$keys{
"\x50\x69\x64\x46\x69\x6c\x65"}));}else{return ((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH).$keys{"\x50\x69\x64\x46\x69\x6c\x65"}));}}sub 
NXTools::getUniquePort{package NXTools;no warnings;(my $a=(
Common::NXTime::getSecondsSinceEpoch ()%(0x166c+ 4734-0x1562)));(my $port=(
$GLOBAL::ServerSlaveBase+$a));(my $end=($GLOBAL::ServerSlaveBase+
$GLOBAL::ServerSlaveLimit));while (($port<$end)){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x28\x31\x2c\x20"
.$port)."\x29"));(my $return=libnxh::NXTryBindLocal ((0x02cb+ 2003-0x0a9d),$port
));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));if (($return eq "\x31")){return ($port);}if (($return eq 
"\x2d\x31")){(my $errorName=libnxh::NXGetErrorName ());if (($errorName ne 
"\x45\x41\x44\x44\x52\x49\x4e\x55\x53\x45")){(my $errorString=
libnxh::NXGetErrorString ());Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x62\x69\x6e\x64\x20\x70\x6f\x72\x74\x20\x27".$port
)."\x27\x3a\x20").$errorName)."\x2c\x20").$errorString)."\x2e"));return ((-
(0x0179+ 6576-0x1b28)));}}(++$port);}Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x72\x61\x6e\x67\x65\x20\x27"
.$port)."\x20\x2d\x20").$end)."\x27\x2e"));return ((-(0x051b+ 4670-0x1758)));}
sub NXTools::isNotCorrectPort{package NXTools;no warnings;(my $port=shift (@_));
return ((!isCorrectPort ($port)));}sub NXTools::isCorrectPort{package NXTools;no
 warnings;(my $port=shift (@_));if ((((defined ($port)and ($port=~ /^\d+$/ ))and
 ($port>=(0x0924+ 4767-0x1bc3)))and ($port<=65535))){return (
(0x23a2+  51-0x23d4));}return ((0x004c+ 8254-0x208a));}package NXTools;no 
warnings;return ((0x0cc4+ 3308-0x19af));
