############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXScripts::BEGIN{package NXScripts;no warnings;require NXSessionParameters;
do{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"->
import};}package NXScripts;no warnings;($nxReportSysLoadScriptPid=(-
(0x1774+ 219-0x184e)));($nxReportSysLoadScriptMaxRerun=(0x01e1+ 3150-0x0e25));(
$nxReportSysLoadScriptRerunTries=(0x15b7+ 1874-0x1d09));(
$nxReportSysLoadScriptRerunCheckDelay=(0x10e2+ 4770-0x2000));(
$nxReportSysLoadScriptLastRun=(0x00f8+ 1877-0x084d));(
$nxReportSysLoadScriptFinishedAbnormally=(0x04cc+ 3513-0x1285));(
$nxReportSysLoadScriptProcessName=(""));sub runScript{(my $functionName=shift (
@_));(my (%functions)=(
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x6c\x6f\x67\x69\x6e",
$GLOBAL::UserScriptBeforeLogin,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x69\x6e",
$GLOBAL::UserScriptAfterLogin,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x6f\x75\x74",
$GLOBAL::UserScriptAfterLogout,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptBeforeSessionStart,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptAfterSessionStart,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x75\x73\x70\x65\x6e\x64"
,$GLOBAL::UserScriptBeforeSessionDisconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x75\x73\x70\x65\x6e\x64"
,$GLOBAL::UserScriptAfterSessionDisconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,$GLOBAL::UserScriptBeforeSessionReconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,$GLOBAL::UserScriptAfterSessionReconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptBeforeSessionClose,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptAfterSessionClose,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,$GLOBAL::UserScriptBeforeSessionFailure,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,$GLOBAL::UserScriptAfterSessionFailure,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeCreateUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterCreateUser,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeDeleteUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterDeleteUser,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeDisableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterDisableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeEnableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterEnableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x69\x6d\x69\x74\x5f\x61\x6c\x61\x72\x6d"
,$GLOBAL::UserScriptAfterLimitAlarm,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
,$GLOBAL::ScriptBeforeServerDaemonStart,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
,$GLOBAL::ScriptAfterServerDaemonStart,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
,$GLOBAL::ScriptBeforeServerDaemonStop,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
,$GLOBAL::ScriptAfterServerDaemonStop,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x73\x79\x6e\x63"
,$GLOBAL::ScriptAfterClusterSync,
"\x73\x63\x72\x69\x70\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x73\x65\x74\x5f\x73\x68\x61\x72\x65\x64\x5f\x69\x70"
,$GLOBAL::ScriptClusterSetSharedIP,
"\x73\x63\x72\x69\x70\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x63\x6c\x65\x61\x72\x5f\x73\x68\x61\x72\x65\x64\x5f\x69\x70"
,$GLOBAL::ScriptClusterClearSharedIP));(my $name=$functions{$functionName});if (
$GLOBAL::SCRIPT_DEBUG){Logger::debug ((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName),(0x197f+ 1519-0x1f6e))
;}if ($name){if ($GLOBAL::SCRIPT_DEBUG){Logger::debug ((((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName)."\x20").$name),
(0x047f+ 2948-0x1003));}if (-x ($name)){(my (@command)=($name,@_));my (
@parameters);__setEnvironmentVariablesForScript ((\@parameters),$functionName);(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if ($GLOBAL::SCRIPT_DEBUG){Logger::debug ((((((((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName).
"\x20\x72\x65\x74\x75\x72\x6e\x3a\x5b").$cmd_err)."\x2c").$cmd_out)."\x2c").(
$exit_value."\x5d")));}if ((not ($exit_value))){__checkAndReloadDatabaseIfNeeded
 ($cmd_out);return ((0x1a01+ 1070-0x1e2f));}else{Logger::error (((
"\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x73\x63\x72\x69\x70\x74\x20"
.$functionName)."\x20\x66\x61\x69\x6c\x65\x64\x2e"),(0x0e72+ 2554-0x186c));
return ($cmd_err,$cmd_out,$exit_value);}}else{if ($GLOBAL::SCRIPT_DEBUG){
Logger::debug ((("\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74"),
(0x16c1+ 1223-0x1b88));}}}else{return ((0x0567+ 6506-0x1ed1));}}sub 
handleScriptBeforeLogin{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x6c\x6f\x67\x69\x6e",
NXClientConnection::getRemoteIp ()));if (($exit_value!=(0x072f+ 5465-0x1c88))){
Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterLogin{(my $user
=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x69\x6e",$user
,NXClientConnection::getRemoteIp ()));if (($exit_value!=(0x1551+ 1602-0x1b93))){
Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterLogout{(my $user
=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x6f\x75\x74",
$user,NXClientConnection::getRemoteIp ()));if (($exit_value!=
(0x11fa+ 1552-0x180a))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptBeforeStart{my (
$cmd_err,$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x128b+  32-0x12ab))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterStart{my (
$cmd_err,$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x0ca9+ 4259-0x1d4c))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeDisconnect{(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x75\x73\x70\x65\x6e\x64"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x08b7+ 5621-0x1eac))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptAfterDisconnect{(my ($cmd_err
,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x75\x73\x70\x65\x6e\x64"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x11b4+ 356-0x1318))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeReconnect{(my ($cmd_err
,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x0a62+ 1891-0x11c5))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterReconnect{
(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x108f+ 986-0x1469))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeClose{my ($cmd_err,
$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x1354+ 4770-0x25f6))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptAfterClose{my ($cmd_err,
$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x133d+ 2694-0x1dc3))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeFailure{if (
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ())){(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}}sub 
handleScriptAfterFailure{if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(my ($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}}sub 
handleScriptBeforeCreateUser{(my $user=shift (@_));(my ($cmd_err,$cmd_out,
$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x1e67+ 1386-0x23d1))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterCreateUser{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x11b2+ 4905-0x24db))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptBeforeDeleteUser
{(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x1e6f+ 326-0x1fb5))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterDeleteUser{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x2151+ 344-0x22a9))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptBeforeDisableUser{(my $user=shift (@_));(my ($cmd_err,$cmd_out,
$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x08ac+ 3983-0x183b))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterDisableUser
{(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0f84+ 1196-0x1430))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptBeforeEnableUser
{(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0742+ 5841-0x1e13))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterEnableUser{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0056+ 1003-0x0441))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterLimitAlarm{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x69\x6d\x69\x74\x5f\x61\x6c\x61\x72\x6d"
,$user,NXClientConnection::getRemoteIp ()));if (($exit_value!=
(0x0a22+ 277-0x0b37))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptBeforeDaemonStart{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
));if (($exit_value!=(0x1278+ 3105-0x1e99))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptAfterDaemonStart{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
));if (($exit_value!=(0x0c93+ 4067-0x1c76))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptBeforeDaemonStop{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
));if (($exit_value!=(0x0a4a+ 3105-0x166b))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterDaemonStop
{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
));if (($exit_value!=(0x159b+ 1841-0x1ccc))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
__setEnvironmentVariablesForScript{(my $ref_parameters=shift (@_));(my $name=
shift (@_));Server::addCONNECTIONvariableToEnvArrayPassed ($ref_parameters);if (
($name eq 
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x6c\x6f\x67\x69\x6e"))
{push (@$ref_parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
Server::getClientVersion ()));}elsif (($name eq 
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x69\x6e")){
push (@$ref_parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
Server::getClientVersion ()));push (@$ref_parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x41\x55\x54\x48\x3d".
NXLogin::getAuthMethod ()));}}sub __checkAndReloadDatabaseIfNeeded{(my $cmd_out=
shift (@_));if (($cmd_out=~ /(reload servers|reload nodes)/i )){
NXNodes::reloadNodesDB ();}if (($cmd_out=~ /(reload profiles|reload rules)/i )){
main::nxrequire ("\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");
NXProfilesDB::reloadProfilesDB ();}if (($cmd_out=~ /reload users/i )){
main::nxrequire ("\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");
NXUsersManager::reloadUsersDB ();}if (($cmd_out=~ /reload groups/i )){
main::nxrequire ("\x4e\x58\x47\x72\x6f\x75\x70\x73");NXGroups::reloadGroupsDB ()
;}if (($cmd_out=~ /reload administrators/i )){main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXAdministratorsManager::reloadAdministratorsDB ();}if (($cmd_out=~ /reload clusters/i )
){main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");NXCluster::reload ();
}}sub handleScriptBeforeKillingHangedProcess{(my $sessionId=shift (@_));(my $pid
=shift (@_));if (($GLOBAL::scriptBeforeKillingHangedProcess ne (""))){(my $script
=$GLOBAL::scriptBeforeKillingHangedProcess);if (-x ($script)){(my (@command)=(
$script,$pid,$sessionId));(my (@parameters)=());(my ($cmd_err,$cmd_out,
$exit_value)=main::run_command ((\@command),(\@parameters)));}else{if (
Common::NXFile::fileExists ($script)){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x27".$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x69\x73\x20\x6e\x6f\x74\x20\x65\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x2e"
));}else{Logger::warning ((("\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x27".
$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
));}}}}sub runNXReportSystemLoadScript{(my $script=
NXPaths::getNXReportLoadScript ());if (NXSystemDaemons::isRunning (
getSystemLoadScriptProcessName ())){Logger::debug (((
"\x53\x6b\x69\x70\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x27".$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x0a74+ 308-0x0ba7));}if (-x ($script)){(my $systemLoadFile=
NXPaths::getSystemLoadFile ());if ((not (__prepareSystemLoadFile (
$systemLoadFile)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script)."\x27\x2e"));return ((0x110a+ 4617-0x2313));}(my (@command)=());push (
@command,$script);push (@command,$systemLoadFile);(my (@parameters)=());(my $pid
=(-(0x1a72+ 2223-0x2320)));push (@parameters,"\x67\x65\x74\x20\x70\x69\x64",(
\$pid));main::nxRunCommandBg ((\@command),(\@parameters));if (($pid>
(0x05a1+ 7970-0x24c3))){($nxReportSysLoadScriptFinishedAbnormally=
(0x16bc+ 747-0x19a7));($nxReportSysLoadScriptLastRun=
Common::NXTime::getSecondsSinceEpoch ());($nxReportSysLoadScriptPid=$pid);
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&nxReportLoadScriptSIGCHLDHandler)
);NXSystemDaemons::savePid (getSystemLoadScriptProcessName (),$pid);return (
(0x04f1+ 7869-0x23ad));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script)."\x27\x2e"));return ((0x1b42+ 827-0x1e7d));}}else{if (
Common::NXFile::fileExists ($script)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x69\x73\x20\x6e\x6f\x74\x20\x65\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x2e"
));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
));}}return ((0x04b9+ 4078-0x14a7));}sub __prepareSystemLoadFile{(my $systemLoadFile
=shift (@_));if ((not (Common::NXFile::fileExists ($systemLoadFile)))){return (
Common::NXFile::createFileReadWriteByUserReadByGroupOthers ($systemLoadFile));}
else{if ((Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll (
$systemLoadFile)==(-(0x06ac+ 3875-0x15ce)))){return ((0x10f2+ 4721-0x2363));}
return ((0x059a+ 6875-0x2074));}}sub rerunNXReportSystemLoadScript{(++
$nxReportSysLoadScriptRerunTries);runNXReportSystemLoadScript ();}sub 
shouldRerunNXReportSystemLoadScript{if ((not (
isRunNXReportSystemLoadScriptEnabled ()))){return ((0x045f+ 3734-0x12f5));}if ((
$nxReportSysLoadScriptFinishedAbnormally==(0x015d+ 3198-0x0ddb))){return (
(0x022f+ 7172-0x1e33));}if (($nxReportSysLoadScriptRerunTries>
$nxReportSysLoadScriptMaxRerun)){return ((0x05a1+ 1077-0x09d6));}(my $currentTime
=Common::NXTime::getSecondsSinceEpoch ());(my $delay=
$nxReportSysLoadScriptRerunCheckDelay);if ((($nxReportSysLoadScriptLastRun+
$delay)<$currentTime)){return ((0x0811+ 1156-0x0c94));}return (
(0x2140+  17-0x2151));}sub isRunNXReportSystemLoadScriptEnabled{return (
(0x0131+ 4766-0x13cf));}sub nxReportLoadScriptSIGCHLDHandler{(my $pid=shift (@_)
);(my $code=shift (@_));if (((not (NXSystemDaemons::isShutdownFlag ()))and (
$code!=(0x241c+ 354-0x257e)))){($nxReportSysLoadScriptFinishedAbnormally=
(0x0016+ 8946-0x2307));}(my $file=NXPaths::getSystemLoadFile ());if (-f ($file))
{Common::NXFile::truncateFile ($file);}}sub 
handleNXReportSystemLoadScriptAfterDaemonStart{if (NXLicense::isMultiNodeFeature
 ()){handleLeftoverSystemLoadScriptCleanup ();}if (
isRunNXReportSystemLoadScriptEnabled ()){runNXReportSystemLoadScript ();}}sub 
handleLeftoverSystemLoadScriptCleanup{if (isReportSystemLoadSupported ()){
terminateNXReportSystemLoadScriptIfRunning ();}}sub isReportSystemLoadSupported{
if ((NXLicense::isServerAvailableAsRemoteNode ()or NXLicense::isMultiNodeFeature
 ())){return ((0x09c0+ 285-0x0adc));}return ((0x20e9+ 1269-0x25de));}sub 
terminateNXReportSystemLoadScriptIfRunning{(my $pid=NXSystemDaemons::readPid (
getSystemLoadScriptProcessName ()));if ((not (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($pid,
getSystemLoadScriptProcessName ())))){return;}if ((Common::NXProcess::sigterm (
$pid)==(0x01a8+ 2719-0x0c46))){NXSystemDaemons::waitForServiceClosure ($pid,
getSystemLoadScriptProcessName ());}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($pid,
getSystemLoadScriptProcessName ())){NXSystemDaemons::killServiceIfRunning ($pid,
getSystemLoadScriptProcessName (),(0x09f3+ 6236-0x224f));}else{
NXSystemDaemons::removePidFile (getSystemLoadScriptProcessName ());}(my $file=
NXPaths::getSystemLoadFile ());if (Common::NXFile::fileExists ($file)){
Common::NXFile::truncateFile ($file);}}sub getSystemLoadScriptProcessName{if ((
$nxReportSysLoadScriptProcessName eq (""))){($nxReportSysLoadScriptProcessName=
substr (NXPaths::getNXReportLoadScriptName (),(0x0e8b+ 4794-0x2145),
(0x21b4+ 1326-0x26d3)));}return ($nxReportSysLoadScriptProcessName);}sub 
getCustomErrorMessage{(my $messageId=shift (@_));(my (@parameters)=());(my (
@command)=($GLOBAL::CustomErrorMessages,$messageId));(my ($cmdErr,$customMessage
,$exitValue)=main::run_command ((\@command),(\@parameters)));if ((($exitValue!=
(0x03bf+ 7430-0x20c5))or ($customMessage eq ("")))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x73\x74\x6f\x6d\x20\x65\x72\x72\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x77\x69\x74\x68\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::CustomErrorMessages)."\x27\x2e"));return;}($customMessage=~ s/^\n//gm )
;($customMessage=~ s/\n$//gm );return ($customMessage);}"\x3f\x3f\x3f";
