############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXVirtualSession::BEGIN{package NXVirtualSession;no warnings;require Error;
do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
NXVirtualSession::BEGIN{package NXVirtualSession;no warnings;require NXLogin;do{
"\x4e\x58\x4c\x6f\x67\x69\x6e"->import};}package NXVirtualSession;no warnings;
require NXShell;sub BEGIN{require NXNodes;do{"\x4e\x58\x4e\x6f\x64\x65\x73"->
import};}sub BEGIN{require Error;do{"\x45\x72\x72\x6f\x72"->import (
"\x3a\x74\x72\x79")};}sub BEGIN{require NXLogin;do{
"\x4e\x58\x4c\x6f\x67\x69\x6e"->import};}sub BEGIN{require NXNodes;do{
"\x4e\x58\x4e\x6f\x64\x65\x73"->import};}sub BEGIN{require NXSessionParameters;
do{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"->
import};}sub BEGIN{require Common::NXSessionType;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"
->import};}sub BEGIN{require Server;do{"\x53\x65\x72\x76\x65\x72"->import};}sub 
BEGIN{require Common::NXDescriptor;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72"
->import};}sub BEGIN{require NXPaths;do{"\x4e\x58\x50\x61\x74\x68\x73"->import};
}($sessionAlreadySaved=(0x12fd+ 4703-0x255c));($VirtualSessionServerSocket=undef
);($VirtualSessionTimedOut=(0x0b56+ 1047-0x0f6d));($firstConnectionToSession=
(0x096f+ 6535-0x22f5));%restoreParameters;($socketCookie=(""));($socketPath=("")
);($yieldDescriptor=(-(0x0022+ 3345-0x0d32)));($nodeHandler=(-
(0x1234+ 4430-0x2381)));($daemonSocket=undef);($sessionStarted=
(0x0432+ 6009-0x1bab));sub BEGIN{require NXSessionParameters;do{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"->
import};}sub BEGIN{require Common::NXSessionType;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"
->import};}sub BEGIN{require Server;do{"\x53\x65\x72\x76\x65\x72"->import};}sub 
BEGIN{require Common::NXDescriptor;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72"
->import};}sub BEGIN{require NXPaths;do{"\x4e\x58\x50\x61\x74\x68\x73"->import};
}sub removeParameter{(my $ref_parameters=shift (@_));(my $name=shift (@_));(
$$ref_parameters=~ s/--$name=\S+ --/--/ );}sub replaceParameter{(my $ref_parameters
=shift (@_));(my $name=shift (@_));(my $newValue=shift (@_));($$ref_parameters=~ s/--$name=\S+ --/--$name="$newValue" --/ )
;}sub getType{(my $ref_parameters=shift (@_));my ($type);if (($$ref_parameters=~ /--type="(\S+)" --/ )
){($type=$1);}if (($type ne (""))){return ($type);}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x74\x79\x70\x65\x20\x66\x6f\x72\x6d\x20\x27"
.$$ref_parameters)."\x27"));Common::NXCore::assertExit ();}}sub addParameter{(my $ref_parameters
=shift (@_));(my $name=shift (@_));(my $value=shift (@_));if ((not ((
$$ref_parameters=~ /\ $/ )))){($$ref_parameters.="\x20");}($$ref_parameters.=(((
("\x2d\x2d".$name)."\x3d\x22").$value)."\x22\x20"));}sub startHeavyModeServer{(
$GLOBAL::OUTPUT_TO_CLIENT="\x73\x65\x74");Logger::debug (
"\x4e\x58\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x68\x65\x61\x76\x79\x20\x6d\x6f\x64\x65\x20\x73\x65\x72\x76\x65\x72\x2e"
);(my $parameters=NXSessionParameters::getInitialParametersString ());if (
defined (NXNodeExec::getstdin ())){Common::NXCore::setDescriptorInheritable (
NXNodeExec::getstdin ());}if (defined (NXNodeExec::getstdout ())){
Common::NXCore::setDescriptorInheritable (NXNodeExec::getstdout ());}
addParameter ((\$parameters),
"\x76\x69\x72\x74\x75\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e\x69\x64",
Server::getMySessionID ());addParameter ((\$parameters),
"\x75\x73\x65\x72\x6e\x61\x6d\x65",NXLogin::get ()->getLogin);addParameter ((
\$parameters),"\x6e\x6f\x64\x65\x5f\x73\x74\x64\x69\x6e",NXNodeExec::getstdin ()
);addParameter ((\$parameters),"\x6e\x6f\x64\x65\x5f\x73\x74\x64\x6f\x75\x74",
NXNodeExec::getstdout ());addParameter ((\$parameters),
"\x6e\x6f\x64\x65\x5f\x73\x74\x64\x65\x72\x72",NXNodeExec::getstderr ());
addParameter ((\$parameters),"\x6e\x6f\x64\x65\x5f\x70\x69\x64",
NXNodeExec::getpid ());addParameter ((\$parameters),
"\x6e\x6f\x64\x65\x5f\x68\x6f\x73\x74",NXSessionParameters::getNodeHost ());
addParameter ((\$parameters),"\x6e\x6f\x64\x65\x5f\x70\x6f\x72\x74",
NXSessionParameters::getNodePort ());addParameter ((\$parameters),
"\x6e\x6f\x64\x65\x5f\x75\x75\x69\x64",NXSessionParameters::getNodeUUID ());
addParameter ((\$parameters),
"\x63\x6c\x69\x65\x6e\x74\x5f\x76\x65\x72\x73\x69\x6f\x6e",
Server::getClientVersion ());if ((Server::getMainServerClientName ()eq 
"\x6e\x78\x77\x65\x62\x63\x6c\x69\x65\x6e\x74")){addParameter ((\$parameters),
"\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65",
"\x6e\x78\x77\x65\x62\x63\x6c\x69\x65\x6e\x74");}else{addParameter ((
\$parameters),"\x63\x6c\x69\x65\x6e\x74\x5f\x6e\x61\x6d\x65",
Server::getClientName ());}addParameter ((\$parameters),
"\x63\x6c\x69\x65\x6e\x74\x5f\x70\x6c\x61\x74\x66\x6f\x72\x6d",
Server::getClientPlatform ());if (NXSessionParameters::isWebClient ()){
addParameter ((\$parameters),"\x77\x65\x62\x5f\x6c\x6f\x63\x61\x6c\x5f\x69\x70",
NXClientConnection::getLocalIp ());addParameter ((\$parameters),
"\x77\x65\x62\x5f\x72\x65\x6d\x6f\x74\x65\x5f\x69\x70",
NXClientConnection::getRemoteIp ());addParameter ((\$parameters),
"\x63\x6c\x69\x65\x6e\x74\x5f\x62\x72\x6f\x77\x73\x65\x72",
Server::getClientBrowser ());}(my $gpuIndex=
NXSessionParameters::getGpuIndexValue ());if (($gpuIndex ne (""))){addParameter 
((\$parameters),"\x67\x70\x75\x5f\x69\x6e\x64\x65\x78",$gpuIndex);}
runVirtualServer (Server::getMySessionID (),$parameters);
NXNodeExec::closeStdHandlers ();}sub runVirtualServer{(my $sessionId=shift (@_))
;(my $virtualSessionParameters=shift (@_));(my $nxConnection=shift (@_));my (
$pid);Logger::debug (((((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x72\x76\x65\x72\x20\x66\x6f\x72\x20\x68\x65\x61\x76\x79\x20\x6d\x6f\x64\x65\x20\x27"
.$sessionId)."\x27\x20\x27").$virtualSessionParameters)."\x27\x2e"));(my (
@command)=());push (@command,($GLOBAL::ETC_DIR.
"\x2f\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2f\x6e\x78\x73\x65\x72\x76\x65\x72\x2f\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65"
));if (Common::NXSessionType::isCustomForeignMaster (NXNodeExec::getSessionType 
())){push (@command,
"\x2d\x2d\x66\x6f\x72\x65\x69\x67\x6e\x73\x65\x73\x73\x69\x6f\x6e");}else{push (
@command,"\x2d\x2d\x76\x69\x72\x74\x75\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e");}
push (@command,"\x2d\x2d\x73\x65\x73\x73\x69\x6f\x6e\x69\x64");push (@command,
$sessionId);my ($pidIn,$pidOut);Common::NXCore::nxPipeCreateBi ((\$pidIn),(
\$pidOut));Common::NXCore::setDescriptorInheritable ($pidOut);push (@command,
"\x2d\x2d\x70\x69\x64",$pidOut);(my (@options)=());(my $logfile=
Common::NXPaths::getNXServerLogPath ());push (@options,
"\x73\x74\x64\x65\x72\x72",$logfile);my ($in,$out);main::nxPipeCreateBi ((\$out)
,(\$in));SetVirtualSessionServerSocket ($out);Logger::debug ((
"\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x53\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x20\x3d\x20"
.$VirtualSessionServerSocket));push (@options,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$in);push (@options,
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",$in);push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (@options
,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));
push (@options,"\x73\x74\x64\x69\x6e",$virtualSessionParameters);push (@options,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");Logger::debug2 (
"\x50\x61\x73\x73\x69\x6e\x67\x20\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x20\x61\x6e\x64\x20\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x2e"
);push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x3d".libnxh::NXTransGetEnvironment
 ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")));if 
(Server::isConnectionTypeNXD ()){Server::setConnectionDescriptorsInheritable (
(0x1196+ 298-0x12c0));}if ((libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")ne (""))){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")));}elsif (($nxConnection
 ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$nxConnection));}if (
(libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")ne (""))){push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")));}if ((
libnxh::NXTransGetEnvironment ("\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54")ne 
(""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54\x3d".libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54")));}if ((
libnxh::NXTransGetEnvironment ("\x53\x53\x48\x32\x5f\x43\x4c\x49\x45\x4e\x54")ne
 (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x32\x5f\x43\x4c\x49\x45\x4e\x54\x3d".libnxh::NXTransGetEnvironment
 ("\x53\x53\x48\x32\x5f\x43\x4c\x49\x45\x4e\x54")));}if (((
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x54\x55\x52\x4e")ne (""))or 
NXSessionParameters::isTurn ())){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",
"\x4e\x58\x5f\x54\x55\x52\x4e\x3d\x31");}if ((libnxh::NXTransGetEnvironment (
"\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45")ne (""))){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45\x3d".
libnxh::NXTransGetEnvironment ("\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45")));}
main::nxRunCommand ((\@command),(\@options));NXNodeExec::__closeDescriptor (
$pidOut);($pid=NXNodeExec::__getNXNodePidFromHandle ($pidIn));Logger::debug (((
"\x4d\x61\x73\x74\x65\x72\x20\x53\x65\x72\x76\x65\x72\x20\x70\x69\x64\x20\x69\x73\x20\x5b"
.$pid)."\x5d"));if ((not (defined ($pid)))){Logger::error (
"\x56\x69\x72\x74\x75\x61\x6c\x20\x53\x65\x72\x76\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x2e"
);return ((0x0618+ 1172-0x0aac));}setVirtualMasterPid ($pid);
Common::NXProcess::leaveChildAtFinish ($pid);if (Server::isConnectionTypeNXD ())
{Server::setConnectionDescriptorsInheritable ((0x1241+ 5323-0x270b));}return (
(0x0bec+ 1386-0x1155));}sub waitForVirtualServer{(my $virtualServerStdout=shift 
(@_));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);if ((not ($selector->add ($$virtualServerStdout)))){Logger::warning (
(
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x73\x74\x64\x6f\x75\x74\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20"
.$!));}else{Logger::debug (
"\x41\x64\x64\x65\x64\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x73\x74\x64\x6f\x75\x74\x2e"
);}(my $virtualServerOutput=(""));(my $flag_exited=(0x02df+ 8427-0x23ca));while 
(($flag_exited==(0x0353+ 2195-0x0be6))){(my (@ready)=$selector->can_read (15000)
);if ((scalar (@ready)==(0x107a+ 4344-0x2172))){($flag_exited=
(0x1a20+ 2886-0x2565));last;}foreach my $fh (@ready){if (($fh==
$$virtualServerStdout)){Logger::debug (
"\x54\x72\x79\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x73\x74\x64\x6f\x75\x74\x2e"
);(my $read_buf=(""));(my $bytes_read=main::nxread ($fh,(\$read_buf),
(0x0908+ 1779-0x0bfb)));Logger::debug ((((((
"\x62\x79\x74\x65\x73\x5f\x72\x65\x61\x64\x20\x5b".$bytes_read).
"\x5d\x20\x72\x65\x61\x64\x5f\x62\x75\x66\x20\x5b").$read_buf)."\x5d\x20").$!));
($virtualServerOutput.=$read_buf);if ((($bytes_read==(0x1f27+ 595-0x217a))or (
$virtualServerOutput=~ /\n$/ ))){$selector->remove ($fh);$selector->remove (
$signalFd);($flag_exited=(0x1649+ 4161-0x2689));}}}}Logger::debug (
"\x52\x65\x70\x6f\x72\x74\x65\x64\x20\x64\x61\x74\x61\x20\x74\x6f\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72"
);(my $bytes=main::nxwrite (main::nxgetSTDOUT (),$virtualServerOutput));
Logger::debug ((("\x5b".$bytes)."\x5d\x20\x77\x61\x73\x20\x73\x65\x6e\x64\x2e"))
;return ((0x2225+ 167-0x22cb));}sub handleVirtualSessionParameters{(my $stdinParameters
=__getParamsFromStdin ());Logger::debug (((
"\x4e\x58\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x20\x50\x72\x65\x70\x61\x72\x69\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x27"
.$stdinParameters)."\x27\x2e"));NXShell::setCurrentModeToWords ();(my $parameters
=NXShell::getLastParameters ($stdinParameters));(my (%hashParameters)=
NXShell::urlParameter2Hash ($parameters));
NXLogin::setAuthenticationMethodNotRequired ();NXLogin::set (NXUser::new (
$hashParameters{"\x75\x73\x65\x72\x6e\x61\x6d\x65"},"\x6e\x61"),
"\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31",(""),(""),"\x76\x69\x72\x74\x75\x61\x6c")
;if (($hashParameters{"\x63\x6c\x69\x65\x6e\x74\x5f\x76\x65\x72\x73\x69\x6f\x6e"
}=~ /(\d+)\.(\d+)\.(\d+)/ )){Server::setClientMajorVersion ($1);
Server::setClientMinorVersion ($2);Server::setClientPatchVersion ($3);}else{
Server::setClientMajorVersion ($hashParameters{
"\x63\x6c\x69\x65\x6e\x74\x5f\x76\x65\x72\x73\x69\x6f\x6e"});}($GLOBAL::ServerIp
="\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31");if (($hashParameters{
"\x66\x6f\x72\x77\x61\x72\x64\x5f\x75\x73\x65\x72\x5f\x64\x69\x73\x70\x6c\x61\x79"
}ne (""))){Server::setPureSession ();}if (defined ($hashParameters{
"\x6e\x6f\x64\x65\x5f\x73\x74\x64\x69\x6e"})){NXNodeExec::setstdin (
$hashParameters{"\x6e\x6f\x64\x65\x5f\x73\x74\x64\x69\x6e"});
libnxh::NXDescriptorCreate (NXNodeExec::getstdin ());main::closeSocketAtFinish (
NXNodeExec::getstdin ());NXNodeExec::setstdout ($hashParameters{
"\x6e\x6f\x64\x65\x5f\x73\x74\x64\x6f\x75\x74"});libnxh::NXDescriptorCreate (
NXNodeExec::getstdout ());main::closeSocketAtFinish (NXNodeExec::getstdout ());
NXNodeExec::setpid ($hashParameters{"\x6e\x6f\x64\x65\x5f\x70\x69\x64"});
NXNodeExec::setNodeHost ($hashParameters{"\x6e\x6f\x64\x65\x5f\x68\x6f\x73\x74"}
);NXNodeExec::setNodePort ($hashParameters{
"\x6e\x6f\x64\x65\x5f\x70\x6f\x72\x74"});NXNodeExec::setNodeUuid (
$hashParameters{"\x6e\x6f\x64\x65\x5f\x75\x75\x69\x64"});NXNodeExec::setLogin (
$hashParameters{"\x75\x73\x65\x72\x6e\x61\x6d\x65"});(
$GLOBAL::SELECTED_SESSION_SET=(0x0198+ 7376-0x1e67));}else{(my ($uuid,$host,
$port)=NXNodes::findLocalNode ());NXSessionParameters::setNodeHost ($host);
NXSessionParameters::setNodePort ($port);NXSessionParameters::setNodeUUID ($uuid
);}if (($hashParameters{
"\x76\x69\x72\x74\x75\x61\x6c\x4e\x6f\x50\x6c\x61\x79\x65\x72"}eq "\x31")){
Server::setPureVirtualSession ();}main::nxclose (main::nxgetSTDIN ());(my $nullin
=main::nxopen ("\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c",$NXBits::O_RDONLY,
(0x0599+ 2504-0x0f61)));($GLOBAL::DefaultSTDINDescriptor=$nullin);(
$stdinParameters=NXShell::hashParameters2Url (%hashParameters));
NXShell::setLastParameters ($stdinParameters);}sub setParametersForFirstAttach{(my $parameters
=NXSessionParameters::getInitialParametersString ());if (
Common::NXSessionType::isNxConsoleFamily (NXSessionParameters::getSessionType ()
)){replaceParameter ((\$parameters),"\x74\x79\x70\x65",
"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65\x2d\x73\x68\x61\x64\x6f\x77");}else{
replaceParameter ((\$parameters),"\x74\x79\x70\x65","\x73\x68\x61\x64\x6f\x77");
}addParameter ((\$parameters),"\x69\x64",Server::getMySessionID ());addParameter
 ((\$parameters),"\x66\x69\x72\x73\x74\x41\x74\x74\x61\x63\x68",
(0x131c+ 3780-0x21df));return ($parameters);}sub askForAgentDParameters{(my $mainSessionID
=shift (@_));Logger::debug (((
"\x41\x73\x6b\x69\x6e\x67\x20\x73\x65\x72\x76\x65\x72\x20".$mainSessionID).
"\x20\x66\x6f\x72\x20\x6d\x61\x73\x74\x65\x72\x20\x61\x67\x65\x6e\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x2e"
));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});if ((not (
$selector->add ($signalFd)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);}else{Logger::debug (((
"\x41\x64\x64\x65\x64\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x6f\x63\x6b\x65\x74\x20\x5b"
.$signalFd)."\x5d"));}(my $msg=($GLOBAL::MSG_WAIT_DISPLAY."\x20\x77\x61\x69\x74"
));(my $socket=main::send_command_to_server ($mainSessionID,$msg,
"\x6e\x6f\x74\x63\x6c\x6f\x73\x65"));if ((defined ($socket)and (not (($socket eq
 (-(0x154b+ 3027-0x211d))))))){Logger::debug (((
"\x63\x6f\x6f\x6b\x69\x65\x20\x73\x6f\x63\x6b\x65\x74\x20\x5b".$socket)."\x5d"))
;if ((not ($selector->add ($socket)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x20\x73\x6f\x63\x6b\x65\x74\x20\x74\x6f\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
);}else{Logger::debug (((
"\x41\x64\x64\x65\x64\x20\x63\x6f\x6f\x6b\x69\x65\x20\x73\x6f\x63\x6b\x65\x74\x20\x74\x6f\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));}(my $answer=(""));(my $finish=(0x0b72+ 2575-0x1581));while (
($finish!=(0x1839+ 909-0x1bc5))){(my (@ready)=$selector->can_read (15000));
Logger::debug ((("\x72\x65\x61\x64\x79\x20\x5b".join ($",@ready))."\x5d"));
foreach my $fh (@ready){if (($fh==$socket)){my ($read_buf);(my $bytes_read=
main::nxread ($fh,(\$read_buf),(0x095b+ 1739-0x0e26)));if (defined ($bytes_read)
){Logger::debug (((
"\x53\x6f\x63\x6b\x65\x74\x20\x62\x79\x74\x65\x73\x5f\x72\x65\x61\x64\x3a\x20".
$bytes_read)."\x2e"));}else{(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23"
.$fh)."\x2e"));Logger::debug ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));}($answer.=$read_buf);
if ((($bytes_read==(0x22da+  99-0x233d))or ($answer=~ /\n$/ ))){$selector->
remove ($fh);$selector->remove ($signalFd);($finish=(0x0bf7+ 2849-0x1717));}}}}(my $log_message
=$answer);($log_message=main::hideOutput ($log_message));Logger::debug (((
"\x6d\x61\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x61\x6e\x73\x77\x65\x72\x20\x77\x61\x73\x20\x5b"
.$log_message)."\x5d"));if (($answer=~ /NX> $GLOBAL::MSG_COMMAND_ERROR (.+)[\n]+/ )
){(my $error=$1);Logger::error ($error);NXNodeExec::stop ();
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x4e\x6f\x64\x65\x45\x72\x72\x6f\x72\x53\x69\x6d\x70\x6c\x65"
->throw ($error);}if (($answer=~ /NX> $GLOBAL::MSG_WAIT_DISPLAY (.*) (.*)/ )){
NXSessionParameters::setAgentMDisplay ($1);NXSessionParameters::setAgentMCookie 
($2);NXSessionParameters::setShadowDisplay ($1);Logger::debug (
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x72\x65\x74\x72\x69\x65\x76\x65\x64"
);}}else{Logger::warning (
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6d\x61\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e"
);NXMsg::register_response (
"\x4e\x58\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e",
"\x65\x54\x69\x6d\x65\x6f\x75\x74\x4f\x6e\x57\x61\x69\x74\x46\x6f\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e"
,(0x0f9c+ 696-0x1060));NXMsg::send_response (
"\x65\x54\x69\x6d\x65\x6f\x75\x74\x4f\x6e\x57\x61\x69\x74\x46\x6f\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e"
,"\x4e\x58\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");
setVirtualSessionTimedOut ();NXNodeExec::stop ();main::nxexit (
(0x04b2+ 8332-0x253e));}}sub ask2{Logger::debug (
"\x57\x61\x69\x74\x20\x66\x6f\x72\x20\x76\x69\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x74\x61\x72\x74\x2e"
);(my $finish=(0x08aa+ 1016-0x0ca2));while (($finish!=(0x0171+ 128-0x01f0))){(my $answer
=main::send_command_to_server (Server::getMainSessionID (),(
$GLOBAL::MSG_WAIT_DISPLAY."\x20\x77\x61\x69\x74"),"\x77\x61\x69\x74"));if ((
$answer=~ /NX> $GLOBAL::MSG_WAIT_DISPLAY (.*) (.*)/ )){
NXSessionParameters::setAgentMDisplay ($1);NXSessionParameters::setAgentMCookie 
($2);NXSessionParameters::setShadowDisplay ($1);($finish=(0x0574+ 692-0x0827));}
else{Logger::debug ((("\x61\x67\x61\x69\x6e\x20\x5b".$answer)."\x5d"));}}}(
$cookieSocket=(-(0x0c2f+ 2750-0x16ec)));sub setSocketForAgentCookie{(
$cookieSocket=shift (@_));Logger::debug (((
"\x53\x6f\x63\x6b\x65\x74\x20\x73\x65\x74\x20\x6f\x6e\x3a\x20\x5b".$cookieSocket
)."\x5d"));}sub checkAgentCookieRequest{Logger::debug (((
"\x43\x68\x65\x63\x6b\x20\x61\x67\x65\x6e\x74\x20\x73\x6f\x63\x6b\x65\x74\x20\x5b"
.$cookieSocket)."\x5d"));if (($cookieSocket!=(-(0x23b5+ 431-0x2563)))){
Logger::debug (
"\x52\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x63\x6f\x6f\x6b\x69\x65\x20\x77\x61\x73\x20\x73\x65\x74\x2e"
);return ((0x0eca+ 4852-0x21bd));}Logger::debug (
"\x4e\x6f\x20\x72\x65\x71\x75\x65\x73\x74\x73\x20\x66\x6f\x72\x20\x63\x6f\x6f\x6b\x69\x65\x2e"
);return ((0x1837+ 544-0x1a57));}sub sentAgentCookie{(my $display=shift (@_));(my $cookie
=shift (@_));Logger::debug (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x63\x6f\x6f\x6b\x69\x65");(my $message=(((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_WAIT_DISPLAY)."\x20").$display)."\x20").$cookie)
);if (($applicationTerminated==(0x0687+ 1805-0x0d93))){($message=
NXNodeExec::getErrorApplicationTerminated ());}(my $bytes=
main::send_reply_to_socket ($cookieSocket,$message));Logger::debug ((("\x5b".
$bytes)."\x5d\x20\x77\x61\x73\x20\x73\x65\x6e\x64\x20\x62\x61\x63\x6b\x2e"));(
$cookieSocket=(-(0x119d+ 3937-0x20fd)));}sub handleWaitDisplay{(my $sock=shift (
@_));Logger::debug (((
"\x53\x65\x6c\x65\x63\x74\x69\x6e\x67\x20\x6d\x79\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x5b"
.Server::getMySessionID ())."\x5d"));(my ($agentm_display,$agentm_cookie)=
NXSession2::getAgentMDisplayAndCookieBySessionId (Server::getMySessionID ()));
Logger::debug (((
"\x64\x69\x73\x70\x6c\x61\x79\x20\x66\x72\x6f\x6d\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x5b"
.$agentm_display)."\x5d"));setSocketForAgentCookie ($sock);sentAgentCookie (
$agentm_display,$agentm_cookie);}sub isCookieSocket{(my $socketNr=shift (@_));
Logger::debug2 (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x66\x20\x73\x6f\x63\x6b\x65\x74\x20\x5b"
.$socketNr).
"\x5d\x20\x69\x73\x20\x63\x6f\x6f\x6b\x69\x65\x20\x73\x6f\x63\x6b\x65\x74\x2e"))
;if (($cookieSocket!=(-(0x0561+ 4424-0x16a8)))){Logger::debug2 (((
"\x53\x6f\x63\x6b\x65\x74\x20\x5b".$socketNr).
"\x5d\x20\x69\x73\x20\x63\x6f\x6f\x6b\x69\x65\x20\x73\x6f\x63\x6b\x65\x74\x2e"))
;return ((0x0bc8+ 6456-0x24ff));}Logger::debug2 (((
"\x53\x6f\x63\x6b\x65\x74\x20\x5b".$socketNr).
"\x5d\x20\x69\x73\x20\x4e\x4f\x54\x20\x63\x6f\x6f\x6b\x69\x65\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x034b+ 2370-0x0c8d));}sub isNotCookieSocket{(my $socket=shift (@_))
;return ((!isCookieSocket ($socket)));}sub __getParamsFromStdin{Logger::debug (
"\x67\x65\x74\x74\x69\x6e\x67\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73"
);(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);if ((not ($selector->add (main::nxgetSTDIN ())))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x53\x54\x44\x49\x4e\x20\x74\x6f\x20\x74\x68\x65\x20\x67\x53\x65\x6c\x65\x63\x74\x6f\x72\x2e"
);}else{Logger::debug ("\x41\x64\x64\x65\x64\x20\x73\x74\x64\x69\x6e");}(my $params
=(""));(my $flag_exited=(0x25c1+ 196-0x2685));while (($flag_exited==
(0x0b64+ 1539-0x1167))){(my (@ready)=$selector->can_read (15000));if ((scalar (
@ready)==(0x091a+ 3637-0x174f))){($flag_exited=(0x0137+ 829-0x0473));last;}
foreach my $fh (@ready){if (($fh==main::nxgetSTDIN ())){Logger::debug (
"\x54\x72\x79\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x2e"
);(my $read_buf=(""));(my $bytes_read=main::nxread ($fh,(\$read_buf),
(0x0e89+ 6739-0x26dc)));if (defined ($bytes_read)){Logger::debug (((((
"\x53\x74\x64\x69\x6e\x20\x62\x79\x74\x65\x73\x5f\x72\x65\x61\x64\x3a\x20".
$bytes_read)."\x20\x72\x65\x61\x64\x5f\x62\x75\x66\x3a\x20\x27").$read_buf).
"\x27\x2e"));}else{(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x20\x46\x44\x23"
.$fh)."\x2e"));Logger::debug ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));}($params.=$read_buf);
if ((($bytes_read==(0x178a+ 2424-0x2102))or ($params=~ /\n$/ ))){$selector->
remove ($fh);$selector->remove ($signalFd);($flag_exited=(0x15c5+ 1363-0x1b17));
}}}}return ($params);}sub setVirtualSessionId{(my $ref_hashParameters=shift (@_)
);(my $virtualSessionID=shift (@_));($$ref_hashParameters{"\x69\x64"}=
$virtualSessionID);}sub setFirstSessionAttach{(my $ref_hashParameters=shift (@_)
);($$ref_hashParameters{"\x66\x69\x72\x73\x74\x41\x74\x74\x61\x63\x68"}=
(0x06b2+ 5397-0x1bc6));}sub setSessionSaved{(my $ref_hashParameters=shift (@_));
($$ref_hashParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x6e\x44\x42"}=
(0x1078+ 841-0x13c0));}sub isSessionSaved{(my $ref_hashParameters=shift (@_));if
 (($$ref_hashParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x6e\x44\x42"}==
(0x08ca+ 5124-0x1ccd))){return ((0x0801+ 7647-0x25df));}return (
(0x0520+ 7776-0x2380));}sub setUsername{(my $ref_hashParameters=shift (@_));(my $username
=shift (@_));($$ref_hashParameters{"\x75\x73\x65\x72\x6e\x61\x6d\x65"}=$username
);}sub startSessionForUser{(my $parameters=shift (@_));return (runVirtualServer 
(main::get_unique_id (),$parameters));}sub __waitForVirtualSessionConnected{(my $ref_error
=shift (@_));(my $serverSocket=GetVirtualSessionServerSocket ());if ((not (
defined ($serverSocket)))){Logger::error (
"\x73\x74\x61\x72\x74\x53\x65\x73\x73\x69\x6f\x6e\x46\x6f\x72\x55\x73\x65\x72\x41\x6e\x64\x57\x61\x69\x74\x46\x6f\x72\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x3a\x20\x6e\x6f\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x2e"
);return ((-(0x058c+ 2551-0x0f82)));}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;$selector->add ($$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$serverSocket);(my $done=(0x1027+ 3453-0x1da4));(my $answer=(""));while ((not (
$done))){(my (@ready)=$selector->can_read ($GLOBAL::DefaultSelectorTimeout));
foreach my $fh (@ready){if (($fh==$serverSocket)){my ($read_buf);(my $bytes_read
=main::nxread ($fh,(\$read_buf),(0x19e1+ 6125-0x21ce)));Logger::debug (((
"\x73\x74\x61\x72\x74\x53\x65\x73\x73\x69\x6f\x6e\x46\x6f\x72\x55\x73\x65\x72\x41\x6e\x64\x57\x61\x69\x74\x46\x6f\x72\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x3a\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x27"
.$read_buf)."\x27\x2e"));($answer.=$read_buf);if (($bytes_read==
(0x140f+ 4633-0x2628))){$selector->remove ($fh);($done=(0x04e3+ 1448-0x0a8a));}
if (__receivedLastMessageFromVirtualSessionStartup ($answer)){($done=
(0x13ea+ 390-0x156f));}if (__receivedErrorFromVirtualSessionStartup ($answer)){(
$done=(0x088b+ 302-0x09b8));}}}if (NXShell::isExitRequestReceivedSIGINT ()){(
$done=(0x04dd+ 2147-0x0d3f));}}return (__parseAnswerFromVirtualSession ($answer,
$ref_error));}sub __receivedLastMessageFromVirtualSessionStartup{(my $answer=
shift (@_));if (($answer=~ /NX> $GLOBAL::MSG_NODE_SESSION_STATUS/ )){return (
(0x0bd6+ 2531-0x15b8));}return ((0x1d70+ 652-0x1ffc));}sub 
__receivedErrorFromVirtualSessionStartup{(my $answer=shift (@_));if (($answer=~ /NX> (\d+) (.*)/ )
){(my $messageNum=$1);(my $messageBody=$2);if ((($messageNum le 
(0x0cf1+ 2915-0x15fc))and ($messageNum gt (0x0f97+ 1980-0x1560)))){return (
(0x0215+ 596-0x0468));}}return ((0x1032+ 1658-0x16ac));}sub 
__parseAnswerFromVirtualSession{(my $answer=shift (@_));(my $ref_error=shift (@_
));(my $display=(-(0x1208+ 3680-0x2067)));if (($answer=~ /NX> $GLOBAL::MSG_NODE_SESSION_DISPLAY Session display: (\d+)/ )
){($display=$1);}if (($answer=~ /NX> $GLOBAL::MSG_NODE_SESSION_STATUS Session status: running/ )
){return ($display);}(my (@outputLines)=split ( /\n/ ,$answer,
(0x02c8+ 2220-0x0b74)));foreach my $line (@outputLines){if (($line=~ /NX> (\d+) (.*)/ )
){(my $messageNum=$1);(my $messageBody=$2);if ((($messageNum le 
(0x0cf0+ 2447-0x1427))and ($messageNum gt (0x1212+ 4149-0x2054)))){chomp ($line)
;($line.="\x0a");if (Server::passErrorsToUserEnabled ()){($line=
NXNodeError::translationTheMessageReceivedFromNode ($line));main::nxwrite (
main::nxgetSTDOUT (),$line);}else{($$ref_error.=$line);}}}}return ((-
(0x1dbc+ 2370-0x26fd)));}sub startSessionForUserAndWaitForConnected{(my $parameters
=shift (@_));(my $ref_error=shift (@_));(my $nxConnection=shift (@_));(my $started
=runVirtualServer (main::get_unique_id (),$parameters,$nxConnection));if ((not (
$started))){Logger::error (
"\x73\x74\x61\x72\x74\x53\x65\x73\x73\x69\x6f\x6e\x46\x6f\x72\x55\x73\x65\x72\x41\x6e\x64\x57\x61\x69\x74\x46\x6f\x72\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x3a\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x2e"
);return ((-(0x0802+ 1381-0x0d66)));}Common::NXCore::exitFromSelectOnFirstSignal
 ();(my $display=__waitForVirtualSessionConnected ($ref_error));
Common::NXCore::disableExitFromSelectOnFirstSignal ();return ($display);}sub 
SetVirtualSessionServerSocket{(my $fh=shift (@_));($VirtualSessionServerSocket=
$fh);}sub GetVirtualSessionServerSocket{return ($VirtualSessionServerSocket);}
sub setVirtualSessionTimedOut{($VirtualSessionTimedOut=(0x0abd+ 3611-0x18d7));}
sub wasVirtualSessionTimedOut{return ($VirtualSessionTimedOut);}sub 
setVirtualMasterPid{($VirtualMasterPid=shift (@_));}sub getVirtualMasterPid{
return ($VirtualMasterPid);}($rootlessReconnect=(0x0493+ 339-0x05e6));sub 
isRootlessReconnect{if (($rootlessReconnect==(0x0dd9+ 115-0x0e4b))){return (
(0x0571+ 2172-0x0dec));}return ((0x150b+ 241-0x15fc));}sub setRootlessReconnect{
($rootlessReconnect=(0x1cd0+ 1864-0x2417));}sub checkEventForConnectedUser{(my $attachedUser
=shift (@_));(my $attachedSessionId=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$attachedSessionId)."\x2e"));(my $directlyConnected=(0x0b9c+ 2181-0x1421));if (
($$attachedUser{"\x63\x6c\x69\x65\x6e\x74"}eq 
"\x6c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74")){($directlyConnected=
(0x1c42+ 691-0x1ef4));if ((not (NXNodeExec::ifAddUserOnConnected ()))){(
$firstConnectionToSession=(0x0e39+ 2275-0x171c));}}else{if (
NXSession2::existSession ($attachedSessionId)){if (
NXSession2::isDirectConnectedBySessionId ($attachedSessionId)){(
$directlyConnected=(0x1440+ 896-0x17bf));}}else{Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$attachedSessionId).
"\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
).((($$attachedUser{"\x75\x73\x65\x72\x6e\x61\x6d\x65"}.
"\x20\x6f\x6e\x20\x64\x69\x73\x70\x6c\x61\x79\x20").$$attachedUser{
"\x64\x69\x73\x70\x6c\x61\x79"})."\x2e")));}}if (
NXSessionParameters::imHeavyModeServer ()){Server::setClientConnectionClosed ();
}NXNodeExec::updateKeyFromAttachedHashBySessionID ($attachedSessionId,
"\x64\x69\x72\x65\x63\x74\x6c\x79\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64",
$directlyConnected);if (($directlyConnected==(0x087a+ 240-0x0969))){
Logger::debug ((("\x55\x73\x65\x72\x20".$$attachedUser{
"\x75\x73\x65\x72\x6e\x61\x6d\x65"}).
"\x20\x69\x73\x20\x64\x69\x72\x65\x63\x74\x6c\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2e"
));if (($firstConnectionToSession==(0x20df+ 169-0x2187))){(
$firstConnectionToSession=(0x262c+ 140-0x26b8));NXEvent::sessionConnected ();}
else{if (($attachedSessionId ne Server::getMySessionID ())){
NXReconnect::setReconnectSessionId ($attachedSessionId);}else{Logger::debug (
"\x50\x72\x65\x76\x65\x6e\x74\x65\x64\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x6d\x79\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x61\x73\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6f\x6e\x65\x2e"
);}}}else{Logger::debug ((("\x55\x73\x65\x72\x20".$$attachedUser{
"\x75\x73\x65\x72\x6e\x61\x6d\x65"}).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x64\x69\x72\x65\x63\x74\x6c\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2e"
));}}sub checkEventForDisonnectedUser{(my $attachedSessionId=shift (@_));if ((
NXNodeExec::getDirectlyConnectedFromAttachedHashBySessionID ($attachedSessionId)
==(0x15dd+ 472-0x17b4))){main::nxrequire (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72");
NXSessionManager::considerAfterSessionDisconnect ();}}sub setRestoreParameters{(my $param
=shift (@_));($param=~ s/--//g );($param=~ s/\s*$// );(my $logParam=
main::hideOutput ($param));Logger::debug (((
"\x73\x65\x74\x20\x52\x65\x73\x74\x6f\x72\x65\x20\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x62\x79\x20\x27"
.$logParam)."\x27"));(my (@args)=split ( / / ,$param,(0x0add+ 575-0x0d1c)));
foreach my $pair (@args){(my ($key,$value)=split ( /=/ ,$pair,
(0x0495+ 2283-0x0d7d)));if ((($key ne "\x69\x64")and ($key ne ("")))){(
$restoreParameters{$key}=$value);}}}sub acquireParameters{(my $line=shift (@_));
($line=~ s/NX> $GLOBAL::MSG_SERVER_DESCRIPTOR_ACQUIRE Acquire descriptor // );(
$line=~ s/\s*$// );(my (@args)=split ( / / ,$line,(0x0ff7+ 2248-0x18bf)));my (
%acquireParameter);foreach my $pair (@args){(my ($key,$value)=split ( /=/ ,$pair
,(0x01e5+ 3526-0x0fa8)));if (($key eq 
"\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x53\x65\x73\x73\x69\x6f\x6e\x49\x64")){
NXReconnect::setReconnectSessionId ($value);next;}($acquireParameter{$key}=
$value);}(my (@keys)=keys (%acquireParameter));(my $newline=(""));foreach my $key
 (@keys){($newline.=((($key."\x3d").$acquireParameter{$key})."\x20"));}(my $message
=((("\x4e\x58\x3e\x20".$GLOBAL::MSG_NODE_DESCRIPTOR_ACQUIRE).
"\x20\x41\x63\x71\x75\x69\x72\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20"
).$newline));Server::setForeignAddress ($acquireParameter{
"\x66\x6f\x72\x65\x69\x67\x6e\x41\x64\x64\x72\x65\x73\x73"});return (
NXNodeExec::sendToNode (($message."\x0a")));}sub yieldParameters{(my $line=shift
 (@_));($line=~ s/NX> $GLOBAL::MSG_NODE_DESCRIPTOR_YIELD Yield descriptor // );(
$line=~ s/\s*$// );(my (@args)=split ( / / ,$line,(0x0a88+ 6638-0x2476)));
foreach my $pair (@args){(my ($key,$value)=split ( /=/ ,$pair,
(0x01c5+ 3180-0x0e2e)));($restoreParameters{$key}=$value);}($restoreParameters{
"\x66\x6f\x72\x65\x69\x67\x6e\x41\x64\x64\x72\x65\x73\x73"}=
NXLogin::getForeignAddres ());(my $udpPort=NXSessionParameters::getUdpPort ());
if (($udpPort>(0x12b8+ 3320-0x1fb0))){($restoreParameters{
"\x75\x64\x70\x50\x6f\x72\x74"}=$udpPort);}(my (@keys)=keys (%restoreParameters)
);(my $newline=(""));foreach my $key (@keys){($newline.=((($key."\x3d").
$restoreParameters{$key})."\x20"));}($newline.=((
"\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x53\x65\x73\x73\x69\x6f\x6e\x49\x64\x3d".
Server::getMySessionID ())."\x20"));(my $message=((
$GLOBAL::MSG_SERVER_DESCRIPTOR_ACQUIRE.
"\x20\x41\x63\x71\x75\x69\x72\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20"
).$newline));main::send_command_to_server (Server::getMainSessionID (),$message,
"\x6e\x6f\x74\x77\x61\x69\x74");}sub addRealConnectedForHeavyMode{(my $sessionID
=shift (@_));if (Common::NXSessionType::isNotVirtual (
NXSessionParameters::getSessionType ())){return;}if ((
NXNodeConfiguration::isAgentX11VectorGraphics ()and 
Server::doesClientSupportLightMode ())){return;}if (
NXSession2::isDirectConnectedBySessionId ($sessionID)){
NXSession2::setRealConnectedBySessionId ($sessionID);
Server::setSessionRealConnected ($sessionID);Logger::debug ((("\x53\x65\x74\x20"
.$sessionID).
"\x20\x61\x73\x20\x72\x65\x61\x6c\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2e"))
;}}sub removeRealConnectedForHeavyMode{(my $sessionID=shift (@_));if (
Common::NXSessionType::isNotVirtual (NXSessionParameters::getSessionType ())){
return;}if ((NXNodeConfiguration::isAgentX11VectorGraphics ()and 
Server::doesClientSupportLightMode ())){return;}if (
Server::isSessionRealConnected ($sessionID)){
NXSession2::removeSessionRealConnected ($sessionID);
Server::removeSessionRealConnected ();Logger::debug (((
"\x52\x65\x6d\x6f\x76\x65\x64\x20".$sessionID).
"\x20\x61\x73\x20\x72\x65\x61\x6c\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2e"))
;}}sub isNodeStartedThroughDaemon{if ((NXSessionParameters::getSessionType ()eq 
(""))){return ((0x0721+ 6806-0x21b7));}if (Common::NXSessionType::isVirtual (
NXSessionParameters::getSessionType ())){return ((0x0ff7+ 4771-0x2299));}return 
((0x0e25+ 2244-0x16e9));}sub __getStartNodeThroughDaemonMessage{(my $username=
shift (@_));(my $socketPath=shift (@_));(my $socketCookie=shift (@_));(my $message
=("\x4e\x58\x3e\x20".$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE));($message.=(
"\x20\x53\x74\x61\x72\x74\x20\x6e\x6f\x64\x65\x20\x66\x6f\x72\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x3d"
.Server::getMySessionID ()));($message.=(
"\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3d".main::urlencode ($username)));(
$message.=("\x20\x70\x69\x64\x3d".$ $));
 ($message.=(
"\x20\x73\x6f\x63\x6b\x65\x74\x50\x61\x74\x68\x45\x6e\x63\x6f\x64\x65\x64\x3d".
main::urlencode ($socketPath)));($message.=(
"\x20\x73\x6f\x63\x6b\x65\x74\x43\x6f\x6f\x6b\x69\x65\x3d".$socketCookie));(
$message.=("\x20\x70\x72\x69\x6f\x74\x69\x74\x79\x3d".main::getNodePriority ()))
;($message.=("\x20\x72\x75\x6e\x4e\x6f\x64\x65\x4d\x6f\x64\x65\x3d".
$GLOBAL::RunNodeMode));(my $nxConnectionEnv=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (($nxConnectionEnv 
ne (""))){($message.=(
"\x20\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".main::urlencode (
$nxConnectionEnv)));}(my $sshConnectionEnv=libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if ((
$sshConnectionEnv ne (""))){($message.=(
"\x20\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".
main::urlencode ($sshConnectionEnv)));}(my $sshClientEnv=
libnxh::NXTransGetEnvironment ("\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"));if (
($sshClientEnv ne (""))){($message.=(
"\x20\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54\x3d".main::urlencode (
$sshClientEnv)));}(my $krb5ccameEnv=libnxh::NXTransGetEnvironment (
"\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45"));if (($krb5ccameEnv ne (""))){(my $isSSHLogin
=NXLogin::isAuthenticationMethodBasedOnSSHSystem ());(my $sessionId=
$NXSessionParameters::hashParameters{"\x69\x64"});(my $isVirtual=
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()));if ((
(($isSSHLogin==(0x0a91+ 530-0x0ca2))and ($sessionId eq ("")))and ($isVirtual==
(0x0535+ 1588-0x0b68)))){(my $clone=NXGssAuth::cloneKerberosTicket (
$krb5ccameEnv,$username));if (($clone ne (""))){Logger::debug (((
"\x52\x65\x74\x72\x65\x69\x76\x65\x20\x63\x6c\x6f\x6e\x65\x64\x20\x6b\x65\x72\x62\x65\x72\x6f\x73\x20\x74\x69\x63\x6b\x65\x74\x20\x61\x73\x20\x5b"
.$clone)."\x5d\x2e"));($krb5ccameEnv=$clone);libnxh::NXTransSetEnvironment (
"\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45",$krb5ccameEnv);}else{Logger::error (
"\x4b\x65\x72\x62\x65\x72\x6f\x73\x20\x74\x69\x63\x6b\x65\x74\x20\x6e\x6f\x74\x20\x63\x6c\x6f\x6e\x65\x64\x20\x66\x6f\x72\x20\x53\x53\x48\x20\x66\x6f\x72\x6d\x65\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);}}($message.=("\x20\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45\x3d".
main::urlencode ($krb5ccameEnv)));}(my $sshAuthSocketEnv=
libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x41\x55\x54\x48\x5f\x53\x4f\x43\x4b"));if (($sshAuthSocketEnv 
ne (""))){prepareSSHAuthSocket ($username,$sshAuthSocketEnv);($message.=(
"\x20\x53\x53\x48\x5f\x41\x55\x54\x48\x5f\x53\x4f\x43\x4b\x3d".main::urlencode (
$sshAuthSocketEnv)));}($message.=("\x20\x66\x64\x3d".$yieldDescriptor));(
$message.="\x20\x0a");return ($message);}sub askDaemonToStartNode{(my $username=
shift (@_));Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6e\x78\x6e\x6f\x64\x65\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$username)."\x27\x2e"));if ((NXClientSystemDaemons::openConnection ()!=
(0x04ba+ 7891-0x238c))){(my $error=
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);Logger::error ($error);return ((0x0167+ 5994-0x18d0));}if (($yieldDescriptor==
(-(0x0d89+ 2104-0x15c0)))){Common::NXCore::nxPipeCreateBi ((\$yieldDescriptor),(
\$nodeHandler));}($socketCookie=main::get_unique_id ());($socketPath=
NXPaths::getAncillarySocketPath (Server::getMySessionID ()));(my $message=
__getStartNodeThroughDaemonMessage ($username,$socketPath,$socketCookie));if ((
NXClientSystemDaemons::sendMessage ($message)!=(0x1466+ 2665-0x1ece))){(my $error
=
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);Logger::error ($error);return ($error);}return ((""));}sub 
cleanYieldParameters{($socketCookie=(""));($socketPath=(""));($yieldDescriptor=(
-(0x1bbb+ 339-0x1d0d)));($nodeHandler=(-(0x14c1+ 2336-0x1de0)));}sub 
yieldDescriptorToDaemon{if ((Common::NXDescriptor::yield ($yieldDescriptor,
$socketPath,$socketCookie)==(-(0x1b53+ 2005-0x2327)))){Logger::debug (((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x79\x69\x65\x6c\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$yieldDescriptor).
"\x20\x77\x69\x74\x68\x20\x73\x6f\x63\x6b\x65\x74\x20\x70\x61\x74\x68\x20").
$socketPath)."\x2e"));return ((0x01ed+ 1174-0x0683));}return (
(0x169b+ 1763-0x1d7d));}sub getNodeFromDaemon{Logger::debug (
"\x67\x65\x74\x4e\x6f\x64\x65\x46\x72\x6f\x6d\x44\x61\x65\x6d\x6f\x6e\x2e");
NXClientSystemDaemons::cleanDaemonBuffer ();(my $reply=
NXClientSystemDaemons::parseMessageFromServer (undef,
$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE));Logger::debug (((
"\x52\x65\x70\x6c\x79\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$reply)."\x2e"));if (($reply=~ /NX> $GLOBAL::MSG_START_VIRTUAL_SESSION_NODE Node started with pid=(.*) nxexec=(.*) / )
){(my $nodePid=$1);(my $nxexecPid=$2);Logger::debug (((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$nodePid)."\x20\x6f\x6e\x20\x68\x61\x6e\x64\x6c\x65\x72\x20").$nodeHandler).
"\x2e"));NXNodeExec::setpid ($nodePid);NXNodeExec::setNxexecPid ($nxexecPid);
NXNodeExec::setstdin ($nodeHandler);NXNodeExec::setstdout ($nodeHandler);
NXNodeExec::setstderr (main::nxgetSTDERR ());NXNodeExec::setRunning ();
NXSession2::setNXExecAndNodePidsBySessionId (Server::getMySessionID (),
$nxexecPid,$nodePid);($daemonSocket=
NXClientSystemDaemons::getSocketToServerDaemon ());
Common::NXSelector::addToGlobalSelector ($daemonSocket,
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74"
,
"\x4e\x58\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x6e\x78\x73\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);}else{(my $error=
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x20\x6e\x6f\x64\x65\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x73\x65\x73\x73\x69\x6f\x6e"
);Logger::error ($error);NXClientSystemDaemons::closeConnection ();return (
$error);}NXClientSystemDaemons::unsetConnection ();return ((""));}sub 
createSessionNode{(my $socket=shift (@_));(my $message=shift (@_));(my (
%parameters)=());my ($nodeDesciptor);if (($message=~ /Start node for virtual session=(.*) username=(.*) / )
){($message=~ s/Start node for virtual // );($parameters{
"\x73\x65\x73\x73\x69\x6f\x6e"}=$1);(my (@args)=split ( / / ,$message,
(0x0eb1+ 273-0x0fc2)));foreach my $pair (@args){(my ($key,$value)=split ( /=/ ,
$pair,(0x04e2+ 4983-0x1856)));($parameters{$key}=$value);}(my $socketPath=
main::urldecode ($parameters{
"\x73\x6f\x63\x6b\x65\x74\x50\x61\x74\x68\x45\x6e\x63\x6f\x64\x65\x64"}));if ((
not (Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($parameters{
"\x70\x69\x64"},"\x6e\x78\x73\x65\x72\x76\x65\x72")))){Logger::warning (((
"\x41\x62\x6f\x72\x74\x20\x63\x72\x65\x61\x74\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20\x73\x65\x72\x76\x65\x72\x20"
.$parameters{"\x70\x69\x64"}).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));return (
(0x10ab+ 3397-0x1def));}(my $fd=($parameters{"\x66\x64"}||(0x0240+  92-0x029b)))
;($nodeDesciptor=Common::NXDescriptor::acquire ($parameters{"\x70\x69\x64"},$fd,
$socketPath,$parameters{"\x73\x6f\x63\x6b\x65\x74\x43\x6f\x6f\x6b\x69\x65"}));if
 (($nodeDesciptor==(-(0x0f84+ 521-0x118c)))){Logger::warning (((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x63\x71\x75\x69\x72\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x20"
.$parameters{"\x70\x69\x64"})."\x20\x61\x6e\x64\x20").$socketPath)."\x2e"));
return ((0x1ee0+ 406-0x2075));}Common::NXCore::closeSocketAtFinish (
$nodeDesciptor);}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x68\x61\x6e\x64\x6c\x65\x20\x63\x72\x65\x61\x74\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20"
.$message)."\x2e"));return ((0x08dd+ 5279-0x1d7c));}(my (%options)=());($options
{"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"}=main::urldecode (
$parameters{"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"}));($options{
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"}=main::urldecode (
$parameters{"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"}));(
$options{"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"}=main::urldecode (
$parameters{"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"}));($options{
"\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45"}=main::urldecode ($parameters{
"\x4b\x52\x42\x35\x43\x43\x4e\x41\x4d\x45"}));($options{
"\x53\x53\x48\x5f\x41\x55\x54\x48\x5f\x53\x4f\x43\x4b"}=main::urldecode (
$parameters{"\x53\x53\x48\x5f\x41\x55\x54\x48\x5f\x53\x4f\x43\x4b"}));($options{
"\x4e\x58\x5f\x55\x53\x45\x52\x5f\x47\x52\x4f\x55\x50\x53"}=main::urldecode (
$parameters{"\x4e\x58\x5f\x55\x53\x45\x52\x5f\x47\x52\x4f\x55\x50\x53"}));(
$options{"\x73\x65\x74\x41\x73\x53\x74\x64\x69\x6e"}=$nodeDesciptor);($options{
"\x73\x65\x74\x41\x73\x53\x74\x64\x6f\x75\x74"}=$nodeDesciptor);($options{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}=main::urldecode ($parameters{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}));($options{
"\x72\x75\x6e\x4e\x6f\x64\x65\x4d\x6f\x64\x65"}=$parameters{
"\x72\x75\x6e\x4e\x6f\x64\x65\x4d\x6f\x64\x65"});main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x50\x72\x6f\x63\x65\x73\x73");
NXNodeProcess::setOptions ((\%options));(my $username=main::urldecode (
$parameters{"\x75\x73\x65\x72\x6e\x61\x6d\x65"}));(my ($in,$out,$nxexecPid,
$pidFD)=NXNodeProcess::start ($username,
"\x4e\x58\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x3a\x3a\x70\x69\x64\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));Common::NXProcess::setExitCallback ($nxexecPid,(\&nxexecSIGCHLDcallback));
Common::NXProcess::setErrorCallback ($nxexecPid,(\&nxexecSIGCHLDcallback));
main::nxclose ($nodeDesciptor);(my (%node)=("\x73\x65\x73\x73\x69\x6f\x6e",
$parameters{"\x73\x65\x73\x73\x69\x6f\x6e"},
"\x6e\x78\x65\x78\x65\x63\x50\x69\x64",$nxexecPid,"\x73\x6f\x63\x6b\x65\x74",
$socket));($server{$pidFD}=(\%node));($nxexecPids{$nxexecPid}=(\%node));if ((
$username ne "\x6e\x78")){main::nxrequire (
"\x4e\x58\x44\x65\x62\x75\x67\x4d\x61\x6e\x61\x67\x65\x72");
NXDebugManager::addUserForLogCollection ($username);}if ((NXGssAuth::isActive ()
and NXGssAuth::isDelegated ())){NXGssAuth::setForward ((0x0d71+ 944-0x1120));}
return ((0x093c+ 3060-0x152f));}sub pidCallback{(my $fd=shift (@_));my ($buffer)
;(my $bytes=main::nxread ($fd,(\$buffer),(0x1271+ 6830-0x1d1f)));Logger::debug (
(((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$fd)."\x3a\x20").$buffer));(my $message=(""));if (($bytes<=
(0x0d16+ 6254-0x2584))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x65\x69\x76\x65\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x66\x6f\x72\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20"
.$server{$fd}{"\x73\x65\x73\x73\x69\x6f\x6e"})."\x2e"));($message=((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE).
"\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x65\x69\x76\x65\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x0a"
));}elsif (($buffer=~ /(\d+)/ )){(my $pid=$1);($message=(((((("\x4e\x58\x3e\x20"
.$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE).
"\x20\x4e\x6f\x64\x65\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3d"
).$pid)."\x20\x6e\x78\x65\x78\x65\x63\x3d").$server{$fd}{
"\x6e\x78\x65\x78\x65\x63\x50\x69\x64"})."\x20\x0a"));}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$fd)."\x2e"));($message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE).
"\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x0a"
));}(my $socket=$server{$fd}{"\x73\x6f\x63\x6b\x65\x74"});if (
NXServerDaemon::clientIsWaitingForReply ($socket)){($bytes=main::nxwrite (
$socket,$message));if (($bytes<=(0x19d7+ 2022-0x21bd))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x69\x6e\x66\x6f\x72\x6d\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20"
.$server{$fd}{"\x73\x65\x73\x73\x69\x6f\x6e"}).
"\x20\x61\x62\x6f\x75\x74\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x2e"));}
NXServerDaemon::removeClientFDFromSelector ($socket);
NXServerDaemon::clearAcceptFDBuffer ($socket);}($server{$fd}=undef);delete (
$server{$fd});main::nxclose ($fd);Common::NXSelector::removeFromGlobalSelector (
$fd);}sub nxexecSIGCHLDcallback{(my $pid=shift (@_));(my $code=shift (@_));(my $sessionId
=$nxexecPids{$pid}{"\x73\x65\x73\x73\x69\x6f\x6e"});(my $socket=$nxexecPids{$pid
}{"\x73\x6f\x63\x6b\x65\x74"});(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXEXEC_TERMINATED).
"\x20\x6e\x78\x65\x78\x65\x63\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x43\x6f\x64\x65\x3d"
).$code)."\x20\x0a"));(my $bytes=main::nxwrite ($socket,$message));if (($bytes<=
(0x0383+ 5235-0x17f6))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x69\x6e\x66\x6f\x72\x6d\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x27"
.$sessionId).
"\x27\x20\x61\x62\x6f\x75\x74\x20\x6e\x78\x65\x78\x65\x63\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x2e"
));}else{Logger::debug ((((("\x53\x65\x6e\x74\x20\x27".$message).
"\x27\x20\x74\x6f\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x72\x76\x65\x72\x20\x27"
).$sessionId)."\x27\x2e"));}($nxexecPids{$pid}=undef);delete ($nxexecPids{$pid})
;if (NXServerDaemon::isClientFDInSelector ($socket)){
NXServerDaemon::removeClientFDFromSelector ($socket);}main::nxclose ($socket);}
sub nxserverDaemonCallback{(my $fd=shift (@_));my ($buffer);(my $bytes=
main::nxread ($fd,(\$buffer),(0x1329+ 890-0x06a3)));Logger::debug ((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$fd)."\x3a\x20").$buffer));(my $message=(""));if ((not (defined ($bytes)))){
Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);}elsif (($bytes==(0x1e8c+ 1337-0x23c5))){Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);}elsif (($buffer=~ /NX> $GLOBAL::MSG_NXEXEC_TERMINATED nxexec terminated with exitCode=(.*) / )
){(my $exitCode=$1);Common::NXProcess::handleWatchDogSIG ();}else{
Logger::warning (((
"\x55\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x27"
.$buffer)."\x27\x2e"));}closeDaemonConnection ();}sub closeDaemonConnection{if (
defined ($daemonSocket)){Common::NXSelector::removeFromGlobalSelector (
$daemonSocket);main::nxclose ($daemonSocket);($daemonSocket=undef);}}sub 
__passConnectionDesciptorToNode{(my $descriptor=shift (@_));(my $type=shift (@_)
);(my $socketCookie=main::get_unique_id ());(my $socketPath=
NXPaths::getAncillarySocketPath (Server::getMySessionID ()));(my $socketPathEnconded
=main::urlencode ($socketPath));(my $message=(((((((("\x74\x79\x70\x65\x3d".
$type)."\x20\x70\x69\x64\x3d").$ $) .  "\x20\x73\x6f\x63\x6b\x65\x74\x50\x61\x74\x68\x3d"
).$socketPathEnconded)."\x20\x63\x6f\x6f\x6b\x69\x65\x3d").$socketCookie)."\x20"
));($message.=(("\x66\x64\x3d".$descriptor)."\x20"));if ((acquireParameters (
$message)<(0x11a7+ 4925-0x24e4))){Logger::error (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6e\x78\x61\x67\x65\x6e\x74\x2e"
);NXNodeExec::handleSessionShutdownApplicationTerminated ();
Server::shutdownClientConnection ();return ((0x17b9+  22-0x17ce));}return (
(0x06d5+ 1970-0x0e87));}sub passConnectionToNode{if (Server::isConnectionTypeNXD
 ()){Logger::debug (
"\x50\x61\x73\x73\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x6f\x64\x65\x20\x2d\x20\x74\x79\x70\x65\x20\x4e\x58\x2e"
);return (__passConnectionDesciptorToNode (Server::getConnectionIN (),"\x6e\x78"
));}Logger::debug (
"\x50\x61\x73\x73\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x6f\x64\x65\x20\x2d\x20\x74\x79\x70\x65\x20\x53\x53\x48\x2e"
);if ((__passConnectionDesciptorToNode ($GLOBAL::DefaultSTDINDescriptor,
"\x73\x73\x68\x5f\x69\x6e")==(0x0151+ 7705-0x1f69))){return (
(0x068d+ 4996-0x1a10));}return (__passConnectionDesciptorToNode (
$GLOBAL::DefaultSTDOUTDescriptor,"\x73\x73\x68\x5f\x6f\x75\x74"));}sub 
setApplicationTerminated{($applicationTerminated=(0x1505+ 3192-0x217c));}sub 
isSessionAlreadyStarted{return ($sessionStarted);}sub setSessionStarted{(
$sessionStarted=(0x0b52+ 2234-0x140b));}sub prepareSSHAuthSocket{();}
"\x3f\x3f\x3f";
