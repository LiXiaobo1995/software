############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTest::BEGIN{package NXTest;no warnings;require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}sub NXTest::run_test{package NXTest;no warnings
;Common::NXMsg::send_response (
"\x69\x52\x75\x6e\x6e\x69\x6e\x67\x54\x65\x73\x74\x50\x72\x6f\x63\x65\x64\x75\x72\x65"
);Common::NXMsg::send_response (
"\x69\x46\x69\x6e\x69\x73\x68\x65\x64\x54\x65\x73\x74\x50\x72\x6f\x63\x65\x64\x75\x72\x65"
);}package NXTest;no warnings;NXMsg::register_response (
"\x4e\x58\x54\x65\x73\x74",
"\x69\x53\x63\x72\x69\x70\x74\x46\x69\x6e\x69\x73\x68\x4f\x6b",
(0x1281+ 3980-0x1eec));NXMsg::register_response ("\x4e\x58\x54\x65\x73\x74",
"\x65\x53\x63\x72\x69\x70\x74\x46\x69\x6e\x69\x73\x68\x4b\x6f",
(0x20fc+ 1493-0x23b0));NXMsg::register_response ("\x4e\x58\x54\x65\x73\x74",
"\x65\x4e\x6f\x74\x45\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x46\x69\x6c\x65",
(0x057b+ 8891-0x2513));"\x3f\x3f\x3f";
