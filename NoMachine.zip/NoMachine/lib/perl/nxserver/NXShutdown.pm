############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXShutdown;no warnings;my (%__wasDisabled);sub handleShutdown{(my (
%parameters)=@_);if (defined ($parameters{"\x6d\x6f\x6e\x69\x74\x6f\x72"})){
Server::setClientConnectionClosed ();($parameters{"\x73\x69\x6c\x65\x6e\x63\x65"
}=(0x0365+ 4627-0x1577));}if (((not (main::effectiveUserIsAdministrator ()))and 
(Common::NXCore::getEffectiveUsername ()eq "\x6e\x78"))){return (
shutdownForUserNx ());}Server::setServerIsShutdown ();setServiceStatuses ();
NXSystemDaemons::stop ("\x6e\x78\x64");main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e");
NXRedisSubscription::publishToSubscribers (($GLOBAL::MSG_SHUTDOWN_TERMINATE.
"\x20\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x72\x65\x61\x73\x6f\x6e\x3d\x73\x68\x75\x74\x64\x6f\x77\x6e\x20"
));NXSystemDaemons::setShutdownFlag ();main::nxrequire (
"\x53\x65\x72\x76\x69\x63\x65");(my $error=Service::setStopFlag ());if (((not (
defined ($parameters{"\x73\x69\x6c\x65\x6e\x63\x65"})))or ($parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"}eq (0x1118+ 2388-0x1a6c)))){if (($error==
(0x15a8+ 1701-0x1c4d))){if (serviceWasDisabled (
"\x6e\x78\x73\x65\x72\x76\x65\x72")){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}else{NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}}else{(my $errorString=
libnxh::NXGetErrorString ());Common::NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x46\x69\x6c\x65"
,$GLOBAL::ServerStopStatusFlagLink,$errorString);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}}main::setSSHStatusShutdown ();
main::nxrequire (
"\x4e\x58\x57\x69\x6e\x64\x6f\x77\x73\x53\x65\x72\x76\x69\x63\x65\x73");
NXWindowsServices::sendTerminateToNodeMirror ();NXSystemDaemons::stop (
"\x6e\x78\x73\x65\x72\x76\x65\x72");NXSystemDaemons::printStatus (
"\x6e\x78\x6e\x6f\x64\x65");if (NXSystemDaemons::isServiceEnabled (
"\x6e\x78\x68\x74\x64")){NXSystemDaemons::stop ("\x6e\x78\x68\x74\x64");}
NXUpdate::killUpdate ();NXTerminate::terminateAll ((0x0fa9+ 1395-0x151b));if (
NXSystemDaemons::isSSHEnabled ()){NXWindowsServices::stopService (
"\x6e\x78\x73\x73\x68\x64");}NXWindowsServices::stopService (
"\x6e\x78\x70\x72\x69\x6e\x74\x65\x72",(0x14ec+ 268-0x15f7));
NXWindowsServices::checkForNotCleanedSessionAndClean ();main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (NXCluster::isEnabled ()){
NXCluster::standby ();}main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleLeftoverSystemLoadScriptCleanup ();__resetWasDisabled ();return
 ((0x1754+ 3532-0x2520));}sub setServiceStatuses{(my $servicesToCheck=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x6e\x78\x6e\x6f\x64\x65\x20\x6e\x78\x64");
if (NXLicense::isHttpdSupportFeature ()){($servicesToCheck.=
"\x20\x6e\x78\x68\x74\x64");}if (NXLicense::isSshFeature ()){($servicesToCheck.=
"\x20\x6e\x78\x73\x73\x68\x64");}($response=
NXSystemDaemons::askServerDaemonForServiceStatus ($servicesToCheck));if (defined
 ($response)){(my (@services)=split ( /, / ,$response,(0x02e7+ 2637-0x0d34)));
foreach my $service (@services){if (($service=~ /(.*) Disabled/ )){(
$__wasDisabled{$1}=(0x04c9+ 4406-0x15fe));}}}else{($__wasDisabled{
"\x6e\x78\x6e\x6f\x64\x65"}=(0x04a1+ 6782-0x1f1e));(my (@services)=(
"\x6e\x78\x73\x65\x72\x76\x65\x72","\x6e\x78\x64"));if (
NXLicense::isHttpdSupportFeature ()){push (@services,"\x6e\x78\x68\x74\x64");}
foreach my $serviceName (@services){if ((not (NXSystemDaemons::isRunning (
$serviceName)))){($__wasDisabled{$serviceName}=(0x1093+ 940-0x143e));}}}}sub 
serviceWasDisabled{(my $service=shift (@_));if ((defined ($__wasDisabled{
$service})and ($__wasDisabled{$service}==(0x0978+ 1141-0x0dec)))){return (
(0x0225+ 814-0x0552));}return ((0x2463+ 359-0x25ca));}sub __resetWasDisabled{(my (
@services)=("\x6e\x78\x73\x65\x72\x76\x65\x72","\x6e\x78\x64",
"\x6e\x78\x6e\x6f\x64\x65"));if (NXLicense::isHttpdSupportFeature ()){push (
@services,"\x6e\x78\x68\x74\x64");}foreach my $serviceName (@services){(
$__wasDisabled{$serviceName}=undef);}}sub shutdownForUserNx{Logger::debug (
"\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x6e\x78\x2e"
);(my (@command)=());push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x73\x68\x75\x74\x64\x6f\x77\x6e\x2e\x73\x68");(my (@parameters)=());
main::run_command ((\@command),(\@parameters));return ((0x0454+ 4135-0x147b));}
return ((0x10eb+ 3156-0x1d3e));
