############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXEvent;no warnings;($event={});sub getLicenseExpiredEventName{return (
"\x6c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64");}sub 
getUnknownSessionLimitExpireEventName{(my $sessionId=shift (@_));return ((
"\x75\x6e\x6b\x6e\x6f\x77\x6e\x45\x78\x70\x69\x72\x65\x64\x5f".$sessionId));}sub
 getAutomaticRecordingCleanEventName{return (
"\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x43\x6c\x65\x61\x6e"
);}sub getConnectionStatsRefreshEventName{return (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x53\x74\x61\x74\x73\x52\x65\x66\x72\x65\x73\x68"
);}sub getParentConnectionsRefreshEventName{return (
"\x50\x61\x72\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x52\x65\x66\x72\x65\x73\x68"
);}sub getAppleActiveSessionCheckEventName{return (
"\x41\x70\x70\x6c\x65\x41\x63\x74\x69\x76\x65\x53\x65\x73\x73\x69\x6f\x6e\x43\x68\x65\x63\x6b"
);}sub getGuestExpiryDateEventName{(my $guest=shift (@_));return (($guest.
"\x5f\x65\x78\x70\x69\x72\x79\x44\x61\x74\x65"));}sub afterGuestExpired{(my $eventName
=shift (@_));(my $username=$eventName);($username=~ s/_expiryDate// );
Logger::debug (((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x65\x78\x70\x69\x72\x65\x64\x20\x75\x73\x65\x72\x20"
.$username)."\x2e"));delete ($$event{$eventName});NXShell::handle_command (
"\x67\x75\x65\x73\x74\x64\x65\x6c",$username);}sub sessionConnected{
Logger::debug ((("\x53\x65\x73\x73\x69\x6f\x6e\x20".Server::getMySessionID ()).
"\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2e"));}sub beforeLogin{
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptBeforeLogin ();
NXClientConnection::redirectBeforeAuthIfNeeded ();}sub afterLogin{(my $user=
shift (@_));main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptAfterLogin ($user);
NXClientConnection::redirectAfterAuthIfNeeded ($user);main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");
NXSession2::createSessionIfNeededForLoggedUser ($user);main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::checkIfForwardedSessionAndInformIfNeeded (
Server::getMySessionID ());NXServers::forwardUserIfNeeded ($user);
NXLogin::addUserLoginToDB ();}sub afterLogout{(my $user=shift (@_));
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptAfterLogout ($user);NXLogin::deleteUserLoginFromDB ();}
sub beforeSessionStart{main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptBeforeStart ();}sub afterSessionStart{if (
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ())){
NXVirtualSession::setSessionStarted ();}main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterStart ();}
sub beforeSessionDisconnect{main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXNodeExec::notifyNodeBeforeDisconnect 
();NXScripts::handleScriptBeforeDisconnect ();}sub afterSessionDisconnect{
NXLogin::considerAfterLogout ();main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXNodeExec::notifyNodeAfterDisconnect ()
;NXScripts::handleScriptAfterDisconnect ();}sub beforeSessionReconnect{
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXNodeExec::notifyNodeBeforeReconnect ();NXScripts::handleScriptBeforeReconnect 
();}sub afterSessionReconnect{if (Server::isDisconnectedSessionExpiryKeySet ()){
NXNodeExec::setSessionConnected ();}main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterReconnect ()
;}sub beforeSessionClose{NXSessionManager::setSessionCloseStarted ();
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptBeforeClose ();}sub afterSessionClose{
NXGssAuth::removeDelegatedTicket ();main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterClose ();}
sub beforeSessionFailure{main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73"
);NXScripts::handleScriptBeforeFailure ();}sub afterSessionFailure{
NXGssAuth::removeDelegatedTicket ();main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterFailure ();}
sub beforeCreateUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptBeforeCreateUser 
($user);}sub afterCreateUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterCreateUser (
$user);}sub beforeDeleteUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptBeforeDeleteUser 
($user);}sub afterDeleteUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterDeleteUser (
$user);}sub beforeDisableUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptBeforeDisableUser
 ($user);}sub afterDisableUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterDisableUser 
($user);}sub beforeEnableUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptBeforeEnableUser 
($user);}sub afterEnableUser{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterEnableUser (
$user);}sub afterLimitAlarm{(my $user=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptAfterLimitAlarm (
$user);}sub beforeDaemonStart{main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");NXScripts::handleScriptBeforeDaemonStart
 ();}sub afterDaemonStart{main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e");
NXScripts::handleScriptAfterDaemonStart ();
NXScripts::handleNXReportSystemLoadScriptAfterDaemonStart ();if (
$GLOBAL::EnableGuestWipeout){NXServerDaemon::checkGuestsExpiryDate ();}}sub 
beforeDaemonStop{main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptBeforeDaemonStop ();
NXScripts::handleLeftoverSystemLoadScriptCleanup ();}sub afterDaemonStop{
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptAfterDaemonStop ();}sub beforeKillingHangedProcess{(my $sessionId
=shift (@_));(my $pid=shift (@_));main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleScriptBeforeKillingHangedProcess ($sessionId,$pid);}sub 
ruleAdded{(my $user=shift (@_));(my $node=shift (@_));(my $group=shift (@_));(my $nodeGroup
=shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));
(my $value=shift (@_));(my $address=shift (@_));}sub subscribe{(my $eventName=
shift (@_));(my $action=shift (@_));unless (defined ($eventName)){Logger::error 
(
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x73\x75\x62\x73\x63\x72\x69\x62\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x65\x76\x65\x6e\x74\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($action)){
Logger::error (((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x73\x75\x62\x73\x63\x72\x69\x62\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x61\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20"
.$eventName)."\x2e"));Logger::stackTrace ();main::nxexit ();}unless (defined (
$$event{$eventName})){createNewEvent ($eventName);}addActionToEvent ($eventName,
$action);return ((0x1028+ 155-0x10c2));}sub unsubscribe{(my $eventName=shift (@_
));(my $action=shift (@_));unless (defined ($eventName)){Logger::error (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x65\x76\x65\x6e\x74\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($action)){
Logger::error (((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x61\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20"
.$eventName)."\x2e"));Logger::stackTrace ();main::nxexit ();}
removeActionFromEvent ($eventName,$action);return ((0x0223+   1-0x0223));}sub 
createNewEvent{(my $eventName=shift (@_));unless (defined ($eventName)){
Logger::error (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x65\x76\x65\x6e\x74\x2e"
);Logger::stackTrace ();main::nxexit ();}Logger::debug (((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x6e\x65\x77\x20\x65\x76\x65\x6e\x74\x20\x27"
.$eventName)."\x27\x2e"));($$event{$eventName}={});}sub removeEvent{(my $eventName
=shift (@_));Common::NXSelector::removeTimestampCallback ($eventName);delete (
$$event{$eventName});Logger::debug (((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x52\x65\x6d\x6f\x76\x65\x64\x20\x65\x76\x65\x6e\x74\x20"
.$eventName)."\x2e"));}sub addActionToEvent{(my $eventName=shift (@_));(my $action
=shift (@_));Logger::debug (((((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x61\x64\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20"
.$action)."\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$eventName)."\x2e"));(
$$event{$eventName}{$action}=(0x0e38+ 3006-0x19f5));}sub removeActionFromEvent{(my $eventName
=shift (@_));(my $action=shift (@_));unless (defined ($eventName)){Logger::error
 (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x65\x76\x65\x6e\x74\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($action)){
Logger::error (((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x61\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20"
.$eventName)."\x2e"));Logger::stackTrace ();main::nxexit ();}Logger::debug (((((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20"
.$action)."\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$eventName)."\x2e"));
delete ($$event{$eventName}{$action});return ((0x03fd+ 5070-0x17ca));}sub 
callActionsForEvent{(my $eventName=shift (@_));foreach my $action (keys (%{
$$event{$eventName};})){if (($action eq "\x70\x65\x72\x69\x6f\x64\x69\x63")){
next;}Logger::debug (((((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6c\x6c\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20"
.$action)."\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$eventName)."\x2e"));&
{$action;}();}}sub callActionsForEventAndRemove{(my $eventName=shift (@_));
foreach my $action (keys (%{$$event{$eventName};})){if (($action eq 
"\x70\x65\x72\x69\x6f\x64\x69\x63")){next;}Logger::debug (((((
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x63\x61\x6c\x6c\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20"
.$action)."\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$eventName)."\x2e"));
if (($action eq 
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x3a\x61\x66\x74\x65\x72\x47\x75\x65\x73\x74\x45\x78\x70\x69\x72\x65\x64"
)){if ($GLOBAL::EnableGuestWipeout){&{$action;}($eventName);}}else{&{$action;}()
;removeActionFromEvent ($eventName,$action);}}}sub createEventOnTime{(my $eventName
=shift (@_));(my $timestamp=shift (@_));unless (defined ($eventName)){
Logger::error (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x65\x76\x65\x6e\x74\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($timestamp)){
Logger::error (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x65\x76\x65\x6e\x74\x20\x6f\x6e\x20\x74\x69\x6d\x65\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($$event{$eventName})){
createNewEvent ($eventName);}Common::NXSelector::addTimestampCallback (
$eventName,$timestamp);}sub createPeriodicEvent{(my $eventName=shift (@_));(my $interval
=shift (@_));unless (defined ($eventName)){Logger::error (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x65\x76\x65\x6e\x74\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($interval)){
Logger::error (
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x65\x76\x65\x6e\x74\x20\x6f\x6e\x20\x74\x69\x6d\x65\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($$event{$eventName})){
createNewEvent ($eventName);}($$event{$eventName}{
"\x70\x65\x72\x69\x6f\x64\x69\x63"}=$interval);
Common::NXSelector::addTimestampCallback ($eventName,(
Common::NXTime::getSecondsSinceEpoch ()+$interval));}sub handleEvent{(my $eventName
=shift (@_));Logger::debug2 (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x65\x76\x65\x6e\x74\x20".$eventName).
"\x2e"));if ($$event{$eventName}{"\x70\x65\x72\x69\x6f\x64\x69\x63"}){
callActionsForEvent ($eventName);Common::NXSelector::addTimestampCallback (
$eventName,(Common::NXTime::getSecondsSinceEpoch ()+$$event{$eventName}{
"\x70\x65\x72\x69\x6f\x64\x69\x63"}));}else{callActionsForEventAndRemove (
$eventName);}}sub createEventOnTimeAndSubscribe{(my $eventName=shift (@_));(my $timestamp
=shift (@_));(my $action=shift (@_));createEventOnTime ($eventName,$timestamp);
subscribe ($eventName,$action);}sub createPeriodicEventAndSubscribe{(my $eventName
=shift (@_));(my $interval=shift (@_));(my $action=shift (@_));
createPeriodicEvent ($eventName,$interval);subscribe ($eventName,$action);}sub 
isEventExist{(my $eventName=shift (@_));if (defined ($$event{$eventName})){
return ((0x1331+ 2427-0x1cab));}return ((0x0470+ 784-0x0780));}"\x3f\x3f\x3f";
