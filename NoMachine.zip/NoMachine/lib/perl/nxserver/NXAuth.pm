############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXAuth::BEGIN{package NXAuth;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXAuth::BEGIN{package NXAuth;no
 warnings;require Exporter;do{"\x45\x78\x70\x6f\x72\x74\x65\x72"->import};}sub 
NXAuth::BEGIN{package NXAuth;no warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"
->import};}sub NXAuth::BEGIN{package NXAuth;no warnings;require Common::NXInfo;
do{"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x49\x6e\x66\x6f"->import};}package 
NXAuth;no warnings;(our (@ISA)="\x45\x78\x70\x6f\x72\x74\x65\x72");(our (@EXPORT
)=("\x67\x65\x74\x4e\x58\x41\x75\x74\x68\x54\x79\x70\x65",
"\x69\x73\x53\x53\x48\x44\x41\x75\x74\x68",
"\x69\x73\x4e\x6f\x74\x53\x53\x48\x44\x41\x75\x74\x68","\x69\x73\x4e\x58\x44",
"\x69\x73\x4e\x6f\x74\x4e\x58\x44",
"\x69\x73\x4e\x6f\x6d\x61\x63\x68\x69\x6e\x65",
"\x69\x73\x53\x79\x73\x74\x65\x6d"));($type=(""));($typeNomachine=
"\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65");($typeSystem="\x73\x79\x73\x74\x65\x6d")
;($typeNXD="\x6e\x78\x64");($salt=(""));($sshConnection=(-(0x0b06+ 5763-0x2188))
);sub init{(my $environmentValue=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (defined (
$environmentValue)){if (($environmentValue ne (""))){setNXD ();}}}sub 
isSSHConnection{if (($sshConnection!=(-(0x0b05+ 1787-0x11ff)))){return (
$sshConnection);}($sshConnection=(0x0dd2+ 2030-0x15c0));(my $env=
libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (defined ($env))
{if (($env ne (""))){($sshConnection=(0x0b69+ 2861-0x1695));}}return (
$sshConnection);}sub initConnectionType{if (isNotNXD ()){if ((defined (
$GLOBAL::LOGGED_USER)and ($GLOBAL::LOGGED_USER ne ("")))){setSystem ();}else{
setNomachine ();}}}sub getNXAuthType{return ($type);}sub isSSHDAuth{if ((defined
 ($GLOBAL::UseSSHAuthentication)and ($GLOBAL::UseSSHAuthentication eq 
"\x65\x6e\x61\x62\x6c\x65\x64"))){return ((0x06ab+ 5947-0x1de5));}else{return (
(0x0783+ 6022-0x1f09));}}sub isNotSSHDAuth{return ((!isSSHDAuth ()));}sub setNXD
{Logger::debug (((
"\x4e\x58\x41\x75\x74\x68\x3a\x20\x53\x65\x74\x20\x74\x79\x70\x65\x20\x27".
$typeNXD)."\x27\x2e"));($type=$typeNXD);}sub isTypeSet{if ((getNXAuthType ()ne 
(""))){return ((0x0b34+ 2808-0x162b));}return ((0x1f56+ 1897-0x26bf));}sub isNXD
{if (($type eq $typeNXD)){return ((0x18fa+ 3286-0x25cf));}return (
(0x1b51+ 449-0x1d12));}sub isNotNXD{return ((!isNXD ()));}sub 
getActiveConnectionPort{if ((isNXD ()eq "\x31")){return (NXNodeInfo::getNxdPort 
());}else{return ($GLOBAL::SSHPort);}}sub setNomachine{if ((not (isTypeSet ())))
{Logger::debug (((
"\x4e\x58\x41\x75\x74\x68\x3a\x20\x53\x65\x74\x20\x74\x79\x70\x65\x20\x27".
$typeNomachine)."\x27\x2e"));($type=$typeNomachine);}}sub isNomachine{if (($type
 eq $typeNomachine)){return ((0x0089+ 6314-0x1932));}return (
(0x04f8+ 7489-0x2239));}sub getTypeNomachine{return ($typeNomachine);}sub 
setSystem{if ((not (isTypeSet ()))){Logger::debug (((
"\x4e\x58\x41\x75\x74\x68\x3a\x20\x53\x65\x74\x20\x74\x79\x70\x65\x20\x27".
$typeSystem)."\x27\x2e"));($type=$typeSystem);}}sub isSystem{if (($type eq 
$typeSystem)){return ((0x04ef+ 4402-0x1620));}return ((0x0de2+ 5391-0x22f1));}
sub getTypeSystem{return ($typeSystem);}sub checkIsSshAvailable{
initConnectionType ();if (isSystem ()){if (NXLicense::isSshFeature ()){if ((not 
(NXSystemDaemons::isSSHEnabledInConfig ()))){Logger::debug (
"\x53\x53\x48\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64"
);return ((0x0dbc+ 5288-0x2263));}}else{Logger::debug (
"\x53\x53\x48\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64"
);return ((0x1c63+ 2665-0x26ca));}}return ((0x101f+ 1350-0x1565));}sub 
NxServerUserSystemAuth{(my $hello_data=shift (@_));($setKnownhostNul=
(0x087d+ 2990-0x142a));(my $helloMessage=(((("\x68\x65\x6c\x6c\x6f\x20".
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_LOGIN_LOGIN})."\x20").$GLOBAL::LOGGED_USER
).("\x20".$hello_data)));(my ($error_msg,$result)=NXServer2Server::execute (
$GLOBAL::MSG_GET_COMMAND,$helloMessage,"\x32\x35\x30",(""),
$GLOBAL::MSG_LOGIN_PASSWORD_AUTH_COOKIE,(""),"\x32\x35\x30",(""),
$GLOBAL::MSG_LOGIN_OK,("")));if ($result){NXMsg::register_error (
"\x4e\x58\x41\x75\x74\x68",
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x75\x74\x68\x6f\x72\x69\x7a\x65",
(0x0c11+ 4032-0x19dd),
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x77\x69\x74\x68\x20\x63\x6f\x6f\x6b\x69\x65"
);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x75\x74\x68\x6f\x72\x69\x7a\x65",
"\x4e\x58\x41\x75\x74\x68");NXShell::handle_command ("\x65\x78\x69\x74");}return
 ((0x12c3+ 1236-0x1797));}sub addCookie{(my $inputfilename=shift (@_));(my $dpyname
=shift (@_));(my $protoname=shift (@_));(my $hexkey=shift (@_));if (((not (
defined ($inputfilename)))or ($inputfilename eq ("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x69\x6e\x70\x75\x74\x20\x66\x69\x6c\x65\x20\x6e\x61\x6d\x65\x2e"
);return ((0x0086+ 3862-0x0f9b));}if (((not (defined ($dpyname)))or ($dpyname eq
 ("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x64\x69\x73\x70\x6c\x61\x79\x2e"
);return ((0x0152+ 3100-0x0d6d));}if (((not (defined ($protoname)))or (
$protoname eq ("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x70\x72\x6f\x74\x6f\x6e\x61\x6d\x65\x2e"
);return ((0x033a+ 4198-0x139f));}if (((not (defined ($hexkey)))or ($hexkey eq 
("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x68\x65\x78\x6b\x65\x79\x2e"
);return ((0x1863+ 848-0x1bb2));}(my $returnValue=libnxh::NXAddCookie (
$inputfilename,$dpyname,$protoname,$hexkey));if (($returnValue!=
(0x0191+ 2663-0x0bf8))){(my $errorInt=libnxh::NXGetError ());(my $errorString=
libnxh::NXGetErrorString ());Logger::warning (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x43\x6f\x6f\x6b\x69\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x63\x6f\x64\x65\x20\x5b"
.$errorInt)."\x5d\x20\x5b").$errorString)."\x5d"));}return ($returnValue);}sub 
isKnowHostSet{if ((defined ($setKnownhostNul)and ($setKnownhostNul==
(0x0721+ 6238-0x1f7e)))){return ((0x1f5c+ 735-0x223a));}return (
(0x071a+ 6270-0x1f98));}sub generateSalt{Logger::debug (
"\x47\x65\x6e\x65\x72\x61\x74\x69\x6e\x67\x20\x73\x61\x6c\x74\x2e");($salt=
main::get_unique_id ());}sub getSalt{return ($salt);}return (
(0x063f+ 4493-0x17cb));
