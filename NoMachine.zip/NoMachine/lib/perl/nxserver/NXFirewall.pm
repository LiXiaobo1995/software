############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXFirewall::BEGIN{package NXFirewall;no warnings;require NXTools;do{
"\x4e\x58\x54\x6f\x6f\x6c\x73"->import};}package NXFirewall;no warnings;(
$checkUfwCommand=(-(0x1181+ 891-0x14fb)));($oldUfwCommand=(0x0259+ 6773-0x1cce))
;sub addFirewallRules{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x73\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2e"
);if (($GLOBAL::EnableFirewallConfiguration==(0x09a5+ 2912-0x1505))){
Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x0587+ 5204-0x19db));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x04af+ 4035-0x1472))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x73\x2e"
);return ((0x011d+ 6418-0x1a2f));}(my $tcpPorts=(""));(my $udpPorts=(""));if ((
NXSystemDaemons::isNxdEnabled ()and NXSystemDaemons::isNxdStartupKeyEnabled ()))
{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x4e\x58\x44\x20\x72\x75\x6c\x65\x73\x2e"
);($tcpPorts.=(NXNodeInfo::getNxdPort ()."\x2c"));($udpPorts.=(
NXNodeInfo::getNxdUDPPort ()."\x2c"));}else{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x4e\x6f\x74\x20\x61\x64\x64\x69\x6e\x67\x20\x4e\x58\x44\x20\x72\x75\x6c\x65\x2e"
);}if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){(my $httpsPort=
NXTools::getNXHtdPort ());Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x48\x54\x54\x50\x53\x20\x72\x75\x6c\x65\x2e"
);($tcpPorts.=($httpsPort."\x2c"));}else{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x4e\x6f\x74\x20\x61\x64\x64\x69\x6e\x67\x20\x4e\x58\x48\x54\x44\x20\x72\x75\x6c\x65\x2e"
);}if (NXLocate::isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x6d\x44\x4e\x53\x20\x72\x75\x6c\x65\x2e"
);($udpPorts.=($GLOBAL::MSDNPort."\x2c"));(my $returnValue=__addRule ((
\@firewallStatus),$ref_iptablesV6,$GLOBAL::MSDNPort,"\x75\x64\x70"));if ((
$returnValue==(0x1a78+ 1834-0x21a2))){__saveAddedRule ($GLOBAL::MSDNPort,
"\x75\x64\x70");}}else{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x4e\x6f\x74\x20\x61\x64\x64\x69\x6e\x67\x20\x6d\x44\x4e\x53\x20\x72\x75\x6c\x65\x2e"
);}if (($tcpPorts ne (""))){($tcpPorts=~ s/,$// );(my $returnValue=__addRule ((
\@firewallStatus),$ref_iptablesV6,$tcpPorts,"\x74\x63\x70"));if (($returnValue==
(0x0d9b+ 2668-0x1807))){__saveAddedRule ($tcpPorts,"\x74\x63\x70");}}if ((
$udpPorts ne (""))){($udpPorts=~ s/,$// );(my $returnValue=__addRule ((
\@firewallStatus),$ref_iptablesV6,$udpPorts,"\x75\x64\x70"));if (($returnValue==
(0x0a2c+ 2975-0x15cb))){__saveAddedRule ($udpPorts,"\x75\x64\x70");}}}sub 
__checkFirewallInstall{if (((Common::NXShellCommands::isApplicationInKnownPath (
"\x69\x70\x74\x61\x62\x6c\x65\x73\x2d\x78\x6d\x6c")or 
Common::NXShellCommands::isApplicationInKnownPath (
"\x69\x70\x74\x61\x62\x6c\x65\x73"))or 
Common::NXShellCommands::isApplicationInKnownPath (
"\x69\x70\x36\x74\x61\x62\x6c\x65\x73"))){return ((0x081a+ 5695-0x1e58));}else{
return ((0x1027+ 5097-0x2410));}}sub __checkUfw{if (($checkUfwCommand!=(-
(0x0b33+ 1746-0x1204)))){return ($checkUfwCommand);}if ((not ((lc (
Common::NXInfo::getDistroInfo ())=~ /ubuntu/ )))){($checkUfwCommand=
(0x1560+ 1811-0x1c73));return ((0x1227+ 2069-0x1a3c));}Logger::debug (
"\x53\x65\x74\x20\x27\x75\x66\x77\x27\x20\x61\x73\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e"
);($checkUfwCommand=(0x10b8+ 3343-0x1dc6));if ((lc (
Common::NXInfo::getDistroInfo ())=~ /ubuntu 8.04|ubuntu 8.10|ubuntu 9.04/ )){
Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6f\x6c\x64\x20\x27\x75\x66\x77\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e"
);($oldUfwCommand=(0x09b2+ 6806-0x2447));}return ((0x0426+ 509-0x0622));}sub 
__checkFirewalldInstall{if (Common::NXShellCommands::isApplicationInKnownPath (
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64")){return (
(0x12f2+ 378-0x146b));}else{return ((0x00ba+ 4338-0x11ac));}}sub 
__getFirewalldStatus{Logger::debug (
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x2e"
);(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ("\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64")
);push (@command,"\x2d\x2d\x7a\x6f\x6e\x65\x3d\x70\x75\x62\x6c\x69\x63");push (
@command,"\x2d\x2d\x6c\x69\x73\x74\x2d\x70\x6f\x72\x74\x73");}else{push (
@command,$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x67\x65\x74\x2e\x73\x68");push
 (@command,"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64",
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64",(0x0c8f+ 3633-0x1ac0));push (
@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x03a8+ 3538-0x117a))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
.$exit_value)."\x27\x2e").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));return ((0x0ae1+ 1001-0x0eca));}Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x2d\x2d\x6c\x69\x73\x74\x2d\x70\x6f\x72\x74\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));return (split ( / / ,$cmd_out,(0x1508+ 1692-0x1ba4)));}
sub __getFirewallStatus{(my $ref_iptablesV6=shift (@_));if (__checkUfw ()){
return (__getUfw ());}elsif (__checkFirewalldInstall ()){return (
__getFirewalldStatus ());}elsif (__checkFirewallInstall ()){(my (@iptablesV6)=
__getIptablesV6 ("\x49\x4e\x50\x55\x54"));($$ref_iptablesV6=(\@iptablesV6));
return (__getIptables ("\x49\x4e\x50\x55\x54"));}}sub __getUfw{Logger::debug (
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x75\x66\x77\x20\x73\x74\x61\x74\x75\x73\x2e"
);(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ("\x75\x66\x77"));push (@command,
"\x73\x74\x61\x74\x75\x73");if (($oldUfwCommand==(0x0c98+ 475-0x0e72))){push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",
"\x50\x41\x54\x48\x3d\x2f\x73\x62\x69\x6e");}}else{push (@command,
$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x67\x65\x74\x2e\x73\x68");push (
@command,"\x75\x66\x77","\x75\x66\x77");if (($oldUfwCommand==
(0x1e78+ 1415-0x23fe))){push (@command,(0x1771+ 1922-0x1ef2));}else{push (
@command,(0x024d+ 125-0x02ca));}push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x0550+ 4184-0x15a8))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x75\x66\x77\x20\x73\x74\x61\x74\x75\x73\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
.$exit_value)."\x27\x2e").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));return ((0x1531+ 2270-0x1e0f));}Logger::debug2 (((
"\x55\x66\x77\x20\x73\x74\x61\x74\x75\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));return (split ( /\n/ ,$cmd_out,(0x09c4+ 3668-0x1818)));}
sub __getIptablesV6{return (__getIptables (@_,(0x11ed+ 2558-0x1bea)));}sub 
__getIptables{(my $chain=shift (@_));(my $IPv6=(shift (@_)||
(0x099b+ 3391-0x16da)));(my $name="\x69\x70\x74\x61\x62\x6c\x65\x73");if (($IPv6
==(0x0d5b+ 4413-0x1e97))){($name="\x69\x70\x36\x74\x61\x62\x6c\x65\x73");}(my (
@command)=());(my (@parameters)=());if (main::effectiveUserIsAdministrator ()){
push (@command,NXTools::getUnixCommandPath ($name));push (@command,"\x2d\x4c",
$chain,"\x2d\x2d\x6c\x69\x6e\x65\x2d\x6e\x75\x6d\x62\x65\x72\x73",
"\x2d\x2d\x6e\x75\x6d\x65\x72\x69\x63");}else{push (@command,
$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x67\x65\x74\x2e\x73\x68");push (
@command,$name,$chain,(0x0092+ 8636-0x224e));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x1f63+ 1524-0x2557))){Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20".$name).
"\x20\x73\x74\x61\x74\x75\x73\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));return (undef);}return (split ( /\n/ ,$cmd_out,(0x03fb+ 7677-0x21f8)));}sub 
__checkFirewallStatus{(my ($ref_firewallStatus,$ref_iptablesV6)=@_);if ((
$ref_firewallStatus eq (""))){Logger::error (((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x73\x74\x61\x74\x75\x73\x20\x27".
$ref_firewallStatus).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"));
return ((0x0fd2+ 148-0x1065));}Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x73\x74\x61\x74\x75\x73\x3a\x20\x27"
.$$ref_firewallStatus[(0x1241+ 3824-0x2131)])."\x27\x2e"));if (__checkUfw ()){(
$$ref_firewallStatus[(0x1708+ 2040-0x1f00)]=~ s/^\s+|\s+$//g );if ((((
$$ref_firewallStatus[(0x1135+ 5388-0x2641)]=~ /^Status: inactive$/ )or (
$$ref_firewallStatus[(0x0669+ 3154-0x12bb)]=~ /^Firewall not loaded$/ ))or (
$$ref_firewallStatus[(0x122c+ 1407-0x17ab)]=~ /^Status: not loaded$/ ))){return 
((0x0bc9+ 3563-0x19b4));}else{return ((0x0675+ 7299-0x22f7));}}elsif (
__checkFirewalldInstall ()){($$ref_firewallStatus[(0x0292+ 4452-0x13f6)]=~ s/^\s+|\s+$//g )
;if (($$ref_firewallStatus[(0x0930+ 3695-0x179f)]=~ /^FirewallD is not running$/ )
){return ((0x08e0+ 3444-0x1654));}else{return ((0x0212+ 1329-0x0742));}}else{(my $number
=__getRuleNr ($ref_firewallStatus));if ((($number==(0x01bf+ 8224-0x21df))and 
defined (@$ref_firewallStatus))){return ((0x1588+ 1633-0x1be8));}else{($number=
__getRuleNrIPv6 ($ref_iptablesV6));if ((($number==(0x0aca+ 3622-0x18f0))and 
defined ($ref_iptablesV6))){return ((0x0bc4+ 5877-0x22b8));}}return ($number);}}
sub __getRuleNrIPv6{return (__getRuleNr (@_,(0x0c77+ 1085-0x10b3)));}sub 
__getRuleNr{(my $ref_firewallStatus=shift (@_));(my $IPv6=(shift (@_)||
(0x0ee5+ 3250-0x1b97)));foreach my $rule (@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g )
;if (($rule=~ /^(\d+)\s+(\w+)\s+(\w+)\s+(.*)$/ )){(my $num=$1);(my $target=$2);(my $prot
=$3);(my $rest=$4);(my (@additionalOptions)=split ( / {1,}/ ,$rest,
(0x069b+ 3596-0x14a7)));if ((((($target eq "\x52\x45\x4a\x45\x43\x54")and ($prot
 eq "\x61\x6c\x6c"))and ($additionalOptions[(0x0465+ 8146-0x2434)]eq ("")))or ((
($target eq "\x44\x52\x4f\x50")and ($prot eq "\x61\x6c\x6c"))and (
$additionalOptions[(0x0791+ 3053-0x137b)]eq (""))))){return ($num);}if (($target
=~ /[a-z]/ )){my (@newChainToCheck);if (($IPv6==(0x0229+ 561-0x045a))){(
@newChainToCheck=__getIptables ($target));}else{(@newChainToCheck=
__getIptablesV6 ($target));}(my ($number,$chain)=__getRuleNr ((\@newChainToCheck
),$IPv6));if (($number!=(0x0b73+ 5403-0x208e))){return ($num);}}}elsif (($rule=~ /^(\d+)\s+(\w+)\s+(.*)$/ )
){(my $num=$1);(my $prot=$2);(my $rest=$3);(my (@additionalOptions)=split ( / {1,}/ ,
$rest,(0x0214+ 5939-0x1947)));if ((($prot eq "\x61\x6c\x6c")and (
$additionalOptions[(0x0135+ 8977-0x2443)]eq ("")))){return ($num);}}}return (
(0x00b4+ 2213-0x0959));}sub __addRule{(my $ref_firewallStatus=shift (@_));(my $ref_iptablesV6
=shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));(my $sessionRule=
shift (@_));if (((($ref_firewallStatus eq (""))or ($ports eq ("")))or ($proto eq
 ("")))){Logger::error (((((((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x73\x74\x61\x74\x75\x73\x20\x27".
$ref_firewallStatus)."\x27\x2c\x20\x70\x6f\x72\x74\x73\x20\x27").$ports).
"\x27\x20\x6f\x72\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$proto).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"));
return ((0x0ccb+ 730-0x0fa4));}if (__checkUfw ()){if (__allRulesAreSetUfw (
$ref_firewallStatus,$ports,$proto)){return ((0x1630+ 3962-0x25a9));}}elsif (
__checkFirewalldInstall ()){if (__allRulesAreSetFirewalld ($ref_firewallStatus,
$ports,$proto)){return ((0x0323+ 1275-0x081d));}}else{if (__ruleIsSetIptables (
$ref_firewallStatus,$ports,$proto)){if (__ruleIsSetIptables ($ref_iptablesV6,
$ports,$proto)){return ((0x1c6c+ 2445-0x25f8));}}}if (($sessionRule ne 
"\x73\x65\x73\x73\x69\x6f\x6e\x52\x75\x6c\x65")){if (__isRuleInFile ($ports,
$proto)){__removeRuleFromFile ($ports,$proto);}}if (__checkUfw ()){return (
__addRuleByUfw ($ports,$proto));}elsif (__checkFirewalldInstall ()){return (
__addRuleByFirewalld ($ports,$proto));}elsif (__checkFirewallInstall ()){(my $return
=__addRuleByIptables ($ref_firewallStatus,$ports,$proto));(my $returnV6=
__addRuleByIptablesV6 ($ref_iptablesV6,$ports,$proto));if (($return and 
$returnV6)){return ((0x0a86+ 5234-0x1ef7));}return ((0x053c+ 5864-0x1c24));}}sub
 __ruleIsNotSetFirewalld{(my $ref_firewallStatus=shift (@_));(my $ports=shift (
@_));(my $proto=shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));(my (@portsTab)=split ( /,/ ,
$ports,(0x1193+ 4139-0x21be)));foreach my $port (@portsTab){foreach my $rule (
@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq (($port."\x2f").
$proto))){Logger::debug (((((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));return 
((0x1727+ 2104-0x1f5f));}}}Logger::debug (((((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x27").$proto).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x1880+ 3353-0x2598));}sub __allRulesAreSetFirewalld{(my $ref_firewallStatus=
shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));(my (@portsTab)=split 
( /,/ ,$ports,(0x07ac+ 4099-0x17af)));(my $portsCount=@portsTab);(my $isRuleSet=
(0x01d8+ 1493-0x07ad));foreach my $port (@portsTab){foreach my $rule (
@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq (""))){next;}
Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$port)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));if (($rule eq (($port."\x2f").
$proto))){Logger::debug (((((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));(++
$isRuleSet);last;}}}Logger::debug (((((
"\x46\x6f\x75\x6e\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20"
.$isRuleSet)."\x2f").$portsCount)."\x2e"));if (($isRuleSet>=$portsCount)){
Logger::debug (((
"\x41\x6c\x6c\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x61\x72\x65\x20\x73\x65\x74\x2e"));return (
(0x0b30+ 945-0x0ee0));}Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x17f7+ 164-0x189b));}sub __ruleIsSetFirewalld{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));return ((!
__ruleIsNotSetFirewalld ($ref_firewallStatus,$ports,$proto)));}sub 
__allRulesAreSetUfw{(my $ref_firewallStatus=shift (@_));(my $ports=shift (@_));(my $proto
=shift (@_));(my (@portsTab)=split ( /,/ ,$ports,(0x14e4+ 3734-0x237a)));(my $portsCount
=@portsTab);(my $isRuleSet=(0x1808+ 1778-0x1efa));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));foreach my $port (@portsTab){
foreach my $rule (@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq 
(""))){next;}Logger::debug2 (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x3a\x20\x27"
.$rule)."\x27\x2e"));if ((($rule=~ /^([\w,]+)[\/:](\w+) \(v6\)\s+(\w+)\s+(.*)$/ )
or ($rule=~ /^([\w,]+)[\/:](\w+)\s+(\w+)\s+(.*)$/ ))){(my $f_port=$1);(my $f_proto
=$2);(my $f_allow=$3);if ((($f_proto ne $proto)or ($f_allow ne 
"\x41\x4c\x4c\x4f\x57"))){next;}if (($f_port eq $port)){Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".
$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));(++
$isRuleSet);last;}}}}if (($portsCount>(0x1462+ 546-0x1683))){Logger::debug (((((
"\x46\x6f\x75\x6e\x64\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20"
.$isRuleSet)."\x2f").$portsCount)."\x2e"));}if (($isRuleSet>=$portsCount)){if ((
$portsCount>(0x0449+ 5507-0x19cb))){Logger::debug (((
"\x41\x6c\x6c\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x61\x72\x65\x20\x73\x65\x74\x2e"));}return (
(0x0cf5+ 1901-0x1461));}Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x27").$proto).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x0c43+ 1134-0x10b1));}sub __ruleIsSetUfw{(my $ref_firewallStatus=shift (@_));(my $ports
=shift (@_));(my $proto=shift (@_));return ((!__ruleIsNotSetUfw (
$ref_firewallStatus,$ports,$proto)));}sub __ruleIsNotSetUfw{(my $ref_firewallStatus
=shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));(my (@portsTab)=split
 ( /,/ ,$ports,(0x0f08+ 4332-0x1ff4)));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));foreach my $rule (
@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq (""))){next;}if ((
($rule=~ /^([\w\/,:]+) \(v6\)\s+(\w+)\s+(.*)$/ )or ($rule=~ /^([\w\/,:]+)\s+(\w+)\s+(.*)$/ )
)){foreach my $port (@portsTab){if (((($1 eq (($port."\x2f").$proto))and ($2 eq 
"\x41\x4c\x4c\x4f\x57"))or (($1 eq (($port."\x3a").$proto))and ($2 eq 
"\x41\x4c\x4c\x4f\x57")))){Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".
$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));return (
(0x0acb+ 2280-0x13b3));}}}}Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x27").$proto).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x178c+ 1906-0x1efd));}sub __ruleIsSetIptables{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));return ((!
__ruleIsNotSetIptables ($ref_firewallStatus,$ports,$proto)));}sub 
__ruleIsNotSetIptables{(my $ref_firewallStatus=shift (@_));(my $ports=shift (@_)
);(my $proto=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$ports)."\x27\x2e"));foreach my $rule (@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g )
;if (($rule=~ /^(\d+)\s+(\w+)\s+(\w+)\s+(.*)$/ )){if (((($2 eq 
"\x41\x43\x43\x45\x50\x54")and ($3 eq $proto))and ($4=~ /multiport dports $ports$/ )
)){Logger::debug (((((
"\x52\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".$ports).
"\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));return (
(0x0c8b+ 5985-0x23ec));}}}Logger::debug (((((
"\x52\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".$ports).
"\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"))
;return ((0x1980+ 2682-0x23f9));}sub __addRuleByFirewalld{(my $ports=shift (@_))
;(my $proto=shift (@_));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20"
.$ports)."\x2e"));(my (@command)=());(my (@parameters)=());if ((
main::effectiveUserIsAdministrator ()and (not (($ports=~ /,/ ))))){push (
@command,NXTools::getUnixCommandPath (
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64"));push (@command,
"\x2d\x2d\x7a\x6f\x6e\x65\x3d\x70\x75\x62\x6c\x69\x63");push (@command,(((
"\x2d\x2d\x61\x64\x64\x2d\x70\x6f\x72\x74\x3d".$ports)."\x2f").$proto));}else{
push (@command,$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x61\x64\x64\x2e\x73\x68"
);push (@command,"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64");push (
@command,$ports);push (@command,$proto);push (@command,(0x0864+ 6582-0x221a),
(0x0aa5+ 1973-0x125a));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x61\x64\x64\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x1556+ 875-0x18c1))){Logger::warning
 ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$ports).
"\x20\x77\x69\x74\x68\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20"
).$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __addRuleByUfw{(my $ports=shift (@_));(my $proto=
shift (@_));(my (@portsTab)=split ( /,/ ,$ports,(0x0336+ 6142-0x1b34)));(my $ret
=(0x0902+ 3297-0x15e3));foreach my $port (@portsTab){($ret=__addSingleRuleByUfw 
($port,$proto));}return ($ret);}sub __addSingleRuleByUfw{(my $port=shift (@_));(my $proto
=shift (@_));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x3a\x20\x27"
.$port)."\x27\x2e"));(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ("\x75\x66\x77"));push (@command,
"\x61\x6c\x6c\x6f\x77");push (@command,"\x70\x72\x6f\x74\x6f",$proto);push (
@command,"\x66\x72\x6f\x6d","\x61\x6e\x79","\x74\x6f","\x61\x6e\x79");push (
@command,"\x70\x6f\x72\x74",$port);if (($oldUfwCommand==(0x1ebd+ 712-0x2184))){
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",
"\x50\x41\x54\x48\x3d\x2f\x73\x62\x69\x6e");}}else{push (@command,
$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x61\x64\x64\x2e\x73\x68");push (
@command,"\x75\x66\x77");push (@command,$port);push (@command,$proto);push (
@command,(0x1238+ 1354-0x1782));if (($oldUfwCommand==(0x070a+ 6504-0x2071))){
push (@command,(0x09c8+ 6113-0x21a8));}else{push (@command,(0x17d6+ 2411-0x2141)
);}push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x75\x66\x77\x20\x61\x64\x64\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x15d2+ 2446-0x1f60))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$port).
"\x20\x77\x69\x74\x68\x20\x75\x66\x77\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20").
$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __addRuleByIptablesV6{__addRuleByIptables (@_,
(0x002f+ 4772-0x12d2));}sub __addRuleByIptables{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));(my $IPv6=(shift (@_)||
(0x0d0d+ 3133-0x194a)));(my $name="\x69\x70\x74\x61\x62\x6c\x65\x73");if (($IPv6
==(0x0ccd+ 2699-0x1757))){($name="\x69\x70\x36\x74\x61\x62\x6c\x65\x73");if ((
$ref_firewallStatus eq (""))){return ((0x0385+ 4135-0x13ab));}}Logger::debug (((
((((
"\x41\x64\x64\x69\x6e\x67\x20\x69\x70\x74\x61\x62\x6c\x65\x73\x20\x72\x75\x6c\x65\x20\x62\x79\x20"
.$name)."\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20").$ports).
"\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x20").$proto)."\x2e"));(my ($ruleNr,
$chain)=__getRuleNr ($ref_firewallStatus));if (($chain eq (""))){($chain=
"\x49\x4e\x50\x55\x54");}if ((($ruleNr==(0x0f31+ 5977-0x268a))and defined (
@$ref_firewallStatus))){($ruleNr=(0x0249+ 5696-0x1888));}if (($ruleNr==
(0x0289+ 1116-0x06e5))){Logger::debug (
"\x4e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x72\x65\x6a\x65\x63\x74\x2f\x64\x72\x6f\x70\x2f\x69\x6e\x70\x75\x74\x5f\x65\x78\x74\x20\x69\x70\x74\x61\x62\x6c\x65\x73\x20\x72\x75\x6c\x65\x2e"
);return ((0x0b65+ 2068-0x1378));}(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ($name));push (@command,"\x2d\x49",$chain,$ruleNr);
push (@command,"\x2d\x70",$proto);push (@command,"\x2d\x2d\x6d\x61\x74\x63\x68",
"\x6d\x75\x6c\x74\x69\x70\x6f\x72\x74");push (@command,
"\x2d\x2d\x64\x70\x6f\x72\x74\x73",$ports);push (@command,"\x2d\x6a",
"\x41\x43\x43\x45\x50\x54");}else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x61\x64\x64\x2e\x73\x68");push (@command,$name);push (@command
,$ports);push (@command,$proto);push (@command,$ruleNr);push (@command,
(0x11c0+ 4909-0x24ed));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x0bf9+ 4346-0x1cf3))){Logger::warning ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports)."\x27\x20\x77\x69\x74\x68\x20\x27").$name).
"\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub delFirewallRules{Logger::debug (
"\x44\x65\x6c\x65\x74\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x73\x2e"
);(my (@rules)=__getFirewallRules ());if ((scalar (@rules)==
(0x16a1+ 2147-0x1f04))){Logger::debug (
"\x4e\x6f\x20\x72\x75\x6c\x65\x73\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65\x2e");
return ((0x0a0c+ 7380-0x26e0));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x0699+ 7892-0x256d))){Logger::debug (((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x73\x3a\x20"
.join ($",@rules))."\x2e"));return ((0x1a11+ 1913-0x218a));}foreach my $rule (
@rules){(my ($ports,$proto)=split ( /:/ ,$rule,(0x06ed+ 3209-0x1373)));__delRule
 ((\@firewallStatus),$ref_iptablesV6,$ports,$proto);if (__isRuleInFile ($ports,
$proto)){__removeRuleFromFile ($ports,$proto);}}}sub __getFirewallRules{(my (
@ports)=());(my $filename=__getFirewallFile ());if ((not (
Common::NXFile::isExists ($filename)))){return (@ports);}(my $FILE=main::nxopen 
($filename,$NXBits::O_RDONLY,(0x0da8+ 5748-0x241c)));if ((not (defined ($FILE)))
){return (@ports);}while (main::nxreadLine ($FILE,(\$_))){($line=$_);if (($line
=~ /^Added exception for port: (.*)$/ )){push (@ports,$1);}}main::nxclose ($FILE
);return (@ports);}sub __delRule{(my $ref_firewallStatus=shift (@_));(my $ref_iptablesV6
=shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));if ((($ports eq (""))
or ($proto eq ("")))){Logger::error ((((("\x50\x6f\x72\x74\x20\x27".$ports).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$proto).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"));
return ((0x1700+  49-0x1730));}if (__checkUfw ()){__delRuleByUfw (
$ref_firewallStatus,$ports,$proto);}elsif (__checkFirewalldInstall ()){return (
__delRuleByFirewalld ($ref_firewallStatus,$ports,$proto));}elsif (
__checkFirewallInstall ()){__delRuleByIftables ($ref_firewallStatus,$ports,
$proto);__delRuleByIftablesV6 ($ref_iptablesV6,$ports,$proto);}}sub 
__delRuleByFirewalld{(my $ref_firewallStatus=shift (@_));(my $ports=shift (@_));
(my $proto=shift (@_));Logger::debug (((((
"\x44\x65\x6c\x65\x74\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$ports)."\x27\x20\x77\x69\x74\x68\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27")
.$proto)."\x27\x2e"));if (__ruleIsNotSetFirewalld ($ref_firewallStatus,$ports,
$proto)){Logger::debug (((((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$proto)."\x20").$ports).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x2e"
));return ((0x0077+ 5836-0x1743));}(my (@command)=());(my (@parameters)=());if (
(main::effectiveUserIsAdministrator ()and (not (($ports=~ /,/ ))))){push (
@command,NXTools::getUnixCommandPath (
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64"));push (@command,
"\x2d\x2d\x7a\x6f\x6e\x65\x3d\x70\x75\x62\x6c\x69\x63");push (@command,(((
"\x2d\x2d\x72\x65\x6d\x6f\x76\x65\x2d\x70\x6f\x72\x74\x3d".$ports)."\x2f").
$proto));}else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x64\x65\x6c\x2e\x73\x68");push (@command,
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64");push (@command,$ports);push 
(@command,$proto);push (@command,(0x16ad+ 906-0x1a37));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x65\x6d\x6f\x76\x65\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x1983+ 1077-0x1db8))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports).
"\x27\x20\x77\x69\x74\x68\x20\x27\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
).$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __delRuleByUfw{(my $ref_firewallStatus=shift (@_))
;(my $ports=shift (@_));(my $proto=shift (@_));if (__ruleIsNotSetUfw (
$ref_firewallStatus,$ports,$proto)){Logger::debug (((((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$proto)."\x20").$ports).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x2e"
));return ((0x09f3+ 5698-0x2035));}(my (@portsTab)=split ( /,/ ,$ports,
(0x1023+ 4468-0x2197)));(my $ret=(0x1692+ 159-0x1731));foreach my $port (
@portsTab){Logger::debug (((((
"\x44\x65\x6c\x65\x74\x69\x6e\x67\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x77\x69\x74\x68\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").
$proto)."\x27\x2e"));($ret=__delSingleRuleByUfw ($port,$proto));}return ($ret);}
sub __delSingleRuleByUfw{(my $ports=shift (@_));(my $proto=shift (@_));(my (
@command)=());(my (@parameters)=());if (main::effectiveUserIsAdministrator ()){
push (@command,NXTools::getUnixCommandPath ("\x75\x66\x77"));push (@command,
"\x64\x65\x6c\x65\x74\x65","\x61\x6c\x6c\x6f\x77");push (@command,
"\x70\x72\x6f\x74\x6f",$proto);push (@command,"\x66\x72\x6f\x6d","\x61\x6e\x79",
"\x74\x6f","\x61\x6e\x79");push (@command,"\x70\x6f\x72\x74",$ports);if ((
$oldUfwCommand==(0x0ff5+ 5776-0x2684))){push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76","\x50\x41\x54\x48\x3d\x2f\x73\x62\x69\x6e");}}
else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x64\x65\x6c\x2e\x73\x68");push (@command,"\x75\x66\x77");push 
(@command,$ports);push (@command,$proto);if (($oldUfwCommand==
(0x008b+ 2784-0x0b6a))){push (@command,(0x0628+ 4590-0x1815));}else{push (
@command,(0x1844+ 1840-0x1f74));}push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x75\x66\x77\x20\x72\x65\x6d\x6f\x76\x65\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x0505+ 4935-0x184c))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports).
"\x27\x20\x77\x69\x74\x68\x20\x27\x75\x66\x77\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
).$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __delRuleByIftablesV6{__delRuleByIftables (@_,
(0x06ea+ 8065-0x266a));}sub __delRuleByIftables{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));(my $IPv6=(shift (@_)||
(0x0bd1+ 5486-0x213f)));(my $name="\x69\x70\x74\x61\x62\x6c\x65\x73");if (($IPv6
==(0x0c38+ 173-0x0ce4))){($name="\x69\x70\x36\x74\x61\x62\x6c\x65\x73");if ((
$ref_firewallStatus eq (""))){return ((0x0088+ 2008-0x085f));}}Logger::debug (((
(((("\x44\x65\x6c\x65\x74\x69\x6e\x67\x20".$name).
"\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27").$ports).
"\x27\x20\x61\x6e\x64\x20\x27").$proto)."\x27\x2e"));if ((__ruleIsNotSetIptables
 ($ref_firewallStatus,$ports,$proto)==(0x0e21+ 6140-0x261c))){Logger::debug ((((
((("\x46\x69\x72\x65\x77\x61\x6c\x6c\x20".$name).
"\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20").$proto)."\x20").$ports).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x2e"
));return ((0x1ae4+ 1450-0x208e));}(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ($name));push (@command,"\x2d\x44",
"\x49\x4e\x50\x55\x54");push (@command,"\x2d\x70",$proto);push (@command,
"\x2d\x2d\x6d\x61\x74\x63\x68","\x6d\x75\x6c\x74\x69\x70\x6f\x72\x74");push (
@command,"\x2d\x2d\x64\x70\x6f\x72\x74\x73",$ports);push (@command,"\x2d\x6a",
"\x41\x43\x43\x45\x50\x54");}else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x64\x65\x6c\x2e\x73\x68");push (@command,$name);push (@command
,$ports);push (@command,$proto);push (@command,(0x082b+ 1235-0x0cfe));push (
@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x0d5d+ 2467-0x1700))){Logger::warning ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports)."\x27\x20\x77\x69\x74\x68\x20\x27").$name).
"\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __getFirewallFile{(my $path=$GLOBAL::VAR_ROOT);(
$path.=($GLOBAL::DIRECTORY_SLASH."\x64\x62"));($path.=($GLOBAL::DIRECTORY_SLASH.
"\x73\x65\x72\x76\x65\x72"));($path.=($GLOBAL::DIRECTORY_SLASH.
"\x66\x69\x72\x65\x77\x61\x6c\x6c"));return ($path);}sub __saveAddedRule{(my $port
=shift (@_));(my $proto=shift (@_));(my $filename=__getFirewallFile ());(my $FH=
main::nxopen ($filename,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND)
,$NXBits::UserReadWrite));if ((not (defined ($FH)))){return (
(0x17e8+ 392-0x196f));}(my $ruleEntry=((((
"\x41\x64\x64\x65\x64\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x3a\x20"
.$port)."\x3a").$proto)."\x0a"));if ((main::nxwrite ($FH,$ruleEntry)==(-
(0x1417+ 494-0x1604)))){main::nxclose ($FH);return ((0x09f7+ 6418-0x2308));}
main::nxclose ($FH);my ($errorName);my ($errorCode);if ((
Common::NXFile::setOwnershipForUserNXSilent ($filename,(\$errorName),(
\$errorCode))==(-(0x1776+ 212-0x1849)))){Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e\x20").$errorCode)."\x20").$errorName));return (
(0x0f33+ 4046-0x1f00));}}sub __isRuleInFile{(my $port=shift (@_));(my $proto=
shift (@_));(my $filename=__getFirewallFile ());if ((not (
Common::NXFile::isExists ($filename)))){return ((0x2484+ 142-0x2512));}(my $FILE
=main::nxopen ($filename,$NXBits::O_RDONLY,(0x0744+ 3963-0x16bf)));if ((not (
defined ($FILE)))){return ((0x1755+ 1751-0x1e2c));}while (main::nxreadLine (
$FILE,(\$_))){($line=$_);if (($line=~ /^Added exception for port: $port:$proto$/ )
){main::nxclose ($FILE);return ((0x11cd+ 836-0x1510));}}main::nxclose ($FILE);
return ((0x0039+ 3777-0x0efa));}sub __removeRuleFromFile{(my $ports=shift (@_));
(my $proto=shift (@_));Logger::debug (((((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20"
.$ports)."\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20").$proto).
"\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x2e"));(my $filename=__getFirewallFile
 ());(my $tmp=(($filename."\x2e\x74\x6d\x70\x2e").$ $));
 (my $FILE=main::nxopen
 ($filename,$NXBits::O_RDONLY,(0x1090+ 985-0x1469)));if ((not (defined ($FILE)))
){return ((0x03f5+ 6360-0x1ccc));}(my $TEMP_FILE=main::nxopen ($tmp,((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND),$NXBits::UserReadWrite));
if ((not (defined ($TEMP_FILE)))){main::nxclose ($FILE);return (
(0x2084+ 370-0x21f5));}(my $flagDel=(0x03e1+ 3563-0x11cb));while (
main::nxreadLine ($FILE,(\$_))){(my $line=$_);if (($line=~ /^Added exception for port: $ports:$proto$/ )
){($flagDel=(0x1106+ 1064-0x152e));}else{main::nxwrite ($TEMP_FILE,$line);}}
main::nxclose ($TEMP_FILE);main::nxclose ($FILE);if ((not (rename ($tmp,
$filename)))){Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x3a\x20\x27"
.$tmp)."\x27\x20\x6f\x6e\x20\x27").$filename)."\x27\x20").$!));}my ($error);if (
(Common::NXFile::setOwnershipForUserNXSilent ($filename,(\$error))==(-
(0x135f+ 4366-0x246c)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x20").$error)."\x2e"));return ((0x08c4+ 1655-0x0f3a));}return 
($flag_del);}sub addFirewallUdpPort{(my $port=shift (@_));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x75\x64\x70\x20\x72\x75\x6c\x65\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));if (($GLOBAL::EnableFirewallConfiguration==
(0x21c0+ 725-0x2495))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x21a8+ 1178-0x2642));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x0bef+ 5297-0x20a0))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x2e"
);return ((0x17d7+ 1545-0x1de0));}(my $returnValue=__addRule ((\@firewallStatus)
,$ref_iptablesV6,$port,"\x75\x64\x70",
"\x73\x65\x73\x73\x69\x6f\x6e\x52\x75\x6c\x65"));if (($returnValue==
(0x03da+ 1796-0x0ade))){__setFirewallUdpPort ($port);
NXSession2::saveFirewallRule (Server::getMySessionID (),$port);}}sub 
addFirewallNXDPort{(my $port=NXNodeInfo::getNxdPort ());Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x4e\x58\x44\x20\x72\x75\x6c\x65\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));if (($GLOBAL::EnableFirewallConfiguration==
(0x05e7+ 6103-0x1dbe))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x0db5+ 1486-0x1383));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x0a57+ 6844-0x2513))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x2e"
);return ((0x181f+ 3443-0x2592));}(my $returnValue=__addRule ((\@firewallStatus)
,$ref_iptablesV6,$port,"\x74\x63\x70"));if (($returnValue==(0x0523+ 7039-0x20a2)
)){__saveAddedRule ($port,"\x74\x63\x70");}($port=NXNodeInfo::getNxdUDPPort ());
(my $returnValue=__addRule ((\@firewallStatus),$ref_iptablesV6,$port,
"\x75\x64\x70"));if (($returnValue==(0x0346+ 3479-0x10dd))){__saveAddedRule (
$port,"\x75\x64\x70");}}sub addFirewallNXHtdPort{(my $port=NXTools::getNXHtdPort
 ());Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x4e\x58\x48\x74\x64\x20\x72\x75\x6c\x65\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));if (($GLOBAL::EnableFirewallConfiguration==
(0x03b8+ 4226-0x143a))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x058c+ 2298-0x0e86));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x0f16+ 5600-0x24f6))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x2e"
);return ((0x00b4+ 1383-0x061b));}(my $returnValue=__addRule ((\@firewallStatus)
,$ref_iptablesV6,$port,"\x74\x63\x70"));if (($returnValue==(0x0dd4+ 485-0x0fb9))
){__saveAddedRule ($port,"\x74\x63\x70");}}sub delFirewallUdpPort{(my $port=
__getFirewallUdpPort ());if (($port ne (""))){my ($ref_iptablesV6);(my (
@firewallStatus)=__getFirewallStatus ((\$ref_iptablesV6)));if ((
__checkFirewallStatus ((\@firewallStatus),$ref_iptablesV6)==(0x0d22+ 562-0x0f54)
)){Logger::debug (((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x55\x44\x50\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20"
.$port)."\x2e"));return ((0x0be9+ 5728-0x2249));}Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x75\x64\x70\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));__delRule ((\@firewallStatus),$ref_iptablesV6,$port,
"\x75\x64\x70");__cleanFirewallUdpPort ();}}sub __setFirewallUdpPort{(
$firewallUdpPort=shift (@_));}sub __getFirewallUdpPort{return ($firewallUdpPort)
;}sub __cleanFirewallUdpPort{($firewallUdpPort=(""));}return (
(0x0324+ 5068-0x16ef));
