############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXConnectedUsersManager;no warnings;($socketToHandlingAdminModeMessages=
undef);sub handleAdminModeMessage{(my $socket=shift (@_));my ($line);(my $bytes=
main::nxread ($socket,(\$line),65536));Logger::debug (((((
"\x52\x65\x61\x64\x20\x27".$bytes).
"\x27\x20\x6f\x66\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20"
).$line)."\x2e"));if (($bytes==(0x0cff+ 3172-0x1963))){
Common::NXSelector::removeFromGlobalSelector ($socket);Logger::debug (((
"\x43\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20".$socket).
"\x20\x72\x65\x6d\x6f\x76\x65\x64\x20\x66\x72\x6f\x6d\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
));main::nxclose ($socket);return;}if (($line=~ /NX> $GLOBAL::MSG_ADMIN_MODE connected (.*)\n/ )
){(my ($username,$ip,$createTime,$display,$cookie,$client,$shadowMode,$nodeName,
$type,$shadowModeCfg)=NXSession2::getClientMonitorParameters ($1));(my (%session
)=("\x73\x65\x73\x73\x69\x6f\x6e\x49\x64",$1,"\x75\x73\x65\x72\x6e\x61\x6d\x65",
$username,"\x49\x50",$ip,"\x63\x72\x65\x61\x74\x69\x6f\x6e\x54\x69\x6d\x65",
$createTime,"\x64\x69\x73\x70\x6c\x61\x79",$display,"\x63\x6f\x6f\x6b\x69\x65",
$cookie,"\x63\x6c\x69\x65\x6e\x74",$client,
"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65",$shadowMode,"\x6e\x6f\x64\x65",
$nodeName,"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65\x43\x66\x67",$shadowModeCfg)
);sendAddUserToClient ((\%session));}elsif (($line=~ /NX> $GLOBAL::MSG_ADMIN_MODE disconnected (.*)\n/ )
){sendDelUserToClient ($1);}else{Logger::warning (((
"\x68\x61\x6e\x64\x6c\x65\x41\x64\x6d\x69\x6e\x4d\x6f\x64\x65\x4d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x77\x72\x6f\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$line)."\x2e"));}}sub sendDelUserToClient{(my $data=shift (@_));(my $silent=
(0x07e8+ 7386-0x24c1));(my $message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_DISCONNECTED_USER_MONITOR).
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x75\x73\x65\x72\x3a\x20"
));($message.=$data);($message.="\x2c\x20\x73\x79\x73\x74\x65\x6d\x0a");(my $bytes
=NXNodeExec::sendToNode ($message));}sub handleEnableAdminMode{(my $socket=shift
 (@_));($socketToHandlingAdminModeMessages=$socket);
Common::NXSelector::addToGlobalSelector ($socket,
"\x73\x65\x72\x76\x65\x72\x27\x73\x20\x73\x6f\x63\x6b\x65\x74\x20\x61\x63\x63\x65\x70\x74\x65\x64\x20\x68\x61\x6e\x64\x6c\x65\x20\x66\x6f\x72\x20\x61\x64\x6d\x69\x6e\x20\x6d\x6f\x64\x65"
,
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x41\x64\x6d\x69\x6e\x4d\x6f\x64\x65\x4d\x65\x73\x73\x61\x67\x65"
);}sub sendAllAddedUserToClient{(my (@allConnected)=
NXSession2::getClientMonitorParametersForAllSessions ());foreach my $ID (
@allConnected){sendAddUserToClient ($ID);}}sub 
isNotSocketToHandleAdminModeMessages{(my $socket=shift (@_));if ((
$socketToHandlingAdminModeMessages ne $socket)){return ((0x13e0+ 3709-0x225c));}
return ((0x023c+ 2347-0x0b67));}sub sendAddUserToClient{(my $session=shift (@_))
;(my $silent=(0x22a1+   6-0x22a7));if (((Server::getMySessionID ()eq $$session{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"})or (Server::getMainSessionID ()eq 
$$session{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}))){Logger::debug (
"\x44\x6f\x6e\x27\x74\x20\x61\x64\x64\x20\x61\x67\x61\x69\x6e\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x73\x65\x73\x73\x69\x6f\x6e"
);return;}(my $fileTransfer=
NXProfilesManager::isFileTransferAvailablePerUserAndNode ($$session{
"\x75\x73\x65\x72\x6e\x61\x6d\x65"},$$session{"\x6e\x6f\x64\x65"}));(my $message
=(("\x4e\x58\x3e\x20".$GLOBAL::MSG_ATTACHED_USER_MONITOR).
"\x20\x41\x74\x74\x61\x63\x68\x65\x64\x20\x75\x73\x65\x72\x3a\x20"));($message.=
($$session{"\x75\x73\x65\x72\x6e\x61\x6d\x65"}."\x2c\x20"));($message.=(
$$session{"\x49\x50"}."\x2c\x20"));($message.=($$session{
"\x63\x72\x65\x61\x74\x69\x6f\x6e\x54\x69\x6d\x65"}."\x2c\x20"));($message.=(
$$session{"\x64\x69\x73\x70\x6c\x61\x79"}."\x2c\x20"));($message.=($$session{
"\x63\x6f\x6f\x6b\x69\x65"}."\x2c\x20"));($message.=($$session{
"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65"}."\x2c\x20"));($message.=($$session{
"\x63\x6c\x69\x65\x6e\x74"}."\x2c\x20"));($message.=($$session{
"\x6f\x77\x6e\x65\x72"}."\x2c\x20"));($message.=($silent."\x2c\x20"));($message
.=($$session{"\x6e\x6f\x64\x65"}."\x2c\x20"));($message.=
"\x73\x79\x73\x74\x65\x6d\x2c\x20");($message.=($fileTransfer."\x2c\x20"));(
$message.=($$session{"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65\x43\x66\x67"}.
"\x0a"));NXNodeExec::sendToNode ($message);}sub disconnectUser{(my $reqUsername=
shift (@_));(my $reqNodeName=shift (@_));(my $reqDisplay=shift (@_));
Logger::debug (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x3a\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x55\x73\x65\x72\x20\x63\x61\x6c\x6c\x65\x64"
);(my $sessionId=NXSession2::getSessionOnNodeByDisplayAndUser ($reqNodeName,
$reqDisplay,$reqUsername));if ((not (defined ($sessionId)))){Logger::warning (((
((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x66\x69\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$reqUsername)."\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x20").$reqNodeName).
"\x20\x77\x69\x74\x68\x20\x64\x69\x73\x70\x6c\x61\x79\x20").$reqDisplay)."\x2e")
);return;}(my $type=NXSession2::getTypeBySessionId ($sessionId));if (
Common::NXSessionType::isAttach ($type)){Logger::debug ((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x3a\x20"
.$sessionId));main::send_command_to_server ($sessionId,(
$GLOBAL::MSG_REQUEST_TERMINATE.
"\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"))
;}else{Logger::debug ((((
"\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6c\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x75\x73\x65\x72\x20"
.$reqUsername)."\x20").(("\x6f\x6e\x20\x64\x69\x73\x70\x6c\x61\x79\x20".
$reqDisplay)."\x2e")));main::send_command_to_server ($sessionId,(
$GLOBAL::MSG_REQUEST_SUSPEND.
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));}}"\x3f\x3f\x3f";
