############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXRemoteMachinesGroups::BEGIN{package NXRemoteMachinesGroups;no warnings;
require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
NXRemoteMachinesGroups::BEGIN{package NXRemoteMachinesGroups;no warnings;require
 Exception::Log;do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->
import};}sub NXRemoteMachinesGroups::BEGIN{package NXRemoteMachinesGroups;no 
warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"->import};}package 
NXRemoteMachinesGroups;no warnings;((%__loadedGroups)=());sub addGroupToDBHash{(my $ref_hash
=shift (@_));(my $groupname=shift (@_));(my $priority=shift (@_));(my (%group)=
());($group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}=$groupname);($group{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}=$priority);($group{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=(""));($$ref_hash{$groupname}=(\%group));}
sub editGroupPriorityInDBHash{(my $ref_hash=shift (@_));(my $groupname=shift (@_
));(my $priority=shift (@_));($$ref_hash{$groupname}{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}=$priority);}sub addMachineToGroupInDBHash{(my $ref_hash
=shift (@_));(my $groupname=shift (@_));(my $machine=shift (@_));if ($$ref_hash{
$groupname}{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}){($$ref_hash{$groupname}{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}.=("\x2c".$machine));}else{($$ref_hash{
$groupname}{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=$machine);}}sub 
delMachineFromGroupInDBHash{(my $ref_hash=shift (@_));(my $groupname=shift (@_))
;(my $machine=shift (@_));($$ref_hash{$groupname}{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=~ s/^$machine,// );($$ref_hash{$groupname}{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=~ s/,*$machine// );}sub save{(my $name=shift
 (@_));(my $ref_hash=shift (@_));if ((not (%$ref_hash))){
NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name)."\x0a"));}else{my ($command);foreach my $group (values (%$ref_hash)){(my $groupname
=main::urlencode ($$group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}));(my $record=
main::urlencode (__createRecord ($group)));if (($record ne $__loadedGroups{
$groupname})){($command.=((("\x2c\x66\x69\x65\x6c\x64\x3d".$groupname).
"\x2c\x76\x61\x6c\x75\x65\x3d").$record));}delete ($__loadedGroups{$groupname});
}if (($command ne (""))){NXRedis::sendToDbAndSave ((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name).$command)."\x0a"));}if (%__loadedGroups){my ($commandDel);foreach my $key
 (keys (%__loadedGroups)){($commandDel.=("\x2c\x66\x69\x65\x6c\x64\x3d".$key));}
if (($commandDel ne (""))){NXRedis::sendToDbAndSave ((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name).$commandDel)."\x0a"));}}}return ((0x1f6f+ 1919-0x26ed));}sub getGroupsDB
{(my $name=shift (@_));(my (%groupsDB)=());if (($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){return (%groupsDB);}
NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x61\x6c\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name)."\x0a"));((%__loadedGroups)=split ( / / ,NXRedis::get (),
(0x1531+ 2349-0x1e5e)));foreach my $key (keys (%__loadedGroups)){(my $ref_group=
__parseDBLine (main::urldecode ($__loadedGroups{$key})));($groupsDB{$$ref_group{
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}}=$ref_group);}return (%groupsDB);}sub 
cleanLoadedGroups{((%__loadedGroups)=());}sub printOneMachineGroupList{(my $ref_group
=shift (@_));(my $ref_parameters=shift (@_));if ((main::nxwrite (
main::nxgetSTDOUT (),(("\x4e\x6f\x64\x65\x20\x6e\x61\x6d\x65\x3a\x20".
$$ref_group{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"})."\x0a"))==(-
(0x096f+ 2418-0x12e0)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);
return ((0x0bd3+ 6336-0x2493));}if ((main::nxwrite (main::nxgetSTDOUT (),((
"\x50\x72\x69\x6f\x72\x69\x74\x79\x3a\x20".$$ref_group{
"\x70\x72\x69\x6f\x72\x69\x74\x79"})."\x0a"))==(-(0x0614+ 5874-0x1d05)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x066f+ 3913-0x15b8));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((main::nxwrite (main::nxgetSTDOUT (),(
("\x4e\x6f\x64\x65\x20\x55\x55\x49\x44\x3a\x20".$$ref_group{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"})."\x0a"))==(-(0x05b5+ 3750-0x145a)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x05e0+ 7813-0x2465));}if ((main::nxwrite (main::nxgetSTDOUT (),((
"\x4e\x6f\x64\x65\x3a\x20".$$ref_group{"\x68\x6f\x73\x74\x70\x6f\x72\x74"}).
"\x0a"))==(-(0x0af4+ 2737-0x15a4)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((0x016f+ 445-0x032c));}}if ((main::nxwrite 
(main::nxgetSTDOUT (),"\x0a")==(-(0x0b15+ 306-0x0c46)))){NXShell::setExitRequest
 ($ExitRequests::closedSTDOUT);return ((0x001b+ 2235-0x08d6));}return (
(0x05b2+ 6573-0x1f5e));}sub printMachinesGroups{(my $ref_hash=shift (@_));(my $ref_parameters
=shift (@_));(my (%table)=());__setMaxWidths ((\%table),$ref_hash,
$ref_parameters);if ((__printHeader ((\%table),$ref_parameters)==
(0x15ed+ 647-0x1874))){return ((0x0c8f+ 213-0x0d64));}if ((__printBody ((\%table
),$ref_hash,$ref_parameters)==(0x04e5+ 1053-0x0902))){return (
(0x032a+ 8752-0x255a));}return ((0x0c0f+ 4672-0x1e4e));}sub __setMaxWidths{(my $ref_table
=shift (@_));(my $ref_hash=shift (@_));(my $ref_parameters=shift (@_));
NXTools::setWidth ($ref_table,"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",
"\x47\x72\x6f\x75\x70\x20\x6e\x61\x6d\x65");NXTools::setWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73","\x4e\x6f\x64\x65\x20\x6e\x61\x6d\x65");
NXTools::setWidth ($ref_table,"\x70\x72\x69\x6f\x72\x69\x74\x79",
"\x50\x72\x69\x6f\x72\x69\x74\x79");if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){NXTools::setWidth ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73","\x4e\x6f\x64\x65\x20\x55\x55\x49\x44");
NXTools::setWidth ($ref_table,"\x68\x6f\x73\x74\x70\x6f\x72\x74",
"\x4e\x6f\x64\x65");}foreach my $group (values (%$ref_hash)){NXTools::setWidth (
$ref_table,"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",$$group{
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"});(my (@nodenameLines)=split ( /,/ ,
$$group{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"},(0x09df+ 4889-0x1cf8)));foreach my $line
 (@nodenameLines){NXTools::setWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73",$line);}NXTools::setWidth ($ref_table,
"\x70\x72\x69\x6f\x72\x69\x74\x79",$$group{"\x70\x72\x69\x6f\x72\x69\x74\x79"});
if (defined ($$ref_parameters{"\x65\x78\x74\x65\x6e\x64\x65\x64"})){(my (
@nodeLines)=split ( /,/ ,$$group{"\x6d\x61\x63\x68\x69\x6e\x65\x73"},
(0x1ddc+ 2003-0x25af)));foreach my $line (@nodeLines){NXTools::setWidth (
$ref_table,"\x6d\x61\x63\x68\x69\x6e\x65\x73",$line);}(my (@hostportLines)=split
 ( /,/ ,$$group{"\x68\x6f\x73\x74\x70\x6f\x72\x74"},(0x00f4+ 8180-0x20e8)));
foreach my $line (@hostportLines){NXTools::setWidth ($ref_table,
"\x68\x6f\x73\x74\x70\x6f\x72\x74",$line);}}}}sub __printHeader{(my $ref_table=
shift (@_));(my $ref_parameters=shift (@_));if ((NXTools::printWidth ($ref_table
,"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",
"\x47\x72\x6f\x75\x70\x20\x6e\x61\x6d\x65")==(-(0x0756+  15-0x0764)))){return (
(0x025b+ 2796-0x0d47));}if ((NXTools::printWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73","\x4e\x6f\x64\x65\x20\x6e\x61\x6d\x65")==
(-(0x0041+ 4257-0x10e1)))){return ((0x0428+ 3920-0x1378));}if ((
NXTools::printWidth ($ref_table,"\x70\x72\x69\x6f\x72\x69\x74\x79",
"\x50\x72\x69\x6f\x72\x69\x74\x79")==(-(0x0147+ 7375-0x1e15)))){return (
(0x09b2+ 1373-0x0f0f));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((NXTools::printWidth ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73","\x4e\x6f\x64\x65\x20\x55\x55\x49\x44")==(-
(0x1337+ 2517-0x1d0b)))){return ((0x1d17+ 2218-0x25c1));}if ((
NXTools::printWidth ($ref_table,"\x68\x6f\x73\x74\x70\x6f\x72\x74",
"\x4e\x6f\x64\x65")==(-(0x0805+ 362-0x096e)))){return ((0x0f15+ 5970-0x2667));}}
if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x0107+ 2291-0x09f9)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x0962+ 2933-0x14d7));}if ((NXTools::printMark ($ref_table,
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65")==(-(0x074d+ 6152-0x1f54)))){return (
(0x0210+ 678-0x04b6));}if ((NXTools::printMark ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73")==(-(0x096f+ 1991-0x1135)))){return (
(0x0223+ 3345-0x0f34));}if ((NXTools::printMark ($ref_table,
"\x70\x72\x69\x6f\x72\x69\x74\x79")==(-(0x017b+ 8812-0x23e6)))){return (
(0x10b4+ 3561-0x1e9d));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((NXTools::printMark ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73")==(-(0x1594+ 654-0x1821)))){return (
(0x1bf5+ 605-0x1e52));}if ((NXTools::printMark ($ref_table,
"\x68\x6f\x73\x74\x70\x6f\x72\x74")==(-(0x174d+ 1161-0x1bd5)))){return (
(0x078c+ 6685-0x21a9));}}if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-
(0x1a4c+  87-0x1aa2)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);
return ((0x044b+ 6098-0x1c1d));}return ((0x06d1+ 1503-0x0caf));}sub __printBody{
(my $ref_table=shift (@_));(my $ref_hash=shift (@_));(my $ref_parameters=shift (
@_));foreach my $group (values (%$ref_hash)){(my (@nodenameLines)=split ( /,/ ,
$$group{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"},(0x04c4+ 8233-0x24ed)));(my (
@nodesLines)=split ( /,/ ,$$group{"\x6d\x61\x63\x68\x69\x6e\x65\x73"},
(0x08c3+ 2480-0x1273)));(my (@hostportLines)=split ( /,/ ,$$group{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"},(0x1377+ 5013-0x270c)));(my $maxLines=scalar
 (@nodesLines));if (($maxLines==(0x1581+ 4014-0x252f))){($maxLines=
(0x19b8+ 1437-0x1f54));}for ((my $i=(0x000c+ 945-0x03bd));($i<$maxLines);(++$i))
{(my $groupname=(""));(my $nodename=(""));(my $priority=(""));(my $nodesLine=
(""));(my $hostportLine=(""));if (($i==(0x1540+ 2375-0x1e87))){($groupname=
$$group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"});($priority=$$group{
"\x70\x72\x69\x6f\x72\x69\x74\x79"});}if (defined ($nodenameLines[$i])){(
$nodename=$nodenameLines[$i]);}if (defined ($nodesLines[$i])){($nodesLine=
$nodesLines[$i]);}if (defined ($hostportLines[$i])){($hostportLine=
$hostportLines[$i]);}if ((NXTools::printWidth ($ref_table,
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",$groupname)==(-(0x0184+ 1160-0x060b)))){
return ((0x0a00+ 5152-0x1e20));}if ((NXTools::printWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73",$nodename)==(-(0x1a31+ 950-0x1de6)))){
return ((0x038c+ 1797-0x0a91));}if ((NXTools::printWidth ($ref_table,
"\x70\x72\x69\x6f\x72\x69\x74\x79",$priority)==(-(0x0fa4+ 1708-0x164f)))){return
 ((0x0695+ 1534-0x0c93));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((NXTools::printWidth ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73",$nodesLine)==(-(0x0283+ 7121-0x1e53)))){
return ((0x0a41+ 4415-0x1b80));}if ((NXTools::printWidth ($ref_table,
"\x68\x6f\x73\x74\x70\x6f\x72\x74",$hostportLine)==(-(0x1af7+ 2974-0x2694)))){
return ((0x0723+ 1640-0x0d8b));}}if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a"
)==(-(0x02e8+ 2593-0x0d08)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((0x10a7+ 194-0x1169));}}}if ((main::nxwrite
 (main::nxgetSTDOUT (),"\x0a")==(-(0x0a61+ 931-0x0e03)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x07b3+ 1629-0x0e10));}}sub __createRecord{(my $ref_group=shift (@_));(my $record
=(""));($record.=($$ref_group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}."\x3a"));(
$record.=(main::urlencode ($$ref_group{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}).
"\x3a"));($record.=$$ref_group{"\x70\x72\x69\x6f\x72\x69\x74\x79"});
Logger::debug3 (((
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x4d\x61\x63\x68\x69\x6e\x65\x73\x47\x72\x6f\x75\x70\x73\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x72\x65\x63\x6f\x72\x64\x20\x27"
.$record)."\x27\x2e"));return ($record);}sub __parseDBLine{(my $lineToParse=
shift (@_));chomp ($lineToParse);(my (@segments)=split ( /:/ ,$lineToParse,
(0x17f9+ 1141-0x1c6e)));(my (%remoteGroup)=());($remoteGroup{
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}=$segments[(0x0da7+ 5743-0x2416)]);(
$remoteGroup{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=main::urldecode ($segments[
(0x0f2f+ 263-0x1035)]));($remoteGroup{"\x70\x72\x69\x6f\x72\x69\x74\x79"}=
$segments[(0x08bf+ 5917-0x1fda)]);($remoteGroup{
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"}=(""));($remoteGroup{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"}=(""));(my (@machines)=split ( /,/ ,
$remoteGroup{"\x6d\x61\x63\x68\x69\x6e\x65\x73"},(0x1e43+ 545-0x2064)));(my $nodeParams
=(""));foreach my $machine (@machines){($nodeParams=NXNodes::get ($machine));(
$remoteGroup{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"}.=(main::urldecode (
$$nodeParams{"\x6e\x6f\x64\x65\x2d\x6e\x61\x6d\x65"})."\x2c"));($remoteGroup{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"}.=((($$nodeParams{"\x68\x6f\x73\x74"}."\x3a")
.$$nodeParams{"\x70\x6f\x72\x74"})."\x2c"));}($remoteGroup{
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"}=~ s/,$// );($remoteGroup{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"}=~ s/,$// );return ((\%remoteGroup));}
"\x3f\x3f\x3f";
