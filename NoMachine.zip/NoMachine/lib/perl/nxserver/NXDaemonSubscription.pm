############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXDaemonSubscription::BEGIN{package NXDaemonSubscription;no warnings;require
 NXClientSystemDaemons;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
->import};}package NXDaemonSubscription;no warnings;((%__subscriptionSockets)=()
);sub createAnywhereSubscriptionClient{if ((createSubscriptionClient (
"\x61\x6e\x79\x77\x68\x65\x72\x65")==(0x16ad+ 1586-0x1cdf))){
Common::NXSelector::addToGlobalSelector (
NXClientSystemDaemons::getSocketToServerDaemon (),
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x4e\x65\x74\x77\x6f\x72\x6b\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e"
,
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x41\x6e\x79\x77\x68\x65\x72\x65\x4d\x65\x73\x73\x61\x67\x65"
);}}sub createSubscriptionClient{(my $type=shift (@_));(my $serverDaemonPid=
NXClientSystemDaemons::getServerDaemonPid ());if ((($serverDaemonPid==(-
(0x07b0+ 1932-0x0f3b)))or ($serverDaemonPid==$ $))) {
 return (
(0x1e16+ 282-0x1f2f));}if ((NXClientSystemDaemons::openConnection ()!=
(0x0ae6+ 6558-0x2483))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x75\x62\x73\x63\x72\x69\x62\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e"
);return ((0x0091+ 5422-0x15be));}($__subscriptionSockets{$type}=
NXClientSystemDaemons::getSocketToServerDaemon ());($sessionID=
Server::getMySessionID ());NXClientSystemDaemons::sendMessage (((((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_SUBSCRIBE_TO_DAEMON).
"\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x3d").$sessionID).
"\x20\x74\x79\x70\x65\x3d").$type)."\x20\x0a"));return ((0x0bc8+ 5957-0x230d));}
sub closeSubscription{(my $type=shift (@_));if ((defined ($__subscriptionSockets
{$type})and ($__subscriptionSockets{$type}!=(-(0x1d59+ 2120-0x25a0))))){
Logger::debug (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);Common::NXSelector::removeFromGlobalSelector ($__subscriptionSockets{$type});
main::nxclose ($__subscriptionSockets{$type});undef ($__subscriptionSockets{
$type});}}sub handleAnywhereMessage{(my $fh=shift (@_));Logger::debug (((
"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x6f\x6e\x20\x74\x68\x65\x20"
.Server::getAnywhereName ()).
"\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));my ($buffer);(my $bytes=main::nxread ($fh,(\$buffer),65536));Logger::debug ((
("\x52\x65\x61\x64\x20\x27".$bytes).
"\x27\x20\x6f\x66\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65"
));if (($bytes==(0x004b+ 475-0x0226))){Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65\x64\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x2e"
);closeSubscription ("\x61\x6e\x79\x77\x68\x65\x72\x65");}else{Logger::debug (((
"\x48\x61\x6e\x64\x6c\x65\x20".Server::getAnywhereName ()).((
"\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27".$buffer).
"\x27\x20\x66\x72\x6f\x6d\x20\x64\x61\x65\x6d\x6f\x6e\x2e")));(my $ret=
NXNodeExec::sendToNode ($buffer));if ((($ret==(-(0x1210+ 2759-0x1cd6)))or ($ret
==(0x0fa1+ 5973-0x26f6)))){Logger::warning ((Server::getAnywhereName ().((
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x27".$buffer).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
)));}else{Logger::debug ((Server::getAnywhereName ().
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x58\x4e\x6f\x64\x65\x2e"
));}}}sub sendUserConnectionToMain{(my $request=shift (@_));(my $fh=
$__subscriptionSockets{"\x61\x6e\x79\x77\x68\x65\x72\x65"});(my $message=((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_USER_CONNECTION_TO_MACHINE).
"\x20\x55\x73\x65\x72\x20").$request)."\x0a"));return (main::nxwrite ($fh,
$message));}"\x3f\x3f\x3f";
