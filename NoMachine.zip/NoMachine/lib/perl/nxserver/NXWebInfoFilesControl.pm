############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXWebInfoFilesControl;no warnings;($serviceMonitoringDelay=
(0x0e38+ 7815-0x1eaf));($serviceStatus=(0x098f+ 291-0x0ab2));($lastCheckTime=
(0x0087+ 6612-0x1a5b));($infoFilesDirectory=(((((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x74\x6d\x70").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72").$GLOBAL::DIRECTORY_SLASH).
"\x69\x6e\x66\x6f"));sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub enableService{if ((
isServiceEnabled ()!=(0x004d+ 4597-0x1241))){init ();}($serviceStatus=
(0x0f3c+ 717-0x1208));return;}sub disableService{if ((isServiceEnabled ()==
(0x1595+ 3767-0x244b))){deleteAllInfoFiles ();}($serviceStatus=
(0x03af+ 8505-0x24e8));return;}sub isServiceEnabled{return ($serviceStatus);}sub
 init{($lastCheckTime=Common::NXTime::getSecondsSinceEpoch ());return;}sub 
__checkIsTimeForRemoveInfoFiles{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=$serviceMonitoringDelay);if 
((($lastCheckTime+$delay)<=$currentTime)){($lastCheckTime=$currentTime);return (
(0x0637+ 1473-0x0bf7));}return ((0x18b9+ 1003-0x1ca4));}sub checkService{if ((
isServiceEnabled ()!=(0x04a3+ 4135-0x14c9))){return ((0x0bff+ 4615-0x1e05));}if 
((__checkIsTimeForRemoveInfoFiles ()==(0x15b5+ 218-0x168f))){return (
(0x1012+ 837-0x1356));}if ((not (Common::NXFile::directoryExists (
$infoFilesDirectory)))){(my $errorString=libnxh::NXGetErrorString ());(my $errorNumber
=libnxh::NXGetError ());Logger::debug (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x63\x68\x65\x63\x6b\x53\x65\x72\x76\x69\x63\x65\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));return;}(my $list=
libnxhs::NXGetFilesList ($infoFilesDirectory));if (($list eq (""))){
Logger::debug (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x63\x68\x65\x63\x6b\x53\x65\x72\x76\x69\x63\x65\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"));return;}
foreach my $name (split ( /\n/ ,$list,(0x1c76+ 344-0x1dce))){if (($name=~ /^[\d\w]{32}\.info$/ )
){(my $path=(($infoFilesDirectory.$GLOBAL::DIRECTORY_SLASH).$name));(my $fileCTime
=Common::NXCore::NXFileCTime ($path));if ((checkAndRemoveInfoFile ($fileCTime)==
(0x0137+ 3566-0x0f24))){deleteInfoFile ($name);}}}return;}sub 
checkAndRemoveInfoFile{(my $cTime=(shift (@_)||(0x2504+ 160-0x25a4)));if ((
$cTime<=(0x07c4+ 2004-0x0f98))){return;}if ((($cTime+$serviceMonitoringDelay)<
Common::NXTime::getSecondsSinceEpoch ())){return ((0x0c4d+ 5013-0x1fe1));}
Logger::debug2 (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x63\x68\x65\x63\x6b\x41\x6e\x64\x52\x65\x6d\x6f\x76\x65\x49\x6e\x66\x6f\x46\x69\x6c\x65\x20\x46\x69\x6c\x65\x20\x6e\x6f\x74\x20\x72\x65\x61\x64\x79\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x2e"
);return ((0x081a+ 4650-0x1a44));}sub deleteAllInfoFiles{Logger::debug2 (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x41\x6c\x6c\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);if ((not (Common::NXFile::directoryExists ($infoFilesDirectory)))){(my $errorString
=libnxh::NXGetErrorString ());(my $errorNumber=libnxh::NXGetError ());
Logger::debug (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x41\x6c\x6c\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x3a\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x2e\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));return;}(my $list=
libnxhs::NXGetFilesList ($infoFilesDirectory));if (($list eq (""))){
Logger::debug (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x41\x6c\x6c\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x3a\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"));}foreach my $name
 (split ( /\n/ ,$list,(0x0939+ 6790-0x23bf))){deleteInfoFile ($name);}return;}
sub deleteInfoFile{(my $filename=(shift (@_)||("")));Logger::debug2 (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x49\x6e\x66\x6f\x46\x69\x6c\x65\x28"
.$filename)."\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"));if (($filename=~ /^[\d\w]{32}\.info$/ )
){(my $path=(($infoFilesDirectory.$GLOBAL::DIRECTORY_SLASH).$filename));if ((
libnxh::NXFileExists ($path)==(0x0358+ 8562-0x24c9))){if ((libnxh::NXFileRemove 
($path)!=(0x1f55+ 389-0x20da))){(my $errorString=libnxh::NXGetErrorString ());(my $errorNumber
=libnxh::NXGetError ());Logger::warning (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x27"
.$path)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$errorNumber).
"\x2c\x20").$errorString)."\x2e"));}else{Logger::debug (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$path)."\x27\x20\x72\x65\x6d\x6f\x76\x65\x64\x2e"));}}else{(my $errorString=
libnxh::NXGetErrorString ());(my $errorNumber=libnxh::NXGetError ());
Logger::debug2 (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$path).
"\x27\x20\x64\x6f\x65\x73\x6e\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
).$errorNumber)."\x2c\x20").$errorString)."\x2e"));}}return;}sub 
setInfoDirectoryPermissionByAdmin{Logger::debug (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x73\x65\x74\x49\x6e\x66\x6f\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x42\x79\x41\x64\x6d\x69\x6e\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);main::nxrequire (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");if ((not (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()))){return;}if ((not (
main::effectiveUserIsAdministrator ()))){return;}if ((not (
Common::NXFile::directoryExists ($infoFilesDirectory)))){my ($errorMsg);if ((not
 (Common::NXPaths::makePath ((\$errorMsg),$infoFilesDirectory)))){
Logger::warning (((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.$infoFilesDirectory)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorMsg)
."\x2e"));return ((0x1908+ 214-0x19dd));}}my ($errorNumber);my ($errorString);(my $silent
=(0x0cd3+ 3360-0x19f2));if ((Common::NXFile::setPermissionsFullForNX (
$infoFilesDirectory,(\$errorNumber),(\$errorString),$silent)==(-
(0x169a+ 2139-0x1ef4)))){Logger::debug (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$infoFilesDirectory)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));}if ((
Common::NXFile::setOwnershipForUserAndGroupNX ($infoFilesDirectory,(
\$errorNumber),(\$errorString))==(-(0x0c28+ 2960-0x17b7)))){Logger::debug ((((((
(
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x20\x27"
.$infoFilesDirectory)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));}return;}"\x3f\x3f\x3f";
