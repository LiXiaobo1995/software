############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}sub BEGIN{
no warnings;require Common::Logger;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->import};}sub BEGIN{
no warnings;require Common::NXTranslator;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x54\x72\x61\x6e\x73\x6c\x61\x74\x6f\x72"
->import};}sub BEGIN{no warnings;require Common::NXMsg;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x4d\x73\x67"->import};}package NXMsg;
no warnings;(my $__silentMode=(0x08fa+ 4431-0x1a49));(my $__eolAfterRequest=
(0x150b+ 2814-0x2009));sub register_response{__register ($_[
(0x0995+ 3500-0x1741)],$_[(0x2310+ 692-0x25c3)],$_[(0x00f1+ 9688-0x26c7)],
Common::NXMsg::getResponseType (),(""));}sub register_error{__register ($_[
(0x1518+ 4428-0x2664)],$_[(0x1ab5+ 377-0x1c2d)],$_[(0x188f+ 752-0x1b7d)],
Common::NXMsg::getErrorType (),$_[(0x0137+ 128-0x01b4)]);}sub register_request{
__register ($_[(0x06bd+ 3956-0x1631)],$_[(0x1c59+ 415-0x1df7)],$_[
(0x0955+ 4000-0x18f3)],Common::NXMsg::getRequestType (),$_[(0x106f+ 2666-0x1ad6)
]);}sub __register{(my $class=$_[(0x0089+ 2543-0x0a78)]);(my $name=$_[
(0x19e2+ 658-0x1c73)]);(my $number=$_[(0x048d+ 5794-0x1b2d)]);(my $type=$_[
(0x01a5+ 3455-0x0f21)]);(my $regExp=$_[(0x0d37+ 3303-0x1a1a)]);if (((not (
defined ($name)))or (not (($name=~ /^[\w\d\._-]{1,128}$/ ))))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6e\x61\x6d\x65\x20"
.$name),(0x07c9+ 1380-0x0d2b));__error ();}if (((not (defined ($number)))or (not
 (($number=~ /^[\d]{3,4}$/ ))))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6e\x75\x6d\x62\x65\x72\x20"
.$number),(0x0d64+ 3920-0x1cb2));__error ();}if ((((!defined ($regExp))||(
$regExp eq ("")))and Common::NXMsg::isRequestType ($type))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x72\x65\x67\x45\x78\x70\x20"
.$regExp),(0x1cb9+ 952-0x206f));__error ();}if (isMessageRegistered ($name)){
Logger::error ((("\x4e\x58\x4d\x73\x67\x3a\x20\x4d\x65\x73\x73\x61\x67\x65\x20".
$name).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x2e"
),(0x1c05+ 2061-0x2410));__error ();}Common::NXMsg::saveMessageData ($name,
$number,$type,$regExp);}sub __sprinf_reg_exp{(my $format=shift (@_));(my $name=
shift (@_));(my $class=shift (@_));(my (@message_parameters)=@_);for ((my $i=
(0x15ff+ 3725-0x248c));($i<=$#message_parameters);(++$i)){($message_parameters[
$i]=~ s/^\n//gm );($message_parameters[$i]=~ s/\n$//gm );}(my $message=sprintf (
$format,@message_parameters));($message=~ s/\n/\n        /gm );return ($message)
;}sub check_msg{(my $index=shift (@_));(my $class=shift (@_));if (((not (defined
 ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){return (
(0x161d+ 2407-0x1f84));}(my $messageNumber=Common::NXMsg::getNumber ($index));if
 ((not (defined ($messageNumber)))){return ((0x0dec+ 2957-0x1979));}return (
(0x1b1a+ 1254-0x1fff));}sub get_msg{(my $index=shift (@_));(my $class=shift (@_)
);(my (@parameters)=@_);if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ )
)))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x6e\x64\x65\x78\x20\x73\x74\x72\x69\x6e\x67\x20"
.$index),(0x02a0+ 7738-0x20d9));__error ();}(my $messageNumber=
Common::NXMsg::getNumber ($index));if ((not (defined ($messageNumber)))){
Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x55\x6e\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$index),(0x046c+ 1828-0x0b8f));__error ();}for ((my $i=(0x0333+ 4336-0x1423));(
$i<=$#parameters);(++$i)){($parameters[$i]=~ s/^\n//gm );($parameters[$i]=~ s/\n$//gm )
;}(my $messageText=(""));if (Common::NXEnglishMessages::isCustomizableMessage (
$index)){(($messageNumber,$index,$messageText)=
Common::NXMsg::getCustomizedMessage ($index,$messageNumber,(\@parameters)));}
else{($messageText=Common::NXEnglishMessages::getMessage ($index));}(my $message
=(""));if (shouldPackMessage ($messageNumber)){($message=
Common::NXMsg::constructMessage ($messageNumber,$messageText,@parameters));(my $packedMessage
=Common::NXMsg::packResponse ($index,$message,@parameters));return ((""),
$packedMessage);}else{Common::NXTranslator::translate ($index,(\$messageText));}
($message=Common::NXMsg::constructMessage ($messageNumber,$messageText,
@parameters));if (($index eq 
"\x65\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72\x44\x65\x6c\x46\x61\x69\x6c\x65\x64"
)){($message=~ s/ERROR: // );}return (Common::NXMsg::getRegExp ($index),$message
);}sub get_text{(my $indexString=shift (@_));(my $class=shift (@_));(my (
@parameters)=@_);(my $translate=(0x0595+ 7486-0x22d2));return (__getText (
$indexString,$translate,@parameters));}sub getEnglishText{(my $indexString=shift
 (@_));(my (@parameters)=@_);(my $translate=(0x1465+ 1485-0x1a32));return (
__getText ($indexString,$translate,@parameters));}sub __getText{(my $index=shift
 (@_));(my $translate=shift (@_));(my (@parameters)=@_);my ($message);if (((not 
(defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){Logger::error 
((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x6e\x64\x65\x78\x20\x73\x74\x72\x69\x6e\x67\x20"
.$index),(0x1f6c+ 447-0x212a));__error ();}unless (($translate and 
Common::NXTranslator::translate ($index,(\$message)))){($message=
Common::NXEnglishMessages::getMessage ($index));}for ((my $i=
(0x0cd0+ 3720-0x1b58));($i<=$#parameters);(++$i)){($parameters[$i]=~ s/^\n//gm )
;($parameters[$i]=~ s/\n$//gm );}if (($message ne (""))){($message=sprintf (
$message,@parameters));}return ($message);}sub send_response{(my $index=$_[
(0x0487+ 5975-0x1bde)]);if (Common::NXMsg::isErrorTypeByIndex ($index)){return (
error (@_));}(my ($reg_exp,$message)=get_msg (@_));if (isSilentMode ()){return;}
if ((not (Server::isClientConnectionOpen ()))){return;}Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));($message.="\x0a");if ((main::nxwrite (main::nxgetSTDOUT (),
$message)==(-(0x16e5+ 410-0x187e)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x07bd+ 5608-0x1da4)));}}sub 
send_response_no_newline{(my ($reg_exp,$message)=get_msg (@_));if (isSilentMode 
()){return;}if ((not (Server::isClientConnectionOpen ()))){return;}Logger::debug
 (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));main::nxwrite (main::nxgetSTDOUT (),$message);}sub 
send_response_without_number{(my $message=get_text (@_));if (isSilentMode ()){
return;}if ((not (Server::isClientConnectionOpen ()))){return;}Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x6e\x75\x6d\x62\x65\x72\x20\x27"
.$message)."\x27"));($message.="\x0a");if ((main::nxwrite (main::nxgetSTDOUT (),
$message)==(-(0x09c4+ 4401-0x1af4)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x035c+ 3397-0x10a0)));}}sub 
sendLogMessage{(my $message=shift (@_));(my $level=shift (@_));(my $storeInHistory
=shift (@_));if (Logger::isErrorLevel ($level)){Logger::error ($message,
$storeInHistory);}elsif (Logger::isWarningLevel ($level)){Logger::warning (
$message,$storeInHistory);}elsif (Logger::isInfoLevel ($level)){Logger::info (
$message,$storeInHistory);}else{Logger::debug ($message,$storeInHistory);}}sub 
__warning{(my $log_level=shift (@_));(my ($reg_exp,$message)=get_msg (@_));if (
isSilentMode ()){return;}if ((defined ($reg_exp)and ($reg_exp eq 
(0x1121+ 3446-0x1e96)))){($log_msg=__sprinf_reg_exp ($reg_exp,@_));
sendLogMessage ($log_msg,$log_level,(0x0f39+ 4218-0x1fb0));}if (((defined (
$reg_exp)and ($reg_exp ne ("")))and ($reg_exp ne (0x057d+ 4705-0x17dd)))){(
$log_msg=__sprinf_reg_exp ($reg_exp,@_));sendLogMessage ($log_msg,$log_level,
(0x1775+  46-0x17a0));}if (((not (defined ($message)))or ($message eq ("")))){((
$reg_exp,$message)=Common::NXMsg::get_msg (
"\x65\x47\x55\x49\x47\x65\x6e\x65\x72\x61\x6c"));}if (
Common::NXMsg::isPackedMessage ($message)){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x63\x6b\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isInfoLevel ($log_level)){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x61\x6c\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isWarningLevel ($log_level)){($message=~ s/(^NX> \d+) *(.*)$/$1 WARNING: $2/gm )
;Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x77\x61\x72\x6e\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}else{($message=~ s/(^NX> \d+) *(.*)$/$1 ERROR: $2/gm );
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x65\x72\x72\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}if (Server::isClientConnectionOpen ()){main::nxwrite (
main::nxgetSTDOUT (),($message."\x0a"));}}sub fatal{__warning (
Logger::getErrorLevel (),@_);NXShell::handle_command ("\x65\x78\x69\x74");}sub 
error{__warning (Logger::getErrorLevel (),@_);}sub warning{__warning (
Logger::getWarningLevel (),@_);}sub info{__warning (Logger::getInfoLevel (),@_);
}$GLOBAL::NXMsg::__inBuffer;sub send_requestWithAdditionalCallback{return (
__send_request (@_));}sub send_request{(my $index=shift (@_));(my $class=shift (
@_));(my $value=shift (@_));(my $additionalFd=(""));(my $callback=(""));return (
__send_request ($index,$class,$additionalFd,$callback,$value,@_));}sub 
__send_request{(my $pRegExp=shift (@_));(my $pMessage=shift (@_));(my $additionalFd
=shift (@_));(my $callback=shift (@_));(my $value=shift (@_));(my ($reg_exp,
$message)=get_msg ($pRegExp,$pMessage,@_));if (defined ($value)){if (($reg_exp 
eq "\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($value=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$value);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x196f+ 2776-0x2427))){Logger::error ((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c"
.sprintf ("\x5c\x30\x25\x6f",ord ($1))).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20").
"\x61\x6e\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x2e"
));return (());}}}}elsif ((not (($value=~ /$reg_exp/ )))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x76\x61\x6c\x75\x65\x20"
.$value));return (());}return ($value);}if (($message=~ /^NX> (\d\d\d)  $/ )){(
$message=(("\x4e\x58\x3e\x20".$1)."\x20"));}else{($message.="\x3a\x20");}if ((
sendEOL ()==(0x0239+ 5825-0x18f9))){if ((main::nxwrite (main::nxgetSTDOUT (),(
$message."\x0a"))==(-(0x0d48+ 1400-0x12bf)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return (());}}else{if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x078a+ 8033-0x26ea)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));(my $parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);((
%parameters)=());($parameters{"\x64\x61\x74\x61"}=(""));($parameters{
"\x6d\x61\x78\x4c\x65\x6e\x67\x74"}=$GLOBAL::commandBufferLimit);($parameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}=(0x2441+ 509-0x263e));($parameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x122f+ 1424-0x17bf));$parser->add ($$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});$parser->add (main::nxgetSTDIN (),(
\&__globalReadnLine),
"\x4e\x58\x4d\x73\x67\x3a\x3a\x5f\x5f\x67\x6c\x6f\x62\x61\x6c\x52\x65\x61\x64\x6e\x4c\x69\x6e\x65"
,(\%parameters));$parser->setNotRead (main::nxgetSTDIN ());if (($additionalFd ne
 (""))){$parser->add ($additionalFd);$parser->setCallbackForHandle (
$additionalFd,"\x43\x6c\x6f\x73\x65",$callback);}$parser->setTimeout (
"\x69\x6e\x66");$parser->run;(my $data=$parameters{"\x64\x61\x74\x61"});if ((not
 (defined ($data)))){return (());}(my $log_data=$data);if (($pRegExp eq 
"\x72\x41\x73\x6b\x46\x6f\x72\x41\x74\x74\x61\x63\x68\x4d\x65\x73\x73\x61\x67\x65"
)){($data=main::urlencode ($data));($log_data=main::urldecode ($data));}if (
NXShell::isCurrentModeNotWords ()){($log_data=~ s/(password=)([^&]*)/do {
            ($1 . ('*' x length($2)));
        };/eg )
;($log_data=~ s/(cookie=)([^&]*)/do {
            ($1 . ('*' x length($2)));
        };/eg )
;}else{();}if (($pRegExp ne "\x63\x6f\x6d\x6d\x61\x6e\x64")){if ((((
$GLOBAL::PROTO_VERSION ne "\x73\x68\x65\x6c\x6c")and ($GLOBAL::PROTO_VERSION ne 
("")))and (NXShell::getNoEcho ()!=(0x0c72+ 1267-0x1164)))){if ((main::nxwrite (
main::nxgetSTDOUT (),($data."\x0a"))==(-(0x1b48+ 766-0x1e45)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}else{if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x1153+ 1202-0x1604)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}}
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$log_data)."\x27\x2e"));if (($reg_exp eq 
"\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($data=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$data);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x1511+ 1934-0x1c7f))){Logger::error (((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x2e\x20\x43\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c").sprintf (
"\x5c\x30\x25\x6f",ord ($1))).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20\x61\x6e\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x68\x65\x72\x65\x2e"
));return (());}}}}elsif ((not (($data=~ /$reg_exp/ )))){Logger::error (((((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e\x20\x44\x61\x74\x61\x20\x27").$data).
"\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x6d\x61\x74\x63\x68\x20\x77\x69\x74\x68\x20\x72\x65\x67\x45\x78\x70\x20\x27"
).$reg_exp)."\x27\x2e"));if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-
(0x0bb1+ 1298-0x10c2)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);}
return (());}if ((($data eq (""))and $GLOBAL::PROTO_VERSION)){if ((main::nxwrite
 (main::nxgetSTDOUT (),"\x0a")==(-(0x0916+ 1451-0x0ec0)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}return (
$data);}sub send_hrequestWithAdditionalCallback{return (__send_hrequest (@_));}
sub send_hrequest{(my $indexString=shift (@_));(my $class=shift (@_));(my $additionalFd
=(""));(my $callback=(""));return (__send_hrequest ($indexString,$class,
$additionalFd,$callback,@_));}sub __send_hrequest{(my $indexString=shift (@_));(my $class
=shift (@_));(my $additionalFd=shift (@_));(my $callback=shift (@_));(my (
$reg_exp,$message)=get_msg ($indexString,$class,@_));($message.="\x3a\x20");(my $parser
="\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);((
%parameters)=());($parameters{"\x64\x61\x74\x61"}=(""));($parameters{
"\x6d\x61\x78\x4c\x65\x6e\x67\x74"}=$GLOBAL::commandBufferLimit);($parameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}=(0x142d+ 4061-0x240a));($parameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x2117+ 1069-0x2544));$parser->add ($$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});$parser->add (main::nxgetSTDIN (),(
\&__globalReadnLine),
"\x4e\x58\x4d\x73\x67\x3a\x3a\x5f\x5f\x67\x6c\x6f\x62\x61\x6c\x52\x65\x61\x64\x6e\x4c\x69\x6e\x65"
,(\%parameters));$parser->setNotRead (main::nxgetSTDIN ());if (($additionalFd ne
 (""))){$parser->add ($additionalFd);$parser->setCallbackForHandle (
$additionalFd,"\x43\x6c\x6f\x73\x65",$callback);}$parser->setTimeout (
"\x69\x6e\x66");blindInput ();if ((main::nxwrite (main::nxgetSTDOUT (),$message)
==(-(0x1211+ 361-0x1379)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT
);showInput ();return (());}Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));$parser->run;showInput ();(my $data=$parameters{
"\x64\x61\x74\x61"});if ((not (defined ($data)))){main::nxwrite (
main::nxgetSTDOUT (),"\x0a");return (());}(my $hdata=$data);($hdata=~ s/./*/g );
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$hdata)."\x27"));if ((not (($data=~ /$reg_exp/ )))){if ((main::nxwrite (
main::nxgetSTDOUT (),"\x0a")==(-(0x1f81+ 1427-0x2513)))){NXShell::setExitRequest
 ($ExitRequests::closedSTDOUT);}Logger::error (((((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x2e\x20\x20").$hdata).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x6d\x61\x74\x63\x68\x20\x77\x69\x74\x68\x20"
).$reg_exp)."\x2e"));return (());}if (((($GLOBAL::PROTO_VERSION ne 
"\x73\x68\x65\x6c\x6c")and ($GLOBAL::PROTO_VERSION ne ("")))and (
NXShell::getNoEcho ()!=(0x1182+ 4100-0x2185)))){if ((main::nxwrite (
main::nxgetSTDOUT (),($hdata."\x0a"))==(-(0x0c06+ 6325-0x24ba)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}else{if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x088f+ 1567-0x0ead)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}return (
$data);}sub __error{main::nxwrite (main::nxgetSTDERR (),
"\x45\x72\x72\x6f\x72\x3a\x20\x66\x61\x74\x61\x6c\x20\x65\x72\x72\x6f\x72\x20\x69\x6e\x20\x6d\x6f\x64\x75\x6c\x65\x20\x4e\x58\x4d\x73\x67\x2c\x20\x63\x68\x65\x63\x6b\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x6d\x6f\x72\x65\x20\x64\x65\x74\x61\x69\x6c\x73\x0a"
);NXShell::handle_command ("\x65\x78\x69\x74");main::nxexit (
(0x0e92+ 5099-0x227c));}sub __readnLine{(my $maxLengt=(shift (@_)||
(0x2647+ 2984-0x21ef)));(my $data=());(my $endOfLine=(0x04ed+ 2421-0x0e62));(my $ignoreUntileEOL
=(0x0263+ 2597-0x0c88));while ((not ($endOfLine))){(my $readBuff=());(my $bytesToRead
=($maxLengt-length ($GLOBAL::NXMsg::__inBuffer)));if (($bytesToRead<=
(0x06eb+ 2112-0x0f2b))){($GLOBAL::NXMsg::__inBuffer=(""));($ignoreUntileEOL=
(0x089f+ 6468-0x21e2));(my $warning=((
"\x4e\x58\x4d\x73\x67\x3a\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6c\x6f\x6e\x67\x65\x72\x20\x74\x68\x61\x6e\x20"
.$GLOBAL::commandBufferLimit)."\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73\x2e"
));Logger::warning ($warning);(my ($reg_exp,$message)=get_msg (
"\x65\x54\x6f\x6f\x4c\x6f\x6e\x67\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x4e\x58\x4d\x73\x67",$GLOBAL::commandBufferLimit));main::nxwrite (
main::nxgetSTDOUT (),$message);}(my $readBytes=main::nxread (main::nxgetSTDIN ()
,(\$readBuff),(0x1e81+ 1232-0x2350)));if ((not (defined ($readBytes)))){(my $errorstring
=libnxh::NXGetErrorString ());(my $errorNumber=libnxh::NXGetError ());
main::nxwrite (main::nxgetSTDOUT (),"\x0a");NXShell::setExitRequest (((((
"\x46\x61\x69\x6c\x65\x64\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x3a\x20"
.$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));return (());}if ((
$readBytes==(0x0766+ 2120-0x0fae))){main::nxwrite (main::nxgetSTDOUT (),"\x0a");
NXShell::setExitRequest ($ExitRequests::closedSTDIN);return (());}if (($readBuff
 eq "\x0a")){(($ignoreUntileEOL eq (0x06a8+ 6393-0x1fa0))and ($ignoreUntileEOL=
(0x1a60+ 1204-0x1f14)));($data=$GLOBAL::NXMsg::__inBuffer);($endOfLine=
(0x08b0+ 1508-0x0e93));($GLOBAL::NXMsg::__inBuffer=(""));}else{if ((
$ignoreUntileEOL eq (0x1312+ 3352-0x202a))){($GLOBAL::NXMsg::__inBuffer.=
$readBuff);}}}return ($data);}sub __globalReadnLine{(my $self=shift (@_));(my $handleHash
=shift (@_));(my $refParameters=$$handleHash{
"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});if ((not ($$refParameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}))){(my $readBuff=());(my $bytesToRead=(
$$refParameters{"\x6d\x61\x78\x4c\x65\x6e\x67\x74"}-length (
$GLOBAL::NXMsg::__inBuffer)));if (($bytesToRead<=(0x03d9+ 994-0x07bb))){(
$GLOBAL::NXMsg::__inBuffer=(""));($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x0b2c+ 484-0x0d0f));(my $warning=((
"\x4e\x58\x4d\x73\x67\x3a\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6c\x6f\x6e\x67\x65\x72\x20\x74\x68\x61\x6e\x20"
.$GLOBAL::commandBufferLimit)."\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73\x2e"
));Logger::warning ($warning);(my ($reg_exp,$message)=get_msg (
"\x65\x54\x6f\x6f\x4c\x6f\x6e\x67\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x4e\x58\x4d\x73\x67",$GLOBAL::commandBufferLimit));if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x14fa+ 1794-0x1bfb)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);}}(my $readBytes=
main::nxread (main::nxgetSTDIN (),(\$readBuff),(0x1529+ 1359-0x0a78)));if ((not 
(defined ($readBytes)))){(my $errorstring=libnxh::NXGetErrorString ());if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x08d6+ 2477-0x1282)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);}NXShell::setExitRequest (
((
"\x46\x61\x69\x6c\x65\x64\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x3a\x20"
.$errorstring)."\x2e"));($$refParameters{"\x64\x61\x74\x61"}=());$self->
removeHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit (
$handleHash,(0x1c7a+ 1063-0x20a1),(0x1313+ 1716-0x19c7));return (());}if ((
$readBytes==(0x0476+ 1473-0x0a37))){if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x0c3c+ 2244-0x14ff)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);}NXShell::setExitRequest (
$ExitRequests::closedSTDIN);($$refParameters{"\x64\x61\x74\x61"}=());$self->
removeHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit (
$handleHash,(0x0fc0+ 2947-0x1b43),(0x00e9+ 1477-0x06ae));return (());}if ((
$readBuff=~ /\n$/ )){($readBuff=~ s/\r?\n$// );($GLOBAL::NXMsg::__inBuffer.=
$readBuff);(($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}eq 
(0x04c7+ 8257-0x2507))and ($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x0d1a+ 478-0x0ef8)));($$refParameters{"\x64\x61\x74\x61"}=
$GLOBAL::NXMsg::__inBuffer);($$refParameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}=(0x1865+ 720-0x1b34));(
$GLOBAL::NXMsg::__inBuffer=(""));$self->removeHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($handleHash,(0x128d+ 759-0x1584),
(0x10bc+ 3132-0x1cf8));return (());}else{if (($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}eq 
(0x05f6+ 5750-0x1c6c))){($GLOBAL::NXMsg::__inBuffer.=$readBuff);}}}else{$self->
removeHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit (
$handleHash,(0x1d4f+ 262-0x1e55),(0x0875+ 2114-0x10b7));}}sub setSilentMode{(
$__silentMode=(0x0caa+ 6555-0x2644));}sub offSilentMode{($__silentMode=
(0x0efb+ 2581-0x1910));}sub isSilentMode{if (($__silentMode==
(0x0857+ 4802-0x1b18))){return ((0x1229+ 1552-0x1838));}return (
(0x10dd+ 5016-0x2475));}sub setSendEOLAfterSendRequest{($__eolAfterRequest=
(0x0d60+ 1125-0x11c4));}sub sendEOL{if (($__eolAfterRequest==
(0x0917+ 4474-0x1a90))){return ((0x05ef+ 1344-0x0b2e));}return (
(0x18dd+ 1227-0x1da8));}sub clearDataParameter{($parameters{"\x64\x61\x74\x61"}=
(""));}sub blindInput{if ((not (Server::isConnectedToConsole ()))){Logger::debug
 (
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x65\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x63\x6f\x6e\x73\x6f\x6c\x65\x2e"
);return ((0x0211+ 7867-0x20cc));}Common::NXCore::disableConsoleEchoMode ();}sub
 showInput{if ((not (Server::isConnectedToConsole ()))){Logger::debug (
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x65\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x63\x6f\x6e\x73\x6f\x6c\x65\x2e"
);return ((0x015c+ 4275-0x120f));}Common::NXCore::enableConsoleEchoMode ();}sub 
getIndexStringByMessage{(my $message=shift (@_));(my $messageId=(-
(0x163a+ 1821-0x1d56)));if (($message=~ /NX> (\d+) / )){($messageId=$1);}
removeMessageHeader ((\$message));if (($messageId==
$GLOBAL::BRAND_MESSAGE_LICENSE_NOT_FOUND)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_NOT_VALID)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_EXPIRED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x78\x70\x69\x72\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_PRODUCT_NOT_MATCH)){return
 (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x72\x6f\x64\x75\x63\x74\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NEED_UPDATE)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x65\x65\x64\x55\x70\x64\x61\x74\x65"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_GENERIC_SUPPORT)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x47\x65\x6e\x65\x72\x69\x63\x53\x75\x70\x70\x6f\x72\x74"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_PLATFORM_NOT_MATCH)){
return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x6c\x61\x74\x66\x6f\x72\x6d\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_EVALUATION_EXPIRED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_DATE_NOT_VALID)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x44\x61\x74\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_EXPIRY_NOT_VALID)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x78\x70\x69\x72\x79\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_UNSUBSCRIBED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x55\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_UPGRADE_EXPIRED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x55\x70\x67\x72\x61\x64\x65\x45\x78\x70\x69\x72\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NODE_LICENSE_NOT_FOUND)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x6f\x64\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NODE_LICENSE_PRODUCT_NOT_MATCH)){
return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x6f\x64\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x72\x6f\x64\x75\x63\x74\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NODE_LICENSE_TYPE_NOT_MATCH)){
return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x6f\x64\x65\x4c\x69\x63\x65\x6e\x63\x65\x54\x79\x70\x65\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==
$GLOBAL::BRAND_MESSAGE_EVALUATION_UPGRADE_FROM_3_TO_4_NOT_POSSIBLE)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x55\x70\x67\x72\x61\x64\x65\x46\x72\x6f\x6d\x33\x54\x6f\x34\x4e\x6f\x74\x50\x6f\x73\x73\x69\x62\x6c\x65"
);}elsif (($messageId==$GLOBAL::MSG_ERROR_NOT_ENOUGH_X_RESOURCES)){return (
"\x65\x4e\x6f\x46\x72\x65\x65\x44\x69\x73\x70\x6c\x61\x79");}elsif (($messageId
==$GLOBAL::MSG_ERROR_REACHED_SESSION_LIMIT)){if ((index ($message,getEnglishText
 (
"\x65\x47\x55\x49\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x73"
))!=(-(0x0175+ 6982-0x1cba)))){return (
"\x65\x47\x55\x49\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x73"
);}elsif ((index ($message,getEnglishText (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x53\x65\x73\x73\x69\x6f\x6e\x73"
))!=(-(0x0cbc+ 1764-0x139f)))){return (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x53\x65\x73\x73\x69\x6f\x6e\x73"
);}elsif ((index ($message,getEnglishText (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x47\x75\x65\x73\x74\x73\x4e\x75\x6d\x62\x65\x72"
))!=(-(0x126b+ 2180-0x1aee)))){return (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x47\x75\x65\x73\x74\x73\x4e\x75\x6d\x62\x65\x72"
);}}elsif ((index ($message,getEnglishText (
"\x65\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x46\x6f\x75\x6e\x64"))!=(-
(0x0a96+ 269-0x0ba2)))){return (
"\x65\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x46\x6f\x75\x6e\x64");}
return ((""));}sub removeMessageHeader{(my $ref_message=shift (@_));(
$$ref_message=~ s/NX> \d+ ERROR: //gm );($$ref_message=~ s/NX> \d+ WARNING: //gm )
;($$ref_message=~ s/NX> \d+ //gm );}sub isMessageRegistered{(my $index=shift (@_
));if (Common::NXMsg::isMessageRegistered ($index)){return ((0x18c4+ 667-0x1b5e)
);}return ((0x14b5+ 3288-0x218d));}sub getMessageNumber{return (
Common::NXMsg::getNumber (@_));}sub shouldPackMessage{(my $messageNumber=shift (
@_));if ((Common::NXMsg::isErrorMessageNumber ($messageNumber)and 
Server::isClientSupportsPackedMessages ())){return ((0x0e35+ 3503-0x1be3));}
return ((0x1f38+ 1342-0x2476));}sub errorDependsOnClientType{(my $message=shift 
(@_));(my (@params)=shift (@_));if (Server::isClientNxclient ()){($message=~ s/^eCMD/eGUI/ )
;}error ($message,"\x4e\x58\x4d\x73\x67",@params);}register_error (
"\x4e\x58\x4d\x73\x67",
"\x65\x54\x6f\x6f\x4c\x6f\x6e\x67\x43\x6f\x6d\x6d\x61\x6e\x64",
(0x0dfd+ 2809-0x16a0));return ((0x16a7+ 3115-0x22d1));
