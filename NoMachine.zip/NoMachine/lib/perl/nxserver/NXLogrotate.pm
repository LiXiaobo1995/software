############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXLogrotate;no warnings;($__timeoutForFileReleasedCheck=
(0x0362+ 2708-0x0de7));($__sleepTimeBetweenFileReleaseChecks=0.2);(
$__checkLogrotateDelay=(0x141c+ 1373-0x15f5));($__lastCheckLogrotate=
(0x1994+ 983-0x1d6b));($__nxhtdErrorLogPath=(""));($__forcedRotate=
(0x062d+ 6972-0x2169));($__forcedRotateDateTime=(""));((
%__ref_forcedRotateParameters)=());((%threadHandles)=());sub 
__rotateTillOriginalFile{(my $type=shift (@_));(my $rotatedName=shift (@_));(my $rotationDir
=NXLogrotateDB::getDestination ($type));(my $maxRotation=
NXLogrotateDB::getRotate ($type));(my $prevRotatedFile=((($rotationDir.
$GLOBAL::DIRECTORY_SLASH).($rotatedName."\x2e")).($maxRotation+
(0x130f+  61-0x134b))));if (NXLogrotateDB::isCompressSet ($type)){(
$prevRotatedFile=($prevRotatedFile."\x2e\x67\x7a"));}for ((my $i=$maxRotation);(
$i>(0x00f3+ 9491-0x2606));(--$i)){(my $curRotatedFile=((($rotationDir.
$GLOBAL::DIRECTORY_SLASH).($rotatedName."\x2e")).$i));if (
NXLogrotateDB::isCompressSet ($type)){($curRotatedFile=($curRotatedFile.
"\x2e\x67\x7a"));}if (Common::NXFile::fileExists ($curRotatedFile)){($result=
Common::NXFile::renameFile ($curRotatedFile,$prevRotatedFile));if (($result==
(0x04b1+ 1549-0x0abe))){NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x52\x65\x6e\x61\x6d\x65\x46\x69\x6c\x65",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$curRotatedFile,$prevRotatedFile)
;return ((0x107d+ 4064-0x205d));}}($prevRotatedFile=$curRotatedFile);}return (
(0x142f+ 3612-0x224a));}sub __copyTruncate{(my $type=shift (@_));(my $path=shift
 (@_));(my $rotatedName=shift (@_));(my $destFilePath=
__getRotatedLogFilePathByLogType ($type,$rotatedName));(my $result=__copyLogFile
 ($path,$destFilePath));if (($result==(0x12b4+ 950-0x166a))){return (
(0x0a24+ 309-0x0b59));}return (__truncateFile ($path));}sub __removeExpiredLogs{
(my $type=shift (@_));(my $rotatedName=shift (@_));(my $rotationDir=
NXLogrotateDB::getDestination ($type));(my $maxRotation=NXLogrotateDB::getRotate
 ($type));(my $fileToRemove=((($rotationDir.$GLOBAL::DIRECTORY_SLASH).(
$rotatedName."\x2e")).($maxRotation+(0x09c6+ 4379-0x1ae0))));if (
NXLogrotateDB::isCompressSet ($type)){($fileToRemove=($fileToRemove.
"\x2e\x67\x7a"));}if (Common::NXFile::fileExists ($fileToRemove)){return (
Common::NXFile::removeFile ($fileToRemove));}return ((0x0dd4+ 6027-0x255e));}sub
 forcedRotate{(my $ref_parameters=shift (@_));(my $result=
__handleForcedRotateParameters ($ref_parameters));if (($result==
(0x010c+ 6408-0x1a14))){return ((0x13ca+ 4794-0x2684));}if (($$ref_parameters{
"\x74\x79\x70\x65"}and (not (isLogTypeSupported ($$ref_parameters{
"\x74\x79\x70\x65"}))))){(my (@supportedTypes)=getAllSupportedLogrotateLogTypes 
());NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x54\x79\x70\x65\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$$ref_parameters{
"\x74\x79\x70\x65"},join ($",@supportedTypes));return ((0x01cb+ 1705-0x0874));}(my $dateTime
=Common::NXTime::getDateTimeForFileName ());__setForcedRotateDateTime ($dateTime
);__setForcedRotate ();return (rotate ($$ref_parameters{"\x74\x79\x70\x65"}));}
sub rotate{(my $type=(shift (@_)||("")));Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x2e"
);NXMsg::send_response (
"\x69\x43\x4d\x44\x53\x74\x61\x72\x74\x69\x6e\x67\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65");if (($type ne (""))){
__rotateByLogType ($type);}else{rotateAllLogFiles ();}Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x68\x61\x73\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2e"
);}sub rotateAllLogFiles{main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42","\x69\x6e\x69\x74");(my (
@availableTypes)=());if (__isForcedRotate ()){(@availableTypes=
getAllSupportedLogrotateLogTypes ());}else{(@availableTypes=
NXLogrotateDB::getLogTypes ());}foreach my $availableType (@availableTypes){if (
__shouldSkipMultiTypeLogrotateForType ($availableType)){next;}__rotateByLogType 
($availableType);}}sub __rotateByLogType{(my $type=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x2e"));if (__isNotForcedRotate ()){main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42","\x69\x6e\x69\x74");if (
NXLogrotateDB::isNotLogrotateExist ($type)){Logger::error ((((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e\x20").
"\x4c\x6f\x67\x20\x74\x79\x70\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x2e"
));NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42",$type);NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$type);return (
(0x23c1+ 600-0x2619));}}($result=__rotateFilesByLogType ($type));if (($result==
(0x028a+ 5974-0x19e0))){Logger::error (((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e"));NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$type);}else{Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type).
"\x27\x20\x68\x61\x73\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
));NXMsg::send_response (
"\x69\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x69\x6e\x69\x73\x68\x65\x64"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$type);}return ($result);}sub 
__getUserLogFilePathsByType{(my $type=shift (@_));(my $ref_filePaths=shift (@_))
;(my (@filePaths)=());(my (%users)=
NXUsersManager::userListIncludingInternalDMUsers ());foreach my $user (keys (
%users)){if (NXUsersManager::isDMUser ($user)){($user=
NXUsersManager::getRealDMUsername ($user));}(my $fileName=__getFilenameByLogType
 ($type));(my $path=((Common::NXPaths::getNxDirectoryInUserHomeDirectory ($user)
.$GLOBAL::DIRECTORY_SLASH).$fileName));(my $rotatedName=($fileName.("\x2d".$user
)));($$ref_filePaths{$rotatedName}=$path);}}sub 
__getSpecialUserLogFilePathByType{(my $type=shift (@_));(my $ref_filePaths=shift
 (@_));(my $fileName=__getFilenameByLogType ($type));(my $path=((
Common::NXPaths::getSpecialUsersLogFolderPath ().$GLOBAL::DIRECTORY_SLASH).
$fileName));($$ref_filePaths{$fileName}=$path);}sub __getFilePathsByLogType{(my $type
=shift (@_));(my (%filePaths)=());if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){if (($GLOBAL::CommonLogDirectory ne 
(""))){(my $fileName=__getFilenameByLogType ($type));(my $rotateFileName=(
$fileName."\x2d\x63\x6f\x6d\x6d\x6f\x6e"));($filePaths{$rotateFileName}=((
$GLOBAL::CommonLogDirectory.$GLOBAL::DIRECTORY_SLASH).$fileName));}else{
__getUserLogFilePathsByType ($type,(\%filePaths));
__getSpecialUserLogFilePathByType ($type,(\%filePaths));}}else{(my $fileName=
__getFilenameByLogType ($type));($filePaths{$fileName}=__getFilePathByLogType (
$type));}return (%filePaths);}sub __rotateFilesByLogType{(my $type=shift (@_));(my $ref_filePaths
=shift (@_));(my $silent=(shift (@_)||(0x1d18+ 2060-0x2524)));(my (%filePaths)=
());if (__isNotForcedRotate ()){((%filePaths)=%$ref_filePaths);}else{((
%filePaths)=__getFilePathsByLogType ($type));}(my $filesCount=
(0x0963+ 1080-0x0d9b));(my $noExistPath=(""));(my $result=(0x137f+ 4121-0x2397))
;foreach my $rotatedName (keys (%filePaths)){(my $path=$filePaths{$rotatedName})
;if ((not (Common::NXFile::fileExists ($path)))){($noExistPath=$path);next;}(++
$filesCount);($result=__rotateWithCopytruncate ($type,$path,$rotatedName));if ((
$result!=(0x1bf8+ 587-0x1e43))){($result=__postRotate ($type,$rotatedName,
$silent));}}if (($filesCount==(0x0251+ 8277-0x22a6))){if ((scalar (@filePaths)>
(0x0892+ 1721-0x0f4a))){Logger::error ((((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e\x20").
"\x4e\x6f\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x73\x20\x66\x6f\x75\x6e\x64\x2e"))
;}else{Logger::error ((((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e\x20").((
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x27".$path).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e")));if ((
$silent==(0x1970+ 2933-0x24e5))){Common::NXMsg::error (
"\x65\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74",$noExistPath);}}if ((
$silent==(0x038f+ 6998-0x1ee5))){NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$noExistPath);}return (
(0x047f+ 3268-0x1143));}return ($result);}sub __postRotate{(my $type=shift (@_))
;(my $rotatedName=shift (@_));(my $silent=shift (@_));if (((__isForcedRotate ()
and __isForcedRotateCompress ())or ((not (__isForcedRotate ()))and 
NXLogrotateDB::isCompressSet ($type)))){(my $rotatedFile=
__getRotatedLogFilePathByLogType ($type,$rotatedName));($result=__compressFile (
$rotatedFile,$silent));if (($result==(0x09cd+ 7466-0x26f7))){return (
(0x0445+ 4919-0x177c));}Common::NXFile::removeFile ($rotatedFile);}return (
(0x136f+ 1358-0x18bc));}sub __rotateWithCopytruncate{(my $type=shift (@_));(my $path
=shift (@_));(my $rotatedName=shift (@_));if (__isNotForcedRotate ()){(my $result
=__rotateTillOriginalFile ($type,$rotatedName));__removeExpiredLogs ($type,
$rotatedName);if (($result==(0x10cb+ 4660-0x22ff))){return (
(0x00f9+ 2468-0x0a9d));}}return (__copyTruncate ($type,$path,$rotatedName));}sub
 __getRotatedLogFilePathByLogType{(my $type=shift (@_));(my $rotatedName=shift (
@_));if (__isNotForcedRotate ()){(my $destination=NXLogrotateDB::getDestination 
($type));return ((($destination.$GLOBAL::DIRECTORY_SLASH).($rotatedName.
"\x2e\x31")));}else{(my $destination=__getForcedRotateDestination ());return (((
($destination.$GLOBAL::DIRECTORY_SLASH).($rotatedName."\x2d")).
__getForcedRotateDateTime ()));}}sub __compressFile{(my $logFilePath=shift (@_))
;(my $silent=shift (@_));(my $compressedFile=($logFilePath."\x2e\x67\x7a"));(my $result
=Common::NXFile::compressFile ($logFilePath,$compressedFile));if (($result!=
(0x1305+ 4171-0x234f))){if (($silent==(0x0598+ 347-0x06f3))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6d\x70\x72\x65\x73\x73\x46\x69\x6c\x65"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$logFilePath);}return (
(0x0b9a+ 6543-0x2529));}else{if (($silent==(0x0d7f+ 1318-0x12a5))){
NXMsg::send_response (
"\x69\x43\x4d\x44\x43\x6f\x6d\x70\x72\x65\x73\x73\x65\x64\x46\x69\x6c\x65",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$compressedFile);}
__correctRotatedFileOwnershipAndPermissions ($compressedFile);return (
(0x12c7+ 2700-0x1d52));}}sub isTimeForCheckLogrotate{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=$__checkLogrotateDelay);if (
(($__lastCheckLogrotate+$delay)<$currentTime)){return ((0x06c2+ 3207-0x1348));}
return ((0x1035+ 1481-0x15fe));}sub checkLogrotateAndHandleIfNeeded{
Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x63\x68\x65\x64\x75\x6c\x65\x64\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x61\x6c\x6c\x20\x66\x69\x6c\x65\x73\x2e"
);($__lastCheckLogrotate=Common::NXTime::getSecondsSinceEpoch ());(my (
@typesToRotate)=());main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42");NXLogrotateDB::reload ()
;(my (@logTypes)=NXLogrotateDB::getLogTypes ());foreach my $type (@logTypes){(my $size
=NXLogrotateDB::getSizeInBytes ($type));(my $minsize=
NXLogrotateDB::getMinsizeInBytes ($type));(my $isTimeToRotate=
NXLogrotateDB::isTimeToRotate ($type));(my (%filePaths)=__getFilePathsByLogType 
($type));foreach my $fileName (keys (%filePaths)){(my $filePath=$filePaths{
$fileName});(my $fileSize=Common::NXCore::NXFileSize ($filePath));if (($size and
 ($size<=$fileSize))){return (__runLogrotateCommand ());}if ($isTimeToRotate){if
 (((not ($minsize))or ($minsize<$fileSize))){return (__runLogrotateCommand ());}
}}}}sub __runLogrotateCommand{(my $serverPath=(((((($GLOBAL::ETC_DIR.
$GLOBAL::DIRECTORY_SLASH)."\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x65\x78\x65"));(my (
@command)=($serverPath,"\x2d\x2d\x6c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x2d\x2d\x6e\x6f\x66\x6f\x72\x63\x65"));(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (@options
,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));
push (@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");main::nxRunCommand ((
\@command),(\@options));Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x6c\x6f\x67\x72\x6f\x74\x61\x74\x65\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x72\x75\x6e\x2e"
);}sub automaticRotate{(my (%typesToRotate)=());main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42");NXLogrotateDB::reload ()
;(my (@logTypes)=NXLogrotateDB::getLogTypes ());foreach my $type (@logTypes){(my $size
=NXLogrotateDB::getSizeInBytes ($type));(my $minsize=
NXLogrotateDB::getMinsizeInBytes ($type));(my $isTimeToRotate=
NXLogrotateDB::isTimeToRotate ($type));(my (%filePaths)=__getFilePathsByLogType 
($type));(my (%pathsToRotate)=());if (__shouldSkipMultiTypeLogrotateForType (
$type)){next;}foreach my $fileName (keys (%filePaths)){(my $filePath=$filePaths{
$fileName});(my $fileSize=Common::NXCore::NXFileSize ($filePath));if (($size and
 ($size<=$fileSize))){($pathsToRotate{$fileName}=$filePath);($typesToRotate{
$type}=(\%pathsToRotate));next;}if ($isTimeToRotate){if (((not ($minsize))or (
$minsize<$fileSize))){($pathsToRotate{$fileName}=$filePath);($typesToRotate{
$type}=(\%pathsToRotate));next;}}}}(my $silent=(0x04b3+ 764-0x07ae));foreach my $type
 (keys (%typesToRotate)){__rotateFilesByLogType ($type,$typesToRotate{$type},
$silent);NXLogrotateDB::updateLastRotateTime ($type);}}sub 
__getFilePathByLogType{(my $type=shift (@_));if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){return (
Common::NXPaths::getNXServerLogPath ());}elsif (($type eq 
Logger::getLogrotateLogTypeNxdLog ())){return (NXPaths::getNxdLog ());}elsif ((
$type eq Logger::getLogrotateLogTypeNwebclientLog ())){return (
NXPaths::getNxwebclientLog ());}elsif (($type eq 
Logger::getLogrotateLogTypeNxhtdErrorLog ())){if (($__nxhtdErrorLogPath eq (""))
){($__nxhtdErrorLogPath=NXTools::getNxhtdErrorLogPath ());}return (
$__nxhtdErrorLogPath);}elsif (($type eq Logger::getLogrotateLogTypeNxserviceLog 
())){return (NXPaths::getNxserviceLog ());}else{return ((""));}}sub 
__getFilenameByLogType{(my $type=shift (@_));if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){return (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67");}elsif (($type eq 
Logger::getLogrotateLogTypeNxdLog ())){return ("\x6e\x78\x64\x2e\x6c\x6f\x67");}
elsif (($type eq Logger::getLogrotateLogTypeNwebclientLog ())){return (
"\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e\x6c\x6f\x67");}elsif (($type 
eq Logger::getLogrotateLogTypeNxhtdErrorLog ())){return (
"\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67");}elsif (($type eq 
Logger::getLogrotateLogTypeNxserviceLog ())){return (
"\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e\x6c\x6f\x67");}else{return ((""));}}
sub isLogTypeSupported{(my $type=shift (@_));(my (@supportedTypes)=
getAllSupportedLogrotateLogTypes ());foreach my $supportedType (@supportedTypes)
{if (($supportedType eq $type)){return ((0x07ea+ 7166-0x23e7));}}return (
(0x1c3a+ 871-0x1fa1));}sub getAllSupportedLogrotateLogTypes{(my (@types)=());
push (@types,Logger::getLogrotateLogTypeNxserverLog ());push (@types,
Logger::getLogrotateLogTypeNxdLog ());if (NXLicense::isHttpdSupportFeature ()){
push (@types,Logger::getLogrotateLogTypeNwebclientLog ());push (@types,
Logger::getLogrotateLogTypeNxhtdErrorLog ());}push (@types,
Logger::getLogrotateLogTypeNxserviceLog ());return (@types);}sub 
__isTypeNxserverLog{(my $type=shift (@_));if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){return ((0x10a8+ 1841-0x17d8));}
return ((0x185b+ 3407-0x25aa));}sub __isTypeNxwebclientLog{(my $type=shift (@_))
;if (($type eq Logger::getLogrotateLogTypeNwebclientLog ())){return (
(0x18dd+ 591-0x1b2b));}return ((0x141f+ 1792-0x1b1f));}sub __truncateFile{(my $filePath
=shift (@_));(my $handle=main::nxopen ($filePath,($NXBits::O_WRONLY+
$NXBits::O_TRUNC)));if (defined ($handle)){main::nxclose ($handle);return (
(0x2184+ 609-0x23e4));}return ((0x17f3+ 1877-0x1f48));}sub __copyLogFile{(my $filePath
=shift (@_));(my $destFilePath=shift (@_));(my ($return,$error)=
Common::NXCore::copyFile ($filePath,$destFilePath));if (($error ne (""))){return
 ((0x0503+ 925-0x08a0));}__correctRotatedFileOwnershipAndPermissions (
$destFilePath);return ((0x021c+ 3297-0x0efc));}sub 
__correctRotatedFileOwnershipAndPermissions{(my $file=shift (@_));
Common::NXFile::setPermissionsReadWriteForNX ($file);if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($file);}return (
(0x1090+ 2433-0x1a10));}sub __setForcedRotateDateTime{($__forcedRotateDateTime=
shift (@_));}sub __getForcedRotateDateTime{return ($__forcedRotateDateTime);}sub
 __setForcedRotate{($__forcedRotate=(0x2541+ 330-0x268a));}sub __isForcedRotate{
return ($__forcedRotate);}sub __getForcedRotateDestination{return (
$$__ref_forcedRotateParameters{"\x64\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"});
}sub __isForcedRotateCompress{if (($$__ref_forcedRotateParameters{
"\x63\x6f\x6d\x70\x72\x65\x73\x73"}eq "\x6e\x6f")){return ((0x15af+ 3518-0x236d)
);}else{return ((0x1ebb+ 1056-0x22da));}}sub __isNotForcedRotate{return ((!
__isForcedRotate ()));}sub __handleForcedRotateParameters{(my $ref_parameters=
shift (@_));($__ref_forcedRotateParameters=$ref_parameters);main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42","\x69\x6e\x69\x74");(my $procedure
="\x66\x6f\x72\x63\x65\x64\x52\x6f\x74\x61\x74\x65");return (
NXLogrotateDB::handleDestinationAndCompressParameters ($ref_parameters,
$procedure));}sub __shouldSkipMultiTypeLogrotateForType{(my $type=shift (@_));if
 (__isTypeNxwebclientLog ($type)){if ((not (Common::NXFile::fileExists (
__getFilePathByLogType ($type))))){return ((0x0555+ 6012-0x1cd0));}}return (
(0x091d+ 3607-0x1734));}NXMsg::register_response (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x69\x43\x4d\x44\x53\x74\x61\x72\x74\x69\x6e\x67\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65"
,(0x0c97+ 6341-0x21d8));NXMsg::register_response (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x69\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x69\x6e\x69\x73\x68\x65\x64"
,(0x1551+ 2302-0x1acb));NXMsg::register_response (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x69\x43\x4d\x44\x43\x6f\x6d\x70\x72\x65\x73\x73\x65\x64\x46\x69\x6c\x65",
(0x1538+ 3265-0x1e75));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
(0x0fe4+ 4353-0x1ef1));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x46\x69\x6c\x65\x49\x73\x42\x65\x69\x6e\x67\x55\x73\x65\x64",
(0x0678+ 6796-0x1f10));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6d\x70\x72\x65\x73\x73\x46\x69\x6c\x65"
,(0x1bb8+ 2337-0x22e5));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x54\x79\x70\x65\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
,(0x19f0+ 2205-0x2099));"\x3f\x3f\x3f";
