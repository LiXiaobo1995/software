############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTwoFactorLoginDB::BEGIN{package NXTwoFactorLoginDB;no warnings;require 
Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
NXTwoFactorLoginDB::savePublicKey{package NXTwoFactorLoginDB;no warnings;(my $user
=main::urlencode (shift (@_)));(my $key=main::urlencode (shift (@_)));if (($user
 eq (""))){Logger::warning (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x74\x68\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x2e"
);return ((0x2646+ 178-0x26f8));}if (($key eq (""))){Logger::warning (((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x65\x6d\x70\x74\x79\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$user)."\x27\x2e"));return ((0x0cf9+ 642-0x0f7b));}__lock ();(my $file=
NXPaths::getTwoFactorPublicKeys ());(my $openMode=(($NXBits::O_CREAT+
$NXBits::O_WRONLY)+$NXBits::O_APPEND));(my $FD=main::nxopen ($file,$openMode,
$NXBits::UserReadWrite));if ((not (defined ($FD)))){(my $error=
libnxh::NXGetError ());(my $errorName=libnxh::NXGetErrorName ());(my $errorString
=libnxh::NXGetErrorString ());if (($errorName eq "\x45\x41\x43\x43\x45\x53")){if
 ((Common::NXCore::removeReadOnlyAttributeOnWindows ($file)==
(0x0506+ 379-0x0680))){($FD=main::nxopen ($file,$openMode,$NXBits::UserReadWrite
));($error=libnxh::NXGetError ());($errorString=libnxh::NXGetErrorString ());}}
if ((not (defined ($FD)))){Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x74\x6f\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x2e").(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".
$errorString)."\x27\x2c\x20").$error)."\x2e")));__unlock ();return (
(0x06e9+ 5621-0x1cde));}}(my $data=((($user."\x20").$key)."\x0a"));if ((
main::nxwrite ($FD,$data)==(-(0x1335+ 4053-0x2309)))){(my $error=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
main::nxclose ($FD);Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x74\x6f\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x2e").(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".
$errorString)."\x27\x2c\x20").$error)."\x2e")));__unlock ();return (
(0x0081+ 1860-0x07c5));}main::nxclose ($FD);__unlock ();return (
(0x0159+ 2320-0x0a68));}sub NXTwoFactorLoginDB::getPublicKeys{package 
NXTwoFactorLoginDB;no warnings;(my $user=shift (@_));(my (@keys)=
getAllPublicKeys ());(my (@userKeys)=());for ((my $i=(0x039f+ 274-0x04b1));($i<
@keys);($i=($i+(0x1a44+ 318-0x1b80)))){if (($user eq @keys[$i])){push (@userKeys
,$keys[$i+(0x1e6a+ 1501-0x2446)]);}}return (@userKeys);}sub 
NXTwoFactorLoginDB::getAllPublicKeys{package NXTwoFactorLoginDB;no warnings;(my $file
=NXPaths::getTwoFactorPublicKeys ());unless (Common::NXFile::isExists ($file)){
Logger::debug (((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"))
;return (());}__lockShared ();(my $fileHandle=main::nxopen ($file,
$NXBits::O_RDONLY));unless (defined ($fileHandle)){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::debug ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x2e").((((
"\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorString)."\x27\x2c\x20").
$errorNumber)."\x2e")));__unlock ();return (());}(my (@content)=());while (
main::nxreadLine ($fileHandle,(\$_))){chomp ($_);(my ($user,$key)=split ( / / ,
$_,(0x1b95+ 1423-0x2121)));($user=main::urldecode ($user));($key=main::urldecode
 ($key));Logger::debug3 (((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x55\x73\x65\x72\x20\x27"
.$user)."\x27\x20\x6b\x65\x79\x20\x27").$key)."\x27\x2e"));push (@content,$user,
$key);}main::nxclose ($fileHandle);__unlock ();return (@content);}sub 
NXTwoFactorLoginDB::removeUserKeys{package NXTwoFactorLoginDB;no warnings;(my $username
=shift (@_));(my $file=NXPaths::getTwoFactorPublicKeys ());(my $tempFile=(($file
."\x2e\x74\x6d\x70\x2e").$ $));
 unless (Common::NXFile::isExists ($file)){
Logger::warning (((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"))
;return ((0x0346+ 4999-0x16cd));}__lock ();(my $FD=main::nxopen ($file,
$NXBits::O_RDONLY));unless (defined ($FD)){(my $errorNumber=libnxh::NXGetError 
());(my $errorString=libnxh::NXGetErrorString ());Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x2e").((((
"\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorString)."\x27\x2c\x20").
$errorNumber)."\x2e")));__unlock ();return ((0x0ecc+ 4833-0x21ad));}if (
Common::NXFile::isExists ($tempFile)){unlink ($tempFile);}(my $openMode=((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND));(my $tempFD=main::nxopen
 ($tempFile,$openMode,$NXBits::UserReadWrite));unless (defined ($tempFD)){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x27"
.$tempFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x65\x2e").((((
"\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorString)."\x27\x2c\x20").
$errorNumber)."\x2e")));__unlock ();return ((0x01c5+ 3323-0x0ec0));}&try (sub{
while (main::nxreadLine ($FD,(\$_))){(my $line=$_);chomp ($line);(my ($keyUser,
$key)=split ( / / ,$line,(0x2093+ 599-0x22e7)));($keyUser=main::urldecode (
$keyUser));if (($keyUser eq $username)){($flag_del=(0x2493+ 330-0x25dc));}else{
Common::NXCore::nxwriteOrThrowException ($tempFD,$_);}}},&otherwise (sub{(my $error
=shift (@_));main::nxclose ($tempFD);main::nxclose ($FD);__unlock ();
Logger::error (((
"\x55\x6e\x65\x78\x70\x65\x63\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x61\x76\x65\x64\x20\x75\x73\x65\x72\x20\x74\x77\x6f\x20\x66\x61\x63\x74\x6f\x72\x20\x6b\x65\x79\x2e\x20"
.$error)."\x2e"));return ((0x195a+ 392-0x1ae2));}));main::nxclose ($tempFD);
main::nxclose ($FD);if ((not (rename ($tempFile,$file)))){__unlock ();
Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$tempFile)."\x27\x20\x74\x6f\x20\x27").$file)."\x27\x2e\x20").$!));return (
(0x0390+ 2775-0x0e67));}(my ($errorName),$errorCode);if ((
Common::NXFile::setOwnerShipAndPermissionsForNX ($file,(\$errorName),(
\$errorCode))==(-(0x11ef+ 317-0x132b)))){__unlock ();Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x27\x6e\x78\x27\x20\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x6e\x78\x2e\x20").
$errorName));return ((0x11c9+ 967-0x1590));}__unlock ();return ($flag_del);}
package NXTwoFactorLoginDB;no warnings;my ($lockFD);sub __lock{(my $lockMode=(
shift (@_)||$NXBits::LOCK_EX));(my $lockFile=(NXPaths::getTwoFactorPublicKeys ()
."\x2e\x6c\x6f\x63\x6b"));(my $openMode=(($NXBits::O_CREAT+$NXBits::O_WRONLY)+
$NXBits::O_APPEND));($lockFD=main::nxopen ($lockFile,$openMode,
$NXBits::UserReadWrite));if ((not (defined ($lockFD)))){(my $error=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$lockFile)."\x27\x2e").(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".
$errorString)."\x27\x2c\x20").$error)."\x2e")));return ((0x0574+ 7011-0x20d7));}
main::nxflock ($lockFD,$lockMode);}sub __lockShared{return (__lock (
$NXBits::LOCK_SH));}sub __unlock{if (defined ($lockFD)){main::nxclose ($lockFD);
}($lockFD=undef);}return ((0x15a1+ 2872-0x20d8));
