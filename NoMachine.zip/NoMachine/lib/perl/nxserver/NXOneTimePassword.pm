############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXOneTimePassword::create{package NXOneTimePassword;no warnings;(my $ref_parameters
=shift (@_));main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);(my $password=NXClientSystemDaemons::askNXServerDaemonForCreateOneTimePassword
 ($ref_parameters));if (($password=~ /$GLOBAL::MSG_OTP_CREATE User password=(.*) / )
){(my $password=$1);if ((NXMsg::send_response (
"\x72\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64",
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64",$password
)==(-(0x0810+ 240-0x08ff)))){return ((-(0x1b10+ 771-0x1e12)));}return (
(0x0cca+ 1144-0x1141));}return ((0x0c66+ 3173-0x18cb));}sub 
NXOneTimePassword::authorize{package NXOneTimePassword;no warnings;(my $login=
shift (@_));(my $password=shift (@_));(my (%user)=());($user{
"\x6c\x6f\x67\x69\x6e"}=$login);($user{"\x70\x61\x73\x73\x77\x6f\x72\x64"}=
$password);(my $timeout=($GLOBAL::AuthorizationTimeout *(0x15f6+ 4649-0x2437)));
main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);(my $answer=
NXClientSystemDaemons::askNXServerDaemonForOneTimePasswordAuthorization ((\%user
),$timeout));if (($answer=~ /Kerberos forwarding serverCookie=(.*) serverPort=(.*) NCMName=(.*) / )
){(my $serverCookie=$1);(my $serverPort=$2);(my $NCMName=$3);
NXServers::setForwardKerberosTicketFromMainServer ($serverPort,$serverCookie,
$NCMName);return ((0x072f+ 7156-0x2322));}if (($answer=~ /User authorized/ )){
return ((0x0c85+ 3417-0x19dd));}return ((0x1c2f+ 499-0x1e22));}sub 
NXOneTimePassword::__getOptions{package NXOneTimePassword;no warnings;(my $line=
shift (@_));($line=~ s/Create one-time password // );($line=~ s/"//g );($line=~ s/\s*$// )
;(my (%options)=());(my (@args)=split ( / / ,$line,(0x19ab+ 3371-0x26d6)));
foreach my $pair (@args){(my ($key,$value)=split ( /=/ ,$pair,
(0x12ff+ 3451-0x2077)));($options{$key}=$value);}return ((\%options));}sub 
NXOneTimePassword::parseMessage{package NXOneTimePassword;no warnings;(my $socket
=shift (@_));(my $request=shift (@_));Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6f\x6e\x65\x20\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x2e"));if (($request=~ /Create one-time password login=(.*) serverCookie=(.*) serverPort=(.*) NCMName=(.*) rules=(\S*) / )
){(my $login=main::urldecode ($1));(my $serverCookie=$2);(my $serverPort=$3);(my $NCMName
=$4);(my $rules=$5);(my $sessionID=(""));if (($request=~ /sessionID=(\S*) / )){(
$sessionID=$1);}(my $ref_options=__getOptions ($request));return (__handleCreate
 ($socket,$login,$serverCookie,$serverPort,$NCMName,$rules,$sessionID,
$ref_options));}elsif (($request=~ /One-time password authorization login=(.*) password=(.*) type=(.*) / )
){(my $login=main::urldecode ($1));(my $password=main::urldecode ($2));(my $type
=main::urldecode ($3));return (__handleAuthorization ($socket,$login,$password,
$type));}Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x6f\x6e\x65\x20\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x2e"));return ((0x181d+ 2286-0x210b));}package 
NXOneTimePassword;no warnings;(my (%__oneTimePassswords)=());sub __handleCreate{
(my $socket=shift (@_));(my $login=shift (@_));(my $serverCookie=shift (@_));(my $serverPort
=shift (@_));(my $NCMName=shift (@_));(my $rules=shift (@_));(my $sessionID=
shift (@_));(my $ref_options=shift (@_));if (((
NXGuestsManager::isGuestByUsername ($login)or 
NXGuestsManager::isRequestForNewGuestAccount ($login))or 
NXGuestsManager::isServerBrowseGuestAccountName ($login))){($login=
NXGuestsManager::getRequestForNewGuestAccount ());}(my $password=
main::get_unique_id ());(my $generationTime=Common::NXTime::getSecondsSinceEpoch
 ());($__oneTimePassswords{$login}{$password}{"\x74\x69\x6d\x65"}=
$generationTime);($__oneTimePassswords{$login}{$password}{"\x70\x61\x6d"}=
(0x06d7+ 2815-0x11d6));($__oneTimePassswords{$login}{$password}{
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6f\x6b\x69\x65"}=$serverCookie);(
$__oneTimePassswords{$login}{$password}{
"\x73\x65\x72\x76\x65\x72\x50\x6f\x72\x74"}=$serverPort);($__oneTimePassswords{
$login}{$password}{"\x4e\x43\x4d\x4e\x61\x6d\x65"}=$NCMName);(
$__oneTimePassswords{$login}{$password}{"\x72\x75\x6c\x65\x73"}=$rules);(
$__oneTimePassswords{$login}{$password}{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x44"}=
$sessionID);($__oneTimePassswords{$login}{$password}{
"\x61\x6c\x6c\x6f\x77\x56\x69\x73\x69\x74\x6f\x72\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
}=$$ref_options{
"\x61\x6c\x6c\x6f\x77\x56\x69\x73\x69\x74\x6f\x72\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
});($__oneTimePassswords{$login}{$password}{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
}=$$ref_options{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
});($__oneTimePassswords{$login}{$password}{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x43\x72\x65\x61\x74\x65\x56\x69\x72\x74\x75\x61\x6c"
}=$$ref_options{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x43\x72\x65\x61\x74\x65\x56\x69\x72\x74\x75\x61\x6c"
});($__oneTimePassswords{$login}{$password}{
"\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x63\x63\x65\x73\x73"}=$$ref_options{
"\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x63\x63\x65\x73\x73"});(
$__oneTimePassswords{$login}{$password}{
"\x76\x69\x72\x74\x75\x61\x6c\x41\x63\x63\x65\x73\x73"}=$$ref_options{
"\x76\x69\x72\x74\x75\x61\x6c\x41\x63\x63\x65\x73\x73"});($__oneTimePassswords{
$login}{$password}{"\x76\x69\x73\x69\x74\x6f\x72"}=$$ref_options{
"\x76\x69\x73\x69\x74\x6f\x72"});($__oneTimePassswords{$login}{$password}{
"\x76\x69\x73\x69\x74\x6f\x72\x48\x6f\x73\x74"}=$$ref_options{
"\x76\x69\x73\x69\x74\x6f\x72\x48\x6f\x73\x74"});($__oneTimePassswords{$login}{
$password}{"\x76\x69\x73\x69\x74\x6f\x72\x4c\x6f\x6e\x67\x4e\x61\x6d\x65"}=
$$ref_options{"\x76\x69\x73\x69\x74\x6f\x72\x4c\x6f\x6e\x67\x4e\x61\x6d\x65"});
Logger::debug (((
"\x47\x65\x6e\x65\x72\x61\x74\x65\x20\x4f\x54\x50\x20\x66\x6f\x72\x20\x6c\x6f\x67\x69\x6e\x20\x27"
.$login)."\x27\x2e"));main::nxwrite ($socket,(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_OTP_CREATE).
"\x20\x55\x73\x65\x72\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x3d").$password).
"\x20\x0a"));return ((0x09f2+ 4656-0x1c22));}sub __handleAuthorization{(my $socket
=shift (@_));(my $login=shift (@_));(my $password=shift (@_));(my $type=shift (
@_));if (((NXGuestsManager::isGuestByUsername ($login)or 
NXGuestsManager::isRequestForNewGuestAccount ($login))or 
NXGuestsManager::isServerBrowseGuestAccountName ($login))){($login=
NXGuestsManager::getRequestForNewGuestAccount ());}Logger::debug (((
"\x4f\x54\x50\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x6c\x6f\x67\x69\x6e\x20\x27"
.$login)."\x27\x2e"));(my $ref_user=$__oneTimePassswords{$login});if ((
$__oneTimePassswords{$login}eq (""))){main::nxwrite ($socket,((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_OTP_AUTH).
"\x20\x55\x73\x65\x72\x20\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x3a\x20\x57\x72\x6f\x6e\x67\x20\x6c\x6f\x67\x69\x6e\x2e\x20\x0a"
));return ((0x0056+ 8210-0x2068));}foreach my $otp (keys (%{$__oneTimePassswords
{$login};})){if (($otp eq $password)){(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $generationTime=
$__oneTimePassswords{$login}{$otp}{"\x74\x69\x6d\x65"});if (($type eq 
"\x70\x61\x6d")){if (($__oneTimePassswords{$login}{$otp}{"\x70\x61\x6d"}==
(0x1a98+ 2615-0x24ce))){main::nxwrite ($socket,(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_OTP_AUTH).
"\x20\x55\x73\x65\x72\x20\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x3a\x20\x57\x72\x6f\x6e\x67\x20\x6c\x6f\x67\x69\x6e\x2e\x20\x0a"
));return ((0x134b+ 309-0x1480));}else{($__oneTimePassswords{$login}{$otp}{
"\x70\x61\x6d"}=(0x1803+ 2377-0x214b));}}if ((($currentTime-$generationTime)<
$GLOBAL::OneTimePasswordValidityPeriod)){(my $message=(""));if ((($type eq 
"\x73\x65\x72\x76\x65\x72")and ($__oneTimePassswords{$login}{$otp}{
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6f\x6b\x69\x65"}ne ("")))){($message=((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_OTP_AUTH).
"\x20\x55\x73\x65\x72\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x2e\x20"));(
$message.=
"\x4b\x65\x72\x62\x65\x72\x6f\x73\x20\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x20"
);($message.=(("\x73\x65\x72\x76\x65\x72\x43\x6f\x6f\x6b\x69\x65\x3d".
$__oneTimePassswords{$login}{$otp}{
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6f\x6b\x69\x65"})."\x20"));($message.=((
"\x73\x65\x72\x76\x65\x72\x50\x6f\x72\x74\x3d".$__oneTimePassswords{$login}{$otp
}{"\x73\x65\x72\x76\x65\x72\x50\x6f\x72\x74"})."\x20"));($message.=((
"\x4e\x43\x4d\x4e\x61\x6d\x65\x3d".$__oneTimePassswords{$login}{$otp}{
"\x4e\x43\x4d\x4e\x61\x6d\x65"})."\x20"));}else{($message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_OTP_AUTH).
"\x20\x55\x73\x65\x72\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x2e\x20"));}(
$message.="\x0a");main::nxwrite ($socket,$message);}else{main::nxwrite ($socket,
(("\x4e\x58\x3e\x20".$GLOBAL::MSG_OTP_AUTH).
"\x20\x55\x73\x65\x72\x20\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x3a\x20\x56\x61\x6c\x69\x64\x69\x74\x79\x20\x70\x65\x72\x69\x6f\x64\x20\x65\x78\x63\x65\x65\x64\x65\x64\x2e\x20\x0a"
));}return ((0x168c+ 4125-0x26a9));}}main::nxwrite ($socket,(("\x4e\x58\x3e\x20"
.$GLOBAL::MSG_OTP_AUTH).
"\x20\x55\x73\x65\x72\x20\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x2e\x20\x0a"
));return ((0x0810+ 4220-0x188c));}sub parsePropagationRulesAndSessionIDRequest{
(my $socket=shift (@_));(my $request=shift (@_));Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x20\x72\x75\x6c\x65\x73\x20\x61\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x2e"));if (($request=~ /login=(.*) otp=(.*) / )){(my $login=
main::urldecode ($1));(my $otp=main::urldecode ($2));return (
sendPropagationRulesAndSessionID ($socket,$login,$otp));}Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x20\x72\x75\x6c\x65\x73\x20\x61\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x2e"));return ((0x0703+ 1622-0x0d59));}sub 
sendPropagationRulesAndSessionID{(my $socket=shift (@_));(my $login=shift (@_));
(my $otp=shift (@_));if (((NXGuestsManager::isGuestByUsername ($login)or 
NXGuestsManager::isRequestForNewGuestAccount ($login))or 
NXGuestsManager::isServerBrowseGuestAccountName ($login))){($login=
NXGuestsManager::getRequestForNewGuestAccount ());}Logger::debug (((
"\x53\x65\x6e\x64\x20\x4f\x54\x50\x20\x72\x75\x6c\x65\x20\x61\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x20\x66\x6f\x72\x20\x27"
.$login)."\x27\x2e"));(my $currentTime=Common::NXTime::getSecondsSinceEpoch ());
(my $generationTime=$__oneTimePassswords{$login}{$otp}{"\x74\x69\x6d\x65"});if (
(($currentTime-$generationTime)<$GLOBAL::OneTimePasswordValidityPeriod)){(my $message
=(("\x4e\x58\x3e\x20".$GLOBAL::MSG_PROPAGATION_RULES_AND_SESSION_ID)."\x20"));if
 (($__oneTimePassswords{$login}{$otp}{
"\x61\x6c\x6c\x6f\x77\x56\x69\x73\x69\x74\x6f\x72\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
}ne (""))){($message.=((
"\x61\x6c\x6c\x6f\x77\x56\x69\x73\x69\x74\x6f\x72\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67\x3d"
.$__oneTimePassswords{$login}{$otp}{
"\x61\x6c\x6c\x6f\x77\x56\x69\x73\x69\x74\x6f\x72\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
})."\x20"));}if (($__oneTimePassswords{$login}{$otp}{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
}ne (""))){($message.=((
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67\x3d"
.$__oneTimePassswords{$login}{$otp}{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x44\x65\x73\x6b\x74\x6f\x70\x53\x68\x61\x72\x69\x6e\x67"
})."\x20"));}if (($__oneTimePassswords{$login}{$otp}{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x43\x72\x65\x61\x74\x65\x56\x69\x72\x74\x75\x61\x6c"
}ne (""))){($message.=((
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x43\x72\x65\x61\x74\x65\x56\x69\x72\x74\x75\x61\x6c\x3d"
.$__oneTimePassswords{$login}{$otp}{
"\x61\x6c\x6c\x6f\x77\x47\x75\x65\x73\x74\x43\x72\x65\x61\x74\x65\x56\x69\x72\x74\x75\x61\x6c"
})."\x20"));}if (($__oneTimePassswords{$login}{$otp}{
"\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x63\x63\x65\x73\x73"}ne (""))){($message.=
(("\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x63\x63\x65\x73\x73\x3d".
$__oneTimePassswords{$login}{$otp}{
"\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x63\x63\x65\x73\x73"})."\x20"));}if ((
$__oneTimePassswords{$login}{$otp}{
"\x76\x69\x72\x74\x75\x61\x6c\x41\x63\x63\x65\x73\x73"}ne (""))){($message.=((
"\x76\x69\x72\x74\x75\x61\x6c\x41\x63\x63\x65\x73\x73\x3d".$__oneTimePassswords{
$login}{$otp}{"\x76\x69\x72\x74\x75\x61\x6c\x41\x63\x63\x65\x73\x73"})."\x20"));
}if (($__oneTimePassswords{$login}{$otp}{"\x76\x69\x73\x69\x74\x6f\x72"}ne (""))
){($message.=(("\x76\x69\x73\x69\x74\x6f\x72\x3d".$__oneTimePassswords{$login}{
$otp}{"\x76\x69\x73\x69\x74\x6f\x72"})."\x20"));}if (($__oneTimePassswords{
$login}{$otp}{"\x76\x69\x73\x69\x74\x6f\x72\x48\x6f\x73\x74"}ne (""))){($message
.=(("\x76\x69\x73\x69\x74\x6f\x72\x48\x6f\x73\x74\x3d".$__oneTimePassswords{
$login}{$otp}{"\x76\x69\x73\x69\x74\x6f\x72\x48\x6f\x73\x74"})."\x20"));}if ((
$__oneTimePassswords{$login}{$otp}{
"\x76\x69\x73\x69\x74\x6f\x72\x4c\x6f\x6e\x67\x4e\x61\x6d\x65"}ne (""))){(
$message.=(("\x76\x69\x73\x69\x74\x6f\x72\x4c\x6f\x6e\x67\x4e\x61\x6d\x65\x3d".
$__oneTimePassswords{$login}{$otp}{
"\x76\x69\x73\x69\x74\x6f\x72\x4c\x6f\x6e\x67\x4e\x61\x6d\x65"})."\x20"));}if ((
$__oneTimePassswords{$login}{$otp}{"\x72\x75\x6c\x65\x73"}ne (""))){($message.=(
("\x72\x75\x6c\x65\x73\x3d".$__oneTimePassswords{$login}{$otp}{
"\x72\x75\x6c\x65\x73"})."\x20"));}else{($message.=
"\x72\x75\x6c\x65\x73\x3d\x30\x20");}if (($__oneTimePassswords{$login}{$otp}{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x44"}ne (""))){($message.=((
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x3d".$__oneTimePassswords{$login}{$otp}{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x44"})."\x20"));}else{($message.=
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x3d\x20");}Logger::debug (((
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64\x3a\x20\x50\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));main::nxwrite ($socket,($message."\x0a"));}else{
Logger::debug (((
"\x52\x75\x6c\x65\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x20\x61\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x3a\x20\x4f\x54\x50\x20\x68\x61\x73\x20\x65\x78\x70\x69\x72\x65\x64\x20\x66\x6f\x72\x20\x27"
.$login)."\x27\x2e"));main::nxwrite ($socket,(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_PROPAGATION_RULES_AND_SESSION_ID).
"\x20\x4f\x6e\x65\x20\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x68\x61\x73\x20\x65\x78\x70\x69\x72\x65\x64\x20\x0a"
));}if (defined ($__oneTimePassswords{$login}{$otp})){($__oneTimePassswords{
$login}{$otp}{"\x74\x69\x6d\x65"}=(""));delete ($__oneTimePassswords{$login}{
$otp});}return ((0x0d51+ 1461-0x1306));}sub parseNCMNameRequest{(my $socket=
shift (@_));(my $request=shift (@_));Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x4e\x43\x4d\x4e\x61\x6d\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x2e"));if (($request=~ /login=(.*) otp=(.*) / )){(my $login=
main::urldecode ($1));(my $otp=main::urldecode ($2));(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $generationTime=
$__oneTimePassswords{$login}{$otp}{"\x74\x69\x6d\x65"});if ((($currentTime-
$generationTime)<$GLOBAL::OneTimePasswordValidityPeriod)){if ((
$__oneTimePassswords{$login}{$otp}{"\x4e\x43\x4d\x4e\x61\x6d\x65"}ne (""))){
main::nxwrite ($socket,(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_NCM_NAME).
"\x20\x4e\x43\x4d\x4e\x61\x6d\x65\x3d").$__oneTimePassswords{$login}{$otp}{
"\x4e\x43\x4d\x4e\x61\x6d\x65"})."\x20\x0a"));}else{main::nxwrite ($socket,((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_NCM_NAME).
"\x20\x4e\x43\x4d\x4e\x61\x6d\x65\x3d\x30\x20\x0a"));}}else{main::nxwrite (
$socket,(("\x4e\x58\x3e\x20".$GLOBAL::MSG_NCM_NAME).
"\x20\x4f\x6e\x65\x20\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x68\x61\x73\x20\x65\x78\x70\x69\x72\x65\x64\x20\x0a"
));}return ((0x157b+ 180-0x162f));}Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x4e\x43\x4d\x4e\x61\x6d\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x2e"));return ((0x03ac+ 6720-0x1dec));}NXMsg::register_response
 ("\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64",
"\x72\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64",
$GLOBAL::MSG_OTP_CREATE);return ((0x007c+ 4482-0x11fd));
