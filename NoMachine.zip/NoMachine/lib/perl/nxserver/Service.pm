############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Service::isNXHtdAvailable{package Service;no warnings;(my $command=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x68\x74\x64"));(my $command=($command.
"\x2e\x65\x78\x65"));if (Common::NXFile::isExists ($command)){return (
(0x0916+  15-0x0924));}return ((0x0358+ 7601-0x2109));}sub 
Service::isNXDAvailable{package Service;no warnings;(my $command=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64"));(my $command=($command.
"\x2e\x65\x78\x65"));if (Common::NXFile::isExists ($command)){return (
(0x2390+ 444-0x254b));}return ((0x05bb+ 1631-0x0c1a));}sub Service::stop{package
 Service;no warnings;(my $ref_parameters=shift (@_));if (($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne (""))){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((NXServers::normalizeTargetParameter
 ($ref_parameters)==(-(0x0ce6+ 6679-0x26fc)))){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x18ca+ 131-0x194c));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x09b6+ 1895-0x111d));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x1975+ 2352-0x22a4))){($isForwarded=
(0x0a72+ 1201-0x0f22));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x1d8b+ 2285-0x2677));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x6f\x70",
$ref_parameters);if (($isForwarded==(0x0729+ 4556-0x18f4))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x1a98+ 2921-0x2600));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x1716+ 2941-0x2292))
){NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}
main::nxrequire ("\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73")
;if (($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x68\x74\x64")
){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){if (isNXHtdAvailable
 ()){return (NXShell::handle_command ("\x6e\x78\x68\x74\x64",
"\x6e\x78\x68\x74\x64","\x73\x74\x6f\x70"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x68\x74\x64"));}return (NXMsg::error (
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x53\x65\x72\x76\x69\x63\x65"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x64")){if (isNXDAvailable ()){return
 (NXShell::handle_command ("\x6e\x78\x64","\x6e\x78\x64","\x73\x74\x6f\x70"));}
return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x64"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x73\x73\x68\x64")){sub BEGIN{require
 NXWindowsServices;do{
"\x4e\x58\x57\x69\x6e\x64\x6f\x77\x73\x53\x65\x72\x76\x69\x63\x65\x73"->import};
}if (NXLicense::isSshFeature ()){return (NXWindowsServices::stopService (
"\x6e\x78\x73\x73\x68\x64"));}}(my $error=setStopFlag ());if (($error==
(0x00c6+ 9162-0x2490))){if (($$ref_parameters{"\x73\x69\x6c\x65\x6e\x63\x65"}!=
(0x0f37+ 5944-0x266e))){NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x64\x69\x73\x61\x62\x6c\x65\x64");}main::sendServerStatus ("\x73\x74\x6f\x70")
;}else{if (($$ref_parameters{"\x73\x69\x6c\x65\x6e\x63\x65"}!=
(0x0730+ 7086-0x22dd))){Common::NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x46\x69\x6c\x65"
,$GLOBAL::ServerStopStatusFlagLink,$errorString);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::informAboutServerStatusChange ();return (
(0x12ac+ 4526-0x245a));}sub Service::setStopFlag{package Service;no warnings;if 
(Common::NXFile::isExists ($GLOBAL::ServerStopStatusFlagLink)){return (
(0x0c65+ 2320-0x1575));}(my $FH=main::nxopen ($GLOBAL::ServerStopStatusFlagLink,
($NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead
)+$NXBits::OthersRead)));if ((not (defined ($FH)))){return (
(0x0364+ 8919-0x263a));}main::nxclose ($FH);return ((0x00e7+ 2998-0x0c9d));}sub 
Service::start{package Service;no warnings;(my $ref_parameters=shift (@_));if ((
$$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne (""))){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((NXServers::normalizeTargetParameter
 ($ref_parameters)==(-(0x183c+ 3056-0x242b)))){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x0464+ 3800-0x133b));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x02c2+ 5428-0x17f6));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0d2a+ 4566-0x1eff))){($isForwarded=
(0x2092+ 1593-0x26ca));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x01f8+ 4664-0x142f));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x61\x72\x74",
$ref_parameters);if (($isForwarded==(0x1c24+ 943-0x1fd2))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x0f28+ 1077-0x135c));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0768+ 2826-0x1271))
){NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}
main::nxrequire ("\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73")
;if (($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x68\x74\x64")
){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){if (isNXHtdAvailable
 ()){return (NXShell::handle_command ("\x6e\x78\x68\x74\x64",
"\x6e\x78\x68\x74\x64","\x73\x74\x61\x72\x74"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x68\x74\x64"));}return (NXMsg::error (
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x53\x65\x72\x76\x69\x63\x65"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x64")){if (isNXDAvailable ()){return
 (NXShell::handle_command ("\x6e\x78\x64","\x6e\x78\x64","\x73\x74\x61\x72\x74")
);}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x64"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x73\x73\x68\x64")){sub BEGIN{require
 NXWindowsServices;do{
"\x4e\x58\x57\x69\x6e\x64\x6f\x77\x73\x53\x65\x72\x76\x69\x63\x65\x73"->import};
}if (NXLicense::isSshFeature ()){return (NXWindowsServices::startService (
"\x6e\x78\x73\x73\x68\x64"));}}main::nxrequire (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");main::nxrequire 
("\x4e\x58\x53\x74\x61\x72\x74\x75\x70");(my $silence=$$ref_parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"});if (($$ref_parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"}eq (""))){($silence=(0x186c+ 2420-0x21e0));}if ((
not (Server::isClientConnectionOpen ()))){($silence=(0x0aed+ 3558-0x18d2));}(my $error
=(0x0973+ 1702-0x1019));if (Common::NXFile::isExists (
$GLOBAL::ServerStopStatusFlagLink)){if ((not (Common::NXFile::removeFile (
$GLOBAL::ServerStopStatusFlagLink)))){if (($silence==(0x0033+ 5855-0x1712))){(my $errorString
=libnxh::NXGetErrorString ());Common::NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x52\x65\x6d\x6f\x76\x65\x46\x69\x6c\x65"
,$GLOBAL::ServerStopStatusFlagLink,$errorString);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}($error=(0x0864+ 635-0x0ade));}}if (((
$error==(0x023a+ 4908-0x1566))and ($silence==(0x0600+ 8253-0x263d)))){if (
NXSystemDaemons::isShutdownFlag ()){NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x31"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x32"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x33"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");}else{
NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x6e\x61\x62\x6c\x65\x64");}}main::sendServerStatus ("\x73\x74\x61\x72\x74"
);main::setSSHStatusStart ();main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::informAboutServerStatusChange ();return (
(0x1148+ 2923-0x1cb3));}sub Service::sudoStop{package Service;no warnings;(my $ref_parameters
=shift (@_));if (defined ($$ref_parameters{"\x74\x61\x72\x67\x65\x74"})){if ((
NXServers::normalizeTargetParameter ($ref_parameters)==(-(0x0381+ 6146-0x1b82)))
){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x02a3+ 1319-0x07ca));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x1ee3+ 1827-0x2606));if (defined ($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"})){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x21a0+ 508-0x239b))){($isForwarded=
(0x0285+ 7975-0x21ab));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x0406+ 5837-0x1ad2));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x6f\x70",
$ref_parameters);if (($isForwarded==(0x022c+ 4204-0x1297))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x091f+ 6124-0x210a));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0137+ 8456-0x223e))
){NXShell::setCommandForwarded ();}}main::nxrequire ("\x4e\x58\x53\x75\x64\x6f")
;NXSudo::setCommandForServer ();NXSudo::setRemoteNodeHost ($$ref_parameters{
"\x68\x6f\x73\x74"});NXSudo::setRemoteNodePort ($$ref_parameters{
"\x70\x6f\x72\x74"});(my $params=(""));foreach my $elem (keys (%$ref_parameters)
){($params.=((($elem."\x3d").$$ref_parameters{$elem})."\x26"));}($params.=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x74\x6f\x70\x26");NXNodes::runNodeForSudo 
($params);NXNodes::reloadNodesDB ();NXSudo::clearCommandForServer ();
NXShell::setExitRequestCommandFinished ();}sub Service::sudoStart{package 
Service;no warnings;(my $ref_parameters=shift (@_));if (defined (
$$ref_parameters{"\x74\x61\x72\x67\x65\x74"})){if ((
NXServers::normalizeTargetParameter ($ref_parameters)==(-(0x090d+ 4734-0x1b8a)))
){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x0a36+ 2659-0x1499));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x0694+ 3144-0x12dc));if (defined ($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"})){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x042c+ 7383-0x2102))){($isForwarded=
(0x1dca+ 2192-0x2659));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x0bf8+ 2373-0x153c));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x61\x72\x74",
$ref_parameters);if (($isForwarded==(0x0f90+ 3736-0x1e27))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x03c1+ 7387-0x209b));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x1cb0+ 2023-0x2496))
){NXShell::setCommandForwarded ();}}main::nxrequire ("\x4e\x58\x53\x75\x64\x6f")
;NXSudo::setCommandForServer ();NXSudo::setRemoteNodeHost ($$ref_parameters{
"\x68\x6f\x73\x74"});NXSudo::setRemoteNodePort ($$ref_parameters{
"\x70\x6f\x72\x74"});(my $params=(""));foreach my $elem (keys (%$ref_parameters)
){($params.=((($elem."\x3d").$$ref_parameters{$elem})."\x26"));}($params.=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x74\x61\x72\x74\x26");
NXNodes::runNodeForSudo ($params);NXNodes::reloadNodesDB ();
NXSudo::clearCommandForServer ();NXShell::setExitRequestCommandFinished ();}sub 
Service::restart{package Service;no warnings;(my $ref_parameters=shift (@_));if 
(($$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne (""))){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((NXServers::normalizeTargetParameter
 ($ref_parameters)==(-(0x0df1+ 6096-0x25c0)))){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x18e1+ 1966-0x208e));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x000d+ 5831-0x16d4));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x1368+ 5015-0x26fe))){($isForwarded=
(0x171c+ 146-0x17ad));}}($$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"
}=(0x0de3+ 6002-0x2554));NXServers::forwardCommand (
"\x73\x65\x72\x76\x69\x63\x65\x72\x65\x73\x74\x61\x72\x74",$ref_parameters);if (
($isForwarded==(0x0269+ 3641-0x10a1))){NXShell::setCommandForwarded ();
NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x05ba+ 6699-0x1fe4));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x204d+ 249-0x2145)))
{NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}
main::nxrequire ("\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73")
;if (($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x68\x74\x64")
){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){if (isNXHtdAvailable
 ()){return (NXShell::handle_command ("\x6e\x78\x68\x74\x64",
"\x6e\x78\x68\x74\x64","\x72\x65\x73\x74\x61\x72\x74"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x68\x74\x64"));}return (NXMsg::error (
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x53\x65\x72\x76\x69\x63\x65"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x64")){if (isNXDAvailable ()){return
 (NXShell::handle_command ("\x6e\x78\x64","\x6e\x78\x64",
"\x72\x65\x73\x74\x61\x72\x74"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x64"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x73\x73\x68\x64")){if (
NXLicense::isSshFeature ()){NXWindowsServices::stopService (
"\x6e\x78\x73\x73\x68\x64");return (NXWindowsServices::startService (
"\x6e\x78\x73\x73\x68\x64"));}}sub BEGIN{require NXWindowsServices;do{
"\x4e\x58\x57\x69\x6e\x64\x6f\x77\x73\x53\x65\x72\x76\x69\x63\x65\x73"->import};
}if ((not (NXMsg::isMessageRegistered (
"\x69\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67")))){
NXMsg::register_response ("\x53\x65\x72\x76\x69\x63\x65",
"\x69\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67",
$GLOBAL::MSG_SERVICE_RESTART);}NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67",
"\x53\x65\x72\x76\x69\x63\x65","\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65");
main::nxrequire ("\x53\x65\x72\x76\x65\x72");Server::setServerIsRestart ();
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");
NXCluster::restartForUserNx ();if (($GLOBAL::isNXServerLoginProcess==
(0x0592+ 6162-0x1da3))){main::nxexit ((0x010b+ 6940-0x1c27));}}package Service;
no warnings;NXMsg::register_error ("\x53\x65\x72\x76\x69\x63\x65",
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,$GLOBAL::MSG_ERROR);NXMsg::register_error ("\x53\x65\x72\x76\x69\x63\x65",
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,$GLOBAL::MSG_ERROR);return ((0x1182+ 2925-0x1cee));
