############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXRemoteServer;no warnings;(my $__name="\x6e\x6f\x74\x73\x65\x74");(my $__majorVersion
="\x6e\x6f\x74\x73\x65\x74");(my $__minorVersion="\x6e\x6f\x74\x73\x65\x74");(my $__patchVersion
="\x6e\x6f\x74\x73\x65\x74");(my $__license="\x6e\x6f\x74\x73\x65\x74");(my $__supportsSha256
=(0x06ad+ 3149-0x12f9));(my $__supportUUIDInHello=(0x046d+ 4371-0x157f));(my $__supportForwardCnnection
=(0x06cd+ 6398-0x1fca));(my $__supportCreatingUnencryptedForwarder=
(0x0f85+ 5166-0x23b3));(my $__supportCheckingMultinodeAvailability=
(0x1621+ 2249-0x1ee9));(my $__supportSeparateAuthInMulitServer=
(0x1973+ 1188-0x1e16));(my $__supportCreatingUnencryptedForwarderForServer=
(0x1e07+ 1355-0x2352));(my $__supportCheckSslCompatibility=(0x0654+ 5001-0x19dd)
);sub setName{($__name=shift (@_));}sub setMajorVersion{($__majorVersion=shift (
@_));}sub setMinorVersion{($__minorVersion=shift (@_));}sub setPatchVersion{(
$__patchVersion=shift (@_));}sub setLicense{($__license=shift (@_));}sub 
getLicense{return ($__license);}sub getVersion{return ($__majorVersion);}sub 
handleTypeAndVersion{(my $name=shift (@_));(my $majorVersion=shift (@_));(my $minorVersion
=shift (@_));(my $patchVersion=shift (@_));(my $license=shift (@_));if ((
$license=~ /(.*) (\d+)$/ )){($license=$1);(my $licenseVersion=$2);}Logger::debug
 ((((((((((("\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20".$name).
"\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x28").$majorVersion)."\x2e").$minorVersion
)."\x2e").$patchVersion).
"\x29\x20\x6f\x70\x65\x72\x61\x74\x69\x6e\x67\x20\x6f\x6e\x20\x6c\x69\x63\x65\x6e\x73\x65\x20"
).$license)."\x2e"));setName ($name);setMajorVersion ($majorVersion);
setMinorVersion ($minorVersion);setPatchVersion ($patchVersion);setLicense (
$license);setIfSupportsSha256 ();setSupportUUIDInHelloMessage ();
setSupportCheckingMultinodeAvailability ();setSupportForwardConnection ();
setSupportSeparateAuthInMulitServer ();setSupportsServerListConnections ();
setSupportsCheckServerLoop ();setSupportCheckSslCompatibility ();}sub 
isVersionLesserOrEqual{(my $major=shift (@_));(my $minor=shift (@_));(my $patch=
shift (@_));if ((not (isVersionSet ()))){return ((0x1b6b+ 232-0x1c53));}if ((not
 (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x0aff+ 6609-0x24cf));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($__majorVersion<$major)){return (
(0x1856+ 2103-0x208c));}if (($__majorVersion==$major)){if ((($minor eq 
"\x61\x6e\x79")or ($__minorVersion<$minor))){return ((0x06a6+ 8085-0x263a));}if 
(($__minorVersion==$minor)){if ((($patch eq "\x61\x6e\x79")or ($__patchVersion<=
$patch))){return ((0x00cf+ 722-0x03a0));}}}return ((0x1fb3+ 1186-0x2455));}sub 
isVersionSet{if ((((((($__majorVersion eq "\x6e\x6f\x74\x73\x65\x74")or (
$__majorVersion eq ("")))or ($__minorVersion eq "\x6e\x6f\x74\x73\x65\x74"))or (
$__minorVersion eq ("")))or ($__patchVersion eq "\x6e\x6f\x74\x73\x65\x74"))or (
$__patchVersion eq ("")))){return ((0x0032+ 2178-0x08b4));}return (
(0x0aad+ 2683-0x1527));}sub setIfSupportsSha256{if (isVersionLesserOrEqual (
(0x0027+ 6957-0x1b4f),(0x13eb+ 2263-0x1cc2),(0x0c1d+ 5586-0x21e2))){(
$__supportsSha256=(0x178c+ 1673-0x1e15));}else{($__supportsSha256=
(0x05f0+ 7035-0x216a));}}sub isSupportingSha256{if (($__supportsSha256==
(0x18f8+ 783-0x1c06))){return ((0x1343+ 818-0x1674));}return (
(0x09a2+ 3328-0x16a2));}sub setSupportUUIDInHelloMessage{if (
isVersionLesserOrEqual ((0x102f+ 2061-0x1837),(0x0c2c+ 3630-0x1a5a),
(0x0a26+ 3442-0x1779))){($__supportUUIDInHello=(0x14db+ 3111-0x2102));}else{(
$__supportUUIDInHello=(0x0987+ 6260-0x21fa));}}sub isSupportUUIDInHelloMessage{
if (($__supportUUIDInHello==(0x1417+ 4536-0x25ce))){return (
(0x0dcf+ 1938-0x1560));}return ((0x0efc+ 5711-0x254b));}sub 
setSupportCheckingMultinodeAvailability{if (isVersionLesserOrEqual (
(0x00d6+ 9491-0x25e4),(0x0593+ 1121-0x09f4),(0x11db+  13-0x11dd))){(
$__supportCheckingMultinodeAvailability=(0x0ad0+ 2072-0x12e8));}else{(
$__supportCheckingMultinodeAvailability=(0x1e17+ 1166-0x22a4));}}sub 
isSupportCheckingMultinodeAvailability{if ((
$__supportCheckingMultinodeAvailability==(0x1143+ 1327-0x1671))){return (
(0x1ec9+ 1080-0x2300));}return ((0x008f+ 9090-0x2411));}sub 
setSupportForwardConnection{if (isVersionLesserOrEqual ((0x1a28+ 2880-0x2562),
(0x1c98+ 702-0x1f56),(0x0586+ 8306-0x25e3))){($__supportForwardCnnection=
(0x0563+ 5515-0x1aee));}else{($__supportForwardCnnection=(0x06e8+ 1878-0x0e3d));
}}sub isSupportForwardConnection{if (($__supportForwardCnnection==
(0x00c1+ 4905-0x13e9))){return ((0x0f0d+ 4624-0x211c));}return (
(0x1a85+ 2192-0x2315));}sub enableUnencryptedForwarder{Logger::debug (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x6e\x61\x62\x6c\x69\x6e\x67\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x75\x6e\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x2e"
);($__supportCreatingUnencryptedForwarder=(0x230d+ 823-0x2643));(
$__supportCreatingUnencryptedForwarderForServer=(0x00e7+ 3922-0x1038));}sub 
isSupportCreatingUnencryptedForwarderForNodes{if ((
$__supportCreatingUnencryptedForwarder==(0x0852+ 3351-0x1568))){return (
(0x1879+ 2760-0x2340));}return ((0x0317+ 9136-0x26c7));}sub 
isSupportCreatingUnencryptedForwarderForServer{if ((
$__supportCreatingUnencryptedForwarderForServer==(0x034f+ 2787-0x0e31))){return 
((0x038f+ 2935-0x0f05));}return ((0x043b+ 4859-0x1736));}sub 
setSupportSeparateAuthInMulitServer{if (isVersionLesserOrEqual (
(0x0f7a+ 3717-0x1df9),(0x0b22+ 518-0x0d21),(0x06d8+ 2003-0x0ea0))){(
$__supportSeparateAuthInMulitServer=(0x01bb+ 423-0x0362));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x73\x65\x70\x61\x72\x61\x74\x65\x20\x61\x75\x74\x68\x2e"
);}else{($__supportSeparateAuthInMulitServer=(0x04a6+ 5695-0x1ae4));
Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x73\x65\x70\x61\x72\x61\x74\x65\x20\x61\x75\x74\x68\x2e"
);}}sub doesSupportSeparateAuthInMulitServer{return (
$__supportSeparateAuthInMulitServer);}sub setSupportsServerListConnections{if (
isVersionLesserOrEqual ((0x01f0+  83-0x023c),(0x029f+ 3066-0x0e99),
(0x0fef+ 1646-0x15b5))){($__supportServerListConnections=(0x11f1+ 1379-0x1754));
Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x69\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x2e"
);}else{($__supportServerListConnections=(0x11e4+ 1877-0x1938));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x69\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x2e"
);}}sub doesSupportServerListConnections{return ($__supportServerListConnections
);}sub setSupportsCheckServerLoop{if (isVersionLesserOrEqual (
(0x0244+ 4360-0x1345),(0x148d+ 1655-0x1b04),(0x0332+ 7536-0x1fe8))){(
$__supportCheckServerLoop=(0x02f8+ 4193-0x1359));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x63\x68\x65\x63\x6b\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x6f\x6f\x70\x2e"
);}else{($__supportCheckServerLoop=(0x0145+ 5471-0x16a3));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x63\x68\x65\x63\x6b\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x6f\x6f\x70\x2e"
);}}sub doesSupportCheckServerLoop{return ($__supportServerListConnections);}sub
 setSupportCheckSslCompatibility{if (isVersionLesserOrEqual (
(0x199f+ 2226-0x2249),(0x15dd+ 3209-0x225b),(0x03cd+ 4938-0x1714))){(
$__supportCheckSslCompatibility=(0x044f+ 6218-0x1c99));Logger::debug (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72\x3a\x20\x44\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x63\x68\x65\x63\x6b\x20\x53\x53\x4c\x20\x63\x6f\x6d\x70\x61\x74\x69\x62\x69\x6c\x69\x74\x79\x2e"
);return ((0x026c+ 2144-0x0acc));}($__supportCheckSslCompatibility=
(0x0045+ 926-0x03e2));Logger::debug (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x75\x70\x70\x6f\x72\x74\x73\x20\x63\x68\x65\x63\x6b\x20\x53\x53\x4c\x20\x63\x6f\x6d\x70\x61\x74\x69\x62\x69\x6c\x69\x74\x79\x2e"
);return ((0x00b1+ 282-0x01ca));}sub doesSupportCheckSslCompatibility{if ((
$__supportCheckSslCompatibility==(0x04e3+ 5928-0x1c0a))){return (
(0x082c+ 6051-0x1fce));}return ((0x1590+ 1429-0x1b25));}return (
(0x1bb7+ 2814-0x26b4));
