############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXServices::NXNode::printStatus{package NXServices::NXNode;no warnings;(my $operation
=shift (@_));(my $response=NXSystemDaemons::askServerDaemonForServiceStatus (
"\x6e\x78\x6e\x6f\x64\x65"));if (defined ($response)){
NXSystemDaemons::printServiceStatusByReply ($response);}else{main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if (NXShutdown::serviceWasDisabled (
"\x6e\x78\x6e\x6f\x64\x65")){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x6e\x6f\x64\x65");}else{NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x6e\x6f\x64\x65");}}}package NXServices::NXNode;no warnings;return (
(0x03d0+ 3778-0x1291));
