############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXServices::NXD;no warnings;(my $__pid=(0x0ce5+ 393-0x0e6e));(my $__disabled
=(0x0324+ 3449-0x109d));(my $__startTime=(0x06dc+ 3863-0x15f3));(my $__silenceMode
=(0x2128+ 309-0x225d));(my $__restartCouter=(0x17fa+ 1091-0x1c3d));(my $__stdin=
(-(0x0cec+ 3933-0x1c48)));(my $__handlingManualStart=(0x0ac3+ 5624-0x20bb));(my $__status
=$NXSystemDaemons::statusUninitialized);sub isEnabled{if (($__disabled==
(0x1de7+ 777-0x20ef))){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);return ((0x1039+ 2089-0x1862));}if (NXSystemDaemons::isServiceDisabled (
"\x6e\x78\x64")){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x6f\x72\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x2e"
);return ((0x116d+ 2519-0x1b44));}if (NXSystemDaemons::isNxdStartupKeyDisabled 
()){if (__isHandlingManualStart ()){return ((0x1690+ 1249-0x1b70));}
Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x6d\x61\x6e\x75\x61\x6c\x6c\x79\x2e"
);return ((0x0976+ 902-0x0cfc));}Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x69\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);return ((0x06b9+ 5590-0x1c8e));}sub isDisabled{return ((!isEnabled ()));}sub 
setEnabled{($__disabled=(0x14c8+ 937-0x1871));}sub setDisabled{($__disabled=
(0x12fa+ 754-0x15eb));}sub start{if (($__status eq 
$NXSystemDaemons::statusStarting)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x2e"
);return ((0x1884+ 2503-0x224a));}if (isEnabled ()){
NXSystemDaemons::removeStopFlag ("\x6e\x78\x64");($__status=
$NXSystemDaemons::statusStarting);if ((NXSystemDaemons::isNxdStartupKeyDisabled 
()and __isHandlingManualStart ())){main::nxrequire (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c");NXFirewall::addFirewallNXDPort ();}(my $nxdPid
=__runNXD ());if (Common::NXProcess::isProcessRunning ($nxdPid)){($__status=
$NXSystemDaemons::statusRunning);__handleNXDStartedWithPid ($nxdPid);return (
(0x1a6a+ 1543-0x2070));}return ((0x13e9+ 3354-0x2103));}return (
(0x1549+ 847-0x1897));}sub stop{NXSystemDaemons::setStopFlag ("\x6e\x78\x64");
setDisabled ();(my $ret=__closeNXD ());main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if ((($ret==(0x0ff8+ 2222-0x18a6))
and NXShutdown::serviceWasDisabled ("\x6e\x78\x64"))){setPid (
(0x21e9+ 376-0x2361));__handleNXDAlreadyClosed ();return ((0x19e1+ 2710-0x2477))
;}elsif (($ret==(0x1559+ 2325-0x1e6e))){setPid ((0x04e2+ 1947-0x0c7d));
__handleNXDClosed ();return ((0x0ad3+ 2237-0x1390));}__handleNXDNotClosed ();
return ((0x1ab4+ 2169-0x232c));}sub isSilenceMode{if (($__silenceMode==
(0x0d94+ 5518-0x2321))){return ((0x0e27+ 5075-0x21f9));}if (
Server::isClientConnectionClosed ()){($__silenceMode=(0x21fd+ 1157-0x2681));}
return ($__silenceMode);}sub setSilentMode{($__silenceMode=(0x2025+ 509-0x2221))
;}sub __closeNXD{(my $nxdPid=getPid ());if ((($nxdPid==(0x1aab+ 1595-0x20e6))or 
(not (Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxdPid,
"\x6e\x78\x64"))))){return ((0x01e2+ 152-0x027a));}if (($__status eq 
$NXSystemDaemons::statusTerminating)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x2e"
);return ((0x04a7+ 2879-0x0fe6));}($__status=$NXSystemDaemons::statusTerminating
);if (Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxdPid,
"\x6e\x78\x64")){NXSystemDaemons::killServiceIfRunning ($nxdPid,"\x6e\x78\x64",
(0x0783+ 7408-0x2473));}else{return ((0x00e8+ 1305-0x0601));}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxdPid,
"\x6e\x78\x64")){($__status=$NXSystemDaemons::statusTerminated);return (
(0x0cf9+ 4107-0x1d03));}return ((0x05ff+ 4710-0x1865));}sub __handleNXDClosed{if
 ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73","\x6e\x78\x64");}
NXSystemDaemons::removePidFile ("\x6e\x78\x64");main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ("\x6e\x78\x64");}
sub __handleNXDAlreadyClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73","\x6e\x78\x64");
}NXSystemDaemons::removePidFile ("\x6e\x78\x64");main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ("\x6e\x78\x64");}
sub __handleNXDNotClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73","\x6e\x78\x64");}
}sub getPid{if (($__pid!=(0x00d0+ 645-0x0355))){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x20"
.$__pid)."\x2e"));return ($__pid);}($__pid=NXSystemDaemons::readPid (
"\x6e\x78\x64"));return ($__pid);}sub setPid{($__pid=shift (@_));if (($__pid>
(0x19da+ 3134-0x2618))){NXSystemDaemons::savePid ("\x6e\x78\x64",$__pid);}}sub 
__setStartTime{($__startTime=Common::NXTime::getSecondsSinceEpoch ());}sub 
__handleNXDStartedWithPid{(my $nxdPid=shift (@_));
Common::NXProcess::setExitCallback ($nxdPid,(\&nxdSIGCHLDHandler));
Common::NXProcess::setErrorCallback ($nxdPid,(\&nxdSIGCHLDHandler));
Logger::debug (((
"\x4e\x58\x44\x20\x69\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$nxdPid)."\x2e"));__setStartTime ();setPid ($nxdPid);__resetHandlingManualStart
 ();main::nxrequire ("\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToAdd 
("\x6e\x78\x64");}sub __getStdoutFile{return ((((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x64\x2e\x6c\x6f\x67"));}sub __getStderrFile{return (((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64\x2e\x6c\x6f\x67"));}sub __runNXD{(my $servicePid
=getPid ());if ((($servicePid>(0x0360+ 7288-0x1fd8))and 
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
"\x6e\x78\x64"))){if (((not (Common::NXProcess::isChildProcess ($servicePid)))
and (not (Common::NXProcess::isOnWatchdogProcess ($servicePid))))){
Common::NXProcess::addWatchdog ($servicePid,$NXBITS::SIGCHLD);
Common::NXProcess::setCallbackSIGCHLD ($servicePid,(\&nxdSIGCHLDHandler));}
Logger::debug (
"\x4e\x58\x44\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ($servicePid);}if (($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31"))
{__createCertIfNeeded ();}(my (@command)=__getCommandStart ());(my (@options)=
__getCommandOptions ());my ($nxdPid);push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$nxdPid));Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x64\x2e");main::nxRunCommand ((
\@command),(\@options));return ($nxdPid);}sub __createCertIfNeeded{if (
Common::NXFile::isExists (NXPaths::getHostPrivateCert ())){return;}(my (@command
)=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);push (@command,"\x2d\x6b\x20");
push (@command,NXPaths::getHostPrivateCert ());push (@command,"\x2d\x63\x20");
push (@command,NXPaths::getHostPublicCert ());(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x45\x54\x43\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e"));
main::nxRunCommand ((\@command),(\@options));}sub __getCommandStart{(my (
@command)=());push (@command,(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64\x2e\x65\x78\x65"));if ((
NXNodeInfo::getNxdPort ()!=(0x1b11+ 5205-0x1fc6))){push (@command,(
"\x2d\x70\x20".NXNodeInfo::getNxdPort ()));}if ((NXNodeInfo::getNxdUDPPort ()!=
(0x11a0+ 4099-0x1203))){push (@command,("\x2d\x75\x20".NXNodeInfo::getNxdUDPPort
 ()));}if (($GLOBAL::NXdConnectionsLimit!=(""))){push (@command,("\x2d\x4c\x20".
$GLOBAL::NXdConnectionsLimit));}if (($GLOBAL::NXdConnectionsInterval!=(""))){
push (@command,("\x2d\x52\x20".($GLOBAL::NXdConnectionsInterval *
(0x21f3+ 302-0x1f39))));}if (($GLOBAL::NXdConnectionsIntervalLimit!=(""))){push 
(@command,("\x2d\x43\x20".$GLOBAL::NXdConnectionsIntervalLimit));}if ((
$GLOBAL::NXdListenAddress ne (""))){push (@command,"\x2d\x6c",
$GLOBAL::NXdListenAddress);}return (@command);}sub __getCommandOptions{(my (
@options)=());(my $homePath=Common::NXPaths::getEffectiveUserHomeDirectory ());
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$homePath)
);push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x48\x4f\x4d\x45\x3d".$homePath));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(((((((((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62\x3a").
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62").
$GLOBAL::DIRECTORY_SLASH)."\x70\x65\x72\x6c\x3a").libnxh::NXTransGetEnvironment 
("\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48")));push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(((((((
"\x50\x45\x52\x4c\x35\x49\x4e\x43\x4c\x55\x44\x45\x3d".$GLOBAL::NODE_ROOT).
$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62").$GLOBAL::DIRECTORY_SLASH).
"\x70\x65\x72\x6c").$GLOBAL::DIRECTORY_SLASH)."\x69\x6e\x63\x6c\x75\x64\x65"));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((((
"\x50\x45\x52\x4c\x35\x4c\x49\x42\x3d".$GLOBAL::NODE_ROOT).
$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62").$GLOBAL::DIRECTORY_SLASH).
"\x70\x65\x72\x6c"));(my $SystemRoot=libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
$SystemRoot));(my $allusersprofile=libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
$allusersprofile));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4e\x58\x5f\x52\x4f\x4f\x54\x3d".$homePath).$GLOBAL::DIRECTORY_SLASH).
"\x2e\x6e\x78"));(my $tempPath=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x76\x61\x72").$GLOBAL::DIRECTORY_SLASH)."\x74\x6d\x70"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x54\x45\x4d\x50\x3d".$tempPath));(my $binPath
=((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",((
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x3d".$binPath).
"\x6e\x78\x72\x75\x6e\x6e\x65\x72\x2e\x65\x78\x65"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(("\x4e\x58\x5f\x41\x55\x54\x48\x3d".$binPath).
"\x6e\x78\x61\x75\x74\x68\x2e\x65\x78\x65"));(my $env=
libnxh::NXTransGetEnvironment ("\x41\x50\x50\x44\x41\x54\x41"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x41\x50\x50\x44\x41\x54\x41\x3d".$env));($env=
libnxh::NXTransGetEnvironment (
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73"));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x3d".
$env));($env=libnxh::NXTransGetEnvironment (
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x28\x78\x38\x36\x29"
));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x28\x78\x38\x36\x29\x3d"
.$env));($env=libnxh::NXTransGetEnvironment (
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x57\x36\x34\x33\x32"
));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x6f\x6d\x6d\x6f\x6e\x50\x72\x6f\x67\x72\x61\x6d\x46\x69\x6c\x65\x73\x57\x36\x34\x33\x32\x3d"
.$env));($env=libnxh::NXTransGetEnvironment (
"\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x43\x4f\x4d\x50\x55\x54\x45\x52\x4e\x41\x4d\x45\x3d".$env));($env=
libnxh::NXTransGetEnvironment ("\x43\x6f\x6d\x53\x70\x65\x63"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x43\x6f\x6d\x53\x70\x65\x63\x3d".$env));($env=
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".$env));($env=
libnxh::NXTransGetEnvironment (
"\x46\x50\x5f\x4e\x4f\x5f\x48\x4f\x53\x54\x5f\x43\x48\x45\x43\x4b"));push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x46\x50\x5f\x4e\x4f\x5f\x48\x4f\x53\x54\x5f\x43\x48\x45\x43\x4b\x3d".$env));(
$env=libnxh::NXTransGetEnvironment ("\x77\x69\x6e\x64\x69\x72"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x77\x69\x6e\x64\x69\x72\x3d".$env));($env=
libnxh::NXTransGetEnvironment ("\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45"));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x55\x53\x45\x52\x50\x52\x4f\x46\x49\x4c\x45\x3d".$env));($env=
libnxh::NXTransGetEnvironment ("\x55\x53\x45\x52\x4e\x41\x4d\x45"));push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x55\x53\x45\x52\x4e\x41\x4d\x45\x3d".
$env));($env=libnxh::NXTransGetEnvironment (
"\x55\x53\x45\x52\x44\x4f\x4d\x41\x49\x4e"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x55\x53\x45\x52\x44\x4f\x4d\x41\x49\x4e\x3d".
$env));($env=libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65\x3d".$env));($env=
libnxh::NXTransGetEnvironment (
"\x50\x53\x4d\x6f\x64\x75\x6c\x65\x50\x61\x74\x68"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x50\x53\x4d\x6f\x64\x75\x6c\x65\x50\x61\x74\x68\x3d".$env));if (($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x45\x54\x43\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e"));}my ($nxdStdin);
Common::NXCore::nxPipeCreateBi ((\$__stdin),(\$nxdStdin));push (@options,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$nxdStdin);push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");
Logger::debug ((("\x4e\x58\x44\x3a\x20\x53\x74\x64\x69\x6e\x20\x46\x44\x23".
$__stdin)."\x2e"));push (@options,"\x73\x74\x64\x65\x72\x72",__getStderrFile ())
;push (@options,"\x73\x74\x64\x6f\x75\x74",__getStdoutFile ());push (@options,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x3d".libnxh::NXTransGetEnvironment
 ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));return (@options
);}sub getStdin{return ($__stdin);}sub nxdSIGCHLDHandler{(my $pid=shift (@_));(my $code
=shift (@_));Logger::debug (((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid).
"\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$code)."\x2e"));NXSystemDaemons::removePidFile ("\x6e\x78\x64");setPid (
(0x0d3f+ 529-0x0f50));if ((($GLOBAL::REQUEST_TERMINATE==(0x1237+ 3769-0x20ef))or
 NXSystemDaemons::isShutdownFlag ())){Logger::debug (
"\x4e\x6f\x74\x20\x72\x65\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x4e\x58\x44\x20\x64\x75\x72\x69\x6e\x67\x20\x73\x68\x75\x74\x64\x6f\x77\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x2e"
);return ((0x1b5b+ 486-0x1d41));}main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e");
NXRedisSubscription::sendNxdClosedEvent ();if (isDisabled ()){return;}if (
NXSystemDaemons::isStopFlag ("\x6e\x78\x64")){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x68\x61\x73\x20\x73\x74\x6f\x70\x20\x66\x6c\x61\x67\x2e"
);return;}if (__isMaximumRestartCounterReached ()){setDisabled ();return;}start 
();}sub __isMaximumRestartCounterReached{(my $lifeTime=(
Common::NXTime::getSecondsSinceEpoch ()-$__startTime));if (($lifeTime<
$GLOBAL::TooShortServiceLifeTime)){($__restartCouter+=(0x0158+ 1464-0x070f));}
else{($__restartCouter=(0x079c+ 399-0x092b));}if (($__restartCouter>
$GLOBAL::MaximumServiceRestartCounter)){Logger::warning (
"\x52\x65\x61\x63\x68\x65\x64\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x4e\x58\x44\x20\x72\x65\x73\x74\x61\x72\x74\x20\x63\x6f\x75\x6e\x74\x65\x72\x2e"
);return ((0x092d+ 7611-0x26e7));}return ((0x2542+ 258-0x2644));}sub 
setHandlingManualStart{($__handlingManualStart=(0x0544+ 2491-0x0efe));}sub 
__isHandlingManualStart{if (($__handlingManualStart==(0x0a80+ 1077-0x0eb4))){
return ((0x009d+ 2210-0x093e));}return ((0x16c8+ 1549-0x1cd5));}sub 
__resetHandlingManualStart{($__handlingManualStart=(0x1255+ 472-0x142d));}return
 ((0x07a3+ 2222-0x1050));
