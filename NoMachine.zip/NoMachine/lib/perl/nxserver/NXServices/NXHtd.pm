############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXServices::NXHtd;no warnings;(my $__serviceName="\x6e\x78\x68\x74\x64")
;(my $__pid=(0x0307+ 5999-0x1a76));(my $__disabled=(0x0240+ 2040-0x0a38));(my $__waitTime
=(0x173a+ 255-0x1839));(my $__nxexecPid=(0x0771+ 4545-0x1932));(my $__startTime=
(0x0435+ 1557-0x0a4a));(my $__silenceMode=(0x2206+ 639-0x2485));(my $__restartCouter
=(0x09c4+ 5323-0x1e8f));(my $__isWaitingForNXHtdStart=(0x0a29+ 3195-0x16a4));(my $__handlingManualStart
=(0x1da8+ 1698-0x244a));(my $__serviceStarting=
"\x73\x74\x61\x72\x74\x69\x6e\x67");(my $__serviceWorking=
"\x77\x6f\x72\x6b\x69\x6e\x67");(my $__serviceShutdown=
"\x73\x68\x75\x74\x64\x6f\x77\x6e");(my $__serviceStatusReported=
$__serviceStarting);sub setServiceStatus{(my $status=(shift (@_)||("")));if ((
$status eq (""))){return;}($__serviceStatusReported=$status);}sub 
getServiceStatus{return ($__serviceStatusReported);}sub isServicesStatusWorking{
if ((getServiceStatus ()eq $__serviceWorking)){return ((0x1a3a+ 552-0x1c61));}
return ((0x0550+ 6910-0x204e));}sub isEnabled{if (($__disabled==
(0x0211+ 2635-0x0c5b))){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x64\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);return ((0x17b9+ 838-0x1aff));}if (NXSystemDaemons::isServiceDisabled (
$__serviceName)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x64\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x6f\x72\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x2e"
);return ((0x03a3+ 5338-0x187d));}if (NXSystemDaemons::isHttpdStartupKeyDisabled
 ()){if (__isHandlingManualStart ()){return ((0x0520+ 432-0x06cf));}
Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x64\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x6d\x61\x6e\x75\x61\x6c\x6c\x79\x2e"
);return ((0x12d9+ 1917-0x1a56));}return ((0x0ae4+ 3478-0x1879));}sub isDisabled
{return ((!isEnabled ()));}sub setEnabled{($__disabled=(0x1326+ 3835-0x2221));}
sub setDisabled{setServiceStatus ($__serviceShutdown);($__disabled=
(0x0260+ 7068-0x1dfb));}sub start{if (isEnabled ()){
NXSystemDaemons::removeStopFlag ($__serviceName);if (__isHandlingManualStart ())
{main::nxrequire ("\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c");
NXFirewall::addFirewallNXHtdPort ();}(my $nxhtdPid=__runNXHtd ());if (($nxhtdPid
>(0x0cc1+ 4630-0x1ed7))){__handleNXHtdStartedWithPid ($nxhtdPid);return (
(0x0262+ 3392-0x0fa1));}__handleNXHtdNotStarted ();return ((0x04ff+ 671-0x079e))
;}return ((0x0386+ 3530-0x114f));}sub stop{NXSystemDaemons::setStopFlag (
$__serviceName);setDisabled ();(my $ret=__closeNXHtd ());main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if ((($ret==(0x03c3+ 1595-0x09fe))
and NXShutdown::serviceWasDisabled ("\x6e\x78\x68\x74\x64"))){setPid (
(0x0378+ 4007-0x131f));__handleNXHtdAlreadyClosed ();return (
(0x12e9+ 2430-0x1c67));}elsif (($ret==(0x1aac+ 2615-0x24e3))){setPid (
(0x0b29+  22-0x0b3f));__handleNXHtdClosed ();return ((0x1328+ 3996-0x22c4));}
__handleNXHtdNotClosed ();return ((0x0492+ 1502-0x0a6f));}sub getPid{if (($__pid
>(0x10e1+ 5673-0x270a))){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x44\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x3a\x20"
.$__pid)."\x2e"));return ($__pid);}($__pid=NXSystemDaemons::readPid (
$__serviceName));return ($__pid);}sub setPid{($__pid=shift (@_));}sub 
__setStartTime{($__startTime=Common::NXTime::getSecondsSinceEpoch ());}sub 
isSilenceMode{if (($__silenceMode==(0x0a51+ 5029-0x1df5))){return (
(0x1699+ 195-0x175b));}if (Server::isClientConnectionClosed ()){($__silenceMode=
(0x0933+ 6768-0x23a2));}return ($__silenceMode);}sub setSilentMode{(
$__silenceMode=(0x0448+ 7108-0x200b));}sub __closeNXHtd{(my $nxhtdPid=getPid ())
;if ((($nxhtdPid==(0x0c9f+ 4580-0x1e83))or (not (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName))))){return ((0x0f47+ 704-0x1207));}if ((__sendStopNXHtdCommand (
$nxhtdPid)==(0x0e35+ 1261-0x1322))){NXSystemDaemons::waitForServiceClosure (
$nxhtdPid,$__serviceName);}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName)){Common::NXProcess::signalProcessByRestrictedScript ($nxhtdPid,
Common::NXProcess::getSignalKill (),(0x0d08+ 4115-0x1d1a));}else{return (
(0x1dc8+ 487-0x1faf));}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName)){return ((0x06fb+ 1798-0x0e00));}return ((0x00b2+ 4575-0x1291));
}sub __sendStopNXHtdCommand{(my $nxhtdPid=shift (@_));(my (@command)=
__getCommandStop ());(my (@options)=__getCommandOptions ());(my ($cmd_err,
$cmd_out,$exit_value)=main::run_command ((\@command),(\@options)));return (
$exit_value);}sub __handleNXHtdClosed{if ((not (isSilenceMode ()))){NXMsg::info 
("\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
NXSystemDaemons::removePidFile ($__serviceName);main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ($__serviceName);}
sub __handleNXHtdAlreadyClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);
}NXSystemDaemons::removePidFile ($__serviceName);main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ($__serviceName);}
sub __handleNXHtdNotClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
}sub __handleNXHtdStartedWithPid{(my $htdPid=shift (@_));
Common::NXProcess::setExitCallback ($htdPid,(\&nxhtdSIGCHLDHandler));
Common::NXProcess::setErrorCallback ($htdPid,(\&nxhtdSIGCHLDHandler));
Logger::debug (((
"\x4e\x58\x48\x54\x44\x20\x69\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$htdPid)."\x2e"));if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
__setStartTime ();setPid ($htdPid);__resetHandlingManualStart ();main::nxrequire
 ("\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToAdd ($__serviceName);}
sub __handleNXHtdNotStarted{if ((not (isSilenceMode ($__serviceName)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
}sub __runNXHtd{(my $nxhtdPid=getPid ());if ((($nxhtdPid>(0x06af+ 3078-0x12b5))
and Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName))){if (((not (Common::NXProcess::isChildProcess ($nxhtdPid)))and 
(not (Common::NXProcess::isOnWatchdogProcess ($nxhtdPid))))){setServiceStatus (
$__serviceWorking);Common::NXProcess::addWatchdog ($nxhtdPid,$NXBITS::SIGCHLD);
Common::NXProcess::setCallbackSIGCHLD ($nxhtdPid,(\&nxhtdSIGCHLDHandler));}
Logger::debug (
"\x4e\x58\x48\x54\x44\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ($nxhtdPid);}if (($__isWaitingForNXHtdStart!=(0x05d0+ 1952-0x0d6f))){(my (
@command)=__getCommandStart ());(my (@options)=__getCommandOptions ());push (
@options,"\x67\x65\x74\x20\x70\x69\x64",(\$__nxexecPid));Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x4e\x58\x48\x54\x44\x2e");
main::nxRunCommand ((\@command),(\@options));($__waitTime=(0x1408+ 393-0x1591));
($__isWaitingForNXHtdStart=(0x0762+ 1510-0x0d47));__setStartTime ();if ((
$__nxexecPid<=(0x08d7+ 2536-0x12bf))){setDisabled ();return (
(0x151a+ 1471-0x1ad9));}}if (NXSystemDaemons::isDisabled ($__serviceName)){(
$__isWaitingForNXHtdStart=(0x102d+ 5008-0x23bd));return ((0x0acf+ 1422-0x105d));
}($nxhtdPid=__waitForNXHtdPid ());return ($nxhtdPid);}sub __waitForNXHtdPid{(my $waitTimeout
=(0x0656+ 7108-0x2215));(my $waitInterval=0.1);for (;($__waitTime<$waitTimeout);
($__waitTime+=$waitInterval)){if (NXSystemDaemons::isDisabled ($__serviceName)){
($__isWaitingForNXHtdStart=(0x04c9+ 8494-0x25f7));return ((0x16c5+ 4148-0x26f9))
;}(my $nxhtdPid=NXSystemDaemons::readPid ($__serviceName));if ((($nxhtdPid>
(0x0a6c+ 4465-0x1bdd))and 
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName))){($__isWaitingForNXHtdStart=(0x1c7f+ 341-0x1dd4));
setServiceStatus ($__serviceWorking);return ($nxhtdPid);}main::nxsleep (
$waitInterval);}Logger::warning (
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x6e\x78\x68\x74\x64\x20\x70\x69\x64\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
);($__isWaitingForNXHtdStart=(0x0bd9+ 1608-0x1221));return ((0x0cc0+ 901-0x1045)
);}sub __getCommandStart{(my (@command)=());(@command=(((
NXTools::getWindowsSystemPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x65\x74\x2e\x65\x78\x65"),"\x73\x74\x61\x72\x74",$__serviceName));return (
@command);}sub __getCommandOptions{(my (@options)=());(my $path=(
$GLOBAL::NODE_ROOT."\x2f\x6c\x69\x62\x3a"));($path.=($GLOBAL::NODE_ROOT.
"\x2f\x6c\x69\x62\x2f\x70\x65\x72\x6c\x3a"));($path.=
libnxh::NXTransGetEnvironment (
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".$path));push 
(@options,"\x73\x74\x64\x69\x6e\x6e\x6f\x72\x65\x64\x69\x72\x65\x63\x74");push (
@options,"\x73\x74\x64\x6f\x75\x74",__getStdoutFile ());push (@options,
"\x73\x74\x64\x65\x72\x72",__getStderrFile ());push (@options,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");return (@options);}sub __getStdoutFile{
return (Common::NXPaths::getNXServerLogPath ());}sub __getStderrFile{return (
Common::NXPaths::getNXServerLogPath ());}sub __getCommandStop{(my (@command)=())
;(@command=(((NXTools::getWindowsSystemPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x65\x74\x2e\x65\x78\x65"),"\x73\x74\x6f\x70",$__serviceName));return (
@command);}sub nxhtdSIGCHLDHandler{(my $pid=shift (@_));(my $code=shift (@_));(
$__isWaitingForNXHtdStart=(0x1132+ 4813-0x23ff));Logger::debug (((((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x54\x44\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid)."\x20\x61\x6e\x64\x20\x73\x74\x61\x67\x65\x20\x27").
$__serviceStatusReported).
"\x27\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$code)."\x2e"));NXSystemDaemons::removePidFile ($__serviceName);setPid (
(0x0bf8+ 3289-0x18d1));if (($GLOBAL::REQUEST_TERMINATE==(0x1360+ 4069-0x2344))){
return ((0x12ac+ 276-0x13c0));}if (isDisabled ()){return;}if (
NXSystemDaemons::isStopFlag ($__serviceName)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x54\x44\x20\x68\x61\x73\x20\x73\x74\x6f\x70\x20\x66\x6c\x61\x67\x2e"
);return;}if (__isMaximumRestartCounterReached ()){setDisabled ();return;}if ((
isServicesStatusWorking ()==(0x15db+ 4046-0x25a8))){start ();}else{setDisabled 
();}}sub __isMaximumRestartCounterReached{(my $lifeTime=(
Common::NXTime::getSecondsSinceEpoch ()-$__startTime));if (($lifeTime<
$GLOBAL::TooShortServiceLifeTime)){($__restartCouter+=(0x0ca2+ 4272-0x1d51));}
else{($__restartCouter=(0x117c+ 2580-0x1b90));}if (($__restartCouter>
$GLOBAL::MaximumServiceRestartCounter)){Logger::warning (
"\x52\x65\x61\x63\x68\x65\x64\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x4e\x58\x48\x54\x44\x20\x72\x65\x73\x74\x61\x72\x74\x20\x63\x6f\x75\x6e\x74\x65\x72\x2e"
);return ((0x0553+ 8103-0x24f9));}return ((0x1583+ 586-0x17cd));}sub 
setHandlingManualStart{($__handlingManualStart=(0x0a64+ 177-0x0b14));}sub 
__isHandlingManualStart{if (($__handlingManualStart==(0x0f91+ 2192-0x1820))){
return ((0x1ad7+ 1657-0x214f));}return ((0x09d8+ 776-0x0ce0));}sub 
__resetHandlingManualStart{($__handlingManualStart=(0x1678+ 3391-0x23b7));}sub 
setNXHtdLogPermissionByAdmin{if ((not (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()))){return;}if ((not (
main::effectiveUserIsAdministrator ()))){return;}(my $__logfile=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67"));Logger::debug
 (((
"\x73\x65\x74\x4e\x58\x48\x74\x64\x4c\x6f\x67\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x42\x79\x41\x64\x6d\x69\x6e\x20\x6e\x78\x68\x74\x64\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x3a\x20"
.$__logfile)."\x2e"));(my $permissions=($NXBits::UserReadWrite+
$NXBits::GroupReadWrite));if ((not (Common::NXFile::fileExists ($__logfile)))){(my $FH
=main::nxopen ($__logfile,$NXBits::O_CREAT,$permissions,{
"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));if ((not (defined ($FH)
))){(my $errorString=libnxh::NXGetErrorString ());(my $errorNumber=
libnxh::NXGetError ());Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$__logfile)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorNumber).
"\x2c\x20").$errorString)."\x2e"));}else{main::nxclose ($FH);}}}return (
(0x1c93+ 2615-0x26c9));
