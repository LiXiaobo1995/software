############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXServices::NXDaemon;no warnings;(my $__childProcessIsNotWorking=(-
(0x009a+ 5317-0x155e)));sub startDaemonOnLinux{Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);(my (@command)=());(my (@options)=());push (@command,$GLOBAL::CommandNXexec);
push (@command,(($GLOBAL::ETC_DIR.$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72"));push (@command,
"\x2d\x2d\x64\x61\x65\x6d\x6f\x6e");(my $pid=(0x08a8+ 3215-0x1537));push (
@options,"\x67\x65\x74\x20\x70\x69\x64",(\$pid));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x3d".libnxh::NXTransGetEnvironment
 ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")));my (
$serverIn);my ($serverOut);my ($serverErr);main::nxRunCommandBg ((\@command),(
\@options),(\$serverIn),(\$serverOut),(\$serverErr));if (($pid>
(0x0e33+ 110-0x0ea1))){Common::NXProcess::setCallbackSIGCHLD ($pid,(
\&nxdaemonSIGCHLDHandler));Logger::debug (((
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));Common::NXProcess::leaveChildAtFinish ($pid);}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($serverOut);(my $finish=(0x1879+ 1027-0x1c7c));while 
(($finish==(0x07df+ 6716-0x221b))){(my (@ready)=$selector->can_read (
$GLOBAL::timeoutForWaitingOnServerStartupMonitorAnswer));if ((scalar (@ready)==
(0x011a+ 7775-0x1f79))){($finish=(0x0848+ 6606-0x2215));last;}foreach my $fh (
@ready){if (($fh==$serverOut)){(my $buffer=(""));(my $readBytes=main::nxread (
$fh,(\$buffer),(0x21f2+ 4192-0x2252)));Logger::debug (((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$buffer)."\x2e"));if (($readBytes==(0x21a9+ 609-0x240a))){Logger::debug (((
"\x43\x6c\x6f\x73\x65\x64\x20\x46\x44\x23".$fh)."\x2e"));main::nxclose ($fh);(
$finish=(0x0fb8+ 896-0x1337));}}else{Logger::warning (((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x20\x46\x44\x23".
$fh).
"\x20\x77\x68\x65\x6e\x20\x77\x61\x69\x74\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x61\x6e\x73\x77\x65\x72\x2c\x20\x69\x67\x6e\x6f\x72\x65\x20\x69\x74\x2e"
));}}}if ((isChildProcessNotWorking ()==(0x0116+ 2082-0x0937))){Logger::warning 
(
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x69\x73\x20\x6e\x6f\x74\x20\x77\x6f\x72\x6b\x69\x6e\x67\x2e"
);return ((0x04d7+ 7710-0x22f4));}return ((0x1e20+ 781-0x212d));}sub stop{if ((
not (NXSystemDaemons::isRunning ("\x6e\x78\x73\x65\x72\x76\x65\x72")))){
Logger::debug (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);NXWindowsServices::stopNXService ();__cleanServerDaemonFilesIfNeeded ();return
;}(my $serverPid=NXSystemDaemons::readPid ("\x6e\x78\x73\x65\x72\x76\x65\x72"));
(my $waitTime=(0x1a7f+ 3059-0x2672));(my $waitInterval=0.1);(my $waitTimeout=
__getTimeoutToWaitForDaemonBeforeKill ());NXWindowsServices::stopNXService ();
Logger::debug (((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$serverPid)."\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"));while 
((Common::NXProcess::isProcessRunning ($serverPid)and ($waitTime<$waitTimeout)))
{main::nxsleep ($waitInterval);($waitTime+=$waitInterval);}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($serverPid,
"\x6e\x78\x73\x65\x72\x76\x65\x72")){if (Common::NXProcess::sigkill ($serverPid)
){Logger::debug (((
"\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x4b\x69\x6c\x6c\x65\x64\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$serverPid)."\x2e"));}else{Logger::error (((
"\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$serverPid)."\x2e"));}}__cleanServerDaemonFilesIfNeeded ();}sub 
__cleanServerDaemonFilesIfNeeded{NXServerDaemon::removeServerDaemonPidFile ();(my $path
=(((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").
$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72"));(my $monitorCookieFile=((
$path.$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));(my $monitorPortFile
=(($path.$GLOBAL::DIRECTORY_SLASH)."\x70\x6f\x72\x74"));if (
Common::NXFile::fileExists ($monitorCookieFile)){if ((not (unlink (
$monitorCookieFile)))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$monitorCookieFile)."\x3a\x20").$!));}else{Logger::debug2 (((
"\x55\x6e\x6c\x69\x6e\x6b\x65\x64\x20\x66\x69\x6c\x65\x20".$monitorCookieFile).
"\x2e"));}}if (Common::NXFile::fileExists ($monitorPortFile)){if ((not (unlink (
$monitorPortFile)))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$monitorPortFile)."\x3a\x20").$!));}else{Logger::debug2 (((
"\x55\x6e\x6c\x69\x6e\x6b\x65\x64\x20\x66\x69\x6c\x65\x20".$monitorPortFile).
"\x2e"));}}}sub lockFile{(my $file=$GLOBAL::ServerDaemonLockFilePath);(my $SERVER_FH
=main::nxopen ($file,($NXBits::O_WRONLY+$NXBits::O_CREAT),((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead)));if ((not (
defined ($SERVER_FH)))){Logger::error (((
"\x6c\x6f\x63\x6b\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));return ((-
(0x070b+ 6012-0x1e86)));}unless (main::nxflock ($SERVER_FH,$NXBits::LOCK_EX)){
Logger::error (((
"\x6c\x6f\x63\x6b\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x66\x6c\x6f\x63\x6b\x20\x66\x69\x6c\x65\x3a\x20"
.$file)."\x2e"));return ((-(0x0405+ 4780-0x16b0)));}
libnxh::NXDescriptorInheritable ($SERVER_FH,(0x022c+ 311-0x0363));
main::closeSocketAtFinish ($SERVER_FH);return ($SERVER_FH);}sub 
startNXServerServiceBySystemd{(my (@command)=());(my (@options)=());push (
@command,Common::NXShellCommands::getCommand (
"\x73\x79\x73\x74\x65\x6d\x63\x74\x6c"));push (@command,"\x73\x74\x61\x72\x74",
$GLOBAL::serverServiceFileName);Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x62\x79\x20\x73\x79\x73\x74\x65\x6d\x64\x2e"
);(my ($cmdErr,$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)))
;return ($exitValue);}sub startNXServerServiceByUpStart{(my (@command)=());(my (
@options)=());push (@command,Common::NXShellCommands::getCommand (
"\x69\x6e\x69\x74\x63\x74\x6c"));push (@command,"\x73\x74\x61\x72\x74");push (
@command,"\x6e\x78\x73\x65\x72\x76\x65\x72");Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x62\x79\x20\x75\x70\x73\x74\x61\x72\x74\x2e"
);(my ($cmdErr,$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)))
;return ($exitValue);}sub stopNXServerServiceByUpStart{(my (@command)=());(my (
@options)=());push (@command,Common::NXShellCommands::getCommand (
"\x69\x6e\x69\x74\x63\x74\x6c"));push (@command,"\x73\x74\x6f\x70");push (
@command,"\x6e\x78\x73\x65\x72\x76\x65\x72");Logger::debug (
"\x53\x74\x6f\x70\x70\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x62\x79\x20\x75\x70\x73\x74\x61\x72\x74\x2e"
);(my ($cmdErr,$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)))
;return ($exitValue);}sub restartNXServerServiceByUpStart{(my (@command)=());(my (
@options)=());push (@command,Common::NXShellCommands::getCommand (
"\x69\x6e\x69\x74\x63\x74\x6c"));push (@command,"\x72\x65\x73\x74\x61\x72\x74");
push (@command,"\x6e\x78\x73\x65\x72\x76\x65\x72");Logger::debug (
"\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x62\x79\x20\x75\x70\x73\x74\x61\x72\x74\x2e"
);(my ($cmdErr,$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)))
;return ($exitValue);}sub stopNxserverServiceBySystemd{(my (@command)=());(my (
@options)=());push (@options,"\x74\x69\x6d\x65\x6f\x75\x74",
$GLOBAL::timeoutForSystemctlStop);push (@command,
Common::NXShellCommands::getCommand ("\x73\x79\x73\x74\x65\x6d\x63\x74\x6c"));
push (@command,"\x73\x74\x6f\x70",$GLOBAL::serverServiceFileName);Logger::debug 
(
"\x53\x74\x6f\x70\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x62\x79\x20\x73\x79\x73\x74\x65\x6d\x64"
);(my ($cmdErr,$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)))
;return ($exitValue);}sub restartNxserverServiceBySystemd{(my (@command)=());(my (
@options)=());push (@options,"\x74\x69\x6d\x65\x6f\x75\x74",
$GLOBAL::timeoutForSystemctlStop);push (@command,
Common::NXShellCommands::getCommand ("\x73\x79\x73\x74\x65\x6d\x63\x74\x6c"));
push (@command,"\x72\x65\x73\x74\x61\x72\x74",$GLOBAL::serverServiceFileName);
Logger::debug (
"\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x62\x79\x20\x73\x79\x73\x74\x65\x6d\x64"
);(my ($cmdErr,$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)))
;return ($exitValue);}sub __getTimeoutToWaitForDaemonBeforeKill{return (
$GLOBAL::TimeoutToWaitForDaemonBeforeKill);}sub nxdaemonSIGCHLDHandler{(my $pid=
shift (@_));(my $code=shift (@_));Logger::debug (((((
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid).
"\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$code)."\x2e"));($__childProcessIsNotWorking=(0x06f2+ 6762-0x215b));}sub 
isChildProcessNotWorking{if (($__childProcessIsNotWorking==(0x0530+ 6793-0x1fb8)
)){return ((0x0890+ 3994-0x1829));}return ((0x1502+ 2995-0x20b5));}return (
(0x0295+ 6379-0x1b7f));
