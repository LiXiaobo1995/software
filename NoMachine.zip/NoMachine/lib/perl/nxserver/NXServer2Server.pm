############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXServer2Server::BEGIN{package NXServer2Server;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package NXServer2Server;no
 warnings;($__startMode="\x4e\x58");($__serverPid=(""));($__cmdIn=(-
(0x0d6d+ 108-0x0dd8)));($__cmdOut=(-(0x003c+ 3886-0x0f69)));($__cmdErr=(-
(0x0a5a+ 962-0x0e1b)));($__insidePipeFD=(-(0x10a2+ 2371-0x19e4)));(
$__outsidePipeFD=(-(0x1ac2+ 2282-0x23ab)));($__insideCallbackFD=(-
(0x12c8+ 3373-0x1ff4)));($__outsideCallbackFD=(-(0x17a4+ 3529-0x256c)));(
$__shell=undef);($__tempIdentityDirectory=(""));($__responseBuffer="\x0a");(
$__unexpectedCode=(-(0x0f63+ 1503-0x1541)));sub execute{(my (@sequence)=@_);(my $flag_exited
=(0x1941+ 2783-0x2420));(my $flag_unexpected=(0x1147+ 851-0x149a));if ((
__startServer2Server ()!=(0x06ba+ 5987-0x1e1d))){($flag_exited=
(0x0584+ 463-0x0752));($flag_unexpected=(0x037c+ 7260-0x1fd7));}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;__addCallbackToSelect ((\$selector));__addCommunicationToSelect ((\$selector));
(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});if (($selector->
count>(0x0f69+ 4615-0x2170))){$selector->add ($signalFd);}($$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=(\&abort));while (($flag_exited
==(0x18f4+ 1408-0x1e74))){(my (@ready)=$selector->can_read ((
$GLOBAL::AuthorizationTimeout *(0x07ba+ 7794-0x2244))));if ((scalar (@ready)==
(0x06d7+ 2153-0x0f40))){Logger::warning (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
);($flag_exited=(0x1fe3+ 959-0x23a1));last;}foreach my $fd (@ready){if (($fd==
__getCommunicationFD ())){my ($buffer);(my $bytes=main::nxread ($fd,(\$buffer),
(0x066a+ 1664-0x0aea)));if (($bytes>(0x079c+ 7522-0x24fe))){Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x3a\x20"
.$buffer)."\x2e"));($__responseBuffer.=$buffer);}else{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);__removeCallbackFromSelect ((\$selector));__removeCommunicationFromSelect ((
\$selector));if (($selector->count==(0x2034+ 1353-0x257c))){$selector->remove (
$signalFd);}($flag_exited=(0x03e3+ 7923-0x22d5));last;}while (($__responseBuffer
=~ s/([^\n]*?)\n+NX> (\d+) (.*)/$3/ )){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x61\x72\x73\x69\x6e\x67\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x62\x75\x66\x66\x65\x72\x2e"
);(my $__responseBody=$1);(my $__responseCode=$2);Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x63\x6f\x64\x65\x20"
.$__responseCode)."\x2c\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20").
$__responseBody)."\x2e"));if (($__responseCode eq $GLOBAL::MSG_DEBUG)){
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x64\x65\x62\x75\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);next;}if (($__responseCode eq $GLOBAL::REQUEST_FOR)){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);next;}if (($__responseCode eq $GLOBAL::MSG_RESPONSE_NODE_DISTRIBUTION_INFO)){
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x64\x69\x73\x74\x72\x69\x62\x75\x74\x69\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);next;}if (($__responseCode eq $GLOBAL::MSG_BYE)){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x72\x76\x65\x72\x20\x68\x61\x73\x20\x65\x78\x69\x74\x2e"
);($flag_exited=(0x1183+ 1169-0x1613));last;}if (($flag_unexpected==
(0x1622+ 2520-0x1ff9))){Logger::warning (((((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x77\x69\x74\x68\x20\x63\x6f\x64\x65\x20"
.$__responseCode).
"\x20\x77\x68\x65\x6e\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20").
$GLOBAL::MSG_BYE)."\x2e"));($flag_exited=(0x11f5+ 333-0x1341));last;}if (defined
 ($sequence[(0x01f8+ 715-0x04c3)])){(my $sequenceExpected=shift (@sequence));(my $sequenceReply
=shift (@sequence));if (($__responseCode ne $sequenceExpected)){Logger::warning 
(((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x77\x69\x74\x68\x20\x63\x6f\x64\x65\x20"
.$__responseCode)."\x2e"));($flag_unexpected=(0x0b5b+ 6373-0x243f));(
$__unexpectedCode=$__responseCode);Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x65\x78\x69\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x2e"
);__sendToServer ("\x65\x78\x69\x74\x0a\x71\x75\x69\x74\x0a");}else{
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$sequenceExpected)."\x2e"));if (($sequenceReply ne (""))){($sequenceReply=~ s/\n//g )
;Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x74\x20\x73\x65\x71\x75\x65\x6e\x63\x65\x20\x72\x65\x70\x6c\x79\x3a\x20"
.$sequenceReply)."\x2e"));__sendToServer (($sequenceReply."\x0a"));}else{
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x2e"
);}}}else{Logger::warning (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x6e\x64\x20\x6f\x66\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x71\x75\x65\x75\x65\x2e\x20\x53\x65\x6e\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x65\x78\x69\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72"
);($flag_unexpected=(0x2072+ 862-0x23cf));__sendToServer (
"\x65\x78\x69\x74\x0a\x71\x75\x69\x74\x0a");}Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x70\x61\x72\x73\x69\x6e\x67\x2e\x20\x52\x65\x6d\x61\x69\x6e\x73\x3a\x20"
.$__responseBuffer)."\x2e"));}}elsif (($fd==__getCallbackFD ())){my ($buffer);(my $readSize
=main::nxread ($fd,(\$buffer),(0x0ca3+ 3950-0x1a11)));if (($readSize>
(0x1abd+ 792-0x1dd5))){Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x28\x63\x61\x6c\x6c\x62\x61\x63\x6b\x29\x3a\x20"
.$buffer)."\x2e"));}else{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6c\x6c\x62\x61\x63\x6b\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);__removeCallbackFromSelect ((\$selector));}if (($buffer=~ /UsernameCallback/ )
){(my $username="\x6e\x78");Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x2e"));__sendToCallback ($username);}elsif (($buffer=~ /event=2/ )
){(my $keyPassword="\x0a");Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x6b\x65\x79\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x2e"
);__sendToCallback ($keyPassword);}}}}__removeTempIdentityServerFileAndDirectory
 ();__closeCallback ();__closeCommunication ();__closeServer ();if (defined (
$sequence[(0x1000+ 104-0x1068)])){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x6e\x64\x20\x6f\x66\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x71\x75\x65\x75\x65\x2e"
);($flag_unexpected=(0x05ad+ 4414-0x16ea));}if ((($flag_unexpected==
(0x14e0+ 1911-0x1c57))and ($flag_exited==(0x0c5d+ 6789-0x26e1)))){Logger::debug 
(
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x2e"
);return ((0x12df+ 473-0x14b8),(0x00a5+ 4182-0x10fb));}($__responseBuffer=~ s/\n+(.*)\n+/$1/ )
;Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x73\x2e"
);return ($__responseBuffer,$__unexpectedCode);}sub __startServer2ServerByNX{(my (
@command)=());push (@command,NXPaths::getServerLaunchPath ());push (@command,
"\x2d\x2d\x6c\x6f\x67\x69\x6e");(my (@options)=());push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$__serverPid));push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20\x30\x20\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20\x30"
);main::nxRunCommandBg ((\@command),(\@options),(\$__cmdIn),(\$__cmdOut),(
\$__cmdErr));(my ($rcOut,$rcErr,$rcExit)=main::nxRunCommandBg ((\@command),(
\@options),(\$__cmdIn),(\$__cmdOut),(\$__cmdErr)));if (($rcExit==(-
(0x16f4+ 2355-0x2026)))){main::nxexit ((0x1966+ 1933-0x20f2));}}sub 
setServerStartMode{(my $mode=shift (@_));if (($mode eq "\x53\x53\x48")){(
$__startMode="\x53\x53\x48");}else{($__startMode="\x4e\x58");}}sub 
__getServerStartMode{return ($__startMode);}sub __isServerStartModeNX{if ((
__getServerStartMode ()eq "\x4e\x58")){return ((0x070b+ 1653-0x0d7f));}return (
(0x0a7b+ 4201-0x1ae4));}sub __isServerStartModeSSH{if ((__getServerStartMode ()
eq "\x53\x53\x48")){return ((0x0115+ 1869-0x0861));}return (
(0x14bf+ 4483-0x2642));}sub __startServer2Server{return (
__startServer2ServerByNX ());}sub __setServerPid{($__serverPid=shift (@_));}sub 
__getServerPid{return ($__serverPid);}sub __getTempIdentityDirectory{return (
$__tempIdentityDirectory);}sub __getTempIdentityFile{return (((
$__tempIdentityDirectory.$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x6c\x6f\x67"));
}sub __setTempIdentityDirectory{($__tempIdentityDirectory=
Common::NXPaths::getNxDirectoryInEffectiveUserHomeDirectory ());(
$__tempIdentityDirectory.=($GLOBAL::DIRECTORY_SLASH."\x74\x65\x6d\x70"));(
$__tempIdentityDirectory.=($GLOBAL::DIRECTORY_SLASH.$ $));
 }sub 
__removeTempIdentityServerFileAndDirectory{if ((__getServerStartMode ()eq 
"\x53\x53\x48")){if (Common::NXFile::fileExists (__getTempIdentityFile ())){if (
(not (unlink (__getTempIdentityFile ())))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20".
__getTempIdentityFile ()).("\x3a\x20".$!)),(0x2115+ 372-0x2289));}else{if (-d (
__getTempIdentityDirectory ())){if ((not (rmdir (__getTempIdentityDirectory ()))
)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.__getTempIdentityDirectory ()).("\x3a\x20".$!)),(0x1473+ 3202-0x20f5));}}}}}}
sub __createCommunicationPipe{my ($error);if ((
Common::NXCore::nxPipeCreateBiWithError ((\$__insidePipeFD),(\$__outsidePipeFD),
(\$error))==(0x0786+ 4505-0x191f))){(my $errorMsg=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x63\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x70\x69\x70\x65\x3a\x20"
.$error)."\x2e"));Logger::error ($errorMsg);__setErrorMsg ($errorMsg);return (
(0x00f6+ 4847-0x13e4));}}sub __createCallbackPipe{my ($error);if ((
Common::NXCore::nxPipeCreateBiWithError ((\$__insideCallbackFD),(
\$__outsideCallbackFD),(\$error))==(0x0742+ 265-0x084b))){(my $errorMsg=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x70\x69\x70\x65\x3a\x20"
.$error)."\x2e"));Logger::error ($errorMsg);__setErrorMsg ($errorMsg);return (
(0x0d73+ 1789-0x146f));}}sub __getCommunicationFD{if (__isServerStartModeNX ()){
return ($__cmdOut);}else{return ($__insidePipeFD);}}sub __getCallbackFD{return (
$__insideCallbackFD);}sub abort{Logger::debug (
"\x54\x68\x65\x20\x75\x73\x65\x72\x20\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x2e");
__removeTempIdentityServerFileAndDirectory ();__closeCallback ();
__closeCommunication ();__closeServer ();Common::NXCore::nxexit ();}sub 
__sendToServer{(my $message=shift (@_));if (__isServerStartModeNX ()){
main::nxwrite ($__cmdIn,$message);}elsif (__isServerStartModeSSH ()){
main::nxwrite ($__insidePipeFD,$message);}}sub __sendToCallback{(my $message=
shift (@_));if (__isServerStartModeSSH ()){main::nxwrite ($__insideCallbackFD,
$message);}}sub __closeServer{if ((not (Common::NXProcess::isChildFinished (
__getServerPid ())))){(my $wait_result=Common::NXProcess::nxwaitpid (
__getServerPid (),$NXBits::WAIT_UNTRACED,(0x07e1+ 3185-0x144d)));if ((
$wait_result==(0x19b9+ 2429-0x2336))){Logger::debug ((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x2c\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x6b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x69\x64\x20"
.__getServerPid ()));if (Common::NXProcess::sigkill (__getServerPid ())){
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x2c\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x6b\x69\x6c\x6c\x65\x64\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.__getServerPid ())."\x2e"));}else{Logger::error (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x2c\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.__getServerPid ())."\x2e"));}}}if (__isServerStartModeSSH ()){if (defined (
$__shell)){$__shell->disconnect;($__shell=undef);}}}sub __closeCallback{if (
__isServerStartModeSSH ()){if (($__insideCallbackFD!=(-(0x1234+ 5126-0x2639)))){
main::nxclose ($__insideCallbackFD);($__insideCallbackFD=(-(0x0299+ 6286-0x1b26)
));}}}sub __closeCommunication{if (__isServerStartModeNX ()){if (($__cmdIn!=(-
(0x0cb9+ 4795-0x1f73)))){main::nxclose ($__cmdIn);($__cmdIn=(-
(0x21b5+ 1261-0x26a1)));}if (($__cmdOut!=(-(0x0037+ 5824-0x16f6)))){
main::nxclose ($__cmdOut);($__cmdOut=(-(0x02c9+ 5076-0x169c)));}if (($__cmdErr!=
(-(0x0bb7+ 830-0x0ef4)))){main::nxclose ($__cmdErr);($__cmdErr=(-
(0x0c7d+ 5185-0x20bd)));}"\x5f\x5f\x63\x6c\x6f\x73\x65";}elsif (
__isServerStartModeSSH ()){if (($__insidePipeFD!=(-(0x078a+ 1062-0x0baf)))){
main::nxclose ($__insidePipeFD);($__insidePipeFD=(-(0x0a54+ 3662-0x18a1)));}}}
sub __addCallbackToSelect{(my $ref_selector=shift (@_));if (
__isServerStartModeSSH ()){if (($__insideCallbackFD!=(-(0x237d+ 511-0x257b)))){
$$ref_selector->add ($__insideCallbackFD);}}}sub __addCommunicationToSelect{(my $ref_selector
=shift (@_));if (__isServerStartModeSSH ()){if (($__insidePipeFD!=(-
(0x0fd0+ 2011-0x17aa)))){$$ref_selector->add ($__insidePipeFD);}}if (
__isServerStartModeNX ()){if (($__cmdOut!=(-(0x0151+ 8526-0x229e)))){
$$ref_selector->add ($__cmdOut);}}}sub __removeCallbackFromSelect{(my $ref_selector
=shift (@_));if ($$ref_selector->exists ($__insideCallbackFD)){$$ref_selector->
remove ($__insideCallbackFD);}}sub __removeCommunicationFromSelect{(my $ref_selector
=shift (@_));if ($$ref_selector->exists ($__insidePipeFD)){$$ref_selector->
remove ($__insidePipeFD);}}sub __setErrorMsg{(my $msg=shift (@_));(
$__unexpectedCode=$GLOBAL::MSG_ERROR);($__responseBuffer=$msg);}return (
(0x18e5+ 869-0x1c49));
