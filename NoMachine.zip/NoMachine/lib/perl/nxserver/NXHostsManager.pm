############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"->import};}sub 
NXHostsManager::put{package NXHostsManager;no warnings;return (__put (@_));}sub 
NXHostsManager::del{package NXHostsManager;no warnings;return (__del (@_));}sub 
NXHostsManager::list{package NXHostsManager;no warnings;return (show (@_));}sub 
NXHostsManager::edit{package NXHostsManager;no warnings;return (__edit (@_));}
sub NXHostsManager::show{package NXHostsManager;no warnings;(my (@hosts)=__list 
(@_));main::nxwrite (main::nxgetSTDOUT (),"\x0a");main::nxwrite (
main::nxgetSTDOUT (),
"\x43\x6c\x69\x65\x6e\x74\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x52\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4d\x6f\x64\x65\x0a"
);main::nxwrite (main::nxgetSTDOUT (),("\x2d" x (0x0f98+ 5968-0x26ca)),"\x20",(
"\x2d" x (0x070d+ 3901-0x162c)),"\x20",("\x2d" x (0x17f1+ 630-0x1a52)),"\x0a");
foreach my $host (@hosts){chomp ($host);($host=~ s/\r//g );(my ($client,
$redirect,$auth)=split ( /,/ ,$host,(0x1fad+  27-0x1fc4)));($client=sprintf (
"\x25\x2d\x33\x30\x73",$client));($redirect=sprintf ("\x25\x2d\x33\x30\x73",
$redirect));($auth=sprintf ("\x25\x2d\x32\x31\x73",($auth.
"\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e")));main::nxwrite 
(main::nxgetSTDOUT (),((((($client."\x20").$redirect)."\x20").$auth)."\x0a"));}
main::nxwrite (main::nxgetSTDOUT (),"\x0a");}sub NXHostsManager::__put{package 
NXHostsManager;no warnings;(my (@fields)=@_);NXRedis::sendToDb (((((((((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$fields[(0x16a4+ 172-0x1750)]).
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x76\x61\x6c\x75\x65\x3d"
).$fields[(0x0038+ 9751-0x264f)]).
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x76\x61\x6c\x75\x65\x3d"
).$fields[(0x0667+ 5026-0x1a08)])."\x3a").$fields[(0x0ad4+ 675-0x0d75)]).
"\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x2c\x76\x61\x6c\x75\x65\x3d").
$fields[(0x02f1+ 2626-0x0d30)])."\x0a"));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2c\x76\x61\x6c\x75\x65\x3d"
.$fields[(0x1d59+ 1400-0x22d1)])."\x0a"));return ((0x17f3+ 2565-0x21f7));}sub 
NXHostsManager::__del{package NXHostsManager;no warnings;(my $clientIpToDelete=
shift (@_));if (checkClientRedirectExist ($clientIpToDelete)){NXRedis::sendToDb 
(((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x72\x65\x6d\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2c\x76\x61\x6c\x75\x65\x3d"
.$clientIpToDelete)."\x0a"));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$clientIpToDelete)."\x0a"));return ((0x0906+ 4543-0x1ac4));}else{return (
(0x0d49+ 6592-0x2709));}}sub NXHostsManager::__list{package NXHostsManager;no 
warnings;(my $clientIpToFind=shift (@_));(my (@hosts)=());if ($clientIpToFind){
NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$clientIpToFind).
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x0a"
));(my $line=NXRedis::get ());($line=~ s/ /,/g );push (@hosts,$line);}else{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x0a"
);(my (@hostList)=split ( / / ,NXRedis::get (),(0x007b+ 1380-0x05df)));foreach 
$host (@hostList){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$host).
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x0a"
));(my $line=NXRedis::get ());($line=~ s/ /,/g );push (@hosts,$line);}}return (
@hosts);}sub NXHostsManager::__edit{package NXHostsManager;no warnings;(my $client
=shift (@_));(my $host=shift (@_));(my $port=shift (@_));(my $switch=shift (@_))
;if (checkClientRedirectExist ($client)){if ((defined ($host)and defined ($port)
)){NXRedis::sendToDbAndSave (((((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$client).
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x76\x61\x6c\x75\x65\x3d"
).$host)."\x3a").$port)."\x0a"));}if (defined ($switch)){
NXRedis::sendToDbAndSave (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$client).
"\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x2c\x76\x61\x6c\x75\x65\x3d").
$switch)."\x0a"));}}NXMsg::send_response (
"\x69\x48\x6f\x73\x74\x45\x64\x69\x74\x65\x64",
"\x4e\x58\x48\x6f\x73\x74\x73\x4d\x61\x6e\x61\x67\x65\x72",$client);return (
(0x16cb+ 1743-0x1d99));}sub NXHostsManager::checkClientRedirectExist{package 
NXHostsManager;no warnings;(my $client=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x65\x78\x69\x73\x74\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$client)."\x0a"));(my $result=NXRedis::get ());if (($result==
(0x147f+ 3337-0x2187))){Logger::debug ((("\x48\x6f\x73\x74\x3a\x20\x27".$client)
."\x27\x20\x65\x78\x69\x73\x74\x73\x2e"));}return ($result);}sub 
NXHostsManager::getClientRedirectBeforeAuth{package NXHostsManager;no warnings;(my $client
=shift (@_));return (__getClientRedirect ($client,(0x1758+ 532-0x196b)));}sub 
NXHostsManager::getClientRedirectAfterAuth{package NXHostsManager;no warnings;(my $client
=shift (@_));return (__getClientRedirect ($client,(0x06af+ 3791-0x157e)));}sub 
NXHostsManager::__getClientRedirect{package NXHostsManager;no warnings;(my $client
=shift (@_));(my $authbeforelogin=shift (@_));my (@hostTab);my (@ipTab);(my $all
=(0x009c+ 5734-0x1702));if (NXLicense::isNotRedirectFeature ()){return (
(0x0f4f+ 5493-0x24c4));}(my (@hostlist)=__list ());foreach my $hostline (
@hostlist){($hostline=~ s/\n//g );(my (@line)=split ( /,/ ,$hostline,
(0x1038+ 4052-0x200c)));if ((($line[(0x13a6+ 4891-0x26c1)]eq "\x2a")or ($line[
(0x0e7b+ 5323-0x2346)]eq "\x2a\x2e\x2a\x2e\x2a\x2e\x2a"))){if (((
$authbeforelogin and ($line[(0x0d35+ 230-0x0e19)]eq "\x62\x65\x66\x6f\x72\x65"))
or ((not ($authbeforelogin))and ($line[(0x02c6+ 4686-0x1512)]eq 
"\x61\x66\x74\x65\x72")))){($all=$line[(0x07e6+ 1442-0x0d87)]);}}elsif (($line[
(0x01cf+ 1694-0x086d)]=~ /^[0-9\*\.]{1,15}$/ )){if ((($authbeforelogin and (
$line[(0x0dc6+ 2440-0x174c)]eq "\x62\x65\x66\x6f\x72\x65"))or ((not (
$authbeforelogin))and ($line[(0x0a8d+ 4972-0x1df7)]eq "\x61\x66\x74\x65\x72"))))
{push (@ipTab,[$line[(0x0221+ 5834-0x18eb)],$line[(0x0b6d+ 1731-0x122f)],$line[
(0x1ad0+ 520-0x1cd6)]]);}}else{if ((($authbeforelogin and ($line[
(0x03db+ 1396-0x094d)]eq "\x62\x65\x66\x6f\x72\x65"))or ((not ($authbeforelogin)
)and ($line[(0x0c63+ 1708-0x130d)]eq "\x61\x66\x74\x65\x72")))){push (@hostTab,[
$line[(0x121f+ 3812-0x2103)],$line[(0x1d01+ 236-0x1dec)],$line[
(0x17e9+ 2162-0x2059)]]);}}}(my $regEx=(""));foreach my $ipLine (@ipTab){(my (
@pieces)=split ( /\./ ,@{$ipLine;}[(0x0851+ 5315-0x1d14)],(-
(0x0592+ 6134-0x1d87))));(my $piecesCount=scalar (@pieces));($regEx=@{$ipLine;}[
(0x2158+  17-0x2169)]);if (($piecesCount<(0x0d34+ 3638-0x1b66))){if (($pieces[
(0x08ad+ 5195-0x1cf8)]=~ /^\*/ )){($regEx=("\x2e\x7b\x30\x2c\x7d".$regEx));}if (
($pieces[$piecesCount-(0x0838+ 2965-0x13cc)]=~ /\*$/ )){($regEx.=
"\x2e\x7b\x30\x2c\x7d");}}($regEx=~ s/\*/(|[0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/g )
;if (($client=~ /^($regEx)$/ )){return (@{$ipLine;}[(0x07cd+ 4930-0x1b0e)]);}}
foreach my $hostLine (@hostTab){(my (@ipdata)=split ( /\./ ,$client,
(0x04b8+ 4971-0x1823)));(my $ippacked=pack ("\x43\x34",@ipdata));(my $host=
gethostbyaddr ($ippacked,(0x0334+ 297-0x045b)));if ((@{$hostLine;}[
(0x0f92+ 5893-0x2697)]=~ /^\*/ )){(@{$hostLine;}[(0x1898+ 620-0x1b04)]=~ s/^\*// )
;}else{(@{$hostLine;}[(0x0f74+ 1646-0x15e2)]=("\x5e".@{$hostLine;}[
(0x2300+ 246-0x23f6)]));}if ((@{$hostLine;}[(0x15a4+ 1335-0x1adb)]=~ /\*$/ )){(@
{$hostLine;}[(0x0b8f+ 5902-0x229d)]=~ s/\*$// );}else{(@{$hostLine;}[
(0x066d+ 5814-0x1d23)]=(@{$hostLine;}[(0x0203+ 6333-0x1ac0)]."\x24"));}if ((
$host=~ @{$hostLine;}[0] )){return (@{$hostLine;}[(0x1f15+ 1066-0x233e)]);}}if (
$all){return ($all);}Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x66\x6f\x75\x6e\x64\x20\x63\x6c\x69\x65\x6e\x74\x20\x49\x50\x3a\x20\x27"
.$client)."\x27\x20\x69\x6e\x20\x68\x6f\x73\x74\x73\x2e\x64\x62\x2e"));return (
(0x0ef2+ 1227-0x13bd));}package NXHostsManager;no warnings;
NXMsg::register_response (
"\x4e\x58\x48\x6f\x73\x74\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x69\x48\x6f\x73\x74\x45\x64\x69\x74\x65\x64",(0x119c+ 4948-0x2461));
"\x3f\x3f\x3f";
