############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXProfiles::BEGIN{package NXProfiles;no warnings;require NXProfilesDB;do{
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42"->import};}package NXProfiles;
no warnings;($mode_bool="\x62\x6f\x6f\x6c");($mode_value="\x76\x61\x6c\x75\x65")
;($value_allowed="\x61\x6c\x6c\x6f\x77\x65\x64");($value_denied=
"\x6e\x6f\x74\x5f\x61\x6c\x6c\x6f\x77\x65\x64");($value_unspecified=
"\x6e\x6f\x74\x53\x70\x65\x63\x69\x66\x69\x65\x64");@profilesDB;%field;($field{
"\x6b\x65\x79"}=(0x13e5+ 1029-0x17ea));($field{"\x6e\x6f\x64\x65"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}=(0x069d+ 6677-0x20b1));($field{
"\x6e\x6f\x64\x65"}{"\x64\x65\x6e\x69\x65\x64"}=(0x1ecf+ 1383-0x2434));($field{
"\x6e\x6f\x64\x65"}{"\x76\x61\x6c\x75\x65"}=(0x0137+ 746-0x041e));($field{
"\x73\x65\x73\x73\x69\x6f\x6e"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}=
(0x070d+ 2018-0x0eeb));($field{"\x73\x65\x73\x73\x69\x6f\x6e"}{
"\x64\x65\x6e\x69\x65\x64"}=(0x0126+ 8288-0x2181));($field{
"\x73\x65\x73\x73\x69\x6f\x6e"}{"\x76\x61\x6c\x75\x65"}=(0x10dd+ 450-0x1299));(
$field{"\x73\x65\x72\x76\x69\x63\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}=
(0x0fab+ 3105-0x1bc5));($field{"\x73\x65\x72\x76\x69\x63\x65"}{
"\x64\x65\x6e\x69\x65\x64"}=(0x0131+ 1100-0x0575));($field{
"\x73\x65\x72\x76\x69\x63\x65"}{"\x76\x61\x6c\x75\x65"}=(0x1101+ 403-0x128b));(
$field{"\x66\x65\x61\x74\x75\x72\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}=
(0x0329+ 8830-0x259d));($field{"\x66\x65\x61\x74\x75\x72\x65"}{
"\x64\x65\x6e\x69\x65\x64"}=(0x011b+ 3184-0x0d80));($field{
"\x66\x65\x61\x74\x75\x72\x65"}{"\x76\x61\x6c\x75\x65"}=(0x0282+ 5995-0x19e1));(
$field{"\x61\x64\x69\x74\x69\x6f\x6e\x61\x6c\x5f\x69\x6e\x66\x6f"}=
(0x0556+ 2612-0x0f7d));($field{"\x73\x65\x72\x76\x65\x72"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}=(0x042a+ 8757-0x2651));($field{
"\x73\x65\x72\x76\x65\x72"}{"\x64\x65\x6e\x69\x65\x64"}=(0x1779+ 1082-0x1ba4));(
$field{"\x73\x65\x72\x76\x65\x72"}{"\x76\x61\x6c\x75\x65"}=(0x11c8+ 4687-0x2407)
);($field{"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{"\x61\x6c\x6c\x6f\x77\x65\x64"
}=(0x0267+ 5424-0x1786));($field{"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{
"\x64\x65\x6e\x69\x65\x64"}=(0x1c66+ 1298-0x2166));($field{
"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{"\x76\x61\x6c\x75\x65"}=
(0x0d32+ 5852-0x23fb));($field{"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}=(0x0c93+ 1554-0x1291));($field{
"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{"\x64\x65\x6e\x69\x65\x64"}=
(0x0a3b+ 3013-0x15eb));($field{"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{
"\x76\x61\x6c\x75\x65"}=(0x0774+ 2417-0x10cf));((%propagatedRules)=());(
$overwriteRules=(0x12ac+ 2005-0x1a81));((%calcResources)=());($resourcesReady=
(0x0336+ 4717-0x15a3));($propagatedTrusted=(0x077f+ 2003-0x0f52));sub 
getValueDenied{return ($value_denied);}sub __addRule{(my $name=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));
(my $skipSave=(shift (@_)||(0x1d2b+ 1171-0x21be)));(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());(my $key=$name);
NXProfilesDB::convertUsernameInKeyToAbsoluteUsername ((\$key));if ((($class eq 
"\x73\x65\x72\x76\x65\x72")or (($class eq 
"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e")and NXNodes::isUUID ($type)))){
__addServerToProfileCheck ($type);}(my $refArray_profile=getProfileForKey ($key,
$refHash_DB));if ((not (defined ($refArray_profile)))){(my (@profile)=
__createNewProfileForKey ($name));if (($mode eq $mode_value)){if (($value eq 
$value_denied)){__addTypeToValueClass ((""),$type,$field{$class}{
"\x76\x61\x6c\x75\x65"},$class,(\@profile));}else{__addTypeToValueClass ($value,
$type,$field{$class}{"\x76\x61\x6c\x75\x65"},$class,(\@profile));}}else{if ((
$value eq $value_allowed)){__addRuleToFieldOfProfile ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},(\@profile));if ((($class eq 
"\x66\x65\x61\x74\x75\x72\x65")and ($type eq 
"\x6d\x61\x6e\x75\x61\x6c\x2d\x6e\x6f\x64\x65\x2d\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e"
))){NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x6d\x61\x6e\x75\x61\x6c\x53\x65\x6c\x65\x63\x74\x69\x6f\x6e\x2c\x76\x61\x6c\x75\x65\x3d\x31\x0a"
);}}elsif (($value eq $value_denied)){__addRuleToFieldOfProfile ($type,$field{
$class}{"\x64\x65\x6e\x69\x65\x64"},(\@profile));}else{Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x76\x61\x6c\x75\x65\x20\x27"
.$value)."\x27\x20\x69\x6e\x20\x6d\x6f\x64\x65\x3a\x20").$mode)."\x2e"));
Common::NXCore::assertExit ((0x063d+ 2125-0x0e89));}}($$refHash_DB{$key}=(
\@profile));unless (($skipSave==(0x0731+ 7884-0x25fc))){NXProfilesDB::save ();}
return ((0x1619+ 2682-0x2092));}else{Logger::debug3 (((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x3a\x5f\x5f\x61\x64\x64\x52\x75\x6c\x65\x3a\x20\x45\x78\x69\x73\x74\x69\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x3a\x20"
.join ($",@$refArray_profile))."\x2e"));if (($mode eq $mode_value)){(my $oldValue
=__getTypeFromValueClass ($type,$field{$class}{"\x76\x61\x6c\x75\x65"},
@$refArray_profile));if (($value eq $value_denied)){if (defined ($oldValue)){
__modifyTypeFromValueClass ((""),$type,$field{$class}{"\x76\x61\x6c\x75\x65"},
$refArray_profile);}else{__addTypeToValueClass ((""),$type,$field{$class}{
"\x76\x61\x6c\x75\x65"},$class,$refArray_profile);}}else{if (defined ($oldValue)
){__modifyTypeFromValueClass ($value,$type,$field{$class}{"\x76\x61\x6c\x75\x65"
},$refArray_profile);}else{__addTypeToValueClass ($value,$type,$field{$class}{
"\x76\x61\x6c\x75\x65"},$class,$refArray_profile);}}}else{if (($value eq 
$value_allowed)){if (__existsTypeInBoolClass ($type,$field{$class}{
"\x64\x65\x6e\x69\x65\x64"},@$refArray_profile)){__removeTypeFromFieldOfProfile 
($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},$refArray_profile);}if ((not (
__existsTypeInBoolClass ($type,$field{$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"},
@$refArray_profile)))){__addRuleToFieldOfProfile ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},$refArray_profile);}else{Logger::debug3 (
"\x52\x75\x6c\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x65\x78\x69\x73\x74\x73\x20\x69\x6e\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
);return ((0x08aa+ 2897-0x13fa));}}elsif (($value eq $value_denied)){if (
__existsTypeInBoolClass ($type,$field{$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"},
@$refArray_profile)){__removeTypeFromFieldOfProfile ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},$refArray_profile);}if ((not (
__existsTypeInBoolClass ($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},
@$refArray_profile)))){__addRuleToFieldOfProfile ($type,$field{$class}{
"\x64\x65\x6e\x69\x65\x64"},$refArray_profile);}else{Logger::debug3 (
"\x52\x75\x6c\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x65\x78\x69\x73\x74\x73\x20\x69\x6e\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
);return ((0x042d+ 8257-0x246d));}}else{Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x76\x61\x6c\x75\x65\x20\x27"
.$value)."\x27\x20\x69\x6e\x20\x6d\x6f\x64\x65\x3a\x20").$mode)."\x2e"));
Common::NXCore::assertExit ((0x17e8+ 2348-0x2113));}}unless (($skipSave==
(0x0dc9+ 2758-0x188e))){NXProfilesDB::save ();}return ((0x1d8f+ 2293-0x2683));}}
sub __addRuleToFieldOfProfile{(my $type=shift (@_));(my $field=shift (@_));(my $profile_ref
=shift (@_));(my $fieldContent=__getFieldFromProfile ($field,@$profile_ref));
Logger::debug3 (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x3a\x5f\x5f\x61\x64\x64\x52\x75\x6c\x65\x54\x6f\x46\x69\x65\x6c\x64\x4f\x66\x50\x72\x6f\x66\x69\x6c\x65\x3a\x20\x66\x69\x65\x6c\x64\x3d"
.$field)."\x20\x66\x69\x65\x6c\x64\x43\x6f\x6e\x74\x65\x6e\x74\x3d").
$fieldContent)."\x20\x70\x72\x6f\x66\x69\x6c\x65\x3d\x27").join ($",
@$profile_ref))."\x27\x2e"));if (((not (defined ($fieldContent)))or (
$fieldContent eq ("")))){__setFieldForProfile ($type,$field,$profile_ref);}else{
__setFieldForProfile ((($fieldContent."\x2c").$type),$field,$profile_ref);}}sub 
__removeTypeFromFieldOfProfile{(my $type=shift (@_));(my $field=shift (@_));(my $profile_ref
=shift (@_));(my $fieldContent=__getFieldFromProfile ($field,@$profile_ref));
Logger::debug3 (((((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x3a\x5f\x5f\x72\x65\x6d\x6f\x76\x65\x54\x79\x70\x65\x46\x72\x6f\x6d\x46\x69\x65\x6c\x64\x4f\x66\x50\x72\x6f\x66\x69\x6c\x65\x3a\x20\x66\x69\x65\x6c\x64\x3d"
.$field)."\x20\x74\x79\x70\x65\x3d").$type).
"\x20\x70\x72\x6f\x66\x69\x6c\x65\x3d").join ($",@$profile_ref)).
"\x20\x66\x69\x65\x6c\x64\x43\x6f\x6e\x74\x65\x6e\x74\x3d").$fieldContent).
"\x2e"));(my $newFieldContent=(""));(my (@items)=split ( /,/ ,$fieldContent,
(0x1440+ 613-0x16a5)));foreach my $item (@items){if (($item ne $type)){(
$newFieldContent.=($item."\x2c"));}}($newFieldContent=~ s/,$// );
__setFieldForProfile ($newFieldContent,$field,$profile_ref);}sub 
__modifyTypeFromValueClass{(my $value=shift (@_));(my $type=shift (@_));(my $field
=shift (@_));(my $profile_ref=shift (@_));(my $oldValue=__getTypeFromValueClass 
($type,$field,@$profile_ref));__removeTypeFromFieldOfProfile ((($type."\x3d").
$oldValue),$field,$profile_ref);__addRuleToFieldOfProfile ((($type."\x3d").
$value),$field,$profile_ref);}sub __addTypeToValueClass{(my $value=shift (@_));(my $type
=shift (@_));(my $field=shift (@_));(my $class=shift (@_));(my $profile_ref=
shift (@_));__addRuleToFieldOfProfile ((($type."\x3d").$value),$field{$class}{
"\x76\x61\x6c\x75\x65"},$profile_ref);}sub __deleteRule{(my $key=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));if (((not (defined ($class)))or (not (defined
 ($type))))){Logger::debug3 (((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x3a\x5f\x5f\x64\x65\x6c\x65\x74\x65\x52\x75\x6c\x65\x3a\x20\x4b\x65\x79\x20\x27"
.$key)."\x27\x2e"));}else{Logger::debug3 (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x3a\x5f\x5f\x64\x65\x6c\x65\x74\x65\x52\x75\x6c\x65\x3a\x20\x4b\x65\x79\x20\x27"
.$key)."\x27\x20\x63\x6c\x61\x73\x73\x20\x27").$class).
"\x27\x20\x74\x79\x70\x65\x20\x27").$type)."\x27\x2e"));}
NXProfilesDB::convertUsernameInKeyToAbsoluteUsername ((\$key));(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());(my $refArray_profile=getProfileForKey (
$key,$refHash_DB));if ((not (defined ($refArray_profile)))){return (
(0x0027+ 9562-0x2581));}if ((defined ($class)and defined ($type))){(my $value=
__getTypeFromValueClass ($type,$field{$class}{"\x76\x61\x6c\x75\x65"},
@$refArray_profile));if (defined ($value)){__removeTypeFromFieldOfProfile (((
$type."\x3d").$value),$field{$class}{"\x76\x61\x6c\x75\x65"},$refArray_profile);
}elsif (__existsTypeInBoolClass ($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"
},@$refArray_profile)){__removeTypeFromFieldOfProfile ($type,$field{$class}{
"\x64\x65\x6e\x69\x65\x64"},$refArray_profile);}elsif (__existsTypeInBoolClass (
$type,$field{$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){
__removeTypeFromFieldOfProfile ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},$refArray_profile);if ((($class eq 
"\x66\x65\x61\x74\x75\x72\x65")and ($type eq 
"\x6d\x61\x6e\x75\x61\x6c\x2d\x6e\x6f\x64\x65\x2d\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e"
))){setManualSelectionState ();}}else{if (($class eq 
"\x73\x65\x73\x73\x69\x6f\x6e")){($type=Common::NXSessionType::convertToExternal
 ($type));NXMsg::error (
"\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72",$type);}
elsif (($class eq "\x6e\x6f\x64\x65")){NXMsg::error (
"\x65\x4e\x6f\x64\x65\x54\x79\x70\x65\x4e\x6f\x74\x45\x78\x69\x73\x74",
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72",$type);}
elsif (($class eq "\x73\x65\x72\x76\x69\x63\x65")){NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x54\x79\x70\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72",$type);}
elsif (($class eq "\x66\x65\x61\x74\x75\x72\x65")){NXMsg::error (
"\x65\x43\x4d\x44\x46\x65\x61\x74\x75\x72\x65\x54\x79\x70\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
,"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72",$type);}
return ((0x0721+ 4402-0x1853));}if (__isEmptyProfileArray ($refArray_profile)){
delete ($$refHash_DB{$key});}}else{(my (@profile)=__createNewProfileForKey ($key
));($profile[$field{"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}]=$$refArray_profile[$field{
"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}]);(
$profile[$field{"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{
"\x64\x65\x6e\x69\x65\x64"}]=$$refArray_profile[$field{
"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{"\x64\x65\x6e\x69\x65\x64"}]);($profile[
$field{"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{"\x76\x61\x6c\x75\x65"}]=
$$refArray_profile[$field{"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67"}{
"\x76\x61\x6c\x75\x65"}]);if (__isEmptyProfileArray ((\@profile))){delete (
$$refHash_DB{$key});}else{($$refHash_DB{$key}=(\@profile));}}NXProfilesDB::save 
();return ((0x058a+ 152-0x0621));}sub __getRule{(my $key=shift (@_));(my $class=
shift (@_));(my $type=shift (@_));(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());
NXProfilesDB::convertUsernameInKeyToAbsoluteUsername ((\$key));(my $refArray_profile
=getProfileForKey ($key,$refHash_DB));if ((not (defined (@$refArray_profile)))){
Logger::debug3 ((((((("\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x27".
$class)."\x2f").$type)."\x27\x20\x66\x6f\x72\x20\x27").$key).
"\x27\x20\x2d\x20\x6e\x6f\x20\x70\x72\x6f\x66\x69\x6c\x65\x2e"));return (
$value_unspecified);}if (__existsTypeInBoolClass ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){Logger::debug3 (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x27".$class)."\x2f").$type).
"\x27\x20\x66\x6f\x72\x20\x27").$key).
"\x27\x20\x27\x61\x6c\x6c\x6f\x77\x65\x64\x27\x2e"));return ($value_allowed);}if
 (__existsTypeInBoolClass ($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},
@$refArray_profile)){Logger::debug3 (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x27".$class)."\x2f").$type).
"\x27\x20\x66\x6f\x72\x20\x27").$key).
"\x27\x20\x27\x64\x65\x6e\x69\x65\x64\x27\x2e"));return ($value_denied);}(my $value
=__getTypeFromValueClass ($type,$field{$class}{"\x76\x61\x6c\x75\x65"},
@$refArray_profile));if (defined ($value)){Logger::debug3 (((((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20".$class)."\x2f").$type).
"\x27\x20\x66\x6f\x72\x20\x27").$key)."\x27\x20\x76\x61\x6c\x75\x65\x20\x27").
$value)."\x27\x2e"));return ($value);}Logger::debug3 (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x27".$class)."\x2f").$type).
"\x27\x20\x66\x6f\x72\x20\x27").$key).
"\x27\x20\x27\x75\x6e\x73\x70\x65\x63\x69\x66\x69\x65\x64\x27\x2e"));return (
$value_unspecified);}sub __createNewProfileForKey{(my $key=shift (@_));(my (
@profile)=NXProfilesDB::getEmptyProfile ());($profile[$field{"\x6b\x65\x79"}]=
$key);return (@profile);}sub __getTypeFromValueClass{(my $type=shift (@_));(my $field
=shift (@_));(my (@profile)=@_);(my $fieldContent=__getFieldFromProfile ($field,
@profile));(my (@fieldContentTable)=split ( /,/ ,$fieldContent,
(0x000d+ 4691-0x1260)));foreach my $item (@fieldContentTable){if (($item=~ /(.*)=(.*)/ )
){(my $itemName=$1);(my $itemValue=$2);if (($type eq $itemName)){return (
$itemValue);}}else{Logger::warning (((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x65\x6e\x74\x72\x79\x20\x27"
.join ($",@profile))."\x27\x20\x61\x74\x20\x27").$item)."\x27\x2e"));
Common::NXCore::assertExit ((0x07f9+ 4119-0x180f));}}return (undef);}sub 
__existsTypeInBoolClass{(my $type=shift (@_));(my $field=shift (@_));(my (
@profile)=@_);(my $fieldContent=__getFieldFromProfile ($field,@profile));(my (
@fieldContentTable)=split ( /,/ ,$fieldContent,(0x18a7+ 937-0x1c50)));foreach my $item
 (@fieldContentTable){if (($type eq $item)){return ((0x015f+ 3337-0x0e67));}}
return ((0x1330+ 4829-0x260d));}sub checkProfileForUser{(my $username=shift (@_)
);(my $class=shift (@_));(my $type=shift (@_));return (__getRule ($username,
$class,$type));}sub addProfileForUser{(my $username=shift (@_));(my $class=shift
 (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));return
 (__addRule ($username,$class,$type,$mode,$value));}sub deleteProfileForUser{(my $username
=shift (@_));(my $class=shift (@_));(my $type=shift (@_));return (__deleteRule (
$username,$class,$type));}sub checkProfileForNode{(my $nodename=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $key=__translateNodenameToKey ($nodename)
);return (__getRule ($key,$class,$type));}sub addProfileForNode{(my $nodename=
shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value
=shift (@_));(my $key=__translateNodenameToKey ($nodename));return (__addRule (
$key,$class,$type,$mode,$value));}sub deleteProfileForNode{(my $nodename=shift (
@_));(my $class=shift (@_));(my $type=shift (@_));(my $key=
__translateNodenameToKey ($nodename));return (__deleteRule ($key,$class,$type));
}sub checkProfileForNodeGroup{(my $nodeGroup=shift (@_));(my $class=shift (@_));
(my $type=shift (@_));(my $key=translateNodeGroupToKey ($nodeGroup));return (
__getRule ($key,$class,$type));}sub checkProfileForServergroup{(my $servergroup=
shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $key=
translateServerGroupToKey ($servergroup));return (__getRule ($key,$class,$type))
;}sub addProfileForNodeGroup{(my $nodeGroup=shift (@_));(my $class=shift (@_));(my $type
=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));(my $key=
translateNodeGroupToKey ($nodeGroup));return (__addRule ($key,$class,$type,$mode
,$value));}sub addProfileForServergroup{(my $servergroup=shift (@_));(my $class=
shift (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));(my $key
=translateServerGroupToKey ($servergroup));return (__addRule ($key,$class,$type,
$mode,$value));}sub deleteProfileForNodeGroup{(my $nodeGroup=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $key=translateNodeGroupToKey ($nodeGroup)
);return (__deleteRule ($key,$class,$type));}sub deleteProfileForServergroup{(my $servergroup
=shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $key=
translateServerGroupToKey ($servergroup));return (__deleteRule ($key,$class,
$type));}sub deleteAllPropagationProfiles{(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());foreach my $profileKey (keys (
%$refHash_DB)){(my $refArray_profile=getProfileForKey ($profileKey,$refHash_DB))
;if ((not (defined (@$refArray_profile)))){next;}if (defined ($$refArray_profile
[$field{"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}])){($$refArray_profile[$field{
"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}]
=(""));}if (defined ($$refArray_profile[$field{
"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{"\x64\x65\x6e\x69\x65\x64"}])){(
$$refArray_profile[$field{"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{
"\x64\x65\x6e\x69\x65\x64"}]=(""));}if (defined ($$refArray_profile[$field{
"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{"\x76\x61\x6c\x75\x65"}])){(
$$refArray_profile[$field{"\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e"}{
"\x76\x61\x6c\x75\x65"}]=(""));}if (__isEmptyProfileArray ($refArray_profile)){
delete ($$refHash_DB{$profileKey});}}NXProfilesDB::save ();return (
(0x11fd+ 3471-0x1f8b));}sub checkProfileForNodeAndUser{(my $nodename=shift (@_))
;(my $username=shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $key
=__translateNodenameAndUsernameToKey ($nodename,$username));return (__getRule (
$key,$class,$type));}sub addProfileForNodeAndUser{(my $nodename=shift (@_));(my $username
=shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));
(my $value=shift (@_));(my $key=__translateNodenameAndUsernameToKey ($nodename,
$username));return (__addRule ($key,$class,$type,$mode,$value));}sub 
deleteProfileForNodeAndUser{(my $nodename=shift (@_));(my $username=shift (@_));
(my $class=shift (@_));(my $type=shift (@_));(my $key=
__translateNodenameAndUsernameToKey ($nodename,$username));return (__deleteRule 
($key,$class,$type));}sub checkProfileForGroup{(my $groupname=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $key=__translateGroupnameToKey (
$groupname));return (__getRule ($key,$class,$type));}sub addProfileForGroup{(my $groupname
=shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));
(my $value=shift (@_));(my $key=__translateGroupnameToKey ($groupname));
__addGroupToProfileCheck ($groupname);return (__addRule ($key,$class,$type,$mode
,$value));}sub deleteProfileForGroup{(my $groupname=shift (@_));(my $class=shift
 (@_));(my $type=shift (@_));(my $key=__translateGroupnameToKey ($groupname));
return (__deleteRule ($key,$class,$type));}sub checkProfileForNodeAndGroup{(my $nodename
=shift (@_));(my $groupname=shift (@_));(my $class=shift (@_));(my $type=shift (
@_));(my $key=__translateNodenameAndGroupnameToKey ($nodename,$groupname));
return (__getRule ($key,$class,$type));}sub addProfileForNodeAndGroup{(my $nodename
=shift (@_));(my $groupname=shift (@_));(my $class=shift (@_));(my $type=shift (
@_));(my $mode=shift (@_));(my $value=shift (@_));__addGroupToProfileCheck (
$groupname);(my $key=__translateNodenameAndGroupnameToKey ($nodename,$groupname)
);return (__addRule ($key,$class,$type,$mode,$value));}sub 
deleteProfileForNodeAndGroup{(my $nodename=shift (@_));(my $groupname=shift (@_)
);(my $class=shift (@_));(my $type=shift (@_));(my $key=
__translateNodenameAndGroupnameToKey ($nodename,$groupname));return (
__deleteRule ($key,$class,$type));}sub checkProfileForNodegroupAndGroup{(my $nodeGroup
=shift (@_));(my $userGroup=shift (@_));(my $class=shift (@_));(my $type=shift (
@_));(my $key=__translateNodegroupAndGroupnameToKey ($nodeGroup,$userGroup));
return (__getRule ($key,$class,$type));}sub addProfileForNodegroupAndGroup{(my $nodeGroup
=shift (@_));(my $userGroup=shift (@_));(my $class=shift (@_));(my $type=shift (
@_));(my $mode=shift (@_));(my $value=shift (@_));__addGroupToProfileCheck (
$userGroup);(my $key=__translateNodegroupAndGroupnameToKey ($nodeGroup,
$userGroup));return (__addRule ($key,$class,$type,$mode,$value));}sub 
deleteProfileForNodegroupAndGroup{(my $nodeGroup=shift (@_));(my $userGroup=
shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $key=
__translateNodegroupAndGroupnameToKey ($nodeGroup,$userGroup));return (
__deleteRule ($key,$class,$type));}sub checkProfileForNodeGroupAndUser{(my $nodeGroup
=shift (@_));(my $user=shift (@_));(my $class=shift (@_));(my $type=shift (@_));
(my $key=__translateNodeGroupAndUserToKey ($nodeGroup,$user));return (__getRule 
($key,$class,$type));}sub addProfileForNodeGroupAndUser{(my $nodeGroup=shift (@_
));(my $user=shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $mode=
shift (@_));(my $value=shift (@_));(my $key=__translateNodeGroupAndUserToKey (
$nodeGroup,$user));return (__addRule ($key,$class,$type,$mode,$value));}sub 
deleteProfileForNodeGroupAndUser{(my $nodeGroup=shift (@_));(my $user=shift (@_)
);(my $class=shift (@_));(my $type=shift (@_));(my $key=
__translateNodeGroupAndUserToKey ($nodeGroup,$user));return (__deleteRule ($key,
$class,$type));}sub checkProfileForSystem{(my $class=shift (@_));(my $type=shift
 (@_));(my $key=getInternalSystemKey ());return (__getRule ($key,$class,$type));
}sub __translateNodegroupAndGroupnameToKey{(my $nodeGroup=shift (@_));(my $groupname
=shift (@_));($nodeGroup=translateNodeGroupToKey ($nodeGroup));($groupname=
__translateGroupnameToKey ($groupname));return ((($nodeGroup."\x2c").$groupname)
);}sub addProfileForSystem{(my $class=shift (@_));(my $type=shift (@_));(my $mode
=shift (@_));(my $value=shift (@_));(my $key=getInternalSystemKey ());return (
__addRule ($key,$class,$type,$mode,$value));}sub deleteProfileForSystem{(my $key
=getInternalSystemKey ());(my $class=shift (@_));(my $type=shift (@_));
Logger::debug3 (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x44\x65\x6c\x65\x74\x65\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return (__deleteRule ($key,$class,$type));}sub checkProfileForGuests{(my $class
=shift (@_));(my $type=shift (@_));(my $key=getInternalGuestKey ());return (
__getRule ($key,$class,$type));}sub addProfileForGuests{(my $class=shift (@_));(my $type
=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));(my $key=
getInternalGuestKey ());return (__addRule ($key,$class,$type,$mode,$value));}sub
 deleteProfileForGuests{(my $key=getInternalGuestKey ());(my $class=shift (@_));
(my $type=shift (@_));return (__deleteRule ($key,$class,$type));}sub 
checkProfileForAddressAndUser{(my $address=shift (@_));(my $user=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());(my (@profiles)=
__getAllProfilesForAddressAndUser ($address,$user,$refHash_DB));if ((scalar (
@profiles)==(0x063f+ 3845-0x1544))){return ($value_unspecified);}foreach my $key
 (@profiles){(my $refArray_profile=getProfileForKey ($key,$refHash_DB));
Logger::debug3 (((((((((
"\x43\x68\x65\x63\x6b\x50\x72\x6f\x66\x69\x6c\x65\x46\x6f\x72\x41\x64\x64\x72\x65\x73\x73\x20\x6b\x65\x79\x3d"
.$key)."\x2c\x20\x63\x6c\x61\x73\x73\x3d").$class).
"\x2c\x20\x74\x79\x70\x65\x3d").$type)."\x20\x70\x72\x6f\x66\x69\x6c\x65\x3d").
join ($",@$refArray_profile))."\x2e"));if ((not (defined (@$refArray_profile))))
{next;}if (__existsTypeInBoolClass ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){return ($value_allowed);}if
 (__existsTypeInBoolClass ($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},
@$refArray_profile)){return ($value_denied);}}return ($value_unspecified);}sub 
addProfileForAddressAndUser{(my $address=shift (@_));(my $user=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));
(my $key=__translateAddressAndUsernameToKey ($address,$user));return (__addRule 
($key,$class,$type,$mode,$value));}sub deleteProfileForAddressAndUser{(my $address
=shift (@_));(my $user=shift (@_));(my $class=shift (@_));(my $type=shift (@_));
(my $key=__translateAddressAndUsernameToKey ($address,$user));return (
__deleteRule ($key,$class,$type));}sub checkProfileForAddressAndGroup{(my $address
=shift (@_));(my $group=shift (@_));(my $class=shift (@_));(my $type=shift (@_))
;(my $refHash_DB=NXProfilesDB::getDatabaseReference ());(my (@profiles)=
__getAllProfilesForAddressAndGroup ($address,$group,$refHash_DB));if ((scalar (
@profiles)==(0x08c6+ 327-0x0a0d))){return ($value_unspecified);}foreach my $key 
(@profiles){(my $refArray_profile=getProfileForKey ($key,$refHash_DB));
Logger::debug3 (((((((((
"\x43\x68\x65\x63\x6b\x50\x72\x6f\x66\x69\x6c\x65\x46\x6f\x72\x41\x64\x64\x72\x65\x73\x73\x20\x6b\x65\x79\x3d"
.$key)."\x2c\x20\x63\x6c\x61\x73\x73\x3d").$class).
"\x2c\x20\x74\x79\x70\x65\x3d").$type)."\x20\x70\x72\x6f\x66\x69\x6c\x65\x3d").
join ($",@$refArray_profile))."\x2e"));if ((not (defined (@$refArray_profile))))
{next;}if (__existsTypeInBoolClass ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){return ($value_allowed);}if
 (__existsTypeInBoolClass ($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},
@$refArray_profile)){return ($value_denied);}}return ($value_unspecified);}sub 
addProfileForAddressAndGroup{(my $address=shift (@_));(my $group=shift (@_));(my $class
=shift (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));
__addGroupToProfileCheck ($group);(my $key=__translateAddressAndGroupToKey (
$address,$group));return (__addRule ($key,$class,$type,$mode,$value));}sub 
deleteProfileForAddressAndGroup{(my $address=shift (@_));(my $group=shift (@_));
(my $class=shift (@_));(my $type=shift (@_));(my $key=
__translateAddressAndGroupToKey ($address,$group));return (__deleteRule ($key,
$class,$type));}sub addProfileForAddress{(my $address=shift (@_));(my $class=
shift (@_));(my $type=shift (@_));(my $mode=shift (@_));(my $value=shift (@_));(my $key
=__translateAddressToKey ($address));return (__addRule ($key,$class,$type,$mode,
$value));}sub deleteProfileForAddress{(my $address=shift (@_));(my $class=shift 
(@_));(my $type=shift (@_));(my $key=__translateAddressToKey ($address));return 
(__deleteRule ($key,$class,$type));}sub checkProfileForAddress{(my $address=
shift (@_));(my $class=shift (@_));(my $type=shift (@_));(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());(my (@profiles)=
__getAllProfilesForAddress ($address,$refHash_DB));if ((scalar (@profiles)==
(0x03cd+ 3100-0x0fe9))){return ($value_unspecified);}foreach my $key (@profiles)
{(my $refArray_profile=getProfileForKey ($key,$refHash_DB));Logger::debug3 (((((
((((
"\x43\x68\x65\x63\x6b\x50\x72\x6f\x66\x69\x6c\x65\x46\x6f\x72\x41\x64\x64\x72\x65\x73\x73\x20\x6b\x65\x79\x3d"
.$key)."\x2c\x20\x63\x6c\x61\x73\x73\x3d").$class).
"\x2c\x20\x74\x79\x70\x65\x3d").$type)."\x20\x70\x72\x6f\x66\x69\x6c\x65\x3d").
join ($",@$refArray_profile))."\x2e"));if ((not (defined (@$refArray_profile))))
{next;}if (__existsTypeInBoolClass ($type,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){return ($value_allowed);}if
 (__existsTypeInBoolClass ($type,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},
@$refArray_profile)){return ($value_denied);}}return ($value_unspecified);}sub 
__getAllProfilesForAddress{(my $address=shift (@_));(my $refHash_DB=shift (@_));
(my (@profiles)=());foreach my $key (keys (%$refHash_DB)){if (($key=~ /__address__$/ )
){if (__isProfileApplyToAddress ($address,$key)){push (@profiles,$key);}}}(
@profiles=__sortAddresses (@profiles));Logger::debug3 (((((
"\x47\x65\x74\x41\x6c\x6c\x50\x72\x6f\x66\x69\x6c\x65\x73\x46\x6f\x72\x41\x64\x64\x72\x65\x73\x73\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
.$address)."\x27\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27").join ($",@profiles)).
"\x27\x2e"));return (@profiles);}sub __getAllProfilesForAddressAndUser{(my $address
=shift (@_));(my $user=shift (@_));(my $refHash_DB=shift (@_));(my (@profiles)=
());foreach my $key (keys (%$refHash_DB)){(my $search=(
"\x5f\x5f\x61\x64\x64\x72\x65\x73\x73\x5f\x5f\x2c".$user));if (($key=~ /($search)$/ )
){(my $tmp=$key);($tmp=~ s/($search)$//g );if (__isProfileApplyToAddress (
$address,$tmp)){push (@profiles,$key);}}}(@profiles=__sortAddresses (@profiles))
;Logger::debug3 (((((((
"\x47\x65\x74\x41\x6c\x6c\x50\x72\x6f\x66\x69\x6c\x65\x73\x46\x6f\x72\x41\x64\x64\x72\x65\x73\x73\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
.$address)."\x27\x20\x61\x6e\x64\x20\x75\x73\x65\x72\x20\x27").$user).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27").join ($",@profiles))."\x27\x2e")
);return (@profiles);}sub __getAllProfilesForAddressAndGroup{(my $address=shift 
(@_));(my $group=shift (@_));(my $refHash_DB=shift (@_));(my (@profiles)=());
foreach my $key (keys (%$refHash_DB)){(my $search=((
"\x5f\x5f\x61\x64\x64\x72\x65\x73\x73\x5f\x5f\x2c".$group).
"\x5f\x5f\x67\x72\x6f\x75\x70\x5f\x5f"));if (($key=~ /$search/ )){(my $tmp=$key)
;($tmp=~ s/$search//g );if (__isProfileApplyToAddress ($address,$tmp)){push (
@profiles,$key);}}}(@profiles=__sortAddresses (@profiles));Logger::debug3 ((((((
(
"\x47\x65\x74\x41\x6c\x6c\x50\x72\x6f\x66\x69\x6c\x65\x73\x46\x6f\x72\x41\x64\x64\x72\x65\x73\x73\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
.$address)."\x27\x20\x61\x6e\x64\x20\x67\x72\x6f\x75\x70\x20\x27").$group).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27").join ($",@profiles))."\x27\x2e")
);return (@profiles);}sub __isProfileApplyToAddress{(my $client=shift (@_));(my $address
=shift (@_));($address=~ s/__address__// );(my (@pieces)=split ( /\./ ,$address,
(-(0x15b0+ 1187-0x1a52))));(my $count=scalar ($address));(my $regEx=$address);if
 (($count<(0x10c5+ 3136-0x1d01))){if (($pieces[(0x11b7+ 2365-0x1af4)]=~ /^\*/ ))
{($regEx=("\x2e\x7b\x30\x2c\x7d".$regEx));}if (($pieces[$count-
(0x138f+ 4119-0x23a5)]=~ /\*$/ )){($regEx.="\x2e\x7b\x30\x2c\x7d");}}($regEx=~ s/\*/(|[0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/g )
;if (($client=~ /^($regEx)/ )){Logger::debug3 (((((
"\x69\x73\x50\x72\x6f\x66\x69\x6c\x65\x41\x70\x70\x6c\x79\x54\x6f\x41\x64\x64\x72\x65\x73\x73\x20\x63\x6c\x69\x65\x6e\x74\x20\x27"
.$client)."\x27\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27").$address).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x31\x2e"));return (
(0x1dc0+ 583-0x2006));}Logger::debug3 (((((
"\x69\x73\x50\x72\x6f\x66\x69\x6c\x65\x41\x70\x70\x6c\x79\x54\x6f\x41\x64\x64\x72\x65\x73\x73\x20\x63\x6c\x69\x65\x6e\x74\x20\x27"
.$client)."\x27\x20\x61\x64\x64\x72\x65\x73\x73\x20").$address).
"\x20\x72\x65\x74\x75\x72\x6e\x20\x30\x2e"));return ((0x0436+ 574-0x0674));}sub 
__sortAddresses{(my (@profiles)=@_);(my (@result)=());(my (%sortHash)=());
foreach my $profile (@profiles){(my $address=$profile);($address=~ s/__address__.*// )
;($address=~ s/\*/0/g );(my (@pieces)=split ( /\./ ,$address,
(0x1bb6+ 921-0x1f4f)));(my $value=(((((($pieces[(0x1f22+ 582-0x2168)]*
(0x0e62+ 282-0x0e7c))*(0x07f1+ 2543-0x10e0))*(0x05c0+ 7350-0x2176))+(($pieces[
(0x1c0b+ 1894-0x2370)]*(0x11c4+ 1248-0x15a4))*(0x11a2+ 1653-0x1717)))+($pieces[
(0x0543+ 2768-0x1011)]*(0x1cf7+ 2668-0x2663)))+$pieces[(0x0756+ 5557-0x1d08)]));
($sortHash{$value}=$profile);}foreach my $key (sort ({$b<=>$a}keys (%sortHash)))
{push (@result,$sortHash{$key});}return (@result);}sub getProfileForKey{(my $key
=shift (@_));(my $refHash_DB=shift (@_));(my $refArray_profile=$$refHash_DB{$key
});return ($refArray_profile);}sub isGroupInProfiles{(my $groupname=shift (@_));
(my $key=__translateGroupnameToKey ($groupname));return (isKeyInProfiles ($key))
;}sub isUserInProfiles{(my $key=shift (@_));
NXProfilesDB::convertUsernameInKeyToAbsoluteUsername ((\$key));return (
isKeyInProfiles ($key));}sub isNodeGroupInProfiles{(my $nodeGroup=shift (@_));(my $nodeGroupKey
=translateNodeGroupToKey ($nodeGroup));(my $nodeGroupType=$nodeGroup);(my $class
="\x6e\x6f\x64\x65");return (isKeyOrTypeInProfiles ($nodeGroupKey,$nodeGroupType
,$class));}sub isServerGroupInProfiles{(my $group=shift (@_));(my $groupKey=
translateServerGroupToKey ($group));(my $groupType=$group);(my $class=
"\x73\x65\x72\x76\x65\x72");return (isKeyOrTypeInProfiles ($groupKey,$groupType,
$class));}sub __isTypeInProfile{(my $type=shift (@_));(my $ref_profile=shift (@_
));(my $class=shift (@_));(my $fieldContent=($$ref_profile[$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}]."\x2c"));($fieldContent.=($$ref_profile[$field{
$class}{"\x64\x65\x6e\x69\x65\x64"}]."\x2c"));($fieldContent.=$$ref_profile[
$field{$class}{"\x76\x61\x6c\x75\x65"}]);(my (@fieldContentTable)=split ( /,/ ,
$fieldContent,(0x1bd5+ 373-0x1d4a)));foreach my $item (@fieldContentTable){if ((
$type eq $item)){return ((0x06a4+ 5678-0x1cd1));}}return ((0x03f4+ 7757-0x2241))
;}sub updateServerHostPortInProfiles{(my $oldAddress=shift (@_));(my $newAddress
=shift (@_));(my $oldUUID=(""));(my $newUUID=(""));return (
updateServerInProfiles ($oldAddress,$newAddress,$oldUUID,$newUUID));}sub 
updateServerUUIDInProfiles{(my $oldUUID=shift (@_));(my $newUUID=shift (@_));(my $oldAddress
=(""));(my $newAddress=(""));return (updateServerInProfiles ($oldAddress,
$newAddress,$oldUUID,$newUUID));}sub updateServerInProfiles{(my $oldAddress=
shift (@_));(my $newAddress=shift (@_));(my $oldUUID=shift (@_));(my $newUUID=
shift (@_));($oldAddress=~ s/:/\// );($newAddress=~ s/:/\// );(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());(my (@keysToUpdate)=());foreach my $keyInProfiles
 (keys (%$refHash_DB)){(my $ref_profile=getProfileForKey ($keyInProfiles,
$refHash_DB));updateServerTypeInProfiles ($oldAddress,$newAddress,$oldUUID,
$newUUID,$ref_profile);if (((($oldAddress ne $newAddress)and ($keyInProfiles=~ /$oldAddress/ )
)or (($oldUUID ne $newUUID)and ($keyInProfiles=~ /$oldUUID/ )))){push (
@keysToUpdate,$keyInProfiles);}($$refHash_DB{$keyInProfiles}=$ref_profile);}
foreach my $keyInProfiles (@keysToUpdate){(my $oldKeyInProfiles=$keyInProfiles);
if (($oldAddress ne $newAddress)){($keyInProfiles=~ s/$oldAddress/$newAddress/ )
;}if (($oldUUID ne $newUUID)){($keyInProfiles=~ s/$oldUUID/$newUUID/ );}(
$$refHash_DB{$keyInProfiles}=$$refHash_DB{$oldKeyInProfiles});delete (
$$refHash_DB{$oldKeyInProfiles});}NXProfilesDB::save ();}sub 
updateServerTypeInProfiles{(my $oldAddress=shift (@_));(my $newAddress=shift (@_
));(my $oldUUID=shift (@_));(my $newUUID=shift (@_));(my $ref_profile=shift (@_)
);if (($oldAddress ne $newAddress)){($$ref_profile[$field{"\x6b\x65\x79"}]=~ s/$oldAddress/$newAddress/g )
;($$ref_profile[$field{"\x6e\x6f\x64\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}]=~ s/$oldAddress/$newAddress/g )
;($$ref_profile[$field{"\x6e\x6f\x64\x65"}{"\x64\x65\x6e\x69\x65\x64"}]=~ s/$oldAddress/$newAddress/g )
;($$ref_profile[$field{"\x6e\x6f\x64\x65"}{"\x76\x61\x6c\x75\x65"}]=~ s/$oldAddress/$newAddress/g )
;($$ref_profile[$field{"\x73\x65\x72\x76\x65\x72"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}]=~ s/$oldAddress/$newAddress/g );($$ref_profile[
$field{"\x73\x65\x72\x76\x65\x72"}{"\x64\x65\x6e\x69\x65\x64"}]=~ s/$oldAddress/$newAddress/g )
;($$ref_profile[$field{"\x73\x65\x72\x76\x65\x72"}{"\x76\x61\x6c\x75\x65"}]=~ s/$oldAddress/$newAddress/g )
;}if (($oldUUID ne $newUUID)){($$ref_profile[$field{"\x6b\x65\x79"}]=~ s/$oldUUID/$newUUID/g )
;($$ref_profile[$field{"\x6e\x6f\x64\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"}]=~ s/$oldUUID/$newUUID/g )
;($$ref_profile[$field{"\x6e\x6f\x64\x65"}{"\x64\x65\x6e\x69\x65\x64"}]=~ s/$oldUUID/$newUUID/g )
;($$ref_profile[$field{"\x6e\x6f\x64\x65"}{"\x76\x61\x6c\x75\x65"}]=~ s/$oldUUID/$newUUID/g )
;($$ref_profile[$field{"\x73\x65\x72\x76\x65\x72"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"}]=~ s/$oldUUID/$newUUID/g );($$ref_profile[$field
{"\x73\x65\x72\x76\x65\x72"}{"\x64\x65\x6e\x69\x65\x64"}]=~ s/$oldUUID/$newUUID/g )
;($$ref_profile[$field{"\x73\x65\x72\x76\x65\x72"}{"\x76\x61\x6c\x75\x65"}]=~ s/$oldUUID/$newUUID/g )
;}}sub isKeyOrTypeInProfiles{(my $key=shift (@_));(my $type=shift (@_));(my $class
=shift (@_));(my $refHash_DB=NXProfilesDB::getDatabaseReference ());foreach my $keyInProfiles
 (keys (%$refHash_DB)){if (($key eq $keyInProfiles)){return (
(0x06c9+ 3475-0x145b));}(my $ref_profile=getProfileForKey ($keyInProfiles,
$refHash_DB));if (__isTypeInProfile ($type,$ref_profile,$class)){return (
(0x0fdd+ 4750-0x226a));}}return ((0x085d+ 4024-0x1815));}sub isKeyInProfiles{(my $key
=shift (@_));(my (@keyTable)=getAllKeys ());foreach my $keyInProfiles (@keyTable
){if (($keyInProfiles=~ /(^$key,|^$key$|, $key$)/ )){return (
(0x1a81+ 839-0x1dc7));}}return ((0x0132+ 9608-0x26ba));}sub getAllKeys{(my $refHash_DB
=NXProfilesDB::getDatabaseReference ());(my (@allKeys)=());foreach my $profileKey
 (keys (%$refHash_DB)){push (@allKeys,$profileKey);}return (@allKeys);}sub 
translateKeyToPrintableName{(my $key=shift (@_));if (isInternalKeyForSystem (
$key)){return ("\x4e\x58\x20\x73\x79\x73\x74\x65\x6d");}if (
isInternalKeyForGuest ($key)){return ("\x47\x75\x65\x73\x74\x20\x75\x73\x65\x72"
);}(my $refHash_DB=NXProfilesDB::getDatabaseReference ());(my $profile=
$$refHash_DB{$key});(my $key=__getKeyFromProfile ($profile));($key=~ s/\//:/g );
($key=~ s/__group__/ (group)/g );($key=~ s/__nodegroup__/ (node group)/g );($key
=~ s/__servergroup__/ (server group)/g );($key=~ s/__address__/ (address)/g );
return ($key);}sub getFieldFromProfile{(my $key=shift (@_));(my $class=shift (@_
));(my $mode=shift (@_));(my $refDB=NXProfilesDB::getDatabaseReference ());(my $profile
=getProfileForKey ($key,$refDB));return (__getFieldFromProfile ($field{$class}{
$mode},@$profile));}sub __getFieldFromProfile{(my $field=shift (@_));(my (
@profile)=@_);return ($profile[$field]);}sub __setFieldForProfile{(my $content=
shift (@_));(my $field=shift (@_));(my $profile_ref=shift (@_));Logger::debug3 (
((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x3a\x5f\x5f\x73\x65\x74\x46\x69\x65\x6c\x64\x46\x6f\x72\x50\x72\x6f\x66\x69\x6c\x65\x3a\x20\x63\x6f\x6e\x74\x65\x6e\x74\x3d"
.$content)."\x20\x66\x69\x65\x6c\x64\x3d").$field).
"\x20\x70\x72\x6f\x66\x69\x6c\x65\x3d").join ($",@$profile_ref))."\x2e"));(
$$profile_ref[$field]=$content);}sub __getKeyFromProfile{(my $profile_ref=shift 
(@_));return ($$profile_ref[$field{"\x6b\x65\x79"}]);}sub 
__translateGroupnameToKey{(my $groupname=shift (@_));return (($groupname.
"\x5f\x5f\x67\x72\x6f\x75\x70\x5f\x5f"));}sub translateNodeGroupToKey{(my $nodeGroup
=shift (@_));return (($nodeGroup.
"\x5f\x5f\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x5f\x5f"));}sub 
translateServerGroupToKey{(my $serverGroup=shift (@_));return (($serverGroup.
"\x5f\x5f\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x5f\x5f"));}sub 
__translateNodenameToKey{(my $nodename=shift (@_));($nodename=~ s/:/\// );return
 ($nodename);}sub __translateNodenameAndUsernameToKey{(my $nodename=shift (@_));
(my $username=shift (@_));($nodename=__translateNodenameToKey ($nodename));
return ((($nodename."\x2c").$username));}sub 
__translateNodenameAndGroupnameToKey{(my $nodename=shift (@_));(my $groupname=
shift (@_));($nodename=__translateNodenameToKey ($nodename));($groupname=
__translateGroupnameToKey ($groupname));return ((($nodename."\x2c").$groupname))
;}sub __translateAddressToKey{(my $address=shift (@_));return (($address.
"\x5f\x5f\x61\x64\x64\x72\x65\x73\x73\x5f\x5f"));}sub 
__translateAddressAndUsernameToKey{(my $address=shift (@_));(my $user=shift (@_)
);($address=__translateAddressToKey ($address));return ((($address."\x2c").$user
));}sub __translateAddressAndGroupToKey{(my $address=shift (@_));(my $group=
shift (@_));($address=__translateAddressToKey ($address));($group=
__translateGroupnameToKey ($group));return ((($address."\x2c").$group));}sub 
__translateNodeGroupAndUserToKey{(my $nodeGroup=shift (@_));(my $user=shift (@_)
);($nodeGroup=translateNodeGroupToKey ($nodeGroup));return ((($nodeGroup."\x2c")
.$user));}sub getInternalSystemKey{return (
"\x5f\x5f\x73\x79\x73\x74\x65\x6d\x5f\x5f");}sub getInternalGuestKey{return (
"\x5f\x5f\x67\x75\x65\x73\x74\x5f\x5f");}sub isInternalKeyForSystem{(my $key=
shift (@_));if (($key eq getInternalSystemKey ())){return ((0x0238+ 2749-0x0cf4)
);}return ((0x060c+ 2513-0x0fdd));}sub isInternalKeyForGuest{(my $key=shift (@_)
);if (($key eq getInternalGuestKey ())){return ((0x2365+ 894-0x26e2));}return (
(0x0780+ 350-0x08de));}sub isInternalKey{(my $key=shift (@_));if ((
isInternalKeyForSystem ($key)or isInternalKeyForGuest ($key))){return (
(0x1afb+ 742-0x1de0));}return ((0x052f+ 6677-0x1f44));}sub 
isUsernameStandardUser{(my $user=shift (@_));if (((not (defined ($user)))or (
$user eq ("")))){return ((0x0de8+ 5391-0x22f7));}if (isInternalKeyForSystem (
$user)){return ((0x140b+ 3806-0x22e9));}if (NXGuestsManager::isGuestByUsername (
$user)){return ((0x1c57+ 522-0x1e61));}return ((0x01aa+ 312-0x02e1));}sub 
isUsernameNXSpecialUser{(my $user=shift (@_));return ((!isUsernameStandardUser (
$user)));}sub __isEmptyProfileArray{(my $refArray_profile=shift (@_));(my $numberOfElements
=(0x0d85+ 776-0x108d));foreach my $arrayElement (@$refArray_profile){if ((
$arrayElement ne (""))){($numberOfElements=($numberOfElements+
(0x1c1a+ 1508-0x21fd)));}}if (($numberOfElements==(0x0644+ 4195-0x16a6))){return
 ((0x0abc+ 5654-0x20d1));}return ((0x131d+ 3002-0x1ed7));}sub getModeValue{
return ($mode_value);}sub setPropagatedRules{(my $user=shift (@_));(my $rules=
shift (@_));if (($rules eq (""))){($overwriteRules=(0x18eb+ 1540-0x1eef));(
$propagatedTrusted=(0x0dd1+ 1497-0x13aa));return ((0x09c1+ 3670-0x1817));}
__preparePropagatedHash ($rules);($propagatedRules{"\x75\x73\x65\x72"}=$user);
overwritePropagatedRules ();}sub __preparePropagatedHash{(my $rules=shift (@_));
(my (%tmpRuleHash)=NXShell::urlParameter2Hash ($rules));foreach my $type (keys (
%tmpRuleHash)){if (($type eq "\x74\x72\x75\x73\x74\x65\x64")){if ((defined (
$tmpRuleHash{$type})and ($tmpRuleHash{$type}ne ("")))){
__setTrustedForThisConnection ($tmpRuleHash{$type});($propagatedTrusted=
(0x0b32+ 364-0x0c9d));}}(my $class=NXProfilesManager::getClassForType ($type));
if (($class ne (""))){(my $mode=NXProfilesManager::getModeForValue ($class,$type
,$tmpRuleHash{$type}));my ($value);if (($mode eq "\x62\x6f\x6f\x6c")){if ((
$tmpRuleHash{$type}eq "\x6e\x6f")){($value=$value_denied);}elsif (($tmpRuleHash{
$type}eq "\x79\x65\x73")){($value=$value_allowed);}else{($value=$tmpRuleHash{
$type});}}elsif (($mode eq "\x76\x61\x6c\x75\x65")){($value=$tmpRuleHash{$type})
;}else{Logger::warning (((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x6d\x6f\x64\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x20\x66\x6f\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x20"
.$type).
"\x20\x64\x75\x72\x69\x6e\x67\x20\x72\x75\x6c\x65\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x65\x2e"
));next;}if ((($class eq "\x73\x65\x73\x73\x69\x6f\x6e")and (not ((
$GLOBAL::ALL_POSSIBLE_SESSIONS_VALUE_LIST=~ /$type/ ))))){($type=
Common::NXSessionType::convertToInternal ($type));}Logger::debug3 (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x6f\x76\x65\x72\x77\x72\x74\x69\x6e\x67\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x65\x64\x20\x72\x75\x6c\x65\x20\x63\x6c\x61\x73\x73\x20\x27"
.$class)."\x27\x2c\x20\x74\x79\x70\x65\x20\x27").$type).
"\x27\x2c\x20\x76\x61\x6c\x75\x65\x20\x27").$value)."\x27\x2e"));(my (%rule)=(
"\x63\x6c\x61\x73\x73",$class,"\x76\x61\x6c\x75\x65",$value,"\x6d\x6f\x64\x65",
$mode));($propagatedRules{$type}=(\%rule));($overwriteRules=
(0x0d3d+ 1614-0x138a));}}}sub overwritePropagatedRules{foreach my $type (keys (
%propagatedRules)){if (($type eq "\x75\x73\x65\x72")){next;}addPropagateProfile 
($type,$propagatedRules{"\x75\x73\x65\x72"},$propagatedRules{$type}{
"\x63\x6c\x61\x73\x73"},$propagatedRules{$type}{"\x6d\x6f\x64\x65"},
$propagatedRules{$type}{"\x76\x61\x6c\x75\x65"});}}sub addPropagateProfile{(my $type
=shift (@_));(my $username=shift (@_));(my $class=shift (@_));(my $mode=shift (
@_));(my $value=shift (@_));return (__addRule ($username,$class,$type,$mode,
$value,(0x1458+ 4310-0x252d)));}sub isPropagatedRuleToOverwrite{return (
$overwriteRules);}sub isTrustedPropagated{return ($propagatedTrusted);}sub 
saveCalculatedResources{(my (@resources)=@_);foreach my $resource (@resources){
chomp ($resource);(my (@tmp)=split ( /\s+/ ,$resource,(0x0997+ 514-0x0b99)));(
$calcResources{$tmp[(0x0ca8+ 3789-0x1b74)]}=$tmp[(0x0394+ 1844-0x0ac6)]);}(
$resourcesReady=(0x0dd5+ 4268-0x1e80));}sub prepareRulePropagation{(my $username
=shift (@_));(my $server=shift (@_));Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x50\x72\x65\x70\x61\x72\x65\x20\x72\x75\x6c\x65\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x2e"
);if (($resourcesReady!=(0x0249+ 676-0x04ec))){Logger::debug (
"\x50\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x3a\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x72\x65\x61\x64\x79\x2c\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69\x6e\x67\x20\x6e\x6f\x77\x2e"
);main::nxrequire ("\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");
NXResources::calculateResourcesBeforeResourcelist ($username,$server);}(my (
%propagation)=NXProfilesManager::getPropagationList ($username,$server));if ((
scalar (keys (%propagation))==(0x1474+ 801-0x1795))){Logger::debug3 (
"\x4e\x6f\x20\x72\x75\x6c\x65\x73\x20\x74\x6f\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x2e"
);return ((0x119d+ 3718-0x2023));}(my $propagateAll=(0x089b+ 7023-0x240a));(my (
%rulesToPropagate)=());foreach my $key (keys (%propagation)){if (($key eq 
"\x61\x6c\x6c")){($propagateAll=(0x14df+ 2954-0x2068));last;}}if (($propagateAll
==(0x08b9+ 2359-0x11ef))){((%rulesToPropagate)=%calcResources);}foreach my $setRule
 (keys (%propagation)){if (($setRule eq "\x61\x6c\x6c")){next;}if (((
$propagation{$setRule}eq "\x64\x65\x66\x61\x75\x6c\x74")and ($propagateAll==
(0x0844+ 7557-0x25c9)))){(my $value=$calcResources{$setRule});if (($value eq 
"\x6e\x6f")){($value=$value_denied);}($rulesToPropagate{$setRule}=$value);next;}
($rulesToPropagate{$setRule}=$propagation{$setRule});}return (
NXShell::hashParameters2Url (%rulesToPropagate));}sub getDefaultProfiles{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x61\x6c\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x64\x65\x66\x61\x75\x6c\x74\x0a"
);(my (%defaultHash)=split ( / / ,NXRedis::get (),(0x19b1+ 3205-0x2636)));return
 (%defaultHash);}sub __addGroupToProfileCheck{(my $group=shift (@_));($group=
main::urlencode ($group));NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x67\x72\x6f\x75\x70\x73\x54\x6f\x43\x68\x65\x63\x6b\x2c\x66\x69\x65\x6c\x64\x3d"
.$group)."\x0a"));}sub __addServerToProfileCheck{(my $server=shift (@_));
NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x73\x65\x72\x76\x65\x72\x73\x54\x6f\x43\x68\x65\x63\x6b\x2c\x66\x69\x65\x6c\x64\x3d"
.$server)."\x0a"));}sub enablePooledServerGroupInProfiles{(my $uuid=shift (@_));
__addServerToProfileCheck ($uuid);}sub findNodeInProfilesAndRemove{(my $uuid=
shift (@_));if (NXLicense::isNotProfilesFeature ()){return (
(0x0125+ 3145-0x0d6e));}(my (@serverRules)=());(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());
NXProfilesManager::isKeyExistsStandaloneOrMixedWithOtherValues ($uuid,(
\@serverRules));foreach my $key (@serverRules){delete ($$refHash_DB{$key});}(my $class
="\x73\x65\x72\x76\x65\x72");foreach my $keyInProfiles (keys (%$refHash_DB)){(my $refArray_profile
=getProfileForKey ($keyInProfiles,$refHash_DB));(my $value=
__getTypeFromValueClass ($uuid,$field{$class}{"\x76\x61\x6c\x75\x65"},
@$refArray_profile));if (defined ($value)){__removeTypeFromFieldOfProfile (((
$uuid."\x3d").$value),$field{$class}{"\x76\x61\x6c\x75\x65"},$refArray_profile);
}if (__existsTypeInBoolClass ($uuid,$field{$class}{"\x64\x65\x6e\x69\x65\x64"},
@$refArray_profile)){__removeTypeFromFieldOfProfile ($uuid,$field{$class}{
"\x64\x65\x6e\x69\x65\x64"},$refArray_profile);}if (__existsTypeInBoolClass (
$uuid,$field{$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){
__removeTypeFromFieldOfProfile ($uuid,$field{$class}{
"\x61\x6c\x6c\x6f\x77\x65\x64"},$refArray_profile);}if (__existsTypeInBoolClass 
($uuid,$field{"\x6e\x6f\x64\x65"}{"\x64\x65\x6e\x69\x65\x64"},@$refArray_profile
)){__removeTypeFromFieldOfProfile ($uuid,$field{"\x6e\x6f\x64\x65"}{
"\x64\x65\x6e\x69\x65\x64"},$refArray_profile);}if (__existsTypeInBoolClass (
$uuid,$field{"\x6e\x6f\x64\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"},
@$refArray_profile)){__removeTypeFromFieldOfProfile ($uuid,$field{
"\x6e\x6f\x64\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"},$refArray_profile);}if ((
NXProfilesManager::__checkValueOnAll (
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
"\x73\x65\x72\x76\x65\x72",$keyInProfiles)eq $uuid)){(my $value=
__getTypeFromValueClass (
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
$field{$class}{"\x76\x61\x6c\x75\x65"},@$refArray_profile));if (defined ($value)
){__removeTypeFromFieldOfProfile ((
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x3d".
$value),$field{$class}{"\x76\x61\x6c\x75\x65"},$refArray_profile);}if (
__existsTypeInBoolClass (
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
$field{$class}{"\x64\x65\x6e\x69\x65\x64"},@$refArray_profile)){
__removeTypeFromFieldOfProfile (
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
$field{$class}{"\x64\x65\x6e\x69\x65\x64"},$refArray_profile);}if (
__existsTypeInBoolClass (
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
$field{$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"},@$refArray_profile)){
__removeTypeFromFieldOfProfile (
"\x66\x6f\x72\x77\x61\x72\x64\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e",
$field{$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"},$refArray_profile);}}}
NXProfilesDB::save ();}sub findHostPortInProfilesAndReplaceWithUUID{(my $uuid=
shift (@_));(my $host=shift (@_));(my $port=shift (@_));Logger::debug (((((((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x43\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20"
.$host)."\x2f").$port)."\x20\x74\x6f\x20").$uuid)."\x2e"));(my (@serverRules)=()
);NXProfilesManager::isKeyExistsStandaloneOrMixedWithOtherValues ($host,(
\@serverRules));NXProfilesManager::isKeyExistsStandaloneOrMixedWithOtherValues (
(($host."\x2f").$port),(\@serverRules));(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());foreach my $oldkey (@serverRules){(
$$refHash_DB{$uuid}=$$refHash_DB{$oldkey});($$refHash_DB{$uuid}[$field{
"\x6b\x65\x79"}]=$uuid);delete ($$refHash_DB{$oldkey});}(my $fullname=(($host.
"\x2f").$port));foreach my $keyInProfiles (keys (%$refHash_DB)){Logger::debug3 (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x67\x65\x74\x50\x72\x6f\x66\x69\x6c\x65\x46\x6f\x72\x4b\x65\x79\x20\x27\x6b\x65\x79\x49\x6e\x50\x72\x6f\x66\x69\x6c\x65\x73\x27\x2e"
);(my $refArray_profile=getProfileForKey ($keyInProfiles,$refHash_DB));(my $field
=$field{"\x73\x65\x72\x76\x65\x72"}{"\x76\x61\x6c\x75\x65"});(my $fieldContent=
__getFieldFromProfile ($field,@$refArray_profile));if ((($fieldContent=~ /$host/ )
or ($fieldContent=~ /$fullname/ ))){($fieldContent=~ s/$fullname/$uuid/g );(
$fieldContent=~ s/$host/$uuid/g );__setFieldForProfile ($fieldContent,$field,
$refArray_profile);}($field=$field{"\x6e\x6f\x64\x65"}{"\x76\x61\x6c\x75\x65"});
($fieldContent=__getFieldFromProfile ($field,@$refArray_profile));if (((
$fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ ))){($fieldContent=~ s/$fullname/$uuid/g )
;($fieldContent=~ s/$host/$uuid/g );__setFieldForProfile ($fieldContent,$field,
$refArray_profile);}($field=$field{"\x73\x65\x72\x76\x65\x72"}{
"\x64\x65\x6e\x69\x65\x64"});($fieldContent=__getFieldFromProfile ($field,
@$refArray_profile));if ((($fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ )
)){($fieldContent=~ s/$fullname/$uuid/g );($fieldContent=~ s/$host/$uuid/g );
__setFieldForProfile ($fieldContent,$field,$refArray_profile);}($field=$field{
"\x6e\x6f\x64\x65"}{"\x64\x65\x6e\x69\x65\x64"});($fieldContent=
__getFieldFromProfile ($field,@$refArray_profile));Logger::debug3 (((
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x7b\x27\x6e\x6f\x64\x65\x27\x7d\x7b\x27\x64\x65\x6e\x69\x65\x64\x27\x7d\x20\x66\x69\x65\x6c\x64\x43\x6f\x6e\x74\x65\x6e\x74\x20\x27"
.$fieldContent)."\x27\x2e"));if ((($fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ )
)){($fieldContent=~ s/$fullname/$uuid/g );($fieldContent=~ s/$host/$uuid/g );
__setFieldForProfile ($fieldContent,$field,$refArray_profile);}($field=$field{
"\x73\x65\x72\x76\x65\x72"}{"\x61\x6c\x6c\x6f\x77\x65\x64"});($fieldContent=
__getFieldFromProfile ($field,@$refArray_profile));if ((($fieldContent=~ /$host/ )
or ($fieldContent=~ /$fullname/ ))){($fieldContent=~ s/$fullname/$uuid/g );(
$fieldContent=~ s/$host/$uuid/g );__setFieldForProfile ($fieldContent,$field,
$refArray_profile);}($field=$field{"\x6e\x6f\x64\x65"}{
"\x61\x6c\x6c\x6f\x77\x65\x64"});($fieldContent=__getFieldFromProfile ($field,
@$refArray_profile));if ((($fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ )
)){($fieldContent=~ s/$fullname/$uuid/g );($fieldContent=~ s/$host/$uuid/g );
__setFieldForProfile ($fieldContent,$field,$refArray_profile);}}
NXProfilesDB::save ();}sub findNodeGroupInProfilesAndReplaceWithUUID{(my $uuid=
shift (@_));(my $name=shift (@_));if (NXLicense::isNotProfilesFeature ()){return
 ((0x131a+ 3294-0x1ff8));}(my (@serverRules)=());(my $refHash_DB=
NXProfilesDB::getDatabaseReference ());
NXProfilesManager::isKeyExistsStandaloneOrMixedWithOtherValues ($name,(
\@serverRules));foreach my $oldkey (@serverRules){($$refHash_DB{$uuid.
"\x5f\x5f\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x5f\x5f"}=$$refHash_DB{
$oldkey});($$$refHash_DB{$uuid.
"\x5f\x5f\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x5f\x5f"}[$field{
"\x6b\x65\x79"}]=$uuid);delete ($$refHash_DB{$oldkey});}(my $class=
"\x73\x65\x72\x76\x65\x72");foreach my $keyInProfiles (keys (%$refHash_DB)){(my $refArray_profile
=getProfileForKey ($keyInProfiles,$refHash_DB));(my $field=$field{$class}{
"\x76\x61\x6c\x75\x65"});(my $fieldContent=__getFieldFromProfile ($field,
@$refArray_profile));if ((($fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ )
)){($fieldContent=~ s/$name/$uuid/g );__setFieldForProfile ($fieldContent,$field
,$refArray_profile);}($field=$field{$class}{"\x64\x65\x6e\x69\x65\x64"});(
$fieldContent=__getFieldFromProfile ($field,@$refArray_profile));if (((
$fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ ))){($fieldContent=~ s/$name/$uuid/g )
;__setFieldForProfile ($fieldContent,$field,$refArray_profile);}($field=$field{
$class}{"\x61\x6c\x6c\x6f\x77\x65\x64"});($fieldContent=__getFieldFromProfile (
$field,@$refArray_profile));if ((($fieldContent=~ /$host/ )or ($fieldContent=~ /$fullname/ )
)){($fieldContent=~ s/$name/$uuid/g );__setFieldForProfile ($fieldContent,$field
,$refArray_profile);}}NXProfilesDB::save ();}sub 
updateProfilesFromHostPortToUUID{Logger::debug (
"\x4e\x58\x52\x65\x64\x69\x73\x54\x72\x61\x6e\x73\x69\x74\x69\x6f\x6e\x3a\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x20\x66\x72\x6f\x6d\x20\x68\x6f\x73\x74\x2f\x70\x6f\x72\x74\x20\x74\x6f\x20\x55\x55\x49\x44\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73");(my (
%nodeGroupsDB)=NXServerGroups::getGroupsDB (
"\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73"));foreach my $groupname (keys
 (%nodeGroupsDB)){(my $group=$NXServerGroups::groupsDB{$groupname});
findNodeGroupInProfilesAndReplaceWithUUID ($$group{"\x75\x75\x69\x64"},
$groupname);}main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");(my (
@servers)=NXServers::getAllServers ());foreach my $serverRef (@servers){
findHostPortInProfilesAndReplaceWithUUID ($$serverRef{"\x75\x75\x69\x64"},
$$serverRef{"\x68\x6f\x73\x74"},$$serverRef{"\x70\x6f\x72\x74"});}}sub 
__setTrustedForThisConnection{(my $value=shift (@_));main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");if (($value eq 
"\x70\x68\x79\x73\x69\x63\x61\x6c")){
NXUsersManager::setUserTrustedPhysicalByPropagation ();
NXUsersManager::setUserNotTrustedVirtualByPropagation ();}elsif (($value eq 
"\x76\x69\x72\x74\x75\x61\x6c")){
NXUsersManager::setUserNotTrustedPhysicalByPropagation ();
NXUsersManager::setUserTrustedVirtualByPropagation ();}elsif (($value eq 
"\x61\x6c\x6c")){NXUsersManager::setUserTrustedPhysicalByPropagation ();
NXUsersManager::setUserTrustedVirtualByPropagation ();}elsif (($value eq 
"\x6e\x6f\x6e\x65")){NXUsersManager::setUserNotTrustedPhysicalByPropagation ();
NXUsersManager::setUserNotTrustedVirtualByPropagation ();}}sub 
setManualSelectionState{(my $refHash_DB=NXProfilesDB::getDatabaseReference ());
foreach my $profileKey (keys (%$refHash_DB)){(my $refArray_profile=
getProfileForKey ($profileKey,$refHash_DB));if (__existsTypeInBoolClass (
"\x6d\x61\x6e\x75\x61\x6c\x2d\x6e\x6f\x64\x65\x2d\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e"
,$field{"\x66\x65\x61\x74\x75\x72\x65"}{"\x61\x6c\x6c\x6f\x77\x65\x64"},
@$refArray_profile)){NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x6d\x61\x6e\x75\x61\x6c\x53\x65\x6c\x65\x63\x74\x69\x6f\x6e\x2c\x76\x61\x6c\x75\x65\x3d\x31\x0a"
);return ((0x03ef+ 3317-0x10e3));}}NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x6d\x61\x6e\x75\x61\x6c\x53\x65\x6c\x65\x63\x74\x69\x6f\x6e\x2c\x76\x61\x6c\x75\x65\x3d\x30\x0a"
);return ((0x049f+ 7218-0x20d1));}"\x3f\x3f\x3f";
