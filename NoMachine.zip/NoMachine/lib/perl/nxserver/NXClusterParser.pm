############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXClusterParser::callback{package NXClusterParser;no warnings;(my $self=
shift (@_));(my $ref_hash=shift (@_));(my $buffer=shift (@_));(my $ref_params=
$$ref_hash{"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});(my $ref_machine=
$$ref_params{"\x6d\x61\x63\x68\x69\x6e\x65"});while (($buffer ne (""))){(my $line
=__getLineToParse ((\$buffer)));__parseMessage ($ref_machine,$line);$ref_machine
->process;if ($ref_machine->isFinalState){Logger::debug (((
"\x46\x69\x6e\x61\x6c\x20\x73\x74\x61\x74\x65\x3a\x20\x69\x67\x6e\x6f\x72\x65\x20\x72\x65\x73\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x62\x75\x66\x66\x65\x72\x20\x27"
.$buffer)."\x27\x2e"));last;}}$self->removeHandle ($$ref_hash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($ref_hash,(0x006a+ 6000-0x17da),
(0x0f8f+ 385-0x1110));}sub NXClusterParser::callbackClose{package 
NXClusterParser;no warnings;(my $self=shift (@_));(my $ref_hash=shift (@_));(my $ref_params
=$$ref_hash{"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});(my $ref_machine=
$$ref_params{"\x6d\x61\x63\x68\x69\x6e\x65"});Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x74\x68\x65\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);main::nxclose ($$ref_hash{"\x48\x61\x6e\x64\x6c\x65"});$ref_machine->sendEvent
 ("\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x43\x6c\x6f\x73\x65\x64");$self->
removeHandle ($$ref_hash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($ref_hash,
(0x04b4+ 425-0x065d),(0x02c7+ 7151-0x1eb6));($$ref_machine{
"\x69\x6e\x73\x69\x64\x65\x50\x69\x70\x65\x46\x44"}=(-(0x0121+ 3594-0x0f2a)));}
sub NXClusterParser::__getLineToParse{package NXClusterParser;no warnings;(my $ref_buffer
=shift (@_));(my $line=$$ref_buffer);if (($$ref_buffer=~ /^(.*?)\n(.*)$/s )){(
$line=$1);($$ref_buffer=$2);}else{($$ref_buffer=(""));}Logger::debug (((
"\x4c\x69\x6e\x65\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x27".$line)."\x27\x2e"
));return ($$ref_buffer,$line);}sub NXClusterParser::__parseMessage{package 
NXClusterParser;no warnings;(my $ref_machine=shift (@_));(my $line=shift (@_));
__registerMessages ();if (($line=~ /NX> (\d+).*/ )){(my $messageNum=$1);if ((
$__handleMessage{$messageNum}ne (""))){(my $function=$__handleMessage{
$messageNum});&$function ($ref_machine,$line);}else{Logger::error (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x20\x27".$messageNum).
"\x27\x20\x66\x72\x6f\x6d\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x73\x65\x72\x76\x65\x72\x20\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d\x65\x6e\x74\x65\x64\x2e"
));}}elsif (($line=~ /^HELLO/ )){__handleHello ($ref_machine,$line);}elsif ((
$line=~ /^Set noecho: $/ )){();}elsif (($line eq (""))){();}else{Logger::error (
((
"\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x73\x65\x72\x76\x65\x72\x20\x27"
.$line)."\x27\x2e"));}}sub NXClusterParser::__registerMessages{package 
NXClusterParser;no warnings;($__handleMessage{$GLOBAL::MSG_GET_COMMAND}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x47\x65\x74\x43\x6f\x6d\x6d\x61\x6e\x64");(
$__handleMessage{$GLOBAL::MSG_PROPERTIES}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x50\x72\x6f\x70\x65\x72\x74\x79");(
$__handleMessage{$GLOBAL::MSG_CLUSTER_NODE_PARAMS}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x43\x6c\x75\x73\x74\x65\x72\x4e\x6f\x64\x65\x50\x61\x72\x61\x6d\x73"
);($__handleMessage{$GLOBAL::MSG_CLUSTER_NODE_PARAMS_PASSWORD_REQUESTED}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x43\x6c\x75\x73\x74\x65\x72\x53\x75\x64\x6f\x50\x61\x73\x73\x77\x6f\x72\x64\x52\x65\x71\x75\x65\x73\x74\x65\x64"
);($__handleMessage{$GLOBAL::MSG_LOGIN_OK}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x4c\x6f\x67\x69\x6e\x4f\x4b");(
$__handleMessage{$GLOBAL::MSG_REQUESTED_PROTO_VERSION_ACCEPTED}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x50\x72\x6f\x74\x6f\x41\x63\x63\x65\x70\x74\x65\x64"
);($__handleMessage{$GLOBAL::MSG_GET_PARAMETER}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x47\x65\x74\x50\x61\x72\x61\x6d\x65\x74\x65\x72"
);($__handleMessage{$GLOBAL::MSG_SUDO_VERIFICATION}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x53\x75\x64\x6f\x56\x65\x72\x69\x66\x69\x63\x61\x74\x69\x6f\x6e"
);($__handleMessage{$GLOBAL::MSG_ERROR}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x45\x72\x72\x6f\x72");($__handleMessage{
$GLOBAL::MSG_ERROR_GENERAL}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x45\x72\x72\x6f\x72");($__handleMessage{
$GLOBAL::MSG_PACKED_RESPONSE}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x45\x72\x72\x6f\x72");($__handleMessage{
$GLOBAL::MSG_LOGIN_PUBLICKEY_NOT_RECOGNIZED}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x45\x72\x72\x6f\x72\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x52\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64"
);}sub NXClusterParser::__handleHello{package NXClusterParser;no warnings;(my $ref_stateMachine
=shift (@_));(my $helloData=lc (shift (@_)));main::nxrequire (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72");if (($helloData=~ /(nx\w+) - version (\d+)\.(\d+)\.(\d+) - (.*)/ )
){NXRemoteServer::handleTypeAndVersion ($1,$2,$3,$4,$5);(my $version=
NXRemoteServer::getVersion ());unless (($version>=(0x0418+ 4944-0x1762))){
$ref_stateMachine->printError (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x57\x72\x6f\x6e\x67\x52\x65\x6d\x6f\x76\x65\x56\x65\x72\x73\x69\x6f\x6e"
,"\x36");return ($ref_stateMachine->sendEvent ("\x65\x72\x72\x6f\x72"));}(my $license
=NXRemoteServer::getLicense ());($license=~ s/\b(\w)/\U$1\E/g );($license=~ s/NoMachine/NoMachine/i )
;unless ((NXLicense::isRemoteServerAvailableAsCluster ($license)or 
NXLicense::wasRemoteServerAvailableAsClusterAsV7 ($license))){$ref_stateMachine
->printError (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x57\x72\x6f\x6e\x67\x52\x65\x6d\x6f\x74\x65\x4c\x69\x63\x65\x6e\x73\x65"
,$license);return ($ref_stateMachine->sendEvent ("\x65\x72\x72\x6f\x72"));}if ((
NXLicense::amICloudServer ()and (not (NXLicense::isLicenseCloudServer ($license)
)))){$ref_stateMachine->printError (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x57\x72\x6f\x6e\x67\x52\x65\x6d\x6f\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x54\x79\x70\x65"
,$license,$GLOBAL::PRODUCT_NAME);return ($ref_stateMachine->sendEvent (
"\x65\x72\x72\x6f\x72"));}if ((NXLicense::amIEnterpriseTerminalServer ()and (not
 (NXLicense::isLicenseEnterpriseTerminalServer ($license))))){$ref_stateMachine
->printError (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x57\x72\x6f\x6e\x67\x52\x65\x6d\x6f\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x54\x79\x70\x65"
,$license,$GLOBAL::PRODUCT_NAME);return ($ref_stateMachine->sendEvent (
"\x65\x72\x72\x6f\x72"));}}}sub NXClusterParser::__handleGetCommand{package 
NXClusterParser;no warnings;(my $ref_stateMachine=shift (@_));$ref_stateMachine
->sendEvent ("\x6e\x78\x70\x72\x6f\x6d\x70\x74");}sub 
NXClusterParser::__handleProperty{package NXClusterParser;no warnings;(my $ref_stateMachine
=shift (@_));$ref_stateMachine->sendEvent (
"\x6e\x78\x70\x72\x6f\x70\x65\x72\x74\x79");}sub 
NXClusterParser::__handleClusterNodeParams{package NXClusterParser;no warnings;(my $ref_stateMachine
=shift (@_));(my $line=shift (@_));Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x50\x61\x72\x73\x65\x72\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x70\x61\x72\x61\x6d\x73\x2e"
);if (($line=~ /NX> $GLOBAL::MSG_CLUSTER_NODE_PARAMS error=(.*) / )){(my $error=
main::urldecode ($1));$ref_stateMachine->printError (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x65\x6d\x6f\x74\x65\x45\x72\x72\x6f\x72"
,$error);return ($ref_stateMachine->sendEvent ("\x65\x72\x72\x6f\x72"));}elsif (
($line=~ /NX> $GLOBAL::MSG_CLUSTER_NODE_PARAMS params=(.*) / )){(my (
%hashParameters)=NXShell::urlParameter2Hash ($1));$ref_stateMachine->
setNxHostCert ($hashParameters{
"\x63\x6c\x75\x73\x74\x65\x72\x48\x6f\x73\x74\x4b\x65\x79"});$ref_stateMachine->
setClusterPublicKey ($hashParameters{
"\x63\x6c\x75\x73\x74\x65\x72\x50\x75\x62\x6c\x69\x63\x4b\x65\x79"});return (
$ref_stateMachine->sendEvent ("\x70\x61\x72\x61\x6d\x73\x52\x65\x73\x75\x6c\x74"
));}return ($ref_stateMachine->sendEvent (
"\x63\x6c\x75\x73\x74\x65\x72\x50\x61\x72\x61\x6d\x73"));}sub 
NXClusterParser::__handleClusterSudoPasswordRequested{package NXClusterParser;no
 warnings;(my $ref_stateMachine=shift (@_));return ($ref_stateMachine->sendEvent
 ("\x73\x75\x64\x6f\x52\x65\x71\x75\x65\x73\x74"));}sub 
NXClusterParser::__handleSudoVerification{package NXClusterParser;no warnings;(my $refParameters
=shift (@_));(my $line=shift (@_));return ((0x0bad+ 3145-0x17f6));if (($line=~ /Sudo password does not match/ )
){setNextState (
"\x72\x65\x63\x65\x69\x76\x65\x64\x53\x75\x64\x6f\x50\x61\x73\x73\x77\x6f\x72\x64\x44\x6f\x65\x73\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);return;}elsif (($line=~ /Key added correctly/ )){setNextState (
"\x72\x65\x63\x65\x69\x76\x65\x64\x4b\x65\x79\x41\x64\x64\x65\x64\x43\x6f\x72\x72\x65\x63\x74\x6c\x79"
);return;}elsif (($line=~ /User is not in sudoers file/ )){setNextState (
"\x72\x65\x63\x65\x69\x76\x65\x64\x55\x73\x65\x72\x49\x73\x4e\x6f\x74\x49\x6e\x53\x75\x64\x6f\x65\x72\x73"
);return;}elsif (($line=~ /No response/ )){setNextState (
"\x72\x65\x63\x65\x69\x76\x65\x64\x4e\x6f\x52\x65\x73\x70\x6f\x6e\x73\x65");
return;}setNextState (
"\x72\x65\x63\x65\x69\x76\x65\x64\x53\x75\x64\x6f\x56\x65\x72\x69\x66\x69\x63\x61\x74\x69\x6f\x6e"
);}sub NXClusterParser::__handleProtoAccepted{package NXClusterParser;no 
warnings;Logger::debug (
"\x50\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x61\x63\x63\x65\x70\x74\x65\x64\x2e");}sub
 NXClusterParser::__handleGetParameter{package NXClusterParser;no warnings;(my $ref_stateMachine
=shift (@_));(my $data=shift (@_));Logger::debug (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x67\x65\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x27"
.$data)."\x27\x2e"));}sub NXClusterParser::__handleLoginOK{package 
NXClusterParser;no warnings;Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x68\x65\x6c\x6c\x6f\x20\x6f\x6e\x20\x62\x6f\x61\x72\x64\x2e"
);}sub NXClusterParser::__handleError{package NXClusterParser;no warnings;(my $ref_stateMachine
=shift (@_));(my $line=shift (@_));(my $message=(""));(my $indexString=(""));(my (
@parameters)=());my ($error);if (Common::NXMsg::isPackedMessage ($line)){((
$indexString,$message,@parameters)=Common::NXMsg::unpackResponse ($line));if (
NXMsg::check_msg ($indexString,
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x50\x61\x72\x73\x65\x72")){($error=
NXMsg::get_text ($indexString,
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x50\x61\x72\x73\x65\x72",@parameters));}
else{($error=$message);NXMsg::removeMessageHeader ((\$error));}}if ((($line=~ /NX> $GLOBAL::MSG_ERROR ERROR: (.+)/ )
or ($line=~ /NX> $GLOBAL::MSG_ERROR_GENERAL ERROR: (.+)/ ))){($error=$1);($error
=~ s/\.\s*$// );}if (($error=~ /Cannot accept public key/ )){($indexString=
"\x65\x47\x55\x49\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
);}if (Common::NXEnglishMessages::isCannotAcceptPublicKeyError ($indexString)){
$ref_stateMachine->setError ($indexString);}elsif (($indexString ne (""))){
$ref_stateMachine->printError ($indexString,@parameters);}return (
$ref_stateMachine->sendEvent ("\x65\x72\x72\x6f\x72"));}sub 
NXClusterParser::__handleErrorPublicKeyNotRecognized{package NXClusterParser;no 
warnings;(my $ref_stateMachine=shift (@_));(my $line=shift (@_));
$ref_stateMachine->setError (
"\x65\x47\x55\x49\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x52\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64"
);return ($ref_stateMachine->sendEvent ("\x65\x72\x72\x6f\x72"));}sub 
NXClusterParser::callbackSSH{package NXClusterParser;no warnings;(my $self=shift
 (@_));(my $ref_hash=shift (@_));(my $buffer=shift (@_));(my $ref_params=
$$ref_hash{"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});(my $ref_machine=
$$ref_params{"\x6d\x61\x63\x68\x69\x6e\x65"});while (($buffer ne (""))){(my $line
=__getLineToParse ((\$buffer)));if (($line=~ /UsernameCallback/ )){$ref_machine
->sendEvent ("\x75\x73\x65\x72\x6e\x61\x6d\x65\x43\x61\x6c\x6c\x62\x61\x63\x6b")
;}elsif (($line=~ /event=0/ )){$ref_machine->sendEvent (
"\x70\x61\x73\x73\x77\x6f\x72\x64\x43\x61\x6c\x6c\x62\x61\x63\x6b");}elsif ((
$line=~ /event=1 (.*)/ )){(my $prompt=$1);Logger::debug (((
"\x4b\x65\x79\x62\x6f\x61\x72\x64\x2d\x69\x6e\x74\x65\x72\x61\x63\x74\x69\x76\x65\x20\x65\x76\x65\x6e\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x77\x69\x74\x68\x20\x70\x72\x6f\x6d\x70\x74\x20\x27"
.$prompt)."\x27\x2e"));if (($prompt=~ /assword/ )){$ref_machine->sendEvent (
"\x70\x61\x73\x73\x77\x6f\x72\x64\x43\x61\x6c\x6c\x62\x61\x63\x6b");}else{
Logger::error (((
"\x4b\x65\x79\x62\x6f\x61\x72\x64\x2d\x69\x6e\x74\x65\x72\x61\x63\x74\x69\x76\x65\x20\x65\x76\x65\x6e\x74\x20\x75\x6e\x68\x61\x6e\x64\x6c\x65\x64\x20\x70\x72\x6f\x6d\x70\x74\x20\x27"
.$prompt)."\x27\x2e"));}}else{Logger::error (((
"\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x53\x53\x48\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$line)."\x27\x2e"));}}$self->removeHandle ($$ref_hash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($ref_hash,(0x096b+ 6389-0x2260),
(0x0b75+ 5912-0x228d));}sub NXClusterParser::callbackSSHClose{package 
NXClusterParser;no warnings;(my $self=shift (@_));(my $ref_hash=shift (@_));(my $ref_params
=$$ref_hash{"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});(my $ref_machine=
$$ref_params{"\x6d\x61\x63\x68\x69\x6e\x65"});main::nxclose ($$ref_hash{
"\x48\x61\x6e\x64\x6c\x65"});$self->removeHandle ($$ref_hash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($ref_hash,(0x20e9+ 630-0x235f),
(0x0754+ 1910-0x0eca));($$ref_machine{
"\x69\x6e\x73\x69\x64\x65\x43\x61\x6c\x6c\x62\x61\x63\x6b\x46\x44"}=(-
(0x18c4+ 1676-0x1f4f)));}sub NXClusterParser::callbackStdin{package 
NXClusterParser;no warnings;(my $self=shift (@_));(my $ref_hash=shift (@_));(my $buffer
=shift (@_));(my $ref_params=$$ref_hash{
"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});(my $ref_machine=$$ref_params{
"\x6d\x61\x63\x68\x69\x6e\x65"});($buffer=~ s/\r//g );chomp ($buffer);
$ref_machine->setUserAnswer ($buffer);if ($ref_machine->isBlindInput){
$ref_machine->unsetBlindInput;main::nxwrite (main::nxgetSTDOUT (),"\x0a");}
$ref_machine->setStopWaitingForStdinInput;$ref_machine->sendEvent (
"\x61\x6e\x73\x77\x65\x72");$self->removeHandle ($$ref_hash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($ref_hash,(0x0341+ 8010-0x228b),
(0x077f+ 7503-0x24ce));}package NXClusterParser;no warnings;return (
(0x0efc+ 3349-0x1c10));
