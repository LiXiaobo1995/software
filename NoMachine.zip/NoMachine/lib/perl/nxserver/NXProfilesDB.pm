############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXProfilesDB;no warnings;require NXPaths;sub BEGIN{require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub BEGIN{require 
Exception::Log;do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->
import};}(my $__databaseInitialized=(0x01d9+ 7740-0x2015));(my $__userSidsInitialized
=(0x0016+ 2021-0x07fb));(my (%__profiles)=());(my (%__loadedProfiles)=());(my $__fields_in_record
=(0x0351+ 8959-0x2636));sub save{Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42\x3a\x20\x53\x61\x76\x69\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
);if ((not (%__profiles))){NXRedis::sendToDbAndSave (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x0a"
);}else{my ($command);foreach my $key (keys (%__profiles)){(my $line=join (
"\x3a",@{$__profiles{$key};}));(my $record=main::urlencode ($line));($key=
main::urlencode ($key));if (($record ne $__loadedProfiles{$key})){(my $newRule=(
(("\x2c\x66\x69\x65\x6c\x64\x3d".$key)."\x2c\x76\x61\x6c\x75\x65\x3d").$record))
;if ((length ($newRule)>(0x10c7+ 4163-0x1ba3))){NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$newRule)."\x0a"));delete ($__loadedProfiles{$key});next;}($command.=$newRule);
}delete ($__loadedProfiles{$key});(my $length=length ($command));if (($length>
15000)){NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$command)."\x0a"));($command=(""));}}if (($command ne (""))){
NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$command)."\x0a"));}if (%__loadedProfiles){my ($commandDel);foreach my $key (
keys (%__loadedProfiles)){($commandDel.=("\x2c\x66\x69\x65\x6c\x64\x3d".$key));}
if (($commandDel ne (""))){NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$commandDel)."\x0a"));}}resetDB ();}return ((0x0bdd+ 1388-0x1149));}sub __load{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x61\x6c\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x0a"
);((%__loadedProfiles)=split ( / / ,NXRedis::get (),(0x1840+ 2153-0x20a9)));
foreach my $key (keys (%__loadedProfiles)){(my $record=main::urldecode (
$__loadedProfiles{$key}));($key=main::urldecode ($key));(my (@recordArray)=split
 ( /:/ ,$record,(0x0317+ 3516-0x10d3)));($__profiles{$key}=(\@recordArray));}
__convertUsernamesInKeysToAbsoluteUsername ();($__databaseInitialized=
(0x0754+ 3079-0x135a));}sub getDatabaseInString{__load ();(my $string=
NXShell::hashParameters2Url (%__loadedProfiles));return ($string);}sub 
setDatabaseByString{(my $string=shift (@_));if (($string eq (""))){return (
(0x14e9+ 2782-0x1fc7));}(my (%tmpProfiles)=NXShell::urlParameter2Hash ($string))
;foreach my $key (keys (%tmpProfiles)){(my (@recordArray)=split ( /:/ ,
main::urldecode ($tmpProfiles{$key}),(0x05fd+ 4825-0x18d6)));($__profiles{$key}=
(\@recordArray));}save ();return ((0x1efc+ 535-0x2113));}sub 
getProfileServerSetInString{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x73\x65\x72\x76\x65\x72\x73\x54\x6f\x43\x68\x65\x63\x6b\x0a"
);return (main::urlencode (NXRedis::get ()));}sub getProfileGroupSetInString{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x67\x72\x6f\x75\x70\x73\x54\x6f\x43\x68\x65\x63\x6b\x0a"
);return (main::urlencode (NXRedis::get ()));}sub saveProfileServerSetByString{(my $string
=shift (@_));(my (@servers)=split ( / / ,main::urldecode ($string),
(0x127b+ 1426-0x180d)));if ((scalar (@servers)==(0x0164+ 6097-0x1935))){
Logger::debug (
"\x4e\x6f\x20\x73\x65\x72\x76\x65\x72\x73\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x69\x6e\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x73\x65\x74\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);return ((0x139d+ 4321-0x247e));}(my $command=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x73\x65\x72\x76\x65\x72\x73\x54\x6f\x43\x68\x65\x63\x6b"
);foreach my $serverToAdd (@servers){($command.=("\x2c\x66\x69\x65\x6c\x64\x3d".
$serverToAdd));}($command.="\x0a");NXRedis::sendToDbAndSave ($command);return (
(0x038a+ 6074-0x1b44));}sub saveProfileGroupSetByString{(my $string=shift (@_));
(my (@groups)=split ( / / ,main::urldecode ($string),(0x1091+ 844-0x13dd)));if (
(scalar (@groups)==(0x0f9b+ 1182-0x1439))){Logger::debug (
"\x4e\x6f\x20\x67\x72\x6f\x75\x70\x73\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x69\x6e\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x73\x65\x74\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);return ((0x1164+ 4530-0x2316));}(my $command=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x67\x72\x6f\x75\x70\x73\x54\x6f\x43\x68\x65\x63\x6b"
);foreach my $groupToAdd (@groups){($command.=("\x2c\x66\x69\x65\x6c\x64\x3d".
$groupToAdd));}($command.="\x0a");NXRedis::sendToDbAndSave ($command);return (
(0x007d+ 5439-0x15bc));}sub cleanDb{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x0a"
);resetDB ();((%__loadedProfiles)=());}sub getDatabaseReference{if ((
$__databaseInitialized==(0x0819+ 4289-0x18da))){__load ();}return ((\%__profiles
));}sub getEmptyProfile{return ((((""))x $__fields_in_record));}sub resetDB{
Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42\x3a\x20\x52\x65\x73\x65\x74\x69\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
);($__databaseInitialized=(0x1aaf+ 2147-0x2312));foreach my $key (keys (
%__profiles)){delete ($__profiles{$key});}}sub 
__convertUsernamesInKeysToAbsoluteUsername{if ((($__userSidsInitialized==
(0x024b+ 231-0x0331))or ($GLOBAL::DisableUsernameConversion==
(0x0157+ 1661-0x07d3)))){return;}Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42\x3a\x20\x43\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x73\x20\x74\x6f\x20\x53\x49\x44\x73\x2e"
);foreach my $key (keys (%__profiles)){(my $convertedKey=$key);
convertUsernameInKeyToAbsoluteUsername ((\$convertedKey));if (($convertedKey ne 
$key)){($__profiles{$convertedKey}=$__profiles{$key});delete ($__profiles{$key})
;}}($__userSidsInitialized=(0x0c2d+ 5378-0x212e));}sub 
convertUsernameInKeyToAbsoluteUsername{if (($GLOBAL::DisableUsernameConversion==
(0x0f21+ 731-0x11fb))){return;}(my $ref_key=shift (@_));if ((
__convertUsernameInNodeAndUserProfileKeyToAbsoluteUsername ($ref_key)==
(0x024b+ 2027-0x0a35))){return;}if ((
__convertUsernameInUserProfileKeyToAbsoluteUsername ($ref_key)==
(0x180f+ 1665-0x1e8f))){return;}}sub 
__convertUsernameInNodeAndUserProfileKeyToAbsoluteUsername{(my $ref_key=shift (
@_));if (($$ref_key=~ /(.*),(.*)/ )){(my $node=$1);(my $user=$2);if (($node=~ /\// )
){if ((__convertUsernameInUserProfileKeyToAbsoluteUsername ((\$user))==
(0x1565+ 670-0x1802))){($$ref_key=(($node."\x2c").$user));}}return (
(0x0b16+ 5639-0x211c));}return ((0x1da9+ 1544-0x23b1));}sub 
__convertUsernameInUserProfileKeyToAbsoluteUsername{(my $ref_key=shift (@_));if 
(NXProfiles::isInternalKey ($$ref_key)){return ((0x0fe7+ 483-0x11ca));}if ((
$$ref_key eq (""))){Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x65\x6d\x70\x74\x79\x20\x6b\x65\x79\x2e"
);return ((0x013d+ 6893-0x1c2a));}if (NXNodes::isUUID ($$ref_key)){return (
(0x0607+ 4299-0x16d2));}if (($$ref_key=~ /__group__/ )){return (
(0x08a6+ 6824-0x234e));}if (($$ref_key=~ /\// )){return ((0x0b71+ 3315-0x1864));
}if (($$ref_key=~ /__nodegroup__/ )){return ((0x0c83+ 3226-0x191d));}if ((
$$ref_key=~ /__servergroup__/ )){return ((0x0917+ 2176-0x1197));}if (($$ref_key
=~ /__address__/ )){return ((0x0705+ 538-0x091f));}(my $username=
NXLogin::getAbsoluteNameForUsername ($$ref_key));($$ref_key=$username);return (
(0x04d0+ 4340-0x15c3));}sub reloadProfilesDB{($__databaseInitialized=
(0x0d44+ 5324-0x2210));($__userSidsInitialized=(0x11af+ 523-0x13ba));((
%__profiles)=());__load ();if (NXProfiles::isPropagatedRuleToOverwrite ()){
NXProfiles::overwritePropagatedRules ();}}"\x3f\x3f\x3f";
