############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXConnectionPolicy::BEGIN{package NXConnectionPolicy;no warnings;require 
NXServices;do{"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73"->import};}sub 
NXConnectionPolicy::BEGIN{package NXConnectionPolicy;no warnings;require NXMsg;
do{"\x4e\x58\x4d\x73\x67"->import};}sub 
NXConnectionPolicy::__setDefaultPolicyValues{package NXConnectionPolicy;no 
warnings;(my $ref_autocreate=shift (@_));(my $ref_autoconnect=shift (@_));(my $ref_automigrate
=shift (@_));(my $ref_desktop=shift (@_));(my $ref_dialog=shift (@_));(my $ref_xsessions
=shift (@_));(my $ref_udp=shift (@_));if (Server::isReverseDefaultDesktopPolicy 
()){($$ref_autocreate="\x6e\x6f");($$ref_autoconnect="\x6e\x6f");(
$$ref_automigrate="\x6e\x6f");($$ref_desktop="\x79\x65\x73");($$ref_dialog=
"\x6e\x6f");($$ref_xsessions="\x79\x65\x73");($$ref_udp="\x79\x65\x73");}else{(
$$ref_autocreate="\x79\x65\x73");($$ref_autoconnect="\x79\x65\x73");(
$$ref_automigrate="\x79\x65\x73");($$ref_desktop="\x6e\x6f");($$ref_dialog=
"\x6e\x6f");($$ref_xsessions="\x6e\x6f");($$ref_udp="\x79\x65\x73");}}sub 
NXConnectionPolicy::getConnectionPolicyValues{package NXConnectionPolicy;no 
warnings;my ($autocreate,$autoconnect,$automigrate,$desktop,$dialog,$xsessions,
$udp);__setDefaultPolicyValues ((\$autocreate),(\$autoconnect),(\$automigrate),(
\$desktop),(\$dialog),(\$xsessions),(\$udp));if (($GLOBAL::ConnectPolicy eq 
"\x6e\x6f\x74\x53\x65\x74")){if (Server::isReverseDefaultDesktopPolicy ()){(
$GLOBAL::ConnectPolicyDesktop=(0x137f+ 4066-0x2361));}return ($autocreate,
$autoconnect,$automigrate,$desktop,$dialog,$xsessions,$udp);}(my (@parameters)=
split ( /,/ ,$GLOBAL::ConnectPolicy,(0x0fef+ 2537-0x19d8)));foreach my $value (
@parameters){if (($value eq "\x61\x75\x74\x6f\x63\x72\x65\x61\x74\x65\x3d\x31"))
{($autocreate="\x79\x65\x73");}elsif (($value eq 
"\x61\x75\x74\x6f\x63\x72\x65\x61\x74\x65\x3d\x30")){($autocreate="\x6e\x6f");}
if (($value eq "\x61\x75\x74\x6f\x63\x6f\x6e\x6e\x65\x63\x74\x3d\x31")){(
$autoconnect="\x79\x65\x73");}elsif (($value eq 
"\x61\x75\x74\x6f\x63\x6f\x6e\x6e\x65\x63\x74\x3d\x30")){($autoconnect=
"\x6e\x6f");}if (($value eq 
"\x61\x75\x74\x6f\x6d\x69\x67\x72\x61\x74\x65\x3d\x31")){($automigrate=
"\x79\x65\x73");}elsif (($value eq 
"\x61\x75\x74\x6f\x6d\x69\x67\x72\x61\x74\x65\x3d\x30")){($automigrate=
"\x6e\x6f");}if (($value eq "\x64\x65\x73\x6b\x74\x6f\x70\x3d\x31")){(
$GLOBAL::ConnectPolicyDesktop=(0x06da+ 6294-0x1f6f));($desktop="\x79\x65\x73");}
elsif (($value eq "\x64\x65\x73\x6b\x74\x6f\x70\x3d\x30")){(
$GLOBAL::ConnectPolicyDesktop=(0x1290+ 800-0x15b0));($desktop="\x6e\x6f");}if ((
$value eq "\x64\x69\x61\x6c\x6f\x67\x3d\x31")){($dialog="\x79\x65\x73");}elsif (
($value eq "\x64\x69\x61\x6c\x6f\x67\x3d\x30")){($dialog="\x6e\x6f");}if ((
$value eq "\x78\x73\x65\x73\x73\x69\x6f\x6e\x73\x3d\x31")){($xsessions=
"\x79\x65\x73");}elsif (($value eq 
"\x78\x73\x65\x73\x73\x69\x6f\x6e\x73\x3d\x30")){($xsessions="\x6e\x6f");}if ((
$value eq "\x75\x64\x70\x3d\x31")){($udp="\x79\x65\x73");}elsif (($value eq 
"\x75\x64\x70\x3d\x30")){($udp="\x6e\x6f");}}return ($autocreate,$autoconnect,
$automigrate,$desktop,$dialog,$xsessions,$udp);}sub 
NXConnectionPolicy::formatConnectionPolicyOutput{package NXConnectionPolicy;no 
warnings;my (@out_resources);(my ($autocreate,$autoconnect,$automigrate,$desktop
,$dialog,$xsessions,$udp)=getConnectionPolicyValues ());push (@out_resources,
sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x61\x75\x74\x6f\x63\x72\x65\x61\x74\x65",$autocreate));push (@out_resources,
sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x61\x75\x74\x6f\x63\x6f\x6e\x6e\x65\x63\x74",$autoconnect));push (
@out_resources,sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x61\x75\x74\x6f\x6d\x69\x67\x72\x61\x74\x65",$automigrate));push (
@out_resources,sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x64\x65\x73\x6b\x74\x6f\x70",$desktop));if (
Server::isClientSupportingDialogInConnectionPolicy ()){push (@out_resources,
sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x64\x69\x61\x6c\x6f\x67",$dialog));}if (
Server::isClientSupportsSystemDesktopsInConnectionPolicy ()){push (
@out_resources,sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x78\x73\x65\x73\x73\x69\x6f\x6e\x73",$xsessions));}if (
Server::isClientSupportsUdpInConnectionPolicy ()){push (@out_resources,sprintf (
"\x25\x2d\x32\x34\x2e\x32\x34\x73\x20\x20\x20\x20\x25\x2d\x36\x2e\x36\x73\x0a",
"\x75\x64\x70",$udp));}return (@out_resources);}sub 
NXConnectionPolicy::printConnactionPolicy{package NXConnectionPolicy;no warnings
;(my (@param)=@_);my (%parameters);if (((Server::isClientNxwebclient ()||
Server::isClientNxclient ())and (not (Server::isClientVersion3OrOlder ())))){(my (
@resources)=formatConnectionPolicyOutput ());NXMsg::send_response (
"\x69\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79",
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79");
main::nxwrite (main::nxgetSTDOUT (),"\x0a");main::nxwrite (main::nxgetSTDOUT (),
"\x54\x79\x70\x65\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x56\x61\x6c\x75\x65\x0a"
);main::nxwrite (main::nxgetSTDOUT (),
"\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x2d\x20\x20\x20\x20\x2d\x2d\x2d\x2d\x2d\x2d\x0a"
);foreach my $res (@resources){main::nxwrite (main::nxgetSTDOUT (),$res);}}
return ((0x0920+ 1384-0x0e88));}sub NXConnectionPolicy::isDesktopEnabled{package
 NXConnectionPolicy;no warnings;getConnectionPolicyValues ();if ((
$GLOBAL::ConnectPolicyDesktop==(0x05ca+ 4611-0x17cc))){return (
(0x0a8a+ 1518-0x1077));}return ((0x07a9+ 744-0x0a91));}sub 
NXConnectionPolicy::isSystemDesktopsEnabled{package NXConnectionPolicy;no 
warnings;(my ($autocreate,$autoconnect,$automigrate,$desktop,$dialog,$xsessions,
$udp)=getConnectionPolicyValues ());if ((not (
Server::isClientSupportsSystemDesktopsInConnectionPolicy ()))){return (
(0x0d6c+ 2609-0x179d));}if (($xsessions eq "\x79\x65\x73")){return (
(0x1969+ 1322-0x1e92));}return ((0x0893+ 2674-0x1305));}package 
NXConnectionPolicy;no warnings;NXMsg::register_response (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79",
"\x69\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79",
(0x04eb+ 1251-0x092a));return ((0x1f44+  25-0x1f5c));
