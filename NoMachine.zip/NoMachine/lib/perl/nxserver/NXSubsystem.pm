############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSubsystem::startCluster{package NXSubsystem;no warnings;(my $paramS=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));(my $paramB=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x43\x6c\x75\x73\x74\x65\x72"));(my $homeDir=
NXPaths::getUserNXHomeDir ());libnxh::NXTransSetEnvironment ("\x48\x4f\x4d\x45",
$homeDir);sub BEGIN{require NXClientConnection;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e"->
import};}if ((libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")eq (""))){
libnxh::NXTransSetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e",
NXClientConnection::getConnectionEnvData ());}(my $connectionType=
Server::getConnectionType ());(my $remoteIn=Server::getSubsystemConnectionIN ())
;(my $remoteOut=Server::getSubsystemConnectionOUT ());Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20\x28"
.$connectionType)."\x29\x2e"));Logger::debug ((((((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x43\x72\x65\x61\x74\x65\x28"
.$remoteIn)."\x2c\x20").$remoteOut)."\x2c\x20").$GLOBAL::ClusterPool)."\x2c").((
(((((("\x20".$GLOBAL::ClusterProto)."\x2c\x20").$GLOBAL::ClusterHost)."\x2c\x20"
).$paramS)."\x2c\x20").$paramB)."\x2c")).(((((("\x20".
$GLOBAL::ClusterGracePeriod)."\x2c\x20").$GLOBAL::ClusterRetryInterval).
"\x2c\x20").$GLOBAL::ClusterProbeTimeout)."\x2c")).(((("\x20".
$GLOBAL::ClusterInterval)."\x2c\x20").$GLOBAL::ClusterTimeout)."\x29")));(my $return
=libnxhs::NXClusterSubsystemCreate ($remoteIn,$remoteOut,$GLOBAL::ClusterPool,
$GLOBAL::ClusterProto,$GLOBAL::ClusterHost,$paramS,$paramB,
$GLOBAL::ClusterGracePeriod,$GLOBAL::ClusterRetryInterval,
$GLOBAL::ClusterProbeTimeout,$GLOBAL::ClusterInterval,$GLOBAL::ClusterTimeout));
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x43\x72\x65\x61\x74\x65\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x65\x73\x74\x72\x6f\x79\x28\x29"
);($return=libnxhs::NXClusterDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));if (libnxh::NXEncryptorRunning ()){Logger::debug (
"\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x69\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x72\x65\x65\x43\x6f\x6e\x74\x65\x78\x74\x28\x29"
);(my $return=libnxh::NXEncryptorFreeContext ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x72\x65\x65\x43\x6f\x6e\x74\x65\x78\x74\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x44\x65\x73\x74\x72\x6f\x79\x28\x29"
);($return=libnxh::NXEncryptorDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));}NXShell::setExitRequestClosedStdout ();return (
(0x07a6+ 1497-0x0d7f));}sub NXSubsystem::startUpdate{package NXSubsystem;no 
warnings;(my $homeDir=NXPaths::getUserNXHomeDir ());
libnxh::NXTransSetEnvironment ("\x48\x4f\x4d\x45",$homeDir);if ((
libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")eq (""))){
libnxh::NXTransSetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e",
NXClientConnection::getConnectionEnvData ());sub BEGIN{require 
NXClientConnection;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e"->
import};};}(my $connectionType=Server::getConnectionType ());if ((not (
Server::isConnectionTypeNXD ()))){Logger::warning (
"\x4e\x6f\x74\x20\x2d\x48\x20\x6d\x6f\x64\x65\x2c\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x75\x70\x64\x61\x74\x65\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x2e"
);return ((0x1913+ 1954-0x20b4));}(my $remoteIn=Server::getSubsystemConnectionIN
 ());(my $remoteOut=Server::getSubsystemConnectionOUT ());Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20\x28"
.$connectionType)."\x29"));(my $return=libnxhs::NXUpdateCreate ($remoteIn,
$remoteOut,$GLOBAL::UpdateBase,$GLOBAL::UpdateManifest,$GLOBAL::UpdateFormat,
$GLOBAL::UpdateTarget,$GLOBAL::UpdateHelper));Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x64\x61\x74\x65\x43\x72\x65\x61\x74\x65\x28"
.$remoteIn)."\x2c\x20").$remoteOut).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$return)."\x27\x2e"));(
$return=libnxhs::NXUpdateDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x64\x61\x74\x65\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$return)."\x27\x2e"));NXShell::setExitRequest (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20\x63\x6c\x6f\x73\x65\x64"
);return ((0x09d7+ 3708-0x1853));}sub NXSubsystem::startLocate{package 
NXSubsystem;no warnings;(my $homeDir=NXPaths::getUserNXHomeDir ());
libnxh::NXTransSetEnvironment ("\x48\x4f\x4d\x45",$homeDir);if ((
libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e")eq (""))){
libnxh::NXTransSetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e",
NXClientConnection::getConnectionEnvData ());sub BEGIN{require 
NXClientConnection;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e"->
import};};}(my $connectionType=Server::getConnectionType ());if ((not (
Server::isConnectionTypeNXD ()))){Logger::warning (
"\x4e\x6f\x74\x20\x2d\x48\x20\x6d\x6f\x64\x65\x2c\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x6c\x6f\x63\x61\x74\x65\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x2e"
);return ((0x0911+ 6510-0x227e));}(my $remoteIn=Server::getSubsystemConnectionIN
 ());(my $remoteOut=Server::getSubsystemConnectionOUT ());Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x63\x61\x74\x65\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20\x28"
.$connectionType)."\x29"));(my $return=libnxhs::NXLocateCreate ($remoteIn,
$remoteOut));Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x72\x65\x61\x74\x65\x28"
.$remoteIn)."\x2c\x20").$remoteOut).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$return)."\x27\x2e"));(
$return=libnxhs::NXLocateDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$return)."\x27\x2e"));NXShell::setExitRequest (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x72\x65\x61\x74\x65\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20\x63\x6c\x6f\x73\x65\x64"
);return ((0x1600+ 571-0x183b));}sub NXSubsystem::sendBufferToTheEncryptor{
package NXSubsystem;no warnings;main::nxrequire (
"\x47\x65\x74\x43\x6f\x6d\x6d\x61\x6e\x64\x53\x74\x61\x74\x65\x4d\x61\x63\x68\x69\x6e\x65"
);if ((Server::isConnectionTypeNXD ()!=(0x0967+ 4298-0x1a30))){return (
(0x007c+ 700-0x0338));}(my $readBuffer=GetCommandStateMachine::getReadBuffer ())
;if (($readBuffer ne (""))){(my $fd=Server::getSubsystemEncryptorIN ());(my $bytes
=Common::NXCore::nxwrite ($fd,$readBuffer));if (($bytes==(-(0x0489+ 761-0x0781))
)){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$readBuffer)."\x20\x74\x6f\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20").
$subsystem)."\x2e"));return ((0x0836+ 3763-0x16e8));}else{Logger::debug ((((((((
("\x53\x65\x6e\x74\x20\x27".$readBuffer)."\x27\x20").$bytes).
"\x20\x62\x79\x74\x65\x73\x20\x6f\x6e\x20\x46\x44\x23").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x20\x74\x6f\x20\x73\x75\x62\x73\x79\x73\x74\x65\x6d\x20").$subsystem)."\x2e"))
;}GetCommandStateMachine::clearReadBuffer ();}return ((0x062d+ 7072-0x21cd));}
package NXSubsystem;no warnings;return ((0x0fba+ 1365-0x150e));
