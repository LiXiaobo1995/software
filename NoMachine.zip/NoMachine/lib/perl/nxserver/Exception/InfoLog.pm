############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::InfoLog::BEGIN{package Exception::InfoLog;no warnings;require 
base;do{"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::InfoLog::BEGIN{package Exception::InfoLog;no warnings;require 
overload;do{"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub Exception::InfoLog::notify{package
 Exception::InfoLog;no warnings;(my $self=shift (@_));(my $text=$self->text);(my $statusId
=main::get_unique_id ());($statusId=~ s/(........).*/$1/ );NXMsg::register_error
 ((""),"\x65\x49\x6e\x66\x6f\x4c\x6f\x67",(0x02db+ 3786-0x0f52));NXMsg::error (
"\x65\x49\x6e\x66\x6f\x4c\x6f\x67","\x67\x65\x6e\x65\x72\x61\x6c",$text,
$statusId,$statusId,Logger::logFilePath ());(my $trace=$self->stacktrace);(
$trace=~ s/\n[^\w]+/\n/ );($trace=~ s/\t//gm );(my (@aTrace)=split ( /\n/ ,
$trace,(0x0cdb+ 5538-0x227d)));Logger::multilineLog (((
"\x28\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x69\x64\x20".$statusId)."\x29"),
@aTrace);}package Exception::InfoLog;no warnings;"\x3f\x3f\x3f";
