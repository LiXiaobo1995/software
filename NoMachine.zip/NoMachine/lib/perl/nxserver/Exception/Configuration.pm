############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::Configuration::BEGIN{package Exception::Configuration;no warnings
;require base;do{"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::Configuration::BEGIN{package Exception::Configuration;no warnings;
require overload;do{"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub Exception::Configuration::notify{
package Exception::Configuration;no warnings;(my $self=shift (@_));(my $statusId
=main::get_unique_id ());($statusId=~ s/(........).*/$1/ );
NXMsg::register_response ((""),
"\x65\x44\x65\x74\x65\x63\x74\x65\x64\x49\x6e\x63\x6f\x73\x69\x73\x74\x65\x6e\x63\x79"
,(0x03ca+ 4625-0x1388));NXMsg::send_response (
"\x65\x44\x65\x74\x65\x63\x74\x65\x64\x49\x6e\x63\x6f\x73\x69\x73\x74\x65\x6e\x63\x79"
,"\x67\x65\x6e\x65\x72\x61\x6c",$statusId,$statusId,Logger::logFilePath ());
Logger::multilineLog ((("\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x69\x64\x20".
$statusId)."\x2e"),((((
"\x57\x72\x6f\x6e\x67\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20"
.$self->text)."\x20\x28").$self->csub)."\x29"));}package 
Exception::Configuration;no warnings;"\x3f\x3f\x3f";
