############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NodeCannotStartDisplay::BEGIN{package 
Exception::NodeCannotStartDisplay;no warnings;require base;do{"\x62\x61\x73\x65"
->import ("\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::NodeCannotStartDisplay::BEGIN{package 
Exception::NodeCannotStartDisplay;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NodeCannotStartDisplay::BEGIN{package 
Exception::NodeCannotStartDisplay;no warnings;require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}sub Exception::NodeCannotStartDisplay::notify{
package Exception::NodeCannotStartDisplay;no warnings;(my $self=shift (@_));
NXMsg::register_response ((""),
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x52\x65\x71\x75\x65\x73\x74\x65\x64\x44\x69\x73\x70\x6c\x61\x79"
,(0x2161+ 1452-0x24b8));NXMsg::send_response (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x52\x65\x71\x75\x65\x73\x74\x65\x64\x44\x69\x73\x70\x6c\x61\x79"
,"\x67\x65\x6e\x65\x72\x61\x6c");}package Exception::NodeCannotStartDisplay;no 
warnings;"\x3f\x3f\x3f";
