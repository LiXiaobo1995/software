############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXAnywhereDefault::BEGIN{package NXAnywhereDefault;no warnings;require 
NXAnywhereClient;do{
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x43\x6c\x69\x65\x6e\x74"->import};}
package NXAnywhereDefault;no warnings;%anywhereConnection;($initialized=
(0x1df8+ 323-0x1f3b));($connectionLost=(0x1901+ 2321-0x2212));(
$waitForLogoutForNewLogin=(0x0a70+ 2886-0x15b6));($status=
"\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64");($defaultAuth=
"\x73\x79\x73\x74\x65\x6d");($loginError=(0x10f7+ 3586-0x1ef9));($machineId=("")
);(my $__timeoutToNextLogin=(0x2571+ 147-0x25c8));(my $__defaultUser=
"\x64\x65\x66\x61\x75\x6c\x74");sub initialize{();}sub getStatusMessage{return (
((((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ANYWHERE).
"\x20\x64\x65\x66\x61\x75\x6c\x74\x2c").$status)."\x2c").$loginError)."\x2c").
$machineId));}sub sendStatusToNode{(my $onlyLocal=shift (@_));if (
isNotInitialized ()){return;}if (($machineId eq (""))){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $machineId=
NXAnywhereRedis::getMachineId ());if (($machineId eq (""))){Logger::debug2 ((
Server::getAnywhereName ().
"\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x6d\x61\x63\x68\x69\x6e\x65\x20\x49\x44\x2c\x20\x73\x6b\x69\x70\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x73\x74\x61\x74\x75\x73\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"
));return;}($NXAnywhereDefault::machineId=$machineId);}(my $message=
getStatusMessage ());(my $socket=NXLocalSession::getActiveLocalSessionNodeSocket
 ());if ((defined ($socket)and ($socket!=(-(0x0174+ 8432-0x2263))))){(my $ret=
NXNodeExec::sendToNode ($message,$socket));if ((($ret==(-(0x1279+ 2965-0x1e0d)))
or ($ret==(0x1792+ 2230-0x2048)))){Logger::warning ((Server::getAnywhereName ().
((
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x73\x74\x61\x74\x75\x73\x20"
.$status).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65\x2e"
)));}else{Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x73\x74\x61\x74\x75\x73\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x58\x4e\x6f\x64\x65\x2e"
));}}else{Logger::debug ((("\x53\x6b\x69\x70\x20\x73\x65\x6e\x64\x20".
Server::getAnywhereName ()).
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2c\x20\x77\x61\x69\x74\x20\x66\x6f\x72\x20\x61\x63\x74\x69\x76\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));}if ($onlyLocal){return;}main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);NXDaemonSubscriptionManager::sendMessageToAnywhereSubscribers ($message);}sub 
sendNotificationToNode{(my $message=shift (@_));(my $socket=
NXLocalSession::getActiveLocalSessionNodeSocket ());($message=(((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_ANYWHERE).
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x2c").$message));if ((
defined ($socket)and ($socket!=(-(0x01ec+ 7441-0x1efc))))){(my $ret=
NXNodeExec::sendToNode ($message,$socket));if ((($ret==(-(0x04b8+ 8435-0x25aa)))
or ($ret==(0x0137+ 1881-0x0890)))){Logger::warning ((Server::getAnywhereName ().
(("\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x27".$message).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65\x2e"
)));}else{Logger::debug ((Server::getAnywhereName ().((
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x27".$message).
"\x27\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x58\x4e\x6f\x64\x65\x2e")));}}else
{Logger::debug ((("\x53\x6b\x69\x70\x20\x73\x65\x6e\x64\x20".
Server::getAnywhereName ()).
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2c\x20\x77\x61\x69\x74\x20\x66\x6f\x72\x20\x61\x63\x74\x69\x76\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));}main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);NXDaemonSubscriptionManager::sendMessageToAnywhereSubscribers ($message);}sub 
__changeStatusToConnected{($status="\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64");
sendStatusToNode ();}sub __changeStatusToDisconnected{($status=
"\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64");sendStatusToNode ();}sub 
isStatusConnected{if (($status eq "\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
return ((0x00e9+ 4228-0x116c));}return ((0x04fb+ 8526-0x2649));}sub 
isNotAllowedLoginDefaultUser{if (($GLOBAL::EnableNMNComputerPublishing==
(0x1c5f+ 1118-0x20bd))){Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e"
));return ((0x158d+ 1154-0x1a0e));}if ((not (
NXLicense::isDirectConnectionFeature ()))){Logger::debug ((
Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e\x20\x44\x69\x72\x65\x63\x74\x20\x61\x63\x63\x65\x73\x73\x20\x66\x65\x61\x74\x75\x72\x65\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"
));return ((0x1ac2+  44-0x1aed));}main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((NXCluster::isInStandby ()==
(0x02df+ 5506-0x1860))){Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e\x20\x49\x73\x20\x43\x6c\x75\x73\x74\x65\x72\x20\x69\x6e\x20\x73\x74\x61\x6e\x64\x62\x79\x2e"
));return ((0x0b6c+ 421-0x0d10));}if (Server::isDirectAccessDisabled ()){
Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e\x20\x44\x69\x72\x65\x63\x74\x20\x61\x63\x63\x65\x73\x73\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
));return ((0x0696+ 2432-0x1015));}if (Server::isAnywhereDisabled ()){
Logger::debug ((Server::getAnywhereName ().
"\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e"
));return ((0x105f+ 2155-0x18c9));}return ((0x1e37+ 682-0x20e1));}sub 
isNotInitialized{if (($initialized==(0x0b67+ 2630-0x15ad))){return (
(0x0511+ 4036-0x14d4));}return ((0x070c+ 5658-0x1d26));}sub handleClientMessage{
(my $message=shift (@_));(my $notifyNode=(shift (@_)||(0x00da+ 5577-0x16a3)));
main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);(my $serverDaemonPid=NXClientSystemDaemons::getServerDaemonPid ());if ((
$serverDaemonPid!=$ $)) {
 return (
NXClientSystemDaemons::sendToServerDaemonAnywhereMessage ($message));}if ((
$message eq "\x72\x65\x6c\x6f\x61\x64\x2c\x64\x65\x66\x61\x75\x6c\x74")){
Logger::debug ((("\x52\x65\x6c\x6f\x61\x64\x20".Server::getAnywhereName ()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x2e"
));if (isNotAllowedLoginDefaultUser ()){return;}if (__isConnectionClosed ()){
initialize ();}else{logoutAllConnections ();($waitForLogoutForNewLogin=
(0x183d+ 3535-0x260b));}if (($notifyNode==(0x050c+ 4554-0x16d5))){
sendNotificationToNode ($message);}}elsif (($message=~ /broadcast,(.*)/ )){
Logger::debug ((Server::getAnywhereName ().((
"\x20\x73\x52\x65\x63\x65\x69\x76\x65\x64\x20\x62\x72\x6f\x61\x64\x63\x61\x73\x74\x20\x73\x74\x61\x74\x75\x73\x20\x63\x68\x61\x6e\x67\x65\x20\x74\x6f\x20"
.$1)."\x2e")));}elsif (($message=~ /default,(.*)/ )){if (($1 eq 
"\x64\x69\x73\x61\x62\x6c\x65\x64")){Logger::debug (((
"\x44\x69\x73\x61\x62\x6c\x65\x64\x20".Server::getAnywhereName ()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x2e"
));($GLOBAL::EnableNMNComputerPublishing=(0x09d6+  82-0x0a28));
logoutAllConnections ();if (($notifyNode==(0x0e94+ 2455-0x182a))){
sendNotificationToNode ($message);}}elsif (($1 eq "\x65\x6e\x61\x62\x6c\x65\x64"
)){Logger::debug ((("\x45\x6e\x61\x62\x6c\x65\x64\x20".Server::getAnywhereName 
()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x2e"
));($GLOBAL::EnableNMNComputerPublishing=(0x0bf2+ 3291-0x18cc));
NXServerDaemon::setConnectionToLocalhostNumber ();if (__isConnectionOpen ()){
Logger::warning (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x65\x6e\x61\x62\x6c\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x77\x68\x65\x6e\x20"
.Server::getAnywhereName ()).
"\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x75\x73\x65\x72\x20\x69\x73\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x74\x2e"
));logoutAllConnections ();($waitForLogoutForNewLogin=(0x03c1+ 6044-0x1b5c));}
else{initialize ();}if (($notifyNode==(0x0983+ 6639-0x2371))){
sendNotificationToNode ($message);}}else{Logger::warning (((
"\x4e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20".
Server::getAnywhereName ()).((
"\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x76\x61\x6c\x75\x65\x20"
.$1)."\x2e")));}}elsif (($message eq 
"\x72\x65\x6c\x6f\x61\x64\x2c\x61\x6c\x6c\x6f\x77\x65\x64")){if (
__isConnectionOpen ()){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");
NXAnywhereClient::sendAllowedCommandOnConnection (__getConnectionId (),
NXAnywhereRedis::getAllowed ());}if (($notifyNode==(0x0b1c+ 6533-0x24a0))){
sendNotificationToNode ($message);}}elsif (($message=~ /hostname,(.*)/ )){(
$GLOBAL::NMNHostName=$1);Logger::debug ((("\x52\x65\x6c\x6f\x61\x64\x20".
Server::getAnywhereName ()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x6f\x6e\x20\x63\x68\x61\x6e\x67\x65\x20\x68\x6f\x73\x74\x6e\x61\x6d\x65\x2e"
));if (($notifyNode==(0x072b+ 6629-0x210f))){sendNotificationToNode ($message);}
if (isNotAllowedLoginDefaultUser ()){return;}if (__isConnectionClosed ()){return
;}logoutAllConnections ();($waitForLogoutForNewLogin=(0x047b+ 8459-0x2585));}
else{Logger::warning (((
"\x4e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20".
Server::getAnywhereName ()).(("\x20\x6d\x65\x73\x73\x61\x67\x65\x20".$message).
"\x2e")));}return;}sub loginOnAnywhereServer{(my $id=
NXAnywhereClient::createConnectionAndRegularLogin ());if (defined ($id)){(my $fd
=NXAnywhereClient::getFdById ($id));($anywhereConnection{"\x69\x64"}=$id);
Logger::debug ((Server::getAnywhereName ().((((
"\x20\x41\x64\x64\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$id)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e")));
Common::NXSelector::addToGlobalSelector ($fd,((
"\x41\x6e\x79\x77\x68\x65\x72\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$id)."\x27"),
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74\x3a\x3a\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x61\x72\x73\x65\x72"
);}return;}sub logoutAllConnections{if (isNotInitialized ()){return;}if (
__isConnectionOpen ()){NXAnywhereClient::sendLogoutOnConnection (
__getConnectionId ());}}sub terminate{if (isNotInitialized ()){return;}
__closeConnection ();Logger::debug ((Server::getAnywhereName ().
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x46\x72\x65\x65\x20\x73\x74\x61\x72\x74\x2e"
));libnxhs::NXAnywhereFree ();Logger::debug ((Server::getAnywhereName ().
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x46\x72\x65\x65\x20\x73\x74\x6f\x70\x2e"
));}sub __closeConnection{if (isNotInitialized ()){return;}
__changeStatusToDisconnected ();if (__isConnectionOpen ()){
NXAnywhereClient::closeAnywhereConnection (__getConnectionId ());
__cleanVariables ();}}sub __cleanVariables{($anywhereConnection{"\x69\x64"}=
undef);}sub __isConnectionClosed{if (defined ($anywhereConnection{"\x69\x64"})){
return ((0x0c94+ 2828-0x17a0));}return ((0x0517+ 4673-0x1757));}sub 
__isConnectionOpen{if (defined ($anywhereConnection{"\x69\x64"})){return (
(0x1ba1+ 744-0x1e88));}return ((0x133a+ 4145-0x236b));}sub __getConnectionId{
Logger::debug ((Server::getAnywhereName ().((
"\x20\x67\x65\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x69\x64\x3a\x20\x27"
.$anywhereConnection{"\x69\x64"})."\x27\x2e")));return ($anywhereConnection{
"\x69\x64"});}sub connectionParser{(my $fd=shift (@_));if ((
NXAnywhereClient::readToBuffer ($fd)==(0x07e4+  29-0x0801))){__cleanVariables ()
;return;}my (%command);while (NXAnywhereClient::getCommandResponse ((\%command))
){if (($command{"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq "\x6c\x6f\x67\x69\x6e")){
__handleLoginCommad ($command{"\x65\x72\x72\x6f\x72"},$command{
"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"});}elsif (($command{
"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq "\x6c\x6f\x67\x6f\x75\x74")){
__handleLogoutCommand ();}elsif (($command{"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq 
"\x65\x76\x65\x6e\x74")){__handleEventCommand ($command{"\x65\x72\x72\x6f\x72"},
$command{"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"});}elsif (($command{
"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq "\x74\x77\x6f\x66\x61\x63\x74\x6f\x72")){
main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");
NXTwoFactorDaemon::handleResponse ((\%command));}elsif (($command{
"\x65\x72\x72\x6f\x72"}eq "\x32\x32")){Logger::warning ((Server::getAnywhereName
 ()."\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x65\x72\x72\x6f\x72\x2e"));
__closeConnection ();}}}sub __handleEventCommand{(my $error=shift (@_));(my $data
=shift (@_));Logger::debug ((Server::getAnywhereName ().((
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x47\x6f\x74\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$__defaultUser)."\x27\x2e")));(my (%options)=NXAnywhereClient::parseLine ($data
));if (defined ($options{"\x65\x76\x65\x6e\x74"})){if (($options{
"\x65\x76\x65\x6e\x74"}eq "\x63\x6f\x6e\x6e\x65\x63\x74")){(my $type=$options{
"\x74\x79\x70\x65"});(my $host=$options{"\x69\x70"});(my $port=$options{
"\x70\x6f\x72\x74"});(my $iv=$options{"\x69\x76"});(my $key=$options{
"\x6b\x65\x79"});(my $trusted=$options{"\x74\x72\x75\x73\x74\x65\x64"});(my $rip
=$options{"\x72\x69\x70"});(my $rport=$options{"\x72\x70\x6f\x72\x74"});(my $rstunport
=$options{"\x72\x73\x74\x75\x6e\x70\x6f\x72\x74"});(my $code=$options{
"\x63\x6f\x64\x65"});(my $turn=(""));(my $display="\x64\x65\x66\x61\x75\x6c\x74"
);if (defined ($options{"\x74\x75\x72\x6e"})){($turn=((((((($options{
"\x74\x75\x72\x6e\x62\x69\x6e\x64"}."\x3b").$options{
"\x74\x75\x72\x6e\x63\x68\x61\x6e\x6e\x65\x6c"})."\x3b").$options{
"\x74\x75\x72\x6e\x70\x6f\x72\x74"})."\x3b").((((($options{
"\x74\x75\x72\x6e\x68\x61\x73\x68"}."\x3b").$options{"\x74\x75\x72\x6e\x69\x70"}
)."\x3b").$options{"\x74\x75\x72\x6e\x6e\x6f\x6e\x63\x65"})."\x3b")).(($options{
"\x74\x75\x72\x6e\x72\x65\x61\x6c\x6d"}."\x3b").$options{
"\x74\x75\x72\x6e\x75\x73\x65\x72"})));}if (defined ($options{
"\x74\x75\x72\x6e\x73\x74\x75\x6e"})){($turn.=("\x3b".$options{
"\x74\x75\x72\x6e\x73\x74\x75\x6e"}));}main::closeSocketAtFinish ($options{
"\x66\x64"});Logger::debug ((((Server::getAnywhereName ().((
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$__defaultUser)."\x27\x20\x77\x69\x74\x68\x20")).((((((((((((
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x27".$options{"\x66\x64"}).
"\x27\x2c\x20\x27").$options{"\x74\x6f\x6b\x65\x6e"})."\x27\x2c\x20\x27").$type)
."\x27\x2c\x20\x27").$host)."\x27\x2c\x20\x27").$port)."\x27\x2c\x20\x27").$iv).
"\x27\x2c\x20")).(((((((((((((("\x20\x27".$key)."\x27\x2c\x20\x27").$trusted).
"\x27\x2c\x20\x27").$display)."\x27\x2c\x20\x27").$rport)."\x27\x2c\x20\x27").
$rstunport)."\x27\x2c\x20\x27").$rip)."\x27\x2c\x20\x27").$turn)."\x27\x2e")));
main::nxrequire ("\x53\x6c\x61\x76\x65\x53\x65\x72\x76\x65\x72");
SlaveServer::startServerProcessConnectedToPlayer ($options{"\x66\x64"},$options{
"\x74\x6f\x6b\x65\x6e"},$type,$host,$port,$iv,$key,$trusted,$display,$rport,
$rstunport,$rip,$code,$turn);}if (($options{"\x65\x76\x65\x6e\x74"}eq 
"\x74\x77\x6f\x66\x61\x63\x74\x6f\x72")){($options{"\x65\x72\x72\x6f\x72"}=
$error);main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");
NXTwoFactorDaemon::handleEvent ((\%options));}if (($options{
"\x65\x76\x65\x6e\x74"}eq "\x6d\x61\x63\x68\x69\x6e\x65\x73")){if ((($options{
"\x74\x79\x70\x65"}eq "\x67\x65\x74\x69\x64")and ($options{
"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64"}ne ("")))){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");
NXAnywhereRedis::setMachineId ($options{"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64"})
;($machineId=$options{"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64"});sendStatusToNode 
();}}}else{Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20".
Server::getAnywhereName ()).(((("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x27").$data)."\x27\x2e")));}}sub __handleLogoutCommand{Logger::debug (
(Server::getAnywhereName ().(("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x6f\x75\x74\x2e")));__closeConnection ();
if (($waitForLogoutForNewLogin==(0x0731+ 3296-0x1410))){(
$waitForLogoutForNewLogin=(0x0bf5+ 2555-0x15f0));loginOnAnywhereServer ();}}sub 
__handleLoginCommad{(my $error=shift (@_));(my $data=shift (@_));($loginError=
$error);if (($error==(0x00af+ 3543-0x0e86))){(my (%options)=
NXAnywhereClient::parseLine ($data));($anywhereConnection{
"\x6e\x69\x63\x6b\x6e\x61\x6d\x65"}=$options{"\x6e\x69\x63\x6b\x6e\x61\x6d\x65"}
);Logger::debug ((Server::getAnywhereName ().(("\x20\x75\x73\x65\x72\x20\x27".
$__defaultUser)."\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x2e")));
__changeStatusToConnected ();(my ($owner,$error)=NXSession2::getOwnerBySessionId
 (Server::getMySessionID ()));if ((defined ($owner)and ($owner ne ("")))){
NXAnywhereClient::sendUserOnConnection (__getConnectionId (),$owner);}if ((
$connectionLost==(0x1e9b+ 501-0x208f))){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");
NXAnywhereClient::sendAllowedCommandOnConnection (__getConnectionId (),
NXAnywhereRedis::getAllowed ());}($connectionLost=(0x0a63+ 4758-0x1cf9));}elsif 
(($error==(-(0x1119+ 3943-0x207e)))){Logger::warning ((Server::getAnywhereName 
().(("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x2e"
)));($connectionLost=(0x07aa+ 5065-0x1b72));__changeStatusToDisconnected ();}
elsif (($error==(-(0x03d9+ 5547-0x197a)))){Logger::warning ((
Server::getAnywhereName ().(("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x6c\x6f\x67\x69\x6e\x2e\x20\x54\x68\x65\x72\x65\x20\x77\x61\x73\x20\x6e\x6f\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x61\x6e\x79\x20\x64\x65\x76\x69\x63\x65\x20\x69\x6e\x20\x67\x69\x76\x65\x6e\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
)));NXAnywhereClient::sendLogoutOnConnection (__getConnectionId ());
__closeConnection ();NXEvent::createEventOnTime (
"\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74",(
Common::NXTime::getSecondsSinceEpoch ()+$__timeoutToNextLogin));
NXEvent::subscribe (
"\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74",
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74\x3a\x3a\x6c\x6f\x67\x69\x6e\x4f\x6e\x41\x6e\x79\x77\x68\x65\x72\x65\x53\x65\x72\x76\x65\x72"
);($__timeoutToNextLogin=((0x0233+ 4436-0x1385)*$__timeoutToNextLogin));if ((
$__timeoutToNextLogin>(0x1e7b+ 871-0x1ada))){($__timeoutToNextLogin=
(0x21d7+ 1289-0x1fd8));}}else{Logger::warning (((Server::getAnywhereName ().((
"\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x6c\x6f\x67\x69\x6e\x2e\x20"))
.__getConnectionErrorString ($error)));NXAnywhereClient::sendLogoutOnConnection 
(__getConnectionId ());__closeConnection ();}}sub sendDesktopOwner{(my $owner=
shift (@_));if ((defined ($owner)and ($owner ne ("")))){if (__isConnectionOpen 
()){return (NXAnywhereClient::sendUserOnConnection (__getConnectionId (),$owner)
);}}}sub sendConnections{(my $connections=shift (@_));if ((defined ($connections
)and ($connections ne ("")))){if (__isConnectionOpen ()){return (
NXAnywhereClient::sendConnectedOnConnection (__getConnectionId (),$connections))
;}}}sub __getConnectionErrorString{(my $error=shift (@_));return (((
"\x46\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27".
$error)."\x27\x2e"));}sub getDefaultNickname{return ($anywhereConnection{
"\x6e\x69\x63\x6b\x6e\x61\x6d\x65"});}sub twoFactorRequest{(my $requestId=shift 
(@_));(my $username=shift (@_));(my $client=shift (@_));(my $ip=shift (@_));(my $local
=shift (@_));(my $hostname=shift (@_));(my $platform=shift (@_));(my $method=
shift (@_));if (__isConnectionOpen ()){return (
NXAnywhereClient::sendTwoFactorRequest (__getConnectionId (),$username,$client,
$ip,$requestId,$local,$hostname,$platform,$method));}Logger::warning ((
Server::getAnywhereName ().
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x4e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x20\x61\x6e\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));return ((0x073c+ 7110-0x2301));}sub cancelTwoFactor{(my $requestId=shift (@_)
);if (__isConnectionOpen ()){return (NXAnywhereClient::sendCancelTwoFactor (
__getConnectionId (),$requestId));}Logger::warning ((Server::getAnywhereName ().
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x4e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));return ((0x13f6+ 3877-0x231a));}sub generateAccessKeyIfNeeded{(my $numberOfDigits
=(0x1103+ 3902-0x2038));main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $currentKey=
NXAnywhereRedis::getAccessKey ());unless ((length ($currentKey)==$numberOfDigits
)){(my $generateKey=(libnxh::NXGetRandomNumber ()%((0x0d5b+ 3773-0x1c0e)**
$numberOfDigits)));(my $len=length ($generateKey));if (($len<$numberOfDigits)){(
$generateKey=(("\x30" x ($numberOfDigits-$len)).$generateKey));}
NXAnywhereRedis::setAccessKey ($generateKey);}}sub generateAccessKey{(my $numberOfDigits
=(0x00f1+ 3293-0x0dc5));(my $generateKey=(libnxh::NXGetRandomNumber ()%(
(0x0394+ 826-0x06c4)**$numberOfDigits)));(my $len=length ($generateKey));if ((
$len<$numberOfDigits)){($generateKey=(("\x30" x ($numberOfDigits-$len)).
$generateKey));}return ($generateKey);}sub getDefaultAuth{return ($defaultAuth);
}"\x3f\x3f\x3f";
