############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXDbusMonitor;no warnings;require Common::NXShellCommands;require NXDbus
;($monitoringMode_noDbus="\x5f\x5f\x6e\x6f\x44\x42\x75\x73\x5f\x5f");(
$monitoringMode_CK=
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x43\x6f\x6e\x73\x6f\x6c\x65\x4b\x69\x74"
);($monitoringMode_GDM=
"\x6f\x72\x67\x2e\x67\x6e\x6f\x6d\x65\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72"
);($monitoringMode_FDM=
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72"
);($monitoringMode_LOG=
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x6c\x6f\x67\x69\x6e\x31"
);($event_sessionAdded="\x53\x65\x73\x73\x69\x6f\x6e\x41\x64\x64\x65\x64");(
$event_sessionRemoved="\x53\x65\x73\x73\x69\x6f\x6e\x52\x65\x6d\x6f\x76\x65\x64"
);($event_activeSessionChanged=
"\x41\x63\x74\x69\x76\x65\x53\x65\x73\x73\x69\x6f\x6e\x43\x68\x61\x6e\x67\x65\x64"
);($monitoringMode=(""));($stdout=(-(0x16e6+ 3203-0x2368)));($stdin=(-
(0x13a3+ 3297-0x2083)));($started=(0x0c93+ 317-0x0dd0));($pid=
(0x0da7+ 5593-0x2380));($currentEvent=(""));sub startMonitor{if ((not (
isDbusEnabledByConfig ()))){Logger::debug (
"\x44\x42\x75\x73\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x18a3+ 129-0x1924));}if ($started){return ((0x10f1+ 5485-0x265e));}
if (($monitoringMode eq (""))){if ((not (selectMonitoringMode ()))){
Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x3a\x20\x6e\x6f\x20\x62\x75\x73\x20\x73\x75\x69\x74\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x69\x6e\x67\x20\x66\x6f\x75\x6e\x64\x2e"
);return ((0x0b7d+ 5687-0x21b4));}}Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);my ($dbusIn);my ($dbusOut);Common::NXCore::nxPipeCreateBi ((\$stdin),(\$dbusIn
));Common::NXCore::nxPipeCreateBi ((\$stdout),(\$dbusOut));if (($monitoringMode 
eq $monitoringMode_CK)){($pid=NXDbus::dbusMonitor ($dbusIn,$dbusOut,
"\x73\x79\x73\x74\x65\x6d","\x73\x69\x67\x6e\x61\x6c",(""),
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x43\x6f\x6e\x73\x6f\x6c\x65\x4b\x69\x74\x2e\x53\x65\x61\x74"
,("")));}elsif (($monitoringMode eq $monitoringMode_GDM)){($pid=
NXDbus::dbusMonitor ($dbusIn,$dbusOut,"\x73\x79\x73\x74\x65\x6d",
"\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c",(""),
"\x6f\x72\x67\x2e\x67\x6e\x6f\x6d\x65\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72\x2e\x4d\x61\x6e\x61\x67\x65\x72"
,"\x52\x65\x67\x69\x73\x74\x65\x72\x53\x65\x73\x73\x69\x6f\x6e"));}elsif ((
$monitoringMode eq $monitoringMode_FDM)){($pid=NXDbus::dbusMonitor ($dbusIn,
$dbusOut,"\x73\x79\x73\x74\x65\x6d","\x73\x69\x67\x6e\x61\x6c",(""),
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72"
,("")));}elsif (($monitoringMode eq $monitoringMode_LOG)){($pid=
NXDbus::dbusMonitor ($dbusIn,$dbusOut,"\x73\x79\x73\x74\x65\x6d",
"\x73\x69\x67\x6e\x61\x6c",(""),
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x6c\x6f\x67\x69\x6e\x31\x2e\x4d\x61\x6e\x61\x67\x65\x72"
,("")));}if (($pid>(0x04ab+ 2067-0x0cbe))){($started=(0x148a+ 4447-0x25e8));
Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid)."\x2e"));return ((0x02d0+ 7068-0x1e6b));}else{Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);return ((0x012b+ 281-0x0244));}}sub getStdout{return ($stdout);}sub isRunning{
return ($started);}sub stopMonitor{Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x73\x74\x6f\x70\x4d\x6f\x6e\x69\x74\x6f\x72\x2e"
);if (isRunning ()){Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x73\x69\x67\x74\x65\x72\x6d\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));Common::NXProcess::signalProcessByRestrictedScript ($pid,
Common::NXProcess::getSignalTerm ());if ((Common::NXProcess::nxwaitpid ($pid,
$NXBits::WAIT_UNTRACED,(0x0731+ 3430-0x1492))==$pid)){($pid=(-
(0x0df8+ 5430-0x232d)));($started=(0x0319+ 5357-0x1806));}else{
Common::NXProcess::signalProcessByRestrictedScript ($pid,
Common::NXProcess::getSignalKill ());if ((Common::NXProcess::nxwaitpid ($pid,
$NXBits::WAIT_UNTRACED,(0x0bdf+ 5016-0x1f72))==$pid)){($pid=(-
(0x1c39+ 1445-0x21dd)));($started=(0x0b91+ 4205-0x1bfe));}}}}sub 
parseDbusMonitorBuffer{(my $buffer=shift (@_));(my (@lines)=split ( /\n/ ,
$buffer,(0x1274+ 4695-0x24cb)));foreach my $line (@lines){parseDbusMonitorLine (
$line);}}sub parseDbusMonitorLine{(my $line=shift (@_));Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x70\x61\x72\x73\x65\x20\x6c\x69\x6e\x65\x20\x27"
.$line)."\x27\x2e"));if (($monitoringMode eq $monitoringMode_CK)){
parseDbusMonitorLine_CK ($line);}elsif (($monitoringMode eq $monitoringMode_LOG)
){parseDbusMonitorLine_LOG ($line);}else{if (($line=~ /member=SessionRemoved/ ))
{PhysicSessions::forceCheck ();}elsif (($line=~ /member=SessionAdded/ )){
PhysicSessions::forceCheck ();}elsif (($line=~ /RegisterSession/ )){
PhysicSessions::forceCheck ();}elsif (($line=~ /object path "(.*)"/ )){(my $objectPath
=$1);Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20\x27"
.$objectPath)."\x27\x2e"));}}}sub parseDbusMonitorLine_CK{(my $line=shift (@_));
if (($line=~ /member=SessionAdded/ )){PhysicSessions::forceCheck ();}elsif ((
$line=~ /member=SessionRemoved/ )){PhysicSessions::forceCheck ();}elsif (($line
=~ /member=ActiveSessionChanged/ )){PhysicSessions::forceCheck ();}elsif (($line
=~ /object path "(.*)"/ )){(my $objectPath=$1);Logger::debug (((((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x27"
.$objectPath)."\x27\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$currentEvent)
."\x2e"));if (($currentEvent eq $event_sessionAdded)){PhysicSessions::forceCheck
 ();}if (($currentEvent eq $event_sessionRemoved)){PhysicSessions::forceCheck ()
;}setEvent ((""));}elsif (($line=~ /string "(.*)"/ )){(my $objectPath=$1);
Logger::debug (((((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x27"
.$objectPath)."\x27\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$currentEvent)
."\x2e"));if (($objectPath eq (""))){setEvent ((""));return (
(0x0a96+ 4883-0x1da9));}if (($currentEvent eq $event_activeSessionChanged)){
PhysicSessions::forceCheck ();}setEvent ((""));}}sub parseDbusMonitorLine_LOG{(my $line
=shift (@_));if (($line=~ /member=SessionNew/ )){PhysicSessions::forceCheck ();}
elsif (($line=~ /member=SessionRemoved/ )){PhysicSessions::forceCheck ();}elsif 
(($line=~ /object path "(.*)"/ )){(my $objectPath=$1);Logger::debug (((((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x27"
.$objectPath)."\x27\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$currentEvent)
."\x2e"));if (($currentEvent eq $event_sessionAdded)){PhysicSessions::forceCheck
 ();}if (($currentEvent eq $event_sessionRemoved)){PhysicSessions::forceCheck ()
;}setEvent ((""));}}sub selectMonitoringMode{if (($monitoringMode ne (""))){
Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));if (($monitoringMode eq $monitoringMode_noDbus)){
return ((0x03c6+ 5076-0x179a));}return ((0x10d4+ 648-0x135b));}(my (@busNames)=
NXDbus::getSystemBusNames ());foreach my $busName (@busNames){if (
canNameBeUsedToMonitor ($busName)){if (($busName eq $monitoringMode_GDM)){(
$monitoringMode=$busName);Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));return ((0x0f2f+ 3975-0x1eb5));}elsif (($busName 
eq $monitoringMode_FDM)){($monitoringMode=$busName);Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));return ((0x2106+ 1217-0x25c6));}elsif (($busName 
eq $monitoringMode_CK)){($monitoringMode=$busName);}elsif ((($busName eq 
$monitoringMode_LOG)and ($monitoringMode ne $monitoringMode_CK))){(
$monitoringMode=$busName);}elsif ((($monitoringMode ne $monitoringMode_CK)and (
$monitoringMode ne $monitoringMode_LOG))){($monitoringMode=$busName);}}}if ((
$monitoringMode ne (""))){Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));return ((0x1084+ 2521-0x1a5c));}($monitoringMode=
$monitoringMode_noDbus);return ((0x0358+ 8037-0x22bd));}sub monitoringMode_byLOG
{if (($monitoringMode eq $monitoringMode_LOG)){return ((0x02a2+ 2993-0x0e52));}
return ((0x16e1+ 802-0x1a03));}sub monitoringMode_byCK{if (($monitoringMode eq 
$monitoringMode_CK)){return ((0x192b+ 575-0x1b69));}return (
(0x0a86+ 2595-0x14a9));}sub monitoringMode_byGDM{if (($monitoringMode eq 
$monitoringMode_GDM)){return ((0x1059+ 3949-0x1fc5));}return (
(0x1ea7+ 1884-0x2603));}sub monitoringMode_byFDM{if (($monitoringMode eq 
$monitoringMode_FDM)){return ((0x1589+ 3197-0x2205));}return (
(0x1bdc+ 848-0x1f2c));}sub checkByDbusDisabled{if (($monitoringMode eq (""))){
return ((0x0c39+ 3603-0x1a4b));}if (($monitoringMode eq $monitoringMode_noDbus))
{return ((0x0134+ 3655-0x0f7a));}return ((0x08c8+ 5196-0x1d14));}sub 
canNameBeUsedToMonitor{(my $name=shift (@_));if ((((($name eq $monitoringMode_CK
)or ($name eq $monitoringMode_FDM))or ($name eq $monitoringMode_LOG))or ($name 
eq $monitoringMode_GDM))){return ((0x0736+ 1420-0x0cc1));}return (
(0x0883+ 3197-0x1500));}sub setEvent{(my $event=shift (@_));($currentEvent=
$event);}sub isDbusEnabledByConfig{return ($GLOBAL::UseDbusToHandleSystemEvents)
;}"\x3f\x3f\x3f";
