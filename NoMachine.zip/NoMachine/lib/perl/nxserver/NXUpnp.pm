############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUpnp::BEGIN{package NXUpnp;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXUpnp::BEGIN{package NXUpnp;no
 warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};
}sub NXUpnp::BEGIN{package NXUpnp;no warnings;require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}sub NXUpnp::BEGIN{package NXUpnp;no warnings;
require NXNodeInfo;do{"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f"->import};}sub 
NXUpnp::BEGIN{package NXUpnp;no warnings;require NXClientSystemDaemons;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
->import};}package NXUpnp;no warnings;($setTime=(0x13b0+ 5144-0x2570));(
$defaultTimeout=(0x12c4+ 1636-0x170c));($timeout=$defaultTimeout);(
@timeoutForRepeatMapping=((0x0075+ 826-0x03a5),(0x09d3+  36-0x09d9),
(0x0114+ 5067-0x14a3)));(@allPossibleTimeoutForRepeat=((0x14a1+ 1758-0x1b75),
(0x0eef+ 4957-0x222e),(0x0cc4+ 2186-0x1512)));($repeatMappingDisabled=
(0x0837+ 4404-0x196b));($repeatMappingStarted=(0x05a7+ 6223-0x1df5));(
$repeatMapping=$repeatMappingDisabled);($protocolsCountForRepeatMapping=
(0x043f+ 5975-0x1b96));($directoryPath=(""));($UPnPStartTime=
(0x177d+ 2780-0x2259));(@UPnPServices=("\x75\x70\x6e\x70\x6e\x78\x74\x63\x70",
"\x75\x70\x6e\x70\x6e\x78\x75\x64\x70","\x75\x70\x6e\x70\x73\x73\x68",
"\x75\x70\x6e\x70\x68\x74\x74\x70\x73"));((%serviceUPnPStartTime)=());((
%serviceUPnPTimeout)=());((%serviceUPnPExternalPort)=());((
%serviceUPnPExternalPortFile)=());((%serviceUPnPPort)=());($enabledUPnPMapping=
(0x059d+ 4307-0x1670));($UPnPMapStartTime=(0x0112+ 1240-0x05ea));(
$UPnPMapTimeout=(0x0964+  73-0x09ad));($GatewayIP=(""));($LocalIP=(""));(
$ExternalIP=(""));((%serviceUPnP)=());($UDPPortAdded=(0x0805+ 649-0x0a8e));(
$Handlerstimeout=(0x0d65+ 1481-0x12b6));((%SocketsToWriteNetworkInformation)=())
;($flagInformAllNodesAboutUPnPChanges=(0x0603+ 985-0x09dc));(
$networkThreadStarted=(0x0eac+ 2854-0x19d2));($networkInfostarted=
(0x101c+ 1829-0x1741));($forceStartUPnPMap=(0x063a+ 4888-0x1952));(
$handleNetworkChange=(0x09d3+ 3304-0x16bb));($NORMAL_MODE=(0x0c62+ 6231-0x24b9))
;($BACKGROUND_MODE=(0x1341+ 4915-0x2673));($SKIP_WAITING=(0x0f89+ 4352-0x2089));
($WAIT=(0x09f0+ 5232-0x1e5f));($FIELD_SEPARATOR="\x23");($sessionPort=(-
(0x11e1+ 2525-0x1bbd)));(my $__nxTcpName="\x4e\x58\x54\x43\x50");(my $__nxUdpName
="\x4e\x58\x55\x44\x50");(my $__nxhtdName="\x4e\x58\x48\x54\x44");(my $__nxsshdName
="\x4e\x58\x53\x53\x48");(my $__cfgNXTCPKeyName=
"\x4e\x58\x54\x43\x50\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgNXUDPKeyName=
"\x4e\x58\x55\x44\x50\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgHTTPKeyName=
"\x48\x54\x54\x50\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgSSHDKeyName=
"\x53\x53\x48\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgEnableUPnPKeyName=
"\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50");(my $__cfgNXTCPKeyValue=
"\x4e\x58\x54\x43\x50");(my $__cfgNXUDPKeyValue="\x4e\x58\x55\x44\x50");(my $__cfgHTTPKeyValue
="\x48\x54\x54\x50");(my $__cfgSSHDKeyValue="\x53\x53\x48");(my $__serviceUpnpnxTcp
="\x75\x70\x6e\x70\x6e\x78\x74\x63\x70");(my $__serviceUpnpnxUdp=
"\x75\x70\x6e\x70\x6e\x78\x75\x64\x70");(my $__serviceUpnpssh=
"\x75\x70\x6e\x70\x73\x73\x68");(my $__serviceUpnphttps=
"\x75\x70\x6e\x70\x68\x74\x74\x70\x73");sub __createFileStructure{if ((not (-d (
$GLOBAL::ExternalTCPPortsDir)))){if (mkdir ($GLOBAL::ExternalTCPPortsDir)){
Logger::debug2 ((
"\x43\x72\x65\x61\x74\x65\x64\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20".
$GLOBAL::ExternalTCPPortsDir));Common::NXFile::setPermissionsFullForNX (
$GLOBAL::ExternalTCPPortsDir);}else{Logger::debug2 ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.$GLOBAL::ExternalTCPPortsDir)."\x3a\x20").$!));}}else{
Common::NXFile::setPermissionsFullForNX ($GLOBAL::ExternalTCPPortsDir);}return;}
sub __setExternalUPnPPortsForAllServicesOnNetworkChange{Logger::debug (
"\x5f\x5f\x73\x65\x74\x45\x78\x74\x65\x72\x6e\x61\x6c\x55\x50\x6e\x50\x50\x6f\x72\x74\x73\x46\x6f\x72\x41\x6c\x6c\x53\x65\x72\x76\x69\x63\x65\x73\x4f\x6e\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);(my $ret=(0x0123+ 9414-0x25e9));(my $localIP=getLocalIPFromMemory ());
Logger::debug (((
"\x5f\x5f\x73\x65\x74\x45\x78\x74\x65\x72\x6e\x61\x6c\x55\x50\x6e\x50\x50\x6f\x72\x74\x73\x46\x6f\x72\x41\x6c\x6c\x53\x65\x72\x76\x69\x63\x65\x73\x4f\x6e\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x28\x29\x20\x67\x6f\x74\x20\x6c\x6f\x63\x61\x6c\x20\x49\x50\x3a\x20"
.$localIP)."\x2e"));foreach my $service (@UPnPServices){
getExternalUPnPPortFromMemoryORFile ($service);if (
isNotSetServiceUPnPExternalPort ($service)){if ((($localIP ne (""))and ($localIP
 ne "\x2d\x31"))){setExternalTCPPortFile ($service,$localIP);($ret=
(0x1561+ 4258-0x2602));}}else{($ret=(0x1fab+ 1387-0x2515));}}return ($ret);}sub 
__setExternalUPnPPortsForAllServices{(my $background=(shift (@_)||$NORMAL_MODE))
;Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x55\x50\x6e\x50\x20\x70\x6f\x72\x74\x73\x2e"
);if (isUPnPEnabled ()){if ((($background==$BACKGROUND_MODE)and (
getLocalIPFromMemory ()eq ("")))){getNetworkInfoBackground (
(0x12f8+ 1019-0x16f3));return ((0x2426+ 626-0x2698));}(my $localIP=getLocalIP ()
);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4c\x6f\x63\x61\x6c\x20\x49\x50\x3a\x20\x27".
$localIP)."\x27\x2e"));foreach my $service (@UPnPServices){
getExternalUPnPPortFromMemoryORFile ($service);if (
isNotSetServiceUPnPExternalPort ($service)){setExternalTCPPortFile ($service,
$localIP);}}}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x70\x6f\x72\x74\x73\x20\x6f\x6e\x6c\x79\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x73\x2e"
);foreach my $service (@UPnPServices){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x27"
.$service)."\x27\x2e"));getExternalUPnPPortFromFile ($service);
setExternalTCPPortFile ($service,(-(0x10a0+ 3748-0x1f43)));}}return (
(0x03a6+ 5849-0x1a7e));}sub __initUPnPService{(my $service=shift (@_));(
$serviceUPnPStartTime{$service}=(0x0306+ 766-0x0604));($serviceUPnPExternalPort{
$service}=(0x09d9+ 1696-0x1079));($serviceUPnPPort{$service}=(""));($serviceUPnP
{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x0549+ 6896-0x2039));
setServiceUPnPPort ($service);setServiceUPnPExternalPortFile ($service);
setServiceUPnPTimeout ($service);return;}sub __setUPnPMapEnabled{(my $enable=(
shift (@_)||(0x21d7+ 781-0x24e4)));($enabledUPnPMapping=$enable);}sub 
__addTCPRule{(my $internalPorts=shift (@_));(my $externalPorts=shift (@_));(my $background
=shift (@_));(my $protocol="\x54\x43\x50");return (__addRule ($internalPorts,
$externalPorts,$background,$protocol));}sub __addUDPRule{(my $internalPorts=
shift (@_));(my $externalPorts=shift (@_));(my $background=shift (@_));(my $protocol
="\x55\x44\x50");return (__addRule ($internalPorts,$externalPorts,$background,
$protocol));}sub __addRule{(my $internalPorts=shift (@_));(my $externalPorts=
shift (@_));(my $background=shift (@_));(my $protocol=shift (@_));(my $ret=
(0x1fcc+ 290-0x20ee));if (($background==$BACKGROUND_MODE)){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4d\x61\x70\x70\x69\x6e\x67\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x2e"
);(my ($read,$write)=(""));if (main::nxPipeCreateBi ((\$read),(\$write))){
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$read)."\x20\x46\x44\x23").$write)."\x2e"));}else{(my $error=libnxh::NXGetError
 ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return (
(0x0c37+ 4245-0x1ccc));}Logger::debug (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x28"
.$write)."\x2c\x20").$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").
$protocol)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exitValue=
libnxhs::NXCreatePortsAdd ($write,$internalPorts,$externalPorts,$protocol));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$exitValue)."\x27\x2e"));if (($exitValue<(0x0ce9+ 4043-0x1cb4))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x75\x70\x6e\x70\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));
main::nxclose ($read);main::nxclose ($write);return ((0x02d9+ 8009-0x2222));}
NXSystemDaemons::addUPnPFD ("\x61\x64\x64\x70\x6f\x72\x74\x73",$read,$write,
(0x016c+ 3665-0x0fbd));setNetworkThreadFlag ((0x04b3+ 4701-0x170f));($ret=$read)
;}else{Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x41\x64\x64\x50\x6f\x72\x74\x73\x28"
.$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").$protocol).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $response=("\x20" x 
(0x0238+ 8490-0x22fe)));($exit_value=libnxhs::NXUpnpAddPorts ($internalPorts,
$externalPorts,$protocol,$response));Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x41\x64\x64\x50\x6f\x72\x74\x73\x28\x2e\x2e\x2e\x2c\x20"
.$response).
"\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));($response=~ s/\0// );($response=main::trimLine ($response
));parseNXUpNPMessage ($response,"\x61\x64\x64\x70\x6f\x72\x74\x73");($ret=
(0x0f20+ 5526-0x24b5));}($UPnPStartTime=Common::NXTime::getSecondsSinceEpoch ())
;return ($ret);}sub getServiceNameByPort{(my $protocol=shift (@_));(my $servicePort
=shift (@_));if ((($servicePort eq (""))or ($protocol eq ("")))){Logger::warning
 (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$servicePort).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$protocol).
"\x27\x2e"));return ((""));}foreach my $service (@UPnPServices){(my $port=
getServiceUPnPPort ($service));if ((($port>(0x0f5f+ 2815-0x1a5e))and ($port==
$servicePort))){if ((($protocol eq "\x54\x43\x50")and isTCPService ($service))){
Logger::debug (((((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x46\x6f\x75\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27").$servicePort).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$protocol).
"\x27\x2e"));return ($service);}elsif ((($protocol eq "\x55\x44\x50")and 
isUDPService ($service))){Logger::debug (((((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x46\x6f\x75\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27").$servicePort).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$protocol).
"\x27\x2e"));return ($service);}}}return ((""));}sub setServiceState{(my $service
=shift (@_));(my $state=shift (@_));if (($service eq (""))){Logger::warning (
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x65\x2e"
);return;}if (($state eq "\x31")){Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x53\x65\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));($serviceUPnP{$service}{
"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x0a7c+ 3068-0x1677));}else{Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x53\x65\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x66\x6f\x72\x20\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));(
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x08d3+ 2615-0x130a));}
return;}sub addSocketToClientList{(my $clientSocket=shift (@_));(my $upnpFD=
shift (@_));(my $type=shift (@_));if (($clientSocket eq (""))){return;}
Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x41\x64\x64\x65\x64\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23"
.$clientSocket)."\x20\x6f\x66\x20\x74\x79\x70\x65\x20\x27").$type).
"\x27\x20\x75\x70\x6e\x70\x46\x44\x20\x46\x44\x23").$upnpFD).
"\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x6c\x69\x73\x74\x2e"));(
$SocketsToWriteNetworkInformation{$clientSocket}{"\x74\x79\x70\x65"}=$type);(
$SocketsToWriteNetworkInformation{$clientSocket}{"\x73\x6f\x63\x6b\x65\x74"}=
$upnpFD);Common::NXCore::closeSocketAtFinish ($clientSocket);return;}sub 
isUPnPSocket{(my $fd=shift (@_));if ($SocketsToWriteNetworkInformation{$fd}){
Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23".$fd).
"\x2e"));return ((0x027c+ 4001-0x121c));}return ((0x0188+ 5842-0x185a));}sub 
handleUPnPSocketOnClose{(my $fd=shift (@_));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6c\x6f\x73\x65\x64\x20\x46\x44\x23"
.$fd)."\x2e"));if ($SocketsToWriteNetworkInformation{$fd}){delete (
$SocketsToWriteNetworkInformation{$fd});}}sub handleMessageOnDescriptor{(my $fd=
shift (@_));(my $type=NXSystemDaemons::getUpPnPFDType ($fd));Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23"
.$fd)."\x20\x74\x79\x70\x65\x20\x27").$type)."\x27\x2e"));(my $read_buf=(""));(my $bytes_read
=main::nxread ($fd,(\$read_buf),(0x15bc+ 198-0x0682)));if ((not (defined (
$bytes_read)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());if (((
$errorname eq "\x45\x41\x47\x41\x49\x4e")or ($errorname eq 
"\x45\x49\x4e\x54\x52"))){Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23".
$fd)."\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20").$errorname).
"\x2c\x20").$errorstring)."\x2e"));return;}else{Logger::warning (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23".
$fd)."\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20")
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));
NXSystemDaemons::removeUPnPFD ($fd);}}elsif (($bytes_read==(0x0df7+ 2576-0x1807)
)){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$fd)."\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));
NXSystemDaemons::removeUPnPFD ($fd);}else{parseNXUPnP ($type,$read_buf);
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$fd)."\x2e"));NXSystemDaemons::removeUPnPFD ($fd);}if (($type eq 
"\x61\x64\x64\x70\x6f\x72\x74\x73")){if (($__waitOnAddUPD==(0x098f+ 3987-0x1921)
)){next;}}if (((($type eq "\x6e\x65\x74\x69\x6e\x66\x6f")or ($type eq 
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73"))or ($type eq 
"\x61\x64\x64\x70\x6f\x72\x74\x73"))){if ((checkIfClientIsWaitingForReply ($fd)
==(0x1806+ 1704-0x1ead))){sendNetworkInfoToAllSockets ($type);}elsif (($type eq 
"\x6e\x65\x74\x69\x6e\x66\x6f")){setNetworkInfoFlag ((0x1432+ 3144-0x207a));}if 
(($type eq "\x61\x64\x64\x70\x6f\x72\x74\x73")){informAllNodesAboutUPnPChanges 
();($flagInformAllNodesAboutUPnPChanges=(0x05bc+ 4181-0x1611));}elsif ((($type 
eq "\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73")and (
$flagInformAllNodesAboutUPnPChanges==(0x0ba0+ 1023-0x0f9e)))){
informAllNodesAboutUPnPChanges ();($flagInformAllNodesAboutUPnPChanges=
(0x2380+ 484-0x2564));}}}sub checkIfClientIsWaitingForReply{(my $fdToCheck=shift
 (@_));foreach my $sock (keys (%SocketsToWriteNetworkInformation)){if ((
$SocketsToWriteNetworkInformation{$sock}{"\x73\x6f\x63\x6b\x65\x74"}==$fdToCheck
)){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x46\x44\x23".
$fdToCheck)."\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x73\x74\x2e"));
return ((0x019b+ 4991-0x1519));}}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x46\x44\x23".
$fdToCheck).
"\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x6f\x6e\x20\x6c\x69\x73\x74\x2e"))
;return ((0x1e59+ 2039-0x2650));}sub sendNetworkInfoToAllSockets{(my $type=shift
 (@_));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x6e\x74\x20\x74\x79\x70\x65\x20\x27".
$type).
"\x27\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x74\x6f\x20\x61\x6c\x6c\x20\x73\x6f\x63\x6b\x65\x74\x73\x2e"
));setNetworkInfoFlag ((0x08cb+ 5089-0x1cac));(my $count=scalar (keys (
%SocketsToWriteNetworkInformation)));if (($count==(0x19ab+ 3139-0x25ee))){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x6f\x20\x73\x6f\x63\x6b\x65\x74\x20\x63\x61\x6e\x64\x69\x64\x61\x74\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x2e"
);return;}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6f\x63\x6b\x65\x74\x73\x20\x63\x6f\x75\x6e\x74\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x27"
.$count)."\x27\x2e"));(my $body=buildMessageUPnPStatusFromMemory (
(0x0377+ 4940-0x16c2)));foreach my $sock (keys (
%SocketsToWriteNetworkInformation)){if (($SocketsToWriteNetworkInformation{$sock
}{"\x74\x79\x70\x65"}ne $type)){Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$sock).
"\x2c\x20\x64\x69\x66\x66\x65\x72\x65\x6e\x74\x20\x74\x79\x70\x65\x20\x27").
$type)."\x27\x20\x2d\x20").$SocketsToWriteNetworkInformation{$sock}{
"\x74\x79\x70\x65"})."\x2e"));next;}Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$sock)."\x20\x74\x79\x70\x65\x3a\x20").$SocketsToWriteNetworkInformation{$sock}
{"\x74\x79\x70\x65"})."\x2e"));if (sendNetworkInfoOnSocket ($sock,$body)){
NXServerDaemon::removeClientFDFromSelector ($sock);
NXServerDaemon::clearAcceptFDBuffer ($sock);main::nxclose ($sock);}delete (
$SocketsToWriteNetworkInformation{$sock});}}sub sendNetworkInfoOnSocket{(my $socket
=shift (@_));(my $body=shift (@_));if (($socket eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6f\x63\x6b\x65\x74\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);return ((0x1273+ 498-0x1465));}(my $bytes=main::nxwrite ($socket,$body));
Logger::debug ((((("\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x6e\x74\x20".$bytes
)."\x20\x62\x79\x74\x65\x73\x20\x6f\x6e\x20\x46\x44\x23").$socket)."\x2e"));
return ((0x021c+ 9043-0x256e));}sub parseNXUPnP{(my $type=shift (@_));(my $buffer
=shift (@_));Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x50\x61\x72\x73\x65\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x62\x75\x66\x66\x65\x72\x20\x27").$buffer)."\x27\x2e"));if ((
$type eq "\x6e\x65\x74\x69\x6e\x66\x6f")){parseNXUpNPNetInfoMessage ($buffer);if
 (($handleNetworkChange==(0x0b93+ 6672-0x25a2))){($handleNetworkChange=
(0x03c8+ 1464-0x0980));handleNetworkChangePortsAdd ();}else{
checkAndStartPortMaping ();}}else{parseNXUpNPMessage ($buffer,$type);}return (
(0x0e0b+ 5190-0x2250));}sub parseNXUpNPNetInfoMessage{(my $buffer=shift (@_));
Logger::debug2 (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x70\x61\x72\x73\x65\x4e\x58\x55\x70\x4e\x50\x4e\x65\x74\x49\x6e\x66\x6f\x4d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x61\x64\x3a\x20"
.$buffer)."\x2e"));($buffer=~ s/\0// );if (($buffer=~ /GATEWAY: (.*), LOCAL: (.*), EXTERNAL: (.*)/ )
){($GatewayIP=main::trimLine ($1));($LocalIP=main::trimLine ($2));($ExternalIP=
main::trimLine ($3));}Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x70\x61\x72\x73\x65\x4e\x58\x55\x70\x4e\x50\x4e\x65\x74\x49\x6e\x66\x6f\x4d\x65\x73\x73\x61\x67\x65\x20\x4c\x6f\x63\x61\x6c\x20\x49\x50\x3a\x20"
.$LocalIP)."\x2c\x20\x47\x61\x74\x65\x77\x61\x79\x20\x49\x50\x3a\x20").
$GatewayIP)."\x2c\x20\x45\x78\x74\x65\x72\x6e\x61\x6c\x20\x49\x50\x3a\x20").
$ExternalIP)."\x2e"));return;}sub checkAndStartPortMaping{if ((
$forceStartUPnPMap==(0x1645+ 1711-0x1cf3))){setFlagForceStartUPnPMap (
(0x0097+ 7413-0x1d8c));__setExternalUPnPPortsForAllServices ($NORMAL_MODE);
forceAddPortMapping ();}return;}sub parseNXUpNPMessage{(my $buffer=shift (@_));(my $type
=shift (@_));($buffer=lc ($buffer));($buffer=~ s/tcp=// );(my $protocol=
"\x54\x43\x50");if (($buffer=~ s/udp=// )){($protocol="\x55\x44\x50");}(my (
@List)=split ( /;/ ,$buffer,(0x0deb+ 2112-0x162b)));(my $enabledPortMApping=
(0x10a4+ 2057-0x18ad));foreach my $service (@List){(my ($port,$state)=split ( /:/ ,
$service,(0x0d97+ 1400-0x130c)));(my $name=getServiceNameByPort ($protocol,$port
));setServiceState ($name,$state);if (($state==(0x1151+ 3115-0x1d7b))){(
$enabledPortMApping=(0x0369+ 5643-0x1973));}}if (($type eq 
"\x61\x64\x64\x70\x6f\x72\x74\x73")){__checkInitializeStatusAndAdjustTimeout (
$enabledPortMApping,$protocol);}return;}sub startUPnPMap{(my $time=shift (@_));
__setUPnPMapEnabled ((0x018f+ 9492-0x26a2));if (($time>(0x0d59+ 1219-0x121c))){(
$UPnPMapStartTime=Common::NXTime::getSecondsSinceEpoch ());($UPnPMapTimeout=
$time);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x74\x61\x72\x74\x65\x64\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x27"
.$UPnPMapTimeout)."\x27\x2e"));return;}($UPnPMapStartTime=(0x0650+ 2006-0x0e26))
;($UPnPMapTimeout=(0x0262+ 5418-0x178c));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x74\x61\x72\x74\x65\x64\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x74\x69\x6d\x65\x72\x2e"
);return;}sub stopUPnPMap{unsetUPnPServices ();__setUPnPMapEnabled (
(0x0537+ 2261-0x0e0c));__disableRepeatMapping ((0x147b+ 817-0x17ac));(
$UPnPMapStartTime=(0x1172+  63-0x11b1));($UPnPMapTimeout=(0x0102+ 6388-0x19f6));
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x74\x6f\x70\x65\x64\x20\x6d\x61\x70\x70\x69\x6e\x67\x2e"
);return;}sub isUPnPMapEnabled{return ($enabledUPnPMapping);}sub isUPnPEnabled{
if (($GLOBAL::EnableUPnP=~ /(NXTCP|NXUDP|SSH|HTTP)/i )){return (
(0x15d5+ 664-0x186c));}Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x64\x2e");return (
(0x0ef8+ 4907-0x2223));}sub isUPnPEnabledForSessions{if ((($GLOBAL::EnableUPnP=~ /NX/i )
and ($GLOBAL::EnableUPnPSession eq "\x31"))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x023f+ 6417-0x1b4f));}Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x18f5+ 1643-0x1f60));}sub addUdpRuleForSession{(my $udpPort=shift (
@_));(my $local=NXClientConnection::getLocalIp ());(my $remote=
NXClientConnection::getRemoteIp ());main::nxrequire (
"\x4e\x58\x4e\x65\x74\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73");(my $mask=
NXNetInterfaces::getMask ($local));if ((NXNetInterfaces::checkIsLocal ($local,
$remote,$mask)==(0x0337+ 7260-0x1f93))){addRule ("\x55\x44\x50",$udpPort,
(0x1191+ 5277-0x262d));__setSessionPort ($port);}}sub setServiceUPnPTimeout{(my $service
=shift (@_));(my $timeout=(shift (@_)||$timeout));($serviceUPnPTimeout{$service}
=$timeout);}sub getServiceUPnPTimeout{(my $service=shift (@_));return (
$serviceUPnPTimeout{$service});}sub setServiceUPnPExternalPortFile{(my $service=
shift (@_));($serviceUPnPExternalPortFile{$service}=((
$GLOBAL::ExternalTCPPortsDir.$GLOBAL::DIRECTORY_SLASH).$service));}sub 
getServiceUPnPExternalPortFile{(my $service=shift (@_));return (
$serviceUPnPExternalPortFile{$service});}sub setUPnPStartTime{(my $service=shift
 (@_));($serviceUPnPStartTime{$service}=Common::NXTime::getSecondsSinceEpoch ())
;return;}sub getUPnPStartTime{(my $service=shift (@_));return (
$serviceUPnPStartTime{$service});}sub setServiceUPnPPort{(my $service=shift (@_)
);if (((not (defined ($service)))or ($service eq ("")))){return (
(0x0553+ 4026-0x150d));}(my $port=(0x04d8+ 8227-0x24fb));if (($service eq 
$__serviceUpnpnxTcp)){($port=NXNodeInfo::getNxdPort ());}if (($service eq 
$__serviceUpnpnxUdp)){($port=NXNodeInfo::getNxdUDPPort ());}elsif (($service eq 
$__serviceUpnphttps)){($port=NXNodeInfo::getHttpsPort ());}elsif (($service eq 
$__serviceUpnpssh)){($port=NXNodeInfo::getSshdPort ());}if ((((not (defined (
$serviceUPnPPort{$service})))or ($serviceUPnPPort{$service}eq ("")))or (
$serviceUPnPPort{$service}eq "\x30"))){($serviceUPnPPort{$service}=$port);}
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x70\x6f\x72\x74\x20\x27").$serviceUPnPPort{$service}).
"\x27\x2e"));return;}sub getServiceUPnPPort{(my $service=shift (@_));if (((not (
defined ($service)))or ($service eq ("")))){return ((0x006d+ 3638-0x0ea3));}if (
(defined ($serviceUPnPPort{$service})and ($serviceUPnPPort{$service}ne ("")))){
return ($serviceUPnPPort{$service});}else{setServiceUPnPPort ($service);if ((
defined ($serviceUPnPPort{$service})and ($serviceUPnPPort{$service}ne ("")))){
return ($serviceUPnPPort{$service});}}return ((0x00a0+ 7238-0x1ce6));}sub init{
Logger::debug2 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x69\x6e\x69\x74\x28\x29\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);(my $silence=shift (@_));__createFileStructure ();foreach my $service (
@UPnPServices){__initUPnPService ($service);}if (isUPnPEnabled ()){
__setRepeatMapping ($repeatMappingStarted);__calculateCountForRepeatMapping ();
__setUPnPMapEnabled ((0x0777+ 2196-0x100a));}if ((
__setExternalUPnPPortsForAllServices ($BACKGROUND_MODE)==(0x0080+ 9236-0x2494)))
{setFlagForceStartUPnPMap ((0x21b7+ 330-0x2300));return ((0x0585+ 3840-0x1484));
}return ((0x0256+ 7034-0x1dd0));}sub initServices{foreach my $service (
@UPnPServices){__initUPnPService ($service);}
__setExternalUPnPPortsForAllServices ($NORMAL_MODE);return;}sub 
destroyNetworkThread{if (($networkThreadStarted>(0x0639+ 4490-0x17c3))){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x65\x73\x74\x72\x6f\x79\x4e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $exit_value=libnxhs::NXDestroyNetworkThread ());Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x65\x73\x74\x72\x6f\x79\x4e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x28\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20"
.$exit_value)."\x2e"));setNetworkThreadFlag ((0x0a34+ 5507-0x1fb7));
setNetworkInfoFlag ((0x0c2f+ 4667-0x1e6a));}else{Logger::debug2 (
"\x4e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x20\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x65\x64\x2c\x20\x73\x6b\x69\x70\x70\x65\x64\x2e"
);}}sub destroy{destroyNetworkThread ();NXUdpControl::destroy ();return;}sub 
isUPnPServiceEnabled{(my $service=shift (@_));if (((not (defined ($service)))or 
($service eq ("")))){return ((0x0da5+ 5950-0x24e3));}if ((lc (
$GLOBAL::EnableUPnP)eq "\x6e\x6f\x6e\x65")){return ((0x1c7a+ 728-0x1f52));}(my $return
=(0x11fc+ 3539-0x1fcf));if (((($service eq $__serviceUpnpnxTcp)and (
$GLOBAL::EnableUPnP=~ /NXTCP/ ))and NXSystemDaemons::isNxdEnabled ())){($return=
(0x0ef7+ 468-0x10ca));}elsif (((($service eq $__serviceUpnpnxUdp)and (
$GLOBAL::EnableUPnP=~ /NXUDP/ ))and NXSystemDaemons::isNxdEnabled ())){($return=
(0x1767+ 3600-0x2576));}elsif (((($service eq $__serviceUpnphttps)and (
$GLOBAL::EnableUPnP=~ /HTTP/ ))and 
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ())){($return=
(0x02ff+ 6579-0x1cb1));}elsif (((($service eq $__serviceUpnpssh)and (
$GLOBAL::EnableUPnP=~ /SSH/ ))and NXSystemDaemons::isSSHEnabled ())){if (-x (
$GLOBAL::CommandNXSSHD)){($return=(0x045d+ 2772-0x0f30));}}if (($return==
(0x0852+ 6536-0x21d9))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service)
."\x27\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"));return ((0x1028+ 3348-0x1d3b));}
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service)
."\x27\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"));return ((0x1248+ 2409-0x1bb1))
;}sub getStatusMessage{(my $response=(""));if (
isNotAllUpnpGetNetworkInfoInMemory ()){getNetworkInfo ();}if (
isNotAllUpnpGetNetworkInfoInMemory ()){return ((""));}($response.=((
"\x4c\x6f\x63\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$LocalIP)."\x0a"));($response.=((
"\x47\x61\x74\x65\x77\x61\x79\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$GatewayIP)."\x0a"));($response.=((
"\x45\x78\x74\x65\x72\x6e\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$ExternalIP)."\x0a"));return ($response);}sub __sendMsgOnSocket{Logger::debug2 
((("\x5f\x5f\x73\x65\x6e\x64\x4d\x73\x67\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x28".
join ($",@_))."\x29\x20\x73\x74\x61\x72\x74\x65\x64\x2e"));(my $clientSocket=
shift (@_));(my $response=shift (@_));if ((($clientSocket eq (""))or (
$clientSocket<(0x00c9+ 5905-0x17da)))){Logger::debug (((
"\x5f\x5f\x73\x65\x6e\x64\x4d\x73\x67\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x3a\x20\x53\x6f\x63\x6b\x65\x74\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x6f\x73\x65\x64\x20\x46\x44\x23"
.$clientSocket)."\x2c\x20\x73\x6b\x69\x70\x70\x65\x64\x2e"));return (
(0x0fb4+ 5827-0x2677));}if ((defined ($response)and ($response ne ("")))){
Logger::debug (((((
"\x5f\x5f\x73\x65\x6e\x64\x4d\x73\x67\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x3a\x20\x53\x65\x6e\x64\x20\x75\x70\x6e\x70\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$clientSocket)."\x3a\x20").$response)."\x2e"));main::nxwrite ($clientSocket,
$response);return ((0x01d0+ 3902-0x110d));}return ((0x0f60+ 3693-0x1dcd));}sub 
handleCodeStartUPnPMap{(my $clientSocket=shift (@_));(my $body=shift (@_));if ((
$clientSocket eq (""))){return ((0x09e9+ 6145-0x21ea));}(my $upnpFD=
handleUPnPMapMessage ($clientSocket,$body));if (($upnpFD>(0x0181+ 4019-0x1134)))
{return ((0x1baf+ 2794-0x2698));}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x43\x6f\x64\x65\x53\x74\x61\x72\x74\x55\x50\x6e\x50\x4d\x61\x70\x28\x29\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6f\x6e\x6c\x79\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x73\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);(my $msg=buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);
return ((0x1c84+ 1812-0x2398));}return ((0x0607+ 486-0x07ec));}sub 
handleUPnPMapMessage{(my $clientSocket=shift (@_));(my $message=shift (@_));(my $time
=(""));(my $upnpKey=(""));if (($message=~ /upnpmap time=(\d+):key=(.*)$/ )){(
$time=$1);($upnpKey=$2);}else{Logger::warning (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6d\x61\x70\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);return ((0x0ccb+ 3811-0x1bae));}Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x6d\x61\x70\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x69\x6d\x65\x20\x27"
.$time)."\x27\x20\x6b\x65\x79\x20\x27").$upnpKey)."\x27\x2e"));(my $internalTCPPortsToAdd
=(""));(my $externalTCPPortsToAdd=(""));(my $internalUDPPortsToAdd=(""));(my $externalUDPPortsToAdd
=(""));(my $internalTCPPortsToDelete=(""));(my $externalTCPPortsToDelete=(""));(my $internalUDPPortsToDelete
=(""));(my $externalUDPPortsToDelete=(""));if ((((not (defined ($upnpKey)))or (
$upnpKey eq ("")))or ($upnpKey eq "\x6e\x6f\x6e\x65"))){($GLOBAL::EnableUPnP=
"\x6e\x6f\x6e\x65");}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x73\x2e"
);(my (@servicesList)=split ( /,/ ,$upnpKey,(0x1002+ 2177-0x1883)));(
$GLOBAL::EnableUPnP=(""));foreach my $serviceElement (@servicesList){(my (
@services)=split ( /:/ ,$serviceElement,(0x1e10+ 1766-0x24f6)));(my $service=
(""));if (($services[(0x0eb0+ 2047-0x16af)]eq $__cfgNXTCPKeyValue)){(
$GLOBAL::EnableUPnP.=$__cfgNXTCPKeyValue);($service=$__serviceUpnpnxTcp);}elsif 
(($services[(0x18cf+ 1114-0x1d29)]eq $__cfgNXUDPKeyValue)){($GLOBAL::EnableUPnP
.=("\x2c".$__cfgNXUDPKeyValue));($service=$__serviceUpnpnxUdp);}elsif ((
$services[(0x016c+ 4213-0x11e1)]eq $__cfgSSHDKeyValue)){($GLOBAL::EnableUPnP.=(
"\x2c".$__cfgSSHDKeyValue));($service=$__serviceUpnpssh);}elsif (($services[
(0x1272+ 3591-0x2079)]eq $__cfgHTTPKeyValue)){($GLOBAL::EnableUPnP.=("\x2c".
$__cfgHTTPKeyValue));($service=$__serviceUpnphttps);}else{next;}(my $iPort=
getServiceUPnPPort ($service));(my $newExtPort=$services[(0x11b5+ 2849-0x1cd5)])
;(my $oldExtPort=getExternalUPnPPort ($service));if (isServiceActive ($service))
{if ((($newExtPort eq (""))or ($newExtPort!=$oldExtPort))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x6f\x6c\x64\x20\x70\x6f\x72\x74\x20\x27").$oldExtPort).
"\x27\x2e"));if (isTCPService ($service)){($internalTCPPortsToDelete.=($iPort.
"\x3a"));($externalTCPPortsToDelete.=($oldExtPort."\x3a"));}else{(
$internalUDPPortsToDelete.=($iPort."\x3a"));($externalUDPPortsToDelete.=(
$oldExtPort."\x3a"));}}}if ((($newExtPort ne (""))and ($newExtPort!=
(0x0170+ 7615-0x1f2f)))){__setExternalUPnPPort ($service,$newExtPort);}}}
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x20\x27"
.$GLOBAL::EnableUPnP)."\x27\x2e"));if ((checkAllNetworkInformationsFromMemory ()
==(0x0caa+ 559-0x0ed9))){getNetworkInfoBackground ((0x0241+ 6996-0x1d95));}
startUPnPMap ($time);if ((lc ($GLOBAL::EnableUPnP)eq "\x6e\x6f\x6e\x65")){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x70\x6f\x72\x74\x73\x2e"
);(my $ret=deleteServiceRules ((0x0b45+ 3782-0x1a0b),$BACKGROUND_MODE));if ((
$ret>(0x1d45+  91-0x1da0))){addSocketToClientList ($clientSocket,$ret,
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");(
$flagInformAllNodesAboutUPnPChanges=(0x0334+ 8625-0x24e4));}unsetUPnPServices ()
;return ($ret);}foreach my $service (@UPnPServices){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x73\x2e"
);(my $iPort=getServiceUPnPPort ($service));(my $ePort=getExternalUPnPPort (
$service));Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service)
."\x27\x20\x69\x70\x6f\x72\x74\x20\x27").$iPort).
"\x27\x20\x65\x70\x6f\x72\x74\x20\x27").$ePort)."\x27\x2e"));if (
isUPnPServiceEnabled ($service)){if (isNotSetServiceUPnPExternalPort ($service))
{setExternalTCPPortFile ($service);}if (isTCPService ($service)){(
$internalTCPPortsToAdd.=($iPort."\x3a"));($externalTCPPortsToAdd.=($ePort."\x3a"
));}else{($internalUDPPortsToAdd.=($iPort."\x3a"));($externalUDPPortsToAdd.=(
$ePort."\x3a"));}}else{if (isServiceActive ($service)){if (isTCPService (
$service)){($internalTCPPortsToDelete.=($iPort."\x3a"));(
$externalTCPPortsToDelete.=($ePort."\x3a"));}else{($internalUDPPortsToDelete.=(
$iPort."\x3a"));($externalUDPPortsToDelete.=($ePort."\x3a"));}($serviceUPnP{
$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x0300+ 8129-0x22c1));}}}(
$internalTCPPortsToDelete=~ s/:$// );($externalTCPPortsToDelete=~ s/:$// );
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$internalTCPPortsToDelete)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$externalTCPPortsToDelete)."\x27\x2e"));(my $upnpFD=(0x1393+ 1867-0x1ade));(my $type
=(""));if ((($internalTCPPortsToDelete ne (""))and ($externalTCPPortsToDelete ne
 ("")))){($upnpFD=deletePortMappingBackground ($internalTCPPortsToDelete,
$externalTCPPortsToDelete,"\x54\x43\x50"));($type=
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");}($internalUDPPortsToDelete=~ s/:$// )
;($externalUDPPortsToDelete=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$internalUDPPortsToDelete)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$externalUDPPortsToDelete)."\x27\x2e"));if ((($internalUDPPortsToDelete ne ("")
)and ($externalUDPPortsToDelete ne ("")))){($upnpFD=deletePortMappingBackground 
($internalUDPPortsToDelete,$externalUDPPortsToDelete,"\x55\x44\x50"));($type=
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");}($internalTCPPortsToAdd=~ s/:$// )
;($externalTCPPortsToAdd=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$internalTCPPortsToAdd)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$externalTCPPortsToAdd)."\x27\x2e"));if ((($internalTCPPortsToAdd ne (""))and (
$externalTCPPortsToAdd ne ("")))){($upnpFD=__addTCPRule ($internalTCPPortsToAdd,
$externalTCPPortsToAdd,$BACKGROUND_MODE));($type=
"\x61\x64\x64\x70\x6f\x72\x74\x73");}($internalUDPPortsToAdd=~ s/:$// );(
$externalUDPPortsToAdd=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$internalUDPPortsToAdd)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$externalUDPPortsToAdd)."\x27\x2e"));if ((($internalUDPPortsToAdd ne (""))and (
$externalUDPPortsToAdd ne ("")))){($upnpFD=__addUDPRule ($internalUDPPortsToAdd,
$externalUDPPortsToAdd,$BACKGROUND_MODE));($type=
"\x61\x64\x64\x70\x6f\x72\x74\x73");}if (($upnpFD>(0x01fd+ 6832-0x1cad))){
addSocketToClientList ($clientSocket,$upnpFD,$type);}return ($upnpFD);}sub 
handleCodeStopUPnPMap{(my $clientSocket=shift (@_));Logger::debug (
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x73\x74\x6f\x70\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);if (($clientSocket eq (""))){return ((0x0963+ 6960-0x2493));}stopUPnPMap ();if
 ((checkNetworkInformationsFromMemory ()==(0x0055+ 487-0x023c))){
getNetworkInfoBackground ((0x13a6+ 3879-0x22cd));}(my $upnpFD=deleteServiceRules
 ((0x1f7a+ 1776-0x266a),$BACKGROUND_MODE));if (($upnpFD>(0x0d47+ 647-0x0fce))){
addSocketToClientList ($clientSocket,$upnpFD,
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");(
$flagInformAllNodesAboutUPnPChanges=(0x020d+ 6703-0x1c3b));return (
(0x02b2+ 6309-0x1b56));}return ((0x1975+ 1134-0x1de3));}sub 
handleCodeDeleteUPnPMap{(my $socket_fn=shift (@_));(my $message=(shift (@_)||
("")));($message=~ s/\0// );if (($message=~ /port=(\d+)/ )){(my $port=$1);
deletePortMappingBackground ($port,$port,"\x55\x44\x50",
"\x73\x65\x73\x73\x69\x6f\x6e");}else{Logger::warning (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}return ((0x0e76+ 373-0x0feb));}sub 
handleCodeStatusUPnPMap{(my $clientSocket=shift (@_));Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x73\x74\x61\x74\x75\x73\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$clientSocket)."\x2e"));if ((($clientSocket eq (""))or ($clientSocket<
(0x1467+ 3415-0x21be)))){return ((0x1e45+ 1198-0x22f3));}if ((
checkAllNetworkInformationsFromMemory ()==(0x1bf5+ 537-0x1e0e))){(my $upnpFD=
getNetworkInfoBackground ((0x0f04+ 3504-0x1cb3)));if (($upnpFD!=
(0x0129+ 7828-0x1fbd))){addSocketToClientList ($clientSocket,$upnpFD,
"\x6e\x65\x74\x69\x6e\x66\x6f");return ((0x20e0+ 1392-0x264f));}}(my $skipEmpty=
(0x0c02+ 173-0x0cae));(my $body=buildMessageUPnPStatusFromMemory ($skipEmpty));
Logger::debug2 (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x43\x6f\x64\x65\x53\x74\x61\x74\x75\x73\x55\x50\x6e\x50\x4d\x61\x70\x3a\x20\x53\x65\x6e\x64\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x20\x6f\x6e\x20\x46\x44\x23"
.$clientSocket)."\x2e"));main::nxwrite ($clientSocket,$body);return (
(0x1672+ 3630-0x24a0));}sub buildMessageUPnPStatusFromMemory{(my $skipEmpty=(
shift (@_)||(0x1467+ 2371-0x1daa)));if ((($skipEmpty==(0x0d4c+ 2824-0x1854))and 
isNotAllUpnpGetNetworkInfoInMemory ())){Logger::debug (
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x53\x6b\x69\x70\x20\x62\x75\x69\x6c\x64\x20\x55\x50\x6e\x50\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);return ((""));}if ((not (NXMsg::isMessageRegistered (
"\x69\x43\x4d\x44\x55\x70\x6e\x70\x53\x74\x61\x74\x75\x73")))){
NXMsg::register_response ("\x4e\x58\x55\x70\x6e\x70",
"\x69\x43\x4d\x44\x55\x70\x6e\x70\x53\x74\x61\x74\x75\x73",
$GLOBAL::MSG_UPNP_STATUS);}(my ($regex,$response)=NXMsg::get_msg (
"\x69\x43\x4d\x44\x55\x70\x6e\x70\x53\x74\x61\x74\x75\x73",
"\x4e\x58\x55\x70\x6e\x70"));($response.="\x0a");($response.=((
"\x4c\x6f\x63\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$LocalIP)."\x0a"));($response.=((
"\x47\x61\x74\x65\x77\x61\x79\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$GatewayIP)."\x0a"));($response.=((
"\x45\x78\x74\x65\x72\x6e\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$ExternalIP)."\x0a"));foreach my $service (@UPnPServices){if (((not (defined (
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"})))or ($serviceUPnP{
$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}==(0x134b+ 3481-0x20e4)))){next;}
getExternalUPnPPort ($service);(my $body=(""));if (($service eq 
$__serviceUpnpnxTcp)){($body.="\x4e\x58\x20\x54\x43\x50\x20\x70\x6f\x72\x74\x20"
);}elsif (($service eq $__serviceUpnpnxUdp)){($body.=
"\x4e\x58\x20\x55\x44\x50\x20\x70\x6f\x72\x74\x20");}elsif (($service eq 
$__serviceUpnpssh)){($body.="\x53\x53\x48\x20\x70\x6f\x72\x74\x20");}elsif ((
$service eq $__serviceUpnphttps)){($body.=
"\x48\x54\x54\x50\x20\x70\x6f\x72\x74\x20");}($body.=(getServiceUPnPPort (
$service)."\x20\x6d\x61\x70\x70\x65\x64\x20\x74\x6f\x3a\x20"));($response.=((((
sprintf ("\x25\x2d\x32\x37\x73",$body).$ExternalIP)."\x3a").
$serviceUPnPExternalPort{$service})."\x0a"));}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x42\x75\x69\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$response)."\x27\x2e"));return ($response);}sub buildStatusMessageForClient{
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x42\x75\x69\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);(my $response=(""));($response.=(("\x6c\x6f\x63\x61\x6c\x2c".$LocalIP).
$FIELD_SEPARATOR));($response.=(("\x67\x61\x74\x65\x77\x61\x79\x2c".$GatewayIP).
$FIELD_SEPARATOR));($response.=("\x65\x78\x74\x65\x72\x6e\x61\x6c\x2c".
$ExternalIP));foreach my $service (@UPnPServices){if (((not (defined (
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"})))or ($serviceUPnP{
$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}==(0x027d+ 5871-0x196c)))){next;}
getExternalUPnPPort ($service);if ((($serviceUPnPExternalPort{$service}<=
(0x12d7+ 1793-0x19d8))or ($ExternalIP eq ("")))){Logger::debug2 (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x27".$service).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6d\x69\x73\x73\x69\x6e\x67\x3a\x20").
$ExternalIP)."\x3a").$serviceUPnPExternalPort{$service})."\x2e"));next;}(
$response.=$FIELD_SEPARATOR);if (($service eq $__serviceUpnpnxTcp)){($response.=
"\x6e\x78\x74\x63\x70\x2c");}elsif (($service eq $__serviceUpnpnxUdp)){(
$response.="\x6e\x78\x75\x64\x70\x2c");}elsif (($service eq $__serviceUpnpssh)){
($response.="\x73\x73\x68\x2c");}elsif (($service eq $__serviceUpnphttps)){(
$response.="\x68\x74\x74\x70\x2c");}($response.=(getServiceUPnPPort ($service).
"\x2c"));($response.=main::urlencode ((($ExternalIP.$FIELD_SEPARATOR).
$serviceUPnPExternalPort{$service})));}(my $response_enc=main::urlencode ((
"\x75\x70\x6e\x70\x73\x74\x61\x74\x75\x73\x20".$response)));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x42\x75\x69\x6c\x64\x20\x63\x6c\x69\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$response)."\x27\x2e"));return ($response_enc);}sub buildMessageUPnPStatus{if (
isNotAllUpnpGetNetworkInfoInMemory ()){getNetworkInfo ();}return (
buildMessageUPnPStatusFromMemory ());}sub handleUPnPUnMapMessage{stopUPnPMap ();
deleteServiceRules ((0x081f+ 364-0x098b),$NORMAL_MODE);return (
buildMessageUPnPStatus ());}sub commandUPnPMap{(my $time=(shift (@_)||
(0x1206+ 4708-0x246a)));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x55\x50\x6e\x50\x20\x6d\x61\x70\x2e"
);if ((not (NXClientSystemDaemons::openConnection ()))){__sendMsgOnSocket (
main::nxgetSTDOUT (),getStatusMessage ());return ((0x0d13+ 3196-0x198f));}(my $key
=(""));if (($GLOBAL::EnableUPnP=~ /none/ )){($key="\x6e\x6f\x6e\x65");}else{
main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");if (($GLOBAL::EnableUPnP=~ /NXTCP/ )
){($key.="\x4e\x58\x54\x43\x50\x3a");if ((NXTools::isCorrectPort (
$GLOBAL::NXTCPUPnPPort)and ($GLOBAL::NXTCPUPnPPort>=(0x0c0f+ 3893-0x1b43)))){(
$key.=$GLOBAL::NXTCPUPnPPort);}else{(my $portFromFile=
getExternalUPnPPortFromFile ("\x75\x70\x6e\x70\x6e\x78\x74\x63\x70"));if (((
defined ($portFromFile)and ($portFromFile ne ("")))and ($portFromFile>
(0x13ab+ 803-0x16ce)))){($key.=$portFromFile);}}}if (($GLOBAL::EnableUPnP=~ /NXUDP/ )
){($key.="\x2c\x4e\x58\x55\x44\x50\x3a");if ((NXTools::isCorrectPort (
$GLOBAL::NXUDPUPnPPort)and ($GLOBAL::NXUDPUPnPPort>=(0x10f9+ 1768-0x17e0)))){(
$key.=$GLOBAL::NXUDPUPnPPort);}else{(my $portFromFile=
getExternalUPnPPortFromFile ("\x75\x70\x6e\x70\x6e\x78\x75\x64\x70"));if (((
defined ($portFromFile)and ($portFromFile ne ("")))and ($portFromFile>
(0x13b8+ 1125-0x181d)))){($key.=$portFromFile);}}}if (($GLOBAL::EnableUPnP=~ /SSH/ )
){($key.="\x2c\x53\x53\x48\x3a");if ((NXTools::isCorrectPort (
$GLOBAL::SSHUPnPPort)and ($GLOBAL::SSHUPnPPort>=(0x0cd1+ 5240-0x2148)))){($key.=
$GLOBAL::SSHUPnPPort);}else{(my $portFromFile=getExternalUPnPPortFromFile (
"\x75\x70\x6e\x70\x73\x73\x68"));if (((defined ($portFromFile)and ($portFromFile
 ne ("")))and ($portFromFile>(0x055c+ 1228-0x0a28)))){($key.=$portFromFile);}}}
if (($GLOBAL::EnableUPnP=~ /HTTP/ )){($key.="\x2c\x48\x54\x54\x50\x3a");if ((
NXTools::isCorrectPort ($GLOBAL::HTTPUPnPPort)and ($GLOBAL::HTTPUPnPPort>=
(0x0cf1+ 2569-0x16f9)))){($key.=$GLOBAL::HTTPUPnPPort);}else{(my $portFromFile=
getExternalUPnPPortFromFile ("\x75\x70\x6e\x70\x68\x74\x74\x70\x73"));if (((
defined ($portFromFile)and ($portFromFile ne ("")))and ($portFromFile>
(0x1f0f+ 578-0x2151)))){($key.=$portFromFile);}}}if (($key eq (""))){($key=
"\x6e\x6f\x6e\x65");}}NXClientSystemDaemons::cleanDaemonBuffer ();(my $testresult
=NXClientSystemDaemons::sendMessage ((((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_START).
"\x20\x75\x70\x6e\x70\x6d\x61\x70\x20\x74\x69\x6d\x65\x3d").$time).
"\x3a\x6b\x65\x79\x3d").$key)."\x0a")));(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));
NXClientSystemDaemons::closeConnection ();if ((defined ($reply)and ($reply ne 
("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x6f\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x64\x61\x65\x6d\x6f\x6e\x2e"
);__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());}return (
(0x095b+ 4888-0x1c72));}sub commandUPnPUnMap{(my $time=(shift (@_)||
(0x13ca+ 1004-0x17b6)));if ((not (NXClientSystemDaemons::openConnection ()))){
__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());return (
(0x0bb7+ 1795-0x12ba));}NXClientSystemDaemons::cleanDaemonBuffer ();(my $testresult
=NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".$GLOBAL::MSG_UPNP_STOP
)."\x20\x75\x70\x6e\x70\x75\x6e\x6d\x61\x70\x0a")));(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));
NXClientSystemDaemons::closeConnection ();if ((defined ($reply)and ($reply ne 
("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}else{__sendMsgOnSocket (
main::nxgetSTDOUT (),getStatusMessage ());}return ((0x1442+ 657-0x16d2));}sub 
getStatus{(my $username=Common::NXCore::getEffectiveUsername ());if (($username 
ne "\x6e\x78")){(my $content=(""));(my (@command)=($GLOBAL::CommandNXexec,
"\x2d\x2d\x73\x65\x72\x76\x65\x72",
"\x2d\x2d\x75\x70\x6e\x70\x73\x74\x61\x74\x75\x73"));(my (@parameters)=());push 
(@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45\x3d".
libnxh::NXTransGetEnvironment (
"\x41\x4c\x4c\x55\x53\x45\x52\x53\x50\x52\x4f\x46\x49\x4c\x45")));push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x61\x74\x68\x3d".
libnxh::NXTransGetEnvironment ("\x50\x61\x74\x68")));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if ((not ($exit_value))){($cmd_out=~ s/NX> 6[0-9][0-9] .*\n//gm );($content=
$cmd_out);}if ((defined ($content)and ($content ne ("")))){main::nxwrite (
main::nxgetSTDOUT (),$content);}else{__sendMsgOnSocket (main::nxgetSTDOUT (),
getStatusMessage ());}return;}if ((not (NXClientSystemDaemons::openConnection ()
))){__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());return;}
NXClientSystemDaemons::cleanDaemonBuffer ();(my $testresult=
NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_STATUS_REQUEST).
"\x20\x75\x70\x6e\x70\x73\x74\x61\x74\x75\x73\x0a")));(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));if ((defined (
$reply)and ($reply ne ("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}
NXClientSystemDaemons::closeConnection ();return;}sub checkIfAddPortMapping{
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x6f\x72\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x2e"
);if (($UPnPMapTimeout>(0x112b+ 1277-0x1628))){(my $mappingLife=(
Common::NXTime::getSecondsSinceEpoch ()-$UPnPMapStartTime));if (($mappingLife>=
$UPnPMapTimeout)){stopUPnPMap ();deleteServiceRules ((0x01f1+ 6157-0x19fe),
$NORMAL_MODE);return;}}(my $nxupnpLife=(Common::NXTime::getSecondsSinceEpoch ()-
$UPnPStartTime));if (($nxupnpLife<$timeout)){return;}if (($networkInfostarted==
(0x05dc+ 4878-0x18e9))){return;}($UPnPStartTime=
Common::NXTime::getSecondsSinceEpoch ());if ((getLocalIPFromMemory ()eq (""))){
getNetworkInfoBackground ((0x018d+ 6309-0x1a32));return ((""));}addServiceRules 
((0x124a+ 4337-0x233b));}sub forceAddPortMapping{(my $force=(0x2436+ 281-0x254e)
);return (addServiceRules ($force));}sub addServiceRules{(my $force=(shift (@_)
||(0x04ed+ 6909-0x1fea)));if (($force==(0x1456+ 2913-0x1fb7))){if ((
$UPnPMapTimeout>(0x0b23+ 4959-0x1e82))){(my $mappingLife=(
Common::NXTime::getSecondsSinceEpoch ()-$UPnPMapStartTime));if (($mappingLife>=
$UPnPMapTimeout)){stopUPnPMap ();deleteServiceRules ((0x033c+ 6811-0x1dd7),
$NORMAL_MODE);return ((0x1555+ 4414-0x2693));}}}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x46\x6f\x72\x63\x65\x20\x73\x74\x61\x72\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x70\x6f\x72\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x2e"
);}(my $internalTCPPorts=(""));(my $externalTCPPorts=(""));(my $internalUDPPorts
=(""));(my $externalUDPPorts=(""));foreach my $service (@UPnPServices){if (
isUPnPServiceEnabled ($service)){(my $iPort=getServiceUPnPPort ($service));
getExternalUPnPPortFromMemory ($service);if (isNotSetServiceUPnPExternalPort (
$service)){next;}(my $ePort=$serviceUPnPExternalPort{$service});if ((((($ePort==
(0x1691+ 120-0x1709))or ($iPort==(0x10f3+ 4926-0x2431)))or ($ePort eq ("")))or (
$iPort eq ("")))){next;}if (isTCPService ($service)){($internalTCPPorts.=($iPort
."\x3a"));($externalTCPPorts.=($ePort."\x3a"));}else{($internalUDPPorts.=($iPort
."\x3a"));($externalUDPPorts.=($ePort."\x3a"));}}}($internalTCPPorts=~ s/:$// );
($externalTCPPorts=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x20\x27"
.$internalTCPPorts)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x20\x27"
.$externalTCPPorts)."\x27\x2e"));if ((($internalTCPPorts ne (""))and (
$externalTCPPorts ne ("")))){__addTCPRule ($internalTCPPorts,$externalTCPPorts,
$BACKGROUND_MODE);}($internalUDPPorts=~ s/:$// );($externalUDPPorts=~ s/:$// );
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x20\x27"
.$internalUDPPorts)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x20\x27"
.$externalUDPPorts)."\x27\x2e"));if ((($internalUDPPorts ne (""))and (
$externalUDPPorts ne ("")))){__addUDPRule ($internalUDPPorts,$externalUDPPorts,
$BACKGROUND_MODE);}return ((0x036c+ 1874-0x0abe));}sub isTCPService{(my $service
=shift (@_));if (($service ne "\x75\x70\x6e\x70\x6e\x78\x75\x64\x70")){return (
(0x1baf+ 1576-0x21d6));}return ((0x19e6+ 1413-0x1f6b));}sub isUDPService{(my $service
=shift (@_));if (($service eq "\x75\x70\x6e\x70\x6e\x78\x75\x64\x70")){return (
(0x1459+ 4674-0x269a));}return ((0x04a9+ 3545-0x1282));}sub addRule{(my $protocol
=shift (@_));(my $port=shift (@_));if (((($protocol eq (""))or ($port eq ("")))
or ($port==(0x1875+ 199-0x193c)))){Logger::warning (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x61\x64\x64\x52\x75\x6c\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3a\x20\x27"
.$protocol)."\x27\x2c\x20\x70\x6f\x72\x74\x3a\x20\x27").$port)."\x27\x2e"));
return ((0x0b09+ 1225-0x0fd2));}my ($read,$write);if (main::nxPipeCreateBi ((
\$read),(\$write))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$read)."\x20\x46\x44\x23").$write)."\x2e"));}else{Logger::error (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x70\x61\x69\x72\x2e"
);return ((0x0091+ 652-0x031d));}Logger::debug (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x28"
.$write)."\x2c\x20").$port)."\x2c\x20").$port)."\x2c\x20").$protocol).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exitValue=libnxhs::NXCreatePortsAdd (
$write,$port,$port,$protocol));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x27"
.$exitValue)."\x27\x2e"));if (($exitValue<(0x15cd+ 188-0x1689))){Logger::warning
 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x75\x70\x6e\x70\x2e"
);main::nxclose ($read);main::nxclose ($write);return ((0x10ba+ 3740-0x1f56));}
NXSystemDaemons::addUPnPFD ("\x61\x64\x64\x70\x6f\x72\x74\x73",$read,$write,
(0x06c8+ 374-0x083e));if (($protocol eq "\x55\x44\x50")){setFlagUDPPortAdded ();
}setNetworkThreadFlag ((0x053f+ 8410-0x2618));if (($protocol eq "\x55\x44\x50"))
{main::addFhToMonitor ($read,
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x72\x41\x64\x64\x55\x44\x50\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);}return ((0x08bb+ 3451-0x1635));}sub handlerAddUDPCallback{(my $f=shift (@_));
Logger::debug2 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x72\x41\x64\x64\x55\x44\x50\x43\x61\x6c\x6c\x62\x61\x63\x6b\x28\x29\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);(my $read_buf=(""));(my $bytes_read=(0x179a+ 2078-0x1fb8));(($bytes_read,
$read_buf)=readOnCallbackFD ($f));destroyNetworkThread ();}sub 
handlerDeleteUDPCallback{(my $f=shift (@_));NXUdpControl::freePort (
NXSystemDaemons::getUpPnPFDPort ($f));}sub deleteServiceRules{(my $skipWaiting=(
shift (@_)||(0x0f94+ 672-0x1234)));(my $mode=(shift (@_)||$NORMAL_MODE));
Logger::debug2 (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x44\x65\x6c\x65\x74\x65\x20\x73\x65\x72\x76\x69\x63\x65\x20\x72\x75\x6c\x65\x73\x20\x73\x6b\x69\x70\x57\x61\x69\x74\x69\x6e\x67\x20\x27"
.$skipWaiting)."\x27\x20\x6d\x6f\x64\x65\x20\x27").$mode)."\x27\x2e"));foreach my $service
 (@UPnPServices){getExternalUPnPPort ($service);}(my $internalTCPPortsToDelete=
(""));(my $externalTCPPortsToDelete=(""));(my $internalUDPPortsToDelete=(""));(my $externalUDPPortsToDelete
=(""));foreach my $service (@UPnPServices){(my $iPort=getServiceUPnPPort (
$service));if (((($iPort ne (""))and ($iPort!=(0x0adb+ 2405-0x1440)))and 
isServiceActive ($service))){if (isTCPService ($service)){(
$internalTCPPortsToDelete.=($iPort."\x3a"));($externalTCPPortsToDelete.=(
$serviceUPnPExternalPort{$service}."\x3a"));}else{($internalUDPPortsToDelete.=(
$iPort."\x3a"));($externalUDPPortsToDelete.=($serviceUPnPExternalPort{$service}.
"\x3a"));}($serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=
(0x0f11+ 3261-0x1bce));}}($internalTCPPortsToDelete=~ s/:$// );(
$externalTCPPortsToDelete=~ s/:$// );($internalUDPPortsToDelete=~ s/:$// );(
$externalUDPPortsToDelete=~ s/:$// );(my $upnpFD=(0x0a80+ 3302-0x1766));if (((
$internalTCPPortsToDelete ne (""))and ($externalTCPPortsToDelete ne ("")))){if (
($mode==$NORMAL_MODE)){deleteTCPRule ($internalTCPPortsToDelete,
$externalTCPPortsToDelete,$skipWaiting);}else{($upnpFD=
deletePortMappingBackground ($internalTCPPortsToDelete,$externalTCPPortsToDelete
,"\x54\x43\x50"));}}if ((($internalUDPPortsToDelete ne (""))and (
$externalUDPPortsToDelete ne ("")))){if (($mode==$NORMAL_MODE)){deleteTCPRule (
$internalUDPPortsToDelete,$externalUDPPortsToDelete,$skipWaiting);}else{($upnpFD
=deletePortMappingBackground ($internalUDPPortsToDelete,
$externalUDPPortsToDelete,"\x55\x44\x50"));}}return ($upnpFD);}sub deleteTCPRule
{(my $internalPorts=shift (@_));(my $externalPorts=shift (@_));(my $skipWaiting=
(shift (@_)||(0x1ea6+ 136-0x1f2e)));(my $protocol="\x54\x43\x50");Logger::debug 
(((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28"
.$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").$protocol)."\x2c\x20").
$skipWaiting)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=
libnxhs::NXUpnpRemovePorts ($internalPorts,$externalPorts,$protocol,$skipWaiting
));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x3a\x20"
.$exit_value)."\x2e"));($UPnPStartTime=(0x0288+ 1008-0x0678));return (
(0x073f+ 2185-0x0fc7));}sub deleteRule{(my $protocol=shift (@_));(my $port=shift
 (@_));if ((((((not (defined ($protocol)))or (not (defined ($port))))or (
$protocol eq ("")))or ($port eq ("")))or ($port==(0x0fc0+ 3503-0x1d6f)))){
Logger::debug2 (((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x64\x65\x6c\x65\x74\x65\x52\x75\x6c\x65\x3a\x20\x77\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3a\x20"
.$protocol)."\x2c\x20\x70\x6f\x72\x74\x3a\x20").$port)."\x2e"));return (
(0x02ad+ 1530-0x08a7));}Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28"
.$port)."\x2c\x20").$port)."\x2c\x20").$protocol).
"\x2c\x20\x30\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=
libnxhs::NXUpnpRemovePorts ($port,$port,$protocol,(0x1f77+ 455-0x213e)));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x3a\x20"
.$exit_value)."\x2e"));return ((0x1991+ 2888-0x24d9));}sub 
deletePortMappingBackground{(my $internalPorts=shift (@_));(my $externalPorts=
shift (@_));(my $protocol=shift (@_));(my $type=shift (@_));if (((($protocol eq 
(""))or ($internalPorts eq ("")))or ($externalPorts eq ("")))){Logger::warning (
((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x64\x65\x6c\x65\x74\x65\x50\x6f\x72\x74\x4d\x61\x70\x70\x69\x6e\x67\x42\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27"
.$protocol)."\x27\x20\x70\x6f\x72\x74\x73\x20\x27").$internalPorts)."\x3a").
$externalPorts)."\x27\x2e"));return ((0x0fd3+ 1221-0x1498));}(my ($read),$write)
;if (main::nxPipeCreateBi ((\$read),(\$write))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$read)."\x20\x46\x44\x23").$write)."\x2e"));}else{Logger::error (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x70\x61\x69\x72\x2e"
);return ((0x0528+ 3114-0x1152));}Logger::debug (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x52\x65\x6d\x6f\x76\x65\x28\x46\x44\x23"
.$write)."\x2c\x20").$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").
$protocol)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exitValue=
libnxhs::NXCreatePortsRemove ($write,$internalPorts,$externalPorts,$protocol));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x52\x65\x6d\x6f\x76\x65\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$exitValue)."\x27\x2e"));if (($exitValue<(0x0883+ 7757-0x26d0))){
Logger::warning (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65\x20\x4e\x58\x55\x50\x6e\x50\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20"
.$internalPorts)."\x2e"));main::nxclose ($read);main::nxclose ($write);return (
(0x18f7+ 213-0x19cc));}setNetworkThreadFlag ((0x09cd+ 776-0x0cd4));
NXSystemDaemons::addUPnPFD ("\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73",$read
,$write,$internalPorts);if (($type eq "\x73\x65\x73\x73\x69\x6f\x6e")){
main::addFhToMonitor ($read,
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x72\x44\x65\x6c\x65\x74\x65\x55\x44\x50\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);return ((0x1020+ 5278-0x24bd));}return ($read);}sub setExternalTCPPortFile{(my $service
=shift (@_));(my $localIP=(shift (@_)||("")));if ((((not (defined ($service)))or
 ($service eq ("")))or ($localIP eq "\x2d\x31"))){return ((0x00b4+ 3974-0x103a))
;}(my $port=generateExternalPort ($service,$localIP));if ((((not (defined ($port
)))or ($port eq ("")))or ($port==(0x00d5+ 3809-0x0fb6)))){__setExternalUPnPPort 
($service,(0x0481+ 7070-0x201f));return ((0x0748+ 2349-0x1075));}
__setExternalUPnPPort ($service,$port);(my $portFile=
getServiceUPnPExternalPortFile ($service));if (((not (defined ($portFile)))or (
$portFile eq ("")))){return ((0x0171+ 5021-0x150e));}(my $TCP_PORT_FD=
main::nxopen ($portFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),
$NXBits::UserReadWrite));if ((not (defined ($TCP_PORT_FD)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::debug (((((((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x73\x65\x74\x45\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x46\x69\x6c\x65\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x27"
.$portFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return (
(0x2128+ 285-0x2245));}main::nxwrite ($TCP_PORT_FD,$serviceUPnPExternalPort{
$service});main::nxclose ($TCP_PORT_FD);if (main::effectiveUserIsAdministrator 
()){Common::NXFile::setOwnershipForUserNX ($portFile);}return (
(0x1228+  44-0x1253));}sub getExternalUPnPPortFromMemory{(my $service=shift (@_)
);if (((not (defined ($service)))or ($service eq ("")))){return (
(0x0116+ 8050-0x2088));}if (($serviceUPnPExternalPort{$service}!=
(0x0016+ 350-0x0174))){return ($serviceUPnPExternalPort{$service});}(my $portFromCfg
=(0x002d+ 9096-0x23b5));if (($service eq $__serviceUpnpnxTcp)){($portFromCfg=
$GLOBAL::NXTCPUPnPPort);}elsif (($service eq $__serviceUpnpnxUdp)){($portFromCfg
=$GLOBAL::NXUDPUPnPPort);}elsif (($service eq $__serviceUpnpssh)){($portFromCfg=
$GLOBAL::SSHUPnPPort);}elsif (($service eq $__serviceUpnphttps)){($portFromCfg=
$GLOBAL::HTTPUPnPPort);}main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");if ((
NXTools::isCorrectPort ($portFromCfg)and ($portFromCfg>=(0x02a7+ 8144-0x2276))))
{__setExternalUPnPPort ($service,$portFromCfg);return ($serviceUPnPExternalPort{
$service});}return ((0x13ed+ 3935-0x234c));}sub getExternalUPnPPort{(my $service
=shift (@_));if ((getExternalUPnPPortFromMemory ($service)==
(0x0b63+ 6893-0x2650))){return (getExternalUPnPPortFromFile ($service));}return 
($serviceUPnPExternalPort{$service});}sub __setExternalUPnPPort{(my $service=
shift (@_));(my $port=shift (@_));main::nxrequire (
"\x4e\x58\x54\x6f\x6f\x6c\x73");if ((($service ne (""))and 
NXTools::isCorrectPort ($port))){($serviceUPnPExternalPort{$service}=$port);
Logger::debug ((((("\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27".
$service).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x20\x27"
).$port)."\x27\x2e"));updateGlobalUPnPPortKey ($service,$port);}return;}sub 
getExternalUPnPPortFromMemoryORFile{(my $service=shift (@_));(my $port=
(0x1cd1+ 1733-0x2396));($port=getExternalUPnPPortFromMemory ($service));if (((
$port ne (""))and ($port>(0x183a+ 638-0x1ab8)))){return ($port);}return (
getExternalUPnPPortFromFile ($service));}sub getExternalUPnPPortFromFile{(my $service
=shift (@_));(my $portFile=getServiceUPnPExternalPortFile ($service));if ((not (
Common::NXFile::isExists ($portFile)))){return ((0x19e0+ 1617-0x2031));}(my $TCP_PORT_FD
=main::nxopen ($portFile,$NXBits::O_RDONLY,(0x0e01+ 1837-0x152e)));if (defined (
$TCP_PORT_FD)){my ($line);main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");while
 (main::nxread ($TCP_PORT_FD,(\$line))){chomp ($line);if ((
NXTools::isCorrectPort ($line)and ($line>=(0x0f56+ 504-0x114d)))){
__setExternalUPnPPort ($service,$line);Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x47\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x70\x6f\x72\x74\x20\x27").$line).
"\x27\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x2e"));main::nxclose ($TCP_PORT_FD
);return ($serviceUPnPExternalPort{$service});}}main::nxclose ($TCP_PORT_FD);}
return ((0x14bf+ 4271-0x256e));}sub isNotAllUpnpGetNetworkInfoInMemory{return ((
!isAllUpnpGetNetworkInfoInMemory ()));}sub isAllUpnpGetNetworkInfoInMemory{if ((
(($LocalIP eq (""))or ($GatewayIP eq ("")))or ($ExternalIP eq ("")))){return (
(0x08ef+ 6439-0x2216));}return ((0x0d34+ 5638-0x2339));}sub 
checkAllNetworkInformationsFromMemory{if ((((($LocalIP ne (""))and ($GatewayIP 
ne ("")))and ($ExternalIP ne ("")))and ($ExternalIP ne 
"\x30\x2e\x30\x2e\x30\x2e\x30"))){return ((0x0cb7+ 3963-0x1c31));}return (
(0x09f0+ 4770-0x1c92));}sub checkNetworkInformationsFromMemory{if (((($LocalIP 
ne (""))or ($GatewayIP ne ("")))or ($ExternalIP ne ("")))){return (
(0x15bf+ 1107-0x1a11));}return ((0x0072+ 1337-0x05ab));}sub getNetworkInfo{(my $gatewayIP
=("\x20" x (0x0a3b+ 4494-0x17e1)));(my $localIP=("\x20" x (0x040c+ 3825-0x0f15))
);(my $externalIP=("\x20" x (0x0ffb+ 4092-0x1c0f)));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $return_code=libnxhs::NXUpnpGetNetworkInfo ($gatewayIP,$localIP,
$externalIP));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20\x27"
.$return_code)."\x27\x2e"));($gatewayIP=~ s/\0// );($localIP=~ s/\0// );(
$externalIP=~ s/\0// );($GatewayIP=main::trimLine ($gatewayIP));($LocalIP=
main::trimLine ($localIP));if (($externalIP ne "\x30\x2e\x30\x2e\x30\x2e\x30")){
($ExternalIP=main::trimLine ($externalIP));}}sub getNetworkInfoBackground{(my $returnFD
=(shift (@_)||(0x0791+ 6166-0x1fa7)));(my $exit_value=(0x21e8+ 559-0x2417));if (
($networkInfostarted==(0x0610+ 3582-0x140d))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x61\x72\x74\x65\x64\x2c\x20\x73\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);return ((0x0c58+ 2318-0x1565));}(my ($NXUPnP_ReadPipe,$NXUPnP_WritePipe)=(""))
;Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x47\x65\x74\x20\x4e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x2e"
);if (main::nxPipeCreateBi ((\$NXUPnP_ReadPipe),(\$NXUPnP_WritePipe))){
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$NXUPnP_ReadPipe)."\x20\x46\x44\x23").$NXUPnP_WritePipe)."\x2e"));}else{(my $error
=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return (
(0x0a56+ 367-0x0bc5));}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28"
.$NXUPnP_WritePipe)."\x29\x20\x73\x74\x61\x72\x74\x2e"));($exit_value=
libnxhs::NXCreateNetworkInfo ($NXUPnP_WritePipe));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x27"
.$exit_value)."\x27\x2e"));if (($exit_value<(0x0a43+ 4877-0x1d50))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x75\x70\x6e\x70\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));
main::nxclose ($NXUPnP_ReadPipe);main::nxclose ($NXUPnP_WritePipe);return (
(0x00f5+ 6932-0x1c09));}NXSystemDaemons::addUPnPFD (
"\x6e\x65\x74\x69\x6e\x66\x6f",$NXUPnP_ReadPipe,$NXUPnP_WritePipe,
(0x01a8+ 5367-0x169f));setNetworkInfoFlag ((0x0f92+ 5289-0x243a));
setNetworkThreadFlag ((0x152f+ 701-0x17eb));if (($returnFD==
(0x1785+ 1020-0x1b80))){return ($NXUPnP_ReadPipe);}return ((0x1a33+ 3248-0x26e2)
);}sub getLocalIPFromMemory{if ((defined ($LocalIP)and ($LocalIP ne ("")))){
return ($LocalIP);}return ((""));}sub getLocalIP{if ((getLocalIPFromMemory ()ne 
(""))){return ($LocalIP);}getNetworkInfo ();if ((defined ($LocalIP)and ($LocalIP
 ne ("")))){return ($LocalIP);}return ((""));}sub generateExternalPort{(my $service
=shift (@_));(my $localIP=(shift (@_)||("")));(my $externalPort=
(0x1c16+ 1176-0x20ae));if (((not (defined ($service)))or ($service eq ("")))){
return ((0x1540+ 4276-0x25f4));}if (((not (defined ($localIP)))or ($localIP eq 
("")))){($localIP=getLocalIP ());}if (($localIP=~ /(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/ )
){(my $ip_3=$3);(my $ip_4=$4);(my $base=($ip_3 %(0x02e0+ 6458-0x1c10)));($base=(
20000+((($ip_4-(0x0fb0+ 3460-0x1d33))*(0x08cc+ 591-0x0af3))+($base *
(0x11fa+ 1558-0x180c)))));if (($service eq $__serviceUpnpnxTcp)){($externalPort=
$base);}elsif (($service eq $__serviceUpnpssh)){($externalPort=($base+
(0x0a8a+ 5595-0x2064)));}elsif (($service eq $__serviceUpnphttps)){(
$externalPort=($base+(0x01ef+ 7969-0x210e)));}elsif (($service eq 
$__serviceUpnpnxUdp)){($externalPort=($base+(0x0f7d+ 1531-0x1575)));}
Logger::debug (((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x45\x78\x74\x65\x72\x6e\x61\x6c\x50\x6f\x72\x74\x3a\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x64\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x3a\x20"
.$externalPort)."\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20").
$service)."\x2e"));return ($externalPort);}Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x45\x78\x74\x65\x72\x6e\x61\x6c\x50\x6f\x72\x74\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$service)."\x2e"));return ((0x0e27+ 4604-0x2023));}sub 
isNotSetServiceUPnPExternalPort{(my $service=shift (@_));if (($service eq ("")))
{return ((0x1322+ 4020-0x22d5));}if ((((not (defined ($serviceUPnPExternalPort{
$service})))or ($serviceUPnPExternalPort{$service}eq ("")))or (
$serviceUPnPExternalPort{$service}==(0x04ad+ 6440-0x1dd5)))){return (
(0x00ab+ 2721-0x0b4b));}return ((0x1369+  68-0x13ad));}sub 
isSetServiceUPnPExternalPort{(my $service=shift (@_));if ((defined (
$serviceUPnPExternalPort{$service})and ($serviceUPnPExternalPort{$service}>
(0x0128+ 8869-0x23cd)))){return ((0x0e48+ 953-0x1200));}return (
(0x0655+ 8180-0x2649));}sub isServiceActive{(my $service=shift (@_));
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x27".
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}).
"\x27\x20\x70\x6f\x72\x74\x20\x27").$serviceUPnPExternalPort{$service}).
"\x27\x2e"));if ((($serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}==
(0x10c7+ 1602-0x1708))and ($serviceUPnPExternalPort{$service}>
(0x0516+ 3863-0x142d)))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4d\x61\x70\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x69\x73\x20\x61\x63\x74\x69\x76\x65\x2e"));return (
(0x011c+ 7277-0x1d88));}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4d\x61\x70\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x63\x74\x69\x76\x65\x2e"));
return ((0x17db+  80-0x182b));}sub isUDPPortAdded{return ($UDPPortAdded);}sub 
setFlagUDPPortAdded{($UDPPortAdded=(0x0e0f+ 6110-0x25ec));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x55\x44\x50\x50\x6f\x72\x74\x41\x64\x64\x65\x64\x27\x20\x66\x6c\x61\x67\x2e"
);return;}sub unSetFlagUDPPortAdded{($UDPPortAdded=(0x18d2+  95-0x1931));
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x73\x65\x74\x20\x27\x55\x44\x50\x50\x6f\x72\x74\x41\x64\x64\x65\x64\x27\x20\x66\x6c\x61\x67\x2e"
);return;}sub setFlagForceStartUPnPMap{(my $value=(shift (@_)||
(0x048d+ 5571-0x1a50)));($forceStartUPnPMap=$value);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x66\x6f\x72\x63\x65\x53\x74\x61\x72\x74\x55\x50\x6e\x50\x4d\x61\x70\x27\x20\x66\x6c\x61\x67\x20\x27"
.$forceStartUPnPMap)."\x27\x2e"));return;}sub setNetworkInfoFlag{(my $value=(
shift (@_)||(0x06aa+ 2541-0x1097)));($networkInfostarted=$value);Logger::debug (
((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x6e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x73\x74\x61\x72\x74\x65\x64\x27\x20\x66\x6c\x61\x67\x20\x27"
.$networkInfostarted)."\x27\x2e"));return;}sub setNetworkThreadFlag{(my $value=(
shift (@_)||(0x06fb+ 4338-0x17ed)));($networkThreadStarted=$value);Logger::debug
 (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x6e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x53\x74\x61\x72\x74\x65\x64\x27\x20\x66\x6c\x61\x67\x20\x27"
.$networkThreadStarted)."\x27\x2e"));return;}sub clearNetworkInfoData{
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x65\x61\x72\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x73\x20\x64\x61\x74\x61\x2e"
);($GatewayIP=(""));($LocalIP=(""));($ExternalIP=(""));return;}sub 
unsetUPnPServices{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x65\x61\x72\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x64\x61\x74\x61\x2e"
);foreach my $service (@UPnPServices){($serviceUPnPStartTime{$service}=
(0x01c8+ 9415-0x268f));($serviceUPnPExternalPort{$service}=(0x0784+ 4872-0x1a8c)
);($serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x09dc+ 2249-0x12a5))
;setServiceUPnPTimeout ($service);}return;}sub handleNetworkChange{
clearNetworkInfoData ();if (((isUPnPMapEnabled ()==(0x0d0d+ 2519-0x16e4))or (
isUPnPEnabled ()==(0x17dc+ 3416-0x2534)))){Logger::debug2 (
"\x53\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x55\x50\x6e\x50\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x69\x67\x6e\x6f\x72\x65\x20\x64\x65\x74\x65\x63\x74\x65\x64\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x63\x68\x61\x6e\x67\x65\x2e"
);return;}destroyNetworkThread ();unsetUPnPServices ();getNetworkInfoBackground 
((0x236f+ 135-0x23f6));($handleNetworkChange=(0x09a1+ 534-0x0bb6));return;}sub 
handleNetworkChangePortsAdd{Logger::debug2 (
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);if (((isUPnPMapEnabled ()==(0x1868+ 2994-0x241a))or (isUPnPEnabled ()==
(0x22bc+ 639-0x253b)))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x75\x70\x70\x6f\x72\x74\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x69\x67\x6e\x6f\x72\x65\x20\x64\x65\x74\x65\x63\x74\x65\x64\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x63\x68\x61\x6e\x67\x65\x2e"
);return;}if ((__setExternalUPnPPortsForAllServicesOnNetworkChange ()==
(0x03eb+ 5471-0x194a))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x65\x73\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x70\x6f\x72\x74\x73\x20\x61\x66\x74\x65\x72\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x63\x68\x61\x6e\x67\x65\x2e"
);informAllNodesAboutUPnPChanges ();return;}deleteServiceRules (
(0x09d5+ 5894-0x20db),$BACKGROUND_MODE);if ((forceAddPortMapping ()==
(0x0f43+ 5070-0x2311))){informAllNodesAboutUPnPChanges ();}return;}sub 
readOnCallbackFD{(my $f=shift (@_));(my $read_buf=(""));(my $bytes_read=
main::nxread ($f,(\$read_buf),(0x1c2d+ 3901-0x1b6a)));if ((not (defined (
$bytes_read)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());if (((
$errorname eq "\x45\x41\x47\x41\x49\x4e")or ($errorname eq 
"\x45\x49\x4e\x54\x52"))){Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23".
$f)."\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20").$errorname).
"\x2c\x20").$errorstring)."\x2e"));}}elsif (($bytes_read==(0x1401+ 3120-0x2031))
){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x46\x44\x23"
.$f)."\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));}else{Logger::debug ((
((("\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x27".$read_buf).
"\x27\x20\x6f\x6e\x20\x46\x44\x23").$f)."\x2e"));}return ($bytes_read,$read_buf)
;}sub checkIfInformNodeAboutUPnPChanges{(my $sessionID=shift (@_));(my $upnpStatusMessage
=buildStatusMessageForClient ());(my $message=((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_STATUS_TO_NXCLIENT)."\x20").$upnpStatusMessage));
NXLocalSession::informNodeAboutUPnPChanges ($sessionID,$message);return;}sub 
delSessionUdpPort{(my $udpPort=__getSessionPort ());if ((((not (defined (
$udpPort)))or ($udpPort eq ("")))or ($udpPort<(0x0e0d+ 6241-0x266e)))){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x55\x44\x50\x20\x70\x6f\x72\x74\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"
);return;}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x27\x73\x20\x55\x44\x50\x20\x70\x6f\x72\x74\x20\x27"
.$udpPort)."\x27\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x2e"));if (isUDPPortAdded 
()){if ((not (NXClientSystemDaemons::openConnection ()))){deleteRule (
"\x55\x44\x50",$udpPort);main::nxrequire (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");NXUdpControl::freePort (
$udpPort);}else{NXClientSystemDaemons::sendMessage ((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_DELETE)."\x20\x70\x6f\x72\x74\x3d").$udpPort)."\x0a"));
NXClientSystemDaemons::closeConnection ();}unSetFlagUDPPortAdded ();}return;}sub
 informAllNodesAboutUPnPChanges{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x66\x6f\x72\x6d\x20\x6e\x6f\x64\x65\x73\x20\x61\x62\x6f\x75\x74\x20\x63\x68\x61\x6e\x67\x65\x73\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32");(my (@sessions)=
NXSession2::getListOfSessionsForServerStatusNotify ());Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x46\x6f\x75\x6e\x64\x20\x27".scalar (@sessions
)).(("\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x5b\x73\x5d\x3a\x20".join ($",
@sessions))."\x2e")));if ((scalar (@sessions)!=(0x0674+ 3656-0x14bc))){(my $upnpStatusMessage
=buildStatusMessageForClient ());(my $message=((
$GLOBAL::MSG_UPNP_STATUS_TO_NXCLIENT."\x20").$upnpStatusMessage));while (scalar 
(@sessions)){(my $sessionId=shift (@sessions));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x74\x68\x65\x20\x75\x70\x6e\x70\x20\x73\x74\x61\x74\x75\x73\x20\x74\x6f\x20\x74\x68\x65\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20"
.$sessionId)."\x2e"));main::send_command_to_server ($sessionId,$message);}}}sub 
handleUPnPSingleServiceMessage{(my $clientSocket=shift (@_));(my $message=shift 
(@_));(my $service=(""));(my $port=(""));if (($message=~ /service=(.*) port=(\d+)$/ )
){($service=$1);($port=$2);}else{Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));return ((0x20ea+ 726-0x23c0));}Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x69\x6e\x67\x6c\x65\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);if ((not (isServiceEnabled ($service)))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27"
.$service).
"\x27\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x2c\x20\x66\x69\x6e\x69\x73\x68\x69\x6e\x67\x2e"
));(my $msg=buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);
return ((0x126f+ 1113-0x16c8));}updateCFGKeys ($service,$port);if ((
checkAllNetworkInformationsFromMemory ()==(0x0388+ 8999-0x26af))){
getNetworkInfoBackground ((0x1b02+ 1971-0x22b5));}getExternalUPnPPort ($service)
;if (isNotSetServiceUPnPExternalPort ($service)){setExternalTCPPortFile (
$service);if (isNotSetServiceUPnPExternalPort ($service)){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x69\x73\x4e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x55\x50\x6e\x50\x45\x78\x74\x65\x72\x6e\x61\x6c\x50\x6f\x72\x74\x20\x66\x6f\x72\x20\x27"
.$service)."\x27\x2c\x20\x66\x69\x6e\x69\x73\x68\x69\x6e\x67\x2e"));(my $msg=
buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);return (
(0x0624+ 2291-0x0f17));}}(my $iPort=getServiceUPnPPort ($service));(my $ePort=
$serviceUPnPExternalPort{$service});Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x47\x6f\x74\x20\x69\x50\x6f\x72\x74\x3a\x20\x27"
.$iPort)."\x27\x2c\x20\x65\x50\x6f\x72\x74\x3a\x20\x27").$ePort)."\x27\x2e"));(my $upnpFD
=(0x1c6d+ 633-0x1ee6));(my $type=(""));if ((($ePort ne (""))and ($ePort ne (""))
)){if (isTCPService ($service)){($upnpFD=deletePortMappingBackground ($iPort,
$ePort,"\x54\x43\x50"));}else{($upnpFD=deletePortMappingBackground ($iPort,
$ePort,"\x55\x44\x50"));}($type="\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");
}if (($port>(0x031a+ 2770-0x0dec))){if ((defined ($iPort)and ($iPort ne ("")))){
if (isTCPService ($service)){($upnpFD=__addTCPRule ($iPort,$port,
$BACKGROUND_MODE));}else{($upnpFD=__addUDPRule ($iPort,$port,$BACKGROUND_MODE));
}($type="\x61\x64\x64\x70\x6f\x72\x74\x73");__setExternalUPnPPort ($service,
$port);}}else{($flagInformAllNodesAboutUPnPChanges=(0x0a14+ 5498-0x1f8d));(
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x1448+ 3293-0x2125));}
if (($upnpFD>(0x06d1+ 6191-0x1f00))){addSocketToClientList ($clientSocket,
$upnpFD,$type);return ((0x0127+ 8603-0x22c1));}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6f\x6e\x6c\x79\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x73\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);(my $msg=buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);
return ((0x0f68+ 1706-0x1612));}}sub updateCFGKeys{(my $service=shift (@_));(my $port
=shift (@_));(my $cfgKeyName=getCFGKeyGatewayPortBasedOnService ($service));(my $cfgEnableUPnPKeyValue
=getEnableUPnPKeyValueBasedOnService ($service));updateGlobalUPnPPortKey (
$service,$port);if (($port>(0x1acf+ 2809-0x25c8))){(my $error=(""));if (((
$cfgKeyName ne (""))and main::changeServerCfgKeySetError ($cfgKeyName,$port,(
\$error)))){Logger::debug2 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x75\x70\x64\x61\x74\x65\x43\x46\x47\x4b\x65\x79\x73\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x63\x66\x67\x2e"
);}else{Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x75\x70\x64\x61\x74\x65\x43\x46\x47\x4b\x65\x79\x73\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x75\x70\x64\x61\x74\x65\x20\x27"
.$cfgKeyName).
"\x27\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x3a\x20"
).$error)."\x2e"));}addServiceToKeyEnableUPnP ($cfgEnableUPnPKeyValue);}else{
removeServiceFromKeyEnableUPnP ($cfgEnableUPnPKeyValue);}if ((not (
main::changeServerCfgKeySetError ($__cfgEnableUPnPKeyName,$GLOBAL::EnableUPnP,(
\$error))))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x75\x70\x64\x61\x74\x65\x43\x46\x47\x4b\x65\x79\x73\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x75\x70\x64\x61\x74\x65\x20\x27"
.$__cfgEnableUPnPKeyName).
"\x27\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x3a\x20"
).$error)."\x2e"));}return ((0x040c+ 8024-0x2363));}sub 
addServiceToKeyEnableUPnP{(my $service=shift (@_));Logger::debug (((((
"\x41\x64\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27".$service).
"\x27\x20\x74\x6f\x20\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x20\x6b\x65\x79\x3a\x20\x27"
).$GLOBAL::EnableUPnP)."\x27\x2e"));if (isUPnPEnabled ()){if ((not ((
$GLOBAL::EnableUPnP=~ /$service/ )))){($GLOBAL::EnableUPnP.=("\x2c".$service));}
}else{($GLOBAL::EnableUPnP=$service);}Logger::debug (((
"\x55\x70\x64\x61\x74\x65\x64\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x27\x20\x6b\x65\x79\x20\x74\x6f\x3a\x20\x27"
.$GLOBAL::EnableUPnP)."\x27\x2e"));return;}sub removeServiceFromKeyEnableUPnP{(my $service
=shift (@_));Logger::debug ((((("\x52\x65\x6d\x6f\x76\x65\x20\x27".$service).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x66\x72\x6f\x6d\x20\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x20\x6b\x65\x79\x3a\x20\x27"
).$GLOBAL::EnableUPnP)."\x27\x2e"));if (isUPnPEnabled ()){if ((
$GLOBAL::EnableUPnP=~ /,$service/ )){($GLOBAL::EnableUPnP=~ s/,$service// );}
elsif (($GLOBAL::EnableUPnP=~ /$service,/ )){($GLOBAL::EnableUPnP=~ s/$service,// )
;}elsif (($GLOBAL::EnableUPnP=~ /$service/ )){($GLOBAL::EnableUPnP=~ s/$service// )
;}if (($GLOBAL::EnableUPnP eq (""))){($GLOBAL::EnableUPnP="\x6e\x6f\x6e\x65");}}
else{($GLOBAL::EnableUPnP="\x6e\x6f\x6e\x65");}Logger::debug (((
"\x55\x70\x64\x61\x74\x65\x64\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x27\x20\x6b\x65\x79\x20\x74\x6f\x3a\x20\x27"
.$GLOBAL::EnableUPnP)."\x27\x2e"));return;}sub isServiceEnabled{(my $service=
shift (@_));if (((not (defined ($service)))or ($service eq ("")))){return (
(0x0a15+ 4574-0x1bf3));}if ((($service eq $__serviceUpnpnxTcp)and 
NXSystemDaemons::isNxdEnabled ())){return ((0x1abf+ 2401-0x241f));}elsif (((
$service eq $__serviceUpnpnxUdp)and NXSystemDaemons::isNxdEnabled ())){return (
(0x0d79+ 3910-0x1cbe));}elsif ((($service eq $__serviceUpnphttps)and 
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ())){return (
(0x0ead+ 3608-0x1cc4));}elsif ((($service eq $__serviceUpnpssh)and 
NXSystemDaemons::isSSHEnabled ())){if (-x ($GLOBAL::CommandNXSSHD)){return (
(0x0631+ 6845-0x20ed));}}return ((0x01c3+ 8059-0x213e));}sub 
getCFGKeyGatewayPortBasedOnService{(my $service=shift (@_));if (($service eq 
$__serviceUpnpnxTcp)){return ($__cfgNXTCPKeyValue);}elsif (($service eq 
$__serviceUpnpnxUdp)){return ($__cfgNXUDPKeyValue);}elsif (($service eq 
$__serviceUpnphttps)){return ($__cfgHTTPKeyName);}elsif (($service eq 
$__serviceUpnpssh)){return ($__cfgSSHDKeyName);}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27".$service)
."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));return ((""));
}sub getEnableUPnPKeyValueBasedOnService{(my $service=shift (@_));if (($service 
eq $__serviceUpnpnxTcp)){return ($__cfgNXTCPKeyValue);}elsif (($service eq 
$__serviceUpnpnxUdp)){return ($__cfgNXUDPKeyValue);}elsif (($service eq 
$__serviceUpnphttps)){return ($__cfgHTTPKeyValue);}elsif (($service eq 
$__serviceUpnpssh)){return ($__cfgSSHDKeyValue);}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27".
$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));
return ((""));}sub updateGlobalUPnPPortKey{(my $service=shift (@_));(my $port=
shift (@_));if (($service eq $__serviceUpnpnxTcp)){($GLOBAL::NXTCPUPnPPort=$port
);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x4e\x58\x54\x43\x50\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::NXTCPUPnPPort)."\x27\x2e"));}elsif (($service eq $__serviceUpnpnxUdp))
{($GLOBAL::NXUDPUPnPPort=$port);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x4e\x58\x55\x44\x50\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::NXUDPUPnPPort)."\x27\x2e"));}elsif (($service eq $__serviceUpnphttps))
{($GLOBAL::HTTPUPnPPort=$port);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x48\x54\x54\x50\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::HTTPUPnPPort)."\x27\x2e"));}elsif (($service eq $__serviceUpnpssh)){(
$GLOBAL::SSHUPnPPort=$port);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x53\x53\x48\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::SSHUPnPPort)."\x27\x2e"));}else{Logger::warning (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x75\x70\x64\x61\x74\x65\x20\x55\x50\x6e\x50\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x6d\x65\x6d\x6f\x72\x79\x2e\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));
return ((0x0632+ 5135-0x1a41));}}sub updateCFGandPortMapping{(my $service=shift 
(@_));(my $port=shift (@_));if ((not (NXClientSystemDaemons::openConnection ()))
){updateCFGKeys ($service,$port);__sendMsgOnSocket (main::nxgetSTDOUT (),
getStatusMessage ());return ((0x12f3+ 148-0x1387));}
NXClientSystemDaemons::cleanDaemonBuffer ();(my $message=((((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_UPNP_MAPPING_SERVICE).
"\x20\x73\x65\x72\x76\x69\x63\x65\x3d").$service)."\x20\x70\x6f\x72\x74\x3d").
$port)."\x0a"));if ((NXClientSystemDaemons::sendMessage ($message)!=
(0x01e6+ 2118-0x0a2b))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x27"
.$message).
"\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
));__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());}(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));
NXClientSystemDaemons::closeConnection ();if ((defined ($reply)and ($reply ne 
("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}else{__sendMsgOnSocket (
main::nxgetSTDOUT (),getStatusMessage ());}return ((0x0651+ 4823-0x1927));}sub 
convertNXplayerServiceNameIntoUPnPServiceName{(my $service=shift (@_));if ((
$service=~ /^$__nxTcpName$/ )){return ($__serviceUpnpnxTcp);}elsif (($service=~ /^$__nxUdpName$/ )
){return ($__serviceUpnpnxUdp);}elsif (($service=~ /^$__nxhtdName$/ )){return (
$__serviceUpnphttps);}elsif (($service=~ /^$__nxsshdName$/ )){return (
$__serviceUpnpssh);}Logger::debug2 (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));
return ((""));}sub __setSessionPort{($sessionPort=shift (@_));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x55\x50\x6e\x50\x20\x70\x6f\x72\x74\x20\x27"
.$sessionPort)."\x27\x2e"));}sub __getSessionPort{return ($sessionPort);}sub 
__checkInitializeStatusAndAdjustTimeout{(my $portMappingAdded=(shift (@_)||
(0x08c2+ 7000-0x241a)));(my $protocol=shift (@_));if ((__isRepeatMappingStarted 
()==(0x06bf+ 2845-0x11db))){if (($portMappingAdded==(0x1a09+ 1810-0x211b))){
__setTimeoutForRepeatMapping ();}else{__disableRepeatMapping (
(0x039b+ 6561-0x1d3c));}}}sub __setTimeoutForRepeatMapping{if ((
$protocolsCountForRepeatMapping>=(0x0528+ 2769-0x0ff7))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x72\x65\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);($protocolsCountForRepeatMapping=(0x028a+ 509-0x0486));return;}(my $timeout=
shift (@timeoutForRepeatMapping));if (((not (defined ($timeout)))or ($timeout eq
 ("")))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x63\x68\x65\x64\x20\x72\x65\x70\x65\x61\x74\x20\x6c\x69\x6d\x69\x74\x2e"
);__disableRepeatMapping ((0x1ca0+ 2320-0x25af));return;}foreach my $lookup_value
 (@allPossibleTimeoutForRepeat){if (($timeout==$lookup_value)){($NXUpnp::timeout
=$timeout);__calculateCountForRepeatMapping ();Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x72\x65\x70\x65\x61\x74\x20\x70\x6f\x72\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x3a\x20\x27"
.$NXUpnp::timeout)."\x27\x2e"));return;}}Logger::warning (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x63\x6f\x72\x65\x63\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x76\x61\x6c\x75\x65\x2e"
);__disableRepeatMapping ((0x00f8+ 2154-0x0961));return;}sub 
__disableRepeatMapping{(my $force=(shift (@_)||(0x0739+ 2977-0x12da)));
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x20\x72\x65\x70\x65\x61\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x6f\x6e\x20\x73\x74\x61\x72\x74\x75\x70\x2e"
);if (((__isRepeatMappingStarted ()==(0x1325+ 4856-0x261c))or ($force==
(0x0072+ 6094-0x183f)))){__setRepeatMapping ($repeatMappingDisabled);}if (((
$timeout!=$defaultTimeout)or ($force==(0x0706+ 4923-0x1a40)))){
__setDefaultTimeout ();}($protocolsCountForRepeatMapping=(0x0a9b+ 5831-0x2162));
return;}sub __setDefaultTimeout{($timeout=$defaultTimeout);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x73\x74\x6f\x72\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x74\x6f\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$timeout)."\x27\x2e"));return;}sub __setRepeatMapping{($repeatMapping=shift (@_
));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x72\x65\x70\x65\x61\x74\x4d\x61\x70\x70\x69\x6e\x67\x27\x20\x66\x6c\x61\x67\x20\x27"
.$repeatMapping)."\x27\x2e"));return;}sub __isRepeatMappingStarted{if ((
$repeatMapping==$repeatMappingStarted)){return ((0x174d+ 3248-0x23fc));}return (
(0x0198+ 4342-0x128e));}sub __calculateCountForRepeatMapping{(my $oldValue=
$protocolsCountForRepeatMapping);($protocolsCountForRepeatMapping=
(0x137a+ 3831-0x2271));if (($GLOBAL::EnableUPnP=~ /(NXTCP|SSH|HTTP)/i )){(++
$protocolsCountForRepeatMapping);}if (($GLOBAL::EnableUPnP=~ /(NXUDP)/i )){(++
$protocolsCountForRepeatMapping);}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x73\x43\x6f\x75\x6e\x74\x46\x6f\x72\x52\x65\x70\x65\x61\x74\x4d\x61\x70\x70\x69\x6e\x67\x27\x20\x66\x6c\x61\x67\x20\x27"
.$protocolsCountForRepeatMapping)."\x27\x2e"));return;}sub 
isRepeatMappingInProgress{if ((isUPnPMapEnabled ()and isUPnPEnabled ())){if ((
__isRepeatMappingStarted ()==(0x0b8f+ 670-0x0e2c))){foreach my $lookup_value (
@allPossibleTimeoutForRepeat){if (($timeout==$lookup_value)){return (
(0x04a2+ 1993-0x0c6a));}}}}return ((0x0c24+ 3785-0x1aed));}sub 
getTimeoutForRepeatMapping{(my $newTime=($timeout *(0x056d+ 7669-0x1f7a)));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x65\x77\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20\x27"
.$newTime)."\x27\x2e"));return ($newTime);}"\x3f\x3f\x3f";
