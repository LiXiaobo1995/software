############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package KeysManager;no warnings;(my $__maxRotatedFiles=(0x1bcd+ 1013-0x1fbc));
sub __getBackupFileName{(my $name=shift (@_));($name.=
"\x2e\x62\x61\x63\x6b\x75\x70");if ((not (Common::NXFile::fileExists ($name)))){
return ($name);}(my $number=(0x02f3+ 9040-0x2641));while (($number<=
$__maxRotatedFiles)){if ((not (Common::NXFile::fileExists (($name.$number))))){
return (($name.$number));}($number+=(0x0427+ 1395-0x0999));}($number=
(0x0a38+ 6803-0x24ca));(my $oldestFile=$name);(my $oldestCTime=
Common::NXCore::NXFileCTime ($name));while (($number<=$__maxRotatedFiles)){(my $cTime
=Common::NXCore::NXFileCTime (($name.$number)));if (($oldestCTime>$cTime)){(
$oldestFile=($name.$number));($oldestCTime=$cTime);}($number+=
(0x0b44+ 6020-0x22c7));}return ($oldestFile);}sub __backupKey{(my $file=shift (
@_));(my $backup=__getBackupFileName ($file));if (Common::NXFile::fileExists (
$file)){(my ($ret,$error)=Common::NXCore::copyFile ($file,$backup));if (($error 
ne (""))){Logger::warning ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x08e0+ 6978-0x2421));}else{
Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX ($backup);}}return (
(0x021a+ 1502-0x07f8));}sub __createRestore{(my $file=shift (@_));if ((not (
Common::NXFile::isExists ($file)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x66\x69\x6c\x65\x2e\x20"
.$file)."\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
return ((0x186f+ 2801-0x2360));}(my $restore=($file.
"\x2e\x72\x65\x73\x74\x6f\x72\x65"));if (Common::NXFile::isExists ($restore)){
Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x66\x69\x6c\x65\x2e\x20"
.$restore)."\x20\x65\x78\x69\x73\x74\x73\x2e"));return ((0x0050+ 3723-0x0edb));}
if (Common::NXFile::fileExists ($file)){(my ($ret,$error)=
Common::NXCore::copyFile ($file,$restore));if (($error ne (""))){Logger::warning
 ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x101d+ 3540-0x1df0));}else{
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($restore);}}return
 ((0x0f02+ 2361-0x183b));}sub __createDefault{(my $file=shift (@_));(my $default
=shift (@_));if (Common::NXFile::fileExists ($default)){return (
(0x03f0+ 8514-0x2532));}if (Common::NXFile::fileExists ($file)){(my ($ret,$error
)=Common::NXCore::copyFile ($file,$default));if (($error ne (""))){
Logger::warning ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x0bdf+ 3255-0x1895));}else{
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($default);}}return
 ((0x0905+ 4768-0x1ba5));}sub backup{if ((__backupKey (
NXPaths::getNodePublicKeys ())==(0x0486+ 2930-0x0ff7))){return (
(0x0a12+ 588-0x0c5d));}if ((__backupKey (NXPaths::getUserDefaultRSAPublicKeyPath
 ())==(0x08eb+ 2231-0x11a1))){return ((0x13e8+ 3529-0x21b0));}if ((__backupKey (
NXPaths::getClientRSAPrivateKey ())==(0x0895+ 3950-0x1802))){return (
(0x0d39+ 985-0x1111));}if ((__backupKey (NXPaths::getClientRSADefaultPrivateKey 
())==(0x05e2+ 3726-0x146f))){return ((0x1411+ 1633-0x1a71));}if ((__backupKey (
NXPaths::getClientDSADefaultPrivateKey ())==(0x0cdb+ 3567-0x1ac9))){return (
(0x024b+ 3123-0x0e7d));}if ((__createRestore (NXPaths::getClientRSAPrivateKey ()
)==(0x0236+ 1815-0x094c))){return ((0x0bf4+ 4886-0x1f09));}return (
(0x1ab0+ 277-0x1bc5));}sub __generateRSAKeys{(my $public=
NXPaths::getUserNewRSAPublicKey ());(my $private=
NXPaths::getUserNewRSAPrivateKey ());return (__generateKeys ($public,$private,
"\x72\x73\x61"));}sub __generateKeys{(my $publicKeyFileName=shift (@_));(my $privateKeyFileName
=shift (@_));(my $algorithm=shift (@_));(my (@command)=());(my (@options)=());(
@command=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);push (@command,"\x2d\x6b"
,$privateKeyFileName,"\x2d\x74",$algorithm,"\x2d\x70",$publicKeyFileName);push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".NXPaths::getUserNXHomeDir ()));(my ($cmdErr,$cmdOut,
$exitValue)=main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x0a9f+ 1304-0x0fb7))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20".$algorithm).
"\x20\x6b\x65\x79\x20").$exitValue).
"\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exitValue);}sub __getKeysFromFile{(my $keyFile=shift (@_));if ((not
 (Common::NXFile::isExists ($keyFile)))){return (undef);}(my (@keyLists)=());(my $fileFH
=Common::NXCore::nxopen ($keyFile,$NXBits::O_RDONLY,(0x17c7+ 1670-0x1e4d)));if (
(not (defined ($fileFH)))){(my $error=libnxh::NXGetErrorName ());Logger::error (
((("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$keyFile)."\x27\x3a\x20").$error));return (undef);}while (
Common::NXCore::nxreadLine ($fileFH,(\$_))){($_=~ s/\r//g );chomp ($_);push (
@keyLists,$_);}Common::NXCore::nxclose ($fileFH);return (@keyLists);}sub 
__addPrefix{(my $file=shift (@_));(my (@keys)=__getKeysFromFile ($file));if ((
not (defined (@keys)))){return ((0x004a+ 3397-0x0d8e));}(my $fh=
Common::NXCore::nxopen ($file,$NXBits::O_WRONLY,(0x0f0b+ 1532-0x1507)));if ((not
 (defined ($fh)))){(my $error=libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".$file).
"\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x2e\x20").$error)."\x2e"));return (
(0x14bb+ 3951-0x2429));}foreach my $key (@keys){($key=__getKeyWithPrefix ($key))
;if ((Common::NXCore::nxwrite ($fh,$key)==(-(0x04e1+ 2236-0x0d9c)))){(my $error=
libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.$file)."\x3a\x20").$error)."\x2e"));Common::NXCore::nxclose ($fh);return (
(0x1217+ 3871-0x2135));}}Common::NXCore::nxclose ($fh);return (
(0x1ca4+  39-0x1ccb));}sub __getKeyWithPrefix{(my $key=shift (@_));chomp ($key);
chomp ($key);(my $keyWithPrefix.=
"\x6e\x6f\x2d\x70\x6f\x72\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c");
(my $path=NXPaths::getServerLaunchPath ());($keyWithPrefix.=((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x22\x63\x6d\x64\x2e\x65\x78\x65\x20\x2f\x43\x20\x5c\x22"
.$path)."\x5c\x22\x20\x2d\x2d\x6c\x6f\x67\x69\x6e\x22\x20"));($keyWithPrefix.=
$key);($keyWithPrefix.="\x0a");return ($keyWithPrefix);}sub generate{if (
isRSASuportedByServerConfig ()){if ((__generateRSAKeys ()>(0x2366+ 304-0x2496)))
{return ((0x1342+ 1049-0x175a));}if ((__addPrefix (
NXPaths::getUserNewRSAPublicKey ())==(0x0c40+ 2092-0x146b))){return (
(0x0d7f+ 6402-0x2680));}}return ((0x11e3+ 2764-0x1caf));}sub 
__changeRSAPublicKey{(my $file=NXPaths::getNodePublicKeys ());(my $oldKey=
NXPaths::getUserDefaultRSAPublicKeyPath ());if (Common::NXFile::isExists (
$oldKey)){if ((__removePublicKey ($file,$oldKey)==(0x18eb+ 3584-0x26ea))){return
 ((0x084d+ 6168-0x2064));}}(my $newKey=NXPaths::getUserNewRSAPublicKey ());if ((
__addPublicKey ($file,$newKey)==(0x1c2d+ 509-0x1e29))){return (
(0x08b2+ 2484-0x1265));}if ((__moveKey ($newKey,$oldKey)==(0x1671+ 3282-0x2342))
){return ((0x0f89+ 5484-0x24f4));}return ((0x0be9+ 4964-0x1f4d));}sub 
__removePublicKey{(my $file=shift (@_));(my $oldKeyFile=shift (@_));(my (
@oldKeys)=__getKeysFromFile ($oldKeyFile));if ((not (defined (@oldKeys)))){
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6f\x6c\x64\x20\x6b\x65\x79\x73\x20\x66\x6f\x72\x6d\x20\x66\x69\x6c\x65\x20"
.$oldKeyFile)."\x2e"));return ((0x070c+ 1229-0x0bd8));}(my (@oldKeys)=
__getKeysFromFile ($oldKeyFile));foreach my $key (@oldKeys){__removePrefix ((
\$key));}foreach my $key (@oldKeys){if ((removeKeyFromFile ($key,$file,
"\x53\x53\x48")==(0x1222+ 980-0x15f5))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x6f\x6c\x64\x20\x6b\x65\x79\x20\x66\x6f\x72\x6d\x20\x66\x69\x6c\x65\x20"
.$file)."\x2e"));return ((0x10a7+ 916-0x143a));}}return ((0x0bb1+ 3105-0x17d2));
}sub __removePrefix{(my $ref_key=shift (@_));if (($$ref_key=~ /(.*) (ssh-.*) (.*)/ )
){(my $type=$2);(my $value=$3);Logger::debug (((
"\x52\x65\x6d\x6f\x76\x65\x64\x20\x70\x72\x65\x66\x69\x78\x3a\x20".$1)."\x2e"));
($$ref_key=(($type."\x20").$value));}}sub __addPublicKey{(my $file=shift (@_));(my $newKeyFile
=shift (@_));(my (@newKeys)=__getKeysFromFile ($newKeyFile));if ((not (defined (
@newKeys)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x65\x77\x20\x6b\x65\x79\x73\x20\x66\x6f\x72\x6d\x20\x66\x69\x6c\x65\x20"
.$newKeyFile)."\x2e"));return ((0x0876+ 820-0x0ba9));}(my $fh=
Common::NXCore::nxopen ($file,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+
$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined ($fh)))){(my $error
=libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".$file).
"\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x2e\x20").$error)."\x2e"));return (
(0x08ed+ 673-0x0b8d));}foreach my $key (@newKeys){if ((Common::NXCore::nxwrite (
$fh,($key."\x0a"))==(-(0x07ac+ 6824-0x2253)))){(my $error=libnxh::NXGetErrorName
 ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.$file)."\x3a\x20").$error)."\x2e"));Common::NXCore::nxclose ($fh);return (
(0x133f+ 4267-0x23e9));}}Common::NXCore::nxclose ($fh);if ((
Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX ($file)==(-
(0x0c36+ 5474-0x2197)))){return ((0x1eca+ 284-0x1fe5));}return (
(0x0234+ 8779-0x247f));}sub __changeRSAPrivateKey{(my $newFile=
NXPaths::getUserNewRSAPrivateKey ());(my $clientFile=
NXPaths::getClientRSAPrivateKey ());if ((__moveKey ($newFile,$clientFile)==
(0x0ad6+ 2696-0x155d))){return ((0x0ad9+ 850-0x0e2a));}return (
(0x0953+ 1212-0x0e0f));}sub __moveKey{(my $from=shift (@_));(my $to=shift (@_));
if (Common::NXFile::fileExists ($from)){if ((Common::NXCore::moveFile ($from,$to
)==(0x0482+ 4790-0x1738))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6f\x76\x65\x20\x6b\x65\x79\x20\x66\x69\x6c\x65\x2e"
);return ((0x0fcb+ 2109-0x1807));}}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20".$from).
"\x2e\x20\x46\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
));return ((0x07d8+ 1060-0x0bfb));}return ((0x02b1+ 4062-0x128f));}sub __copyKey
{(my $from=shift (@_));(my $to=shift (@_));if (Common::NXFile::fileExists ($from
)){(my ($ret,$error)=Common::NXCore::copyFile ($from,$to));if (($error ne ("")))
{Logger::warning ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x73\x73\x68\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x104c+ 3704-0x1ec3));}else{if ((
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($to)==(-
(0x1441+ 1205-0x18f5)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x20"
.$to)."\x2e"));return ((0x046f+ 4112-0x147e));}}}else{Logger::warning (((
"\x53\x6f\x75\x72\x63\x65\x20\x6b\x65\x79\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x20"
.$from)."\x2e"));return ((0x141a+ 4230-0x249f));}return ((0x0fac+ 3973-0x1f31));
}sub change{if (isRSASuportedByServerConfig ()){if ((__changeRSAPublicKey ()==
(0x0480+ 6946-0x1fa1))){return ((0x15f9+ 1987-0x1dbb));}if ((
__changeRSAPrivateKey ()==(0x05ec+ 5434-0x1b25))){return ((0x0cf3+ 700-0x0fae));
}}return ((0x173f+ 1176-0x1bd7));}sub __restoreRSAPublicKey{(my $file=
NXPaths::getNodePublicKeys ());(my $oldKey=
NXPaths::getUserDefaultRSAPublicKeyPath ());if (Common::NXFile::isExists (
$oldKey)){if ((__removePublicKey ($file,$oldKey)==(0x1d2f+ 114-0x1da0))){return 
((0x0378+ 1397-0x08ec));}}(my $newKey=NXPaths::getRestoreRSAPublicKey ());if ((
__addPublicKey ($file,$newKey)==(0x16d9+ 2650-0x2132))){return (
(0x1aff+ 1477-0x20c3));}if ((__copyKey ($newKey,$oldKey)==(0x0b95+ 5239-0x200b))
){return ((0x1153+ 3234-0x1df4));}return ((0x0e40+ 522-0x104a));}sub 
__restoreRSAPrivateKey{(my $restoreKey=NXPaths::getClientRSARestorePrivateKey ()
);(my $clientKey=NXPaths::getClientRSAPrivateKey ());if ((__copyKey ($restoreKey
,$clientKey)==(0x01e6+ 2009-0x09be))){return ((0x1cd4+ 1523-0x22c6));}return (
(0x225c+ 340-0x23b0));}sub restore{if (isRSASuportedByServerConfig ()){if ((
__restoreRSAPublicKey ()==(0x0f70+ 4241-0x2000))){return ((0x16da+ 1572-0x1cfd))
;}if ((__restoreRSAPrivateKey ()==(0x1877+ 782-0x1b84))){return (
(0x118d+ 1527-0x1783));}}return ((0x0397+ 4964-0x16fb));}sub __isKeyInLine{(my $key
=shift (@_));(my $line=shift (@_));(my $protocol=shift (@_));($key=~ s/\r//g );(
$key=~ s/\n//g );chomp ($key);(my ($keyType,$keyValue)=split ( / / ,$key,
(0x0f4b+ 5167-0x2377)));($line=~ s/\r//g );($line=~ s/\n//g );chomp ($line);(my (
@lineFields)=split ( / / ,$line,(0x0a72+ 5044-0x1e26)));if (($protocol eq 
"\x53\x53\x48")){if ((($keyType eq $lineFields[(0x1919+ 2722-0x23b7)])and (
$keyValue eq $lineFields[(0x08d1+ 5144-0x1ce4)]))){Logger::debug (((
"\x4b\x65\x79\x20\x27".$key).
"\x27\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
));return ((0x21df+ 719-0x24ad));}}else{if ((($keyType eq $lineFields[
(0x0a00+ 3556-0x17e4)])and ($keyValue eq $lineFields[(0x0278+ 8594-0x2409)]))){
Logger::debug ((("\x4b\x65\x79\x20\x27".$key).
"\x27\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
));return ((0x01b4+ 8606-0x2351));}}return ((0x051f+ 6552-0x1eb7));}sub 
__isAnyKeyInLine{(my $line=shift (@_));(my $protocol=shift (@_));($line=~ s/\r//g )
;($line=~ s/\n//g );chomp ($line);(my (@lineFields)=split ( / / ,$line,
(0x195c+ 588-0x1ba8)));if (($protocol eq "\x53\x53\x48")){if ((($lineFields[
(0x0045+ 7868-0x1efd)]ne (""))and ($lineFields[(0x0b2f+ 3408-0x187a)]ne ("")))){
Logger::debug (
"\x4b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e");
return ((0x0b7d+ 4688-0x1dcc));}}else{if ((($lineFields[(0x0206+ 824-0x053e)]ne 
(""))and ($lineFields[(0x0a5c+ 1197-0x0f08)]ne ("")))){Logger::debug (
"\x4b\x65\x79\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
);return ((0x0ab3+ 5080-0x1e8a));}}return ((0x00ea+ 4507-0x1285));}sub 
removeKeyFromFile{(my $keyToRemove=shift (@_));(my $filePath=shift (@_));(my $protocol
=shift (@_));(my $tempFilePath=(($filePath."\x2e\x74\x6d\x70\x2e").$ $));
 (my $fileFH
=Common::NXCore::nxopen ($filePath,$NXBits::O_RDONLY,(0x06c0+ 6345-0x1f89)));if 
((not (defined ($fileFH)))){(my $error=libnxh::NXGetErrorName ());Logger::error 
(((("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$filePath)."\x27\x3a\x20").$error));return ((0x1ca1+  31-0x1cbf));}(my $tempFileFH
=Common::NXCore::nxopen ($tempFilePath,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+
$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined ($tempFileFH)))){(my $error
=libnxh::NXGetErrorName ());Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x74\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x66\x69\x6c\x65\x20\x27"
.$tempFilePath)."\x27\x3a\x20").$error));return ((0x0364+ 2711-0x0dfa));}while (
Common::NXCore::nxreadLine ($fileFH,(\$_))){(my $line=$_);if (__isKeyInLine (
$keyToRemove,$line,$protocol)){Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x6b\x65\x79\x20\x27".$line)."\x27\x2e"));}
else{Common::NXCore::nxwrite ($tempFileFH,$line);}}Common::NXCore::nxclose (
$tempFileFH);Common::NXCore::nxclose ($fileFH);if ((Common::NXFile::removeFile (
$filePath)==(0x0109+ 8364-0x21b5))){return ((0x03c3+ 8186-0x23bc));}if ((
Common::NXFile::renameFile ($tempFilePath,$filePath)==(0x1d27+  38-0x1d4d))){
return ((0x0936+ 3083-0x1540));}if ((
Common::NXFile::setOwnerShipAndPermissionsForNX ($filePath)==(-
(0x1089+ 2786-0x1b6a)))){return ((0x1f52+ 444-0x210d));}return (
(0x0246+ 7467-0x1f71));}sub isKeyInFile{(my $key=shift (@_));(my $keyFile=shift 
(@_));(my $protocol=shift (@_));(my (@listSupportedKeys)=__getKeysFromFile (
$keyFile));foreach my $line (@listSupportedKeys){if (__isKeyInLine ($key,$line,
$protocol)){Logger::debug (
"\x4b\x65\x79\x20\x69\x73\x20\x69\x6e\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x2e");
return ((0x0f4f+ 5715-0x25a1));}}Logger::debug (
"\x4b\x65\x79\x20\x69\x73\x20\x75\x6e\x69\x71\x75\x65\x2e");return (
(0x1275+ 4784-0x2525));}sub restorePrivateKey{(my $privateKey=
NXPaths::getClientPrivateKey ());(my $defaultPrivateKey=
NXPaths::getClientDefaultPrivateKey ());(my $restore=($privateKey.
"\x2e\x72\x65\x73\x74\x6f\x72\x65"));if (Common::NXFile::fileExists ($restore)){
copyKeyFile ($restore,$privateKey);copyKeyFile ($restore,$defaultPrivateKey);}}
sub isNotExistNodePublicKey{if (((not (Common::NXFile::isExists (
NXPaths::getNodePublicKeys ())))and (not (Common::NXFile::isExists (
NXPaths::getNXAuthorizedKeysPath ("\x6e\x78")))))){return ((0x19e6+ 3034-0x25bf)
);}if (Common::NXFile::isExists (NXPaths::getNXAuthorizedKeysPath ("\x6e\x78")))
{(my (@listSupportedKeys)=__getKeysFromFile (NXPaths::getNXAuthorizedKeysPath (
"\x6e\x78")));foreach my $line (@listSupportedKeys){if (__isAnyKeyInLine ($line,
"\x4e\x58")){Logger::debug (
"\x46\x6f\x75\x6e\x64\x20\x4e\x58\x20\x6b\x65\x79\x2e");return (
(0x15da+ 2087-0x1e01));}}}if (Common::NXFile::isExists (
NXPaths::getNodePublicKeys ())){(my (@listSupportedKeys)=__getKeysFromFile (
NXPaths::getNodePublicKeys ()));foreach my $line (@listSupportedKeys){if (
__isAnyKeyInLine ($line,"\x53\x53\x48")){Logger::debug (
"\x46\x6f\x75\x6e\x64\x20\x53\x53\x48\x20\x6b\x65\x79\x2e");return (
(0x0ebc+ 1794-0x15be));}}}return ((0x0ce9+ 308-0x0e1c));}sub 
getSupportedSSHDKeyExchangeAlgorithm{if ((
$GLOBAL::SupportedSSHDKeyExchangeAlgorithm=~ /DSA|RSA|all|DSA,RSA|RSA,DSA/ )){
return ($GLOBAL::SupportedSSHDKeyExchangeAlgorithm);}else{Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x6b\x65\x79\x3a\x20\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x53\x53\x48\x44\x4b\x65\x79\x45\x78\x63\x68\x61\x6e\x67\x65\x41\x6c\x67\x6f\x72\x69\x74\x68\x6d\x3a\x20"
.$GLOBAL::SupportedSSHDKeyExchangeAlgorithm).
"\x20\x75\x73\x65\x20\x61\x6c\x6c\x2e"));return ("\x61\x6c\x6c");}}sub 
isDSASuportedByServerConfig{(my $supportedKeyList=
getSupportedSSHDKeyExchangeAlgorithm ());if (($supportedKeyList=~ /DSA/ )){
return ((0x0e03+ 487-0x0fe9));}if (($supportedKeyList eq "\x61\x6c\x6c")){return
 ((0x0d73+ 5192-0x21ba));}return ((0x07dd+ 1761-0x0ebe));}sub 
isRSASuportedByServerConfig{(my $supportedKeyList=
getSupportedSSHDKeyExchangeAlgorithm ());if (($supportedKeyList=~ /RSA/ )){
return ((0x0694+ 4837-0x1978));}if (($supportedKeyList eq "\x61\x6c\x6c")){
return ((0x10f3+ 2563-0x1af5));}return ((0x033c+ 688-0x05ec));}sub add{(my $ref_parameters
=shift (@_));($$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}=uc (
$$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}));if (($$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}eq (""))){($$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}="\x4e\x58");}unless (__getKey (
$ref_parameters)){return ((0x1cfd+ 439-0x1eb4));}unless (prepareKey (
$ref_parameters)){return ((0x005c+ 9378-0x24fe));}unless (setKey (
$ref_parameters)){return ((0x0897+ 1973-0x104c));}NXMsg::send_response (
"\x69\x43\x4d\x44\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x41\x64\x64\x65\x64\x4f\x6b"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"});return ((0x05c7+ 1608-0x0c0e));}sub 
__getKey{(my $ref_parameters=shift (@_));if (($$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"}ne (""))){unless (__getKeyFromFile (
$ref_parameters)){return ((0x0fb2+ 4558-0x2180));}return ((0x05c3+ 5906-0x1cd4))
;}unless (__getKeyFromSTDIN ($ref_parameters)){return ((0x228d+ 427-0x2438));}
return ((0x0362+  97-0x03c2));}sub __getKeyFromFile{(my $ref_parameters=shift (
@_));unless (Common::NXFile::isExists ($$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"})){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"});return ((0x023d+ 2883-0x0d80));}(my $INFILE=
Common::NXCore::nxopen ($$ref_parameters{"\x6b\x65\x79\x46\x69\x6c\x65"},
$NXBits::O_RDONLY));unless (defined ($INFILE)){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x52\x65\x61\x64"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"});return ((0x0190+ 5179-0x15cb));}if ((
Common::NXCore::nxread ($INFILE,(\$$ref_parameters{"\x6b\x65\x79"}))==
(0x21c2+  93-0x221f))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x45\x6d\x70\x74\x79\x46\x69\x6c\x65"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"});Common::NXCore::nxclose ($INFILE);return (
(0x014a+ 5437-0x1687));}Logger::debug ((((("\x4b\x65\x79\x20\x27".
$$ref_parameters{"\x6b\x65\x79"}).
"\x27\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27").
$$ref_parameters{"\x6b\x65\x79\x46\x69\x6c\x65"})."\x27\x2e"));
Common::NXCore::nxclose ($INFILE);return ((0x188d+ 476-0x1a68));}sub 
__getKeyFromSTDIN{(my $ref_parameters=shift (@_));(my $message=
"\x4e\x58\x3e\x20\x39\x32\x33\x20\x50\x6c\x65\x61\x73\x65\x20\x65\x6e\x74\x65\x72\x20\x74\x68\x65\x20\x73\x73\x68\x2d\x64\x73\x73\x20\x6b\x65\x79\x3a"
);(my $bytes=main::nxwrite (main::nxgetSTDOUT (),$message));unless (($bytes>
(0x14f5+ 1344-0x1a35))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x6b\x65\x79\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6f\x6e\x20\x53\x54\x44\x4f\x55\x54\x2e"
);return ((0x03dc+ 2043-0x0bd7));}(($$ref_parameters{"\x6b\x65\x79"},
$$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$$ref_parameters{
"\x75\x75\x69\x64"})=__retrieveKey ());if (($$ref_parameters{"\x6b\x65\x79"}eq 
(""))){Logger::error (
"\x50\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x6e\x6f\x74\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e"
);return ((0x0968+ 1705-0x1011));}($$ref_parameters{"\x6b\x65\x79"}.="\x0a");
return ((0x19b0+ 1790-0x20ad));}sub prepareKey{(my $ref_parameters=shift (@_));(my $proto
=$$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"});if (($proto eq "\x4e\x58"
)){(my $authFile=NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));(my $authDir=
Common::NXFile::dirname ($authFile));Logger::debug (((
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6b\x65\x79\x73\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27"
.$authDir)."\x27\x2e"));if ((not (Common::NXFile::directoryExists ($authDir)))){my (
$error);unless (Common::NXPaths::createAccessibleForNXDirectory ((\$error),
$authDir)){NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x44\x69\x72"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$proto,$authDir);return ((0x0b37+ 5815-0x21ee));
}}($$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"}=$authFile);Logger::debug
 (((
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6b\x65\x79\x73\x20\x66\x69\x6c\x65\x20\x27"
.$$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"})."\x27\x2e"));}elsif ((
$proto eq "\x53\x53\x48")){($$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"}
=NXPaths::getNodePublicKeys ());if (isKeyInFile ($$ref_parameters{"\x6b\x65\x79"
},$$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"},$proto)){
removeKeyFromFile ($$ref_parameters{"\x6b\x65\x79"},$$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"},$proto);}}else{NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x55\x6e\x6b\x6e\x6f\x77\x6e\x50\x72\x6f\x74\x6f"
,"\x4e\x58\x53\x68\x65\x6c\x6c");return ((0x215f+ 1160-0x25e7));}if (
Common::NXFile::isExists ($$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"}))
{if ((Common::NXFile::setPermissionsReadWriteForNX ($$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"})==(-(0x2529+ 143-0x25b7)))){NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$proto,$$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"});return ((0x0eda+ 4707-0x213d));}}return (
(0x04c4+ 7037-0x2040));}sub setKey{(my $ref_parameters=shift (@_));(my $filepath
=$$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"});(my $mode=((
$NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND));(my $permissions=
$NXBits::UserReadWrite);(my $OUTFILE=Common::NXCore::nxopen ($filepath,$mode,
$permissions));unless (defined ($OUTFILE)){(my $errorString=
libnxh::NXGetErrorName ());NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x54\x6f\x57\x72\x69\x74\x65"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$filepath);return ((0x11d7+ 1825-0x18f8));}(my $keyToSave
=$$ref_parameters{"\x6b\x65\x79"});if (($$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}eq "\x53\x53\x48")){($keyToSave=
NXNodeExec::addPrefixForSSHKey ($$ref_parameters{"\x6b\x65\x79"}));}if ((
Common::NXCore::nxwrite ($OUTFILE,$keyToSave)==(-(0x137a+ 1356-0x18c5)))){
NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x57\x72\x69\x74\x65"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$filepath);Common::NXCore::nxclose ($OUTFILE
);return ((0x00a1+ 3390-0x0ddf));}Common::NXCore::nxclose ($OUTFILE);if ((
Common::NXFile::setOwnerShipAndPermissionsForNX ($filepath)==(-
(0x03ff+ 7511-0x2155)))){NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$filepath);return ((0x0792+ 2287-0x1081));}
if (($$ref_parameters{"\x75\x75\x69\x64"}ne (""))){NXNodes::setAccessKey (
$$ref_parameters{"\x75\x75\x69\x64"},$$ref_parameters{"\x6b\x65\x79"});}return (
(0x0408+ 1237-0x08dc));}sub __retrieveKey{(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});($$NXBegin::parser
{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=sub{Common::NXCore::nxexit ();}
);$selector->add ($signalFd);$selector->add (main::nxgetSTDIN ());(my $key=(""))
;(my $protocol=(""));(my $finish=(0x014f+ 9078-0x24c5));while (($finish==
(0x0b6b+ 5058-0x1f2d))){(my (@ready)=$selector->can_read ((0x1657+ 6259-0x1b42))
);if ((scalar (@ready)==(0x1f81+ 1049-0x239a))){Logger::debug (
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x2e");($finish=
(0x01af+ 4421-0x12f3));}foreach my $fh (@ready){Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x46\x44\x23".$fh)."\x2e"));if (($fh==
main::nxgetSTDIN ())){my ($read_buf);(my $bytes_read=main::nxread ($fh,(
\$read_buf),(0x1150+ 2011-0x092b)));Logger::debug (((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x53\x54\x44\x49\x4e\x20\x27".$read_buf
)."\x27\x2e"));if (($read_buf=~ /NX> params=(.*) / )){(my (%hashParameters)=
NXShell::urlParameter2Hash ($1));($key=$hashParameters{"\x6b\x65\x79"});(
$protocol=$hashParameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"});($uuid=
$hashParameters{"\x75\x75\x69\x64"});$selector->remove (main::nxgetSTDIN ());
$selector->remove ($signalFd);($finish=(0x0487+ 3934-0x13e4));}elsif ((
$bytes_read==(0x09c1+ 4235-0x1a4c))){$selector->remove (main::nxgetSTDIN ());
$selector->remove ($signalFd);($finish=(0x06dc+ 5689-0x1d14));}}}}return ($key,
$protocol,$uuid);}NXMsg::register_response (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x69\x43\x4d\x44\x41\x64\x64\x69\x6e\x67\x4b\x65\x79",(0x11ca+ 5576-0x26f8));
NXMsg::register_response ("\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x69\x43\x4d\x44\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x41\x64\x64\x65\x64\x4f\x6b"
,(0x1bc9+ 165-0x1bd3));NXMsg::register_error (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x4e\x6f\x74\x45\x78\x69\x73\x74"
,(0x086d+ 1961-0x0dd2));NXMsg::register_error (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x52\x65\x61\x64"
,(0x12d2+ 1938-0x1820));NXMsg::register_error (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x45\x6d\x70\x74\x79\x46\x69\x6c\x65"
,(0x0c13+ 1645-0x103c));return ((0x0ce3+ 4931-0x2025));
