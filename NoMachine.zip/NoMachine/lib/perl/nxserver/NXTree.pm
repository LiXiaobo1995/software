############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXTree;no warnings;($branchLength=(0x0573+ 455-0x0738));($refData=());(
$idField=(""));($parentField=(""));($drawPattern=(""));(@drawPatternFields=());(
$rootId=(""));($symbolLine="\xe2\x94\x80");($symbolBranch="\xe2\x94\x9c");(
$symbolFinish="\xe2\x94\x94");($symbolEmpty="\xe2\x94\x82");($loopTerminator=
"\x28\x2e\x2e\x2e\x29");($loopTerminatorID=(-(0x0715+ 5812-0x1dc8)));sub setData
{($refData=shift (@_));}sub setIdField{($idField=shift (@_));}sub setParentField
{($parentField=shift (@_));}sub setDrawPattern{($drawPattern=shift (@_));(
@drawPatternFields=@_);}sub setRootId{($rootId=shift (@_));}sub 
setLoopTerminator{($loopTerminator=shift (@_));}sub draw{(my (%drawData)=());
libnxh::NXSetConsoleOutputUTF8 ();__prepareData ((\%drawData));(my $count=
(0x0366+ 4466-0x14d8));(my $history=(""));foreach my $key (keys (%drawData)){if 
(($drawData{$key}{"\x70\x61\x72\x65\x6e\x74\x49\x44"}eq 
"\x5f\x5f\x6e\x6f\x6e\x65\x5f\x5f")){(++$count);}}foreach my $key (keys (
%drawData)){if (($drawData{$key}{"\x70\x61\x72\x65\x6e\x74\x49\x44"}eq 
"\x5f\x5f\x6e\x6f\x6e\x65\x5f\x5f")){if (($count==(0x09d6+ 5204-0x1e29))){
__drawForRoot ((\%drawData),$key,$history,"\x72\x6f\x6f\x74\x4c\x61\x73\x74");}
else{__drawForRoot ((\%drawData),$key,$history,
"\x72\x6f\x6f\x74\x4d\x69\x64\x64\x6c\x65");}(--$count);}}}sub __drawForRoot{(my $refDrawData
=shift (@_));(my $rootKey=shift (@_));(my $history=shift (@_));(my (@headType)=
@_);(my (@children)=());if (defined ($$refDrawData{$rootKey}{
"\x63\x68\x69\x6c\x64\x72\x65\x6e"})){(@children=@{$$refDrawData{$rootKey}{
"\x63\x68\x69\x6c\x64\x72\x65\x6e"};});}__drawEntry ($$refDrawData{$rootKey},
@headType);if ((($history=~ /,$rootKey,/ )or ($$refDrawData{$rootKey}{"\x49\x44"
}eq $rootId))){__drawEntry ($$refDrawData{$loopTerminatorID},@headType,
"\x6c\x61\x73\x74");return;}($history.=(("\x2c".$rootKey)."\x2c"));(my $counter=
(0x0579+ 7511-0x22cf));(my $childNumber=@children);foreach my $key (@children){
if (($counter==$childNumber)){__drawForRoot ($refDrawData,$key,$history,
@headType,"\x6c\x61\x73\x74");}else{__drawForRoot ($refDrawData,$key,$history,
@headType,"\x6d\x69\x64\x64\x6c\x65");}(++$counter);}}sub __drawEntry{(my $entry
=shift (@_));(my (@headType)=@_);(my $header=__getHeader (@headType));(my $message
=(($header.$$entry{"\x63\x61\x70\x74\x69\x6f\x6e"})."\x0a"));if ((main::nxwrite 
(main::nxgetSTDOUT (),$message)==(-(0x0501+ 5193-0x1949)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x1124+ 1638-0x1789)));}}sub __getHeader{(my (@headType)=@_);my ($header);(my $myHeadType
=pop (@headType));if (($myHeadType eq "\x72\x6f\x6f\x74\x4d\x69\x64\x64\x6c\x65"
)){($header=sprintf ("\x25\x73\x25\x73\x25\x73",$symbolBranch,$symbolLine,
$symbolLine));return ($header);}elsif (($myHeadType eq 
"\x72\x6f\x6f\x74\x4c\x61\x73\x74")){($header=sprintf (
"\x25\x73\x25\x73\x25\x73",$symbolFinish,$symbolLine,$symbolLine));return (
$header);}else{($header=("\x20" x int ($branchLength)));foreach my $head (
@headType){if (($head eq "\x72\x6f\x6f\x74\x4d\x69\x64\x64\x6c\x65")){($header=(
sprintf ("\x25\x73",$symbolEmpty).$header));}if (($head eq 
"\x72\x6f\x6f\x74\x4c\x61\x73\x74")){($header=("\x20".$header));}if (($head eq 
"\x6d\x69\x64\x64\x6c\x65")){($header.=(sprintf ("\x25\x73",$symbolEmpty).(
"\x20" x $branchLength)));}if (($head eq "\x6c\x61\x73\x74")){($header.=("\x20" 
x ($branchLength+(0x02ff+ 5462-0x1854))));}}}my ($branch);if (($myHeadType eq 
"\x6d\x69\x64\x64\x6c\x65")){($branch=sprintf ("\x25\x73\x25\x73\x25\x73",
$symbolBranch,$symbolLine,$symbolLine));}elsif (($myHeadType eq 
"\x6c\x61\x73\x74")){($branch=sprintf ("\x25\x73\x25\x73\x25\x73",$symbolFinish,
$symbolLine,$symbolLine));}($header.=$branch);return ($header);}sub 
__prepareData{(my $refDrawData=shift (@_));(my $uuid=(0x0f67+ 5521-0x24f8));
foreach my $key (keys (%$refData)){(my $entry=$$refData{$key});(my $caption=
getCaption ($entry));my ($parentID);if ((($$entry{$parentField}eq (""))or (
$$entry{$parentField}eq $rootId))){($parentID="\x5f\x5f\x6e\x6f\x6e\x65\x5f\x5f"
);}else{($parentID=$$entry{$parentField});}(my $dup=(0x04d4+ 3572-0x12c8));
foreach my $tmpKey (keys (%$refDrawData)){(my $tmpEntry=$$refDrawData{$tmpKey});
if ((($$entry{$idField}eq $$tmpEntry{"\x49\x44"})and ($parentID eq $$tmpEntry{
"\x70\x61\x72\x65\x6e\x74\x49\x44"}))){Logger::debug (((
"\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x27".
$$entry{$idField})."\x27\x2e"));($dup=(0x1830+ 3647-0x266e));last;}}if (($dup==
(0x06d0+ 7690-0x24da))){($$refDrawData{$uuid}={"\x63\x61\x70\x74\x69\x6f\x6e",
$caption,"\x49\x44",$$entry{$idField},"\x70\x61\x72\x65\x6e\x74\x49\x44",
$parentID});(++$uuid);}}foreach my $key (keys (%$refDrawData)){(my $entry=
$$refDrawData{$key});(my $parent=$$entry{"\x70\x61\x72\x65\x6e\x74\x49\x44"});if
 (($parent ne "\x5f\x5f\x6e\x6f\x6e\x65\x5f\x5f")){foreach my $tmpKey (keys (
%$refDrawData)){(my $tmpEntry=$$refDrawData{$tmpKey});if (($parent eq $$tmpEntry
{"\x49\x44"})){push (@{$$refDrawData{$tmpKey}{"\x63\x68\x69\x6c\x64\x72\x65\x6e"
};},$key);}}}}($$refDrawData{$uuid}={"\x63\x61\x70\x74\x69\x6f\x6e",
$loopTerminator,"\x49\x44",
"\x4c\x6f\x6f\x70\x5f\x54\x65\x72\x6d\x69\x6e\x61\x74\x6f\x72",
"\x70\x61\x72\x65\x6e\x74\x49\x44",
"\x4c\x6f\x6f\x70\x5f\x54\x65\x72\x6d\x69\x6e\x61\x74\x6f\x72"});(
$loopTerminatorID=$uuid);}sub getCaption{(my $entry=shift (@_));(my (@parameters
)=());foreach my $parameter (@drawPatternFields){push (@parameters,$$entry{
$parameter});}(my $caption=sprintf ($drawPattern,@parameters));return ($caption)
;}"\x3f\x3f\x3f";
