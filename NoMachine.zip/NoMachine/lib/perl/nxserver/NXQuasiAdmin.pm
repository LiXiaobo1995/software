############################################################################
#                                                                          #
#  Copyright (c) 2001, 2024 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXQuasiAdmin;no warnings;((%parameters)=());sub check{(my $user=shift (
@_));return (__handleQuasiAdminRequet ("\x63\x68\x65\x63\x6b",$user));}sub 
authorize{(my $user=shift (@_));return (__handleQuasiAdminRequet (
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65",$user));}sub __handleQuasiAdminRequet{(my $mode
=shift (@_));(my $user=shift (@_));Logger::debug (((((
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x71\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$mode)."\x27\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27").$user).
"\x27\x27\x2e"));(my (@command)=NXTools::getNXExecCommand ());if (($mode eq 
"\x63\x68\x65\x63\x6b")){push (@command,"\x2d\x2d\x69\x73\x61\x64\x6d\x69\x6e",
$user);}elsif (($mode eq "\x61\x75\x74\x68\x6f\x72\x69\x7a\x65")){push (@command
,"\x2d\x2d\x61\x64\x6d\x69\x6e\x61\x75\x74\x68",$user);}(my $rhost=
NXClientConnection::getRemoteIp ());(my $pid=(""));(my (@options)=());push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x52\x48\x4f\x53\x54\x3d".
$rhost));push (@options,"\x67\x65\x74\x20\x70\x69\x64",(\$pid));push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");($parameters
{"\x72\x65\x61\x64\x42\x75\x66\x66\x65\x72"}=(""));main::nxRunCommandBg ((
\@command),(\@options),(\$parameters{"\x73\x74\x64\x69\x6e"}),(\$parameters{
"\x73\x74\x64\x6f\x75\x74"}),(\$parameters{"\x73\x74\x64\x65\x72\x72"}));(my $parser
="\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);(my $signal
=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$parser->add ($signal);$parser->
add ($parameters{"\x73\x74\x64\x6f\x75\x74"},(\&callbackStdout),
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x3a\x63\x61\x6c\x6c\x62\x61\x63\x6b\x53\x74\x64\x6f\x75\x74"
,(\%parameters));$parser->setCallbackTimeout ((\&callbackTimeout),(\%parameters)
);$parser->setTimeout ($GLOBAL::AuthorizationTimeout);$parser->run;main::nxclose
 ($parameters{"\x73\x74\x64\x69\x6e"});(my $result=Common::NXProcess::nxwaitpid 
($pid,$NXBits::WAIT_UNTRACED,$GLOBAL::defaultTimeoutForProcessBeforeKill));(my $finish
=(0x2088+ 458-0x2251));if (($result==$pid)){($finish=
Common::NXProcess::getExitValue ($pid));}elsif ((not (
Common::NXProcess::isProcessRunning ($pid)))){($finish=(0x02b7+ 3932-0x1212));}
else{Logger::warning (((
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x43\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid).
"\x27\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x70\x72\x6f\x70\x65\x72\x6c\x79\x2e"
));Common::NXProcess::sigkill ($pid);($finish=(0x11b2+ 4010-0x215b));}
Logger::debug (((
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$finish)."\x27\x2e"));return ($finish);}sub callbackStdout{(my $self=shift (@_)
);(my $handleHash=shift (@_));(my $readBuffer=shift (@_));(my $readBytes=shift (
@_));(my $ref_params=$$handleHash{"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});
if ((($readBytes==(0x0f2a+ 1260-0x1416))or (not (defined ($readBytes))))){
Logger::debug (
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x53\x74\x64\x6f\x75\x74\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($$handleHash{"\x57\x61\x69\x74\x45\x4f\x46"}=(0x0b10+ 3439-0x187f));$self->
removeAndCloseHandle ($$ref_params{"\x73\x74\x64\x6f\x75\x74"});return;}(my $host
=Server::getHostnameForPropertyRequest ());(my $port=
NXAuth::getActiveConnectionPort ());Logger::debug (((
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x73\x74\x64\x6f\x75\x74\x20\x27"
.$readBuffer)."\x27\x2e"));if (($readBuffer=~ /assword/ )){(my $password=
NXMsg::send_hrequest ("\x68\x43\x4d\x44\x50\x72\x6f\x70\x65\x72\x74\x79",
"\x4e\x58\x53\x68\x65\x6c\x6c","\x70\x61\x73\x73\x77\x6f\x72\x64",$host,$port,
"\x73\x75\x64\x6f"));main::nxwrite ($$ref_params{"\x73\x74\x64\x69\x6e"},(
$password."\x0a"));}else{Logger::warning (((
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x61\x6e\x73\x77\x65\x72\x20\x27"
.$readBuffer)."\x27\x2e"));}}sub callbackTimeout{(my $self=shift (@_));(my $refParameters
=shift (@_));Logger::debug (
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e\x3a\x20\x54\x69\x6d\x65\x6f\x75\x74\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x2e"
);}return ((0x10a5+ 4533-0x2259));
